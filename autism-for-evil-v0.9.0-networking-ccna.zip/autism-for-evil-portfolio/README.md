# Autism For Evil — Personal Knowledge Workspace

**Version:** 0.9.0  
**Purpose:** A private, local-first place to learn technical subjects, keep reference notes and connect study to practical projects.

AFE is for personal use. It is not a public portfolio, course marketplace or publishing platform. The navigation is deliberately small:

- **Learning Paths** — a guided route through the notes, in the order that makes sense.
- **Notes** — the single searchable notebook: guided notes, references and exercises together.
- **Projects** — practical work connected to the things being learned.
- **Tools** — locally run Python utilities and their project notes.

The key distinction is simple: **a learning path tells you what to read next; the note is where the actual learning material lives.** Paths do not duplicate the notes.

## Start here

1. Run the workspace locally using the steps below.
2. Open `/learning-paths/` and start with **Networking & CCNA**. This is the primary technical route.
3. Follow its numbered notes in order. Each note explains one concept, shows how it connects to what came before, gives you something practical to try, and points to the next note.
4. Build **Python Foundations** alongside networking in manageable sessions. You do not need to finish all of Python before continuing with networking.
5. When a networking module links to a Python note or project, use it to apply the idea—for example, use `ipaddress` to verify subnet calculations or dictionaries and CSV files to model a fictional device inventory.
6. After the core networking route, use **Python for Network Engineers** for deeper automation work. The optional **OT Networking Extension** applies the foundations to industrial environments.

Open **Notes** when you need to look something up. Open **Learning Paths** when you want to know what to study next. The path is the route; the notes are the actual learning material. Missed days do not create overdue work: continue from the next unfinished note.

`Foundational Knowledge` supports the engineering process, problem solving, Git and software delivery. `Database Systems` is a shared technical path for SQL, PostgreSQL and application data.

## Run locally

Requirements: Node.js 22, npm and an internet connection for the first dependency installation.

```bash
npm install
npm run dev
```

Open the local address shown in the terminal, usually `http://localhost:4321`.

Build and type/content check:

```bash
npm run check
npm run build
npm run preview
```

The site is generated as a static Astro app. There is no account system or remote database. Lesson completion checkboxes are saved in the browser's local storage on the device where they are checked.

## How the learning paths work

The path definitions live in `src/data/learningPaths.ts`. This file explains each path's purpose, prerequisites, module progression, supporting reference notes and next directions.

All guided notes and reference material live together in `src/content/notes/`. A note can optionally belong to a Learning Path. Guided notes use these frontmatter fields:

- `pathId` — the learning path that contains the note.
- `module` — the stage within that path.
- `order` — its position in the sequence.
- `minutes` — a rough reading/practice estimate, not a deadline.
- `kind` — lesson, guide or project exercise.

The path page filters the same Notes collection by `pathId`, then presents those exact note files in order. Related deeper notes are also part of that collection and are linked from the relevant module. Update a note itself when changing teaching content; update `learningPaths.ts` when changing the route or connecting references.

## Current learning paths

| Path | Purpose | Notes |
|---|---|---:|
| Networking & CCNA | Networking foundations through addressing, switching, routing, services, security, operations and a capstone | 46 |
| Python Foundations | Core Python from first program to files, validation, tests and professional workflow | 15 |
| Python for Network Engineers | Apply Python to network operations and read-only OT lab tools | 14 |
| Python for Developers | Build maintainable Python applications and APIs | 17 |
| OT Networking Extension | Apply networking foundations to industrial architecture and protocols | 6 |
| Foundational Knowledge | SDLC, requirements, problem solving, design, data modelling, Git and delivery | 34 |
| Database Systems | Relational design, SQL, PostgreSQL, Python integration and operations | 18 |

Networking & CCNA is the recommended primary route. Python Foundations is its supporting programming skill; the Python specialist paths branch from there. The OT extension is optional and follows the relevant networking foundations.

## Where content lives

- `src/data/learningPaths.ts` — the map explaining how the notes connect.
- `src/content/notes/` — every guided note and reference note. Guided notes are stored under `learning/`; reference notes keep their original subject folders.
- `src/content/articles/` — personal field notes and write-ups, shown in the Notes area.
- `src/content/projects/` — project briefs and build records.
- `applications/python-network-tools/` — the local React + Vite interface and Python + FastAPI backend for the engineering tools.
- `public/downloads/` — source bundles for the local tools and starter projects.
- `src/pages/learning-paths/` — learning path index and generated path pages.
- `src/pages/notes/` — unified notes index and detail pages.
- `src/pages/learn/` — backwards-compatible redirects into the shared `/notes/` detail route.

## Networking material: clean restart

The imported standalone networking-notes collection has been removed completely. The old Switch Ops-derived notes, diagrams and migration files are not part of this workspace. The networking-specific Python automation learning path remains separate because it teaches Python by building engineering utilities; it is not a CCNA or networking theory notes collection.

The **Python for Network Engineers** path remains because it teaches Python applied to engineering tasks (inventory validation, IP planning, bounded diagnostics, log analysis, APIs and isolated OT protocol simulators). It is not a replacement for a proper networking/CCNA knowledge base. Any new networking fundamentals and CCNA notes will be authored from scratch and added to the same Notes collection, then connected to a new guided path.

## Personal and OT data boundaries

Keep this repository private unless you deliberately prepare it for sharing. Do not add workplace credentials, real asset inventories, customer network diagrams, internal hostnames, raw production configurations or unredacted logs. Use fictional examples, offline files, simulators and explicitly approved lab endpoints. The network-tools backend is designed for local learning; it is not permission to query production OT equipment.

## Useful commands

```bash
npm run dev       # Start the local site
npm run check     # Astro and TypeScript content checks
npm run build     # Build the static site
npm run preview   # Preview the production build
```

Keep this project boring to maintain. Add a new note when it solves a real learning need; update the learning path when it belongs in a sequence. Do not create another hub or navigation section just because a subject gets bigger.
