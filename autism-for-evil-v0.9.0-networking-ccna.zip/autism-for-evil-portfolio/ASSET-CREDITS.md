# Asset credits

AFE is a personal learning and reference workspace. It does not currently use stock portrait placeholders or the former gateway animation effects.

## PlasmaWave

The home-page `PlasmaWave` component is adapted from **React Bits / David Haz**:

- Repository: https://github.com/DavidHDev/react-bits
- License: https://github.com/DavidHDev/react-bits/blob/main/LICENSE.md

The component is decorative; page content remains usable without the visual effect. The upstream project identifies its license as MIT + Commons Clause. Review the current license before redistributing the component or making this source repository public. Keep the component attribution with the source.

No other third-party image assets are currently intended as permanent site content. Replace or remove any temporary imagery before sharing screenshots or deploying the workspace publicly.
