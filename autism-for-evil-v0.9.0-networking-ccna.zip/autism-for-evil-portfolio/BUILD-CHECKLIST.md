# Local Verification Checklist

Use this checklist after changing AFE. The workspace is intended for personal local use.

## Automated checks

- [ ] `npm install` completes successfully.
- [ ] `npm run check` completes without Astro/content errors.
- [ ] `npm run build` completes successfully.
- [ ] `npm run preview` serves the generated site.

## Navigation and learning flow

- [ ] `/` opens the personal workspace dashboard directly.
- [ ] Header has only Learning Paths, Notes, Projects and Tools (plus search/theme controls).
- [ ] `/learning-paths/` presents Networking & CCNA as the primary route, with Python Foundations as a supporting skill and specialist branches available later.
- [ ] Each path page shows the correct ordered note count.
- [ ] Each module contains the supporting reference notes configured for it.
- [ ] Every guided note opens the previous and next note in its path using the same `/notes/` route as reference material.
- [ ] Lesson completion checkboxes save and restore state in the current browser.
- [ ] `/notes/` search and category filters work.
- [ ] Each reference note points back to any relevant learning path.
- [ ] Search results open the correct path, lesson, note or project.

## Content and removal checks

- [ ] No standalone imported `src/content/networking/` collection exists.
- [ ] No navigation link exposes the old Networking, Development, Databases or Courses hubs.
- [ ] No page attempts to query an Astro `networking` collection.
- [ ] Only one Astro Notes collection exists; path notes and reference notes use the same note route.
- [ ] No page points to deleted `/networking/` note pages or `/networking-assets/` diagrams.
- [ ] Python for Network Engineers remains a clearly labelled Python specialization, not a general CCNA course.

## Responsive and accessibility checks

- [ ] Header navigation works on mobile.
- [ ] Learning path cards and module rows fit at 320px width.
- [ ] Search can be used by keyboard.
- [ ] Light and dark themes both remain readable.
- [ ] Reduced-motion settings are respected by decorative visuals.

## Local tools safety

- [ ] Network tools start in demo/local mode as documented.
- [ ] Reachability checks use only explicit, approved lab targets.
- [ ] PCAP analysis remains offline.
- [ ] OPC UA and Modbus examples use isolated simulators or authorised lab endpoints.

## Verification note for v0.9.0

Content/frontmatter, path-module alignment, supporting-note references, internal note links, and the learning-path TypeScript file were checked during this refactor. A full Astro content/build check remains outstanding because dependencies are not installed in this build environment; run the npm checks below on the local machine.


## Networking & CCNA v0.9.0 content checks

- [x] 46 guided Networking & CCNA notes have unique IDs, sequential order values and recognised module names.
- [x] 6 optional OT Networking Extension notes are assigned to their own learning path.
- [x] 5 networking reference notes are in the same Notes collection.
- [x] Learning-path references resolve to existing Notes IDs.
- [x] Internal `/notes/` links in the new networking and OT notes resolve.
- [x] Old Switch Ops-derived note/archive content is absent from the unified Notes collection.
- [ ] Run `npm install`, `npm run check` and `npm run build` on a machine with working npm registry access.
- [ ] Review the generated site in a browser at desktop and mobile widths.
