# Foundational Knowledge — learning-path reference index

**Path ID:** `foundational-knowledge`  
**Website:** `/learning-paths/foundational-knowledge/`  
**Level:** Beginner to intermediate  
**Prerequisites:** No programming experience required  
**Lessons:** 34  

## Purpose

This learning path teaches the engineering practices shared by software developers and network engineers. It begins with problem discovery and the SDLC, moves through requirements, algorithms, pseudocode, flowcharts, design and data modelling, then teaches Git, review, testing, documentation, security and delivery. A final mathematics module introduces discrete logic, data representation and an optional linear-algebra primer.

## How to study

1. Read each note in order, but take time to complete its exercise before continuing.
2. Save each deliverable in a small project folder. The artefacts accumulate into a project pack.
3. Use the seven Git references when you need command syntax or a workflow reminder.
4. Use the templates for requirements, pseudocode, data dictionaries, ERD reviews, test plans, ADRs and READMEs.
5. Treat the linear-algebra primer as enrichment; it is not a prerequisite for the project capstone.

## Lesson sequence

| # | Lesson | Module | Level | Minutes |
|---:|---|---|---|---:|
| 00 | [Start here: how engineers turn ideas into working systems](../src/content/notes/learning/foundational-knowledge/00-start-here.md) | Start here | Beginner | 12 |
| 01 | [The SDLC: the complete life of a software system](../src/content/notes/learning/foundational-knowledge/01-sdlc-overview.md) | Software development lifecycle | Beginner | 20 |
| 02 | [Find the real problem before choosing a technology](../src/content/notes/learning/foundational-knowledge/02-problem-statements-stakeholders.md) | Discovery and requirements | Beginner | 18 |
| 03 | [Requirements: what the system must do and how well](../src/content/notes/learning/foundational-knowledge/03-requirements-functional-nonfunctional.md) | Discovery and requirements | Beginner | 22 |
| 04 | [Scope, feasibility and project boundaries](../src/content/notes/learning/foundational-knowledge/04-scope-feasibility-constraints.md) | Discovery and requirements | Beginner | 18 |
| 05 | [User stories, use cases and acceptance criteria](../src/content/notes/learning/foundational-knowledge/05-user-stories-use-cases-acceptance.md) | Discovery and requirements | Beginner | 20 |
| 06 | [Break a large problem into smaller pieces](../src/content/notes/learning/foundational-knowledge/06-decomposition-abstraction.md) | Problem solving and algorithms | Beginner | 18 |
| 07 | [Algorithms: describe the steps before writing code](../src/content/notes/learning/foundational-knowledge/07-algorithms-and-logic.md) | Problem solving and algorithms | Beginner | 20 |
| 08 | [Pseudocode: plan logic in plain language](../src/content/notes/learning/foundational-knowledge/08-pseudocode-handbook.md) | Problem solving and algorithms | Beginner | 24 |
| 09 | [Flowcharts and decision tables](../src/content/notes/learning/foundational-knowledge/09-flowcharts-decision-tables.md) | Problem solving and algorithms | Beginner | 22 |
| 10 | [Software design: components, layers and responsibilities](../src/content/notes/learning/foundational-knowledge/10-software-design-architecture.md) | Design and architecture | Beginner–Intermediate | 22 |
| 11 | [How to structure a project so other people can work in it](../src/content/notes/learning/foundational-knowledge/11-project-structure-repositories.md) | Design and architecture | Beginner–Intermediate | 25 |
| 12 | [Data modelling: understand the information before the tables](../src/content/notes/learning/foundational-knowledge/12-data-modelling-foundations.md) | Database design foundations | Beginner | 20 |
| 13 | [Database design: from questions to a defensible schema](../src/content/notes/learning/foundational-knowledge/13-database-design-process.md) | Database design foundations | Beginner–Intermediate | 22 |
| 14 | [Entities, attributes, candidate keys and primary keys](../src/content/notes/learning/foundational-knowledge/14-entities-attributes-keys.md) | Database design foundations | Beginner | 22 |
| 15 | [Relationships, cardinality and optionality](../src/content/notes/learning/foundational-knowledge/15-relationships-cardinality-optionality.md) | Database design foundations | Beginner–Intermediate | 22 |
| 16 | [ERDs: draw a database before creating it](../src/content/notes/learning/foundational-knowledge/16-erds-crows-foot.md) | Database design foundations | Beginner | 25 |
| 17 | [Normalisation: reduce duplication without losing meaning](../src/content/notes/learning/foundational-knowledge/17-normalization-overview.md) | Database design foundations | Beginner–Intermediate | 24 |
| 18 | [From ERD to relational schema: tables and constraints](../src/content/notes/learning/foundational-knowledge/18-relational-schema-constraints.md) | Database design foundations | Beginner–Intermediate | 22 |
| 19 | [Git mental model: commits, trees, branches and remotes](../src/content/notes/learning/foundational-knowledge/19-git-mental-model.md) | Git and collaboration | Beginner | 20 |
| 20 | [Create a repository and keep it clean](../src/content/notes/learning/foundational-knowledge/20-git-repository-setup-hygiene.md) | Git and collaboration | Beginner | 24 |
| 21 | [The everyday Git workflow: status, diff, stage and commit](../src/content/notes/learning/foundational-knowledge/21-git-daily-workflow.md) | Git and collaboration | Beginner | 24 |
| 22 | [Write commit messages that tell a useful story](../src/content/notes/learning/foundational-knowledge/22-git-commit-messages.md) | Git and collaboration | Beginner–Intermediate | 26 |
| 23 | [Branches: work safely without disturbing the main line](../src/content/notes/learning/foundational-knowledge/23-git-branches-merging.md) | Git and collaboration | Beginner–Intermediate | 23 |
| 24 | [GitHub collaboration: remotes, pull requests and reviews](../src/content/notes/learning/foundational-knowledge/24-github-remotes-pull-requests.md) | Git and collaboration | Beginner–Intermediate | 24 |
| 25 | [Undo safely: restore, revert, reset, stash and conflicts](../src/content/notes/learning/foundational-knowledge/25-git-undo-conflicts-recovery.md) | Git and collaboration | Intermediate | 28 |
| 26 | [Testing and quality assurance across the lifecycle](../src/content/notes/learning/foundational-knowledge/26-testing-qa-quality.md) | Quality, documentation and delivery | Beginner–Intermediate | 23 |
| 27 | [Documentation that helps the next person](../src/content/notes/learning/foundational-knowledge/27-documentation-readmes-adr.md) | Quality, documentation and delivery | Beginner | 22 |
| 28 | [Secure engineering: protect data, access and operations](../src/content/notes/learning/foundational-knowledge/28-secure-engineering-basics.md) | Quality, documentation and delivery | Beginner–Intermediate | 23 |
| 29 | [CI/CD, releases and keeping systems healthy](../src/content/notes/learning/foundational-knowledge/29-cicd-release-maintenance.md) | Quality, documentation and delivery | Beginner–Intermediate | 24 |
| 30 | [Discrete mathematics for computing: logic, sets and relationships](../src/content/notes/learning/foundational-knowledge/30-discrete-mathematics-for-computing.md) | Mathematics for computing | Beginner | 30 |
| 31 | [Number systems and data representation: binary, decimal and hexadecimal](../src/content/notes/learning/foundational-knowledge/31-number-systems-and-data-representation.md) | Mathematics for computing | Beginner | 32 |
| 32 | [Linear algebra primer: vectors, matrices and practical uses](../src/content/notes/learning/foundational-knowledge/32-linear-algebra-primer.md) | Mathematics for computing | Beginner · Optional enrichment | 28 |
| 33 | [Capstone: plan a system like an engineering team](../src/content/notes/learning/foundational-knowledge/30-capstone-engineering-project-pack.md) | Capstone | Beginner–Intermediate | 35 |

## Git reference shelf

The following reference notes are available in `src/content/notes/git/`:
- [Git mental model: working tree, index, commits and remotes](../src/content/notes/git/00-git-mental-model.md)
- [Repository layout and .gitignore reference](../src/content/notes/git/01-repository-layout-and-gitignore.md)
- [Everyday Git command reference](../src/content/notes/git/02-everyday-git-command-reference.md)
- [Commit message style guide with examples](../src/content/notes/git/03-commit-message-style-guide.md)
- [Branching and pull-request workflow](../src/content/notes/git/04-branching-and-pull-request-workflow.md)
- [Safe undo and Git recovery reference](../src/content/notes/git/05-safe-undo-and-recovery.md)

## Reusable templates

Templates are stored in `docs/foundational-knowledge-templates/`:
- [Architecture Decision Record Template](foundational-knowledge-templates/architecture-decision-record-template.md)
- [Commit Message Examples](foundational-knowledge-templates/commit-message-examples.md)
- [Data Dictionary Template](foundational-knowledge-templates/data-dictionary-template.md)
- [Erd Review Checklist](foundational-knowledge-templates/erd-review-checklist.md)
- [Problem And Requirements Template](foundational-knowledge-templates/problem-and-requirements-template.md)
- [Project Readme Template](foundational-knowledge-templates/project-readme-template.md)
- [Pseudocode Template](foundational-knowledge-templates/pseudocode-template.md)
- [Test Plan Template](foundational-knowledge-templates/test-plan-template.md)

## Source archive

This index is a guide to the local notes and reference material in AFE. Use the Learning Paths area in the site to follow the sequence and open each note directly.
