# Data dictionary

| Entity | Field | Meaning | Conceptual type | Required? | Allowed values/rules | Source of truth |
|---|---|---|---|---|---|---|

## Business rules
-

## Historical data requirements
-

## Open questions
-
