# ADR-NNN: [Decision title]

- Status: proposed / accepted / superseded
- Date: YYYY-MM-DD

## Context
What problem, constraint or requirement prompted this decision?

## Decision
What have we decided?

## Alternatives considered

## Consequences
What becomes easier, harder, safer or more expensive?

## Follow-up actions
