# ERD review checklist

- [ ] Each entity represents a distinct concept that needs its own identity/lifecycle.
- [ ] Attributes have precise meanings and documented units.
- [ ] Candidate keys and primary keys are identified.
- [ ] Alternate identifiers have appropriate uniqueness rules.
- [ ] Foreign keys represent real relationships.
- [ ] Cardinality is shown at both ends.
- [ ] Optionality is explicit.
- [ ] Many-to-many relationships use an associative entity when mapped relationally.
- [ ] Repeating groups and multi-valued attributes are modelled intentionally.
- [ ] Historical/audit requirements are addressed.
- [ ] Sample scenarios can be represented without ambiguity.
- [ ] Diagram has a legend, owner and revision date.
