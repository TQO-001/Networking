# Foundational Knowledge project templates

Copy these templates into your own project and adapt them. They are starting points, not mandatory forms. Never fill them with confidential workplace data in a public repository.

- `problem-and-requirements-template.md`
- `pseudocode-template.md`
- `data-dictionary-template.md`
- `erd-review-checklist.md`
- `test-plan-template.md`
- `architecture-decision-record-template.md`
- `project-readme-template.md`
- `commit-message-examples.md`
