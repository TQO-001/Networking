# Project name

## Purpose

## Status
Planned / In progress / Complete. Be precise about what has actually been verified.

## Features

## Requirements

## Setup

## Configuration
List variable names and safe examples. Never include secret values.

## Run

## Test

## Project structure

## Limitations and safety boundaries

## Contributing
Branch, commit and review workflow.

## License
