# Project problem and requirements

## Problem statement
[Who needs what, why, desired outcome, constraint]

## Stakeholders
| Stakeholder | Need/interest | Decision or responsibility |
|---|---|---|

## Goals
- [ ]

## In scope
-

## Out of scope
-

## Assumptions
-

## Constraints
-

## Risks
| Risk | Likelihood | Impact | Mitigation | Owner |
|---|---|---|---|---|

## Functional requirements
| ID | Requirement | Priority | Verification |
|---|---|---|---|

## Non-functional requirements
| ID | Quality/constraint | Measure/condition | Verification |
|---|---|---|---|

## Acceptance criteria
- Given ... when ... then ...
