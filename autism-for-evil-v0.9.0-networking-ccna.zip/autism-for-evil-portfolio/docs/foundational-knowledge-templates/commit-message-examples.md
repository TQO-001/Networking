# Commit message examples

```text
chore: initialise project structure
feat(inventory): add CSV import preview
fix(validation): reject malformed IP address
refactor(api): separate asset service from route handler
test(import): cover missing CSV headers
docs: document Windows and Linux setup
ci: run lint and tests on pull requests
perf(search): index asset identifiers
```

For changes that need context:

```text
fix(import): avoid partial updates after invalid rows

Validate the complete input before applying accepted records.
This keeps the stored register consistent when an upload fails.

Refs: ASSET-IMPORT-04
```

Use imperative subjects, concise scopes, and body text for why/trade-offs. Follow the repository's own convention if it differs.
