# Changelog


## 0.9.0 — Networking & CCNA learning path (16 November 2026)

- Added a fresh 46-note Networking & CCNA learning sequence to the unified Notes collection.
- Organised the sequence into 11 modules: orientation, foundations, addressing, switching, routing, infrastructure, services, security, operations, automation and capstone.
- Connected Python references and existing network-engineering projects at the points where they reinforce networking concepts.
- Added a six-note optional OT Networking Extension for industrial architecture, segmentation, protocols and safe documentation.
- Added five focused networking reference notes, including a CCNA v2.0 coverage map and quick references for AAA, SFTP/SCP, IPsec and Layer 2 security.
- Aligned the exam mapping with Cisco's published 200-301 v2.0 blueprint and kept QoS clearly labelled as supplementary rather than a listed v2.0 objective.
- Reconfirmed that the old imported Switch Ops-derived note collection and diagrams are not part of AFE.
- Updated the homepage, Learning Paths index, README and content map to make Networking & CCNA the primary route, with Python as a supporting skill.


## 0.6.2 — Original Notes source map and computing mathematics (10 November 2026)

- Added `/development/source-notes/` to map the original public GitHub Notes folders to the curated Development, Networking, Database and Foundational Knowledge areas.
- Added source links from the Development, Networking and full reference-library pages.
- Preserved the accessible original `Tech Stack.md` roadmap as a local reference snapshot and marked it historical.
- Expanded Foundational Knowledge from 31 to 34 lessons with discrete mathematics, number systems/data representation, and an optional linear-algebra primer.
- Updated course counts, the content roadmap, README and build checklist.
- Kept the original GitHub repository as the source of truth for folders not imported into the site.

## 0.6.1 — Foundational Knowledge and original notes source map

- Added a 31-lesson Foundational Knowledge course covering SDLC, discovery, requirements, scope, user stories, algorithms, pseudocode, flowcharts, architecture, project structure, database design, ERDs, normalisation, Git, commit messages, testing, documentation, security, CI/CD and a capstone project pack.
- Added seven Git reference notes, including repository structure, `.gitignore`, daily commands, commit-message conventions, branching, pull requests, safe recovery and Git use in network engineering.
- Added reusable project-planning templates for requirements, pseudocode, data dictionaries, ERD reviews, test plans, ADRs and project READMEs.
- Added an original Notes repository source map linking the older GitHub folders to their organised areas on Autism For Evil.
- Clarified which source material has been curated locally and which original folders remain linked pending a full content review.


## 0.5.0 — Full-stack Python Network Tools (6 November 2026)

- Added a unified React + Vite workspace with eight dedicated tool screens.
- Added a modular Python 3.14 + FastAPI backend with individual routers, services and tests.
- Added a standalone source bundle at `public/downloads/python-network-tools-suite.zip`.
- Added a `/tools/` portfolio page with local Windows/Linux run instructions and links to each project brief.
- Kept OT protocol functions demo-first and read-only; constrained reachability checks and offline packet capture analysis.
- Added a shared Python-for-developers lesson explaining React frontends and Python APIs.

## 0.4.1 — Python code highlighting (6 November 2026)

- Added dual Shiki themes: Catppuccin Latte for light mode and Catppuccin Mocha for dark mode.
- Connected code-block colours to the website's existing theme toggle.
- Replaced the former muted green code-block surface with a branded purple/blue surface.
- Added common Python and shell fence aliases and normalised uppercase `Python` fences in the content collection.
- Kept long code lines horizontally scrollable to preserve indentation and CLI formatting.

## 0.4.0 — Development and Networking hubs (5 November 2026)

- Added a dedicated Development hub at `/development/`.
- Added a searchable Developer Notes index at `/development/notes/` for the original 28 Python/Foundation reference notes.
- Grouped developer references into Python foundations, Core Python, quality/performance, APIs/backend, automation, language/security, and exercises.
- Added a dedicated Database Systems hub at `/databases/`, with all 13 reference notes grouped by subject.
- Kept Networking independent at `/networking/`.
- Updated primary navigation, footer links, homepage workbench cards, the reference library filters, note-detail breadcrumbs and global search labels.
- Retained the shared Python foundation and cross-discipline database course architecture.


## v0.6.0 — Foundational Knowledge course

- Added 31 guided lessons on SDLC, requirements, algorithms, pseudocode, flowcharts, design, project structure, database modelling/ERDs, Git, commit messages, testing, documentation, security, CI/CD and capstone planning.
- Added seven dedicated Git reference notes to the Development notes library.
- Added reusable project artefact templates for requirements, pseudocode, data dictionaries, ERD reviews, test plans, ADRs, READMEs and commit messages.
- Linked Foundational Knowledge from the course catalogue, Development hub, Networking hub, Python tracks and Database Systems.

## 0.8.0 — Guided personal workspace

- Reframed AFE as a personal, local-first knowledge workspace rather than a public technical portfolio.
- Replaced the large multi-hub navigation with Learning Paths, Notes, Projects and Tools.
- Added an explicit learning-path map: Python Foundations first, then Python for Network Engineers or Python for Developers; Foundational Knowledge and Database Systems remain supporting paths.
- Linked supporting Python, Git and database reference notes to the exact module where they help.
- Replaced the separate reference-library URLs with `/notes/` while preserving old library/course URLs as redirects.
- Removed the imported standalone networking-notes collection, its Switch Ops content, diagrams and migration manifest. The Python-for-Network-Engineers path remains as a Python specialization.
- Made the workspace home page a practical dashboard rather than a portfolio gateway and biography.
- Added a focused verification checklist for the new learning and notes flow.

## 0.8.1 — One Notes collection

- Merged sequenced learning notes and reference notes into a single Astro `notes` collection.
- Learning Paths now filter and order the same note files instead of loading a separate lessons collection.
- Every learning note and reference note uses the same `/notes/...` detail route.
- Kept `/learn/...` and `/library/...` as compatibility redirects to the unified Notes pages.
- Removed the imported Switch Ops-derived networking note archive; Python for Network Engineers remains a clearly scoped Python specialization.
