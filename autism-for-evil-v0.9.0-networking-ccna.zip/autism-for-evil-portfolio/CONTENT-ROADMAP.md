# AFE Content Map

This document is an editorial map for the personal knowledge workspace. It is not a publishing schedule.

## Navigation

- `/` — personal workspace dashboard.
- `/learning-paths/` — guided routes through the notes.
- `/learning-paths/<slug>/` — a path overview with ordered notes and topic-linked supporting notes.
- `/notes/learning/<lesson-id>/` — the actual guided note (in the same Notes collection).
- `/notes/` — searchable guided notes, reference notes and personal field notes.
- `/notes/<note-id>/` — a note.
- `/projects/` — project index and build records.
- `/tools/` — local Python engineering utilities.
- `/search/` — search across paths, notes, field notes and projects.

## Learning paths

The canonical path metadata lives in `src/data/learningPaths.ts`.

| Learning path | `pathId` | Notes | Position |
|---|---|---:|---|
| Networking & CCNA | `networking-ccna` | 46 | Primary technical route |
| Python Foundations | `shared-python-foundations` | 15 | Supporting programming skill |
| Python for Network Engineers | `python-for-network-engineers` | 14 | Specialist branch after Python Foundations |
| Python for Developers | `python-for-developers` | 17 | Specialist branch after Python Foundations |
| OT Networking Extension | `ot-networking-extension` | 6 | Optional industrial specialisation after networking foundations |
| Foundational Knowledge | `foundational-knowledge` | 34 | Supporting engineering foundation |
| Database Systems | `database-management` | 18 | Shared data foundation |

A guided note's frontmatter `pathId`, `module` and `order` determine its position. Do not invent a second copy of a note just to make it appear in a path. Put a supporting reference link in `learningPaths.ts` instead.

## Notes collection

`src/content/notes/` is the only learning-note collection. It contains sequenced notes, deeper references, Python exercises, Git references and Database Management material. Each file is a note; a Learning Path only adds order and context to the notes it uses.

## Removed content

The previous imported standalone networking notes have been removed completely from AFE. The former Switch Ops / networking-note archive should not be re-imported. When new CCNA/networking content is created, author the actual notes first in the unified Notes collection, then connect those same notes to a guided Learning Path.

The Python for Network Engineers path remains as a Python specialization. It teaches how to apply Python to engineering problems; it is not the general CCNA curriculum.

## Writing standard for future notes

Each learning note should answer:

1. What will I be able to explain or do after this note?
2. Why does this topic exist, and what previous idea does it build on?
3. How does it work, using plain-language explanations and examples?
4. What should I try myself before looking at the answer?
5. How do I know I understood it?
6. What is the next note, and why does it come next?

Keep the main sequence approachable. Put long command lists, deeper edge cases and alternate examples in reference notes, then link them at the relevant stage.
