export type PathReference = {
  id: string;
  why: string;
};

export type PathModule = {
  title: string;
  purpose: string;
  references?: PathReference[];
};

export type LearningPath = {
  id: string;
  slug: string;
  code: string;
  title: string;
  shortTitle: string;
  description: string;
  outcome: string;
  level: string;
  prerequisite: string;
  role: string;
  tone: 'foundation' | 'python' | 'developer' | 'network' | 'database';
  featured?: boolean;
  modules: PathModule[];
  nextPathIds?: string[];
};

/**
 * A learning path is a guided route through the notes. The notes remain the
 * source material; this file only explains their order and how they connect.
 */
export const learningPaths: LearningPath[] = [

  {
    id: 'networking-ccna',
    slug: 'networking-and-ccna',
    code: 'NET-CCNA',
    title: 'Networking & CCNA',
    shortTitle: 'Networking & CCNA',
    description: 'Build networking knowledge in a deliberate sequence: understand devices and protocols, master addressing, learn switching and routing, then work through services, security, operations and automation. Python is connected to the topics where it is useful.',
    outcome: 'Explain, configure, verify and troubleshoot small routed and switched networks, with a structured foundation for the Cisco CCNA exam.',
    level: 'Beginner → CCNA preparation',
    prerequisite: 'No previous networking experience is required. Basic computer familiarity helps. Python is not a prerequisite; learn its foundations alongside the path and use it for selected practical exercises.',
    role: 'Primary learning path',
    tone: 'network',
    featured: true,
    modules: [
      {
        title: 'Getting oriented',
        purpose: 'Read the start note first. It explains the route, the flexible study method, how Python supports the networking work and how this path maps to the current CCNA blueprint.'
      },
      {
        title: 'Network foundations',
        purpose: 'Understand the equipment, topology, layered models, Ethernet, MAC addressing, ARP and transport protocols before configuring anything. This gives you a mental model for what later commands actually change.'
      },
      {
        title: 'IP addressing and subnetting',
        purpose: 'Build the mathematical foundation for every routed network. Learn binary, IPv4, masks, CIDR, subnetting, VLSM and IPv6. Do the calculations by hand first, then use Python to verify them.',
        references: [
          { id: 'learning/python-for-network-engineers/09-build-subnet-calculator', why: 'Turn the subnetting method into a small Python program after you can calculate the results manually.' },
          { id: 'learning/python-network-engineer-series/02-ipaddress-network-planning', why: 'Apply Python ipaddress objects to validate and plan network ranges.' },
          { id: 'section-02-data-types', why: 'Revisit Python values and types if the code examples feel unfamiliar.' }
        ]
      },
      {
        title: 'Switching and network access',
        purpose: 'Learn how a switch forwards frames, then create VLANs, carry them over trunks, route between them and prevent loops. Finish by verifying link aggregation and neighbour information.',
        references: [
          { id: 'learning/python-network-engineer-series/01-validate-network-inventory', why: 'Use structured device records to practise inventory validation without contacting live equipment.' },
          { id: 'learning/python-for-network-engineers/07-reading-csv', why: 'Learn how to read a small fictional switch/port inventory from CSV.' }
        ]
      },
      {
        title: 'IP routing',
        purpose: 'Understand how routers choose routes, configure static paths and learn the basics of OSPFv2/v3 and gateway redundancy. Then troubleshoot a whole path instead of focusing on one device.',
        references: [
          { id: 'learning/python-network-engineer-series/03-safe-reachability-checks', why: 'A later Python exercise for carefully bounded checks against explicitly approved targets.' }
        ]
      },
      {
        title: 'Infrastructure and client connectivity',
        purpose: 'Connect the logical design to physical media, wireless, virtual machines, containers and virtual routing. Learn to distinguish link faults from addressing, wireless, DHCP and application problems.'
      },
      {
        title: 'Network services',
        purpose: 'Understand DHCP, DNS and NAT, then learn the operational context of QoS. These services explain how hosts receive configuration, find applications and communicate beyond their local subnet.'
      },
      {
        title: 'Network security',
        purpose: 'Learn to manage devices securely, filter traffic with ACLs, understand IPsec VPNs and apply Layer 2 protections. Configuration examples are for controlled labs; real network changes require approval.',
        references: [
          { id: 'networking-reference/aaa-radius-tacacs-reference', why: 'A compact comparison of local authentication, RADIUS and TACACS+.' },
          { id: 'networking-reference/sftp-scp-device-files-reference', why: 'A checklist for securely transferring device configuration and software files.' },
          { id: 'networking-reference/ipsec-vpn-reference', why: 'A concise reference for IPsec, IKE and VPN modes.' },
          { id: 'networking-reference/layer2-security-controls-reference', why: 'A comparison of port security, DHCP snooping, DAI, storm control and RA Guard.' }
        ]
      },
      {
        title: 'Network operations and management',
        purpose: 'Make networks observable. Understand time synchronisation, SNMP, syslog, controller-based management and the difference between control, data and management planes.',
        references: [
          { id: 'networking-reference/ccna-v2-coverage-map', why: 'Use this as a final navigation aid to the official CCNA v2.0 domains; the Cisco blueprint remains authoritative.' },
          { id: 'learning/python-network-engineer-series/07-parse-network-logs', why: 'Apply Python to fictional or approved exported logs after learning what the events mean.' }
        ]
      },
      {
        title: 'Network automation and programmability',
        purpose: 'Learn APIs, REST and JSON, then compare Python and Ansible. Use small, testable, read-only or offline tasks before considering approved configuration automation.',
        references: [
          { id: 'learning/python-network-engineer-series/09-http-api-client', why: 'Practise calling an approved lab API with timeouts and response validation.' },
          { id: 'section-23-apis-and-json', why: 'A deeper Python reference for APIs and JSON data.' },
          { id: 'learning/python-network-engineer-series/13-network-ops-capstone', why: 'See how several small network engineering tools can be combined into a documented capstone.' }
        ]
      },
      {
        title: 'Applied networking capstone',
        purpose: 'Bring the foundations together in a small Packet Tracer network. Design first, configure in stages, verify each layer, introduce controlled lab faults and document the evidence.'
      }
    ],
    nextPathIds: ['python-for-network-engineers', 'ot-networking-extension']
  },
  {
    id: 'ot-networking-extension',
    slug: 'ot-networking',
    code: 'OT-01',
    title: 'OT Networking Extension',
    shortTitle: 'OT Networking',
    description: 'Apply networking foundations to industrial environments, with attention to availability, operational constraints, segmentation, industrial protocols and safe documentation.',
    outcome: 'Read industrial network architecture, explain trust boundaries and produce useful read-only documentation from approved or fictional data.',
    level: 'Intermediate specialisation',
    prerequisite: 'Complete the relevant Networking & CCNA foundations first. This is an optional extension, not a prerequisite for the CCNA.',
    role: 'Specialist extension',
    tone: 'network',
    modules: [
      { title: 'Getting oriented', purpose: 'Understand the purpose, prerequisites and safety boundaries of this OT extension.' },
      { title: 'OT foundations', purpose: 'Compare IT and OT operating requirements and learn why availability, process safety and change control affect network decisions.' },
      { title: 'Segmentation and architecture', purpose: 'Use zones, conduits and industrial architecture diagrams to reason about boundaries and permitted communication.' },
      {
        title: 'Industrial communication',
        purpose: 'Understand Modbus TCP and OPC UA conceptually and learn how to study them in isolated simulators.',
        references: [
          { id: 'learning/python-network-engineer-series/11-opcua-read-only-monitor', why: 'A read-only OPC UA lab exercise for a simulator.' },
          { id: 'learning/python-network-engineer-series/12-modbus-read-only-monitor', why: 'A read-only Modbus TCP lab exercise for a simulator.' }
        ]
      },
      {
        title: 'Safe operations and documentation',
        purpose: 'Build asset inventory and reporting skills from approved records or fictional data; preserve data provenance and do not probe production equipment.',
        references: [
          { id: 'learning/python-network-engineer-series/01-validate-network-inventory', why: 'Validate sample or approved inventory data.' },
          { id: 'learning/python-network-engineer-series/13-network-ops-capstone', why: 'Combine documentation and read-only tools in a small engineering capstone.' }
        ]
      }
    ],
    nextPathIds: []
  },
  {
    id: 'shared-python-foundations',
    slug: 'python-foundations',
    code: 'PY-01',
    title: 'Python Foundations',
    shortTitle: 'Python Foundations',
    description: 'Start with the language itself. Learn to run programs, work with values and collections, make decisions, use functions, handle files and errors, then organise and test small projects.',
    outcome: 'Write small, useful Python programs and understand how to improve them.',
    level: 'Beginner → Intermediate',
    prerequisite: 'No prior Python experience required.',
    role: 'Start here',
    tone: 'python',
    featured: true,
    modules: [
      {
        title: 'Python foundations',
        purpose: 'Learn the basic building blocks in the order you need them: running code, storing information, making decisions, repeating work, organising logic into functions, and reading structured data. The later exercises combine these ideas into a small subnet calculator.',
        references: [
          { id: 'section-01-python-basics', why: 'A deeper explanation of Python syntax, names, comments and basic input/output.' },
          { id: 'section-02-data-types', why: 'Use this when strings, numbers, booleans and collections start to feel unfamiliar.' },
          { id: 'section-04-control-flow', why: 'A fuller reference for conditionals and loops.' },
          { id: 'section-03-functions', why: 'A deeper reference for parameters, return values and reusable logic.' },
          { id: 'section-05-exception-handling', why: 'Revisit this when you begin validating input and handling failures.' },
          { id: 'section-06-file-io', why: 'Use this alongside the CSV lesson to understand reading and writing files.' },
        ],
      },
      {
        title: 'Professional workflow',
        purpose: 'Move from a script that works once to a small project that can be repeated, tested, understood and maintained. Project structure, Git, tests, type hints, formatting and logging support every later Python project.',
        references: [
          { id: 'section-12-modules-packages', why: 'The reference for splitting code into reusable files and packages.' },
          { id: 'section-14-testing', why: 'A deeper pytest reference once you reach automated tests.' },
          { id: 'section-15-16-typehints-logging', why: 'Use this as a reference for type hints and the move toward structured application code.' },
          { id: 'section-11-context-managers', why: 'Explains the resource-cleanup pattern used with files and other resources.' },
          { id: 'git/00-git-mental-model', why: 'A companion reference for understanding what Git is tracking.' },
          { id: 'git/02-everyday-git-command-reference', why: 'A practical command reference to keep beside the Git workflow lesson.' },
        ],
      },
    ],
    nextPathIds: ['networking-ccna', 'python-for-network-engineers', 'python-for-developers'],
  },
  {
    id: 'python-for-network-engineers',
    slug: 'python-for-network-engineers',
    code: 'PY-02A',
    title: 'Python for Network Engineers',
    shortTitle: 'Python for Network Engineers',
    description: 'Apply Python to network operations: validate inventories, plan IP networks, make bounded checks, inspect logs and offline packet captures, work with APIs, and read industrial protocol data in simulators.',
    outcome: 'Build small, testable network and OT engineering utilities.',
    level: 'Intermediate → Advanced',
    prerequisite: 'Complete Python Foundations first, especially functions, collections, files, exceptions, tests and project structure.',
    role: 'Specialist branch',
    tone: 'network',
    modules: [
      {
        title: 'Path overview',
        purpose: 'Orient yourself in this specialist path. It assumes Python Foundations is already complete, then explains how the coming inventory, monitoring, troubleshooting, services and OT engineering notes fit together. Read this first, then follow the numbered notes in order.'
      },
      {
        title: 'Inventory and data',
        purpose: 'Start with structured, offline data. Learn to validate device records and reason about IP addresses before interacting with any endpoint.',
        references: [
          { id: 'section-24-automation', why: 'A broader reference for using Python to automate repeatable work.' },
          { id: 'section-25-regular-expressions', why: 'An optional reference when text parsing becomes more complex.' },
        ],
      },
      {
        title: 'Monitoring and diagnostics',
        purpose: 'Turn individual checks into useful observations. Keep target lists explicit, apply timeouts and limits, and record what a check actually proves.',
        references: [
          { id: 'section-05-exception-handling', why: 'Review error handling before building checks that can fail.' },
          { id: 'section-15-16-typehints-logging', why: 'Use type hints and structured logging to make reports understandable.' },
        ],
      },
      {
        title: 'Troubleshooting and traffic',
        purpose: 'Work from existing evidence: exported logs and offline packet captures. Learn to parse, filter and summarise information without touching a production network.',
        references: [
          { id: 'section-23-apis-and-json', why: 'Useful for understanding structured data and exchanging reports.' },
          { id: 'section-25-regular-expressions', why: 'Supports pattern matching when parsing text logs.' },
        ],
      },
      {
        title: 'Network services',
        purpose: 'Connect to APIs and multiple lab services responsibly. Focus on timeouts, response validation, bounded concurrency and clear failure handling.',
        references: [
          { id: 'section-23-apis-and-json', why: 'The main reference for HTTP APIs and JSON data.' },
          { id: 'section-18-19-20-21-auth-tasks-cache-config', why: 'Read when working with authentication and configuration boundaries.' },
        ],
      },
      {
        title: 'OT protocols',
        purpose: 'Use read-only OPC UA and Modbus examples against an isolated simulator. Learn the data model and the difference between reading lab telemetry and changing a controller.',
        references: [
          { id: 'section-26-security-cryptography', why: 'A supporting reference for credentials, secure communication and handling sensitive data.' },
        ],
      },
      { title: 'Capstone', purpose: 'Combine inventory, bounded checks, logs and read-only lab data into a documented network-operations toolkit. Keep the scope small and state exactly what has been tested.' },
    ],
    nextPathIds: ['database-management', 'python-for-developers'],
  },
  {
    id: 'python-for-developers',
    slug: 'python-for-developers',
    code: 'PY-02B',
    title: 'Python for Developers',
    shortTitle: 'Python for Developers',
    description: 'Turn small scripts into maintainable software. Organise modules, use data models and objects deliberately, build reliable API clients and services, test interfaces, and connect applications to PostgreSQL.',
    outcome: 'Design, test and maintain a Python application or API.',
    level: 'Intermediate → Advanced',
    prerequisite: 'Complete Python Foundations first. You should be comfortable with functions, collections, files, exceptions and basic tests.',
    role: 'Specialist branch',
    tone: 'developer',
    modules: [
      {
        title: 'Path overview',
        purpose: 'Understand the shape of the developer path before starting. The notes move from maintainable Python, to HTTP clients, to backend services, then persistence, quality and full-stack delivery.'
      },
      {
        title: 'Maintainable Python',
        purpose: 'Learn how to divide code into sensible parts and use language features when they solve a real design problem. Modules come before advanced patterns; objects, generators and decorators build on that foundation.',
        references: [
          { id: 'section-07-oop', why: 'Deeper reference for classes, objects and composition.' },
          { id: 'section-09-decorators', why: 'A detailed reference for decorators after you understand functions.' },
          { id: 'section-10-generators-and-iterators', why: 'A deeper look at iteration and lazy data processing.' },
          { id: 'section-11-context-managers', why: 'Useful for understanding safe resource management.' },
          { id: 'section-12-modules-packages', why: 'The main reference for package and module design.' },
          { id: 'section-15-16-typehints-logging', why: 'Reference for type hints, models and logging.' },
        ],
      },
      {
        title: 'HTTP and APIs',
        purpose: 'Learn the client side of application integration before creating your own service. Understand HTTP requests, responses, JSON and predictable network failures.',
        references: [
          { id: 'section-23-apis-and-json', why: 'Companion reference for HTTP APIs and JSON.' },
          { id: 'section-22-production-api-patterns', why: 'Read after the basic API client lesson for production patterns.' },
        ],
      },
      {
        title: 'Backend development',
        purpose: 'Build a service in layers: create endpoints, validate incoming data, manage configuration and secrets, test failure cases, and introduce asynchronous I/O only where it helps.',
        references: [
          { id: 'section-17-fastapi', why: 'The detailed FastAPI reference.' },
          { id: 'section-18-19-20-21-auth-tasks-cache-config', why: 'Supporting reference for authentication, background tasks, caching and configuration.' },
          { id: 'section-26-security-cryptography', why: 'Security background for credentials, validation and sensitive data.' },
          { id: 'section-14-testing', why: 'Revisit pytest patterns when testing the service.' },
        ],
      },
      {
        title: 'Persistence',
        purpose: 'Connect the application to durable storage. Learn how the application creates, reads and updates records, and how to keep database access separate from request-handling code.',
        references: [
          { id: 'database-management/postgresql-python', why: 'Companion reference for connecting Python to PostgreSQL.' },
        ],
      },
      {
        title: 'Quality and performance',
        purpose: 'Improve reliability after the basic application works. Test important behaviour, profile before optimising, handle configuration carefully and document operational assumptions.',
        references: [
          { id: 'section-14-testing', why: 'Revisit pytest patterns when testing the service and its integrations.' },
          { id: 'section-13-advanced-performance', why: 'Use this after the profiling lesson, not before.' },
        ],
      },
      {
        title: 'Full-stack integration',
        purpose: 'Connect the API to a user interface through a clear request/response contract. Test the integration from the user’s point of view, not just each component in isolation.',
        references: [
          { id: 'section-22-production-api-patterns', why: 'A final checklist for robust API behaviour.' },
        ],
      },
      {
        title: 'Capstone',
        purpose: 'Bring the application together as a small, maintainable deliverable. Include setup instructions, tests, a concise architecture explanation and honest limitations.'
      },
    ],
    nextPathIds: ['database-management'],
  },
  {
    id: 'foundational-knowledge',
    slug: 'foundational-knowledge',
    code: 'ENG-01',
    title: 'Foundational Knowledge',
    shortTitle: 'Engineering Foundations',
    description: 'Understand the thinking and working practices behind software projects: the SDLC, requirements, problem solving, pseudocode, design, data modelling, Git, testing and delivery.',
    outcome: 'Plan and organise engineering work before and during implementation.',
    level: 'Beginner → Intermediate',
    prerequisite: 'No programming experience required. This path supports every development track.',
    role: 'Supporting foundation',
    tone: 'foundation',
    modules: [
      { title: 'Start here', purpose: 'Understand how to use the material and how the engineering topics fit together.' },
      { title: 'Software development lifecycle', purpose: 'See the whole lifecycle before exploring each activity in more detail.' },
      { title: 'Discovery and requirements', purpose: 'Define the problem, users, scope and acceptance conditions before deciding how to build.' },
      { title: 'Problem solving and algorithms', purpose: 'Turn requirements into steps and logic that can be implemented in any programming language.' },
      { title: 'Design and architecture', purpose: 'Organise responsibilities and plan the shape of a system before writing all the code.' },
      { title: 'Database design foundations', purpose: 'Model the information first, then translate entities and relationships into a relational schema.' },
      {
        title: 'Git and collaboration',
        purpose: 'Track changes as a sequence of deliberate decisions. This supports the Python project workflow and makes experimentation safer.',
        references: [
          { id: 'git/00-git-mental-model', why: 'The Git mental model behind commits, branches and remotes.' },
          { id: 'git/01-repository-layout-and-gitignore', why: 'A practical reference for repository structure and ignored files.' },
          { id: 'git/02-everyday-git-command-reference', why: 'Everyday commands in one place.' },
          { id: 'git/03-commit-message-style-guide', why: 'Examples for writing useful commit messages.' },
          { id: 'git/04-branching-and-pull-request-workflow', why: 'Branching and review workflow reference.' },
          { id: 'git/05-safe-undo-and-recovery', why: 'How to recover safely when a change goes wrong.' },
        ],
      },
      { title: 'Quality, documentation and delivery', purpose: 'Test work, document decisions, consider security and understand how software is released and maintained.' },
      { title: 'Mathematics for computing', purpose: 'Build supporting knowledge for logic, data representation and later technical subjects.' },
      { title: 'Capstone', purpose: 'Apply the engineering process from problem statement through delivery evidence.' },
    ],
    nextPathIds: ['shared-python-foundations', 'database-management'],
  },
  {
    id: 'database-management',
    slug: 'database-systems',
    code: 'DATA-01',
    title: 'Database Systems',
    shortTitle: 'Database Systems',
    description: 'Learn how data is modelled and stored, how to query it with SQL, and how PostgreSQL protects integrity, handles transactions and supports real applications.',
    outcome: 'Design and operate a dependable relational database for an application or engineering tool.',
    level: 'Beginner → Advanced',
    prerequisite: 'No SQL experience required. Basic Python is useful for the integration notes.',
    role: 'Shared technical foundation',
    tone: 'database',
    modules: [
      {
        title: 'Path overview',
        purpose: 'Preview the whole database journey: SQL first, then relational design, PostgreSQL operations, Python integration, reliability, performance, security and applied work. Use this as the map, then begin with SQL foundations.'
      },
      {
        title: 'SQL foundations',
        purpose: 'Start with the relational model, then read, filter, join and safely change data. These are the query skills used by every later database topic.',
        references: [
          { id: 'database-management/sql-dbm', why: 'A beginner-friendly SQL and database management reference.' },
        ],
      },
      {
        title: 'Relational design',
        purpose: 'Model the information before building tables. Learn relationships, keys, normalisation and constraints so the database can protect data quality.',
        references: [
          { id: 'database-management/dbm-02-design-principles', why: 'Supporting notes on relational design and normalisation.' },
          { id: 'database-management/dbm-03-advanced-schema-design', why: 'Deeper schema design reference for later review.' },
          { id: 'database-management/dbm-04-data-integrity', why: 'A deeper reference for constraints and integrity.' },
        ],
      },
      {
        title: 'PostgreSQL operations',
        purpose: 'Move from SQL concepts to a real PostgreSQL environment. Set up a safe learning database, understand roles and practise the operational basics.',
        references: [
          { id: 'database-management/dbm-01-storage-architecture', why: 'Understand how PostgreSQL stores and organises data.' },
        ],
      },
      {
        title: 'Python integration',
        purpose: 'Connect application code to a database, handle transactions deliberately and keep credentials out of source code.',
        references: [
          { id: 'database-management/postgresql-python', why: 'Python/PostgreSQL integration reference.' },
        ],
      },
      {
        title: 'Reliability and concurrency',
        purpose: 'Understand transactions, MVCC and locking. These concepts explain how PostgreSQL keeps concurrent work consistent.',
        references: [
          { id: 'database-management/dbm-07-08-09-mvcc-security-backup', why: 'Supporting notes on concurrency, security and recovery.' },
        ],
      },
      {
        title: 'Performance and maintenance',
        purpose: 'Learn how indexes and query plans affect performance, then practise migrations and monitoring so databases remain maintainable.',
        references: [
          { id: 'database-management/dbm-05-indexes-in-depth', why: 'Index design reference after the indexes lesson.' },
          { id: 'database-management/dbm-06-query-planning', why: 'Query planning reference for performance investigations.' },
          { id: 'database-management/dbm-10-11-monitoring-migrations', why: 'Operations and migration reference.' },
          { id: 'database-management/dbm-12-13-tuning-replication', why: 'Advanced performance and replication reference.' },
        ],
      },
      {
        title: 'Security and recovery',
        purpose: 'Protect database access and plan for recovery. Treat permissions, backups and restoration as part of the design rather than afterthoughts.',
        references: [
          { id: 'database-management/dbm-07-08-09-mvcc-security-backup', why: 'Reference for security, backups and recovery planning.' },
        ],
      },
      {
        title: 'Advanced PostgreSQL',
        purpose: 'Explore advanced database capabilities after the core relational and operational ideas are secure.',
        references: [
          { id: 'database-management/dbm-14-15-16-partitioning-indexing-patterns', why: 'Advanced schema and indexing patterns.' },
          { id: 'database-management/dbm-17-18-19-20-zerodowntime-pooling-fts-jsonb', why: 'Further reference for pooling, search, JSONB and safe changes.' },
        ],
      },
      { title: 'Applied track: network operations', purpose: 'Apply database concepts to asset inventories, observations, event history and engineering reports.' },
      { title: 'Applied track: developers', purpose: 'Apply the same database foundation to a Python application and its API.' },
      { title: 'Capstone', purpose: 'Bring the design, SQL, application integration and operational decisions together in one documented database project.' },
    ],
    nextPathIds: ['python-for-developers', 'python-for-network-engineers'],
  },
];

export const getLearningPath = (slug: string) => learningPaths.find((path) => path.slug === slug);
export const getLearningPathById = (id: string) => learningPaths.find((path) => path.id === id);
