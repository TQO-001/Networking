---
title: "Algorithms: describe the steps before writing code"
description: "Understand algorithms, sequence, selection, iteration, validation and termination."
order: 7
minutes: 20
level: "Beginner"
pathId: "foundational-knowledge"
module: "Problem solving and algorithms"
tags: ["algorithms", "logic", "sequence", "iteration"]
kind: "lesson"
---

## What is an algorithm?

An **algorithm** is a finite, ordered set of instructions for solving a problem. It is language-independent: the same algorithm can later be implemented in Python, JavaScript or another language.

A useful algorithm has:

- Defined inputs.
- Clear steps.
- A defined result.
- A way to handle invalid or unexpected inputs.
- A termination condition so it does not run forever.

## Three basic control structures

**Sequence** means steps happen in order. Example: read a CSV, parse the header, then parse rows.

**Selection** means choose a path based on a condition. Example: if an IP address is valid, accept the row; otherwise record an error.

**Iteration** means repeat a step. Example: process each row until there are no rows left.

These structures are the foundation of most procedural logic.

## Worked example: validate a batch of asset records

Inputs: a list of candidate rows. Output: accepted records and rejected rows with reasons.

1. Create empty accepted and rejected lists.
2. For each row, check required fields.
3. If a required field is missing, add the row and reason to rejected.
4. Otherwise validate the IP address.
5. If invalid, reject it with a reason.
6. Otherwise check whether the asset ID has already appeared.
7. If duplicate, reject or flag it according to the agreed rule.
8. Otherwise add the record to accepted and remember its ID.
9. Return both lists.

Notice the duplicate rule is a requirement decision, not something the programmer should guess. Should the first row win? Should all duplicates be rejected? The behaviour must be agreed.

## Trace a small example

| Row | Asset ID | IP | Expected result |
|---:|---|---|---|
| 1 | PLC-LAB-01 | 192.0.2.10 | Accepted |
| 2 | HMI-LAB-01 | invalid | Rejected: invalid IP |
| 3 | PLC-LAB-01 | 192.0.2.11 | Rejected/flagged: duplicate ID |

The IP range `192.0.2.0/24` is reserved for documentation examples, not a real deployment plan.

## Common algorithm mistakes

- No termination condition in a loop.
- Checking only the normal case.
- Forgetting empty input.
- Mixing validation, storage and display into one step.
- Using a condition whose meaning is unclear.
- Failing to decide what happens when multiple rules conflict.

## Exercise

Write the steps for a tool that reads a list of ports and flags values outside the valid range. Include the behaviour for an empty list and a non-numeric input.

## Checkpoint

Can another person follow your algorithm and predict the result without knowing a programming language? If not, make the steps more precise.
