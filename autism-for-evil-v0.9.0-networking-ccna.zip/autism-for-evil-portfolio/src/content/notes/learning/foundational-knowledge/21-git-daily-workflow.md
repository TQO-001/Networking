---
title: "The everyday Git workflow: status, diff, stage and commit"
description: "Practise a repeatable small-change workflow and learn to inspect exactly what will enter a commit."
order: 21
minutes: 24
level: "Beginner"
pathId: "foundational-knowledge"
module: "Git and collaboration"
tags: ["git-status", "git-diff", "git-add", "git-commit"]
kind: "lesson"
---

## The safe daily loop

Use this sequence whenever you make a small change:

```bash
git status
git diff
# edit files
git status
git diff
git add path/to/file
git diff --cached
git status
git commit -m "docs: explain asset import validation"
```

The exact filenames will differ. The important habit is to inspect before and after staging.

## What the commands do

- `git status` summarises the working tree and staging area.
- `git diff` shows unstaged changes.
- `git add <path>` stages the current content of a file or directory.
- `git diff --cached` shows what is staged for the next commit.
- `git commit` records the staged snapshot.
- `git log --oneline` shows compact history.

`git add` does not mean “save forever”. It selects a version of the content for the next commit. If you edit the file again after staging, the new edit is not automatically included until you stage it again.

## Stage deliberately

For a focused change, prefer:

```bash
git add src/asset_register/validation.py tests/test_validation.py
```

over blindly staging everything with `git add .`. Staging everything can be fine when you have inspected all changes, but do not make it a reflex. You might accidentally stage local notes, large exports or secrets.

## Inspect a commit

After committing:

```bash
git log --oneline --max-count=5
git show --stat HEAD
git show --format=fuller HEAD
```

These commands help you understand what was recorded. A good commit should contain only the intended change and have a message that summarises it accurately.

## A practical sequence of small commits

For the capstone, a readable history might look like:

```text
chore: initialise asset register project
 docs: record first-release requirements
 feat(validation): validate asset identifiers
 test(validation): cover duplicate identifiers
 feat(api): expose asset import preview
 docs: explain local development setup
```

Each commit captures a coherent step. Do not create artificial commits just to reach a number; the goal is useful history.

## Exercise

Make three separate changes to your capstone: add a README section, create a small validation function and add a test. Stage and commit each change separately. Use `git show` to inspect them.

## Checkpoint

Explain the difference between `git diff` and `git diff --cached`. Why is it useful to inspect both before committing?
