---
title: "Linear algebra primer: vectors, matrices and practical uses"
description: "Get an approachable introduction to vectors and matrices, and recognise where linear algebra appears in graphics, data processing and engineering."
order: 32
minutes: 28
level: "Beginner · Optional enrichment"
pathId: "foundational-knowledge"
module: "Mathematics for computing"
tags: ["linear-algebra", "vectors", "matrices", "maths", "enrichment"]
kind: "guide"
---

## Why include linear algebra?

Most beginner software and network tools do not require advanced linear algebra. However, vectors and matrices appear in computer graphics, image processing, machine learning, simulations, statistics and some forms of signal analysis. This primer gives you enough vocabulary to recognise those ideas later.

This is an **enrichment lesson**, not a prerequisite for Python, Git, database design or network automation.

## Vectors

A vector is an ordered collection of values. In a simple two-dimensional example, a vector may represent a point or a direction:

\[
\mathbf{v} = \begin{bmatrix} 3 \\ 2 \end{bmatrix}
\]

The first value could represent horizontal position and the second vertical position. In data analysis, a vector might instead represent several measurements belonging to one observation.

Vectors of the same length can be added component by component:

\[
\begin{bmatrix} 3 \\ 2 \end{bmatrix} + \begin{bmatrix} 1 \\ 4 \end{bmatrix} = \begin{bmatrix} 4 \\ 6 \end{bmatrix}
\]

## Matrices

A matrix is a rectangular arrangement of values in rows and columns. It can represent a table of measurements, a transformation or a system of equations.

```text
A = | 1  2 |
    | 3  4 |
```

A two-dimensional matrix can describe a transformation applied to a vector. In graphics, a matrix can rotate, scale or translate points when combined with the appropriate coordinate representation.

## Dot product

For two vectors of the same length, the dot product multiplies matching components and adds the results:

\[
[3, 2] \cdot [1, 4] = (3 \times 1) + (2 \times 4) = 11
\]

Dot products are used in geometry, projections, similarity calculations and machine-learning models. You do not need to memorise applications yet; understand the operation and why the vector lengths must match.

## Where linear algebra appears

- **Graphics:** transformations of positions, directions and camera coordinates.
- **Data analysis:** data sets represented as vectors and matrices.
- **Machine learning:** weighted sums and matrix operations across many inputs.
- **Signal processing:** representing and transforming sampled measurements.
- **Simulation:** working with multiple related quantities in one model.

## A small Python representation

Plain Python lists can represent a simple vector or matrix for learning:

```python
vector = [3, 2]
other = [1, 4]

sum_vector = [a + b for a, b in zip(vector, other)]
dot_product = sum(a * b for a, b in zip(vector, other))

print(sum_vector)   # [4, 6]
print(dot_product)  # 11
```

For substantial numerical work, specialised numerical libraries provide safer and more efficient operations. This course uses plain lists only to make the underlying idea visible.

## Exercises

1. Add the vectors `[2, 5]` and `[4, 1]`.
2. Calculate the dot product of `[2, 5]` and `[4, 1]`.
3. State the number of rows and columns in a 3 × 2 matrix.
4. Name one software field where matrices are useful and explain why.
5. Explain why this enrichment lesson is not a prerequisite for the network tools in this portfolio.

## Checkpoint

Describe a vector and a matrix in your own words. Give one example of each from outside mathematics class.
