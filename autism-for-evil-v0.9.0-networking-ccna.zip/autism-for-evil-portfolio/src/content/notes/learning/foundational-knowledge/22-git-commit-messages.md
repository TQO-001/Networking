---
title: "Write commit messages that tell a useful story"
description: "Use clear subject lines, optional scopes, body text and Conventional Commits without turning messages into bureaucracy."
order: 22
minutes: 26
level: "Beginner–Intermediate"
pathId: "foundational-knowledge"
module: "Git and collaboration"
tags: ["commit-messages", "conventional-commits", "git", "workflow"]
kind: "lesson"
---

## Why commit messages matter

A commit message is documentation attached to a change. Future you, a reviewer or another engineer may use it to understand why a change happened without reopening the entire discussion.

Weak messages:

```text
update
fix stuff
final changes
working version
changes 2
```

Useful messages:

```text
feat(inventory): reject duplicate asset identifiers
fix(api): return a clear error for invalid CIDR input
docs(networking): clarify the lab VLAN example
test(parser): cover empty CSV files
```

## A practical format

Conventional Commits use this common structure:

```text
<type>[optional scope]: <short description>

[optional body]

[optional footer(s)]
```

The type describes the nature of the change. Useful types include:

| Type | Use |
|---|---|
| `feat` | Add user-facing functionality |
| `fix` | Correct a defect |
| `docs` | Change documentation |
| `test` | Add or change tests |
| `refactor` | Restructure code without intended behaviour change |
| `perf` | Improve performance |
| `build` | Change build system or dependencies |
| `ci` | Change continuous integration workflows |
| `chore` | Maintenance that does not fit another category |
| `revert` | Revert an earlier commit |

A scope is optional and identifies the affected area, such as `api`, `inventory`, `database` or `networking`.

## Write a strong subject line

A good subject line:

- Starts with a meaningful type.
- Uses imperative wording: “Add”, “Fix”, “Document”, “Remove”.
- Says what changed, not merely that a change happened.
- Avoids a full stop at the end by convention.
- Is concise; many teams aim for roughly 50–72 characters, but follow the repository's own rule.

Prefer `feat(api): add read-only device status endpoint` over `feat(api): added endpoint`.

## When to add a body

Use the body when the subject cannot explain the reason, impact or trade-off. Wrap long lines for readability if your team expects it.

Example:

```text
fix(import): preserve existing records after invalid CSV

Validate the complete upload before applying accepted rows.
This prevents a malformed file from leaving the register in a
partially updated state.

Refs: FND-24
```

The body should explain **why** the change was needed or what important decision it records. The code diff already shows much of what changed.

## Breaking changes and issue references

A breaking change alters an interface or behaviour in a way that requires users or other code to adapt. Conventional Commits can mark this as `feat(api)!: rename asset identifier field` and explain the migration in a `BREAKING CHANGE:` footer. Teams may use different issue-reference conventions; follow the project's workflow.

## What not to put in a commit message

Do not include passwords, tokens, private hostnames, confidential incident details or personal information. Commit history can be retained and copied to remote systems even after a file is deleted from the latest version.

## Exercise

Rewrite these weak messages: `updates`, `fixed`, `new code`, `stuff`, `readme`. Then write one detailed commit message body for a design decision that explains why the app validates an entire CSV before saving it.

## Checkpoint

A reviewer reads only your subject line. Can they tell the type of change and affected area? If the reason is important, does the body explain it?
