---
title: "Git mental model: commits, trees, branches and remotes"
description: "Understand version control concepts before memorising commands."
order: 19
minutes: 20
level: "Beginner"
pathId: "foundational-knowledge"
module: "Git and collaboration"
tags: ["git", "version-control", "commit", "branch", "remote"]
kind: "lesson"
---

## What Git is

Git is a distributed version-control system. It records project history as commits and lets you compare, branch and merge changes. Git runs on your computer. GitHub is a hosting and collaboration service that stores remote repositories and provides pull requests, issue tracking and reviews.

Git is not a cloud backup for every file on your machine. It only records what you stage and commit. A file that is ignored, untracked or never staged is not in the commit.

## The three local states

A beginner-friendly mental model has three areas:

1. **Working tree:** the files you currently see and edit.
2. **Staging area/index:** the exact changes selected for the next commit.
3. **Repository history:** the commits already recorded.

You edit a file in the working tree, stage the change and commit it. You can stage only part of a file or stage several files together.

## Commits and snapshots

A commit is a recorded project snapshot plus metadata: author, time, message and a reference to its parent commit(s). Git stores content efficiently; it is helpful to think of a commit as a snapshot, not as a patch file you must manually replay.

A commit should represent a coherent, understandable change. “Add duplicate asset validation” is a useful checkpoint. “Changes” tells a future reader almost nothing.

## Branches

A branch is a movable name pointing to a commit. It lets you develop a feature or fix separately from the main line of work. Branches are lightweight; they are not separate copies of the entire project in the usual mental model.

## Remotes

A remote is a named reference to another repository, often hosted on GitHub. `origin` is a common default name, not a magic word. You can fetch remote history, push your commits and open a pull request for review.

## Exercise

Draw a simple picture with a working tree, staging area, local commit history and a GitHub remote. Use arrows to show edit → stage → commit → push. Add a branch diverging from `main` and merging back.

## Checkpoint

Explain in your own words the difference between Git and GitHub. Then explain why committing and pushing are two separate actions.
