---
title: "Data modelling: understand the information before the tables"
description: "Identify facts, entities, attributes, identifiers, events and relationships before designing a database."
order: 12
minutes: 20
level: "Beginner"
pathId: "foundational-knowledge"
module: "Database design foundations"
tags: ["data-modelling", "entities", "attributes", "database"]
kind: "lesson"
---

## Data modelling starts with meaning

A database design should represent facts about a domain. Before making tables, identify what the organisation needs to remember and what questions it needs to answer.

For the asset register, possible facts include:

- A device has an asset identifier, hostname, role and location.
- A device may have one or more interfaces.
- An interface may have an IP address and VLAN assignment.
- A review event records when a person checked an asset and what changed.

These are not yet SQL tables. They are statements about the world that we need to validate with stakeholders.

## Entity, attribute and relationship

An **entity** is a thing or concept we need to track, such as Device, Interface, Location or Review.

An **attribute** describes an entity, such as hostname or serial number.

A **relationship** describes how entities are associated, such as a Device having Interfaces or a Device being assigned to a Location.

Do not create an entity for every noun in a sentence. Ask whether it has its own identity, attributes, lifecycle or relationships. Some values are better represented as attributes or controlled lookup values.

## Facts, events and snapshots

A current-state record answers “what is true now?” An event record answers “what happened, and when?” These are different needs.

If a device's location changes, overwriting the old location may be enough for a simple register. If you must audit historical assignments, record a time-stamped change event or effective-dated history. Decide based on the requirement; do not assume a database automatically preserves history.

## Data ownership and source of truth

For every important field, ask who owns it and which source is authoritative. If hostname comes from one inventory and location comes from another spreadsheet, define how conflicts are resolved. A database is not automatically the truth simply because it stores the value.

## Exercise

Write ten plain-language facts the OT asset register must remember. Highlight nouns and verbs, then propose entities, attributes and relationships. Mark any fact whose owner or source is unknown.

## Checkpoint

Explain the difference between a device and an observation about a device. Why might the observation need its own timestamp and identifier?
