---
title: "Branches: work safely without disturbing the main line"
description: "Create feature branches, keep changes focused and understand merge commits and fast-forward merges."
order: 23
minutes: 23
level: "Beginner–Intermediate"
pathId: "foundational-knowledge"
module: "Git and collaboration"
tags: ["git-branch", "merge", "feature-branches"]
kind: "lesson"
---

## Why branches exist

A branch lets you work on a change separately from the main line of development. You can test, review and refine a feature without mixing unfinished work into `main`.

A common workflow is:

```bash
git switch main
git pull --ff-only
git switch -c feat/asset-import-preview
# make changes, test, commit
git status
git switch main
git merge --no-ff feat/asset-import-preview
```

This is a teaching sequence. In a team, the merge is often performed through a reviewed pull request on GitHub rather than directly on the local machine.

## Branch naming

Use names that describe the work:

```text
feat/asset-import-preview
fix/duplicate-hostname-validation
docs/git-workflow
chore/update-python-version
```

Avoid vague names such as `new`, `test2` or `final-final`.

## Keep branches focused and current

A branch should ideally represent one coherent task. Smaller branches are easier to review and less likely to conflict. Before merging, bring in the latest changes from the base branch using the team's chosen strategy and rerun relevant tests.

Do not rebase a branch that other people are actively using unless the team understands and agrees to the history rewrite.

## Merge basics

A merge combines histories. A fast-forward merge moves the branch pointer when the target branch has no divergent commits. A merge commit records a point where histories were joined. The choice depends on team policy and the need to preserve context.

## Exercise

Create a feature branch from your capstone's `main`, add a short design note, commit it and merge it back. Inspect `git log --oneline --graph --decorate --all` to visualise the history.

## Checkpoint

Explain why a focused branch is easier to review than one that mixes a new feature, a dependency upgrade and unrelated formatting changes.
