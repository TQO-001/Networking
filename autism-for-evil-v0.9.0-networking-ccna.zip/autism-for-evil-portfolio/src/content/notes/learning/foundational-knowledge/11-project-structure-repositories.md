---
title: "How to structure a project so other people can work in it"
description: "Choose a repository layout, separate source from tests and documentation, and understand monorepo versus multiple repositories."
order: 11
minutes: 25
level: "Beginner–Intermediate"
pathId: "foundational-knowledge"
module: "Design and architecture"
tags: ["project-structure", "repository", "monorepo", "src-layout"]
kind: "lesson"
---

## A project structure is a map

A repository should make it obvious where to find application code, tests, documentation, configuration and supporting data. Good structure reduces the time a new contributor spends guessing.

A small Python package may use:

```text
asset-register/
├── README.md
├── pyproject.toml
├── uv.lock
├── .gitignore
├── src/
│   └── asset_register/
│       ├── __init__.py
│       ├── models.py
│       ├── validation.py
│       └── importer.py
├── tests/
│   ├── test_validation.py
│   └── test_importer.py
├── docs/
└── sample-data/
```

A full-stack application may separate `frontend/` and `backend/` because they have different runtimes and dependency managers:

```text
asset-register/
├── README.md
├── docs/
├── frontend/
│   ├── package.json
│   └── src/
└── backend/
    ├── pyproject.toml
    ├── src/asset_register/
    └── tests/
```

This is a monorepo: multiple related application parts live in one repository. It can make coordinated changes easier, but repository permissions and build pipelines may become more complex.

## Monorepo versus multiple repositories

Use a **monorepo** when components are closely related, changes often need to land together and one team owns the system. Use **separate repositories** when projects have independent lifecycles, ownership, access controls or release schedules.

Neither choice is automatically more professional. Choose based on how the work is shared and released.

## Keep generated files out of source control

Usually commit source code, tests, lockfiles, documentation, safe sample data and configuration templates. Usually do not commit virtual environments, `node_modules`, caches, build outputs, local secrets, real credentials, production exports or personal editor state.

Lockfiles are generally useful to commit because they preserve resolved dependency versions. Generated output such as `dist/` is commonly rebuilt by the deployment pipeline rather than committed, unless the project's release method explicitly requires it.

## README as the front door

A contributor should find the project purpose, supported runtimes, setup instructions, commands for testing, configuration names, example usage, known limitations and contribution process without searching through source files.

## Exercise

Create a folder tree for a project you want to build. Mark every folder as source, tests, docs, safe sample data, configuration or generated output. Explain why you chose a monorepo or separate repositories.

## Checkpoint

Show a new developer where they would find: API route code, domain validation, tests, environment-variable examples, local secrets and the release instructions. Your structure should make each answer obvious.
