---
title: "ERDs: draw a database before creating it"
description: "Build and review an entity-relationship diagram using entities, attributes, keys and Crow’s Foot cardinality."
order: 16
minutes: 25
level: "Beginner"
pathId: "foundational-knowledge"
module: "Database design foundations"
tags: ["erd", "crow-foot", "database-design", "diagram"]
kind: "lesson"
---

## What an ERD communicates

An **entity-relationship diagram (ERD)** is a visual model of data. It helps developers, analysts, database engineers and stakeholders discuss the entities, attributes, keys and relationships before a schema is created.

An ERD is not a network topology diagram. A topology diagram shows communication paths and infrastructure; an ERD shows how data is structured and related. Both are useful, but they answer different questions.

## Crow’s Foot notation

Crow’s Foot notation uses marks at relationship ends to show minimum and maximum cardinality:

- Circle: zero (optional).
- Bar: one.
- Crow’s foot: many.

Common combinations are `0..1`, `1..1`, `0..many` and `1..many`. Tooling and visual conventions vary slightly, so add a legend if the audience may not know the notation.

## Worked example

Consider three entities:

**Device**: `device_id` (PK), `asset_tag` (unique), `hostname`, `role`, `location_id` (FK)

**Interface**: `interface_id` (PK), `device_id` (FK), `name`, `mac_address`, `vlan_id`

**Review**: `review_id` (PK), `device_id` (FK), `reviewed_at`, `review_status`, `notes`

Relationships:

- One Device can have zero or many Interfaces; each Interface belongs to exactly one Device.
- One Device can have zero or many Reviews; each Review concerns exactly one Device.

A compact text sketch:

```text
DEVICE 1 ───── 0..* INTERFACE
DEVICE 1 ───── 0..* REVIEW
LOCATION 1 ─── 0..* DEVICE
```

This sketch communicates cardinality but is not a complete ERD. A full diagram should show the attributes, primary keys and foreign keys inside each entity box and make optionality visible at both ends.

## A repeatable drawing workflow

1. List the entities from the data requirements.
2. Add attributes and identify candidate keys.
3. Choose primary keys and mark foreign keys.
4. Write each relationship in plain English.
5. Determine minimum and maximum participation on both ends.
6. Draw the connections using a consistent notation.
7. Check the diagram against sample scenarios.
8. Add a legend and a version/date.

## Validate the ERD with scenarios

Can a device have no interface yet? Can a review exist without a device? Can a device move to another location without erasing its review history? Does one device have multiple interfaces? The diagram should represent the agreed rules rather than the designer's assumptions.

## Exercise

Draw an ERD for Device, Interface, Location and Review. Mark primary keys, foreign keys, unique attributes, optional fields and Crow’s Foot relationships. Include at least three business rules below the diagram.

## Checkpoint

Show your ERD to someone and ask them to explain what records are allowed. If two readers interpret a relationship differently, clarify the model.
