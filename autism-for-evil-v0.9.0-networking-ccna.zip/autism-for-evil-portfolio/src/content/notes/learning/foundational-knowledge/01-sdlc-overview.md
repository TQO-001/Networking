---
title: "The SDLC: the complete life of a software system"
description: "Learn the stages of the software development life cycle and how iterative delivery differs from a one-time handoff."
order: 1
minutes: 20
level: "Beginner"
pathId: "foundational-knowledge"
module: "Software development lifecycle"
tags: ["sdlc", "planning", "delivery", "maintenance"]
kind: "lesson"
---

## What SDLC means

The **software development life cycle (SDLC)** is a way to organise the work involved in creating, releasing and maintaining software. It gives a team a shared view of the activities that happen before, during and after implementation.

A useful high-level model has seven stages:

| Stage | Main question | Typical output |
|---|---|---|
| Initiation | Why are we doing this? | Problem statement, business case |
| Requirements | What must it do? | Requirements, user stories, acceptance criteria |
| Analysis and design | How should it work? | Architecture, algorithms, ERD, interface design |
| Implementation | How will we build it? | Source code, configuration, migrations |
| Verification and validation | Does it work and solve the right problem? | Test results, review findings |
| Deployment/release | How do users receive it? | Release package, deployment record |
| Operations and maintenance | Does it remain useful and reliable? | Monitoring, support, fixes, improvements |

These stages apply beyond a web application. A network automation utility also needs a problem statement, target boundaries, design, tests, controlled rollout and maintenance. An OT change may have additional management-of-change, safety and approval requirements.

## Waterfall, iterative and agile approaches

**Waterfall** organises work into sequential phases. It can suit projects with stable requirements, formal gates and substantial documentation. Its risk is that major assumptions may only be tested late.

**Iterative development** builds a solution through repeated cycles. Each cycle improves understanding and produces feedback. It helps when requirements are uncertain or the solution is being discovered.

**Agile** is a family of approaches that emphasises delivering useful increments, collaborating with stakeholders and adapting plans. Scrum and Kanban are examples of ways teams organise work; neither means “no planning” or “no documentation”.

Teams often combine approaches. For example, an OT change may require formal approval gates while the software that supports it is developed iteratively in a lab.

## Verification versus validation

- **Verification:** did we build the system according to its specification? “Does the import reject malformed IP addresses?”
- **Validation:** did we build the right thing for the people who need it? “Can the engineer quickly find the approved device record they came to review?”

Both matter. A technically correct system can still solve the wrong problem.

## Worked example: OT asset register

A first release might only import a CSV, validate rows and display an asset table. A later release could add filters, database persistence and audit history. We would still plan each increment, test it and record the release. We would not need to build every imagined feature before showing a working result.

## Exercise

Choose one project idea. List one activity and one tangible output for each of the seven SDLC stages. Keep the outputs small and realistic.

## Checkpoint

Describe one situation where a sequential approval process is appropriate and one where iterative feedback is especially useful. Explain why a project may use both.
