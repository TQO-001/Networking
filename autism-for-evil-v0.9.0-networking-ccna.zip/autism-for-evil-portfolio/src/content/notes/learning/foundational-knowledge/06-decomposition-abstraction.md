---
title: "Break a large problem into smaller pieces"
description: "Use decomposition, abstraction, inputs, outputs and boundaries to make complex work manageable."
order: 6
minutes: 18
level: "Beginner"
pathId: "foundational-knowledge"
module: "Problem solving and algorithms"
tags: ["decomposition", "abstraction", "input-output"]
kind: "lesson"
---

## Why decomposition matters

A project feels overwhelming when it is treated as one giant task. **Decomposition** breaks it into smaller parts that can be understood, built and checked independently.

For the asset register, “build the application” can become:

1. Define the asset fields.
2. Read a CSV file.
3. Validate the required columns.
4. Validate each row.
5. identify duplicates.
6. Present a preview.
7. Save accepted records.
8. Search and filter the records.
9. Export a report.

Each item can be split further. “Validate each row” could mean checking required fields, IP syntax, VLAN range and duplicate identifier.

## Use input–process–output (IPO)

An IPO table helps define a component:

| Component | Input | Process | Output |
|---|---|---|---|
| IP validator | Text value | Parse and validate address | Valid address or error |
| Duplicate checker | List of asset IDs | Count repeated IDs | Duplicate report |
| CSV importer | File path/file content | Parse headers and rows | Candidate records and row errors |

IPO thinking is useful for functions, APIs, scripts, network services and database jobs.

## Abstraction: keep the right details

Abstraction means exposing the details needed for a task while hiding irrelevant complexity. A person using the importer needs to know which file to choose and which rows failed. They do not need to understand every internal parsing step.

Good abstraction is not hiding everything. It gives each part a clear responsibility and a clear contract.

## Define boundaries

A component boundary should answer:

- What does this component own?
- What data does it accept?
- What does it return?
- What errors can occur?
- What should it not do?

For example, a CSV parser should parse rows. It should not also write database records, send emails and change device configuration. Keeping responsibilities separate makes the code easier to test.

## Exercise

Take one feature from your project and split it into at least six smaller tasks. For each task, write its input, process, output and one possible failure.

## Checkpoint

Explain how decomposition helps testing. A component with a small responsibility and clear inputs/outputs can usually be tested without running the entire application.
