---
title: "Requirements: what the system must do and how well"
description: "Distinguish functional requirements, quality requirements, constraints and acceptance criteria."
order: 3
minutes: 22
level: "Beginner"
pathId: "foundational-knowledge"
module: "Discovery and requirements"
tags: ["requirements", "functional", "non-functional", "acceptance"]
kind: "lesson"
---

## A requirement is a statement of need

Requirements describe capabilities, qualities or boundaries that a solution must satisfy. Clear requirements reduce disagreement because the team can review and test them.

### Functional requirements

Functional requirements describe **what the system does**. Examples:

- The user can import a CSV file containing asset records.
- The system validates each IPv4 address before accepting a row.
- The user can search assets by hostname or asset identifier.
- The system reports duplicate asset identifiers.

### Non-functional requirements

Non-functional requirements describe **how well or under what qualities** the system operates. Examples include usability, performance, reliability, security, accessibility, maintainability and portability.

Weak: “The application should be fast.”

Better: “On the agreed sample dataset of 5,000 assets, the asset list should become usable within two seconds on the documented reference machine.”

The number is an example target, not a universal rule. A real team must agree on the dataset, machine and measurement method.

### Constraints

Constraints limit the solution. Examples: must run on Windows and Linux, must use the approved Python version, must not connect to production OT networks, or must comply with an organisation's change process.

A constraint is different from a preference. “We prefer PostgreSQL” is a preference until a decision makes it mandatory.

## Make requirements testable

Avoid vague words such as fast, simple, secure, intuitive and robust unless you define what they mean. Use a structure such as:

- Identifier: `FR-001`
- Statement: “The system shall reject a row whose IP address cannot be parsed.”
- Rationale: “Invalid addresses should not enter the asset register.”
- Priority: Must / Should / Could
- Verification: test a valid row and several invalid values.

For quality requirements, write down the measurement conditions. A requirement without a way to verify it is difficult to use during acceptance.

## Prioritisation

A small project rarely needs every feature immediately. MoSCoW is one prioritisation technique:

- **Must:** required for the first usable release.
- **Should:** important, but a workaround exists temporarily.
- **Could:** useful enhancement if time allows.
- **Won't (this time):** explicitly excluded from this release.

Prioritisation is not a promise that every “Should” or “Could” will be built later.

## Exercise

Write five functional requirements, three non-functional requirements and three constraints for the OT asset register. Give each a unique ID and a verification method.

## Checkpoint

Explain why “the system shall be secure” is not sufficient. Rewrite it as two concrete requirements, such as role-based access and secrets not being committed to Git.
