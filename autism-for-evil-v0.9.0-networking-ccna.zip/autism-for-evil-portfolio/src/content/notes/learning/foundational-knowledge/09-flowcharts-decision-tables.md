---
title: "Flowcharts and decision tables"
description: "Visualise control flow, branches and rule combinations before implementation."
order: 9
minutes: 22
level: "Beginner"
pathId: "foundational-knowledge"
module: "Problem solving and algorithms"
tags: ["flowcharts", "decision-tables", "diagrams"]
kind: "lesson"
---

## When a diagram helps

A flowchart represents a process as connected steps and decisions. It is useful when a workflow has several branches, approvals, retry paths or failure outcomes. A decision table is useful when multiple conditions combine to determine an outcome.

Do not create a diagram just to decorate a document. Use one when it helps people notice missing steps or disagree about behaviour before code is written.

## Common flowchart symbols

| Symbol | Meaning | Typical use |
|---|---|---|
| Oval/rounded terminator | Start or end | Entry and exit |
| Rectangle | Process | Validate a row |
| Diamond | Decision | Is the IP valid? |
| Parallelogram | Input/output | Read file, display report |
| Arrow | Direction | Connect the steps |

Keep the flow moving in a consistent direction, label decision branches (`Yes` / `No`) and avoid crossing connectors where possible.

## Worked flow: one imported row

```text
[Start]
   |
[Read row]
   |
<Required fields present?> -- No --> [Record missing-field error] --+
   | Yes                                                        |
[IP address valid?] -- No --> [Record IP error] -----------------+
   | Yes                                                        |
[Asset ID unique?] -- No --> [Flag duplicate] ------------------+
   | Yes                                                        |
[Accept row] ---------------------------------------------------+
   |
[Next row or finish]
```

This simplified diagram still leaves a design question: after recording an error, should the process continue validating the other fields in that row or stop at the first error? Either can be reasonable. Write down the chosen behaviour.

## Decision tables

Suppose a row can be accepted only when required fields are present, the IP is valid and the asset ID is unique.

| Rule | Required fields? | Valid IP? | Unique ID? | Outcome |
|---|---|---|---|---|
| R1 | Yes | Yes | Yes | Accept |
| R2 | No | — | — | Reject: missing fields |
| R3 | Yes | No | — | Reject: invalid IP |
| R4 | Yes | Yes | No | Flag/reject: duplicate |

The dash means the condition does not need to be checked for that rule. A decision table makes rule coverage easier to review.

## Keep diagrams in sync

If the implementation changes, update the diagram and requirements. A diagram that contradicts the code is worse than no diagram because it misleads future maintainers.

## Exercise

Draw a flowchart for a login attempt, but do not design a real authentication system from scratch. Use a fictional local application and include empty input, valid credentials, invalid credentials and a temporary service error. Then create a small decision table.

## Checkpoint

Explain when a flowchart is more useful than a numbered list and when a decision table makes a collection of rules easier to test.
