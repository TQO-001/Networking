---
title: "Find the real problem before choosing a technology"
description: "Identify stakeholders, current pain points, desired outcomes and evidence before proposing a technical solution."
order: 2
minutes: 18
level: "Beginner"
pathId: "foundational-knowledge"
module: "Discovery and requirements"
tags: ["problem-statement", "stakeholders", "discovery"]
kind: "lesson"
---

## Why discovery comes before design

A request often arrives as a proposed solution: “We need a dashboard”, “We need a database” or “Can you automate this?” Those requests may be valid, but they do not yet explain the underlying problem.

Discovery asks what is happening today, who is affected, what decisions they need to make and what evidence would show an improvement. This prevents a team from spending time building a polished answer to the wrong question.

## Identify stakeholders

A **stakeholder** is a person or group affected by the system or able to influence it. For the OT asset register, stakeholders might include:

- Network engineers who maintain device records.
- OT engineers who need accurate asset context.
- A supervisor who approves changes to the register.
- Security staff who care about access and sensitive information.
- Developers who implement and support the application.

A stakeholder is not automatically a user. A manager may approve a project but never open the application.

## Ask neutral questions

Useful discovery questions include:

- What task are you trying to complete?
- How do you do it today?
- Where does the current process become slow or unreliable?
- What information must be available to make a decision?
- What must never happen?
- How often does this task occur, and who performs it?
- How will we know the new process is better?

Avoid leading questions such as “Wouldn't a React dashboard solve this?” They bias the answer toward a technology before the problem is understood.

## Write a problem statement

A practical format is:

> **[User/group]** needs a way to **[complete a task]** because **[current difficulty/evidence]**. The desired outcome is **[measurable improvement]**, while respecting **[important constraint]**.

Example:

> OT and network engineers need a consistent way to review approved lab asset records because device details are currently stored in separate spreadsheets. The desired outcome is one searchable, validated register, while ensuring production infrastructure details are not imported into the learning environment.

This statement describes the need and constraint. It does not prescribe a framework or database.

## Separate facts from assumptions

Create two lists. **Known facts** are supported by evidence or confirmed by a stakeholder. **Assumptions** are beliefs that still need checking. An assumption is not necessarily wrong; it is simply not verified yet.

For example, “engineers use the register every day” is an assumption until someone confirms frequency. Marking assumptions prevents them from silently becoming requirements.

## Exercise

Write a problem statement for a system you care about. Then list three stakeholders, five discovery questions, three known facts and three assumptions.

## Checkpoint

Can you explain the problem without mentioning a specific programming language, database, UI library or vendor product? If not, rewrite it until the need is clear independently of the proposed solution.
