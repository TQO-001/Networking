---
title: "Undo safely: restore, revert, reset, stash and conflicts"
description: "Choose the right recovery command and understand which operations rewrite history or discard work."
order: 25
minutes: 28
level: "Intermediate"
pathId: "foundational-knowledge"
module: "Git and collaboration"
tags: ["git-restore", "git-revert", "git-reset", "stash", "merge-conflict"]
kind: "lesson"
---

## First: inspect before changing anything

When something looks wrong, stop and inspect:

```bash
git status
git diff
git diff --cached
git log --oneline --decorate -8
```

If work may be important, create a backup copy or a temporary branch before attempting recovery. Avoid running a command you do not understand just because a forum post says it “cleans everything”.

## Restore an unstaged file

`git restore path/to/file` replaces an unstaged working-tree file with the version from the index. This discards the unstaged changes to that file. Inspect and save anything you need first.

To unstage a file while keeping its working-tree edits:

```bash
git restore --staged path/to/file
```

## Revert a committed change

`git revert <commit>` creates a new commit that applies the inverse of an earlier commit. This is often the safer option for a commit already shared with other people because it preserves published history.

## Reset and history rewriting

`git reset` moves the current branch reference and can change the index and working tree depending on the option. `--soft`, `--mixed` and `--hard` have very different effects. `--hard` can discard tracked working-tree changes. Rewriting commits that others have based work on can disrupt collaboration.

Do not use `git reset --hard` as a general clean-up command. Understand the state you are changing, ensure work is backed up and follow team policy. Avoid force-pushing shared branches; if a force update is genuinely required, coordinate it and prefer `--force-with-lease` under an agreed workflow.

## Stash

`git stash` temporarily stores tracked working-tree changes so you can switch tasks. Stashes are not a long-term backup or a replacement for commits. Name stashes when possible and inspect the result before applying or dropping them.

## Merge conflicts

A conflict means Git cannot automatically combine competing edits. Open each conflicted file, understand both changes, edit the final intended result, run tests and mark the file resolved with `git add`. Then complete the merge or rebase according to the current operation.

Do not simply delete conflict markers and choose one side without understanding what each side changed.

## Exercise

On a disposable practice repository, create an uncommitted change and practise unstaging it while keeping the edit. Then make and revert a test commit. Finally create a simple merge conflict on two branches and resolve it.

## Checkpoint

Choose between restore, revert and reset for three scenarios: an unstaged typo, a bad commit already pushed to a shared branch, and a local commit that has not been shared. Explain your reasoning.
