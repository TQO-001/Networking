---
title: "Database design: from questions to a defensible schema"
description: "Follow a repeatable design workflow from data requirements through conceptual, logical and physical models."
order: 13
minutes: 22
level: "Beginner–Intermediate"
pathId: "foundational-knowledge"
module: "Database design foundations"
tags: ["database-design", "schema", "requirements"]
kind: "lesson"
---

## Design the data around questions

Start with the questions the system must answer. “Which devices are assigned to VLAN 20?” “Which assets have not been reviewed this quarter?” “What interfaces belong to this switch?” The required questions shape the data model.

A practical design sequence is:

1. Gather data requirements and business rules.
2. Identify entities and their attributes.
3. Identify candidate identifiers and relationships.
4. Draw a conceptual ERD.
5. Refine the model into a logical relational design.
6. Apply keys, data types, constraints and normalisation.
7. Consider indexes, workload and operational requirements.
8. Review with stakeholders and test with sample data.

This is iterative. The model may change when a business rule becomes clearer.

## Conceptual, logical and physical models

A **conceptual model** describes the important entities and relationships in business language. It avoids implementation details.

A **logical model** adds attributes, identifiers, relationship rules and normalisation, usually without committing to a specific database engine.

A **physical model** specifies how the design is implemented in a particular database: table names, PostgreSQL data types, indexes, constraints, partitions and storage choices.

Keeping these levels distinct helps teams discuss meaning before arguing about column types.

## Data dictionary

A data dictionary records what each field means and how it is used. Example:

| Field | Meaning | Example | Rule |
|---|---|---|---|
| `asset_id` | Stable register identifier | `LAB-PLC-001` | Required, unique |
| `hostname` | Recorded device hostname | `plc-lab-01` | Required in this release |
| `management_ip` | Documented management address | `192.0.2.10` | Must parse as an IP address |
| `vlan_id` | Assigned VLAN identifier | `20` | Must be within agreed range |

Document units, allowed values, nullability and source of truth. A field called `speed` is ambiguous unless its unit is known.

## Review the design with sample records

Insert a few fictional examples on paper and ask whether the model can represent them without awkward duplication. Try a device with two interfaces, an unassigned location, a renamed hostname and an asset with multiple review events.

If the design cannot represent a real requirement, revise it before writing migrations.

## Exercise

Create a data dictionary for at least eight fields across your proposed entities. Include data type concept, required/optional status, allowed values, meaning and source.

## Checkpoint

Describe one decision that belongs in the logical model and one that belongs in the physical PostgreSQL model.
