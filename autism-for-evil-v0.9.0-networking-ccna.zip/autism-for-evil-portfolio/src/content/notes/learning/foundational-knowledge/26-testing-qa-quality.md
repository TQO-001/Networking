---
title: "Testing and quality assurance across the lifecycle"
description: "Understand test levels, test cases, edge cases, regression testing and the role of quality assurance."
order: 26
minutes: 23
level: "Beginner–Intermediate"
pathId: "foundational-knowledge"
module: "Quality, documentation and delivery"
tags: ["testing", "qa", "test-plan", "regression"]
kind: "lesson"
---

## Testing is part of design, not the final ceremony

Testing checks whether a system behaves as expected. Quality assurance is broader: it includes practices that reduce defects, improve process and make outcomes dependable. Testing is one way to gather evidence about quality; it cannot prove every possible behaviour is correct.

## Common test levels

- **Unit tests:** check a small function or component in isolation.
- **Integration tests:** check that components work together, such as an API route and service.
- **System tests:** check the complete application against requirements.
- **Acceptance tests:** confirm the system meets agreed user or business needs.
- **Regression tests:** rerun checks after changes to make sure previously working behaviour has not broken.

Manual exploratory testing is also valuable, especially for usability and unexpected workflows. Automated tests are best for repeatable checks.

## Design test cases from requirements

Each test case should identify its purpose, setup, input, action, expected result and actual result. Include normal, boundary, invalid and failure cases.

Example requirement: asset IDs must be unique.

| Case | Input | Expected result |
|---|---|---|
| New ID | `LAB-001` not yet stored | Accepted |
| Duplicate ID | Existing `LAB-001` | Rejected or flagged according to rule |
| Empty ID | Empty string | Validation error |
| Whitespace | ` LAB-001 ` | Normalisation policy applied consistently |

The last case forces a design decision: does trimming whitespace make the ID equivalent? Write the rule down and test it.

## Test environments and test data

Use safe, representative data. For networking and OT projects, use fictional addresses, simulated devices, exported sample captures and isolated lab services. Do not use production traffic or real device configurations as casual test fixtures.

A test environment should be documented so another person can reproduce the result. Record versions, configuration and any assumptions that affect the outcome.

## Exercise

Write a ten-case test plan for your capstone. Include at least two invalid cases, one boundary case, one failure case and one acceptance scenario. Link each test to a requirement ID.

## Checkpoint

Explain why passing unit tests alone does not prove that the complete application meets user needs.
