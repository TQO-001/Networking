---
title: "Create a repository and keep it clean"
description: "Initialise a repository, choose a practical folder structure and configure .gitignore before the first commit."
order: 20
minutes: 24
level: "Beginner"
pathId: "foundational-knowledge"
module: "Git and collaboration"
tags: ["git-init", "gitignore", "repository-structure", "readme"]
kind: "lesson"
---

## Start with the project folder

Create a named project directory, then initialise Git inside that directory:

```bash
mkdir asset-register
cd asset-register
git init
git status
```

`git init` creates the local repository metadata. `git status` tells you which files are untracked, modified or staged.

## Create the front-door files first

A sensible starter structure might be:

```text
asset-register/
├── README.md
├── .gitignore
├── docs/
├── backend/
│   ├── pyproject.toml
│   ├── src/
│   └── tests/
└── frontend/
    ├── package.json
    └── src/
```

You do not need every folder on day one. Create folders when there is a real file to put in them and keep the structure understandable.

## What belongs in .gitignore?

`.gitignore` tells Git which untracked files or paths to ignore. For a Python + React project, typical entries include:

```gitignore
# Python
.venv/
__pycache__/
*.py[cod]
.pytest_cache/
.ruff_cache/

# Node
node_modules/
dist/

# Local environment and secrets
.env
.env.*
!.env.example

# Editor / operating system
.vscode/
.idea/
.DS_Store
Thumbs.db
```

Adjust this to the project. Do not ignore files the team needs to build and test consistently. Python lockfiles and JavaScript lockfiles are commonly committed for reproducibility.

Important: `.gitignore` does not remove a file that is already tracked. If a secret was committed, adding `.env` later does not erase it from history. Treat the secret as exposed, rotate it and follow the repository's incident process.

## Safe and unsafe data

Commit fictional sample data and sanitised examples. Do not commit credentials, private keys, production device configurations, real IP inventories, personal information or raw workplace exports. For network and OT projects, ensure sample commands, diagrams and outputs are approved for public sharing.

## First commit

```bash
git status
git add README.md .gitignore
git diff --cached
git commit -m "chore: initialise asset register project"
```

Review the staged changes before committing. This is how you catch accidental secrets or unwanted build files.

## Exercise

Create a new local repository for your capstone. Add a README, `.gitignore`, `docs/` and an empty test folder. Run `git status` and inspect the staged diff before your first commit.

## Checkpoint

Explain why `.env.example` can be committed while `.env` usually should not be. What should you do if a real secret has already been pushed?
