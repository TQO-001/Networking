---
title: "Pseudocode: plan logic in plain language"
description: "Write readable pseudocode using sequence, IF/ELSE, loops, validation and named procedures."
order: 8
minutes: 24
level: "Beginner"
pathId: "foundational-knowledge"
module: "Problem solving and algorithms"
tags: ["pseudocode", "planning", "logic"]
kind: "lesson"
---

## What pseudocode is

Pseudocode is a structured way to describe program logic without committing to the syntax of a particular language. It is not one official programming language, so teams may use slightly different conventions. The important qualities are clarity, consistency and enough detail that the logic can be implemented and reviewed.

Pseudocode helps you focus on the steps and decisions before worrying about Python indentation, JavaScript syntax or framework details.

## A simple house style

Use these conventions throughout this course:

```text
START
    INPUT value
    IF value is valid THEN
        DISPLAY "Accepted"
    ELSE
        DISPLAY "Please correct the value"
    END IF
END
```

For repeated work:

```text
FOR EACH row IN rows
    VALIDATE row
    IF row is valid THEN
        ADD row TO accepted_rows
    ELSE
        ADD error TO rejected_rows
    END IF
END FOR
```

For a loop that continues until a condition changes:

```text
WHILE there are unprocessed records
    PROCESS next record
END WHILE
```

Use meaningful names. `valid_ip_address` tells the reader more than `x`. Indent nested blocks consistently. End each block explicitly (`END IF`, `END FOR`) so the structure is visible.

## Procedures and functions

When a process has a clear subtask, name it:

```text
PROCEDURE validate_asset(row)
    CHECK required fields
    CHECK IP address format
    CHECK VLAN value
    RETURN validation result
END PROCEDURE
```

This lets you describe a larger algorithm without repeating every low-level detail. The procedure should have one clear responsibility and a known return result.

## Worked design: search assets

```text
FUNCTION search_assets(assets, search_text)
    SET matches TO empty list
    NORMALISE search_text

    FOR EACH asset IN assets
        IF search_text appears in asset.hostname
           OR search_text appears in asset.asset_id THEN
            ADD asset TO matches
        END IF
    END FOR

    RETURN matches
END FUNCTION
```

Before implementation, ask what “appears in” means. Is the search case-insensitive? Does it match partial text? What if search text is empty? Good pseudocode makes these decisions visible.

## Translate only after the logic is understood

A helpful workflow is:

1. Write the pseudocode.
2. Walk through sample inputs by hand.
3. Add missing edge cases.
4. Ask another person to review it.
5. Translate each block into code.
6. Write tests that match the expected behaviour.

Do not write Python syntax inside every pseudocode line. If you already use `for row in rows:` and `None`, you may be writing Python rather than pseudocode. Both are useful, but they serve different purposes.

## Exercise

Write pseudocode for CSV import validation. It must return accepted rows, rejected rows and a summary count. Include what happens if the file has no rows or the required header is missing.

## Checkpoint

Give your pseudocode to someone who has not seen your code. Can they describe the expected behaviour? That is a good sign your logic is clear.
