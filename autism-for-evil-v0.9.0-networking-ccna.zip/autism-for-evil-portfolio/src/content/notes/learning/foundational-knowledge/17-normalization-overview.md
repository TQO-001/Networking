---
title: "Normalisation: reduce duplication without losing meaning"
description: "Understand update anomalies, first through third normal form and when denormalisation should be a deliberate choice."
order: 17
minutes: 24
level: "Beginner–Intermediate"
pathId: "foundational-knowledge"
module: "Database design foundations"
tags: ["normalization", "1nf", "2nf", "3nf"]
kind: "lesson"
---

## Why normalisation exists

A poorly designed table may repeat the same fact in many rows. Repetition creates anomalies:

- **Update anomaly:** a device's location is changed in some rows but not others.
- **Insert anomaly:** a location cannot be recorded until a device is added.
- **Delete anomaly:** deleting the last device record accidentally removes the only copy of a location fact.

Normalisation organises data around dependencies so each fact has an appropriate authoritative place.

## First Normal Form (1NF)

A practical 1NF starting point is to represent each field as one value for the chosen domain and avoid repeating groups or lists stored inside a cell. If a device has four interfaces, model interface records rather than storing `"Gi0/1, Gi0/2, Gi0/3, Gi0/4"` in one text field when each interface needs its own attributes.

“Atomic” depends on the operations the system needs. A full name could be one value for a display-only system, but first and last names may need separate fields if the application searches or sorts them independently.

## Second Normal Form (2NF)

2NF builds on 1NF and addresses partial dependencies on part of a composite candidate key. If a junction table uses `(device_id, segment_id)` as its key, an attribute that depends only on `device_id` belongs with Device rather than being repeated for every segment association.

## Third Normal Form (3NF)

3NF addresses transitive dependencies where a non-key attribute depends on another non-key attribute rather than directly on a key. If `device_id` determines `location_id` and `location_id` determines `location_name`, storing location name in every device row can create duplicated facts. A separate Location entity may be appropriate.

Formal definitions use functional dependencies; this course introduces the practical reasoning. More advanced database design should be studied alongside the database course.

## Denormalisation is a trade-off

A reporting table or materialized view may be useful for measured read performance. Denormalisation introduces duplicated or precomputed information, so teams must define how it stays consistent and measure the benefit. It is not a shortcut around understanding relationships.

## Exercise

Create a deliberately messy table with device name, location name, interface and review date repeated across rows. Identify one update, insert and delete anomaly. Propose entities that reduce the duplication.

## Checkpoint

Explain why normalisation is about data integrity and clarity, not simply having the largest possible number of tables.
