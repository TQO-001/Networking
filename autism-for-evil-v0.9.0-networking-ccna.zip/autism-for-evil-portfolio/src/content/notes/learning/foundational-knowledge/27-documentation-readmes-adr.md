---
title: "Documentation that helps the next person"
description: "Write useful READMEs, setup guides, architecture decisions and change records."
order: 27
minutes: 22
level: "Beginner"
pathId: "foundational-knowledge"
module: "Quality, documentation and delivery"
tags: ["documentation", "readme", "adr", "maintenance"]
kind: "lesson"
---

## Documentation is part of the deliverable

A project is not easy to maintain if only its author knows how to run it. Documentation should help a reader understand the purpose, install it, configure it, test it, use it and recognise its limitations.

## A practical README outline

```markdown
# Asset Register

## Purpose
What problem does this project solve?

## Features
What is implemented today?

## Requirements
Supported Python/Node versions and dependencies.

## Setup
Exact commands for Windows and Linux.

## Configuration
Variable names, safe example values and where secrets belong.

## Run
How to start the backend and frontend.

## Test
Commands and expected outcomes.

## Project structure
Where source, tests and docs live.

## Limitations and safety
What it does not do; approved operating boundaries.

## Contributing
Branch, commit and pull-request workflow.
```

Be honest about status. If a feature is planned, label it planned. If a build has not been tested, say so.

## Architecture Decision Records (ADRs)

An ADR records an important technical decision and why it was made. A lightweight format:

- Title and status (proposed, accepted, superseded).
- Context: what problem or constraint prompted the decision?
- Decision: what did the team choose?
- Consequences: what becomes easier or harder?
- Alternatives considered.

Example: “Use a single repository for React and FastAPI because the components are developed and released together.” Consequence: the pipeline must understand both frontend and backend dependencies.

ADRs should record meaningful decisions, not every small coding preference.

## Keep docs near the work

Use the README for entry-point information, `docs/` for longer guides and diagrams, and inline comments for non-obvious reasoning near the code. Avoid comments that merely repeat the code.

## Exercise

Write a README for your capstone and one ADR explaining your repository layout decision. Ask someone else to follow the setup guide without your help; note every point where they get stuck.

## Checkpoint

Can a new contributor install and test the project from a clean checkout using only the README? If not, identify the missing steps.
