---
title: "Number systems and data representation: binary, decimal and hexadecimal"
description: "Understand bits, bytes, binary and hexadecimal notation, numeric ranges and the ways computers represent addresses and data."
order: 31
minutes: 32
level: "Beginner"
pathId: "foundational-knowledge"
module: "Mathematics for computing"
tags: ["binary", "hexadecimal", "number-systems", "bits", "bytes", "ip-addressing"]
kind: "lesson"
---

## Why number systems matter

People usually count in decimal (base 10). Computers store information as patterns of bits, which are commonly discussed in binary (base 2). Hexadecimal (base 16) is a shorter way to write binary values and appears frequently in memory addresses, colour values, protocol fields and network identifiers.

You do not need to memorise every conversion shortcut. Learn how place value works and practise checking your result.

## Bits and bytes

A **bit** is one binary digit: `0` or `1`. A **byte** is eight bits. A byte can represent 256 distinct patterns, from `00000000` through `11111111`.

For an unsigned value, the range of `n` bits is:

\[
0 \text{ through } 2^n - 1
\]

So an unsigned 8-bit value ranges from 0 to 255. This is why each IPv4 octet has a decimal range of 0–255.

## Binary place value

Each binary position is a power of two. From right to left, the first eight place values are:

| Position | 7 | 6 | 5 | 4 | 3 | 2 | 1 | 0 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Value | 128 | 64 | 32 | 16 | 8 | 4 | 2 | 1 |

For example, `00001010` equals 8 + 2 = 10 in decimal.

To convert a small decimal number to binary, find which place values add up to it. For 13, use 8 + 4 + 1, giving `00001101`.

## Hexadecimal

Hexadecimal uses sixteen symbols: `0`–`9` and `A`–`F`. The letters represent decimal values 10–15.

One hexadecimal digit represents four bits (a nibble):

| Binary | Hex | Decimal |
|---|---|---:|
| `0000` | `0` | 0 |
| `1001` | `9` | 9 |
| `1010` | `A` | 10 |
| `1111` | `F` | 15 |

Two hexadecimal digits represent one byte. For example, `0x2A` is 2 × 16 + 10 = 42 in decimal.

## Connection to networking

An IPv4 address contains 32 bits divided into four 8-bit octets. Each octet is normally displayed in decimal, which is easier for people to read. Subnet masks also use 32 bits; a `/24` prefix means the first 24 bits identify the network portion.

Hexadecimal is common in MAC addresses, IPv6 addresses and packet fields. You do not need to convert every value by hand, but understanding the notation makes protocol output less mysterious.

## Other data representation concepts

- **Unsigned integers** represent zero and positive values only.
- **Signed integers** reserve a representation for negative values. Two's complement is a common binary representation.
- **Text** is encoded as numeric values. UTF-8 is a widely used variable-width text encoding.
- **Floating-point numbers** approximate many real values; not every decimal fraction can be represented exactly in binary.
- **Endianness** describes the byte order used to represent multi-byte values in memory or protocol formats.

Treat these as separate ideas. A number's mathematical value, its binary representation and the byte order used to store it are related but not identical questions.

## Use Python to verify conversions

```python
number = 42

print(bin(number))  # 0b101010
print(hex(number))  # 0x2a
print(int("101010", 2))  # 42
print(int("2a", 16))     # 42
```

Python is useful as a verification tool, but make sure you can explain the place-value calculation for a small example yourself.

## Exercises

1. Convert decimal 13 into an 8-bit binary representation.
2. Convert binary `00101100` into decimal.
3. Convert hexadecimal `3F` into decimal.
4. Explain why an IPv4 octet cannot be greater than 255.
5. How many distinct bit patterns can 12 bits represent? Use the formula rather than listing them.
6. Explain the difference between a bit and a byte.

## Checkpoint

Without using a converter, explain how `0x2A`, `00101010` and decimal 42 represent the same numeric value.
