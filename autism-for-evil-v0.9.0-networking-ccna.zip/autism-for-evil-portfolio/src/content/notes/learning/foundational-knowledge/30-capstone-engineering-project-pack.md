---
title: "Capstone: plan a system like an engineering team"
description: "Combine discovery, requirements, pseudocode, flowcharts, ERDs, Git workflow, tests and documentation into one project pack."
order: 33
minutes: 35
level: "Beginner–Intermediate"
pathId: "foundational-knowledge"
module: "Capstone"
tags: ["capstone", "project-pack", "sdlc", "git", "erd"]
kind: "project"
---

## Your task

Prepare an engineering project pack for a fictional **OT asset register**. You do not need to build the complete application in this course. The objective is to demonstrate that you can plan and document a buildable, testable project before implementation.

The system is for a training lab and uses fictional sample data. It records devices, interfaces, locations and reviews. The first release supports import, validation, search and export. It does not scan production networks or configure industrial equipment.

## Deliverables

Create a repository with this structure:

```text
ot-asset-register/
├── README.md
├── .gitignore
├── docs/
│   ├── 01-problem-statement.md
│   ├── 02-requirements.md
│   ├── 03-use-cases.md
│   ├── 04-pseudocode.md
│   ├── 05-flowchart.md
│   ├── 06-data-dictionary.md
│   ├── 07-erd.md
│   ├── 08-test-plan.md
│   └── decisions/
│       └── ADR-001-repository-layout.md
├── backend/
├── frontend/
└── sample-data/
```

The frontend and backend folders can remain as planned placeholders at this stage. Do not commit a virtual environment, `node_modules`, local secrets or real workplace data.

## Required project artefacts

### 1. Problem and scope

Write a stakeholder list, a problem statement, goals, in-scope items, out-of-scope items, assumptions, constraints and at least three risks with mitigations.

### 2. Requirements

Write at least eight functional requirements and four non-functional requirements. Give each an ID, priority and verification method. Include acceptance criteria for import, duplicate detection and search.

### 3. Algorithm and pseudocode

Describe the CSV import flow from file selection to preview and accepted/rejected result. Include missing headers, malformed rows, duplicates and an empty file.

### 4. Flowchart

Draw the import decision flow. Make every branch lead somewhere. Label Yes/No paths and show the end state for invalid files.

### 5. Database design

Create a data dictionary and ERD for Device, Interface, Location and Review. Mark keys, optionality and cardinality. List three integrity constraints and explain any historical data requirement.

### 6. Test plan

Create at least twelve cases: normal inputs, invalid input, boundary values, duplicate IDs, missing fields, empty import, search no-results and failure handling. Link each case to a requirement.

### 7. Git history

Use Git from the first day. Create a coherent sequence of commits, for example:

```text
chore: initialise OT asset register project
 docs: define first-release scope and requirements
 docs(design): add import pseudocode and flowchart
 docs(database): model device and interface relationships
 test(plan): document import and validation cases
```

Create a feature branch for one document, open a pull request if using GitHub, review the diff and merge it. Do not invent commits after the fact; make the work and history together.

## Definition of done

- [ ] The problem can be explained without naming a technology.
- [ ] Scope and exclusions are explicit.
- [ ] Requirements are testable and prioritised.
- [ ] Pseudocode covers failure and boundary cases.
- [ ] Flowchart matches pseudocode.
- [ ] ERD matches the data dictionary and business rules.
- [ ] Test plan traces back to requirements.
- [ ] Repository has a useful README and `.gitignore`.
- [ ] Git commits are small, meaningful and reviewed.
- [ ] No secrets or workplace-sensitive material are included.

## Final reflection

Write a short retrospective: what changed after reviewing the design, which assumption was hardest to verify, which requirement was ambiguous and what you would build first in the next course.

When you are ready, continue to Python for Developers or Python for Network Engineers. The database course expands the ERD and schema concepts into SQL, PostgreSQL and data persistence.
