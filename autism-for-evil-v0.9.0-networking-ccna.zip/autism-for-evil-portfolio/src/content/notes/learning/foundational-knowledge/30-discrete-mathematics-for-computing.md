---
title: "Discrete mathematics for computing: logic, sets and relationships"
description: "Build the mathematical vocabulary behind conditions, data relationships, algorithms and network policies without assuming a mathematics background."
order: 30
minutes: 30
level: "Beginner"
pathId: "foundational-knowledge"
module: "Mathematics for computing"
tags: ["mathematics", "discrete-mathematics", "logic", "sets", "functions", "boolean-algebra"]
kind: "lesson"
---

## Why engineers use discrete mathematics

Discrete mathematics studies distinct values and structures rather than continuously changing quantities. It appears in everyday software and networking work: a validation rule, a permission check, a SQL filter, a VLAN membership rule and a data relationship all rely on precise logic.

You do not need advanced mathematics to begin. The goal is to become comfortable expressing a condition, understanding a relationship and checking whether a conclusion follows from its inputs.

## Propositions and Boolean values

A **proposition** is a statement that can be true or false. In programming, this is represented by a Boolean value: `True` or `False`.

The basic logical operators are:

| Operator | Meaning | Example | Result |
|---|---|---|---|
| NOT | Reverses a truth value | NOT True | False |
| AND | True only when both inputs are true | True AND False | False |
| OR | True when at least one input is true | True OR False | True |
| XOR | True when inputs differ | True XOR False | True |

A truth table lists every input combination and its result. For two Boolean inputs, there are four combinations:

| A | B | A AND B | A OR B |
|---|---|---|---|
| False | False | False | False |
| False | True | False | True |
| True | False | False | True |
| True | True | True | True |

### Translate a requirement into logic

Imagine a fictional asset register that should accept an import only when the file exists **and** the user has permission. The rule is:

`file_exists AND user_is_authorised`

Both conditions must be true. This is more precise than saying “check the file and permission” because it defines the exact decision.

In Python, the expression would be:

```python
if file_exists and user_is_authorised:
    accept_import()
else:
    reject_import()
```

The important learning point is the logical rule, not the Python syntax. You should be able to explain the rule before writing it in any language.

## Sets and membership

A **set** is a collection of distinct elements. For example:

- `A = {10, 20, 30}` could represent VLAN IDs in one lab area.
- `B = {20, 30, 40}` could represent VLAN IDs assigned to another group.

Common set operations:

- **Union** (`A ∪ B`): elements in A or B or both.
- **Intersection** (`A ∩ B`): elements shared by A and B.
- **Difference** (`A − B`): elements in A that are not in B.
- **Subset**: every element of one set is also present in another.

These are useful when comparing permissions, supported protocols, asset categories, package dependencies or groups of network segments.

Python has a built-in `set` type:

```python
planned_vlans = {10, 20, 30}
observed_vlans = {20, 30, 40}

shared = planned_vlans & observed_vlans
missing = planned_vlans - observed_vlans
unexpected = observed_vlans - planned_vlans

print(shared)      # {20, 30}
print(missing)     # {10}
print(unexpected)  # {40}
```

## Relations and functions

A **relation** describes how members of one set are associated with members of another. A device may be related to several interfaces; a user may be related to several roles.

A **function** is a special kind of relation: each valid input maps to exactly one output. For example, a function that converts a Celsius temperature to Fahrenheit must return one result for each numeric input.

When designing a database, ask whether the relationship is one-to-one, one-to-many or many-to-many. These are not merely diagram decorations; they describe real rules in the domain.

## Where this appears in engineering

- Python conditions and validation rules use Boolean logic.
- SQL `WHERE` clauses combine conditions with `AND`, `OR` and `NOT`.
- Network access policies combine source, destination, protocol and port conditions.
- Database relationships model associations between people, devices, interfaces and locations.
- Tests check that a rule behaves correctly for every important input combination.

## Exercises

1. Write a truth table for `A AND NOT B`.
2. A user may export a report only if they are authorised and the report is ready. Write the rule using Boolean operators and list all inputs that should produce a rejection.
3. Given `planned = {10, 20, 30, 40}` and `observed = {10, 30, 50}`, calculate the shared, missing and unexpected values.
4. Explain why a device with many interfaces is usually a one-to-many relationship rather than a many-to-many relationship.
5. Write one real-world rule from a project idea and express it in plain language before translating it into pseudocode.

## Checkpoint

Explain the difference between a set, a relation and a function. Give one software or networking example of each.
