---
title: "Relationships, cardinality and optionality"
description: "Read one-to-one, one-to-many and many-to-many relationships and translate business rules into modelling decisions."
order: 15
minutes: 22
level: "Beginner–Intermediate"
pathId: "foundational-knowledge"
module: "Database design foundations"
tags: ["relationships", "cardinality", "optionality"]
kind: "lesson"
---

## Relationships are business rules

A relationship describes how instances of entities connect. Cardinality answers how many instances may be associated; optionality answers whether the association is required.

Examples:

- One Location may contain zero or many Devices.
- Each Device may be assigned to zero or one current Location.
- One Device may have one or many Interfaces, depending on the business rule.
- One User may create many Reviews; each Review is created by one User.

Always phrase the relationship in both directions. “A device has interfaces” is incomplete until you decide whether a device can exist with zero interfaces and whether an interface can exist without a device.

## One-to-one

A one-to-one relationship means each instance on either side is associated with at most one instance on the other. These are less common than they first appear. Sometimes the attributes belong in one entity; sometimes separating them is justified by optionality, security or lifecycle.

## One-to-many

A one-to-many relationship connects one parent to many children. A typical relational implementation places the parent's primary key as a foreign key in the child table. For example, `interfaces.device_id` points to `devices.device_id`.

## Many-to-many

A many-to-many relationship normally needs an associative (junction) entity in a relational model. Suppose devices can participate in many network segments and a segment can contain many devices. A junction table such as `device_segment` stores the pair of foreign keys and any attributes of the assignment, such as start date or role.

## Avoid assumptions hidden in diagrams

A device might have a management IP, multiple interface IPs or no configured IP in a lab record. Do not collapse those possibilities into one column until the requirements are clear. A user may be responsible for many assets and an asset may have several reviewers over time; that is not necessarily a single `owner` field.

## Exercise

Write five relationship rules in plain English for the asset register. For each, state minimum and maximum participation on both sides. Identify any many-to-many relationship and propose an associative entity.

## Checkpoint

Explain the difference between “one or many” and “zero or many”. What changes when optionality is different?
