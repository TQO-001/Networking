---
title: "Software design: components, layers and responsibilities"
description: "Learn to separate user interfaces, application logic, domain rules and infrastructure dependencies."
order: 10
minutes: 22
level: "Beginner–Intermediate"
pathId: "foundational-knowledge"
module: "Design and architecture"
tags: ["architecture", "separation-of-concerns", "layers"]
kind: "lesson"
---

## Design is a set of decisions

Software design turns requirements into a structure that can be implemented and maintained. It decides what components exist, what each component owns and how they communicate.

A useful starting point is **separation of concerns**: give different responsibilities different places. A component that parses a file should not also render a React screen and manage database credentials.

## A common layered shape

A typical web application may use:

1. **Presentation layer:** React pages, forms, tables and user feedback.
2. **API/interface layer:** FastAPI routes, request/response schemas and HTTP status codes.
3. **Application/service layer:** use-case orchestration, such as importing assets.
4. **Domain layer:** business rules, such as what makes an asset record valid.
5. **Infrastructure/data layer:** files, PostgreSQL, external APIs and protocol clients.

This is a useful mental model, not a rule that every small script needs five folders. A small program can begin with fewer modules and split when responsibilities become difficult to manage.

## Dependency direction

The user interface calls the API. The API invokes application services. The services use domain rules and infrastructure through clear interfaces. Avoid making the domain rules depend on React components or database-specific details.

For example, a function that validates an IP address should be testable without starting FastAPI or connecting to PostgreSQL.

## Contracts between components

A component contract should describe:

- Inputs and their types/shape.
- Outputs and their meaning.
- Errors or failure results.
- Side effects (writes, network calls, file access).
- Performance or safety limits where relevant.

Contracts help separate teams. A React developer can build against an agreed JSON response even while the Python service is being implemented.

## Avoid premature architecture

Do not add microservices, message queues, event buses or complex abstraction layers merely because large companies use them. Start with the simplest structure that supports the known requirements, tests and expected growth. Add complexity when a real constraint justifies it.

## Exercise

Draw a component diagram for the OT asset register. Include React, FastAPI, validation service, storage adapter and PostgreSQL (if persistence is in scope). Add arrows showing who calls whom. Mark which components can be tested independently.

## Checkpoint

Explain why IP validation should not be buried inside a React table component. Identify at least two consumers that might need the same rule.
