---
title: "Scope, feasibility and project boundaries"
description: "Define what belongs in a release, what is excluded and which risks or dependencies need investigation."
order: 4
minutes: 18
level: "Beginner"
pathId: "foundational-knowledge"
module: "Discovery and requirements"
tags: ["scope", "feasibility", "constraints", "risk"]
kind: "lesson"
---

## Scope protects a project from becoming endless

**Scope** defines what work is included in a project or release. A scope statement should say what the system will do and what it will not do.

For the first OT asset register release:

**In scope:** import a prepared CSV, validate required fields, identify duplicate IDs, display a searchable table and export a corrected report.

**Out of scope:** scan networks, change device configurations, write to PLCs, discover credentials or connect to production infrastructure.

Writing exclusions is not a sign of a weak project. It is how a team makes boundaries visible.

## Feasibility questions

A feasibility check considers whether the project is practical:

- **Technical:** do we have the skills, tools and system access?
- **Operational:** can the intended users fit it into their workflow?
- **Economic:** are costs and benefits reasonable?
- **Schedule:** can the work be delivered with available time and people?
- **Legal/policy:** are data handling, licensing and approvals acceptable?
- **Safety:** could the proposed interaction affect people, equipment or service continuity?

For OT work, operational and safety constraints deserve explicit attention. A technique that is acceptable in a disposable software lab may not be acceptable against a live controller or production segment.

## Risk register

A risk is an uncertain event that could affect the project. Record:

| Field | Example |
|---|---|
| Risk | Imported file contains sensitive infrastructure details |
| Likelihood | Medium |
| Impact | High |
| Mitigation | Use fictional training data; review before import |
| Owner | Project maintainer |
| Status | Open |

Do not write “risk: bugs”. Identify a plausible event and what it would affect.

## Dependencies and assumptions

A dependency is something your project relies on, such as a supported Python release, approved test data or an API. An assumption is something believed to be true but not yet confirmed. Track both because a dependency can fail or an assumption can be false.

## Change control

When a new feature is requested, do not silently add it. Ask what problem it solves, what it changes in scope, how it affects schedule and testing, and whether the project owner accepts the trade-off. Small projects can use a lightweight change log; regulated environments may require a formal approval process.

## Exercise

Create an in-scope / out-of-scope list with at least five items each. Add three risks and one mitigation for each. Include at least one technical, one operational and one data-handling risk.

## Checkpoint

A stakeholder asks to add live network discovery. Explain why this is a scope change, identify the approvals and risk assessment needed, and propose a safe lab-only alternative for the current release.
