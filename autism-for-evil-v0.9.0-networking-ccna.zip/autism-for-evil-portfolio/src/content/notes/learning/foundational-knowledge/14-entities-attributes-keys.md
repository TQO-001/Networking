---
title: "Entities, attributes, candidate keys and primary keys"
description: "Choose stable identifiers and understand primary keys, alternate keys, foreign keys and nullable attributes."
order: 14
minutes: 22
level: "Beginner"
pathId: "foundational-knowledge"
module: "Database design foundations"
tags: ["entities", "primary-key", "foreign-key", "candidate-key"]
kind: "lesson"
---

## Give each entity a reliable identity

A row needs a way to be identified. A **candidate key** is an attribute or combination of attributes that could uniquely identify an entity. One candidate key is selected as the **primary key**. Other candidate keys may be protected with unique constraints.

For example, a device may have an internal `device_id` and an externally assigned `asset_tag`. If both are unique and stable, both are candidate keys. The team may choose an internal ID as the primary key and keep the asset tag unique as an alternate identifier.

## Natural and surrogate keys

A **natural key** has meaning in the domain, such as an approved asset tag. A **surrogate key** is generated mainly to identify a row, such as an integer identity or UUID.

Natural keys can be useful, but they may change or have formatting rules. Surrogate keys can make relationships stable, but they do not replace domain constraints. If asset tags must be unique, enforce that rule even if a row also has a UUID.

## Primary and foreign keys

A primary key uniquely identifies a row and should not be null. A **foreign key** references a candidate key in another table and helps prevent orphaned relationships.

Example (conceptual): `interfaces.device_id` references `devices.device_id`. This says an interface belongs to an existing device. It does not, by itself, guarantee that a device has at least one interface; that is a different rule.

## Attributes and nullability

An attribute should have a precise meaning. Decide whether it is required, optional, derived or controlled by another system. `NULL` means unknown, missing or not applicable depending on the domain; it should not be used as a substitute for an empty string or the text “N/A” without a clear convention.

Avoid storing multiple independent values in one field, such as `"Gi0/1, Gi0/2"` in a single interfaces column, when the values need to be searched or managed separately.

## Exercise

For Device, Interface and Review, list candidate keys, choose primary keys and identify foreign keys. Explain which fields may be null and why.

## Checkpoint

Explain why an auto-generated ID does not remove the need for a unique constraint on an asset tag.
