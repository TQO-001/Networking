---
title: "CI/CD, releases and keeping systems healthy"
description: "Understand automated checks, build artifacts, release notes, rollback planning and maintenance after deployment."
order: 29
minutes: 24
level: "Beginner–Intermediate"
pathId: "foundational-knowledge"
module: "Quality, documentation and delivery"
tags: ["ci", "cd", "release", "deployment", "maintenance"]
kind: "lesson"
---

## From source code to a release

A change is not ready for users simply because it works on the developer's laptop. A release process should produce a known artifact from a known commit, run agreed checks and document what is changing.

**Continuous Integration (CI)** usually means that proposed changes are automatically built and checked, often when code is pushed or a pull request is opened.

**Continuous Delivery/Deployment (CD)** extends the process toward preparing or automatically releasing changes. Continuous delivery keeps a release ready for approval; continuous deployment automatically promotes qualifying changes to production. Organisations choose based on their risk and approval requirements.

## A simple pipeline

1. Check out the commit.
2. Install locked dependencies.
3. Run formatting and lint checks.
4. Run unit and integration tests.
5. Build the frontend/backend artifact.
6. Scan dependencies or validate policy where configured.
7. Publish an artifact or deploy to a controlled environment.

A green pipeline is evidence that defined checks passed; it is not proof that the system is free of defects.

## Release notes

A release note should summarise user-visible changes, fixes, known limitations, configuration changes and migration steps. Reference the commit or release tag so the package can be traced to source history.

## Rollback and recovery

Before deploying, know how to return to a previous working version and what happens to data. Rolling back application code may not reverse a database migration safely. Backup, restore and migration plans should be tested rather than assumed.

For OT changes, software delivery may need formal approval, maintenance windows, offline validation, backups and a tested restoration plan. CI/CD automation does not override change-control or safety processes.

## Maintenance is part of the SDLC

After release, teams monitor errors and performance, respond to incidents, update dependencies, fix defects and eventually retire unsupported features. A system without an owner or maintenance plan becomes a liability.

## Exercise

Write a release checklist for your capstone. Include required checks, artifact identity, environment configuration, backup/rollback strategy, release notes and post-release observation.

## Checkpoint

Explain why a successful CI pipeline cannot replace user acceptance testing or OT change approval.
