---
title: "User stories, use cases and acceptance criteria"
description: "Translate requirements into actor-focused scenarios that can be built and checked."
order: 5
minutes: 20
level: "Beginner"
pathId: "foundational-knowledge"
module: "Discovery and requirements"
tags: ["user-stories", "use-cases", "acceptance-criteria"]
kind: "lesson"
---

## Three related ways to describe behaviour

A **requirement** states a system obligation. A **user story** describes a user's goal in a compact form. A **use case** describes the interaction in more detail, often including the normal path and alternatives.

A common user-story template is:

> As a **[role]**, I want **[capability]**, so that **[benefit]**.

Example:

> As a network engineer, I want to filter the asset list by VLAN, so that I can review the records associated with a particular lab segment.

This is a useful conversation starter, not a complete specification by itself.

## Acceptance criteria make the story checkable

Acceptance criteria state observable outcomes. Given/When/Then is a common format:

- **Given** the asset list contains records in VLANs 10 and 20
- **When** the user selects VLAN 10
- **Then** only records assigned to VLAN 10 are displayed

Add edge cases: What happens if no record matches? What happens if a record has no VLAN? Can the filter be cleared?

## A simple use case

**Use case:** Import an asset CSV

- Primary actor: network engineer.
- Preconditions: a prepared CSV file is available; the user is authorised to use the tool.
- Trigger: user selects Import.
- Main flow: choose file → parse headers → validate rows → show preview → user confirms → accepted records are saved.
- Alternative flow: malformed file → show a helpful error and do not modify existing records.
- Postcondition: either valid records are saved, or the data remains unchanged and the user sees why the import failed.

The use case forces us to consider failure behaviour before implementation.

## Traceability

A simple traceability table connects a requirement to its story, design and tests. This makes it easier to answer: “How do we know FR-003 has been implemented and verified?”

| Requirement | Story/use case | Verification |
|---|---|---|
| FR-001 CSV import | Import asset CSV | Valid and invalid file tests |
| FR-002 duplicate detection | Review duplicates | Duplicate ID test |
| FR-003 search | Search by hostname | Search acceptance test |

## Exercise

Write three user stories for your chosen project. Give each three acceptance criteria, including at least one error or empty-state case.

## Checkpoint

Explain why “the button works” is not a good acceptance criterion. Describe the user-visible result the button should produce, including what happens when the operation fails.
