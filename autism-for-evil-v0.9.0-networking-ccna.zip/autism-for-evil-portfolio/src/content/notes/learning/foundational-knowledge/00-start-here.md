---
title: "Start here: how engineers turn ideas into working systems"
description: "Understand the course, the shared engineering language and the practical case study used throughout the lessons."
order: 0
minutes: 12
level: "Beginner"
pathId: "foundational-knowledge"
module: "Start here"
tags: ["foundations", "course-map", "engineering"]
kind: "lesson"
---

## What this course is for

Programming languages and network commands are only part of engineering. Before anyone writes code, configures a switch or creates a database, a team needs to understand the problem, agree on a safe solution, organise the work and decide how success will be checked.

This course teaches those shared practices. It is useful whether you are building a Python API, a React interface, an OT asset inventory, a network monitoring tool or a database-backed application.

You do **not** need to know Python to begin. When code appears, it is used as an example of a designed solution, not as a prerequisite.

## The case study we'll use

We'll design a small **OT asset register** for a fictional training lab. It records devices, their role, a management address, location, VLAN and review status. It is not a scanner and it does not connect to production equipment. The example gives us enough complexity to practise requirements, algorithms, pseudocode, diagrams, data modelling, Git and testing without depending on real infrastructure.

## The engineering lifecycle

A simplified project travels through these activities:

1. Discover the problem and the people affected.
2. Define scope, requirements and constraints.
3. Design the process, data and interfaces.
4. Plan and implement small changes.
5. Test the result against agreed acceptance criteria.
6. Release it, monitor it and maintain it.

Real teams revisit these activities. They are not always a one-way staircase. A test may reveal a missing requirement; a new constraint may change the design.

## How to use the lessons

For each lesson, read the explanation, follow the worked example, complete the exercise and save the artefact it asks for. The artefacts accumulate into a small project pack: problem statement, requirements, pseudocode, flowchart, ERD, repository structure, Git history, test plan and README.

Suggested pace: one or two lessons per study session. Do not rush through diagrams or commit-message practice. Being able to explain *why* you made a decision matters more than finishing quickly.

## What you should have at the end

You should be able to take a loosely described problem and turn it into a scoped, documented, testable project. You should also understand how Git records changes and how a team uses branches and reviews to collaborate safely.

### First exercise

Write three sentences describing a system you would like to build. Include who needs it, what they struggle with today and what a better outcome would look like. Avoid naming a programming language or framework yet.

### Checkpoint

Explain the difference between **learning a tool** and **engineering a solution**. A tool is selected to help solve a defined problem; the existence of a tool is not, by itself, a reason to build a system.
