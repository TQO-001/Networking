---
title: "Secure engineering: protect data, access and operations"
description: "Apply least privilege, secret handling, input validation, safe defaults and operational boundaries throughout development."
order: 28
minutes: 23
level: "Beginner–Intermediate"
pathId: "foundational-knowledge"
module: "Quality, documentation and delivery"
tags: ["security", "least-privilege", "secrets", "safe-defaults"]
kind: "lesson"
---

## Security is a lifecycle concern

Security is not a final checklist that can be added after a system is built. Requirements, design, implementation, testing, deployment and maintenance all influence security.

## Core habits

- **Least privilege:** users and services receive only the permissions needed for their job.
- **Secure defaults:** start with conservative behaviour; require deliberate action to enable risky features.
- **Secret management:** keep passwords, tokens and private keys out of source code, commit history, screenshots and logs.
- **Input validation:** check data at trust boundaries, not only in the user interface.
- **Dependency hygiene:** use known packages, review dependency changes and keep lockfiles consistent.
- **Error handling:** return useful messages without disclosing stack traces, tokens or sensitive system details to ordinary users.
- **Auditability:** record important actions without collecting unnecessary sensitive data.

## Network and OT context

A read-only tool can still create risk. Polling can consume resources, an unexpected connection can trigger alarms and a poorly bounded monitor can generate excessive traffic. In OT environments, always use approved targets, maintenance processes and lab testing. Do not treat “read-only” as “risk-free”.

For this course, network exercises use local/private lab targets, sample files or simulators. They do not include production scanning, device configuration changes or control writes.

## Data classification

Before publishing sample data, classify it. Fictional examples are safest. Real device names, private IP mappings, hostnames, credentials, incident logs and screenshots may reveal infrastructure details. Sanitising a screenshot requires checking the image itself, not only the text file around it.

## Threat modelling at a beginner level

Ask:

1. What are we protecting?
2. Who or what can interact with the system?
3. What could go wrong?
4. What controls reduce the risk?
5. How will we know the controls work?

A simple data-flow diagram helps identify where data enters, crosses a trust boundary, is stored and leaves the system.

## Exercise

Make a small threat list for your capstone: at least four risks, the affected asset, likely impact and one mitigation. Include one risk involving secrets, one involving untrusted input and one involving network access.

## Checkpoint

Explain why a front-end validation rule is not enough to protect a database API. Identify where else validation and authorisation should occur.
