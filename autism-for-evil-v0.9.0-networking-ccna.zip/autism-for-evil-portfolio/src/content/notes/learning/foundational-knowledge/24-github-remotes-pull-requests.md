---
title: "GitHub collaboration: remotes, pull requests and reviews"
description: "Connect a local repository to a remote and understand the purpose of pull requests and code review."
order: 24
minutes: 24
level: "Beginner–Intermediate"
pathId: "foundational-knowledge"
module: "Git and collaboration"
tags: ["github", "remote", "pull-request", "code-review"]
kind: "lesson"
---

## Local Git and GitHub have different jobs

Git records history locally. GitHub hosts a remote repository and adds collaboration features. You can use Git without GitHub, and you can host Git repositories on other services.

A remote is a named address for another repository. A common setup is:

```bash
git remote add origin https://github.com/USERNAME/asset-register.git
git remote -v
git push -u origin main
```

Replace the example address with your own repository. If the repository is private or your organisation requires SSH, follow the approved authentication setup. Do not paste tokens into command history or commit them to files.

## Fetch, pull and push

- `git fetch` downloads remote references and objects but does not automatically change your current working branch.
- `git pull` fetches and integrates remote changes according to the configured strategy.
- `git push` sends local commits to a remote branch.

Before pushing, inspect your current branch and commits. Before integrating remote changes, check whether your working tree is clean and follow the team's workflow.

## Pull requests

A pull request (PR) proposes merging changes from one branch into another. It gives reviewers a place to inspect the diff, discuss decisions, run automated checks and agree that the change is ready.

A useful PR description includes:

- What changed.
- Why the change was needed.
- How it was tested.
- Screenshots or sample output when they help.
- Risks, limitations or migration steps.
- Links to the relevant issue or requirement.

## Review the change, not the person

A useful review asks whether the code satisfies requirements, handles edge cases, is understandable, avoids unsafe side effects and includes suitable tests. Comments should be specific and respectful: “What happens when the CSV has no header?” is more useful than “This is bad.”

## Exercise

Create a public or private practice repository. Push your capstone branch and open a pull request against `main`. Add a summary, test steps and one known limitation. Review the diff yourself before merging.

## Checkpoint

Explain why a pull request is not merely a button to merge code. What information does it preserve for maintainers?
