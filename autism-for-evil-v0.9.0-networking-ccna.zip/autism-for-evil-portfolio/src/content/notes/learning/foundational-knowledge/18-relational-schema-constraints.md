---
title: "From ERD to relational schema: tables and constraints"
description: "Translate entities and relationships into tables, primary/foreign keys, uniqueness and check constraints."
order: 18
minutes: 22
level: "Beginner–Intermediate"
pathId: "foundational-knowledge"
module: "Database design foundations"
tags: ["relational-schema", "constraints", "primary-key", "foreign-key"]
kind: "lesson"
---

## An ERD is not yet a physical schema

An ERD describes the model. A relational schema turns that model into tables, columns, data types and constraints. The physical database design adds database-specific choices such as indexes and storage behaviour.

Typical mapping rules:

- Each strong entity becomes a table.
- Each attribute becomes a column with a suitable type.
- The chosen primary key becomes a primary-key constraint.
- A one-to-many relationship usually becomes a foreign key on the “many” side.
- A many-to-many relationship becomes an associative table containing foreign keys to both entities.
- Optional relationships influence whether a foreign-key column may be null.

## Constraints protect data at the boundary

Validation in the user interface is useful for feedback, and validation in the API is useful for a clear contract. Database constraints provide another important protection because data may also arrive through scripts, imports or maintenance tasks.

Common constraints include:

- `NOT NULL` for required values.
- `UNIQUE` for values that must not repeat.
- `PRIMARY KEY` for row identity.
- `FOREIGN KEY` for valid references.
- `CHECK` for an allowed condition, such as a positive port number.

Do not rely on a front-end dropdown to enforce a permanent rule. The API and database should validate according to the system's design.

## Example schema sketch

```sql
CREATE TABLE devices (
    device_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    asset_tag TEXT NOT NULL UNIQUE,
    hostname TEXT NOT NULL,
    role TEXT NOT NULL
);

CREATE TABLE interfaces (
    interface_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    device_id BIGINT NOT NULL REFERENCES devices(device_id),
    name TEXT NOT NULL,
    vlan_id INTEGER CHECK (vlan_id BETWEEN 1 AND 4094),
    UNIQUE (device_id, name)
);
```

This is a teaching sketch, not a complete production schema. For a real design, confirm PostgreSQL types, naming conventions, nullability, update/delete behaviour and VLAN policy. A NULL VLAN may mean unassigned; a `CHECK` does not make the field mandatory.

## Link to the dedicated database course

This course focuses on design reasoning. The Database Systems course goes deeper into SQL, PostgreSQL setup, transactions, migrations, indexes, backups and Python integration.

## Exercise

Translate your ERD into a table list. For every table, list columns, types, primary key, foreign keys, uniqueness rules and nullability. Identify one rule that should be checked in both the API and database.

## Checkpoint

Explain the difference between a foreign key and a field that merely contains another table's ID as text. What protection does the actual constraint add?
