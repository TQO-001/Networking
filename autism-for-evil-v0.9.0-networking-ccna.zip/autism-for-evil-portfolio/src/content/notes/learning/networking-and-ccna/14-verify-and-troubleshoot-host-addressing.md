---
title: "Verify and Troubleshoot Host Addressing"
description: "Inspect a host’s IP configuration and identify common address, prefix, gateway, DNS and DHCP faults."
order: 14
minutes: 30
level: Beginner
pathId: networking-ccna
module: "IP addressing and subnetting"
kind: lesson
tags: ["networking", "ipv4", "ipv6", "dhcp", "troubleshooting", "ccna"]
---

## Why this matters

Many connectivity faults begin with an incorrect host configuration. Before touching a switch or router, verify what the endpoint believes its address, subnet, gateway and DNS settings should be.

## The four essentials

1. **IP address:** identifies the host at Layer 3.
2. **Prefix or subnet mask:** identifies which destinations are local.
3. **Default gateway:** first-hop router for remote destinations.
4. **DNS resolver:** translates names into addresses for applications.

A host can have a valid IP address and still be unable to reach the required service if the gateway, DNS or VLAN is wrong.

## Windows example

```powershell
ipconfig /all
route print
arp -a
```

Look for the active adapter, DHCP status, IPv4/IPv6 addresses, mask, gateway, DNS servers and lease information. Avoid copying sensitive addresses from a workplace machine into public posts.

## Linux example

```bash
ip addr
ip route
ip neigh
resolvectl status
```

Exact commands vary by distribution and resolver setup. The goal is to inspect the interface, default route, neighbour table and resolver configuration.

## A useful decision sequence

- Is the interface enabled and physically connected?
- Does it have the expected address and prefix?
- Does the gateway belong to the local subnet?
- Can it reach the gateway?
- Can it reach a known remote IP?
- Can it resolve a known name?
- Can it reach the exact TCP/UDP service that matters?

If a client has a `169.254.x.x` IPv4 address, it may have failed to obtain a DHCP lease. That is a clue, not a complete diagnosis: check the client, VLAN, DHCP scope, relay and server.

## Practical exercise

Use a lab PC with a known-good configuration. Record its address, prefix/mask, gateway and DNS. Then deliberately change one setting in Packet Tracer (for example, the gateway) and observe which tests still work and which fail. Restore the correct setting afterwards.

## Python connection

Python's `ipaddress` module can validate whether a gateway is in the host's local network. A later inventory checker can flag a missing address or malformed prefix before the data is used in an automation task.

## Recall without notes

1. What four configuration items should you inspect first?
2. What might a `169.254.x.x` address suggest?
3. Why can a client ping a gateway but still fail to open a website?
4. Why is changing several settings at once a poor troubleshooting method?

**Next:** [Layer 2 switching behaviour](/notes/learning/networking-and-ccna/15-layer-2-switching-behaviour/).
