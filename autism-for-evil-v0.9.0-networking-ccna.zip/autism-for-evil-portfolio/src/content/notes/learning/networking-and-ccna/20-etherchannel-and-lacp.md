---
title: "EtherChannel and LACP"
description: "Understand how multiple physical Ethernet links can operate as one logical port channel and how LACP negotiates membership."
order: 20
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Switching and network access"
kind: lesson
tags: ["switching", "etherchannel", "lacp", "port-channel", "ccna"]
---

## Why link aggregation exists

EtherChannel combines multiple compatible physical links into one logical port channel. It can increase aggregate capacity across multiple conversations and provide resilience if one member link fails. Load distribution is normally based on a hash of flow attributes; one individual flow is not guaranteed to use the combined bandwidth of every member link.

## LACP

Link Aggregation Control Protocol (LACP), standardised as IEEE 802.1AX (historically 802.3ad), negotiates a link aggregation group.

- **Active:** sends LACP negotiation messages.
- **Passive:** responds to LACP messages but does not initiate them.
- Active + active can form a channel.
- Active + passive can form a channel.
- Passive + passive does not initiate negotiation.

## Configuration consistency

Member interfaces must have compatible speed, duplex, Layer 2/Layer 3 mode, VLAN/trunk settings and other relevant attributes. A mismatch can prevent the channel from forming or cause member ports to be suspended.

## Example lab configuration

```text
configure terminal
interface range gigabitEthernet 0/1-2
 channel-group 1 mode active
 no shutdown
!
interface port-channel 1
 switchport mode trunk
 switchport trunk allowed vlan 10,20
end
show etherchannel summary
show lacp neighbor
```

Platform syntax varies. In some labs, configure the port-channel and member interface attributes in the order required by the IOS version. Verify before and after making changes.

## Verification

Look for a port-channel that is up and member ports bundled rather than individual links operating independently. Check `show etherchannel summary`, interface status and logs if the channel does not form.

## Practical exercise

Connect two switches with two physical links. Configure LACP in a lab, verify the port channel and test connectivity across it. Disconnect one member link and observe what happens to the logical channel and traffic.

## Recall without notes

1. What problem does EtherChannel solve?
2. What does LACP negotiate?
3. Which LACP mode combination does not initiate a channel?
4. Why does a single flow not necessarily use the full sum of all member-link bandwidth?

**Next:** [CDP, LLDP and topology validation](/notes/learning/networking-and-ccna/21-cdp-and-lldp/).
