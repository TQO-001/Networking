---
title: "Basic IPv4 Subnetting"
description: "Calculate network addresses, broadcast addresses, host ranges and subnet sizes by hand."
order: 11
minutes: 35
level: Beginner
pathId: networking-ccna
module: "IP addressing and subnetting"
kind: lesson
tags: ["networking", "ipv4", "subnetting", "cidr", "vlsm", "ccna"]
---

## What subnetting does

Subnetting divides a larger IPv4 address block into smaller networks. Each subnet has its own network address and broadcast address. Hosts in one subnet use a common prefix to decide which destinations are local.

## The calculation method

For a prefix `/p`:

1. Count host bits: `32 - p`.
2. Calculate total addresses: `2^(host bits)`.
3. For conventional LAN subnets, usable hosts are usually total minus 2 (network and broadcast). Remember `/31` point-to-point and `/32` host-route exceptions.
4. Find the block size in the octet where the mask changes: `256 - mask value`.
5. Locate which block contains the given address.

## Worked example: 192.168.10.77/26

A `/26` mask is `255.255.255.192`. The interesting octet is the last one. The block size is `256 - 192 = 64`, so the subnet boundaries are 0, 64, 128 and 192.

The address `.77` falls inside the block from `.64` through `.127`.

| Item | Result |
|---|---|
| Network address | `192.168.10.64` |
| First conventional host | `192.168.10.65` |
| Last conventional host | `192.168.10.126` |
| Broadcast address | `192.168.10.127` |
| Total addresses | 64 |
| Conventional usable hosts | 62 |

The calculation can be checked with binary AND between the IP address and subnet mask. The block-size method is a quicker way to find the same boundary in common cases.

## Common mistakes

- Treating the first address as a usable host in a normal subnet.
- Using the wrong octet when calculating the block size.
- Confusing total addresses with usable host addresses.
- Forgetting that subnet boundaries align to the block size.
- Relying on a calculator without understanding why the result is correct.

## Practical exercise

Calculate the network, first host, last host, broadcast and usable host count for:

1. `192.168.5.130/25`
2. `10.20.30.70/26`
3. `172.16.8.200/27`
4. `192.168.40.14/28`

Show your block-size working. Then check your answers with a trusted calculator or Python's `ipaddress` module.

## Python connection

```python
import ipaddress

interface = ipaddress.ip_interface("192.168.10.77/26")
network = interface.network

print("Network:", network.network_address)
print("Broadcast:", network.broadcast_address)
print("Mask:", network.netmask)
print("Total addresses:", network.num_addresses)

# Conventional IPv4 LANs reserve network and broadcast addresses.
# /31 point-to-point networks and /32 host routes are special cases.
if network.prefixlen == 31:
    usable_hosts = 2
elif network.prefixlen == 32:
    usable_hosts = 1
else:
    usable_hosts = max(0, network.num_addresses - 2)

print("Usable hosts:", usable_hosts)
```

This example handles the common IPv4 subnet cases explicitly. The Python lesson [Build a subnet calculator](/notes/learning/python-for-network-engineers/09-build-subnet-calculator/) turns this into a small tested program.

## Recall without notes

1. What is the block size for `/26` in the final octet?
2. Why is `.77` in the `.64–.127` block?
3. What is the difference between total addresses and usable hosts?
4. Why are `/31` and `/32` special?

**Next:** [VLSM and subnet planning](/notes/learning/networking-and-ccna/12-vlsm-and-subnet-planning/).
