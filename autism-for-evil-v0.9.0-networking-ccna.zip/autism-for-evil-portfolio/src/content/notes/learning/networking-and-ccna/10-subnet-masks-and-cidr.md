---
title: "Subnet Masks and CIDR"
description: "Understand how prefix lengths and dotted-decimal masks separate network bits from host bits."
order: 10
minutes: 25
level: Beginner
pathId: networking-ccna
module: "IP addressing and subnetting"
kind: lesson
tags: ["networking", "subnet-mask", "cidr", "ipv4", "ccna"]
---

## Why the mask matters

An IPv4 address does not tell a host which addresses are local by itself. The subnet mask or CIDR prefix identifies the network portion. A longer prefix means more network bits and fewer host bits within that subnet.

## Prefix notation

CIDR writes the number of leading network bits after a slash. For example, `/24` means 24 network bits and 8 host bits.

| Prefix | Dotted-decimal mask | Host bits |
|---:|---|---:|
| /8 | 255.0.0.0 | 24 |
| /16 | 255.255.0.0 | 16 |
| /24 | 255.255.255.0 | 8 |
| /25 | 255.255.255.128 | 7 |
| /26 | 255.255.255.192 | 6 |
| /27 | 255.255.255.224 | 5 |
| /28 | 255.255.255.240 | 4 |
| /30 | 255.255.255.252 | 2 |
| /31 | 255.255.255.254 | 1 |
| /32 | 255.255.255.255 | 0 |

A valid traditional subnet mask has contiguous `1` bits followed by contiguous `0` bits. `/31` is commonly used for point-to-point IPv4 links under RFC 3021, while `/32` represents one host route.

## Example: /24

`255.255.255.0` in binary is:

```text
11111111.11111111.11111111.00000000
<------ 24 network bits ------><8 host bits>
```

The `/24` network contains 256 total IPv4 addresses. In a traditional LAN subnet, the all-zero host portion identifies the network and the all-one host portion is the broadcast address, leaving 254 conventional usable host addresses.

## A useful relationship

- More network bits → more, smaller subnets from the same address block.
- More host bits → fewer, larger subnets.

The goal is not to choose the longest prefix possible. It is to fit the real addressing requirement and leave room for growth without wasting address space.

## Practical exercise

For `/25`, `/26`, `/27` and `/28`, write the dotted-decimal mask, count the host bits and calculate the total address count. Do not calculate exact network boundaries yet; that is the next lesson.

## Python connection

The standard-library `ipaddress` module can display a network's prefix and netmask:

```python
import ipaddress

network = ipaddress.ip_network("192.168.10.0/24")
print(network.netmask)
print(network.prefixlen)
print(network.num_addresses)
```

Use this to verify your understanding after doing the conversion manually.

## Recall without notes

1. What does `/26` mean?
2. What happens to host bits when the prefix becomes longer?
3. Why must subnet mask bits be contiguous?
4. What is special about `/31` and `/32`?

**Next:** [Basic IPv4 subnetting](/notes/learning/networking-and-ccna/11-basic-ipv4-subnetting/).
