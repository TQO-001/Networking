---
title: "First-Hop Redundancy: HSRP and VRRP"
description: "Understand how hosts can keep a usable default gateway when one Layer 3 gateway device or path becomes unavailable."
order: 26
minutes: 30
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "IP routing"
kind: lesson
tags: ["routing", "fhrp", "hsrp", "vrrp", "availability", "ccna"]
---

## The default-gateway availability problem

Hosts commonly have one default gateway address configured. If the physical router or Layer 3 switch providing that gateway fails, hosts may lose access to remote networks even when another gateway device is available.

First-Hop Redundancy Protocols (FHRPs) allow multiple Layer 3 devices to present a shared virtual gateway address. One device forwards traffic as the active gateway while another can take over if needed.

## HSRP and VRRP

- **HSRP (Hot Standby Router Protocol):** Cisco-developed first-hop redundancy protocol. A group presents a virtual IP and virtual MAC address; one device is active and another is standby.
- **VRRP (Virtual Router Redundancy Protocol):** an open standard with a similar first-hop redundancy purpose. A master router forwards for the virtual router and backups can take over.

The important operational question is which device currently owns the virtual gateway role and whether the expected peer and priority state are healthy.

## What affects operation

Priority, preemption behaviour, interface tracking and peer communication can influence which device becomes active/master. A device with higher configured priority is commonly preferred, subject to protocol rules and configuration. Tracking can reduce priority when an important upstream interface fails.

## Verification

Cisco IOS/IOS XE commands vary by protocol and release, but common operational checks include:

```text
show standby brief
show standby
show vrrp brief
show vrrp
```

Interpret the state, group, virtual IP, active/master device, standby/backup device and priority. Do not assume a configuration is working merely because the commands were entered.

## Practical exercise

Use a simulator or a supported lab to create two routers with a shared virtual gateway. Observe which device is active. Simulate a controlled lab failure and confirm the other device takes over. Do not test failover on a production network without change approval.

## Recall without notes

1. What problem does an FHRP solve?
2. What is the difference between a physical interface address and a virtual gateway address?
3. What operational state should you inspect?
4. Why can tracking matter?

**Next:** [End-to-end path troubleshooting](/notes/learning/networking-and-ccna/27-end-to-end-path-troubleshooting/).
