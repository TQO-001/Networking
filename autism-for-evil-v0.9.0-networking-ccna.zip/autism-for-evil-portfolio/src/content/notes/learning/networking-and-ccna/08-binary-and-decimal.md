---
title: "Binary and Decimal for IP Addressing"
description: "Understand bits, octets and powers of two so IPv4 addresses and subnet masks make sense rather than becoming memorised patterns."
order: 8
minutes: 25
level: Beginner
pathId: networking-ccna
module: "IP addressing and subnetting"
kind: lesson
tags: ["networking", "binary", "ipv4", "subnetting", "math", "ccna"]
---

## Why this matters

IPv4 addresses contain 32 bits. Subnet masks work by marking which bits belong to the network portion and which bits are available for host addressing. Binary is the foundation of subnetting.

## Bits and place values

A bit has a value of either `0` or `1`. Eight bits make one byte (or octet). In an IPv4 address, each dotted-decimal octet represents eight bits.

| Bit position | 7 | 6 | 5 | 4 | 3 | 2 | 1 | 0 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Decimal value | 128 | 64 | 32 | 16 | 8 | 4 | 2 | 1 |

To convert binary to decimal, add the place values where the bit is `1`.

Example: `11000000` = 128 + 64 = 192.

Example: `00001010` = 8 + 2 = 10.

Therefore `11000000.10101000.00000001.00001010` is `192.168.1.10`.

## Powers of two

You will repeatedly use these values:

| Number of bits | Combinations |
|---:|---:|
| 1 | 2 |
| 2 | 4 |
| 3 | 8 |
| 4 | 16 |
| 5 | 32 |
| 6 | 64 |
| 7 | 128 |
| 8 | 256 |

With `h` host bits, there are `2^h` total bit patterns. Traditional IPv4 subnet calculations commonly subtract the network and broadcast addresses to get usable host addresses. `/31` point-to-point and `/32` host routes are special cases.

## Convert decimal to binary

To express a decimal octet, check the place values from largest to smallest. For `10`, the 8 and 2 positions are set: `00001010`. For `172`, use 128 + 32 + 8 + 4: `10101100`.

## Practical exercise

Convert these octets in both directions: `10`, `24`, `64`, `128`, `172`, `192`, `224` and `255`. Show the place values you used. Do not use a converter for the first attempt.

## Python connection

Python can display a number in binary with `bin(192)`, but using that function is a check—not a replacement for understanding the place values. Later, the `ipaddress` module will handle network calculations while you still learn to work them out manually.

## Recall without notes

1. How many bits are in an IPv4 address?
2. What decimal value does the leftmost bit in an octet represent?
3. What is `11111111` in decimal?
4. Why are powers of two useful for subnetting?

**Next:** [IPv4 addressing](/notes/learning/networking-and-ccna/09-ipv4-addressing/).
