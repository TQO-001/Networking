---
title: "Network Components and Their Roles"
description: "Understand the devices and components that make a network work, and how they cooperate to move data."
order: 1
minutes: 25
level: Beginner
pathId: networking-ccna
module: "Network foundations"
kind: lesson
tags: ["networking", "devices", "switching", "routing", "ccna"]
---

## Why this matters

Before learning commands, learn what the devices are responsible for. If you cannot explain the difference between a switch, router, firewall and access point, a topology diagram becomes a collection of boxes rather than a system you understand.

## The basic idea

A **network** is a group of connected devices that exchange information using agreed rules called protocols. A device needs a way to connect, an address or identity, and a method of deciding where received data should go.

```text
Laptop ──┐
Printer ──┼── Switch ─── Router ─── Firewall ─── Internet
Server ──┘       │
                 └── Access Point ))) Wi-Fi clients
```

The diagram is simplified. In a real organisation, there may be multiple switches, routers, firewalls, wireless controllers, server networks and redundant links.

## Main components

| Component | Main responsibility | Mental model |
|---|---|---|
| Endpoint | Creates or consumes network traffic | The user or machine using the network |
| Network interface card (NIC) | Connects a device to Ethernet or Wi-Fi | The device's network connection |
| Switch | Forwards Ethernet frames within a Layer 2 network using MAC information | Connects devices in a LAN |
| Router | Forwards IP packets between different IP networks | Chooses a path between networks |
| Layer 3 switch | Combines switching with routing functions | Routes between VLANs or subnets at switching speeds |
| Firewall | Applies rules to allow, deny or inspect traffic | A policy enforcement point |
| Access point (AP) | Bridges wireless clients onto a wired network | The Wi-Fi connection point |
| Wireless LAN controller | Centrally manages compatible access points and wireless policy | A management/control point for Wi-Fi |
| Server | Provides a service such as DNS, DHCP, file sharing or an application | A provider of network services |
| Modem / ONT | Terminates a service-provider access technology | The handoff between the provider link and local equipment |
| PoE switch/injector | Supplies electrical power over compatible Ethernet cabling | Power and data on one cable |

## Switch versus router

A traditional Layer 2 switch looks at the **destination MAC address** in an Ethernet frame and uses its MAC address table to decide which port should receive it. A router looks at the **destination IP address** in a packet and uses its routing table to choose the next hop or outgoing interface.

A switch does not automatically route between IP subnets. A router does not normally forward a Layer 2 broadcast from one interface to another. A Layer 3 switch can perform both roles, but the concepts remain distinct.

## Example: a small office

A laptop sends a request to an internal application. Its Ethernet or Wi-Fi interface connects it to the LAN. A switch forwards local frames. If the application is on another subnet, the laptop sends the packet to its default gateway. A router or Layer 3 switch forwards it toward the destination network. A firewall may enforce policy between zones. The destination server responds using the reverse path.

## Common misunderstandings

- A firewall is not simply “a router with security”; firewalls make policy decisions and may inspect sessions or application data.
- An access point is not the same as a wireless router. An AP provides wireless access; a wireless router commonly combines routing, switching, firewall and AP functions.
- A server is not necessarily a special physical box. It can be a virtual machine or a service running in a cloud environment.
- A switch port being physically up does not prove that IP connectivity or an application is working.

## Practical exercise

In Packet Tracer, place two PCs, one switch and one router. Connect the PCs to the switch and the switch to the router. Label which device provides local switching and which device would be the default gateway. Do not configure anything yet; identify the roles first.

## Python connection

A network inventory is structured information about devices. Later, Python lists and dictionaries can store fields such as `hostname`, `role`, `management_ip` and `location`. That exercise belongs after you understand what the fields mean. If dictionaries and data types are unfamiliar, use the [Python data types reference](/notes/section-02-data-types/) as a companion—not a prerequisite for finishing this networking lesson.

## Recall without notes

1. What job does a switch perform?
2. What job does a router perform?
3. Why might a firewall sit between two networks?
4. What is the difference between a server and an endpoint?

**Next:** [Network topologies and architectures](/notes/learning/networking-and-ccna/02-network-topologies-and-architectures/).
