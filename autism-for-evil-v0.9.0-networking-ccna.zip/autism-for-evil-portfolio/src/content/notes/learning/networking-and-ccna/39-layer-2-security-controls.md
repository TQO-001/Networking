---
title: "Layer 2 Security Controls"
description: "Understand common defensive Layer 2 protections including port security, DHCP snooping, Dynamic ARP Inspection, storm control and RA Guard."
order: 39
minutes: 40
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Network security"
kind: lesson
tags: ["networking", "security", "layer2", "dhcp-snooping", "dai", "port-security", "ccna"]
---

## Why Layer 2 security matters

A switched LAN needs controls that reduce the risk of unauthorised connections, incorrect address assignment and disruptive Layer 2 traffic. These features should be designed and tested before they are enabled on production interfaces because a mistake can block legitimate devices.

## Controls to recognise

| Feature | Purpose |
|---|---|
| Port security | Restricts which source MAC addresses can use a switch port |
| DHCP snooping | Identifies trusted DHCP server paths and helps prevent unauthorised DHCP replies |
| Dynamic ARP Inspection (DAI) | Validates ARP messages against trusted binding information where supported |
| Storm control | Limits excessive broadcast, multicast or unknown-unicast traffic |
| RA Guard | Helps control which devices may send IPv6 Router Advertisements on a Layer 2 segment |

These features address different risks; none should be treated as a universal security switch.

## Port security example

An illustrative access-port configuration in a Cisco lab:

```text
interface gigabitEthernet 0/5
 switchport mode access
 switchport port-security
 switchport port-security maximum 2
 switchport port-security mac-address sticky
 switchport port-security violation restrict
```

The maximum, learning method and violation action should reflect the endpoint design. A phone plus workstation may need more than one MAC address. A restrictive setting can unintentionally block legitimate endpoints.

## DHCP snooping and DAI relationship

DHCP snooping builds a binding table from DHCP exchanges. Dynamic ARP Inspection can use those bindings to validate ARP packets on untrusted ports. Uplink ports toward authorised DHCP servers may need to be marked trusted; endpoint access ports normally remain untrusted. Trust must be placed carefully because trusting the wrong port weakens the control.

## Safe implementation process

1. Map endpoint, server and uplink ports.
2. Identify legitimate DHCP servers and trusted paths.
3. Understand which devices use static addressing.
4. Test the feature in a simulator or isolated lab.
5. Review logs and counters.
6. Make a controlled change with a rollback plan.

## Practical exercise

In Packet Tracer or a supported switch simulator, enable port security on a single lab access port and observe its operational status. Then draw where DHCP snooping trust belongs in a small access/distribution design. Avoid making changes to a workplace switch as a learning experiment.

## Recall without notes

1. What does DHCP snooping help prevent?
2. What information can DAI use to validate ARP messages?
3. What is the purpose of port security?
4. Why must trusted ports be selected carefully?

**Next:** [Network monitoring: NTP, SNMP and syslog](/notes/learning/networking-and-ccna/40-network-monitoring-ntp-snmp-syslog/).
