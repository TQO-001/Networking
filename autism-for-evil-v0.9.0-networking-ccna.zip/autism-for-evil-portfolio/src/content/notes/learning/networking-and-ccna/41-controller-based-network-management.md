---
title: "Controller-Based Network Management"
description: "Compare device-based, controller-based, cloud-based and automation-based management, and understand the control and data planes."
order: 41
minutes: 30
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Network operations and management"
kind: lesson
tags: ["networking", "controller-based", "control-plane", "data-plane", "management", "ccna"]
---

## Traditional device-based management

In a traditional network, engineers connect to individual devices and configure them directly. This provides detailed control but can become difficult to scale. Repeated manual changes can drift between devices if procedures are not consistent.

## Control plane and data plane

- **Data plane:** forwards user packets according to forwarding information installed on the device.
- **Control plane:** learns or calculates information used to make forwarding decisions, such as routes and neighbour relationships.
- **Management plane:** provides the interfaces and protocols used to configure, monitor and administer the network.

These planes are conceptual ways to describe responsibilities. A device or architecture may implement them in different ways.

## Controller-based management

A controller provides a central point for policy, visibility and configuration across supported devices. It may use device APIs, telemetry and configuration templates. Central management can improve consistency, but the controller itself needs availability, authentication, authorisation, backup and change control.

## Cloud-managed networks

Cloud-managed platforms host some management functions with a provider. This can simplify distributed administration, but creates dependencies on cloud connectivity, service availability, identity access and the vendor's operational model.

## Automation and infrastructure as code

Automation executes repeatable actions through APIs, command interfaces or configuration tools. Infrastructure as Code (IaC) expresses desired infrastructure in version-controlled declarations. The key benefit is repeatability and review; the risk is that a faulty or over-broad change can also be repeated quickly.

## Practical exercise

Compare managing three switches individually versus using a controller template. List what becomes easier, what new dependencies are introduced and how you would test a policy before applying it to every device.

## Recall without notes

1. What is the difference between control and data planes?
2. What does a controller centralise?
3. What new risks accompany cloud-based management?
4. Why should automation be reviewed and tested?

**Next:** [APIs, REST and JSON](/notes/learning/networking-and-ccna/42-apis-rest-and-json/).
