---
title: "Wireless Principles"
description: "Understand how Wi-Fi clients connect through access points, and how bands, channels, RF conditions and security affect connectivity."
order: 29
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Infrastructure and client connectivity"
kind: lesson
tags: ["networking", "wireless", "wifi", "rf", "ssid", "wlc", "ccna"]
---

## The basic wireless model

A wireless client communicates over radio frequency (RF) with an access point (AP). The AP bridges or otherwise integrates that wireless network with the wired infrastructure. In controller-based deployments, a wireless LAN controller (WLC) manages compatible APs and central wireless policy.

## Terms to recognise

| Term | Meaning |
|---|---|
| SSID | The network name presented to wireless clients |
| BSSID | Identifier for a specific basic service set, commonly based on an AP radio MAC address |
| Band | Frequency range used by the radio, such as 2.4, 5 or 6 GHz where supported |
| Channel | A defined portion of spectrum used by the AP radio |
| Channel width | Amount of spectrum occupied by a channel |
| Roaming | A client moves its association from one AP to another |
| RF interference | Other signals or noise reduce the quality of wireless communication |

## Band and channel selection

The 2.4 GHz band generally travels farther and penetrates obstacles better but has fewer non-overlapping channel choices and is often congested. 5 GHz offers more channel capacity in many environments but has different range/propagation characteristics. 6 GHz is available with supported Wi-Fi generations and regulatory approval; availability depends on the country and device capabilities.

Channel planning should consider nearby APs, channel width, client capabilities, building materials and interference. A stronger signal does not automatically mean better throughput if the channel is congested or noisy.

## Wireless security

Use appropriate modern authentication and encryption, such as WPA2/WPA3 configurations supported by the client and infrastructure. Enterprise deployments often use 802.1X authentication backed by a RADIUS service. An SSID name alone does not provide security.

## Troubleshooting a client

Check whether the SSID is visible, whether the client associates, whether authentication succeeds, whether the client receives the expected VLAN/IP configuration, and whether it can reach the gateway and required service. Separate radio problems from DHCP, routing, DNS and application problems.

## Practical exercise

In Packet Tracer or a supported simulator, create a wireless network, connect a client and inspect its association and IP settings. Write down the separate stages: discover SSID, authenticate, associate, obtain IP configuration, reach the gateway and use an application.

## Recall without notes

1. What is the role of an AP?
2. What does an SSID identify?
3. Why is a wireless connection not proven healthy by signal strength alone?
4. What is the role of a wireless controller?

**Next:** [Network virtualisation and VRFs](/notes/learning/networking-and-ccna/30-network-virtualisation-and-vrfs/).
