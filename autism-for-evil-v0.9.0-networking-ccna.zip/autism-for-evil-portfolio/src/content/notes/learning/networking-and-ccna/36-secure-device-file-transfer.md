---
title: "Secure Device File Transfer: SFTP and SCP"
description: "Understand how SFTP and SCP support secure transfer of configuration and software files for network-device operations."
order: 36
minutes: 25
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Network security"
kind: lesson
tags: ["networking", "security", "sftp", "scp", "file-transfer", "ccna"]
---

## Why file transfer belongs in network operations

Network engineers may need to back up configurations, archive logs, transfer approved software images or move support files. These operations need a controlled, auditable process. Secure File Transfer Protocol (SFTP) and Secure Copy Protocol (SCP) use SSH-based protection, unlike legacy unencrypted FTP and TFTP.

## SFTP and SCP

- **SFTP:** a file-transfer protocol that operates over an SSH connection and supports file-management operations.
- **SCP:** copies files between systems using SSH transport.

Both can protect file contents and credentials in transit when correctly configured. They still require secure authentication, permissions, host verification and an approved destination.

## Operational safeguards

Before transferring a device configuration or software file:

1. Confirm the device, file, destination and change approval.
2. Verify available storage and the correct software/hardware compatibility.
3. Use an approved transfer host and secure account.
4. Validate the file after transfer (size, checksum or platform verification as appropriate).
5. Keep a record of who transferred it, when and why.
6. Protect configuration backups because they may contain sensitive information.

## Practical exercise

In an isolated lab, transfer a harmless text file using SFTP or SCP between two systems you control. Verify the remote filename and contents. Do not transfer real workplace configurations or images without authorisation.

## Common misunderstanding

Using an encrypted protocol does not make every transfer safe. The file can still be sent to the wrong host, exposed through poor permissions or contain secrets. Transport security is only one part of handling sensitive data.

## Recall without notes

1. What transport does SFTP use?
2. How does SCP differ from legacy TFTP?
3. Why should configuration backups be treated as sensitive?
4. What should be verified after a transfer?

**Supporting reference:** Cisco's CCNA v2.0 blueprint includes secure file-transfer operations with SFTP/SCP for managing device configuration and software files.

**Next:** [Access Control Lists](/notes/learning/networking-and-ccna/37-access-control-lists/).
