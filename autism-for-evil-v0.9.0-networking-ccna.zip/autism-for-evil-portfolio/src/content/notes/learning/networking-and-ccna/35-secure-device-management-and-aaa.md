---
title: "Secure Device Management and AAA"
description: "Understand secure administrative access, local user accounts, AAA, RADIUS and TACACS+ for managing network devices."
order: 35
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Network security"
kind: lesson
tags: ["networking", "security", "aaa", "radius", "tacacs", "ssh", "ccna"]
---

## Why management access needs protection

A network device controls traffic and availability. Administrative access should therefore be authenticated, authorised and auditable. Use unique accounts, least privilege, secure management protocols and documented access procedures.

## AAA

AAA stands for:

- **Authentication:** who are you?
- **Authorisation:** what are you allowed to do?
- **Accounting:** what actions or sessions should be recorded?

A device can use a local user database or consult a central AAA service.

## RADIUS and TACACS+

| RADIUS | TACACS+ |
|---|---|
| Commonly uses UDP 1812 for authentication and 1813 for accounting | Uses TCP port 49 |
| Common in network access authentication | Common for centralised network-device administration |
| Traditionally combines authentication and authorisation behaviours | Separates authentication, authorisation and accounting more distinctly in its design |

Both require protected shared secrets, trusted server configuration and carefully designed fallback behaviour. Use the organisation's approved identity system and device documentation.

## Local account and SSH concepts

A basic Cisco IOS lab may use a local username and SSH for management access. The commands below are illustrative; use the syntax supported by your lab device and do not reuse real passwords in notes or source control.

```text
configure terminal
username labadmin privilege 15 secret <use-a-lab-only-secret>
ip domain-name lab.example.test
crypto key generate rsa modulus 2048
ip ssh version 2
line vty 0 4
 login local
 transport input ssh
end
```

The placeholder is intentionally not a real credential. Generate lab-only secrets locally and never paste production credentials into documentation.

## AAA client concepts

A device configured as an AAA client needs the server address, protocol settings and shared secret. It should have a tested fallback method consistent with policy. A misconfigured AAA change can lock administrators out, so practise on a simulator or console-accessible lab and have a recovery route.

## Practical exercise

In Packet Tracer or an isolated lab, configure a local account and SSH-only VTY access. Verify that remote management uses SSH, not Telnet. Then write a short comparison of local authentication versus central RADIUS/TACACS+.

## Recall without notes

1. What do authentication, authorisation and accounting mean?
2. What is a common RADIUS port pair?
3. What transport does TACACS+ use?
4. Why should management access use SSH rather than Telnet?

**Next:** [Secure device file transfer: SFTP and SCP](/notes/learning/networking-and-ccna/36-secure-device-file-transfer/).
