---
title: "VLSM and Subnet Planning"
description: "Design several differently sized subnets from one address block while avoiding overlap and unnecessary waste."
order: 12
minutes: 35
level: Beginner
pathId: networking-ccna
module: "IP addressing and subnetting"
kind: lesson
tags: ["networking", "vlsm", "subnetting", "address-planning", "python", "ccna"]
---

## What VLSM means

Variable Length Subnet Masking (VLSM) allows different subnets to use different prefix lengths. A point-to-point link does not need the same address space as a user LAN with dozens of hosts.

The design goal is to meet each subnet's host requirement, keep ranges aligned and avoid overlap.

## A repeatable method

1. List each network and its required host count.
2. Add reasonable growth allowance if the design requirement specifies it.
3. Sort requirements from largest to smallest.
4. Choose the smallest prefix that provides enough usable addresses.
5. Allocate each subnet on a valid boundary.
6. Record network, prefix, usable range, broadcast and purpose.
7. Check for overlap and confirm the allocation fits the parent block.

## Worked example

You have `192.168.20.0/24` and need three LANs: 50 hosts, 20 hosts and 10 hosts.

| Requirement | Prefix | Conventional usable hosts | Allocation |
|---:|---:|---:|---|
| 50 | /26 | 62 | `192.168.20.0/26` |
| 20 | /27 | 30 | `192.168.20.64/27` |
| 10 | /28 | 14 | `192.168.20.96/28` |

The next available address after the third block is `192.168.20.112`. The remaining space can be reserved for later needs, provided the future allocation continues to respect boundaries.

## Address plan quality

A good plan records more than CIDR blocks. Include VLAN or network purpose, gateway convention, DHCP scope, static/reserved addresses, owner, location and any relevant security boundary. Use a fictional or approved inventory; do not paste confidential workplace address plans into public notes.

## Python connection

Python's `ipaddress` module can help validate that candidate subnets belong to a parent block and do not overlap. It should validate the plan after you understand and produce it manually. The companion note [IP address planning in Python](/notes/learning/python-network-engineer-series/02-ipaddress-network-planning/) uses these ideas in a structured tool.

## Practical exercise

Divide `10.50.0.0/24` for requirements of 100, 40, 20 and 10 hosts. Allocate largest first. Record each prefix, network, usable range and broadcast address. Explain how much of the parent block remains unused.

## Recall without notes

1. Why allocate the largest subnet first?
2. What makes an address block aligned?
3. How do you confirm two proposed subnets do not overlap?
4. Why should an address plan record purpose and gateway information?

**Next:** [IPv6 fundamentals](/notes/learning/networking-and-ccna/13-ipv6-fundamentals/).
