---
title: "Layer 2 Switching Behaviour"
description: "Understand how a switch learns MAC addresses, forwards known frames, floods unknown traffic and keeps separate VLAN forwarding domains."
order: 15
minutes: 30
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Switching and network access"
kind: lesson
tags: ["switching", "mac-address-table", "ethernet", "vlan", "ccna"]
---

## The switch’s job

A Layer 2 Ethernet switch receives frames on physical ports and decides where to forward them. Its main reference is the destination MAC address, and its forwarding database is commonly called the MAC address table or CAM table.

## How learning works

When a frame arrives, the switch reads the **source MAC address** and records the port and VLAN where it was seen. This is how it learns where devices are reachable. When it needs to forward a frame, it looks up the destination MAC address in the same VLAN context.

| Destination lookup | Switch action |
|---|---|
| Known unicast on another port | Forward to that port |
| Known unicast on the same incoming port | Filter; do not send it back out the same port |
| Unknown unicast | Flood within the VLAN, excluding the incoming port |
| Broadcast | Flood within the VLAN, excluding the incoming port |
| Multicast | Forward according to the switch’s multicast behaviour and configuration |

The switch learns from source MAC addresses, not from the destination field. Entries age out so the table can adapt when devices move or disappear.

## VLAN context matters

A switch maintains forwarding information in the context of VLANs. The same MAC address can appear in different VLANs and represent different Layer 2 reachability. A VLAN is its own broadcast domain; a Layer 2 broadcast is not normally forwarded into another VLAN.

## Example

PC-A sends a frame to PC-B. If the switch has already learned PC-B’s MAC address, it forwards the frame only out PC-B’s port. If it has not learned the address yet, it floods the frame within that VLAN. PC-B may reply; the reply lets the switch learn PC-B’s source MAC and port.

## Verification

On a Cisco switch:

```text
show mac address-table
show mac address-table dynamic
show interfaces status
```

The exact options depend on IOS/IOS XE version and platform. Check the VLAN column as well as the MAC and port columns.

## Practical exercise

In Packet Tracer, connect three PCs to one switch. Send traffic between two PCs and inspect the MAC table. Predict what the switch will do before generating traffic. Repeat after clearing or allowing entries to age, if your lab supports it.

## Recall without notes

1. Which MAC address does a switch learn from an incoming frame?
2. What happens to an unknown unicast frame?
3. Why does VLAN context matter in the MAC table?
4. Why does a switch age dynamic MAC entries?

**Next:** [VLANs and access ports](/notes/learning/networking-and-ccna/16-vlans-and-access-ports/).
