---
title: "NAT and PAT"
description: "Understand address translation, static and dynamic NAT, and Port Address Translation at a network edge."
order: 33
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Network services"
kind: lesson
tags: ["networking", "nat", "pat", "ipv4", "ip-services", "ccna"]
---

## Why NAT is used

Network Address Translation (NAT) changes address information as packets pass through a device. It is commonly used to translate internal IPv4 addresses to addresses used on another network. Port Address Translation (PAT) allows multiple internal sessions to share one translated IPv4 address by using transport-layer port information.

NAT is common in IPv4 networks because private address space is not globally routed on the public Internet. NAT is not a complete security control and does not replace a firewall or access policy.

## Common types

- **Static NAT:** a fixed one-to-one mapping between an inside and outside address.
- **Dynamic NAT:** maps inside addresses to addresses from a configured pool.
- **PAT / NAT overload:** maps multiple inside sessions to one or a smaller number of outside addresses using port information.

## Conceptual example

A workstation with a private IPv4 address opens an Internet connection. The edge router translates the source address, and possibly the source port, into a public-side mapping. Return traffic is matched to the translation entry and forwarded toward the original inside host.

## IOS configuration concepts

A simple lab requires identifying inside and outside interfaces, defining the source addresses to translate, applying a translation type and verifying the translation table. Example syntax (adapt to the topology and platform):

```text
interface gigabitEthernet 0/0
 ip nat inside
interface gigabitEthernet 0/1
 ip nat outside
!
access-list 10 permit 192.168.10.0 0.0.0.255
ip nat inside source list 10 interface gigabitEthernet 0/1 overload
```

This is an illustrative PAT configuration. It is not a recommended production template without a full addressing, routing and policy design.

## Verification

```text
show ip nat translations
show ip nat statistics
show access-lists
show ip route
```

Verify that translations appear during a test flow, that the routing path exists and that security policy permits the required traffic.

## Practical exercise

In Packet Tracer, build one private LAN behind an edge router. Configure PAT on the edge interface and use a simulated external network to test reachability. Record the before/after source address and explain how the router associates reply traffic with the original host.

## Recall without notes

1. What does NAT change?
2. How is PAT different from static NAT?
3. Why is NAT not a replacement for firewall policy?
4. Which command shows translation entries?

**Next:** [Quality of Service fundamentals](/notes/learning/networking-and-ccna/34-quality-of-service-fundamentals/).
