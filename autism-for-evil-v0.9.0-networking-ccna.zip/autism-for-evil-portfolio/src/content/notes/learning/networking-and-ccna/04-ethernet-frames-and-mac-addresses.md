---
title: "Ethernet, Frames and MAC Addresses"
description: "Understand Ethernet framing, MAC addressing, media types and how devices communicate across a local link."
order: 4
minutes: 30
level: Beginner
pathId: networking-ccna
module: "Network foundations"
kind: lesson
tags: ["networking", "ethernet", "mac-address", "frames", "physical-layer", "ccna"]
---

## Why this matters

Ethernet is the common wired LAN technology used in many office and industrial networks. Switches use Ethernet frame information—especially MAC addresses—to forward traffic inside a Layer 2 network.

## MAC addresses

A standard Ethernet MAC address is 48 bits, usually written as six hexadecimal octets, for example `00:1A:2B:3C:4D:5E`. It identifies a network interface at the data-link layer. It is not a substitute for an IP address: MAC addressing supports local-link delivery, while IP addressing supports communication across networks.

Common destination types:

- **Unicast:** one interface.
- **Broadcast:** all devices in the local Layer 2 broadcast domain (`FF:FF:FF:FF:FF:FF`).
- **Multicast:** a defined group of receiving interfaces.

## Ethernet frame structure

A simplified Ethernet frame includes a destination MAC, source MAC, type/length field, payload and frame check sequence (FCS). The FCS helps detect frame corruption; it does not repair the frame.

```text
+----------------+----------------+----------+---------+-----+
| Destination MAC| Source MAC     | Type     | Payload | FCS |
+----------------+----------------+----------+---------+-----+
```

The payload commonly carries an IP packet, but Ethernet can carry other Layer 3 protocols too.

## Ethernet media

| Media | Typical use | Considerations |
|---|---|---|
| Twisted-pair copper | Desktops, phones, APs and switch uplinks | Cable category, length, pinout and interference matter |
| Multimode fibre | Shorter fibre links, often within buildings or data centres | Optics and supported distance must match |
| Single-mode fibre | Longer fibre links | Correct optics, connector cleanliness and optical levels matter |
| Wireless radio | Wi-Fi clients | Signal strength, interference, channel and security matter |

The cable, connector and transceiver must be compatible at both ends. Never infer a supported distance from “fibre” alone; check the specific optic and cable specifications.

## How a switch uses MAC addresses

A switch learns the **source MAC address** of an incoming frame and associates it with the port where it arrived. It then looks up the destination MAC:

- Known destination: forward out the associated port.
- Unknown unicast: flood within the VLAN, excluding the incoming port.
- Broadcast: flood within the VLAN.

The switch updates its table as devices move or entries age out. VLAN boundaries limit the flooding domain.

## Practical exercise

In Packet Tracer, connect two PCs to a switch. Generate traffic between them, then inspect the switch's MAC address table with `show mac address-table`. Identify the learned MAC address and port. Repeat with a third PC.

## Common misunderstandings

- A MAC address is not the same as an IP address.
- A switch does not need to know the full IP route to forward an ordinary Layer 2 frame.
- An Ethernet switch does not forward Layer 2 broadcasts through a router by default.

## Recall without notes

1. What information does a Layer 2 switch learn?
2. What does an unknown-unicast frame cause a switch to do?
3. What is the difference between copper and fibre as a physical medium?
4. Why can a MAC address not replace IP addressing?

**Next:** [ARP and local delivery](/notes/learning/networking-and-ccna/05-arp-and-local-delivery/).
