---
title: "Basic Network Troubleshooting Tools"
description: "Use host and Cisco IOS commands to collect evidence before changing a network configuration."
order: 7
minutes: 30
level: Beginner
pathId: networking-ccna
module: "Network foundations"
kind: lesson
tags: ["networking", "troubleshooting", "cli", "windows", "linux", "cisco-ios", "ccna"]
---

## A reliable troubleshooting habit

Troubleshooting is a process of reducing uncertainty. Start with the symptom, identify what should work, collect evidence, test one hypothesis and record the result. Avoid changing several settings at once: if the problem disappears, you will not know which change mattered.

## Host commands

| Goal | Windows | Linux | macOS |
|---|---|---|---|
| View interfaces and IP settings | `ipconfig /all` | `ip addr` | `ifconfig` or Network settings |
| View routes | `route print` | `ip route` | `netstat -rn` |
| View neighbour/ARP cache | `arp -a` | `ip neigh` | `arp -a` |
| Test IP reachability | `ping` | `ping` | `ping` |
| Trace a path | `tracert` | `traceroute` | `traceroute` |
| Query DNS | `nslookup` | `dig` / `nslookup` | `dig` / `nslookup` |

Command availability varies by operating-system version and installed tools.

## Cisco IOS verification commands

```text
show ip interface brief
show interfaces
show mac address-table
show ip arp
show ip route
show vlan brief
show interfaces trunk
show logging
```

Use the command that matches the question. For example, `show vlan brief` does not prove that an end-to-end application works; it tells you about VLANs and their access-port membership. `show logging` (or `show log` on supported platforms) helps you correlate a symptom with interface or device events.

### Standard ping and extended ping

A normal `ping` checks whether an ICMP echo request receives a reply. Cisco IOS also provides an **extended ping** workflow. Enter `ping` from the appropriate EXEC prompt and follow the interactive questions to vary items such as the source interface/address, repeat count, packet size or timeout. This helps test a path from a particular source rather than assuming the device's default source is representative.

Use extended ping only in your Packet Tracer or approved lab, with a target you are authorised to test. A failed ping does not automatically prove the destination is offline; ICMP may be filtered.

### Packet-capture output

A packet capture is a recorded view of traffic at a particular observation point. Use a supplied sample capture or a capture from your own isolated lab to identify basic facts such as source/destination addresses, protocol, ports and whether a request is followed by a response. The capture shows only what the capture point could observe; it does not automatically reveal the complete path or prove why an application failed.

## What each test proves—and does not prove

- `ping` tests whether ICMP echo traffic receives a reply. A firewall may block ICMP while the application works.
- `traceroute` / `tracert` can reveal responding hops, but routers may filter or rate-limit probe messages.
- `ipconfig` / `ip addr` show local interface configuration, not whether the gateway is routing correctly.
- `nslookup` / `dig` test DNS queries, not whether the returned application service is healthy.
- `show interfaces` can reveal link state, errors, speed and duplex information, but must be interpreted in context.

## A simple order of checks

1. Physical link and interface state.
2. Correct local IP address and prefix/mask.
3. Correct default gateway and DNS settings.
4. Reachability to the local gateway.
5. Reachability to a known remote IP.
6. Name resolution.
7. Required application port and service.

This is a guide, not a rigid rule. A known outage, change or monitoring alert may give you a better starting point.

## Practical exercise

In your own computer or an approved lab, record the output of the IP configuration, routing table and ARP/neighbour table commands. Identify the active interface, its address, its default gateway and at least one learned neighbour. Do not publish private work network details.

## Recall without notes

1. Which command displays the routing table on Windows?
2. Why is a successful ping not enough to declare an application healthy?
3. Which Cisco command displays a brief interface status summary?
4. Why should you change one thing at a time?
5. What additional question can extended ping help answer?
6. Why does a packet capture represent only the traffic visible at its capture point?

**Next:** [Binary and decimal for IP addressing](/notes/learning/networking-and-ccna/08-binary-and-decimal/).
