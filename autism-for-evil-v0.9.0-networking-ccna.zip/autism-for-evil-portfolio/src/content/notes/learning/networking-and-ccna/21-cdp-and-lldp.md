---
title: "CDP, LLDP and Topology Validation"
description: "Use neighbour discovery to confirm directly connected devices and compare the observed network with your documentation."
order: 21
minutes: 25
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Switching and network access"
kind: lesson
tags: ["switching", "cdp", "lldp", "network-documentation", "ccna"]
---

## Why neighbour discovery matters

A network diagram can become outdated after a device move, replacement or cabling change. Cisco Discovery Protocol (CDP) and Link Layer Discovery Protocol (LLDP) help identify directly connected neighbours and the local/remote ports used for the link.

CDP is Cisco-specific. LLDP is an open standards-based discovery protocol. They share a purpose but are not identical in every field or implementation.

## What you can learn

Depending on the device and settings, neighbour information may include device identity, platform, local interface, remote port, capability and management address. This information helps validate a topology and troubleshoot cabling or unexpected connections.

## Cisco IOS examples

```text
show cdp neighbors
show cdp neighbors detail
show lldp neighbors
show lldp neighbors detail
```

LLDP may need to be enabled:

```text
configure terminal
lldp run
```

Some devices disable discovery on selected interfaces or restrict advertised information. Do not assume a missing neighbour entry proves a cable is disconnected; check the protocol state and interface separately.

## Security and documentation

Neighbour discovery can expose device names and topology information. In a managed environment, follow policy about where it is enabled and which information is shared. Keep diagrams and port records current, but do not publish internal topology details without approval.

## Practical exercise

Connect two Cisco-compatible devices in Packet Tracer. Enable the relevant discovery protocol and identify the local and remote interfaces. Compare the output with your topology drawing. Then update the drawing so it reflects what you verified.

## Python connection

If you later export approved neighbour information to CSV or JSON, Python can compare the observed records against an expected topology. This is a useful data-validation project; it does not remove the need to verify the physical link and interpret the discovery output.

## Recall without notes

1. What does CDP discover?
2. How is LLDP different from CDP?
3. Why is a neighbour table useful for documentation?
4. Why does missing discovery output not automatically prove a physical fault?

**Next:** [Routing tables and route selection](/notes/learning/networking-and-ccna/22-routing-tables-and-route-selection/).
