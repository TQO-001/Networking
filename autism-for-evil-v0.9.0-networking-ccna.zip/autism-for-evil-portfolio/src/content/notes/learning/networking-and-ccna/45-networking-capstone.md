---
title: "Networking Capstone: Design, Configure and Verify"
description: "Bring addressing, VLANs, switching, routing, DHCP, security and troubleshooting together in one controlled Packet Tracer project."
order: 45
minutes: 90
level: "Intermediate"
pathId: networking-ccna
module: "Applied networking capstone"
kind: project
tags: ["networking", "capstone", "packet-tracer", "vlan", "routing", "python", "ccna"]
---

## The goal

This capstone tests whether you can connect the concepts into one small network design. Work in Packet Tracer or an equivalent isolated lab. The design uses fictional addresses and does not connect to production equipment.

## Scenario

A small organisation has three logical groups:

- Users: VLAN 10, `192.168.10.0/24`
- Printers: VLAN 20, `192.168.20.0/24`
- Management: VLAN 99, `192.168.99.0/24`

The organisation needs two access switches, one Layer 3 switch as the gateway, DHCP for users, and a clear management boundary. For the first version, do not add Internet access, wireless controllers or external services. Keep the project small.

## Design before configuring

Draw the topology and label:

- Endpoints and their VLANs.
- Trunk links between switches.
- SVIs and gateway addresses.
- Management access path.
- Which traffic should and should not cross VLANs.

Write a short port/VLAN table before entering commands.

## Suggested build sequence

1. Create VLANs on the switches.
2. Assign endpoint-facing access ports.
3. Configure the inter-switch trunk and verify the allowed VLANs.
4. Configure SVIs and enable Layer 3 routing where supported.
5. Assign host addresses or DHCP settings.
6. Verify same-VLAN connectivity across switches.
7. Verify the expected inter-VLAN flows.
8. Add a simple ACL only after the base network works.
9. Save the project and a short verification record.

## Verification evidence

Use relevant commands such as:

```text
show vlan brief
show interfaces trunk
show mac address-table
show ip interface brief
show ip route
show access-lists
show logging
```

Record what each command proves. For end-to-end testing, test both permitted and intentionally restricted flows. A passing ping does not prove that every application or security requirement works.

## Troubleshooting challenge

After the working baseline is saved, introduce one lab fault at a time:

- Put one endpoint in the wrong VLAN.
- Remove a VLAN from the trunk allowed list.
- Configure an incorrect default gateway.
- Apply an ACL in the wrong direction.

For each fault, record symptom, evidence, cause, fix and verification. Restore the baseline before introducing the next issue.

## Python integration

Once the network design is working, create a **local inventory validator** from fictional CSV data. Check that every device has a unique hostname, a valid IP address and an expected VLAN. The first version must not log in to devices or alter configuration.

Related project: [Subnet Calculator](/projects/01-subnet-calculator/).

## Completion standard

You can explain the topology, justify the addressing, configure and verify the VLAN/routing functions, demonstrate a controlled failure and produce a clear record of what you tested. If one part is weak, revisit the corresponding note instead of restarting the full path.
