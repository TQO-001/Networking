---
title: "Network Virtualisation and VRFs"
description: "Understand hypervisors, virtual machines, containers, virtual switches and VRFs, and why virtualised systems still need network design."
order: 30
minutes: 30
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Infrastructure and client connectivity"
kind: lesson
tags: ["networking", "virtualization", "hypervisor", "containers", "vrf", "ccna"]
---

## Why virtualisation matters to networking

Applications and infrastructure no longer run only on dedicated physical servers. A single physical host can run several virtual machines or containers, each with its own network interface and connectivity requirements. Engineers still need to design addressing, segmentation, routing, security and monitoring for these virtual environments.

## Virtual machines and hypervisors

A **virtual machine (VM)** emulates a computer with virtual CPU, memory, storage and network interfaces. A **hypervisor** manages the execution of VMs on physical resources. Type 1 hypervisors run directly on hardware; Type 2 hypervisors run on top of a host operating system.

A VM commonly connects through a virtual NIC to a virtual switch, which may connect to physical network interfaces and VLANs.

## Containers

Containers package an application and its dependencies while sharing the host operating-system kernel. They are usually lighter than full VMs, but they still have network namespaces, interfaces, routes and policies that need to be understood.

## VRFs

A Virtual Routing and Forwarding instance creates a separate routing table context on a router or Layer 3 switch. Multiple VRFs can use overlapping address ranges because their routing contexts are isolated. VRFs are not automatically a complete security boundary; route leaking and policy must be designed deliberately.

## Practical comparison

| Technology | What is separated? | Networking concern |
|---|---|---|
| VM | Guest operating system and virtual hardware | vNIC, virtual switch, VLAN and routing |
| Container | Application environment/process isolation | Container interfaces, bridge/overlay and policy |
| VRF | Routing table context | Route separation and controlled interconnection |

## Practical exercise

Draw a physical server hosting two VMs. Show their vNICs, virtual switch, VLANs and physical uplink. Then draw two VRFs on a Layer 3 device and explain why identical IP prefixes can exist in separate VRFs.

## Recall without notes

1. What does a hypervisor do?
2. How does a VM connect to a physical network?
3. How is a container different from a VM?
4. What does a VRF separate?

**Next:** [DHCPv4 and relay](/notes/learning/networking-and-ccna/31-dhcpv4-and-relay/).
