---
title: "IPv4 Addressing"
description: "Understand the 32-bit IPv4 address, network and host portions, private ranges, special addresses and the default gateway."
order: 9
minutes: 30
level: Beginner
pathId: networking-ccna
module: "IP addressing and subnetting"
kind: lesson
tags: ["networking", "ipv4", "private-addressing", "gateway", "ccna"]
---

## What an IPv4 address does

An IPv4 address is a 32-bit logical address, normally written as four decimal octets separated by dots, for example `192.168.10.25`. The subnet mask or prefix length tells the host which bits describe the network and which bits describe the host within that network.

An address by itself is incomplete for most design and troubleshooting tasks. You usually need the prefix/mask and, for remote communication, the default gateway.

## Network portion and host portion

For `192.168.10.25/24`, the `/24` indicates that the first 24 bits describe the network. The remaining 8 bits identify an address within that network. We will calculate exact network and broadcast boundaries in the subnetting lessons.

## Private IPv4 ranges

These ranges are reserved for private internets and are not globally routed on the public Internet:

| Range | Prefix |
|---|---|
| `10.0.0.0` – `10.255.255.255` | `10.0.0.0/8` |
| `172.16.0.0` – `172.31.255.255` | `172.16.0.0/12` |
| `192.168.0.0` – `192.168.255.255` | `192.168.0.0/16` |

Private addressing often uses NAT/PAT at an Internet edge, but NAT is not what makes an address private.

## Important special ranges

| Range/address | Purpose |
|---|---|
| `127.0.0.0/8` | Loopback on the local host |
| `169.254.0.0/16` | IPv4 link-local addressing, often seen when DHCP configuration fails |
| `0.0.0.0` | Unspecified address in relevant contexts |
| `0.0.0.0/0` | Default route prefix |
| `224.0.0.0/4` | IPv4 multicast range |
| `255.255.255.255` | Limited broadcast |

Do not confuse `0.0.0.0` as an address with `0.0.0.0/0` as a route prefix.

## Default gateway

A host uses its subnet information to decide whether a destination is local. For a destination outside its own subnet, it sends the first-hop frame to the default gateway. The gateway is normally an interface on the local router or Layer 3 switch.

## Example

A workstation has:

```text
IPv4 address: 192.168.10.25
Prefix:       /24
Gateway:      192.168.10.1
DNS:          192.168.10.10
```

This says the host belongs to the `192.168.10.0/24` subnet, uses `192.168.10.1` to reach remote networks, and asks `192.168.10.10` for name resolution. Whether those settings are correct depends on the actual network design.

## Practical exercise

Classify these example addresses as private, loopback, link-local or multicast: `10.4.5.6`, `172.20.1.8`, `192.168.50.2`, `127.0.0.1`, `169.254.10.20`, `224.0.0.5`. Explain what each classification implies.

## Recall without notes

1. Why does an IPv4 address need a prefix or mask?
2. Name the three RFC 1918 private ranges.
3. What might a `169.254.x.x` address suggest on a DHCP client?
4. When does a host send traffic to its default gateway?

**Next:** [Subnet masks and CIDR](/notes/learning/networking-and-ccna/10-subnet-masks-and-cidr/).
