---
title: "Access Control Lists"
description: "Understand how standard and extended IPv4 ACLs filter traffic through ordered permit and deny rules."
order: 37
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Network security"
kind: lesson
tags: ["networking", "security", "acl", "ipv4", "traffic-filtering", "ccna"]
---

## What an ACL does

An Access Control List (ACL) is an ordered set of rules used to match and permit or deny traffic. On Cisco routers, IPv4 ACLs can be applied to interfaces in an inbound or outbound direction. ACLs are also used by other features, such as NAT classification.

## Standard and extended ACLs

- **Standard ACL:** primarily matches the source IPv4 address.
- **Extended ACL:** can match source and destination addresses, protocol and transport ports.

ACLs may be numbered or named. Named ACLs are often easier to read and maintain.

## Rule processing

Rules are evaluated from top to bottom. The first matching ACE determines the result. If no explicit rule matches, an implicit deny applies at the end. Rule order is therefore important.

A wildcard mask is used in Cisco ACL syntax. It is the inverse of a subnet mask for common contiguous masks: `0` means a bit must match; `1` means it can vary.

## Example named extended ACL

This fictional lab rule permits HTTPS from one example user subnet to a server, then denies other IP traffic to that server:

```text
ip access-list extended USERS-TO-WEB
 permit tcp 192.168.10.0 0.0.0.255 host 192.0.2.25 eq 443
 deny ip 192.168.10.0 0.0.0.255 host 192.0.2.25 log
 permit ip any any
```

The last permit is included to make the lab example's intended remaining traffic explicit. In a real design, choose rules based on documented requirements and least privilege; do not copy a broad permit without considering the rest of the policy.

## Placement and direction

An inbound ACL filters packets as they enter an interface; an outbound ACL filters packets as they leave. Placement affects which traffic the ACL sees and how much traffic must be processed. Consider source, destination, direction and the required return traffic.

## Verification

```text
show access-lists
show ip interface
show running-config
```

Check the ACL is attached to the intended interface and direction. Hit counters can help establish whether a rule is matching, but they do not prove that the complete application path is healthy.

## Practical exercise

Build two subnets and a server in Packet Tracer. Write a requirement that allows only HTTPS from one subnet to the server. Create the ACL, apply it in the lab, test allowed and denied cases, and document the rule order.

## Recall without notes

1. What does a standard ACL primarily match?
2. What additional fields can an extended ACL inspect?
3. What happens when no ACE matches?
4. Why does rule order matter?

**Next:** [IPsec VPN fundamentals](/notes/learning/networking-and-ccna/38-ipsec-vpn-fundamentals/).
