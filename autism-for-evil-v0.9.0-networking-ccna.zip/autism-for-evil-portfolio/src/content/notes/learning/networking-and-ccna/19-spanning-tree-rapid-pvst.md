---
title: "Spanning Tree and Rapid PVST+"
description: "Understand why Layer 2 loops are dangerous and how Rapid PVST+ selects a loop-free forwarding topology."
order: 19
minutes: 40
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Switching and network access"
kind: lesson
tags: ["switching", "stp", "rapid-pvst", "bpdu", "ccna"]
---

## Why Layer 2 loops are a problem

Ethernet frames do not have a Layer 2 time-to-live field that reliably stops a frame circulating forever. A loop can cause broadcast storms, repeated frames and MAC address-table instability. Redundant links are useful for availability, but the network needs a loop-prevention mechanism.

## Spanning Tree Protocol

Spanning Tree Protocol (STP) exchanges Bridge Protocol Data Units (BPDUs) and elects a root bridge. Switches calculate a loop-free logical tree while leaving redundant paths available as alternatives. Rapid PVST+ is Cisco's per-VLAN implementation of Rapid Spanning Tree Protocol (RSTP).

## Root bridge and port roles

The root bridge is selected using Bridge ID, which includes priority and MAC address. The lowest Bridge ID wins. Switches then determine how to reach the root.

| Role | Meaning |
|---|---|
| Root port | Best path from a non-root switch toward the root bridge |
| Designated port | Port selected to forward for a network segment |
| Alternate port | A backup path toward the root, normally not forwarding user traffic |
| Backup port | A backup role on a shared segment; less common in modern full-duplex switched designs |

RSTP uses port states commonly described as discarding, learning and forwarding. It improves convergence compared with classic 802.1D STP.

## Edge-port protections

- **PortFast / edge port:** allows an endpoint-facing port to move quickly toward forwarding.
- **BPDU Guard:** protects an edge port by disabling it if a BPDU is received, depending on platform behaviour and configuration.
- **Root Guard:** prevents an unexpected superior BPDU from causing a port to become a root port.
- **Loop Guard:** helps prevent certain failures from causing a loop by guarding against unexpected loss of BPDUs.

These features are not interchangeable. Apply them based on the port's role and documented topology.

## Useful verification

```text
show spanning-tree
show spanning-tree vlan 10
show spanning-tree summary
show logging
```

Check which switch is root, each port role/state and whether a protection feature has placed a port into a blocking or inconsistent state.

## Practical exercise

Create three switches in a triangle with redundant links. Observe which ports are forwarding and which are alternate/discarding. Identify the root bridge. Change the bridge priority in the lab and observe how the tree changes.

## Recall without notes

1. Why can a Layer 2 loop cause a broadcast storm?
2. How is the root bridge selected?
3. What is the purpose of a root port?
4. Why should PortFast be used only on appropriate edge ports?

**Next:** [EtherChannel and LACP](/notes/learning/networking-and-ccna/20-etherchannel-and-lacp/).
