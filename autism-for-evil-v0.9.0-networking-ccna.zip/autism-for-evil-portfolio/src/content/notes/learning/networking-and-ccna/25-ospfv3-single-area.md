---
title: "OSPFv3: Single-Area IPv6 Routing"
description: "Understand how OSPFv3 supports IPv6 routing and how it differs operationally from OSPFv2."
order: 25
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "IP routing"
kind: lesson
tags: ["routing", "ospfv3", "ipv6", "ccna"]
---

## Why OSPFv3 matters

OSPFv3 provides OSPF routing support for IPv6. It uses many familiar OSPF ideas—router IDs, neighbours, areas, link-state information and cost—but the protocol operation and configuration are not simply a copy of OSPFv2.

## Concepts to carry forward

- Routers still need unique router IDs.
- Neighbour relationships still depend on compatible interface and area settings.
- Area 0 remains the backbone for a single-area lab.
- IPv6 addressing and interface state must be correct before troubleshooting OSPFv3.

Unlike IPv4 subnet-based OSPFv2 examples, OSPFv3 is commonly enabled on an interface and assigned to an area. Commands vary among Cisco IOS/IOS XE versions and platforms.

## Illustrative IOS XE lab configuration

```text
configure terminal
ipv6 unicast-routing
ipv6 router ospf 10
 router-id 2.2.2.2
!
interface gigabitEthernet 0/0
 ipv6 address 2001:DB8:1::1/64
 ipv6 ospf 10 area 0
 no shutdown
end
```

The documentation prefix `2001:DB8::/32` is used only for examples. Use the addressing plan assigned to your lab. Some platforms use slightly different OSPFv3 configuration syntax; check the device help and version-specific command reference.

## Verification

```text
show ipv6 interface brief
show ipv6 ospf neighbor
show ipv6 route ospf
show ipv6 protocols
```

First confirm IPv6 addressing and link-local addresses, then examine the OSPFv3 neighbour relationship and learned routes.

## Troubleshooting sequence

1. Confirm IPv6 is enabled and interfaces are up.
2. Verify the intended IPv6 prefix and link-local state.
3. Confirm OSPFv3 is enabled on the correct interfaces.
4. Check router IDs and area assignments.
5. Inspect neighbour state and routing table.
6. Verify end-to-end IPv6 reachability.

Do not troubleshoot a routing protocol before verifying the underlying interface and IPv6 connectivity.

## Practical exercise

Build a two-router IPv6 lab, enable OSPFv3 in area 0 and advertise one LAN behind each router. Verify the neighbour and learned routes. Compare the OSPFv3 interface configuration with the OSPFv2 network statement you used in the previous lesson.

## Recall without notes

1. What does OSPFv3 provide?
2. Which OSPF concepts remain familiar from OSPFv2?
3. Why should IPv6 interface state be verified before OSPFv3?
4. What is the purpose of the router ID?

**Next:** [First-hop redundancy: HSRP and VRRP](/notes/learning/networking-and-ccna/26-first-hop-redundancy-hsrp-vrrp/).
