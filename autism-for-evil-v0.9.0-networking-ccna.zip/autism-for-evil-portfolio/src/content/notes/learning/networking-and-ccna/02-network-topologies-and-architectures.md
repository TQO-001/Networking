---
title: "Network Topologies and Architectures"
description: "Learn how network devices are arranged, why organisations choose different designs, and how to read a topology."
order: 2
minutes: 25
level: Beginner
pathId: networking-ccna
module: "Network foundations"
kind: lesson
tags: ["networking", "topology", "architecture", "wan", "ccna"]
---

## Why this matters

A network topology shows how devices and links connect. Architecture explains the larger design choices: where services live, how networks are divided, where routing happens and how the design can grow.

## Topology versus architecture

- **Physical topology:** the actual cabling, radios, ports and devices.
- **Logical topology:** how traffic is grouped and forwarded, including VLANs, subnets and routing relationships.
- **Architecture:** the wider design pattern and the role each part performs.

A physical diagram and logical diagram can describe the same environment from different viewpoints.

## Common topologies

| Topology | Description | Trade-off |
|---|---|---|
| Star | Endpoints connect to a central switch or AP | Easy to manage; central device is important |
| Mesh | Devices have multiple interconnections | Resilient but can be more complex and costly |
| Point-to-point | A direct link between two devices | Simple and predictable |
| Hub-and-spoke | Branches connect through a central site | Easier central control; central site matters |
| Tree / hierarchical | Access devices feed distribution and core layers | Scales well when designed carefully |
| Spine-leaf | Every leaf switch connects to the spine layer | Predictable paths for data-centre traffic |

## Campus designs

A **two-tier or collapsed-core design** combines distribution and core roles. It can suit smaller campuses. A **three-tier design** separates access, distribution and core roles. It can support larger environments with clearer hierarchy and scaling boundaries.

```text
Three-tier campus model

             CORE
          /        \\
   DISTRIBUTION   DISTRIBUTION
     /   |   \\      /   |   \\
  ACCESS ACCESS ACCESS ACCESS ACCESS
    |      |      |      |      |
  Users  Phones Printers APs   Servers
```

A **WAN** connects networks across locations. A **SOHO** network is a small office/home-office environment, often with several functions combined into one device. **On-premises** services run within an organisation's facilities; **cloud-connected** designs use services hosted by a provider. Organisations commonly combine these approaches.

## Reading a topology diagram

Start by identifying endpoints, access switches, Layer 3 gateways, firewalls, service-provider links and server networks. Then trace a likely path from source to destination. Ask which links are Layer 2 trunks, which devices route, and where policy is enforced. Do not assume every line represents the same kind of link.

## Example

A branch office may have a star topology at the access layer: PCs, phones and APs connect to an access switch. The switch uplinks to a router/firewall that connects to the WAN. The local design is simple, but the architecture also includes central services, remote sites and security boundaries.

## Practical exercise

Draw a small office with two user PCs, a printer, an AP, a switch, a router/firewall and a server. Use different line styles or labels for wired, wireless and WAN connections. Mark where routing occurs. Then explain what would fail if the central switch stopped working.

## Python connection

A topology can be represented as data: devices are nodes and links are relationships. Python can eventually validate a device inventory or produce reports from a documented topology. The network design must be understood before code can interpret it correctly.

## Recall without notes

1. How is physical topology different from logical topology?
2. What is the purpose of an access layer?
3. When might a two-tier design be reasonable?
4. What does a WAN connect?

**Next:** [OSI and TCP/IP models](/notes/learning/networking-and-ccna/03-osi-and-tcpip-models/).
