---
title: "DNS Records and Name Resolution"
description: "Understand how DNS resolves names and recognise A, AAAA, CNAME, MX, NS and PTR records when troubleshooting access."
order: 32
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Network services"
kind: lesson
tags: ["networking", "dns", "records", "name-resolution", "ccna"]
---

## Why DNS matters

People use names such as `intranet.example.test`; networks use IP addresses to deliver packets. The Domain Name System (DNS) stores distributed records that help clients resolve names and discover services.

A host usually asks a configured recursive resolver. The resolver may answer from cache or query other DNS servers until it can provide an answer or an error.

## Records to recognise

| Record | Purpose | Example meaning |
|---|---|---|
| A | Maps a name to an IPv4 address | `app.example.test → 192.0.2.25` |
| AAAA | Maps a name to an IPv6 address | `app.example.test → 2001:DB8::25` |
| CNAME | Alias from one name to another canonical name | `portal → web01.example.test` |
| MX | Identifies mail exchangers for a domain | Mail delivery destination |
| NS | Identifies authoritative name servers | Which servers host the zone |
| PTR | Reverse lookup from an address to a name | Reverse DNS mapping |

The names and addresses here are examples only.

## DNS and application troubleshooting

If a user cannot open a site by name, test the name resolution separately from the IP path. Query the configured resolver, compare the returned record with the expected result, and check whether the client has a stale cache or is using an unintended DNS server.

Useful commands:

```powershell
nslookup app.example.test
```

```bash
dig app.example.test A
dig app.example.test AAAA
dig -x 192.0.2.25
```

A correct DNS answer does not prove that the target service is running or reachable. It only gives the information needed for the next step.

## Caching and TTL

DNS answers are commonly cached for a period determined by the record's Time to Live (TTL). A change may therefore take time to be reflected by all clients and resolvers. When troubleshooting, note the query time, resolver and TTL rather than assuming every client sees the same result immediately.

## Practical exercise

Create a small table with one A record, one AAAA record, one CNAME, one MX, one NS and one PTR record. For each, explain what question it answers. Then use `nslookup` or `dig` against a lab or public test domain and identify the record type returned.

## Python connection

Python applications often perform DNS resolution when opening an HTTP connection. A connection error may originate from name resolution, routing, TCP reachability, TLS or the application. Keep these layers separate when reading exceptions.

## Recall without notes

1. What is the difference between A and AAAA?
2. What is a CNAME used for?
3. Which record type identifies mail exchangers?
4. Why can DNS resolve correctly while an application still fails?

**Next:** [NAT and PAT](/notes/learning/networking-and-ccna/33-nat-and-pat/).
