---
title: "OSPFv2: Single-Area IPv4 Routing"
description: "Understand OSPFv2 neighbour relationships, router IDs, area 0 and basic route verification in an IPv4 lab."
order: 24
minutes: 40
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "IP routing"
kind: lesson
tags: ["routing", "ospf", "ospfv2", "ipv4", "ccna"]
---

## Why dynamic routing exists

Static routes are manageable in a small network, but as networks grow, maintaining every route manually becomes difficult. A dynamic routing protocol allows routers to exchange routing information and react to topology changes.

Open Shortest Path First (OSPF) is a link-state Interior Gateway Protocol. Routers exchange link-state information and calculate paths using the SPF algorithm. OSPF uses cost as its metric.

## OSPFv2 concepts

- **Router ID:** a 32-bit value that uniquely identifies an OSPF router within the routing domain.
- **Neighbour:** a directly connected router with which OSPF forms a relationship.
- **Adjacency:** a relationship in which routers exchange the relevant link-state information.
- **Area:** a logical grouping that scopes link-state information. Area 0 is the backbone area.
- **Cost:** OSPF's metric used in path selection.

A neighbour relationship depends on compatible settings and working IP connectivity. Common causes of failure include mismatched area, timers, network type, subnet or authentication settings (where authentication is configured).

## Simple Cisco IOS lab example

```text
configure terminal
router ospf 1
 router-id 1.1.1.1
 network 192.0.2.0 0.0.0.3 area 0
 network 198.51.100.0 0.0.0.255 area 0
end
```

The `network` command uses a wildcard mask to identify interfaces participating in OSPF. The exact networks and router ID must match the lab design. OSPF can also be enabled directly under interfaces on some platforms.

## Verify before troubleshooting configuration

```text
show ip ospf neighbor
show ip ospf interface brief
show ip route ospf
show ip protocols
```

A neighbour stuck in a non-full state is a clue. Check interface state, addressing, area, timers, network type and whether the relevant packets can pass.

## Point-to-point and broadcast networks

OSPF behaves differently depending on the interface network type. On broadcast multiaccess networks such as Ethernet, Designated Router (DR) and Backup Designated Router (BDR) roles reduce the number of adjacencies. Point-to-point links do not use DR/BDR election in the same way.

## Practical exercise

Build two routers connected by an IPv4 point-to-point network and advertise one LAN behind each. Configure single-area OSPFv2 in area 0. Verify the neighbour relationship and learned routes. Then intentionally mismatch the area in the lab and diagnose the result.

## Recall without notes

1. What kind of routing protocol is OSPF?
2. What is a router ID?
3. Why is area 0 important?
4. When do DR/BDR roles matter?

**Next:** [OSPFv3 single-area IPv6 routing](/notes/learning/networking-and-ccna/25-ospfv3-single-area/).
