---
title: "VLANs and Access Ports"
description: "Understand how VLANs divide a switched network into logical broadcast domains and how to assign endpoint switch ports."
order: 16
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Switching and network access"
kind: lesson
tags: ["switching", "vlans", "access-port", "poe", "ccna"]
---

## Why VLANs exist

A Virtual LAN (VLAN) creates a separate Layer 2 broadcast domain on a switched network. Devices in the same VLAN can communicate at Layer 2 when other settings allow it. Devices in different VLANs need a Layer 3 function—usually a router or Layer 3 switch—to communicate.

VLANs help organise a network by function, location or security policy. For example, users, voice devices, printers, servers and building-management devices may be placed into different VLANs. VLANs alone are not a complete security boundary: routing and firewall policy still determine what communication is allowed between them.

## Access ports

An access port normally carries traffic for one data VLAN to an endpoint such as a PC or printer. The endpoint usually sends and receives ordinary untagged Ethernet frames; the switch associates those frames with the configured access VLAN.

A voice VLAN can be configured for an IP phone, allowing phone and attached workstation traffic to be treated separately on a compatible design. Power over Ethernet (PoE) can supply power to phones, APs and other supported devices.

## Example Cisco IOS configuration

Use only in Packet Tracer or an approved lab. The interface number depends on the device.

```text
configure terminal
vlan 10
 name USERS
vlan 20
 name PRINTERS
!
interface gigabitEthernet 0/1
 description Example user workstation
 switchport mode access
 switchport access vlan 10
 spanning-tree portfast
 no shutdown
end
show vlan brief
show interfaces gigabitEthernet 0/1 switchport
```

PortFast is for an edge port connected to an endpoint, not a link to another switch. Enabling edge-port features on the wrong connection can contribute to a Layer 2 loop or instability; understand the topology first.

## VLAN IDs and defaults

802.1Q VLAN IDs are 12 bits, allowing IDs from 1 through 4094 for ordinary VLAN use. Some IDs have special meanings or platform-specific restrictions. Cisco switches commonly have VLAN 1 present by default. A deliberate design should document VLAN purpose and avoid treating the default VLAN as a universal choice for every endpoint.

## Common mistakes

- Creating a VLAN but leaving the endpoint port in another VLAN.
- Assuming devices in different VLANs can communicate without routing.
- Using VLANs as the only security control.
- Applying access-port configuration to an uplink that must carry several VLANs.

## Practical exercise

Create VLAN 10 (Users) and VLAN 20 (Printers). Put one PC and one printer into different VLANs. Verify the port membership with `show vlan brief`. Explain why they will not communicate through the switch at Layer 2 alone.

## Recall without notes

1. What does a VLAN create?
2. What does an access port normally carry?
3. Why do different VLANs need a Layer 3 device to communicate?
4. When is PortFast appropriate?

**Next:** [Trunking and 802.1Q](/notes/learning/networking-and-ccna/17-trunking-and-8021q/).
