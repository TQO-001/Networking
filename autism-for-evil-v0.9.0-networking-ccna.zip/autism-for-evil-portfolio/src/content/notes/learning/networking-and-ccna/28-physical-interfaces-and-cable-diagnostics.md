---
title: "Physical Interfaces and Cable Diagnostics"
description: "Understand copper and fibre links, interface status, speed, duplex, signal and common physical-layer symptoms."
order: 28
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Infrastructure and client connectivity"
kind: lesson
tags: ["networking", "physical-layer", "cabling", "fibre", "copper", "poe", "ccna"]
---

## Why physical-layer checks come early

If a link is physically broken, changing VLANs or routing will not fix it. Physical troubleshooting checks the medium, connectors, transceivers, interface state and negotiated link properties before investigating higher layers.

## Copper and fibre

| Medium | Common use | What to check |
|---|---|---|
| Twisted-pair copper | Endpoints and many local switch links | Cable category, length, pinout, termination, damage and interference |
| Multimode fibre | Shorter fibre runs | Correct fibre type, optic, connector and supported distance |
| Single-mode fibre | Longer fibre runs | Compatible optic wavelength, connector cleanliness, link budget and receive levels |

Fibre is not one interchangeable medium. The transceiver, wavelength, connector type and expected distance must match the link design. Copper cabling must meet its category and installation requirements.

## Speed and duplex

**Speed** describes the link rate. **Duplex** describes whether a link can transmit and receive simultaneously. Modern Ethernet links commonly use full duplex. A speed or duplex mismatch can produce poor performance, errors and retransmissions. Collisions are associated with shared or half-duplex Ethernet; they should not be treated as a normal condition on a correctly operating full-duplex switched link.

## Interface counters and state

Cisco IOS/IOS XE examples:

```text
show interfaces status
show interfaces gigabitEthernet 0/1
show ip interface brief
show logging
```

Look at administrative and operational state, negotiated speed/duplex, input errors, CRC/FCS errors, drops, resets and recent log messages. A single counter should be interpreted over time and in context; old counters may reflect a past incident.

## PoE and connected devices

Power over Ethernet can provide power to compatible devices such as APs and phones. A device may fail to start because of power budget, cable or endpoint compatibility even when the switch interface is physically connected. Check the platform's PoE status and power budget where relevant.

## Practical exercise

Use a Packet Tracer or approved lab interface. Inspect the link status and interface counters. Draw a checklist for “interface down”, “interface up but errors increasing” and “device has no power”. Do not disconnect production equipment for practice.

## Recall without notes

1. What is the difference between speed and duplex?
2. Why must fibre optics match the cable and link requirements?
3. What can CRC/input errors suggest?
4. Why can a link be up while a connected device still fails?

**Next:** [Wireless principles](/notes/learning/networking-and-ccna/29-wireless-principles/).
