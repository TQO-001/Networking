---
title: "Trunking and 802.1Q"
description: "Understand how a trunk carries multiple VLANs between network devices and how 802.1Q identifies VLAN membership."
order: 17
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Switching and network access"
kind: lesson
tags: ["switching", "trunking", "8021q", "native-vlan", "ccna"]
---

## Why trunks are needed

An access link normally carries one data VLAN. A trunk link can carry traffic for multiple VLANs over one physical connection, commonly between switches or between a switch and a router/Layer 3 device.

## 802.1Q tagging

IEEE 802.1Q adds a VLAN tag to an Ethernet frame on a trunk. The tag identifies the VLAN associated with the frame. The receiving switch uses the tag to keep the frame in the correct VLAN context. The tag is normally removed before the frame is delivered to an untagged endpoint access port.

The **native VLAN** is the VLAN associated with untagged traffic on an 802.1Q trunk in common Cisco designs. Both ends should agree on the native VLAN. A mismatch can cause unexpected VLAN placement and warnings.

## Example configuration

```text
configure terminal
interface gigabitEthernet 0/24
 description Lab trunk to the second switch
 switchport mode trunk
 switchport trunk allowed vlan 10,20,30
 switchport trunk native vlan 99
 no shutdown
end
show interfaces trunk
show interfaces gigabitEthernet 0/24 switchport
```

Create VLANs and verify that the far end is configured consistently. Some platforms require an explicit trunk encapsulation command or do not expose that command because they support only 802.1Q.

## Allowed VLAN lists

A trunk can be configured to carry only the VLANs required on that link. This reduces unnecessary Layer 2 reachability and makes the design easier to reason about. An allowed VLAN list is not a substitute for routing or security policy.

## Troubleshooting a trunk

Check both ends:

- Is the physical link up?
- Is the interface actually operating as a trunk?
- Is the VLAN permitted on both ends?
- Does the VLAN exist and is it active?
- Do native VLAN settings agree?
- Are the connected ports and spanning-tree state appropriate?

## Practical exercise

Build two switches with one PC in VLAN 10 and another PC in VLAN 20 on each switch. Configure the inter-switch link as a trunk. Verify the trunk status and permitted VLANs. Confirm same-VLAN connectivity across switches, then explain why different-VLAN connectivity still needs routing.

## Recall without notes

1. What problem does a trunk solve?
2. What does the 802.1Q tag identify?
3. What is the native VLAN?
4. Why should both trunk ends have compatible configuration?

**Next:** [Inter-VLAN routing and SVIs](/notes/learning/networking-and-ccna/18-inter-vlan-routing-and-svis/).
