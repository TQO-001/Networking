---
title: "APIs, REST and JSON for Network Operations"
description: "Understand how network platforms expose data and operations through APIs, HTTP methods and structured JSON."
order: 42
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Network automation and programmability"
kind: lesson
tags: ["networking", "api", "rest", "http", "json", "python", "ccna"]
---

## What an API is

An Application Programming Interface (API) is a defined way for one program to request data or actions from another. Network platforms may expose APIs for inventory, status, configuration and monitoring. An API is a contract: it defines endpoints, request formats, authentication and expected responses.

## REST-style APIs

REST-style APIs commonly use HTTP methods:

| Method | Typical intent |
|---|---|
| GET | Read a resource |
| POST | Create a resource or submit an action |
| PUT | Replace a resource |
| PATCH | Partially update a resource |
| DELETE | Remove a resource |

A method's meaning depends on the API contract. Never assume a GET request is the only safe call or that every endpoint is read-only.

## Common HTTP status codes

| Code | General meaning |
|---:|---|
| 200 | Successful response |
| 201 | Resource created |
| 400 | Bad request |
| 401 | Authentication required or failed |
| 403 | Request understood but not authorised |
| 404 | Resource not found |
| 409 | Conflict with current state |
| 429 | Rate limit exceeded |
| 500 | Server-side error |

## JSON

JSON represents structured data using objects, arrays, strings, numbers, booleans and null values.

```json
{
  "hostname": "switch-lab-01",
  "management_ip": "192.0.2.10",
  "site": "training-lab",
  "vlans": [10, 20, 30],
  "managed": true
}
```

This is fictional sample data. A Python program can parse JSON into dictionaries and lists, validate required fields and produce a report.

## Authentication and data handling

APIs may use tokens, certificates, basic authentication or other mechanisms. Keep credentials out of source code and version control. Use least privilege and classify the information being sent; network inventories and configurations can reveal sensitive internal details.

## Practical exercise

Read the sample JSON. Identify the string, list, boolean and numeric values. Write down three validation rules an inventory API client should check before trusting the data.

## Python connection

Use Python's `json` module to load a local sample file first. Later, use an HTTP client to call an approved lab API with an explicit timeout, error handling and credential management. Do not experiment against production network controllers.

## Recall without notes

1. What does an API define?
2. What is the usual intent of an HTTP GET request?
3. What does HTTP 403 mean?
4. Why should credentials never be hard-coded into a public repository?

**Next:** [Network automation with Python and Ansible](/notes/learning/networking-and-ccna/43-network-automation-python-ansible/).
