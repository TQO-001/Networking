---
title: "TCP, UDP, Ports and Common Services"
description: "Understand transport protocols, port numbers and the services that make networks useful."
order: 6
minutes: 30
level: Beginner
pathId: networking-ccna
module: "Network foundations"
kind: lesson
tags: ["networking", "tcp", "udp", "ports", "protocols", "ccna"]
---

## Why this matters

IP delivers packets between hosts. Applications on those hosts still need a way to identify which program should receive the data. TCP and UDP provide transport functions, and port numbers identify application endpoints.

## TCP and UDP

| TCP | UDP |
|---|---|
| Connection-oriented | Connectionless datagrams |
| Uses sequence numbers and acknowledgements | No built-in delivery acknowledgement or ordering |
| Retransmits lost data and delivers an ordered byte stream | Lower protocol overhead; applications decide what reliability they need |
| Common for web sessions, SSH and file transfer | Common for DNS queries, voice/video and telemetry, depending on the application |

TCP begins a connection with a three-way handshake: SYN, SYN-ACK, ACK. This establishes shared connection state. UDP sends datagrams without that handshake. UDP is not automatically “faster” in every situation; performance depends on the application and network conditions.

## Port numbers

Ports range from 0 to 65535. Common categories are:

- Well-known: 0–1023.
- Registered: 1024–49151.
- Dynamic/private: 49152–65535 (commonly used for temporary client-side ports).

A conversation commonly uses a source IP, source port, destination IP, destination port and transport protocol.

## Common services to recognise

| Service | Common port(s) | Purpose |
|---|---:|---|
| SSH / SFTP / SCP | TCP 22 | Secure remote management and file transfer |
| DNS | UDP/TCP 53 | Name resolution and related DNS operations |
| DHCPv4 | UDP 67 server, 68 client | Dynamic IPv4 configuration |
| HTTP | TCP 80 | Web traffic without TLS |
| HTTPS | TCP 443 | Web traffic protected with TLS |
| NTP | UDP 123 | Clock synchronisation |
| SNMP | UDP 161, traps often 162 | Monitoring and management data |
| Syslog | Commonly UDP 514; other transports exist | Log transport |
| RADIUS | UDP 1812 authentication, 1813 accounting | Centralised AAA |
| TACACS+ | TCP 49 | Centralised device administration AAA |

Ports are common defaults, not a guarantee that every implementation uses them. Applications can be configured to use different ports.

## How to think about a failed service

If a host can ping a server but cannot open its web application, IP reachability may be working while the TCP port, firewall policy, TLS configuration or application is failing. Test the service you actually need; do not rely on ping alone.

## Practical exercise

For each of these, name the protocol and common port: HTTPS, SSH, DNS, DHCP, NTP and SNMP. Then explain why DNS can use both UDP and TCP.

## Python connection

When Python later calls an API, it will usually use HTTP(S), which runs over a transport connection. Understanding IP, ports, DNS and timeouts makes the Python error messages much easier to interpret.

## Recall without notes

1. What does a TCP handshake establish?
2. What is the purpose of a port number?
3. Which transport protocols are commonly used by DNS and DHCPv4?
4. Why does successful ping not prove HTTPS is working?

**Next:** [Basic network troubleshooting tools](/notes/learning/networking-and-ccna/07-basic-network-troubleshooting-tools/).
