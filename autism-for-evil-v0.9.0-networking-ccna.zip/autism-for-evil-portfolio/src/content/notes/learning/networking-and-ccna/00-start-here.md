---
title: "Start Here: How Networking & CCNA Fit Together"
description: "A map of the networking path, how each subject builds on the previous one, and how Python supports practical networking work."
order: 0
minutes: 12
level: Beginner
pathId: networking-ccna
module: "Getting oriented"
kind: guide
tags: ["orientation", "networking", "ccna", "study-method"]
---

## Why this path exists

This path is the main route for learning networking properly and preparing for the Cisco CCNA. It starts with how networks behave, builds your addressing and switching knowledge, then moves into routing, services, security and network operations. Python is connected to the route whenever it helps you practise or automate a real idea.

This is a **sequence, not a calendar**. There are no weekdays, deadlines or overdue lessons. Complete the next useful note when you have time. If you take a break, continue where you stopped.

## How the subjects connect

A network is made from devices and links. Those devices exchange frames and packets using agreed protocols. IP addressing tells devices where they belong; switches move frames inside a local network; routers move packets between networks. Services such as DHCP and DNS make networks usable. Security and management keep them controlled and observable. Automation helps repeat work consistently.

```text
Network foundations
       ↓
IP addressing and subnetting
       ↓
Switching and VLANs
       ↓
Routing and end-to-end paths
       ↓
Network services and security
       ↓
Operations, automation and troubleshooting
       ↓
Industrial / OT networking extension
```

## Your learning priority

- **Deep focus: Networking and CCNA.** Understand how networks work and practise configuration, verification and troubleshooting in a lab.
- **Supporting skill: Python.** Learn programming fundamentals separately, then apply them to network data and repeatable tasks.
- **Integration: small useful tools.** For example, use `ipaddress` to verify subnet calculations, dictionaries to model a device inventory, and CSV/JSON to read fictional asset data.
- **Specialisation: OT networking.** Apply the foundations to industrial architecture after the core path is comfortable.

Do not force Python into every lesson. A good network engineer needs to understand the network first; code is a tool, not a shortcut around that understanding. When a concept connects naturally to programming, the path links to the relevant Python reference or project. For general Python syntax and dictionaries, use [Python Foundations](/learning-paths/python-foundations/) and the [data types reference](/notes/section-02-data-types/).

## A flexible study session

Aim for about 40–60 minutes when your day allows it. A shorter session still counts.

1. **Recall (5 min):** Say what you remember from the previous topic without opening it.
2. **Learn (15–20 min):** Read one note. Do not open five different courses at once.
3. **Practise (15–25 min):** Draw, calculate, configure or troubleshoot in Packet Tracer or a safe lab.
4. **Explain (5 min):** Close the note and explain the idea in your own words.
5. **Record (2 min):** Write one thing understood, one thing unclear and the next action.

Do not rewrite the entire reference note. Your personal notes should capture your explanation, mistakes and questions—not a copy of the textbook.

## How to decide when a note is complete

A note is complete when you can:

- Explain the central idea without reading the definition.
- Interpret a small diagram, command output or example.
- Complete the practical task or explain why you cannot yet.
- Answer at least one variation of the example.

If one part is weak, mark it for revision. Do not restart the whole path.

## CCNA version note

Cisco's published transition is:

- **200-301 v1.1:** last test date 2 February 2027.
- **200-301 v2.0:** first test date 3 February 2027.

Use the blueprint that matches your booked exam date. This path is mapped primarily to v2.0 because it is the upcoming version as of this document's creation date. Foundational networking topics remain useful across both versions, but the exam emphasis and some objectives differ.

The v2.0 exam domains are:

| Domain | Weight | What this path covers |
|---|---:|---|
| Network Infrastructure and Connectivity | 25% | Physical links, IPv4/IPv6 client addressing, wireless, virtualisation and DHCPv4 |
| Switching and Network Access | 25% | Switch interfaces, VLANs, trunks, LACP, SVIs, discovery, verification and Rapid PVST+ |
| IP Routing | 20% | Routing tables, static routes, OSPFv2/v3 and first-hop redundancy |
| Network Services and Security | 20% | AAA, SFTP/SCP, NAT/PAT, DNS, ACLs, IPsec and Layer 2 security |
| AI, and Network Operations and Management | 10% | AI use, management approaches, SNMP, Ansible and syslog |

The official exam blueprint is the final authority. See the [Cisco v2.0 exam topics PDF](https://learningcontent.cisco.com/documents/marketing/exam-topics/200-301_CCNA_v2.0_Exam_Topics_PDF.pdf) and [Cisco's transition announcement](https://blogs.cisco.com/learning/stay-on-track-get-certified-before-the-ccna-refresh).

## Start here

Follow the notes in order. You do not need to study Python and networking for equal amounts of time. Keep networking as the main focus and use the Python references in the relevant modules when they make the concept easier to practise.

**First lesson:** [Network components and their roles](/notes/learning/networking-and-ccna/01-network-components-and-roles/).
