---
title: "Network Monitoring: NTP, SNMP and Syslog"
description: "Understand clock synchronisation, device telemetry and centralised logs as foundations for network operations."
order: 40
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Network operations and management"
kind: lesson
tags: ["networking", "monitoring", "ntp", "snmp", "syslog", "operations", "ccna"]
---

## Why network visibility matters

A device can be forwarding traffic while experiencing errors, resource pressure or configuration changes. Monitoring helps engineers understand the state of a network over time rather than relying only on user reports.

## NTP

Network Time Protocol (NTP) synchronises clocks across devices. Consistent time makes it possible to compare switch logs, firewall events, server records and monitoring alerts. Without a consistent time source, an incident timeline can be misleading.

## SNMP

Simple Network Management Protocol (SNMP) allows a management system to query or receive information from network devices.

- **Manager:** the monitoring system.
- **Agent:** software on the managed device.
- **MIB:** a structured collection of managed objects.
- **OID:** an identifier for a particular managed object.
- **Polling:** manager requests data at intervals.
- **Trap/inform:** device sends an event notification to the manager.

SNMPv3 supports authentication and privacy features; older versions have weaker security characteristics and should be treated according to organisational policy.

## Syslog

Syslog transports event messages from devices to a collector. Cisco severity levels are numbered from 0 (emergency) through 7 (debugging). Lower numbers indicate more severe conditions.

| Level | Name |
|---:|---|
| 0 | Emergencies |
| 1 | Alerts |
| 2 | Critical |
| 3 | Errors |
| 4 | Warnings |
| 5 | Notifications |
| 6 | Informational |
| 7 | Debugging |

Messages can include a timestamp, facility, severity and event text. Consistent timestamps from NTP make logs much more useful.

## Management approaches

Monitoring can be device-based, controller-based or cloud-based. Regardless of platform, decide what should be measured, how often, who receives alerts, how long data is retained and how access is protected.

## Practical exercise

Create a small incident timeline from fictional switch events. Include a link-down message, an authentication warning and a routing change. Explain why timestamps and severity help determine the order and impact of events.

## Python connection

The Python network log-analyser project can read exported sample logs, normalise timestamps and summarise events. Keep data offline or use explicitly approved exports; do not collect production logs without permission.

## Recall without notes

1. Why is NTP useful during troubleshooting?
2. What is the difference between SNMP polling and a trap?
3. What does an OID identify?
4. Which syslog severity number is most severe?

**Next:** [Controller-based network management](/notes/learning/networking-and-ccna/41-controller-based-network-management/).
