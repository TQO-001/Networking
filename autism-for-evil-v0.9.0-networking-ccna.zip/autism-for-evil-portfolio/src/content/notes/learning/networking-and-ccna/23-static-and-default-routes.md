---
title: "Static and Default Routes"
description: "Configure and verify IPv4 and IPv6 static routes, including network, host, default and floating static routes."
order: 23
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "IP routing"
kind: lesson
tags: ["routing", "static-route", "ipv4", "ipv6", "default-route", "ccna"]
---

## Static routing

A static route is entered by an administrator rather than learned dynamically from a routing protocol. It is useful for small or predictable networks, default paths and specific destinations. Static routes do not automatically adapt to every topology change.

## IPv4 route forms

```text
! Destination network route
ip route 192.168.20.0 255.255.255.0 192.0.2.2

! Default route
ip route 0.0.0.0 0.0.0.0 192.0.2.1

! Host route (/32)
ip route 203.0.113.10 255.255.255.255 192.0.2.2

! Floating static route with a higher administrative distance
ip route 192.168.20.0 255.255.255.0 192.0.2.3 200
```

These are illustrative commands for a lab. The next-hop addresses must match the actual topology. A floating static route is intended as a less-preferred backup when a preferred route is unavailable; the administrative-distance value must be chosen deliberately.

## IPv6 routes

IPv6 static routes use a prefix and next hop or interface as supported by the platform. A default IPv6 route uses `::/0`.

```text
ipv6 unicast-routing
ipv6 route 2001:DB8:20::/64 2001:DB8:1::2
ipv6 route ::/0 2001:DB8:1::1
```

The `2001:DB8::/32` prefix is reserved for documentation examples. Do not use it as a real production allocation.

## Recursive lookup

If a static route uses a next-hop address, the router must have a way to reach that next hop. The router may perform another route lookup to determine the outgoing interface. If that recursive resolution fails, the route may not be usable.

## Verification

```text
show ip route
show ip route static
show ipv6 route
ping 192.0.2.2
traceroute 203.0.113.10
```

Check the route is installed, confirm the next hop is reachable and test an end-to-end destination. A route being present does not guarantee the remote host or application is healthy.

## Practical exercise

Build two routers and two LANs in Packet Tracer. Configure one static route on each router so the LANs can communicate. Add a default route on an edge router. Then add a higher-AD backup route in a separate lab scenario and explain when it becomes preferred.

## Recall without notes

1. What distinguishes a static route from a dynamic route?
2. What is the IPv4 default route prefix?
3. What makes a floating static route “floating”?
4. Why must a next hop be resolvable?

**Next:** [OSPFv2 single-area routing](/notes/learning/networking-and-ccna/24-ospfv2-single-area/).
