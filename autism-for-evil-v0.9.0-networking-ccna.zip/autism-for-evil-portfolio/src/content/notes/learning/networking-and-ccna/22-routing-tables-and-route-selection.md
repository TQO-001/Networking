---
title: "Routing Tables and Route Selection"
description: "Understand how routers select a route for a destination and interpret next hops, prefixes, administrative distance and metrics."
order: 22
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "IP routing"
kind: lesson
tags: ["routing", "routing-table", "longest-prefix-match", "administrative-distance", "ccna"]
---

## What routing does

A router forwards IP packets between networks. It consults its routing information to determine which route best matches the destination address. The result identifies an outgoing interface, next hop, or both.

## What a routing entry contains

A route can include:

- Destination network and prefix/mask.
- Next-hop IP address or outgoing interface.
- Route source (connected, static, OSPF or another protocol).
- Administrative distance (AD), where applicable.
- Metric used by the routing protocol to compare paths.

The routing table is not simply a list of every device. It is a set of destination prefixes and forwarding instructions.

## Longest-prefix match

When several routes match a destination, routers prefer the most specific matching prefix. For example, a destination that matches both `10.0.0.0/8` and `10.10.0.0/16` uses the `/16` route because it has more matching network bits.

Administrative distance and metric help choose between routes to the same destination prefix from different sources or within the routing protocol. They do not replace longest-prefix match.

## Common Cisco route codes

| Code | Meaning |
|---|---|
| C | Connected network |
| L | Local interface address (/32 for IPv4) |
| S | Static route |
| O | OSPF-learned route |

The code set depends on enabled protocols and platform. Read the legend shown by the device.

## Example

A router has these entries:

```text
C  10.10.0.0/16 is directly connected, GigabitEthernet0/0
S  10.10.20.0/24 via 192.0.2.2
S* 0.0.0.0/0 via 192.0.2.1
```

A destination in `10.10.20.0/24` uses the more specific `/24` route. A destination elsewhere that has no more-specific match may use the default route, provided the next hop is reachable and the route is installed.

## Verification

```text
show ip route
show ip route 10.10.20.25
show ipv6 route
```

Use the exact destination to ask the router what route it would select. Also verify that the next hop can be resolved/reached on the outgoing link.

## Practical exercise

Create a small table with a default route, a `/8`, a `/16` and a `/24`. For several destination addresses, identify which route wins by longest-prefix match. Explain why the metric is not consulted to choose between different prefix lengths.

## Recall without notes

1. What is a next hop?
2. What is longest-prefix match?
3. How is administrative distance different from a routing metric?
4. What does a default route represent?

**Next:** [Static and default routes](/notes/learning/networking-and-ccna/23-static-and-default-routes/).
