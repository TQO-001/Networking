---
title: "Quality of Service Fundamentals"
description: "Learn why networks classify and prioritise traffic, and how latency, jitter and loss affect real-time applications."
order: 34
minutes: 25
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Network services"
kind: lesson
tags: ["networking", "qos", "latency", "jitter", "supplementary"]
---

## Why QoS exists

Not all traffic has the same performance requirements. A file transfer can often tolerate variable delay; interactive voice and video are more sensitive to delay, jitter and packet loss. Quality of Service (QoS) provides mechanisms for classifying, marking, queuing, policing and shaping traffic.

This is **supporting networking knowledge**, not one of the five weighted domains in the published CCNA v2.0 blueprint. It remains useful operational context, and you should follow the official blueprint for exam scope.

## Performance terms

- **Latency:** time taken for data to travel from source to destination.
- **Jitter:** variation in packet delay.
- **Packet loss:** packets that fail to reach the destination.
- **Throughput:** amount of data successfully delivered over time.
- **Bandwidth:** capacity of a link, not a guarantee of delivered application throughput.

## QoS building blocks

| Mechanism | Purpose |
|---|---|
| Classification | Identify traffic that belongs to a class |
| Marking | Add or use a priority indicator, such as DSCP |
| Queuing/scheduling | Decide which traffic is sent first during congestion |
| Policing | Enforce a rate by dropping or remarking excess traffic |
| Shaping | Buffer traffic to smooth the sending rate |

QoS does not create bandwidth. It manages how limited resources are shared when a link is congested.

## Practical example

A voice call may be placed into a priority queue so that it experiences less delay during congestion. A bulk file transfer can use remaining capacity. The QoS policy must be consistent across the path for end-to-end treatment to be meaningful.

## Exercise

For voice, video meeting, file download and network backup traffic, describe the impact of latency, jitter and loss. Decide which characteristics matter most to each type and explain why.

## Recall without notes

1. What is jitter?
2. How does shaping differ from policing?
3. Why does QoS not create additional bandwidth?
4. Why should QoS be designed end to end?

**Next:** [Secure device management and AAA](/notes/learning/networking-and-ccna/35-secure-device-management-and-aaa/).
