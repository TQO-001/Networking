---
title: "IPsec VPN Fundamentals"
description: "Understand the purpose of IPsec, remote-access and site-to-site VPNs, and transport versus tunnel mode."
order: 38
minutes: 30
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Network security"
kind: lesson
tags: ["networking", "security", "ipsec", "vpn", "ccna"]
---

## Why VPNs exist

A Virtual Private Network (VPN) creates a protected logical connection across an underlying network that may not be trusted. IPsec is a suite of protocols used to protect IP traffic through security services such as confidentiality, integrity, authentication and anti-replay protection.

## Common VPN use cases

- **Site-to-site VPN:** connects networks through security gateways, commonly between offices or a branch and a central site.
- **Remote-access VPN:** gives an individual user a protected connection to an organisation's network using an approved client or access method.

## IPsec building blocks

- **IKE (Internet Key Exchange):** negotiates security associations and keying material.
- **ESP (Encapsulating Security Payload):** provides encryption and can provide integrity/authentication depending on the configuration.
- **Security Association (SA):** defines parameters for protected traffic.
- **Authentication and encryption algorithms:** must be selected according to the supported security policy.

## Transport and tunnel mode

- **Transport mode:** protects the payload of the original IP packet while retaining the original IP header.
- **Tunnel mode:** encapsulates and protects the original IP packet inside a new IP packet. It is common for gateway-to-gateway site-to-site VPNs.

## Things to verify in a VPN design

The two sides need compatible proposals and identities, reachable peer addresses, correct traffic selectors or policies, valid certificates/keys and appropriate routing. Time synchronisation and clear logging also help troubleshooting.

## Troubleshooting mindset

Separate underlay reachability from the VPN itself. First establish that the peers can reach each other over the underlying network. Then check IKE negotiation, security associations, protected traffic selectors, routing and return traffic. A tunnel state alone does not prove every intended application flow works.

## Practical exercise

Draw a branch office and central office connected over an untrusted Internet path. Label the IPsec tunnel endpoints, protected subnets and traffic that should use the tunnel. Explain what happens to packets outside the protected traffic selectors.

## Recall without notes

1. What problem does IPsec solve?
2. How does a site-to-site VPN differ from remote access?
3. What is the difference between transport and tunnel mode?
4. What is the role of IKE?

**Note:** The CCNA v2.0 blueprint asks you to describe IPsec remote-access and site-to-site VPN concepts, including protocols and transport modes.
