---
title: "OSI and TCP/IP Models"
description: "Use layered network models to understand encapsulation, protocols and where a connectivity problem may occur."
order: 3
minutes: 30
level: Beginner
pathId: networking-ccna
module: "Network foundations"
kind: lesson
tags: ["networking", "osi", "tcp-ip", "encapsulation", "troubleshooting", "ccna"]
---

## Why this matters

The OSI and TCP/IP models give engineers a shared way to discuss network functions. They are especially useful for troubleshooting: a cable fault, IP addressing error and application failure are different problems and need different evidence.

## The OSI model

| Layer | Name | What it describes | Examples |
|---:|---|---|---|
| 7 | Application | Network services used by applications | HTTP, DNS, SSH |
| 6 | Presentation | Data representation, encoding and encryption concepts | Character encoding, TLS-related presentation concepts |
| 5 | Session | Dialog/session management concepts | Session establishment and control |
| 4 | Transport | End-to-end application transport | TCP, UDP, ports |
| 3 | Network | Logical addressing and routing | IPv4, IPv6, routers |
| 2 | Data Link | Local frame delivery on a link | Ethernet, MAC addresses, switches |
| 1 | Physical | Signals, media and connectors | Copper, fibre, radio, optics |

The model is a learning and troubleshooting framework. Real protocols do not always fit into one perfectly isolated box.

## TCP/IP model

A common four-layer view is:

| TCP/IP layer | Rough OSI relationship | Main purpose |
|---|---|---|
| Application | OSI 5–7 | Application protocols and data formats |
| Transport | OSI 4 | Process-to-process delivery |
| Internet | OSI 3 | IP addressing and routing |
| Network access / link | OSI 1–2 | Local framing and physical transmission |

Some references use a five-layer teaching model by separating physical and data link. The important thing is understanding the function, not arguing over labels.

## Encapsulation

When an application sends data, each lower layer adds information needed for its part of delivery.

```text
Application data
      ↓ add transport header
TCP segment / UDP datagram
      ↓ add IP header
IP packet
      ↓ add Ethernet header and trailer
Ethernet frame
      ↓ encode as signals
Bits / physical transmission
```

At the receiver, the process is reversed: each layer reads and removes the information it needs, then passes the remaining payload upward. This is decapsulation.

## A web request example

A browser creates application data. TCP may provide reliable transport to the destination port. IP identifies the source and destination hosts. Ethernet carries the packet across the local link to the next hop. A router removes the incoming Layer 2 framing, examines the IP packet, chooses a route, and creates new Layer 2 framing for the next link. The IP packet is forwarded hop by hop, subject to routing and any translation or policy applied along the way.

## How to use the model in troubleshooting

Start low and move upward:

- Layer 1: Is the cable/radio link working? Is the interface up?
- Layer 2: Is the correct VLAN active? Are frames being forwarded?
- Layer 3: Are IP address, mask, gateway and routes correct?
- Layer 4: Is the required TCP/UDP port reachable?
- Layers 5–7: Is the application, name resolution, session or data format working?

A successful ping does not prove that a web application works. It proves only that a particular ICMP exchange succeeded at that time.

## Practical exercise

Take the example of opening an HTTPS website. Identify the role of DNS, TCP, IP and Ethernet in the journey. Then draw the same path from the perspective of one router.

## Recall without notes

1. Which OSI layer is responsible for logical addressing and routing?
2. What is encapsulation?
3. What is the difference between a frame and a packet?
4. Why does a router create new Layer 2 framing for the next link?

**Next:** [Ethernet, frames and MAC addresses](/notes/learning/networking-and-ccna/04-ethernet-frames-and-mac-addresses/).
