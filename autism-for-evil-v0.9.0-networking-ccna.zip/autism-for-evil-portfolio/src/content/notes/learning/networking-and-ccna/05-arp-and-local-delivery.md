---
title: "ARP and Local Delivery"
description: "Understand how an IPv4 host discovers a local destination MAC address and decides whether to use its default gateway."
order: 5
minutes: 25
level: Beginner
pathId: networking-ccna
module: "Network foundations"
kind: lesson
tags: ["networking", "arp", "ipv4", "gateway", "mac-address", "ccna"]
---

## Why this matters

An IPv4 host needs an Ethernet destination MAC address before it can send an Ethernet frame. ARP (Address Resolution Protocol) helps a host discover the MAC address associated with an IPv4 address on the local link.

## Same subnet or remote subnet?

Before sending, a host compares the destination IP address with its own IP address and subnet mask.

- If the destination is on the same subnet, the host resolves the destination host's MAC address with ARP and sends the frame directly.
- If the destination is on another subnet, the host resolves the MAC address of its **default gateway** and sends the frame to the router. The packet's destination IP remains the remote host's IP; the Ethernet destination is the gateway's MAC for that local hop.

## Example

Assume a PC has `192.168.10.25/24` and a default gateway of `192.168.10.1`.

- Destination `192.168.10.40`: same `/24` network, so the PC ARPs for `192.168.10.40`.
- Destination `203.0.113.20`: remote network, so the PC ARPs for `192.168.10.1` and sends the frame to the gateway.

The router then makes its own routing decision and uses the appropriate Layer 2 information on the next link.

## ARP request and reply

An ARP request is normally broadcast on the local Layer 2 network: “Who has this IPv4 address?” The device that owns the address replies with its MAC address. Hosts cache recent mappings so they do not need to ask every time. Cache entries age out or are refreshed.

```text
PC ── ARP request (broadcast): who has 192.168.10.40?
PC ← ARP reply (unicast): 192.168.10.40 is at AA:BB:CC:DD:EE:FF
```

ARP is for IPv4. IPv6 uses Neighbor Discovery Protocol (NDP), which relies on ICMPv6 rather than ARP.

## Useful commands

Windows:

```powershell
arp -a
```

Cisco IOS:

```text
show ip arp
```

These commands show cached mappings. An empty or incomplete entry may be temporary; interpret it alongside interface, VLAN and connectivity evidence.

## Common misunderstanding

The destination IP address and destination MAC address do not have to identify the same device. For a remote destination, the IP destination is the remote host while the Ethernet destination is the local next hop (usually the default gateway).

## Practical exercise

Draw two cases: two PCs in the same `/24`, and a PC contacting a server in a different subnet. Label the source/destination IP and source/destination MAC in each first-hop frame.

## Python connection

Python's `ipaddress` module can help determine whether two IPv4 addresses belong to the same network. It does not perform ARP for you; it helps calculate the addressing decision that a host makes.

## Recall without notes

1. When does a host ARP for the destination itself?
2. When does it ARP for the default gateway?
3. Does a router normally forward an Ethernet broadcast to another subnet?
4. What does IPv6 use instead of ARP?

**Next:** [TCP, UDP, ports and common services](/notes/learning/networking-and-ccna/06-tcp-udp-ports-and-services/).
