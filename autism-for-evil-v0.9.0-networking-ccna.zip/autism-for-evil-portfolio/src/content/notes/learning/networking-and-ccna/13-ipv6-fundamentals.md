---
title: "IPv6 Fundamentals"
description: "Understand 128-bit IPv6 addresses, notation, prefix lengths and the main address types used in modern networks."
order: 13
minutes: 35
level: Beginner
pathId: networking-ccna
module: "IP addressing and subnetting"
kind: lesson
tags: ["networking", "ipv6", "addressing", "ndp", "ccna"]
---

## Why IPv6 exists

IPv6 uses 128-bit addresses, providing a much larger address space than IPv4. It also changes address notation and some network functions. You should be able to read, shorten, classify and verify a basic IPv6 address.

## Address notation

IPv6 addresses use hexadecimal groups separated by colons. A full address has eight groups of four hexadecimal digits:

`2001:0DB8:0000:0000:0000:0000:0000:0025`

Two shortening rules are allowed:

1. Leading zeros in a group may be omitted: `0DB8` becomes `DB8`.
2. One consecutive run of all-zero groups may be replaced by `::` once.

The example becomes `2001:DB8::25`. The double-colon can only appear once because otherwise the original number of omitted groups would be ambiguous.

`2001:DB8::/32` is an example documentation prefix, not a public address plan.

## Prefix length

IPv6 uses CIDR prefix notation, such as `/64`. A `/64` has 64 network-prefix bits and 64 interface-identifier bits. `/64` is common for ordinary LAN subnets, although other prefix lengths appear in routing and allocation contexts.

## Important IPv6 address types

| Type | Typical prefix/example | Purpose |
|---|---|---|
| Global unicast | `2000::/3` | Globally routable unicast space |
| Unique local | `FC00::/7` | Private-like internal addressing |
| Link-local | `FE80::/10` | Communication on a local link; automatically present on IPv6 interfaces |
| Multicast | `FF00::/8` | One-to-many group communication |
| Loopback | `::1/128` | Refers to the local IPv6 stack |
| Unspecified | `::/128` | No address specified |
| Anycast | An address assigned to multiple interfaces | Traffic is delivered to one suitable member of the anycast set |

IPv6 has no broadcast address. Multicast performs functions that broadcast served in IPv4.

## Neighbor discovery

IPv6 uses Neighbor Discovery Protocol (NDP), which relies on ICMPv6 messages, for functions such as discovering neighbours and routers. It is not the same as IPv4 ARP.

## Modified EUI-64

Some IPv6 interface identifiers can be derived from a MAC address using a modified EUI-64 process. This is one possible addressing method, not the only one. Privacy extensions and other interface-identifier methods are also used.

## Practical exercise

Shorten these addresses and identify their type where possible:

- `2001:0DB8:0000:0000:0000:0000:0000:0001`
- `FE80:0000:0000:0000:0200:00FF:FE00:1234`
- `0000:0000:0000:0000:0000:0000:0000:0001`

Then explain why `::` may appear only once in a compressed address.

## Recall without notes

1. How many bits are in an IPv6 address?
2. What do `FE80::/10` addresses indicate?
3. Does IPv6 use broadcast?
4. What protocol family replaces ARP for neighbour discovery?

**Next:** [Verify and troubleshoot host addressing](/notes/learning/networking-and-ccna/14-verify-and-troubleshoot-host-addressing/).
