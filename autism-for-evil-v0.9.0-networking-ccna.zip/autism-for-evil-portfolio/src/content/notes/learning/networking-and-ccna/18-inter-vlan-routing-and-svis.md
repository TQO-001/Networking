---
title: "Inter-VLAN Routing and SVIs"
description: "Understand how Layer 3 interfaces allow devices in different VLANs to communicate, including SVIs and router-on-a-stick."
order: 18
minutes: 40
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Switching and network access"
kind: lesson
tags: ["switching", "inter-vlan-routing", "svi", "layer-3-switch", "ccna"]
---

## Why routing is needed

VLANs separate Layer 2 broadcast domains. A PC in VLAN 10 cannot reach a PC in VLAN 20 using ordinary Layer 2 switching alone. A Layer 3 device must route packets between the VLAN subnets.

## Two common designs

**Router-on-a-stick:** a router connects to a switch through one trunk. The router uses subinterfaces, each associated with a VLAN tag and an IP gateway address.

**Layer 3 switch with SVIs:** a multilayer switch has a Switch Virtual Interface (SVI) for each VLAN that needs a Layer 3 gateway. Routing is performed by the switch.

## SVI concept

An SVI is a logical Layer 3 interface associated with a VLAN, often written as `interface vlan 10`. It provides an IP address that hosts in that VLAN can use as their default gateway. For an SVI to operate, the VLAN and Layer 2 conditions must be present; an SVI that is administratively enabled can still remain down if the VLAN has no suitable active Layer 2 ports.

## Example Layer 3 switch configuration

Use this only in a lab and adapt the interface names and address plan:

```text
configure terminal
vlan 10
 name USERS
vlan 20
 name PRINTERS
!
interface vlan 10
 ip address 192.168.10.1 255.255.255.0
 no shutdown
interface vlan 20
 ip address 192.168.20.1 255.255.255.0
 no shutdown
!
ip routing
end
show ip interface brief
show ip route
```

The switch also needs active Layer 2 ports in the relevant VLANs. Hosts need the correct default gateway for their own subnet.

## Example router-on-a-stick idea

The router interface connects to a switch trunk. Router subinterfaces use VLAN encapsulation and provide a gateway address for each VLAN. The exact commands and interface names are platform-specific; understand the relationship first: one physical router interface carries multiple tagged logical interfaces.

## Common mistakes

- Creating an SVI without creating the VLAN.
- Forgetting to enable routing on a multilayer switch where required.
- Giving a host a gateway from the wrong subnet.
- Forgetting that the switch-to-switch or switch-to-router link must carry the VLAN.
- Treating a VLAN as if it automatically creates a routed subnet and gateway.

## Practical exercise

Build two VLANs with one PC each. Configure the Layer 3 switch SVIs, assign host addresses and gateways, and verify inter-VLAN reachability. Use `show vlan brief`, `show ip interface brief` and `show ip route` to explain each part of the result.

## Python connection

When a device inventory includes VLAN and gateway fields, Python can validate that a gateway address belongs to the intended subnet. This is an extension of the IP-address planning lesson, not a replacement for configuring the SVI correctly.

## Recall without notes

1. What does an SVI represent?
2. Why do hosts in different VLANs need a Layer 3 gateway?
3. What does `ip routing` enable on a suitable multilayer switch?
4. Name two reasons an SVI might not be operational.

**Next:** [Spanning Tree Protocol](/notes/learning/networking-and-ccna/19-spanning-tree-rapid-pvst/).
