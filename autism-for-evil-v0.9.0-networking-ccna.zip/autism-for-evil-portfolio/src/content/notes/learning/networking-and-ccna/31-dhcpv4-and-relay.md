---
title: "DHCPv4 and DHCP Relay"
description: "Understand how DHCP assigns IPv4 configuration, how the DORA exchange works and why relay agents are used across subnets."
order: 31
minutes: 35
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Network services"
kind: lesson
tags: ["networking", "dhcp", "dhcpv4", "relay", "ip-services", "ccna"]
---

## Why DHCP exists

Dynamic Host Configuration Protocol for IPv4 (DHCPv4) automatically provides clients with configuration such as an IP address, subnet mask, default gateway and DNS resolver. It reduces manual configuration and address conflicts when the service is designed correctly.

## DORA exchange

A common initial DHCPv4 exchange is remembered as **DORA**:

1. Discover — client looks for a DHCP server.
2. Offer — server offers an address and options.
3. Request — client requests the offered configuration.
4. Acknowledge — server confirms the lease.

The initial messages use UDP ports 68 (client) and 67 (server). Renewal behaviour later in the lease cycle is different from the initial broadcast exchange.

## Why relay is needed

A DHCP Discover is a local broadcast and routers do not normally forward that Layer 2 broadcast to another subnet. A DHCP relay agent receives the client request and forwards it toward a DHCP server, allowing centralised DHCP services to serve multiple IP networks.

On Cisco IOS, `ip helper-address` is commonly configured on the client-facing Layer 3 interface:

```text
interface vlan 10
 ip address 192.168.10.1 255.255.255.0
 ip helper-address 192.0.2.50
```

The address shown is an example documentation address. Use the actual approved DHCP server address in your lab design.

## Scope and options

A DHCP scope/pool defines which addresses can be leased and which options are supplied. Common options include subnet mask, default router and DNS servers. Reservations, exclusions, lease time and address utilisation should be documented.

## Troubleshooting

- Does the client use DHCP?
- Is the access port in the expected VLAN?
- Does the client receive an offer/lease?
- Is the DHCP pool exhausted or incorrectly scoped?
- Is the relay configured on the correct Layer 3 interface?
- Can the relay reach the DHCP server?
- Are DHCP security features or policies affecting the exchange?

On Cisco equipment, useful checks include `show ip dhcp binding`, `show ip dhcp pool`, `show running-config` for relay settings and `show logging`.

## Practical exercise

Build two VLANs with separate subnets and one central DHCP server. Configure relay on the Layer 3 gateways and obtain a lease from a client in each VLAN. Then remove the relay address in the lab and explain why the remote VLAN client fails to receive a lease.

## Python connection

A Python inventory validator can check that documented DHCP scopes, gateways and VLAN IDs are present and correctly formatted. Do not build a DHCP server as the first automation project; first understand the exchange and the addressing plan.

## Recall without notes

1. What does DORA stand for?
2. Which UDP ports are used by DHCPv4 client and server?
3. Why is a relay agent needed across subnets?
4. Where is `ip helper-address` typically configured?

**Next:** [DNS records and name resolution](/notes/learning/networking-and-ccna/32-dns-records-and-name-resolution/).
