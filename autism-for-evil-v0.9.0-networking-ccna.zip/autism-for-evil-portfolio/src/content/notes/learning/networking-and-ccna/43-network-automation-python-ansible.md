---
title: "Network Automation with Python and Ansible"
description: "Understand where Python, Ansible and configuration management fit, and how to make automation controlled, testable and repeatable."
order: 43
minutes: 40
level: "Beginner → Intermediate"
pathId: networking-ccna
module: "Network automation and programmability"
kind: lesson
tags: ["networking", "automation", "python", "ansible", "configuration-management", "ccna"]
---

## Why automation matters

Network automation helps engineers repeat tasks consistently: build an inventory, validate an address plan, compare configuration data, collect status, generate reports or apply approved changes. The aim is not to remove engineering judgement. It is to reduce avoidable manual repetition and make the process reviewable.

## Python and Ansible have different strengths

| Python | Ansible |
|---|---|
| General-purpose programming language | Automation and configuration-management tool |
| Useful for data validation, APIs, reporting and custom logic | Useful for repeatable tasks across supported devices and systems |
| You define program flow, validation and error handling | Playbooks describe tasks and desired operations |
| Standard library can handle many first projects | Uses modules, inventories, variables and execution controls |

They can be used together. Python may prepare or validate data; Ansible may execute an approved set of tasks. Neither removes the need for change control.

## A safe automation lifecycle

1. Define the task and its impact.
2. Identify the exact approved targets and credentials.
3. Use sample data or a lab first.
4. Validate inputs and expected device/platform compatibility.
5. Run a read-only/check/diff mode where supported.
6. Review the proposed change with another engineer where required.
7. Apply the smallest approved change.
8. Verify results and preserve logs/evidence.
9. Document rollback and failure behaviour.

## Idempotency

An idempotent operation can be run more than once while maintaining the same intended end state. For example, “ensure VLAN 20 exists” should not create a new duplicate VLAN every time. Idempotency is valuable for configuration management, but only when the desired state is correct and the module behaves as expected.

## A first Python integration

Use a local CSV containing fictional device records. Read it, validate that each row has a hostname, role and valid IP address, then write a report of invalid rows. This uses Python programming without sending traffic to any device.

Relevant companion notes:

- [Python network inventory validation](/notes/learning/python-network-engineer-series/01-validate-network-inventory/)
- [IP address planning in Python](/notes/learning/python-network-engineer-series/02-ipaddress-network-planning/)
- [Python for Network Engineers path](/learning-paths/python-for-network-engineers/)

## Practical exercise

Write a five-step automation plan for creating a VLAN on a lab switch. Include pre-checks, target identification, proposed change, verification and rollback. Do not execute against a workplace device.

## Recall without notes

1. What is the difference between Python and Ansible?
2. What does idempotent mean?
3. Why should targets be explicit?
4. What is the purpose of check/diff mode and a rollback plan?

**Next:** [AI-assisted network operations](/notes/learning/networking-and-ccna/44-ai-assisted-network-operations/).
