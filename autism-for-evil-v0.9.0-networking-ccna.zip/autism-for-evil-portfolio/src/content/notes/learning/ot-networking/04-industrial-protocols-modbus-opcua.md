---
title: "Industrial Protocols: Modbus TCP and OPC UA"
description: "Compare Modbus TCP and OPC UA at a conceptual level, including common roles, data models and safe lab learning."
order: 4
minutes: 35
level: "Intermediate"
pathId: ot-networking-extension
module: "Industrial communication"
kind: reference
tags: ["ot", "modbus-tcp", "opc-ua", "industrial-protocols", "python"]
---

## Why industrial protocols matter

An OT network may carry ordinary Ethernet/IP traffic as well as specialised application protocols. Understanding what a protocol is used for helps you read architecture drawings, firewall rules, packet-capture summaries and asset inventories.

## Modbus TCP

Modbus TCP is a client/server industrial communication protocol commonly used to exchange values with devices such as meters, controllers and other equipment. It carries Modbus application messages over TCP/IP. TCP port 502 is the commonly assigned default, but a design must be checked against the actual device and configuration.

The protocol is relatively simple and widely encountered, but security capabilities depend heavily on the surrounding architecture and the versions/extensions in use. Do not assume that reachability means a device is protected or that a read/write operation is appropriate.

## OPC UA

OPC Unified Architecture (OPC UA) is a platform-independent architecture for exchanging industrial information. It provides a richer information model than a simple register map and supports security mechanisms such as authentication and encrypted communication when configured correctly. TCP port 4840 is a common default endpoint, but actual endpoints are configured by the system.

## Conceptual comparison

| Aspect | Modbus TCP | OPC UA |
|---|---|---|
| Common role | Simple register/value exchange | Structured industrial information exchange |
| Data model | Coils and registers in a protocol data model | Address space with nodes, types and relationships |
| Common default port | TCP 502 | TCP 4840 for common UA TCP endpoint |
| Security | Often relies on network segmentation and additional controls | Includes built-in security capabilities, which must be configured correctly |

## Safe way to learn

Use an isolated simulator or sample project. Start by reading documentation and sample data. If a lab provides a read-only monitor, understand exactly which nodes/registers it reads and what it logs. Do not test protocol clients against live controllers or production devices without explicit approval and a defined procedure.

## Python connection

Your Python for Network Engineers material includes read-only OPC UA and Modbus monitor exercises for simulators. Use those after you understand the protocol purpose and the site safety boundary:

- [Read-only OPC UA monitor](/notes/learning/python-network-engineer-series/11-opcua-read-only-monitor/)
- [Read-only Modbus TCP monitor](/notes/learning/python-network-engineer-series/12-modbus-read-only-monitor/)

## Recall without notes

1. What type of data model does Modbus commonly expose?
2. What is OPC UA designed to provide?
3. Why is a common port number not proof of the endpoint configuration?
4. Why should first protocol practice use an isolated simulator?
