---
title: "Industrial Network Architecture"
description: "Recognise common industrial network components and understand how redundancy, managed switching and monitoring fit into the architecture."
order: 3
minutes: 30
level: "Intermediate"
pathId: ot-networking-extension
module: "Segmentation and architecture"
kind: reference
tags: ["ot", "architecture", "purdue", "industrial-ethernet", "redundancy"]
---

## Common industrial network components

An industrial network may include engineering workstations, operator stations, supervisory servers, historians, controllers, remote I/O, drives, sensors, managed switches, fibre links, firewalls, remote-access gateways and monitoring systems. The exact architecture depends on the process and vendor ecosystem.

## Levels and layers

The Purdue Enterprise Reference Architecture is often used as a conceptual way to discuss industrial system layers, from physical process and basic control through supervisory operations and enterprise systems. It is a model for reasoning and communication—not a universal blueprint that every modern site follows exactly.

A modern architecture may include virtualisation, industrial DMZs, cloud-connected services and security monitoring while still preserving strong boundaries around control functions.

## Why redundancy needs engineering

Redundant links, ring topologies, redundant power and resilient devices can improve availability. But redundancy protocols and failover behaviour must be supported by the equipment and designed for the process. A redundant path that creates a Layer 2 loop or unexpected failover can be harmful.

## Documentation should show

- Device role and asset identifier.
- Network/interface and approved address information.
- Switch and port relationships where documented.
- VLAN/subnet and security zone.
- Upstream and downstream dependencies.
- Redundant path and failover design.
- Data owner, source and timestamp of the record.

## Practical exercise

Using a fictional plant diagram, identify the controller network, operator network, historian, engineering workstation, firewall boundary and redundant fibre links. Label which items are physical and which are logical.

## Recall without notes

1. What does a historian commonly do?
2. Why should redundancy be documented?
3. What is the Purdue model used for?
4. Why is a model not a substitute for the actual site architecture?

**Next:** [Industrial protocols: Modbus TCP and OPC UA](/notes/learning/ot-networking/04-industrial-protocols-modbus-opcua/).
