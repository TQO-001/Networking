---
title: "Zones, Conduits and Segmentation"
description: "Understand how industrial environments group assets into security zones and define controlled communication paths between them."
order: 2
minutes: 30
level: "Intermediate"
pathId: ot-networking-extension
module: "Segmentation and architecture"
kind: reference
tags: ["ot", "segmentation", "zones", "conduits", "industrial-dmz"]
---

## Why segmentation matters

Segmentation divides a network into smaller areas with defined communication rules. In an industrial environment, segmentation helps reduce unnecessary connectivity between business systems, supervisory systems, control systems and external connections.

VLANs and IP subnets can contribute to segmentation, but they do not by themselves enforce every security requirement. Routing, firewalls, access controls, monitoring and operational procedures all play a role.

## Zones and conduits

A **zone** is a grouping of assets that share security requirements or operational characteristics. A **conduit** is the controlled communication path between zones. This language is associated with industrial cybersecurity architecture and IEC 62443 concepts.

```text
Enterprise IT zone
       │
  Controlled conduit
       │
Industrial DMZ zone
       │
  Controlled conduit
       │
Supervisory / SCADA zone
       │
  Controlled conduit
       │
Controller / cell-area zone
```

The diagram is conceptual. Actual site architecture should be designed from process, risk, vendor and safety requirements.

## Industrial DMZ

An Industrial DMZ is commonly used as a buffer between enterprise IT and industrial control environments. Services such as approved data historians, jump services, update staging or data brokers may be placed there according to the architecture. It should not become an unrestricted bridge between IT and OT.

## Connect this to CCNA knowledge

The concepts build on VLANs, subnets, routing, ACLs and firewalls. A VLAN creates a Layer 2 broadcast domain. A firewall or routed policy can control traffic between zones. The security design should specify which source, destination, protocol and purpose are permitted.

## Practical exercise

Use a fictional plant with enterprise IT, an industrial DMZ, supervisory systems and controller cells. Draw the zones and conduits. For each conduit, write the business/operational purpose and identify who would approve its rules.

## Safety note

Do not discover or test real production paths yourself. Use architecture documents and approved sample data. Any validation of production communication paths must follow site authorisation and change-control requirements.

## Recall without notes

1. What is a security zone?
2. What is a conduit?
3. Why is an Industrial DMZ useful?
4. Why is a VLAN alone not a complete security boundary?

**Next:** [Industrial network architecture](/notes/learning/ot-networking/03-industrial-network-architecture/).
