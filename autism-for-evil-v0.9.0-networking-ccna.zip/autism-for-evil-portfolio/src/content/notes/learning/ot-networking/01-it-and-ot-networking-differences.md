---
title: "IT and OT Networking Differences"
description: "Compare enterprise IT and operational technology networks, focusing on availability, lifecycle, safety and change control."
order: 1
minutes: 25
level: "Beginner → Intermediate"
pathId: ot-networking-extension
module: "OT foundations"
kind: reference
tags: ["ot", "it-ot", "availability", "change-control"]
---

## IT and OT are different operating environments

Information Technology (IT) networks commonly support business applications, collaboration, user access and data services. Operational Technology (OT) networks support systems that monitor or influence physical processes, such as manufacturing, utilities, building systems and industrial control.

The technologies can overlap, but the priorities and consequences of change may differ.

## Typical differences

| Consideration | Enterprise IT tendency | OT environment consideration |
|---|---|---|
| Primary concern | Confidentiality, integrity and availability | Safety, availability, integrity and predictable operation |
| Change frequency | Often more frequent | May be constrained by production windows and vendor lifecycle |
| Asset lifecycle | Regular refresh cycles are common | Equipment may remain in service for many years |
| Downtime | Disrupts users and business services | Can disrupt physical processes or create safety/production consequences |
| Protocols | Broad mix of enterprise protocols | May include specialised industrial protocols alongside standard IP |
| Ownership | IT operations and service teams | Engineering, operations, control-system vendors and IT/security may share responsibilities |

These are tendencies, not absolute rules. Each site has its own requirements and governance.

## Why an IT-style approach may not transfer directly

A seemingly harmless scan, reboot, configuration change or software update can have different effects on a legacy controller, remote I/O device or industrial switch. Some equipment has limited resources, strict timing expectations or vendor-specific operating requirements. The fact that a device responds to a network packet does not mean it is safe to test further.

## How to approach an OT network as an engineer

- Learn the process and ownership before touching the network.
- Understand which systems are safety-related or production-critical.
- Use approved drawings, asset registers and maintenance records.
- Confirm whether an action is read-only or changes device state.
- Follow site access, change-control and incident procedures.
- Escalate uncertainty to the responsible engineer or system owner.

## Practical exercise

Choose a fictional water-treatment, packaging or building-management site. List five devices and classify their role, owner, operational impact and whether a network change should require formal approval. Do not use real site asset details.

## Recall without notes

1. Why can downtime have different consequences in OT?
2. Why might older industrial devices have longer lifecycles?
3. Why is “it responds to ping” not permission to probe it further?
4. What should happen before a production change?

**Next:** [Zones, conduits and segmentation](/notes/learning/ot-networking/02-zones-conduits-and-segmentation/).
