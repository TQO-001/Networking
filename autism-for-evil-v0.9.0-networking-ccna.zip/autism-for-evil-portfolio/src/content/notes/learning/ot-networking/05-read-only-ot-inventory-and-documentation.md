---
title: "Read-Only OT Inventory and Documentation"
description: "Design a safe inventory and reporting workflow from approved records or fictional data, preserving data provenance and avoiding active probing."
order: 5
minutes: 35
level: "Intermediate"
pathId: ot-networking-extension
module: "Safe operations and documentation"
kind: project
tags: ["ot", "inventory", "documentation", "python", "read-only", "safety"]
---

## Why asset documentation matters

A useful OT inventory answers: what assets exist, what role do they perform, where are they located, who owns them, how are they connected and where did the information come from? Incomplete or stale records make troubleshooting, maintenance and security planning harder.

## A simple inventory schema

| Field | Example value (fictional) |
|---|---|
| Asset ID | `OT-PLC-001` |
| Hostname | `line1-controller` |
| Role | Controller |
| Zone | Cell-area zone |
| IPv4 | `192.0.2.40` |
| VLAN | `120` |
| Switch/port | `SW-LAB-01 / Gi0/8` |
| Protocol notes | Modbus TCP client/server role documented |
| Source | Approved asset register |
| Last verified | Date/time from the approved record |

Do not copy customer identifiers, real IP inventories, credentials, full network diagrams or unredacted logs into public repositories.

## Read-only means more than “I did not change a setting”

A safe workflow begins from approved records or an explicitly authorised data source. It does not automatically probe addresses to discover assets. It records the source, timestamp and confidence of each field so engineers know whether the information is current and verified.

## Python connection

Use CSV or JSON sample data. A Python script can:

1. Validate required fields.
2. Parse and validate IP addresses.
3. Check that VLAN IDs are in the intended range.
4. Detect duplicate asset IDs or hostnames.
5. Report missing source/timestamp information.
6. Produce a human-readable summary.

This work is a natural extension of [Python network inventory validation](/notes/learning/python-network-engineer-series/01-validate-network-inventory/).

## Practical exercise

Create five fictional asset records with different roles. Add one deliberate error (duplicate hostname, invalid IP or missing data source). Write down what a validator should flag and why. Do not connect to any real industrial device.

## Completion standard

A good inventory report is accurate, traceable, clear about unknown values and safe to share with its intended audience. It does not imply that an asset was actively checked unless an approved check actually occurred.
