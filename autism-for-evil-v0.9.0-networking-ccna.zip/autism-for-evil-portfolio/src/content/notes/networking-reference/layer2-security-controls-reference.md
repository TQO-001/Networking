---
title: "Layer 2 Security Controls Reference"
description: "A compact comparison of port security, DHCP snooping, Dynamic ARP Inspection, storm control and RA Guard."
minutes: 10
level: "Reference"
kind: reference
tags: ["networking", "layer2-security", "port-security", "dhcp-snooping", "dai"]
---

## Controls at a glance

| Control | Main purpose | Design dependency |
|---|---|---|
| Port security | Limit MAC addresses on an access port | Endpoint count and endpoint type |
| DHCP snooping | Restrict DHCP server replies to trusted paths and build bindings | Correct trusted uplink identification; static hosts need consideration |
| Dynamic ARP Inspection | Validate ARP messages using trusted binding information | DHCP snooping bindings or other approved validation method |
| Storm control | Limit excessive broadcast, multicast or unknown unicast traffic | Thresholds must match expected traffic |
| RA Guard | Control IPv6 Router Advertisements on a Layer 2 segment | Correct identification of legitimate router ports |

## Change planning

Map the topology and endpoint roles first. Test on a simulator or isolated lab. Confirm how the feature behaves on the actual platform/software release. Define rollback and monitor logs/counters after an approved change.

A misapplied trust setting or overly restrictive port-security limit can interrupt legitimate communications. Do not enable features on production ports as an experiment.
