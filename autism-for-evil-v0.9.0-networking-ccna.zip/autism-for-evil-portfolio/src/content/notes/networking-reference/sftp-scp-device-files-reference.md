---
title: "SFTP and SCP Device File Operations"
description: "A reference checklist for transferring network-device configuration and software files securely."
minutes: 10
level: "Reference"
kind: reference
tags: ["networking", "sftp", "scp", "secure-file-transfer", "operations"]
---

## Protocols

- SFTP performs file operations over an SSH connection.
- SCP copies files using SSH transport.
- FTP and TFTP do not provide the same transport confidentiality as SSH-based file transfer.

## Before a transfer

- Confirm device, file, destination and approval.
- Verify compatibility and available storage.
- Use an approved secure transfer host.
- Use least-privilege accounts and verify the host identity.
- Validate the transfer with a checksum or platform-supported verification.
- Store the backup securely; device configurations can contain sensitive information.

## After a transfer

Record the file, source, destination, operator, timestamp, change reference and verification result. A secure transport does not protect a file after it has been placed in an overly broad or unprotected storage location.
