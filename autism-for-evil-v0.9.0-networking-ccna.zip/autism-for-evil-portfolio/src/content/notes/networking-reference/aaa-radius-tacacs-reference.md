---
title: "AAA, RADIUS and TACACS+ Reference"
description: "A compact reference for local device authentication and centralised AAA concepts."
minutes: 10
level: "Reference"
kind: reference
tags: ["networking", "aaa", "radius", "tacacs", "security"]
---

## AAA reminder

- Authentication verifies identity.
- Authorisation determines permitted actions.
- Accounting records sessions or actions.

## Protocol comparison

| Feature | RADIUS | TACACS+ |
|---|---|---|
| Common transport | UDP | TCP |
| Common ports | 1812 authentication, 1813 accounting | TCP 49 |
| Typical use | Network access authentication | Administrative access to network devices |
| Protocol design | Traditionally combines authentication and authorisation behaviours | Separates authentication, authorisation and accounting more distinctly |

## Design checklist

- Use approved identity sources and unique accounts.
- Protect shared secrets and certificates.
- Apply least privilege.
- Configure a tested and policy-approved fallback method.
- Monitor failed authentication and account changes.
- Ensure time synchronisation so accounting and log events can be correlated.

Do not put real shared secrets, passwords or tokens in this note or a public repository.
