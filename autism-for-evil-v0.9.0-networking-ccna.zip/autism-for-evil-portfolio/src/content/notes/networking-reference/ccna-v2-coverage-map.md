---
title: "CCNA 200-301 v2.0 Coverage Map"
description: "A reference mapping of the Networking & CCNA learning path to Cisco’s published 200-301 v2.0 exam domains."
minutes: 12
level: "Reference"
kind: reference
tags: ["ccna", "exam-blueprint", "v2.0", "cisco", "exam-preparation"]
---

## Exam version reminder

Cisco's published transition dates are:

- Current 200-301 v1.1: last test date **2 February 2027**.
- Refreshed 200-301 v2.0: first test date **3 February 2027**.

Use the blueprint matching your actual exam date. Do not assume every course or third-party checklist has been updated.

## Published v2.0 domain weights and where to study

| Domain | Weight | Main notes in this path |
|---|---:|---|
| 1.0 Network Infrastructure and Connectivity | 25% | NET-08–14 (addressing and client configuration), NET-28 (physical links), NET-29 (wireless), NET-30 (virtualisation), NET-31 (DHCPv4 client/server/relay) |
| 2.0 Switching and Network Access | 25% | NET-04 (Ethernet foundation), NET-07 (verification tools), NET-15–21 (switching, VLANs, trunks, SVIs, LACP, discovery and Rapid PVST+); NET-27 (end-to-end troubleshooting) |
| 3.0 IP Routing | 20% | NET-22–27 (route selection, static routes, OSPFv2/v3, first-hop redundancy and path troubleshooting) |
| 4.0 Network Services and Security | 20% | NET-32–33 and NET-35–39 (DNS, NAT/PAT, AAA, SFTP/SCP, ACLs, IPsec and Layer 2 security) |
| 5.0 AI, and Network Operations and Management | 10% | NET-40–44 (monitoring, management approaches, APIs and data, automation, AI-assisted operations) |

The path is ordered for learning, not to mirror the exam domains. Some foundational notes support more than one exam objective. NET-34 (QoS fundamentals) is supplementary context and is **not listed as a separate v2.0 objective** in Cisco's current blueprint.

## Official sources

- [Cisco 200-301 CCNA v2.0 Exam Topics PDF](https://learningcontent.cisco.com/documents/marketing/exam-topics/200-301_CCNA_v2.0_Exam_Topics_PDF.pdf)
- [Cisco: Stay on Track Before the CCNA Refresh](https://blogs.cisco.com/learning/stay-on-track-get-certified-before-the-ccna-refresh)
- [Cisco 200-301 CCNA certification page](https://www.cisco.com/site/us/en/learn/training-certifications/exams/ccna.html)

## Important coverage reminders

The current v2.0 blueprint specifically includes physical interface and cable diagnosis; hypervisors, virtual machines and containers; IPv4/IPv6 client troubleshooting; wireless; DHCPv4 client, server and relay; switch-to-switch and switch-to-router connectivity; Layer 2/Layer 3 interfaces, trunks, LACP, SVIs, PoE and edge-host connectivity; CDP/LLDP; show commands, logs, ping, extended ping, traceroute and packet-capture output; Rapid PVST+ including port roles and protections; IPv4/IPv6 static routing; single-area OSPFv2/v3; HSRP/VRRP; local usernames and AAA using TACACS+/RADIUS; SFTP/SCP; NAT/PAT; DNS records; IPsec VPNs; IPv4 ACLs; Layer 2 protections; AI for network operations; network-management approaches; SNMP; Ansible; and syslog.

Use the official PDF itself as your final coverage checklist before the exam. The mapping above helps you navigate your notes; it does not replace Cisco's objective wording.
