---
title: "IPsec VPN Reference"
description: "A compact reminder of IPsec, IKE, ESP, security associations and the distinction between remote-access and site-to-site VPNs."
minutes: 10
level: "Reference"
kind: reference
tags: ["networking", "ipsec", "vpn", "security"]
---

## Core terms

- **IPsec:** a suite of protocols that protects IP traffic.
- **IKE:** negotiates peers, security associations and keying material.
- **ESP:** provides encapsulation and security services such as confidentiality and integrity/authentication depending on configuration.
- **Security Association:** the parameters used to protect traffic.
- **Transport mode:** protects the original packet payload while retaining the original IP header.
- **Tunnel mode:** encapsulates the original IP packet inside a new IP packet.

## Common designs

- Site-to-site: security gateways protect traffic between networks.
- Remote-access: a user endpoint establishes a protected connection to an organisation.

## Troubleshooting order

1. Verify underlay reachability between VPN peers.
2. Check IKE negotiation and peer identity.
3. Check security association state and proposals.
4. Check traffic selectors, routes and security policy.
5. Test the actual application path and return traffic.

A tunnel being established does not guarantee that every intended flow is permitted or routed correctly.
