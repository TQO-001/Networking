---
title: "Tech Stack & Learning Roadmap (original note)"
description: "A preserved snapshot of the technologies and portfolio milestones in the original Notes repository. Treat this as a historical roadmap, not a list of tools that must all be learned at once."
section: "Project planning & roadmap"
level: "Reference"
sourcePath: "https://github.com/TQO-001/Notes/blob/main/Tech%20Stack.md"
tags: ["roadmap", "technology-stack", "development", "portfolio", "cloud", "testing"]
---

# Tech Stack & Learning Roadmap

> This page preserves the intent of the original roadmap in your GitHub Notes repository. It is a snapshot of planned technologies, not a commitment to learn every tool or a statement that every item is currently in use.

**Original source:** [TQO-001/Notes — Tech Stack.md](https://github.com/TQO-001/Notes/blob/main/Tech%20Stack.md)

## Core languages and frameworks in the original roadmap

- HTML and CSS
- JavaScript and Python
- C++ with wxWidgets
- C# with .NET / ASP.NET
- SQL Server and PostgreSQL
- React for web and React Native for mobile
- Tailwind CSS and Node.js
- MongoDB and FastAPI
- Azure cloud services

## Databases and data access

The original roadmap prioritised relational databases, especially PostgreSQL and SQL Server, and listed SQLAlchemy for Python and Entity Framework Core for C#. MongoDB and Redis appeared as optional NoSQL and caching technologies.

## Testing and quality

The roadmap listed pytest for Python, NUnit / xUnit for C#, and Jest with React Testing Library for frontend work. The current Autism For Evil course stack uses pytest for Python and will teach frontend testing in the React project track when those lessons are introduced.

## Version control and delivery

- Git command-line proficiency
- GitHub and GitLab workflows
- GitHub Actions and GitLab CI
- Jenkins as an optional CI/CD tool

The Foundational Knowledge course now expands this topic into repository structure, staging, commits, commit-message conventions, branches, pull requests, code review and safe recovery.

## Cloud, DevOps and operations

The original roadmap named Azure as the priority cloud platform, with AWS and Google Cloud as future areas. It also listed Docker, Kubernetes fundamentals, cloud monitoring, Datadog and the ELK stack.

## Authentication and security

The original plan included OAuth2 and JWT-based authentication for web, mobile and API applications. The developer learning path should first establish HTTP, secure session concepts, validation, secrets handling and authorization boundaries before building a complete authentication flow.

## Collaboration and project management

The original notes listed Jira / Trello, Slack / Discord, GitHub Issues and Pull Requests. These are tools for supporting collaboration; the underlying skills are breaking work into reviewable tasks, communicating decisions and keeping a traceable history.

## How to use this roadmap today

Do not treat this as a checklist to learn all at once. The current course architecture intentionally prioritises:

1. Shared engineering foundations, including SDLC, requirements, algorithms, database design and Git.
2. Shared Python foundations, then a choice between developer and network-engineering specialisations.
3. PostgreSQL and relational design where projects need persistent data.
4. React + FastAPI for the interactive Python engineering tools.
5. Cloud, deployment, CI/CD and advanced security after the core applications are understood and tested.

The point of a roadmap is to give direction. Revisit it as your work and priorities change.
