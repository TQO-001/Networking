---
title: "Repository layout and .gitignore reference"
description: "A practical structure for Python, React and full-stack repositories, including what should and should not be committed."
section: "Repository structure"
level: "Beginner"
sourcePath: "Autism For Evil Git reference notes"
tags: ["gitignore", "project-structure", "python", "react", "monorepo"]
---

## Recommended Python package layout

```text
project/
├── README.md
├── pyproject.toml
├── uv.lock
├── .gitignore
├── docs/
├── src/package_name/
└── tests/
```

## Recommended full-stack layout

```text
project/
├── README.md
├── docs/
├── backend/
│   ├── pyproject.toml
│   ├── uv.lock
│   ├── src/app_name/
│   └── tests/
└── frontend/
    ├── package.json
    ├── package-lock.json
    └── src/
```

A monorepo can be useful when frontend and backend changes are reviewed and released together. Separate repositories can be better when projects have independent ownership, access rules or release schedules.

## Example .gitignore

```gitignore
# Python
.venv/
__pycache__/
*.py[cod]
.pytest_cache/
.ruff_cache/

# Node
node_modules/
dist/

# Local secrets
.env
.env.*
!.env.example

# Editor and OS
.idea/
.vscode/
.DS_Store
Thumbs.db
```

Adjust for your stack. Commit lockfiles so other contributors can reproduce dependency resolution. Do not ignore required scripts, migrations or source files.

## Files to keep out of public history

Never commit passwords, API tokens, private keys, real environment files, production device configs, private IP inventories, unredacted logs, personal data or confidential screenshots. Use fictional sample data and environment-variable names in `.env.example`.

`.gitignore` only affects untracked files. If a secret was committed, adding it to `.gitignore` does not remove it from history. Revoke or rotate the secret immediately and follow the incident process.

## Before the first commit

```bash
git status
git diff --check
git add README.md .gitignore
git diff --cached
git commit -m "chore: initialise project structure"
```
