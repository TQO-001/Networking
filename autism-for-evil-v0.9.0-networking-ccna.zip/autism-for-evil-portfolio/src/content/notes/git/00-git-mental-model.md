---
title: "Git mental model: working tree, index, commits and remotes"
description: "A plain-language reference to Git’s core objects and the everyday development cycle."
section: "Git fundamentals"
level: "Beginner"
sourcePath: "Autism For Evil Git reference notes"
tags: ["git", "working-tree", "index", "commit", "remote"]
---

## Git versus GitHub

Git is distributed version control running locally. GitHub is a hosting and collaboration platform. A local commit exists in your repository whether or not it has been pushed to GitHub.

## The three local areas

| Area | What it contains |
|---|---|
| Working tree | Files as they currently appear on disk |
| Staging area/index | The exact content selected for the next commit |
| Repository | Recorded commits and references |

Typical flow:

```text
Edit files → inspect diff → stage selected changes → inspect staged diff → commit
```

A push transfers commits to a remote. A pull request proposes integrating a branch and provides a place for review.

## Core vocabulary

- **Repository:** project files plus Git history and metadata.
- **Commit:** a recorded snapshot with parent history and a message.
- **Branch:** a movable name pointing to a commit.
- **Tag:** a named reference often used to identify releases.
- **Remote:** a named reference to another repository.
- **Merge:** combines histories.
- **Rebase:** replays commits onto a new base and rewrites commit identities.

## Useful inspection commands

```bash
git status
git log --oneline --graph --decorate --all
git diff
git diff --cached
git show --stat HEAD
git remote -v
```

Read the output before changing state. `git status` is the best first command when unsure what is happening.

## Important distinction

Git does not automatically track every file. Untracked and ignored files are not part of a commit. A commit records only what is staged at that moment.
