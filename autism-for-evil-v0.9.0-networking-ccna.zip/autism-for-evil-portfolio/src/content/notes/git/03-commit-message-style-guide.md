---
title: "Commit message style guide with examples"
description: "Use meaningful Conventional Commit subjects, scopes, bodies and breaking-change notes."
section: "Git and collaboration"
level: "Beginner"
sourcePath: "Autism For Evil Git reference notes"
tags: ["commit-messages", "conventional-commits", "code-review"]
---

## Recommended format

```text
<type>[optional scope]: <short imperative summary>

[why the change was needed, important details or trade-offs]

[issue reference or breaking-change footer]
```

## Types

| Type | Meaning | Example |
|---|---|---|
| `feat` | New capability | `feat(inventory): add CSV preview` |
| `fix` | Bug fix | `fix(parser): handle empty files` |
| `docs` | Documentation | `docs(git): explain branch workflow` |
| `test` | Tests | `test(api): cover invalid CIDR input` |
| `refactor` | Behaviour-preserving restructuring | `refactor(validation): split address checks` |
| `perf` | Performance improvement | `perf(search): index asset identifiers` |
| `build` | Build/dependency system | `build: update frontend tooling` |
| `ci` | CI pipeline | `ci: run backend tests on pull requests` |
| `chore` | Maintenance | `chore: add editor settings example` |
| `revert` | Undo prior commit | `revert: remove unsafe import behaviour` |

## Subject line rules

- Use imperative wording: `Add`, `Fix`, `Document`, `Remove`.
- Explain what changed, not “updates” or “done”.
- Keep it concise; many projects target 50–72 characters.
- Avoid a trailing full stop by convention.
- Add a scope when it clarifies the affected subsystem.

## Examples from network and software projects

```text
feat(subnet): display usable IPv4 host range
fix(api): return validation details for malformed input
docs(ot): clarify that protocol examples use a simulator
test(inventory): cover duplicate asset tags
refactor(database): isolate connection configuration
ci: run Ruff and pytest on pull requests
```

## When to add a body

Use the body to explain why a decision was made, a trade-off, a migration requirement or a limitation. Do not repeat the diff line-by-line.

```text
fix(import): validate the full file before saving rows

Prevent a malformed upload from leaving the asset register
partially updated. Rejected files now leave stored records
unchanged and return row-level validation details.

Refs: FND-IMPORT-03
```

## Breaking changes

A breaking change requires users or dependent code to adapt. Example:

```text
feat(api)!: rename device_id response field

BREAKING CHANGE: clients must read `asset_id` instead of
`device_id` from the asset response.
```

Do not place secrets, production identifiers or confidential incident details in commit messages. Commit messages are retained in history and may be sent to remotes.
