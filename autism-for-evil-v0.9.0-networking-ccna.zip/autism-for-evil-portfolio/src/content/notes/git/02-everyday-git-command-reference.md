---
title: "Everyday Git command reference"
description: "Commands for checking status, staging, committing, inspecting history and working with remotes."
section: "Git commands"
level: "Beginner"
sourcePath: "Autism For Evil Git reference notes"
tags: ["git-status", "git-add", "git-commit", "git-log", "git-diff"]
---

## Inspect current state

```bash
git status
git diff
git diff --cached
git log --oneline --max-count=10
git show --stat HEAD
```

## Stage and commit deliberately

```bash
git add README.md
git add src/package/module.py tests/test_module.py
git diff --cached
git commit -m "feat(validation): reject duplicate asset IDs"
```

Use explicit paths when you want a focused commit. `git add .` stages all eligible changes under the current directory; only use it after inspecting the entire working tree.

## Branches

```bash
git branch
git switch main
git switch -c feat/asset-search
git branch -d feat/asset-search
```

## Remotes

```bash
git remote -v
git fetch origin
git pull --ff-only
git push -u origin feat/asset-search
```

The exact pull/merge strategy may be set by your team. `--ff-only` refuses to create a merge commit during pull when a fast-forward is not possible.

## Useful hygiene

```bash
git diff --check
git status --short
git log --oneline --graph --decorate --all
```

Never copy destructive commands from a snippet without understanding their impact. Check the status first and protect work that matters.
