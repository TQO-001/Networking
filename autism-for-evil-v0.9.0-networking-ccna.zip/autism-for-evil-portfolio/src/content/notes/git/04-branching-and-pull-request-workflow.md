---
title: "Branching and pull-request workflow"
description: "A simple feature-branch workflow with code review and safe integration."
section: "Git and collaboration"
level: "Beginner"
sourcePath: "Autism For Evil Git reference notes"
tags: ["branches", "pull-requests", "review", "merge"]
---

## A lightweight team workflow

1. Update the base branch.
2. Create a branch with a clear name.
3. Make one coherent change.
4. Run tests and inspect the diff.
5. Push the branch.
6. Open a pull request.
7. Respond to review and CI feedback.
8. Merge using the team's chosen strategy.
9. Delete the merged branch when no longer needed.

## Example

```bash
git switch main
git pull --ff-only
git switch -c feat/asset-import-preview
# edit files, run tests and commit
git push -u origin feat/asset-import-preview
```

## Pull request description

A useful PR explains:

- Purpose and user impact.
- Requirements or issue addressed.
- Important design choices.
- Commands/tests run and their results.
- Screenshots or sample output, where useful.
- Risks, limitations and migration steps.

## Reviewing code

Review correctness, requirements, error handling, security, performance, readability, testing and documentation. Ask specific questions. A review is about the change, not the author's worth.

## Network and OT repository caution

Do not put real device configuration dumps, credentials, production topology details or unredacted logs into a public pull request. Use approved sanitised examples and follow your organisation's source-control policy.
