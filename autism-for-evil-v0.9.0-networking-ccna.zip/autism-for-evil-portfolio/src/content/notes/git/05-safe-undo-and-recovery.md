---
title: "Safe undo and Git recovery reference"
description: "Know when to restore, revert, reset, stash and use reflog; understand destructive operations first."
section: "Git recovery"
level: "Beginner"
sourcePath: "Autism For Evil Git reference notes"
tags: ["git-restore", "git-revert", "git-reset", "git-stash", "reflog"]
---

## Start with inspection

```bash
git status
git diff
git diff --cached
git log --oneline --decorate -8
```

If you are unsure, stop and create a backup or temporary branch before altering history.

## Common recovery actions

| Command | Typical purpose | Important caution |
|---|---|---|
| `git restore file` | Discard unstaged edits to a file | Local edits are lost |
| `git restore --staged file` | Unstage but keep working edits | Inspect afterward |
| `git revert <commit>` | Add a commit that reverses an earlier commit | May itself conflict |
| `git reset --soft <commit>` | Move branch pointer, keep index/worktree | Rewrites local history |
| `git reset --mixed <commit>` | Move branch pointer, reset index, keep worktree | Changes staging state |
| `git reset --hard <commit>` | Move pointer and discard tracked changes | Destructive; avoid casual use |
| `git stash push -m "message"` | Temporarily shelve work | Not a durable backup |
| `git reflog` | Inspect recent local reference movements | Local recovery aid, not a remote backup |

## Shared history

For commits already pushed and used by others, `git revert` is generally safer than rewriting the branch history. Avoid force-pushing shared branches unless the team has explicitly coordinated it. When a force update is required, understand `--force-with-lease` and the branch policy.

## Merge conflicts

Open every conflicted file, inspect both versions and decide the intended final content. Remove conflict markers only after making that decision. Run tests, stage the resolved file and complete the merge/rebase using the appropriate command.

Do not choose “ours” or “theirs” automatically without understanding the change.
