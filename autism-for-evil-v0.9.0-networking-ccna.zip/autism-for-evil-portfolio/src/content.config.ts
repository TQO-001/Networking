import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

/**
 * Every learning item lives in one Notes collection. A note may optionally
 * belong to a Learning Path; paths only organise these notes into a sequence.
 */
const notes = defineCollection({
  loader: glob({ base: './src/content/notes', pattern: '**/*.md' }),
  schema: z.object({
    title: z.string(),
    description: z.string(),
    order: z.number().optional(),
    minutes: z.number().default(10),
    level: z.string().default('Reference'),
    pathId: z.string().optional(),
    module: z.string().optional(),
    kind: z.enum(['lesson', 'guide', 'project', 'reference']).default('reference'),
    section: z.string().optional(),
    sourcePath: z.string().optional(),
    tags: z.array(z.string()).default([]),
  }),
});

const articles = defineCollection({
  loader: glob({ base: './src/content/articles', pattern: '**/*.md' }),
  schema: z.object({
    title: z.string(),
    description: z.string(),
    date: z.string(),
    tags: z.array(z.string()).default([]),
    status: z.enum(['published', 'draft']).default('draft'),
    featured: z.boolean().default(false),
  }),
});

const projects = defineCollection({
  loader: glob({ base: './src/content/projects', pattern: '**/*.md' }),
  schema: z.object({
    title: z.string(),
    description: z.string(),
    order: z.number(),
    stage: z.string(),
    status: z.enum(['brief', 'in-progress', 'complete']).default('brief'),
    technologies: z.array(z.string()).default([]),
    tags: z.array(z.string()).default([]),
  }),
});

export const collections = { notes, articles, projects };
