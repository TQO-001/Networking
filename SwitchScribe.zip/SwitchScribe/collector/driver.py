from __future__ import annotations

import re
import socket
import time
from typing import Any

from netmiko import ConnectHandler

from .commands import commands_for


def _collect_netmiko(target: dict[str, Any], username: str, password: str, secret: str,
                     timeout: int, commands: list[str]) -> list[dict[str, str]]:
    transport = str(target.get("transport", "ssh")).lower()
    if target["vendor"] == "cisco_ios":
        device_type = "cisco_ios_telnet" if transport == "telnet" else "cisco_ios"
    elif transport == "telnet":
        raise ValueError("Telnet is currently supported only for Cisco IOS. Moxa collection uses SSH.")
    else:
        device_type = "moxa_eds"
    device: dict[str, Any] = {
        "device_type": device_type,
        "host": target["ip"], "port": int(target.get("port", 23 if transport == "telnet" else 22)),
        "username": username, "password": password,
        "conn_timeout": timeout, "auth_timeout": timeout,
        "banner_timeout": timeout, "timeout": timeout,
        "fast_cli": False,
    }
    if secret:
        device["secret"] = secret
    with ConnectHandler(**device) as connection:
        if secret and target["vendor"] == "cisco_ios":
            connection.enable()
        results = []
        for command in commands:
            try:
                output = connection.send_command(
                    command, read_timeout=max(timeout + 8, 15),
                    strip_prompt=False, strip_command=False,
                )
                rejected = re.search(r"(?im)(invalid input|invalid command|unknown command|unrecognized command|command not found|ambiguous command|incomplete command|authorization failed)", output)
                error = f"CLI rejected the command: {rejected.group(1)}" if rejected else ""
                results.append({"command": command, "output": output, "error": error})
            except Exception as exc:  # one unsupported command must not discard other captures
                results.append({"command": command, "output": "", "error": f"{type(exc).__name__}: {exc}"})
        return results


def _collect_moxa_paramiko(target: dict[str, Any], username: str, password: str,
                           timeout: int, commands: list[str]) -> list[dict[str, str]]:
    """Generic interactive-shell fallback when this Netmiko install lacks moxa_eds."""
    import paramiko

    from pathlib import Path

    client = paramiko.SSHClient()
    client.load_system_host_keys()
    known_hosts = Path(__file__).resolve().parents[1] / "data" / "known_hosts"
    known_hosts.parent.mkdir(parents=True, exist_ok=True)
    if known_hosts.exists():
        client.load_host_keys(str(known_hosts))
    # Trust-on-first-use: remember the Moxa host key locally, then reject key changes.
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    results: list[dict[str, str]] = []
    try:
        client.connect(
            hostname=target["ip"], port=int(target.get("port", 22)),
            username=username, password=password, timeout=timeout,
            auth_timeout=timeout, banner_timeout=timeout,
            look_for_keys=False, allow_agent=False,
        )
        channel = client.invoke_shell(width=200, height=1000)
        channel.settimeout(timeout)
        time.sleep(0.5)
        if channel.recv_ready():
            channel.recv(65535)
        for command in commands:
            try:
                channel.send(command + "\n")
                chunks: list[bytes] = []
                started = time.monotonic()
                last_data = started
                while time.monotonic() - started < max(timeout + 8, 15):
                    if channel.recv_ready():
                        chunks.append(channel.recv(65535))
                        last_data = time.monotonic()
                    elif time.monotonic() - last_data > 1.0:
                        break
                    else:
                        time.sleep(0.12)
                output = b"".join(chunks).decode("utf-8", errors="replace")
                rejected = re.search(r"(?im)(invalid input|invalid command|unknown command|unrecognized command|command not found|ambiguous command|incomplete command|authorization failed)", output)
                error = f"CLI rejected the command: {rejected.group(1)}" if rejected else ""
                results.append({"command": command, "output": output, "error": error})
            except Exception as exc:
                results.append({"command": command, "output": "", "error": f"{type(exc).__name__}: {exc}"})
    finally:
        client.save_host_keys(str(known_hosts))
        client.close()
    return results


def collect_one(target: dict[str, Any], username: str, password: str, secret: str,
                timeout: int, selected_groups: list[str],
                custom_commands: list[str] | dict[str, list[str]] | None = None) -> dict[str, Any]:
    started = time.monotonic()
    result: dict[str, Any] = {
        "target": target.copy(), "status": "failed", "outputs": [],
        "neighbors": [], "interfaces": {}, "vlans": {}, "model": target.get("model") or "",
        "error": "", "duration_seconds": 0.0,
        "connection_method": "Netmiko Telnet" if target.get("transport", "ssh") == "telnet" else "Netmiko SSH",
    }
    try:
        commands = commands_for(target["vendor"], selected_groups, custom_commands)
        if target["vendor"] != "cisco_ios" and target.get("transport", "ssh") == "telnet":
            raise ValueError("Telnet is currently supported only for Cisco IOS. Moxa collection uses SSH.")
        if not commands:
            result["status"] = "skipped"
            result["error"] = "None of the selected command groups apply to this vendor profile."
            result["duration_seconds"] = round(time.monotonic() - started, 2)
            return result
        if target["vendor"] == "cisco_ios":
            outputs = _collect_netmiko(target, username, password, secret, timeout, commands)
        else:
            # Current Netmiko platform list marks Moxa EDS experimental. Prefer its driver
            # when present; otherwise use Paramiko's interactive shell as a compatibility path.
            try:
                from netmiko.ssh_dispatcher import CLASS_MAPPER
                has_driver = "moxa_eds" in CLASS_MAPPER
            except Exception:
                has_driver = False
            if has_driver:
                try:
                    outputs = _collect_netmiko(target, username, password, secret, timeout, commands)
                except ValueError as exc:
                    if "device_type" not in str(exc).lower() and "moxa" not in str(exc).lower():
                        raise
                    result["connection_method"] = "Paramiko SSH fallback"
                    outputs = _collect_moxa_paramiko(target, username, password, timeout, commands)
            else:
                result["connection_method"] = "Paramiko SSH fallback"
                outputs = _collect_moxa_paramiko(target, username, password, timeout, commands)
        result["outputs"] = outputs
        from .parsers import (
            infer_model, parse_cisco_interfaces, parse_cisco_vlans,
            parse_moxa_interfaces, parse_moxa_vlans, parse_neighbors,
        )
        result["neighbors"] = parse_neighbors(outputs, target["vendor"])
        for item in outputs:
            cmd = item.get("command", "").lower()
            if "show ip interface brief" in cmd:
                result["interfaces"].update(parse_cisco_interfaces(item.get("output", "")))
            elif "show interface status" in cmd:
                result["interfaces"].update(parse_moxa_interfaces(item.get("output", "")))
            elif "show vlan brief" in cmd:
                if target["vendor"] == "cisco_ios":
                    result["vlans"].update(parse_cisco_vlans(item.get("output", "")))
                else:
                    result["vlans"].update(parse_moxa_vlans(item.get("output", "")))
            elif cmd == "show vlan":
                result["vlans"].update(parse_moxa_vlans(item.get("output", "")))
        result["model"] = infer_model(outputs, target.get("model", ""))
        command_errors = [x for x in outputs if x.get("error")]
        result["status"] = "partial" if command_errors else "success"
        if command_errors:
            result["error"] = f"{len(command_errors)} command(s) could not be collected."
    except (socket.timeout, TimeoutError) as exc:
        result["error"] = f"Connection timed out: {exc}".strip()
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    result["duration_seconds"] = round(time.monotonic() - started, 2)
    return result
