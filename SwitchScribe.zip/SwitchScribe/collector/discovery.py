"""Conservative discovery of SSH/Telnet management endpoints on a private IPv4 subnet.

This module performs only TCP connect checks against ports 22 and 23. It does
not authenticate, send CLI commands, fingerprint services, or probe other ports.
"""
from __future__ import annotations

import ipaddress
import socket
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

RFC1918_NETWORKS = tuple(
    ipaddress.ip_network(value)
    for value in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16")
)
MANAGEMENT_PORTS = (22, 23)
MAX_NETWORK_ADDRESSES = 256
MAX_DISCOVERY_WORKERS = 16
DEFAULT_PROBE_TIMEOUT = 0.35


def validate_discovery_network(cidr: str) -> ipaddress.IPv4Network:
    """Return a normalized RFC1918 IPv4 network with at most 256 addresses."""
    try:
        network = ipaddress.ip_network(str(cidr).strip(), strict=False)
    except ValueError as exc:
        raise ValueError("Enter a valid IPv4 network in CIDR notation, for example 192.168.160.0/24.") from exc
    if not isinstance(network, ipaddress.IPv4Network):
        raise ValueError("Only private IPv4 subnets are supported.")
    if not any(network.subnet_of(allowed) for allowed in RFC1918_NETWORKS):
        raise ValueError("Discovery is restricted to RFC1918 private networks (10/8, 172.16/12, or 192.168/16).")
    if network.num_addresses > MAX_NETWORK_ADDRESSES:
        raise ValueError("The selected network is too large. Use a subnet containing no more than 256 addresses (normally /24 or smaller).")
    if network.num_addresses <= 2:
        raise ValueError("Choose a subnet containing usable host addresses, such as a /30 through /24.")
    return network


def _tcp_port_open(ip: str, port: int, timeout: float) -> bool:
    try:
        with socket.create_connection((ip, port), timeout=timeout):
            return True
    except (OSError, TimeoutError):
        return False


def _probe_host(ip: ipaddress.IPv4Address, timeout: float) -> dict[str, Any] | None:
    address = str(ip)
    open_ports = [port for port in MANAGEMENT_PORTS if _tcp_port_open(address, port, timeout)]
    if not open_ports:
        return None
    # Prefer SSH when both management services are reachable.
    suggested_transport = "ssh" if 22 in open_ports else "telnet"
    return {
        "ip": address,
        "open_ports": open_ports,
        "suggested_transport": suggested_transport,
        "suggested_port": 22 if suggested_transport == "ssh" else 23,
    }


def discover_management_hosts(cidr: str, timeout: float = DEFAULT_PROBE_TIMEOUT) -> dict[str, Any]:
    """Check only TCP/22 and TCP/23 on the usable IPs in a validated subnet."""
    network = validate_discovery_network(cidr)
    timeout = max(0.15, min(float(timeout), 1.0))
    hosts = list(network.hosts())
    found: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=min(MAX_DISCOVERY_WORKERS, max(1, len(hosts)))) as executor:
        futures = {executor.submit(_probe_host, ip, timeout): ip for ip in hosts}
        for future in as_completed(futures):
            try:
                result = future.result()
            except Exception:
                # A single host probe must never abort the subnet check.
                continue
            if result:
                found.append(result)
    found.sort(key=lambda item: ipaddress.ip_address(item["ip"]))
    return {
        "network": str(network),
        "scanned_hosts": len(hosts),
        "found_count": len(found),
        "ports_checked": list(MANAGEMENT_PORTS),
        "probe_timeout_seconds": timeout,
        "hosts": found,
    }
