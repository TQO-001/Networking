from __future__ import annotations

import re
from typing import Any


def _clean(value: str | None) -> str | None:
    if value is None:
        return None
    value = value.strip().strip(",")
    return value or None


def _ip_from_text(text: str) -> str | None:
    match = re.search(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text)
    return match.group(0) if match else None


def parse_cdp_detail(text: str) -> list[dict[str, Any]]:
    neighbors: list[dict[str, Any]] = []
    blocks = re.split(r"(?im)(?=^\s*Device ID\s*:)", text)
    for block in blocks:
        if not re.search(r"(?im)^\s*Device ID\s*:", block):
            continue
        def value(pattern: str) -> str | None:
            match = re.search(pattern, block, re.I | re.M)
            return _clean(match.group(1)) if match else None
        name = value(r"^\s*Device ID\s*:\s*(.+)$")
        ip = value(r"^\s*IP address\s*:\s*(.+)$")
        platform = value(r"^\s*Platform\s*:\s*([^,\r\n]+)")
        local = value(r"^\s*Interface\s*:\s*([^,\r\n]+)")
        remote = value(r"Port ID\s*\(outgoing port\)\s*:\s*([^,\r\n]+)")
        if name:
            neighbors.append({
                "protocol": "CDP", "name": name, "ip": _ip_from_text(ip or ""),
                "platform": platform, "local_port": local, "remote_port": remote,
                "capabilities": None, "media": None,
            })
    return neighbors


def _lldp_blocks(text: str) -> list[str]:
    # Cisco output usually separates entries with dashes. Some Moxa releases
    # repeat Chassis Id fields without divider lines, so split those too.
    starts = [m.start() for m in re.finditer(r"(?im)^\s*Chassis Id\s*:", text)]
    if len(starts) > 1:
        return [text[start:end] for start, end in zip(starts, starts[1:] + [len(text)])]
    parts = re.split(r"(?m)^\s*-{8,}\s*$", text)
    return [part for part in parts if re.search(r"(?im)^\s*(?:Chassis id|Local Intf|System Name)\s*:", part)]


def parse_lldp_detail(text: str) -> list[dict[str, Any]]:
    neighbors: list[dict[str, Any]] = []
    for block in _lldp_blocks(text):
        def value(pattern: str) -> str | None:
            match = re.search(pattern, block, re.I | re.M)
            return _clean(match.group(1)) if match else None
        name = value(r"^\s*System Name\s*:\s*(.+)$")
        chassis = value(r"^\s*Chassis id\s*:\s*(.+)$")
        if name in {"--", "-", "not advertised"}:
            name = None
        desc = value(r"^\s*System Description\s*:\s*(.+)$")
        local = value(r"^\s*Local Intf(?:ace)?\s*:\s*(.+)$")
        remote = value(r"^\s*Port id\s*:\s*(.+)$")
        remote_description = value(r"^\s*Port Description\s*:\s*(.+)$")
        # Cisco may render this on a separate line below 'Management Addresses'.
        ip = _ip_from_text(block)
        capabilities = value(r"^\s*(?:Enabled )?Capabilities\s*:\s*(.+)$")
        mau = value(r"^\s*Media Attachment Unit type\s*:?\s*(.+)$")
        physical = re.findall(r"(?im)^\s*(\d+base[-\w]+\([^\r\n]+\))", block)
        media = ", ".join(physical) if physical else None
        if not media and mau:
            media = {"16": "100BASE-TX (UTP)", "26": "1000BASE-X (Fiber)", "30": "1000BASE-T (UTP)"}.get(mau.strip(), f"MAU type {mau}")
        if name or chassis:
            neighbors.append({
                "protocol": "LLDP", "name": name or chassis, "chassis_id": chassis,
                "ip": ip, "platform": desc, "local_port": local,
                "remote_port": remote_description or remote, "capabilities": capabilities, "media": media,
            })
    return neighbors


def parse_lldp_summary(text: str) -> list[dict[str, Any]]:
    """Parse Cisco's compact LLDP table, including wrapped device-ID rows."""
    rows: list[dict[str, Any]] = []
    interface_re = re.compile(
        r"(?i)(?:Gig(?:abitEthernet)?|Gi|FastEthernet|Fas|Fa|TenGig(?:abitEthernet)?|Te)\s*\d+(?:/\d+){1,2}"
    )
    pending_name: str | None = None
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if re.search(r"(?i)Device ID|Local Intf|Capability Codes|Total entries", stripped):
            continue
        ports = list(interface_re.finditer(line))
        if len(ports) >= 2:
            name = line[:ports[0].start()].strip() or pending_name
            if name:
                local_port = re.sub(r"\s+", "", ports[0].group(0))
                remote_port = re.sub(r"\s+", "", ports[-1].group(0))
                rows.append({
                    "protocol": "LLDP", "name": name, "ip": None,
                    "platform": None, "local_port": local_port,
                    "remote_port": remote_port, "capabilities": None, "media": None,
                })
            pending_name = None
            continue
        # In classic IOS, the device ID is on its own line and the port columns
        # appear on the following indented line.
        if not re.match(r"(?i)^(?:Capability|Device ID|Local Intf|Total entries)", stripped):
            if not stripped.startswith(("Gig", "Gi", "Fas", "Fa", "Ten", "Te")):
                pending_name = stripped
    return rows


def parse_moxa_fw5_lldp(text: str) -> list[dict[str, Any]]:
    """Parse older Moxa `show lldp entry` blocks (Port/Neighbor ID/System)."""
    neighbors: list[dict[str, Any]] = []
    blocks = re.split(r"(?im)(?=^\s*Port\s*:\s*\S+)", text)
    for block in blocks:
        if not re.search(r"(?im)^\s*Neighbor (?:ID|System)\s*:", block):
            continue
        def value(pattern: str) -> str | None:
            match = re.search(pattern, block, re.I | re.M)
            return _clean(match.group(1)) if match else None
        local = value(r"^\s*Port\s*:\s*(.+)$")
        chassis = value(r"^\s*Neighbor ID\s*:\s*(.+)$")
        remote = value(r"^\s*Neighbor Port\s*:\s*(.+)$")
        media = value(r"^\s*Neighbor Port Descript\s*:\s*(.+)$")
        name = value(r"^\s*Neighbor System\s*:\s*(.+)$")
        if name or chassis:
            neighbors.append({
                "protocol": "LLDP", "name": name or chassis,
                "chassis_id": chassis, "ip": _ip_from_text(block),
                "platform": None, "local_port": local,
                "remote_port": remote, "capabilities": "Bridge (inferred from Moxa LLDP entry)",
                "media": media,
            })
    return neighbors


def _normalize_port(value: str | None) -> str:
    normalized = re.sub(r"\s+", "", (value or "")).casefold()
    for prefix, short in (("tengigabitethernet", "te"), ("gigabitethernet", "gi"), ("fastethernet", "fa"), ("ethernet", "eth")):
        if normalized.startswith(prefix):
            return short + normalized[len(prefix):]
    return normalized


def _normalize_peer(value: str | None) -> str:
    value = (value or "").strip().casefold()
    value = re.sub(r"\.[a-z0-9.-]+$", "", value)
    return re.sub(r"[^a-z0-9]", "", value)


def parse_neighbors(outputs: list[dict[str, str]], vendor: str) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    for item in outputs:
        command = item.get("command", "").lower()
        output = item.get("output", "")
        if "cdp neighbors detail" in command:
            found.extend(parse_cdp_detail(output))
        elif "show lldp neighbors" in command and "detail" not in command:
            found.extend(parse_lldp_summary(output))
        elif "lldp entry" in command:
            found.extend(parse_moxa_fw5_lldp(output))
        elif "lldp neighbors" in command and "detail" in command:
            found.extend(parse_lldp_detail(output))
    # Merge CDP/LLDP descriptions of the same peer on the same local interface.
    merged: list[dict[str, Any]] = []
    for item in found:
        local = _normalize_port(item.get("local_port"))
        name = _normalize_peer(item.get("name") or item.get("chassis_id"))
        match = None
        for existing in merged:
            old_local = _normalize_port(existing.get("local_port"))
            if old_local and local and old_local != local:
                continue
            same_ip = bool(item.get("ip") and existing.get("ip") and item["ip"] == existing["ip"])
            old_name = _normalize_peer(existing.get("name") or existing.get("chassis_id"))
            same_name = bool(name and old_name and (
                name == old_name or (min(len(name), len(old_name)) >= 8 and (name.startswith(old_name) or old_name.startswith(name)))
            ))
            if same_ip or same_name:
                match = existing
                break
        if match is None:
            merged.append(item.copy())
            continue
        for field, value in item.items():
            if value and not match.get(field):
                match[field] = value
        protocols = {x for x in str(match.get("protocol", "")).split("/") if x}
        protocols.add(item.get("protocol", ""))
        match["protocol"] = "/".join(sorted(x for x in protocols if x))
    return merged


def parse_cisco_interfaces(text: str) -> dict[str, dict[str, str]]:
    interfaces: dict[str, dict[str, str]] = {}
    for line in text.splitlines():
        parts = line.split()
        if len(parts) < 6:
            continue
        name = parts[0]
        if not re.match(r"^(?:FastEthernet|GigabitEthernet|TenGigabitEthernet|Ethernet|Fa\d|Gi\d|Te\d)", name, re.I):
            continue
        interfaces[name] = {"status": parts[-2], "protocol": parts[-1]}
    return interfaces


def parse_moxa_interfaces(text: str) -> dict[str, dict[str, str]]:
    interfaces: dict[str, dict[str, str]] = {}
    for line in text.splitlines():
        match = re.match(r"^\s*((?:Eth|Ethernet)\S+)\s+(connected|not connected|not present|disabled)\b", line, re.I)
        if match:
            interfaces[match.group(1)] = {"status": match.group(2), "protocol": "-"}
    return interfaces


def parse_cisco_vlans(text: str) -> dict[str, str]:
    """Map interface name -> 'VID VLAN_NAME'; handles wrapped port lists."""
    result: dict[str, str] = {}
    current: str | None = None
    header_seen = False
    for line in text.splitlines():
        if re.match(r"^\s*VLAN\s+Name\s+Status", line, re.I):
            header_seen = True
            continue
        if not header_seen:
            continue
        match = re.match(r"^\s*(\d+)\s+(\S+)\s+\S+\s*(.*)$", line)
        if match:
            current = f"{match.group(1)} {match.group(2)}"
            ports = match.group(3).strip()
        elif current and line[:1].isspace():
            ports = line.strip()
        else:
            continue
        for port in re.split(r"\s*,\s*", ports):
            port = port.strip()
            if port:
                result[port] = current
    return result


def parse_moxa_vlans(text: str) -> dict[str, str]:
    """Parse both Moxa Next-gen `show vlan brief` and FW5.x `show vlan` samples."""
    result: dict[str, str] = {}
    # Next-generation output: vlan ID : N / Member Ports : Eth1/1, Eth1/2
    blocks = re.split(r"(?im)(?=^\s*vlan ID\s*:)", text)
    for block in blocks:
        vid_match = re.search(r"(?im)^\s*vlan ID\s*:\s*(\d+)", block)
        if not vid_match:
            continue
        vid = vid_match.group(1)
        name_match = re.search(r"(?im)^\s*Name[ \t]*:[ \t]*([^\r\n]+)$", block)
        vlan_name = _clean(name_match.group(1)) if name_match else None
        # Membership lines can wrap to the next indented line.
        member_match = re.search(r"(?im)^\s*(?:Member Ports|Untagged Ports|Access Ports)\s*:\s*(.*(?:\n(?!\s*(?:Untagged Ports|Forbidden Ports|Name|Status|Trunk Ports|Hybrid Ports)\s*:)[ \t]+.*)*)", block)
        if member_match:
            ports_text = member_match.group(1)
            for port in re.findall(r"(?:Eth|Ethernet)?\d+[/\-]\d+", ports_text, re.I):
                normalized = port if port.lower().startswith(("eth", "ethernet")) else f"Eth{port}"
                result[normalized] = f"{vid} {vlan_name}" if vlan_name else vid
    # Legacy FW5.x output: VLAN N: ... Access Ports: 1/1, 1/2
    legacy_blocks = re.split(r"(?im)(?=^\s*VLAN\s+\d+\s*:)", text)
    for block in legacy_blocks:
        vid_match = re.search(r"(?im)^\s*VLAN\s+(\d+)\s*:", block)
        if not vid_match:
            continue
        vid = vid_match.group(1)
        name_match = re.search(r"(?im)^\s*Name[ \t]*:[ \t]*([^\r\n]+)$", block)
        vlan_name = _clean(name_match.group(1)) if name_match else None
        port_lines = re.findall(r"(?im)^\s*(?:Access Ports|Trunk Ports|Hybrid Ports)\s*:\s*([^\r\n]*)", block)
        for ports_text in port_lines:
            for port in re.findall(r"\b\d+[/\-]\d+\b", ports_text):
                result[f"Eth{port.replace('-', '/')}"] = f"{vid} {vlan_name}" if vlan_name else vid
    return result


def infer_model(outputs: list[dict[str, str]], configured_model: str = "") -> str:
    if configured_model:
        return configured_model
    for item in outputs:
        output = item.get("output", "")
        patterns = [
            r"(?im)^\s*Model Number\s*:\s*(\S.+)$",
            r"(?im)^\s*Model\s*:\s*(\S.+)$",
            r"(?im)^\s*Platform\s*:\s*([^,\r\n]+)",
            r"(?i)\b(IE-\d{3,4}[^\s,]*)\b",
            r"(?i)\b(WS-C\d{4,5}[^\s,]*)\b",
        ]
        for pattern in patterns:
            match = re.search(pattern, output)
            if match:
                return match.group(1).strip()
    return "Not reported"
