from __future__ import annotations

import csv
import ipaddress
import json
import os
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
INVENTORY_JSON = DATA_DIR / "inventory.json"
ALLOWED_VENDORS = {"cisco_ios", "moxa_nextgen", "moxa_fw5"}
ALLOWED_TRANSPORTS = {"ssh", "telnet"}
MAX_SWITCHES = 512


def validate_inventory(items: Any) -> list[dict[str, Any]]:
    if not isinstance(items, list):
        raise ValueError("Inventory must be a list of switches.")
    if len(items) > MAX_SWITCHES:
        raise ValueError(f"A maximum of {MAX_SWITCHES} switches is allowed.")
    cleaned: list[dict[str, Any]] = []
    seen_ips: set[tuple[str, int]] = set()
    seen_names: set[str] = set()
    for index, raw in enumerate(items, start=1):
        if not isinstance(raw, dict):
            raise ValueError(f"Row {index} is not a switch object.")
        name = str(raw.get("name", "")).strip()
        ip = str(raw.get("ip", "")).strip()
        vendor = str(raw.get("vendor", "cisco_ios")).strip().lower()
        model = str(raw.get("model", "")).strip()
        location = str(raw.get("location", "")).strip()
        transport = str(raw.get("transport", "ssh")).strip().lower() or "ssh"
        try:
            ipaddress.ip_address(ip)
        except ValueError as exc:
            raise ValueError(f"Row {index}: '{ip}' is not a valid IP address.") from exc
        if not name:
            raise ValueError(f"Row {index}: switch name is required.")
        if vendor not in ALLOWED_VENDORS:
            raise ValueError(f"Row {index}: unsupported vendor profile '{vendor}'.")
        if transport not in ALLOWED_TRANSPORTS:
            raise ValueError(f"Row {index}: unsupported transport '{transport}'. Choose ssh or telnet.")
        default_port = 23 if transport == "telnet" else 22
        try:
            port = int(raw.get("port") or default_port)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Row {index}: connection port must be a number.") from exc
        if not 1 <= port <= 65535:
            raise ValueError(f"Row {index}: connection port must be between 1 and 65535.")
        if vendor != "cisco_ios" and transport == "telnet":
            raise ValueError(f"Row {index}: Telnet is currently supported only for the Cisco IOS profile.")
        key = (ip, port)
        if key in seen_ips:
            raise ValueError(f"Duplicate switch endpoint: {ip}:{port}.")
        norm_name = name.casefold()
        if norm_name in seen_names:
            raise ValueError(f"Duplicate switch name: {name}.")
        seen_ips.add(key)
        seen_names.add(norm_name)
        cleaned.append({
            "id": str(raw.get("id") or f"sw-{index}"),
            "name": name,
            "ip": ip,
            "port": port,
            "transport": transport,
            "vendor": vendor,
            "model": model,
            "location": location,
            "enabled": bool(raw.get("enabled", True)),
        })
    return cleaned


def load_inventory() -> list[dict[str, Any]]:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not INVENTORY_JSON.exists():
        return []
    with INVENTORY_JSON.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    return validate_inventory(data)


def save_inventory(items: Any) -> list[dict[str, Any]]:
    cleaned = validate_inventory(items)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix="inventory-", suffix=".json", dir=DATA_DIR)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(cleaned, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
        os.replace(tmp_name, INVENTORY_JSON)
    finally:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)
    return cleaned


def load_csv_text(csv_text: str) -> list[dict[str, Any]]:
    reader = csv.DictReader(csv_text.splitlines())
    required = {"name", "ip"}
    if not reader.fieldnames or not required.issubset({x.strip().lower() for x in reader.fieldnames}):
        raise ValueError("CSV needs at least these headers: name,ip. Optional: vendor,model,location,transport,port,enabled.")
    items = []
    for row in reader:
        normal = {str(k).strip().lower(): (v or "").strip() for k, v in row.items() if k}
        if not normal.get("name") and not normal.get("ip"):
            continue
        enabled_text = normal.get("enabled", "true").lower()
        items.append({
            "name": normal.get("name", ""),
            "ip": normal.get("ip", ""),
            "vendor": normal.get("vendor") or "cisco_ios",
            "model": normal.get("model", ""),
            "location": normal.get("location", ""),
            "port": normal.get("port") or (23 if normal.get("transport", "ssh").lower() == "telnet" else 22),
            "transport": normal.get("transport") or "ssh",
            "enabled": enabled_text not in {"false", "0", "no", "off"},
        })
    return validate_inventory(items)
