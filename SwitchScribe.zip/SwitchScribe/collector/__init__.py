"""SwitchScribe collection and documentation helpers."""
