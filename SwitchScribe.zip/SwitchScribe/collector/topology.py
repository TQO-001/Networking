from __future__ import annotations

import re
from collections import defaultdict, deque
from typing import Any


def _normal(value: str | None) -> str:
    value = (value or "").strip().lower()
    value = re.sub(r"\.[a-z0-9.-]+$", "", value)
    return re.sub(r"[^a-z0-9]", "", value)


def resolve_neighbor(neighbor: dict[str, Any], targets: list[dict[str, Any]]) -> dict[str, Any] | None:
    ip = neighbor.get("ip")
    if ip:
        for target in targets:
            if target["target"]["ip"] == ip:
                return target
    peer_name = _normal(neighbor.get("name"))
    if not peer_name:
        return None
    for target in targets:
        known = _normal(target["target"]["name"])
        if peer_name == known:
            return target
    return None


def _port_key(value: str) -> str:
    normalized = re.sub(r"\s+", "", value).casefold()
    for prefix, short in (("gigabitethernet", "gi"), ("fastethernet", "fa"), ("tengigabitethernet", "te"), ("ten-gigabitEthernet", "te"), ("ethernet", "eth")):
        if normalized.startswith(prefix):
            return short + normalized[len(prefix):]
    return normalized


def build_topology(results: list[dict[str, Any]]) -> dict[str, Any]:
    successful = [r for r in results if r["status"] in {"success", "partial"}]
    by_id = {r["target"]["id"]: r for r in results}
    adjacency: dict[str, set[str]] = {r["target"]["id"]: set() for r in results}
    links: dict[tuple[str, str, str, str], dict[str, Any]] = {}
    for result in successful:
        local_id = result["target"]["id"]
        for neighbor in result.get("neighbors", []):
            remote = resolve_neighbor(neighbor, results)
            if not remote or remote["target"]["id"] == local_id:
                continue
            remote_id = remote["target"]["id"]
            adjacency[local_id].add(remote_id)
            adjacency[remote_id].add(local_id)
            local_port = neighbor.get("local_port") or "?"
            remote_port = neighbor.get("remote_port") or "?"
            if local_id <= remote_id:
                a_id, b_id, a_port, b_port = local_id, remote_id, local_port, remote_port
            else:
                a_id, b_id, a_port, b_port = remote_id, local_id, remote_port, local_port
            key = (a_id, b_id, _port_key(a_port), _port_key(b_port))
            if key not in links:
                links[key] = {
                    "a": by_id[a_id]["target"], "b": by_id[b_id]["target"],
                    "a_port": a_port, "b_port": b_port,
                    "protocols": set(), "media": neighbor.get("media") or "Not reported",
                }
            entry = links[key]
            entry["protocols"].add(neighbor.get("protocol", "LLDP"))
            if entry["media"] == "Not reported" and neighbor.get("media"):
                entry["media"] = neighbor["media"]
    groups: list[list[dict[str, Any]]] = []
    visited: set[str] = set()
    for result in sorted(results, key=lambda x: (x["target"]["name"].casefold(), x["target"]["ip"])):
        root = result["target"]["id"]
        if root in visited:
            continue
        queue = deque([root])
        visited.add(root)
        group_ids: list[str] = []
        while queue:
            current = queue.popleft()
            group_ids.append(current)
            for peer in sorted(adjacency[current]):
                if peer not in visited:
                    visited.add(peer)
                    queue.append(peer)
        groups.append([by_id[item] for item in group_ids])
    groups.sort(key=lambda g: (-len(g), g[0]["target"]["name"].casefold()))
    final_links = []
    for item in sorted(links.values(), key=lambda x: (x["a"]["name"], x["b"]["name"], x["a_port"])):
        item["protocols"] = "/".join(sorted(item["protocols"]))
        final_links.append(item)
    return {"groups": groups, "links": final_links, "adjacency": adjacency}
