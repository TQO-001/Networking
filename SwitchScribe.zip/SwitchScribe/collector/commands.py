"""Curated, read-only collection commands and user-command validation."""
from __future__ import annotations

import re
from collections.abc import Iterable
from typing import Any

COMMAND_GROUPS = {
    "neighbors": {
        "label": "Neighbor discovery (LLDP/CDP)",
        "description": "Find adjacent switches and devices.",
        "commands": {
            "cisco_ios": ["show cdp neighbors detail", "show lldp neighbors", "show lldp neighbors detail"],
            "moxa_nextgen": ["show lldp neighbors detail"],
            "moxa_fw5": ["show lldp entry"],
        },
    },
    "vlans": {
        "label": "VLAN information",
        "description": "Collect VLAN IDs, names and memberships.",
        "commands": {
            "cisco_ios": ["show vlan brief"],
            "moxa_nextgen": ["show vlan brief"],
            "moxa_fw5": ["show vlan"],
        },
    },
    "interfaces": {
        "label": "Interface status",
        "description": "Collect port state and interface information.",
        "commands": {
            "cisco_ios": ["show ip interface brief"],
            "moxa_nextgen": ["show interface status"],
            "moxa_fw5": [],
        },
    },
    "system": {
        "label": "System and software information",
        "description": "Collect platform and software details (Cisco profile).",
        "commands": {
            "cisco_ios": ["show version"],
            "moxa_nextgen": [],
            "moxa_fw5": [],
        },
    },
}

DEFAULT_GROUPS = ["neighbors", "vlans", "interfaces", "system"]
MAX_CUSTOM_COMMANDS = 20
MAX_COMMAND_LENGTH = 160
# Restrict the custom-command box to operational show commands. In particular,
# block broad configuration dumps and diagnostics that can reveal secrets or
# generate very large outputs. Commands are sent as single CLI lines, never via a shell.
_BLOCKED_SHOW = re.compile(
    r"(?i)^show\s+(?:run(?:ning)?(?:[- ]config(?:uration)?)?|"
    r"start(?:up)?(?:[- ]config(?:uration)?)?|tech(?:[- ]support)?|support|logging|"
    r"archive\s+config|crypto\s+key|users?\s+detail)\b"
)
_CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f]")
_PIPE_FILTER = re.compile(r"(?i)^\s*(?:include|exclude|begin|section|count)\s+[\w .:/_-]{1,80}$")


ALL_SAFE_COMMANDS = {
    command
    for group in COMMAND_GROUPS.values()
    for command_list in group["commands"].values()
    for command in command_list
}


def _validate_command_lines(value: str | Iterable[str] | None) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        raw_commands = value.splitlines()
    elif isinstance(value, Iterable):
        raw_commands = list(value)
    else:
        raise ValueError("Custom commands must be supplied as text or a list of lines.")

    commands: list[str] = []
    seen: set[str] = set()
    for line_number, raw in enumerate(raw_commands, start=1):
        if not isinstance(raw, str):
            raise ValueError(f"Custom command line {line_number} must be text.")
        command = raw.strip()
        if not command or command.startswith("#"):
            continue
        if len(command) > MAX_COMMAND_LENGTH:
            raise ValueError(f"Custom command line {line_number} exceeds {MAX_COMMAND_LENGTH} characters.")
        if _CONTROL_CHARS.search(command) or any(token in command for token in (";", "`", "&&", ">", "<")):
            raise ValueError(f"Custom command line {line_number} contains unsupported control characters, separators, or output redirection.")
        if "|" in command:
            parts = command.split("|")
            if len(parts) != 2 or not _PIPE_FILTER.fullmatch(parts[1]):
                raise ValueError(f"Custom command line {line_number} uses an unsupported pipe modifier. Only include, exclude, begin, section, and count filters are allowed.")
        if not re.match(r"(?i)^show\s+\S", command):
            raise ValueError(f"Custom command line {line_number} must be a read-only 'show ...' command.")
        if _BLOCKED_SHOW.search(command):
            raise ValueError(f"Custom command line {line_number} is blocked because it may expose sensitive configuration or produce an excessive diagnostic dump.")
        key = command.casefold()
        if key not in seen:
            seen.add(key)
            commands.append(command)
        if len(commands) > MAX_CUSTOM_COMMANDS:
            raise ValueError(f"A maximum of {MAX_CUSTOM_COMMANDS} custom commands is allowed per CLI profile.")
    return commands


def validate_custom_commands(value: Any) -> list[str] | dict[str, list[str]]:
    """Validate commands globally or separately for each supported CLI profile.

    Dict input is profile-specific, which prevents Cisco syntax from being
    blindly sent to Moxa devices and vice versa. List/text input remains
    available for internal callers that deliberately want common commands.
    """
    if value is None:
        return []
    if isinstance(value, dict):
        unsupported = set(value) - set(COMMAND_GROUPS["neighbors"]["commands"])
        if unsupported:
            raise ValueError(f"Unsupported custom-command CLI profile(s): {', '.join(sorted(unsupported))}.")
        result = {vendor: _validate_command_lines(value.get(vendor, []))
                  for vendor in COMMAND_GROUPS["neighbors"]["commands"]}
        return result
    return _validate_command_lines(value)


def commands_for(vendor: str, selected_groups: list[str], custom_commands: list[str] | dict[str, list[str]] | None = None) -> list[str]:
    commands: list[str] = []
    for group_id in selected_groups:
        if group_id not in COMMAND_GROUPS:
            raise ValueError(f"Unknown command group: {group_id}")
        commands.extend(COMMAND_GROUPS[group_id]["commands"].get(vendor, []))
    if isinstance(custom_commands, dict):
        commands.extend(custom_commands.get(vendor, []))
    else:
        commands.extend(custom_commands or [])
    # Stable de-duplication keeps report sections predictable.
    return list(dict.fromkeys(commands))
