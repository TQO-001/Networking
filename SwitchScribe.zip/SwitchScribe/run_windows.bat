@echo off
setlocal
cd /d "%~dp0"
echo.
echo  SwitchScribe - local switch documentation
echo.
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)"
  if errorlevel 1 goto old_python
  if not exist .venv py -3 -m venv .venv
) else (
  python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)"
  if errorlevel 1 goto old_python
  if not exist .venv python -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 goto failed
start "" http://127.0.0.1:5000
python app.py
goto end
:old_python
echo Python 3.11 or newer was not found. Install Python, then run this file again.
pause
goto end
:failed
echo Dependency installation failed. Check your internet connection and Python version.
pause
:end
endlocal
