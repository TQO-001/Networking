import pytest

from collector import discovery


def test_discovery_network_normalizes_a_private_ipv4_cidr():
    network = discovery.validate_discovery_network("192.168.160.19/24")
    assert str(network) == "192.168.160.0/24"
    assert network.num_addresses == 256


@pytest.mark.parametrize("cidr", [
    "8.8.8.0/24",          # public range
    "172.15.0.0/24",       # outside RFC1918 172.16/12
    "192.168.0.0/23",      # more than 256 addresses
    "192.168.1.1",         # /32 has no usable hosts
    "2001:db8::/120",      # IPv6 intentionally unsupported
    "not-a-network",
])
def test_discovery_rejects_out_of_scope_or_oversized_networks(cidr):
    with pytest.raises(ValueError):
        discovery.validate_discovery_network(cidr)


def test_discovery_checks_only_ports_22_and_23_and_returns_open_hosts(monkeypatch):
    seen = []
    open_map = {
        ("192.168.10.1", 22): True,
        ("192.168.10.1", 23): False,
        ("192.168.10.2", 22): False,
        ("192.168.10.2", 23): True,
        ("192.168.10.3", 22): True,
        ("192.168.10.3", 23): True,
    }

    def fake_probe(ip, port, timeout):
        seen.append((ip, port))
        return open_map.get((ip, port), False)

    monkeypatch.setattr(discovery, "_tcp_port_open", fake_probe)
    result = discovery.discover_management_hosts("192.168.10.0/29", timeout=0.5)

    assert result["network"] == "192.168.10.0/29"
    assert result["scanned_hosts"] == 6
    assert result["found_count"] == 3
    assert result["ports_checked"] == [22, 23]
    assert result["hosts"] == [
        {"ip": "192.168.10.1", "open_ports": [22], "suggested_transport": "ssh", "suggested_port": 22},
        {"ip": "192.168.10.2", "open_ports": [23], "suggested_transport": "telnet", "suggested_port": 23},
        {"ip": "192.168.10.3", "open_ports": [22, 23], "suggested_transport": "ssh", "suggested_port": 22},
    ]
    assert set(port for _, port in seen) == {22, 23}


def test_discovery_clamps_probe_timeout(monkeypatch):
    observed = []
    monkeypatch.setattr(discovery, "_tcp_port_open", lambda ip, port, timeout: observed.append(timeout) or False)
    discovery.discover_management_hosts("192.168.20.0/30", timeout=99)
    assert observed and all(value == 1.0 for value in observed)
