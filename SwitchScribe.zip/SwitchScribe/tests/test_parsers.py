from collector.parsers import (
    parse_cdp_detail, parse_lldp_detail, parse_moxa_fw5_lldp,
    parse_cisco_interfaces, parse_cisco_vlans,
)


def test_parse_cdp_detail_extracts_peer_and_ports():
    raw = """-------------------------
Device ID: IND-SW-EDNL_TLL.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.59
Platform: cisco IE-3000-8TC, Capabilities: Switch IGMP
Interface: GigabitEthernet1/1, Port ID (outgoing port): GigabitEthernet1/2
Holdtime : 138 sec
"""
    rows = parse_cdp_detail(raw)
    assert len(rows) == 1
    assert rows[0]["name"].startswith("IND-SW-EDNL_TLL")
    assert rows[0]["ip"] == "192.168.160.59"
    assert rows[0]["local_port"] == "GigabitEthernet1/1"
    assert rows[0]["remote_port"] == "GigabitEthernet1/2"


def test_parse_cisco_lldp_detail_includes_mau_media():
    raw = """------------------------------------------------
Local Intf: Gi1/1
Chassis id: 0027.90cc.d582
Port id: port-002-00000
Port Description: GigabitEthernet1/2
System Name: IND-SW-EDNL_TLL.hulamin.co.za
System Description:
 Cisco IOS Software, Version 15.2(4)EA5
Management Addresses:
    IP: 192.168.160.59
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1
"""
    rows = parse_lldp_detail(raw)
    assert len(rows) == 1
    assert rows[0]["ip"] == "192.168.160.59"
    assert rows[0]["local_port"] == "Gi1/1"
    assert "1000baseX" in rows[0]["media"]


def test_parse_moxa_legacy_lldp_entry():
    raw = """MOXA# show lldp entry
Port : 23
Neighbor ID : 00:90:e8:0a:0a:0a
Neighbor Port : 3
Neighbor Port Descript : 100TX,RJ45.
Neighbor System : Managed Redundant Switch 00000

Port : 19
Neighbor ID : 00:90:e8:0a:0a:0a
Neighbor Port : 2
Neighbor Port Descript : 100TX,RJ45.
Neighbor System : Managed Redundant Switch 00000
"""
    rows = parse_moxa_fw5_lldp(raw)
    assert len(rows) == 2
    assert rows[0]["local_port"] == "23"
    assert rows[0]["remote_port"] == "3"
    assert rows[0]["protocol"] == "LLDP"


def test_parse_cisco_interfaces_and_vlan_memberships():
    interfaces = parse_cisco_interfaces("""Interface IP-Address OK? Method Status Protocol
Vlan560 192.168.160.73 YES NVRAM up up
FastEthernet1/1 unassigned YES unset up up
FastEthernet1/3 unassigned YES unset down down
""")
    assert interfaces["FastEthernet1/1"]["status"] == "up"
    assert interfaces["FastEthernet1/3"]["protocol"] == "down"
    vlans = parse_cisco_vlans("""VLAN Name Status Ports
---- -------------------------------- --------- -------------------------------
561 VLAN0561 active Fa1/2, Fa1/3
590 EDPowerMeters active Fa1/1
""")
    assert vlans["Fa1/2"] == "561 VLAN0561"
    assert vlans["Fa1/1"] == "590 EDPowerMeters"


def test_parse_moxa_vlans_for_nextgen_and_fw5_outputs():
    from collector.parsers import parse_moxa_vlans

    nextgen = """vlan database
-------------
vlan ID : 1
Member Ports : Eth1/1, Eth1/2
Untagged Ports : Eth1/1, Eth1/2
Name : Default
Status : Permanent
----------------------------------------------------
vlan ID : 20
Member Ports : Eth1/3
Name : Controls
Status : Permanent
"""
    parsed = parse_moxa_vlans(nextgen)
    assert parsed["Eth1/1"] == "1 Default"
    assert parsed["Eth1/3"] == "20 Controls"

    fw5 = """MOXA# show vlan
VLAN 1:
  Name:
  Access Ports: 1/1, 1/2,
  Trunk Ports:
  Hybrid Ports:
VLAN 20:
  Name: Controls
  Access Ports: 1/3,
"""
    parsed = parse_moxa_vlans(fw5)
    assert parsed["Eth1/1"] == "1"
    assert parsed["Eth1/3"] == "20 Controls"


def test_parse_multiple_moxa_nextgen_lldp_entries_without_dividers():
    raw = """Chassis Id SubType : Mac Address
Chassis Id : 00:90:e8:00:00:01
Port Id SubType : Local
Port Id : 1
System Name : MOXA-AREA-A
System Desc : EDS-G512E
Local Intf : Eth1/3
Management Addresses :
 IP: 192.0.2.21
Chassis Id SubType : Mac Address
Chassis Id : 00:90:e8:00:00:02
Port Id SubType : Local
Port Id : 2
System Name : MOXA-AREA-B
System Desc : EDS-G512E
Local Intf : Eth1/4
Management Addresses :
 IP: 192.0.2.22
"""
    rows = parse_lldp_detail(raw)
    assert len(rows) == 2
    assert rows[0]["name"] == "MOXA-AREA-A"
    assert rows[1]["ip"] == "192.0.2.22"


def test_parse_lldp_summary_and_merge_local_port_into_detail_record():
    from collector.parsers import parse_neighbors

    summary = """Capability Codes: (R) Router, (B) Bridge
Device ID        Local Intf Hold-time Capability Platform Port ID
IND-SW-EDNL_TLL.hulamin.co.za
                 Gig 1/1   173       S I        IE-3000-8 Gig 1/2
Total entries displayed: 1
"""
    detail = """------------------------------------------------
Chassis id: 0027.90cc.d582
Port id: port-002-00000
Port Description: GigabitEthernet1/2
System Name: IND-SW-EDNL_TLL.hulamin.co.za
System Description: Cisco IOS Software
Management Addresses:
  IP: 192.168.160.59
Media Attachment Unit type: 26
"""
    rows = parse_neighbors([
        {"command": "show lldp neighbors", "output": summary},
        {"command": "show lldp neighbors detail", "output": detail},
    ], "cisco_ios")
    assert len(rows) == 1
    assert rows[0]["local_port"] == "Gig1/1"
    assert rows[0]["remote_port"] == "Gig1/2"
    assert rows[0]["ip"] == "192.168.160.59"
