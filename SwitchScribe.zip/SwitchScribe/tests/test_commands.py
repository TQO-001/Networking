import pytest

from collector.commands import commands_for, validate_custom_commands


def test_custom_commands_accept_show_commands_and_deduplicate_case_insensitively():
    commands = validate_custom_commands("show mac address-table\n\nshow spanning-tree\nSHOW MAC ADDRESS-TABLE\nshow version | include uptime")
    assert commands == ["show mac address-table", "show spanning-tree", "show version | include uptime"]


def test_custom_commands_can_be_used_without_builtin_groups():
    custom = validate_custom_commands(["show version", "show ip ssh"])
    assert commands_for("cisco_ios", [], custom) == ["show version", "show ip ssh"]


@pytest.mark.parametrize("command", [
    "configure terminal",
    "write memory",
    "reload",
    "clear counters",
    "debug ip packet",
    "show running-config",
    "show run",
    "show startup-config",
    "show start",
    "show tech-support",
    "show logging",
    "show version | redirect flash:/dump.txt",
    "show version | include uptime | redirect flash:/dump.txt",
    "show version; reload",
    "show version\nreload",
])
def test_custom_commands_reject_non_show_or_sensitive_commands(command):
    with pytest.raises(ValueError):
        validate_custom_commands(command)


def test_custom_commands_enforce_line_count_and_length():
    with pytest.raises(ValueError, match="maximum of 20"):
        validate_custom_commands([f"show item {index}" for index in range(21)])
    with pytest.raises(ValueError, match="exceeds 160 characters"):
        validate_custom_commands("show " + "x" * 160)


def test_custom_commands_ignore_comment_lines():
    assert validate_custom_commands("# comment\nshow version") == ["show version"]



def test_profile_specific_commands_only_apply_to_matching_vendor():
    custom = validate_custom_commands({
        "cisco_ios": ["show mac address-table"],
        "moxa_nextgen": ["show interface status"],
        "moxa_fw5": ["show vlan"],
    })
    assert commands_for("cisco_ios", [], custom) == ["show mac address-table"]
    assert commands_for("moxa_nextgen", [], custom) == ["show interface status"]
    assert commands_for("moxa_fw5", [], custom) == ["show vlan"]


def test_profile_specific_commands_reject_unknown_profile():
    with pytest.raises(ValueError, match="Unsupported custom-command CLI profile"):
        validate_custom_commands({"unknown_vendor": ["show version"]})
