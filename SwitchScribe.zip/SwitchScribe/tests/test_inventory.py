import pytest
from collector.inventory import validate_inventory


def test_inventory_rejects_invalid_ip_and_duplicate_endpoint():
    with pytest.raises(ValueError, match="valid IP"):
        validate_inventory([{"name": "bad", "ip": "not-an-ip"}])
    rows = [
        {"name": "SW1", "ip": "192.0.2.1"},
        {"name": "SW2", "ip": "192.0.2.1"},
    ]
    with pytest.raises(ValueError, match="Duplicate switch endpoint"):
        validate_inventory(rows)


def test_inventory_default_profile_and_port():
    rows = validate_inventory([{"name": "SW1", "ip": "192.0.2.1"}])
    assert rows[0]["vendor"] == "cisco_ios"
    assert rows[0]["port"] == 22
    assert rows[0]["enabled"] is True


def test_inventory_defaults_to_ssh_and_ssh_port():
    rows = validate_inventory([{"name": "SW1", "ip": "192.0.2.1"}])
    assert rows[0]["transport"] == "ssh"
    assert rows[0]["port"] == 22


def test_inventory_telnet_defaults_to_port_23():
    rows = validate_inventory([{
        "name": "SW1", "ip": "192.0.2.1", "transport": "telnet"
    }])
    assert rows[0]["transport"] == "telnet"
    assert rows[0]["port"] == 23


def test_inventory_rejects_telnet_for_moxa_profiles():
    with pytest.raises(ValueError, match="Telnet is currently supported only for the Cisco IOS"):
        validate_inventory([{
            "name": "MOXA1", "ip": "192.0.2.1",
            "vendor": "moxa_fw5", "transport": "telnet",
        }])


def test_csv_import_reads_transport_and_applies_default_port():
    from collector.inventory import load_csv_text

    rows = load_csv_text("name,ip,transport\nSW1,192.0.2.1,telnet\nSW2,192.0.2.2,ssh\n")
    assert rows[0]["transport"] == "telnet"
    assert rows[0]["port"] == 23
    assert rows[1]["transport"] == "ssh"
    assert rows[1]["port"] == 22


def test_known_telnet_only_switches_are_preconfigured():
    from collector.inventory import load_inventory

    by_ip = {item["ip"]: item for item in load_inventory()}
    expected = {
        "192.168.160.5": "IND-SW-EDNL_CompHouse1",
        "192.168.160.33": "IND-SW-EDNL_S4PulPit",
        "192.168.160.124": "IND-SW-EDNL_PTTL_PLC2",
    }
    for ip, name in expected.items():
        assert by_ip[ip]["name"] == name
        assert by_ip[ip]["transport"] == "telnet"
        assert by_ip[ip]["port"] == 23
