from collector.topology import build_topology


def target(name, ip, switch_id):
    return {
        "target": {"id": switch_id, "name": name, "ip": ip, "vendor": "cisco_ios", "port": 22},
        "status": "success", "outputs": [], "interfaces": {}, "vlans": {}, "model": "IE-3000",
        "error": "", "duration_seconds": 1, "neighbors": [],
    }


def test_build_topology_groups_connected_switches_and_keeps_isolated_switch():
    a = target("SW-A", "192.0.2.1", "a")
    b = target("SW-B", "192.0.2.2", "b")
    c = target("SW-C", "192.0.2.3", "c")
    a["neighbors"] = [{"protocol": "LLDP", "name": "SW-B", "ip": "192.0.2.2", "local_port": "Gi1/1", "remote_port": "Gi1/2"}]
    b["neighbors"] = [{"protocol": "CDP", "name": "SW-A", "ip": "192.0.2.1", "local_port": "Gi1/2", "remote_port": "Gi1/1"}]
    topology = build_topology([a, b, c])
    sizes = sorted((len(group) for group in topology["groups"]), reverse=True)
    assert sizes == [2, 1]
    assert len(topology["links"]) == 1
    assert topology["links"][0]["protocols"] == "CDP/LLDP"


def test_topology_deduplicates_long_and_short_interface_names():
    a = target("SW-A", "192.0.2.1", "a")
    b = target("SW-B", "192.0.2.2", "b")
    a["neighbors"] = [{"protocol": "CDP", "name": "SW-B", "ip": "192.0.2.2", "local_port": "GigabitEthernet1/1", "remote_port": "GigabitEthernet1/2"}]
    b["neighbors"] = [{"protocol": "LLDP", "name": "SW-A", "ip": "192.0.2.1", "local_port": "Gi1/2", "remote_port": "Gi1/1"}]
    topology = build_topology([a, b])
    assert len(topology["links"]) == 1
    assert topology["links"][0]["protocols"] == "CDP/LLDP"
