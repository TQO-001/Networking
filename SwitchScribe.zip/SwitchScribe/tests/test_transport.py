from __future__ import annotations

import sys
import types

import pytest

# Keep these connection-selection unit tests runnable without installing Netmiko.
# In the real application, requirements.txt installs Netmiko before app.py starts.
try:
    import netmiko  # noqa: F401
except ModuleNotFoundError:
    stub = types.ModuleType("netmiko")
    stub.ConnectHandler = lambda **kwargs: None
    sys.modules["netmiko"] = stub

from collector import driver


class FakeConnection:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def send_command(self, command, **kwargs):
        return f"output for {command}"


def test_cisco_telnet_uses_netmiko_telnet_device_type_and_default_port(monkeypatch):
    captured = {}

    def fake_connect_handler(**kwargs):
        captured.update(kwargs)
        return FakeConnection()

    monkeypatch.setattr(driver, "ConnectHandler", fake_connect_handler)
    outputs = driver._collect_netmiko(
        {"vendor": "cisco_ios", "transport": "telnet", "ip": "192.0.2.10"},
        "readonly", "secret", "", 10, ["show version"],
    )

    assert captured["device_type"] == "cisco_ios_telnet"
    assert captured["port"] == 23
    assert outputs[0]["command"] == "show version"


def test_cisco_ssh_driver_remains_unchanged(monkeypatch):
    captured = {}

    def fake_connect_handler(**kwargs):
        captured.update(kwargs)
        return FakeConnection()

    monkeypatch.setattr(driver, "ConnectHandler", fake_connect_handler)
    driver._collect_netmiko(
        {"vendor": "cisco_ios", "transport": "ssh", "ip": "192.0.2.11", "port": 2222},
        "readonly", "secret", "", 10, ["show version"],
    )

    assert captured["device_type"] == "cisco_ios"
    assert captured["port"] == 2222


def test_moxa_telnet_is_rejected_without_attempting_connection(monkeypatch):
    def unexpected_connection(**kwargs):
        pytest.fail("No Telnet connection should be attempted for a Moxa profile")

    monkeypatch.setattr(driver, "ConnectHandler", unexpected_connection)
    result = driver.collect_one(
        {"id": "m1", "name": "MOXA", "ip": "192.0.2.12", "vendor": "moxa_fw5",
         "transport": "telnet", "port": 23, "enabled": True},
        "readonly", "secret", "", 5, ["neighbors"],
    )

    assert result["status"] == "failed"
    assert "Telnet is currently supported only for Cisco IOS" in result["error"]
