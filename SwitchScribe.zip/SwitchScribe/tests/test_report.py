from collector.report import generate_markdown


def test_report_contains_groups_links_and_raw_commands():
    a = {
        "target": {"id": "a", "name": "SW-A", "ip": "192.0.2.1", "port": 22, "vendor": "cisco_ios", "model": "IE-3000", "location": "Room A"},
        "status": "success", "model": "IE-3000", "duration_seconds": 0.5, "connection_method": "Netmiko",
        "error": "", "neighbors": [{"protocol": "LLDP", "name": "SW-B", "ip": "192.0.2.2", "local_port": "Gi1/1", "remote_port": "Gi1/2", "media": "1000BASE-X (Fiber)"}],
        "interfaces": {"Gi1/1": {"status": "up", "protocol": "up"}}, "vlans": {},
        "outputs": [{"command": "show lldp neighbors detail", "output": "System Name: SW-B", "error": ""}],
    }
    b = {
        "target": {"id": "b", "name": "SW-B", "ip": "192.0.2.2", "port": 22, "vendor": "cisco_ios", "model": "IE-3000", "location": "Room B"},
        "status": "failed", "model": "IE-3000", "duration_seconds": 0.1, "connection_method": "Netmiko",
        "error": "Timeout", "neighbors": [], "interfaces": {}, "vlans": {}, "outputs": [],
    }
    report = generate_markdown([a, b], ["neighbors"])
    assert "## Switch-to-Switch Links" in report
    assert "### Group 1 — Connected switch group" in report
    assert "show lldp neighbors detail" in report
    assert "Collection Failures" in report
    assert "Timeout" in report


def test_telnet_transport_is_documented_for_switch():
    result = {
        "target": {
            "id": "telnet-sw", "name": "TELNET-SW", "ip": "192.0.2.23",
            "port": 23, "transport": "telnet", "vendor": "cisco_ios",
            "model": "IE-3000", "location": "Room C",
        },
        "status": "failed", "model": "IE-3000", "duration_seconds": 0.2,
        "connection_method": "Netmiko Telnet", "error": "Connection refused",
        "neighbors": [], "interfaces": {}, "vlans": {}, "outputs": [],
    }
    report = generate_markdown([result], ["neighbors"])
    assert "| **Transport** | TELNET |" in report
    assert "| **Connection port** | 23 |" in report
    assert "| **Connection method** | Netmiko Telnet |" in report


def test_custom_commands_are_documented_in_report_summary():
    result = {
        "target": {"id": "a", "name": "SW-A", "ip": "192.0.2.1", "port": 22, "vendor": "cisco_ios"},
        "status": "success", "model": "IE-3000", "duration_seconds": 0.1,
        "connection_method": "Netmiko SSH", "error": "", "neighbors": [],
        "interfaces": {}, "vlans": {},
        "outputs": [{"command": "show mac address-table", "output": "Vlan Mac Address", "error": ""}],
    }
    report = generate_markdown([result], [], ["show mac address-table"])
    assert "Command groups selected: None" in report
    assert "Custom read-only commands: `show mac address-table`" in report
    assert "show mac address-table" in report



def test_profile_specific_custom_commands_are_listed_by_profile():
    result = {
        "target": {"id": "a", "name": "SW-A", "ip": "192.0.2.1", "port": 22, "vendor": "cisco_ios"},
        "status": "success", "model": "IE-3000", "duration_seconds": 0.1,
        "connection_method": "Netmiko SSH", "error": "", "neighbors": [],
        "interfaces": {}, "vlans": {},
        "outputs": [{"command": "show mac address-table", "output": "Vlan Mac Address", "error": ""}],
    }
    report = generate_markdown([result], [], {
        "cisco_ios": ["show mac address-table"],
        "moxa_nextgen": [],
        "moxa_fw5": ["show lldp entry"],
    })
    assert "cisco_ios: `show mac address-table`" in report
    assert "moxa_fw5: `show lldp entry`" in report
