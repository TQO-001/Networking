#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3.11 or newer is required."
  exit 1
fi
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if command -v open >/dev/null 2>&1; then open http://127.0.0.1:5000 || true
elif command -v xdg-open >/dev/null 2>&1; then xdg-open http://127.0.0.1:5000 >/dev/null 2>&1 || true
fi
python app.py
