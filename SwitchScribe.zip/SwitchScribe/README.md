# SwitchScribe

A local web application for collecting **read-only** information from Cisco and Moxa switches, discovering LLDP/CDP neighbours, and generating a single Markdown documentation file grouped by connected switch topology.

The report follows the structure of the supplied `Department 34.md` example: network overview, switch summary, switch-to-switch links, neighbour-based groups, per-switch sections, connected-port tables, and raw CLI captures.

## Start it on Windows

1. Install **Python 3.11 or newer**. Python 3.12 is a good default. During installation, enable **Add Python to PATH**.
2. Extract the `SwitchScribe.zip` folder somewhere convenient.
3. Double-click `run_windows.bat`.
4. The first run creates a virtual environment and installs the dependencies. The browser opens at **http://127.0.0.1:5000**.
5. Enter the connection username/password, choose the built-in command groups, optionally open the profile-specific custom-command boxes, then select **Start collection**. Each inventory row chooses SSH or Telnet.
6. When the run finishes, select **Download Markdown**. The file is ready to open in Obsidian or any Markdown editor.

Keep the terminal window open while using the app. Close it to stop the local web server.

### macOS / Linux

Run the following from the extracted project folder:

```bash
chmod +x run_mac_linux.sh
./run_mac_linux.sh
```

Then open `http://127.0.0.1:5000` if the browser did not open automatically.

## Already loaded: your starter inventory

`data/inventory.json` and `data/starter_inventory.csv` contain the switch list from your supplied script (102 rows after adding the four additional Department 34 entries visible in the reference document). The 18 switches documented in the Department 34 file have their documented model and the three known SL7 room locations pre-filled.

Before the first live run, open **Switch inventory** and check each switch's vendor profile and transport. The following three switches from your inventory are already set to Telnet on port 23 because you identified them as Telnet-only:

| Profile | Select it for | Commands used |
|---|---|---|
| `cisco_ios` | Cisco IOS / IOS-XE switches, including the Cisco IE switches in the example | `show version`, `show vlan brief`, `show ip interface brief`, `show cdp neighbors detail`, `show lldp neighbors`, `show lldp neighbors detail` |
| `moxa_nextgen` | Moxa switches running the newer EDS / G4000 Next-generation OS CLI | `show vlan brief`, `show interface status`, `show lldp neighbors detail` |
| `moxa_fw5` | Moxa switches using the older FW 5.x CLI family | `show vlan`, `show lldp entry` |

### Known Telnet devices

| Switch | Management IP | Transport | Port |
|---|---|---:|---:|
| `IND-SW-EDNL_CompHouse1` | `192.168.160.5` | Telnet | 23 |
| `IND-SW-EDNL_S4PulPit` | `192.168.160.33` | Telnet | 23 |
| `IND-SW-EDNL_PTTL_PLC2` | `192.168.160.124` | Telnet | 23 |

All other starter inventory entries remain SSH on port 22. You can change any row's transport and port in the **Switch inventory** table. Changing SSH to Telnet automatically changes the default port to 23; changing back to SSH sets it to 22. A custom port can be entered afterward.

**Telnet warning:** Telnet does not encrypt usernames, passwords, or command output. Use it only if your site's OT security policy allows it and the management path is appropriately isolated. The app uses the same username/password entered on the Collection tab for both protocols. Cisco IOS Telnet is supported through Netmiko's `cisco_ios_telnet` driver; Moxa profiles currently remain SSH-only.

**Do not guess the Moxa profile from the brand alone.** Check the switch model and firmware family first. Moxa command syntax varies by product generation. If you are unsure, leave that switch disabled until its profile is confirmed. Profiles can be changed in the inventory table; you do not need to edit Python code.

## What the app does

1. Opens independent SSH or Telnet sessions to enabled inventory entries using a `ThreadPoolExecutor`. Cisco IOS Telnet rows use Netmiko's `cisco_ios_telnet` device type; SSH rows continue to use the existing Cisco/Moxa SSH drivers.
2. Executes the selected built-in read-only command groups plus optional profile-specific custom `show ...` commands. Custom commands are validated on the server; configuration, write, reload, clear, debug, configuration-dump, and excessive diagnostic command families are blocked.
3. Collects each switch independently. A timeout, authentication problem, unreachable host, or unsupported command is stored against that switch; it does not cancel the other workers.
4. Parses CDP and LLDP neighbour records, matching peers to inventory entries by management IP or advertised system/device name.
5. Builds connected components from resolved switch-to-switch neighbour links. Those components become **Group 1**, **Group 2**, etc. End devices that are not in the switch inventory remain listed on the local switch's connected-port table; they are not treated as switch groups.
6. Writes raw command output below the matching switch entry. Cisco output uses a `Cisco` code fence; Moxa output uses a `text` code fence so that it is not mislabeled as Cisco CLI.

A switch with no resolved switch neighbour appears in its own single-switch group. A failed switch is still included in the report as failed, with no fabricated neighbour information.

## Discover additional management IPs

The **Switch inventory** tab includes an optional **Find additional management IPs** panel. The default CIDR is `192.168.160.0/24`, matching the management subnet in the starter inventory. Change it when you have approval to check a different subnet.

1. Enter a private IPv4 subnet in CIDR notation.
2. Tick the authorization acknowledgement.
3. Select **Discover devices**.
4. Review the results. SwitchScribe checks only TCP port 22 (SSH) and TCP port 23 (Telnet), using short connection attempts. It does not authenticate, send CLI commands, perform ICMP sweeps, identify device vendors, or probe any other ports.
5. Select the new addresses you want, give each a meaningful name, choose the correct Cisco/Moxa CLI profile, confirm the transport, and add them to inventory.

**Scope limits:** discovery accepts only RFC1918 private IPv4 ranges (`10.0.0.0/8`, `172.16.0.0/12`, and `192.168.0.0/16`) and networks containing no more than 256 total addresses (normally a `/24` or smaller). It uses at most 16 concurrent TCP connection checks and a short timeout. This is deliberately conservative for OT environments. A host is shown only when TCP/22 or TCP/23 accepts a connection; hosts that block both ports will not appear even if they are online. Conversely, an open SSH/Telnet port does not prove that the host is a switch.

Discovered entries are **not** added automatically. The CLI profile starts unselected because an open management port cannot tell the app whether the host is Cisco, Moxa, a server, or another device. Review the device and its model before adding it. Moxa profiles remain SSH-only; if a new host exposes Telnet only, do not assign a Moxa profile until you have confirmed an approved SSH management path.

## Custom command profiles

On the **Collection** tab, expand the custom-command section for the matching CLI profile: Cisco IOS/IOS-XE, Moxa Next-generation OS, or Moxa FW 5.x. Commands are sent only to enabled inventory entries using that exact profile. This avoids sending Cisco-specific syntax to Moxa devices. You can use the built-in command groups, custom commands, or both; at least one command source must be selected.

Enter one command per line. The server accepts at most 20 custom commands per CLI profile, with a maximum of 160 characters per command. Custom commands must begin with `show`. Commands such as `configure terminal`, `write memory`, `reload`, `clear`, `debug`, abbreviated or full `show running-config` / `show startup-config`, `show tech-support`, and `show logging` are rejected. Safe Cisco-style pipe filters (`include`, `exclude`, `begin`, `section`, and `count`) are allowed; output redirection and command chaining are not. Blank lines and comment lines beginning with `#` are ignored. The app does not try to determine whether a `show` command is supported by a particular model/firmware; if a device rejects it, that command error is recorded while the remaining commands and devices continue.

The custom command list and its profile are recorded in the generated report summary. Raw output is included under the matching switch section. As with all collected CLI output, review the report before sharing it because even read-only operational output may contain internal network information.

## Moxa compatibility details

Netmiko's supported-platform catalogue currently lists Moxa EDS as an experimental platform. SwitchScribe first checks whether the installed Netmiko build exposes its `moxa_eds` driver. If not, the app uses a small Paramiko interactive-shell fallback for the same curated Moxa read-only commands.

The fallback uses trust-on-first-use for SSH host keys: a first-seen key is saved in `data/known_hosts`, and a later key change will be rejected. Review that file locally if a Moxa switch is intentionally replaced or its SSH host key is rotated. Cisco connections use Netmiko.

Moxa profiles are deliberately separate because, for example, newer EDS-4000/G4000 manuals document `show lldp neighbors` and `show interface status`, while older FW 5.x manuals document `show lldp entry` and `show vlan`. Do not enable a command group on a model/firmware combination unless the device manual confirms it.

## Inventory CSV

The inventory can be edited in the table or replaced with **Import CSV**. Required headers:

```csv
name,ip
```

Optional headers:

```csv
vendor,model,location,transport,port,enabled
```

Example:

```csv
name,ip,vendor,model,location,transport,port,enabled
IND-SW-EDNL_SL7,192.168.160.73,cisco_ios,IE-3000-4TC,SL7 LV Room,ssh,22,true
IND-SW-EDNL_CompHouse1,192.168.160.5,cisco_ios,,,telnet,23,true
MOXA-AREA-A,192.168.160.150,moxa_nextgen,EDS-4008,Area A,ssh,22,true
MOXA-AREA-B,192.168.160.151,moxa_fw5,EDS-510E,Area B,ssh,22,true
```

Allowed `vendor` values are `cisco_ios`, `moxa_nextgen`, and `moxa_fw5`; allowed `transport` values are `ssh` and `telnet`. If the vendor or transport column is blank, the import defaults that row to Cisco IOS over SSH. If `port` is blank, the app defaults to 22 for SSH or 23 for Telnet. Telnet is currently accepted only with the Cisco IOS profile. The app validates IP addresses, duplicate endpoints, connection ports, and duplicate names before saving.

The inventory is stored in `data/inventory.json` (up to 512 entries); credentials are **not** stored there. The username/password/optional enable password are sent to the local app for the current run and are not written to the report or inventory. Jobs and captured output are held in the app's memory and disappear when the server stops.

## Safe operating defaults

- The web server binds to `127.0.0.1` only; it is not exposed to the LAN.
- The default concurrency is four sessions; the UI caps it at eight. Keep it low on production OT networks and follow your site's change/monitoring rules.
- SSH is the default transport. Telnet is selected per Cisco IOS switch, not globally; the three user-identified Telnet devices are preconfigured above. Telnet is plaintext and should only be used when explicitly permitted by your site's OT security policy.
- Start by enabling only a small, approved subset of switches. Confirm credentials, SSH/Telnet reachability, prompt behavior, and command support before enabling a larger sweep.
- Use a read-only account. The app does not need configuration privileges for the default collection.
- Collection is not a substitute for verifying data against the switch itself. Reports may show `Not reported` when a model or command does not advertise a field. If you select only commands that do not apply to a particular profile, that switch is marked `skipped` rather than failed.
- Optional subnet discovery is explicit and requires an authorization acknowledgement. It is limited to RFC1918 IPv4 subnets of at most 256 addresses and checks TCP 22/23 only. It never logs in or adds discovered endpoints automatically.
- Discovery results are potential management endpoints, not confirmed switches. Review each device and select its CLI profile before adding it to inventory.
- Custom command entry is limited to single-line `show ...` operations, with sensitive configuration dumps and large diagnostics blocked server-side. Use a read-only device account and check commands against the relevant model/firmware documentation before running them.
- The app does not modify VLANs, change interfaces, save configurations, or restart devices.

## TLA+ specification

`spec/Collector.tla` models the job lifecycle, bounded concurrent workers, transport selection, and the invariant that selected commands belong to an abstract safe-command set. `spec/Discovery.tla` models explicit authorization, private-subnet scoping, the 256-address bound, and the restriction to management ports 22 and 23. These are formal workflow specifications, not the language used to implement SSH or the web application. TLC configurations are in `spec/Collector.cfg` and `spec/Discovery.cfg`.

To check the models, install the TLA+ tools separately and run TLC against `spec/Collector.cfg` and `spec/Discovery.cfg`. TLA+ is optional; the Python application does not require it.

## Tests

The parser and topology tests do not connect to real switches:

```bash
python -m pip install -r requirements.txt
python -m pytest -q
```

They cover inventory transport defaults and Telnet validation, Cisco Telnet driver selection, Cisco CDP/LLDP detail parsing, Moxa FW 5.x LLDP parsing, Cisco VLAN/interface parsing, LLDP/CDP group formation, private-subnet discovery scope and results, profile-specific command selection, custom-command validation, and report output.

## Project structure

```text
SwitchScribe/
├── app.py
├── collector/
│   ├── commands.py
│   ├── discovery.py
│   ├── driver.py
│   ├── inventory.py
│   ├── parsers.py
│   ├── report.py
│   └── topology.py
├── data/
│   ├── inventory.json
│   └── starter_inventory.csv
├── spec/
│   ├── Collector.cfg
│   ├── Collector.tla
│   ├── Discovery.cfg
│   └── Discovery.tla
├── static/
│   ├── app.js
│   ├── index.html
│   └── styles.css
├── tests/
│   ├── test_commands.py
│   ├── test_discovery.py
│   └── ...
├── requirements.txt
├── run_windows.bat
└── run_mac_linux.sh
```

## Troubleshooting

**The browser says it cannot connect.** Make sure the terminal still shows the Flask server running. Open `http://127.0.0.1:5000` manually.

**The app says authentication failed.** Verify the username/password with the switch administrator. If Cisco commands require privileged EXEC mode, enter the enable password too.

**A switch times out.** Check that the device is powered, reachable from the computer running SwitchScribe, and that the selected transport (SSH or Telnet) is enabled and permitted by the relevant ACL/firewall. Check the per-device port in Switch inventory (normally 22 for SSH or 23 for Telnet). A timeout is recorded for that switch; the rest of the run continues.

**A Moxa command is rejected.** Confirm the model and firmware family, then choose the matching Moxa profile. The app does not try configuration commands or silently switch to a different CLI dialect.

**A neighbour is not grouped with an inventory switch.** Check that the advertised management IP or LLDP system name matches that switch's inventory IP/name. If the peer is not in the inventory, it remains an endpoint in the local switch section rather than being guessed as a switch. Add it to inventory only after confirming that it is a switch and selecting the correct CLI profile.

**A device does not appear in subnet discovery.** Discovery checks TCP/22 and TCP/23 only. A device using a non-standard port, a device that blocks connection checks, or a host reachable only through another management method will not be listed. Add such a device manually with its known IP and port.

**A custom command is rejected before collection.** It must be a single-line `show ...` command. Put it in the text area matching the device's CLI profile. Configuration dumps and large diagnostic commands are blocked intentionally.

**An SSH host key changed.** Verify the change through your normal device-maintenance process before removing the matching entry from `data/known_hosts`. Do not delete the file just to bypass an unexplained key change.

## CLI references used for the device profiles

- [Netmiko supported platforms](https://github.com/ktbyers/netmiko/blob/develop/PLATFORMS.md) — includes the `cisco_ios_telnet` Telnet driver; Moxa EDS is listed as experimental.
- [Moxa EDS-4000 / G4000 Next-generation OS CLI manual](https://www.moxa.com/getmedia/a5653f08-6ff5-42e6-b129-f2c36924cc92/moxa-eds-4000-g4000-series-cli-manual-v1.0.pdf) — documents LLDP neighbours, VLAN brief output, and interface status commands.
- [Moxa EDS-510E FW 5.x CLI manual](https://www.moxa.com/getmedia/d1da13e9-b557-4efe-8eae-33605eae9800/moxa-eds-510e-series-command-line-interface-fw-5.x-um-manual-v1.5.pdf) — documents the older `show lldp entry` and `show vlan` syntax.
- [Netmiko project and installation guidance](https://github.com/ktbyers/netmiko) — the app is pinned to Netmiko 4.x and uses its documented SSH and Telnet connection handlers.
