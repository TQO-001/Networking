const $ = (selector) => document.querySelector(selector);
let inventory = [];
let discoveredHosts = [];
let activeJobId = null;
let pollHandle = null;
let lastRunTime = 'Not run';

const vendorOptions = [
  ['cisco_ios', 'Cisco IOS / IOS-XE'],
  ['moxa_nextgen', 'Moxa EDS · Next-gen OS'],
  ['moxa_fw5', 'Moxa · Firmware 5.x'],
];

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function toast(message, isError = false) {
  const el = $('#toast');
  el.textContent = message;
  el.className = `toast show${isError ? ' error' : ''}`;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.className = 'toast', 3200);
}
function setBusy(busy) {
  $('#run-button').disabled = busy;
  $('#run-button').innerHTML = busy ? '<span class="button-glyph">◌</span> Collection running…' : '<span class="button-glyph">▶</span> Start collection <span class="button-arrow">→</span>';
}
async function api(url, options = {}) {
  const response = await fetch(url, options);
  const data = response.headers.get('content-type')?.includes('application/json') ? await response.json() : await response.text();
  if (!response.ok) throw new Error(data?.error || `Request failed (${response.status})`);
  return data;
}
function updateStats() {
  const enabled = inventory.filter(s => s.enabled).length;
  const vendors = new Set(inventory.filter(s => s.enabled).map(s => s.vendor)).size;
  $('#stat-total').textContent = inventory.length;
  $('#stat-enabled').textContent = enabled;
  $('#stat-vendors').textContent = vendors;
  $('#inventory-tab-count').textContent = inventory.length;
  $('#ready-count').textContent = enabled;
  $('#inventory-count-label').textContent = `${inventory.length} switches`;
}
function vendorSelect(value) {
  return `<select data-field="vendor">${vendorOptions.map(([v,l]) => `<option value="${v}" ${value===v?'selected':''}>${l}</option>`).join('')}</select>`;
}
function transportSelect(value, vendor) {
  const selected = value || 'ssh';
  const telnetDisabled = vendor !== 'cisco_ios' ? 'disabled' : '';
  return `<select data-field="transport" aria-label="Connection transport"><option value="ssh" ${selected==='ssh'?'selected':''}>SSH</option><option value="telnet" ${selected==='telnet'?'selected':''} ${telnetDisabled}>Telnet</option></select>`;
}
function renderInventory() {
  const query = ($('#inventory-search').value || '').trim().toLowerCase();
  const body = $('#inventory-body');
  body.innerHTML = '';
  const shown = inventory.map((s, i) => ({s, i})).filter(({s}) => `${s.name} ${s.ip} ${s.model} ${s.location}`.toLowerCase().includes(query));
  $('#inventory-empty').classList.toggle('hidden', shown.length !== 0);
  for (const {s, i} of shown) {
    const tr = document.createElement('tr');
    tr.dataset.index = i;
    tr.innerHTML = `
      <td><input data-field="name" value="${escapeHtml(s.name)}" aria-label="Switch name"></td>
      <td><input data-field="ip" value="${escapeHtml(s.ip)}" aria-label="Management IP"></td>
      <td>${vendorSelect(s.vendor)}</td>
      <td><input data-field="model" value="${escapeHtml(s.model || '')}" aria-label="Model"></td>
      <td><input data-field="location" value="${escapeHtml(s.location || '')}" aria-label="Location"></td>
      <td><div class="transport-port-control">${transportSelect(s.transport, s.vendor)}<input data-field="port" type="number" min="1" max="65535" value="${escapeHtml(s.port || (s.transport === 'telnet' ? 23 : 22))}" aria-label="Connection port"></div></td>
      <td><input data-field="enabled" type="checkbox" ${s.enabled ? 'checked' : ''} aria-label="Include in scan"></td>
      <td><button class="delete-row" title="Remove switch" aria-label="Remove ${escapeHtml(s.name)}">×</button></td>`;
    body.appendChild(tr);
  }
  updateStats();
}
function readTableIntoInventory() {
  for (const tr of $('#inventory-body').querySelectorAll('tr')) {
    const index = Number(tr.dataset.index);
    if (!inventory[index]) continue;
    for (const field of ['name','ip','vendor','model','location','transport','port','enabled']) {
      const control = tr.querySelector(`[data-field="${field}"]`);
      if (!control) continue;
      inventory[index][field] = field === 'enabled' ? control.checked : (field === 'port' ? Number(control.value || (inventory[index].transport === 'telnet' ? 23 : 22)) : control.value.trim());
    }
  }
}
async function loadInventory() {
  const data = await api('/api/inventory');
  inventory = data.switches || [];
  renderInventory();
}
async function saveInventory(silent = false) {
  readTableIntoInventory();
  const data = await api('/api/inventory', {
    method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify({switches: inventory})
  });
  inventory = data.switches;
  renderInventory();
  if (!silent) toast(`Saved ${data.count} switches to the local inventory.`);
}
function setTab(tab) {
  document.querySelectorAll('.tab').forEach(el => el.classList.toggle('active', el.dataset.tab === tab));
  document.querySelectorAll('.tab-panel').forEach(el => el.classList.toggle('active', el.id === `panel-${tab}`));
}
async function startRun() {
  const username = $('#username').value.trim();
  const password = $('#password').value;
  const secret = $('#secret').value;
  const groups = [...$('#command-groups').querySelectorAll('input:checked')].map(el => el.value);
  const customCommands = {
    cisco_ios: $('#custom-cisco').value.split(/\r?\n/).map(line => line.trim()).filter(Boolean),
    moxa_nextgen: $('#custom-moxa-nextgen').value.split(/\r?\n/).map(line => line.trim()).filter(Boolean),
    moxa_fw5: $('#custom-moxa-fw5').value.split(/\r?\n/).map(line => line.trim()).filter(Boolean),
  };
  const hasCustomCommands = Object.values(customCommands).some(lines => lines.length > 0);
  if (!username || !password) return toast('Enter the connection username and password first.', true);
  if (!groups.length && !hasCustomCommands) return toast('Select a command group or enter at least one custom show command.', true);
  const enabledCount = inventory.filter(s => s.enabled).length;
  if (!enabledCount) return toast('There are no enabled switches in the inventory.', true);
  try {
    await saveInventory();
    $('#password').value = '';
    $('#secret').value = '';
    const data = await api('/api/run', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({username, password, secret, groups, custom_commands: customCommands, timeout: Number($('#timeout').value), workers: Number($('#workers').value)})
    });
    activeJobId = data.job_id;
    $('#progress-panel').classList.remove('hidden');
    $('#download-row').classList.add('hidden');
    $('#result-list').innerHTML = '';
    $('#progress-bar').style.width = '0%';
    $('#progress-number').textContent = '0%';
    $('#progress-count').textContent = `0 / ${data.total} completed`;
    $('#progress-title').textContent = 'Connecting to switches…';
    $('#progress-copy').textContent = 'Each switch is handled independently. Unreachable devices will not stop the run.';
    setBusy(true);
    $('#stat-last').textContent = 'Running';
    if (pollHandle) clearInterval(pollHandle);
    pollHandle = setInterval(() => pollJob(activeJobId), 1000);
    pollJob(activeJobId);
    $('#progress-panel').scrollIntoView({behavior:'smooth',block:'nearest'});
  } catch (err) {
    toast(err.message, true);
  }
}
function renderResults(devices) {
  const list = $('#result-list');
  list.innerHTML = '';
  for (const device of devices) {
    const row = document.createElement('div');
    row.className = 'result-row';
    row.innerHTML = `<div class="result-device"><strong>${escapeHtml(device.name)}</strong><small>${escapeHtml(device.ip)} · ${escapeHtml((device.transport || 'ssh').toUpperCase())} · ${device.duration_seconds || 0}s</small></div><span class="status-pill ${escapeHtml(device.status)}">${escapeHtml(device.status.toUpperCase())}</span>`;
    list.appendChild(row);
  }
}
async function pollJob(jobId) {
  if (!jobId) return;
  try {
    const job = await api(`/api/jobs/${jobId}`);
    const percent = job.total ? Math.round(job.completed / job.total * 100) : 0;
    $('#progress-bar').style.width = `${percent}%`;
    $('#progress-number').textContent = `${percent}%`;
    $('#progress-count').textContent = `${job.completed} / ${job.total} completed`;
    $('#progress-state').textContent = job.state.toUpperCase();
    renderResults(job.devices || []);
    if (job.state === 'completed') {
      clearInterval(pollHandle); pollHandle = null; setBusy(false);
      const summary = job.summary || {};
      $('#progress-title').textContent = 'Collection complete';
      $('#progress-copy').textContent = `${summary.success || 0} successful · ${summary.partial || 0} partial · ${summary.failed || 0} failed`;
      $('#download-link').href = `/api/jobs/${jobId}/report.md`;
      $('#download-row').classList.remove('hidden');
      lastRunTime = new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
      $('#stat-last').textContent = lastRunTime;
      toast('Collection finished. Your Markdown report is ready.');
    } else if (job.state === 'failed') {
      clearInterval(pollHandle); pollHandle = null; setBusy(false);
      $('#progress-title').textContent = 'Collection stopped';
      $('#progress-copy').textContent = job.fatal_error || 'An unexpected error stopped this run.';
      toast('The collection job failed.', true);
    }
  } catch (err) {
    clearInterval(pollHandle); pollHandle = null; setBusy(false);
    toast(err.message, true);
  }
}
function renderDiscoveryResults(data) {
  discoveredHosts = data.hosts || [];
  const panel = $('#discovery-results');
  const body = $('#discovery-body');
  body.innerHTML = '';
  panel.classList.remove('hidden');
  const newCount = discoveredHosts.filter(host => !host.already_in_inventory).length;
  $('#discovery-summary').textContent = `${data.found_count} management endpoint(s) found · ${newCount} not in inventory`;
  $('#add-discovered').disabled = newCount === 0;
  $('#discovery-detail').textContent = `${data.network} · ${data.scanned_hosts} host addresses checked · TCP ${data.ports_checked.join(' / ')}`;
  $('#discovery-empty').classList.toggle('hidden', discoveredHosts.length !== 0);
  for (const [index, host] of discoveredHosts.entries()) {
    const portOptions = host.open_ports.map(port => {
      const transport = port === 22 ? 'ssh' : 'telnet';
      return `<option value="${transport}:${port}" ${port === host.suggested_port ? 'selected' : ''}>${transport.toUpperCase()} · ${port}</option>`;
    }).join('');
    const tr = document.createElement('tr');
    tr.dataset.index = index;
    tr.innerHTML = `
      <td><input data-discovery-add type="checkbox" ${host.already_in_inventory ? 'disabled' : 'checked'} aria-label="Add ${escapeHtml(host.ip)}"></td>
      <td><code>${escapeHtml(host.ip)}</code>${host.already_in_inventory ? '<small class="already-added">Already in inventory</small>' : ''}</td>
      <td>${host.open_ports.map(port => `<span class="port-chip">${port === 22 ? 'SSH' : 'TELNET'} ${port}</span>`).join(' ')}</td>
      <td><input data-discovery-name value="${escapeHtml(`Unclassified-${host.ip}`)}" aria-label="Device name"></td>
      <td><select data-discovery-vendor aria-label="Choose CLI profile"><option value="">Choose profile…</option>${vendorOptions.map(([value,label]) => `<option value="${value}">${label}</option>`).join('')}</select></td>
      <td><select data-discovery-transport aria-label="Choose transport and port">${portOptions}</select></td>`;
    body.appendChild(tr);
  }
}
async function discoverNetwork() {
  const cidr = $('#discovery-cidr').value.trim();
  if (!cidr) return toast('Enter a private IPv4 subnet in CIDR notation.', true);
  if (!$('#discovery-authorized').checked) return toast('Confirm that you are authorized to check this network first.', true);
  const button = $('#discover-button');
  button.disabled = true;
  button.textContent = 'Checking management ports…';
  try {
    const data = await api('/api/discover', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({cidr, authorized: true, timeout: 0.35})
    });
    renderDiscoveryResults(data);
    toast(`Discovery finished: ${data.found_count} endpoint(s) responded.`);
  } catch (err) {
    toast(err.message, true);
  } finally {
    button.disabled = false;
    button.innerHTML = 'Discover devices <span>⌕</span>';
  }
}
async function addDiscoveredToInventory() {
  const selectedRows = [...$('#discovery-body').querySelectorAll('tr')].filter(row => row.querySelector('[data-discovery-add]')?.checked);
  if (!selectedRows.length) return toast('Select at least one new device to add.', true);
  readTableIntoInventory();
  const existingIps = new Set(inventory.map(item => item.ip));
  const selected = [];
  for (const row of selectedRows) {
    const candidate = discoveredHosts[Number(row.dataset.index)];
    if (!candidate || candidate.already_in_inventory || existingIps.has(candidate.ip)) continue;
    const name = row.querySelector('[data-discovery-name]').value.trim();
    const vendor = row.querySelector('[data-discovery-vendor]').value;
    const [transport, rawPort] = row.querySelector('[data-discovery-transport]').value.split(':');
    if (!name) return toast(`Enter a name for ${candidate.ip}.`, true);
    if (!vendor) return toast(`Choose a CLI profile for ${candidate.ip}. We cannot identify its vendor from an open management port alone.`, true);
    if (vendor !== 'cisco_ios' && transport === 'telnet') return toast(`${candidate.ip} is set to Telnet, but this project currently supports Telnet only for Cisco IOS. Choose SSH or a Cisco profile.`, true);
    selected.push({
      id: `discovered-${candidate.ip.replaceAll('.', '-')}`,
      name, ip: candidate.ip, vendor, model: '', location: '',
      transport, port: Number(rawPort), enabled: true,
    });
    existingIps.add(candidate.ip);
  }
  if (!selected.length) return toast('All selected addresses are already in the inventory.', true);
  inventory.push(...selected);
  try {
    await saveInventory(true);
    discoveredHosts = discoveredHosts.map(host => ({...host, already_in_inventory: existingIps.has(host.ip)}));
    const detail = $('#discovery-detail').textContent;
    renderDiscoveryResults({
      network: detail.split(' · ')[0],
      scanned_hosts: Number((detail.match(/· (\d+) host addresses checked/) || [])[1] || 0),
      found_count: discoveredHosts.length,
      ports_checked: [22, 23],
      hosts: discoveredHosts,
    });
    toast(`Added ${selected.length} device(s). Verify their vendor profile and name before collection.`);
  } catch (err) {
    inventory = inventory.filter(item => !selected.some(added => added.ip === item.ip));
    renderInventory();
    toast(err.message, true);
  }
}
function exportCsv() {
  readTableIntoInventory();
  const headers = ['name','ip','vendor','model','location','transport','port','enabled'];
  const quote = value => `"${String(value ?? '').replace(/"/g,'""')}"`;
  const content = [headers.join(','), ...inventory.map(row => headers.map(h => quote(row[h])).join(','))].join('\r\n');
  const blob = new Blob([content], {type:'text/csv;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'switchscribe-inventory.csv'; anchor.click(); URL.revokeObjectURL(url);
}

$('#inventory-body').addEventListener('click', event => {
  const button = event.target.closest('.delete-row');
  if (!button) return;
  const row = button.closest('tr');
  readTableIntoInventory();
  const index = Number(row.dataset.index);
  const name = inventory[index]?.name || 'this switch';
  if (confirm(`Remove ${name} from the inventory?`)) { inventory.splice(index, 1); renderInventory(); }
});
document.querySelectorAll('.tab').forEach(button => button.addEventListener('click', () => setTab(button.dataset.tab)));
$('#inventory-search').addEventListener('input', () => { readTableIntoInventory(); renderInventory(); });
$('#add-switch').addEventListener('click', () => {
  readTableIntoInventory();
  inventory.push({id:`new-${Date.now()}`,name:'New switch',ip:'192.0.2.10',transport:'ssh',port:22,vendor:'cisco_ios',model:'',location:'',enabled:true});
  renderInventory();
  $('#inventory-body tr:last-child input[data-field="name"]')?.focus();
});
$('#inventory-body').addEventListener('change', event => {
  const control = event.target;
  const row = control.closest('tr');
  if (!row) return;
  const transport = row.querySelector('[data-field="transport"]');
  const portInput = row.querySelector('[data-field="port"]');
  if (control.dataset.field === 'vendor') {
    const telnetOption = transport?.querySelector('option[value="telnet"]');
    if (telnetOption) telnetOption.disabled = control.value !== 'cisco_ios';
    if (control.value !== 'cisco_ios' && transport?.value === 'telnet') {
      transport.value = 'ssh';
      if (portInput) portInput.value = 22;
    }
    return;
  }
  if (control.dataset.field === 'transport' && portInput) {
    portInput.value = control.value === 'telnet' ? 23 : 22;
  }
});
$('#save-inventory').addEventListener('click', () => saveInventory().catch(err => toast(err.message, true)));
$('#export-csv').addEventListener('click', exportCsv);
$('#discover-button').addEventListener('click', discoverNetwork);
$('#add-discovered').addEventListener('click', addDiscoveredToInventory);
$('#run-button').addEventListener('click', startRun);
$('#csv-file').addEventListener('change', async event => {
  const file = event.target.files?.[0];
  if (!file) return;
  try {
    const form = new FormData(); form.append('file', file);
    const response = await fetch('/api/inventory/import', {method:'POST',body:form});
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'CSV import failed.');
    inventory = data.switches; renderInventory(); toast(`Imported ${data.count} switches.`);
  } catch (err) { toast(err.message, true); }
  event.target.value = '';
});
loadInventory().catch(err => toast(err.message, true));
