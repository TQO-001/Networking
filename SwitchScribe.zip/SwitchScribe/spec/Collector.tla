---------------- MODULE Collector ----------------
EXTENDS Naturals, FiniteSets, Sequences

CONSTANTS Devices, SafeCommands, MaxWorkers, SupportedTransports

ASSUME Devices # {}
ASSUME MaxWorkers \in Nat \ {0}
ASSUME SupportedTransports = {"ssh", "telnet"}

VARIABLES state, selectedDevices, selectedCommands, selectedTransports,
          completedDevices, activeDevices, failedDevices

vars == <<state, selectedDevices, selectedCommands, selectedTransports,
          completedDevices, activeDevices, failedDevices>>

Init ==
    /\ state = "Idle"
    /\ selectedDevices = {}
    /\ selectedCommands = {}
    /\ selectedTransports = {}
    /\ completedDevices = {}
    /\ activeDevices = {}
    /\ failedDevices = {}

Start(devices, commands, transports) ==
    /\ state \in {"Idle", "Completed"}
    /\ devices \subseteq Devices
    /\ devices # {}
    /\ commands \subseteq SafeCommands
    /\ commands # {}
    /\ transports \subseteq devices \X SupportedTransports
    /\ \A device \in devices:
          Cardinality({transport \in SupportedTransports:
                       <<device, transport>> \in transports}) = 1
    /\ selectedDevices' = devices
    /\ selectedCommands' = commands
    /\ selectedTransports' = transports
    /\ completedDevices' = {}
    /\ activeDevices' = {}
    /\ failedDevices' = {}
    /\ state' = "Running"

BeginDevice(device) ==
    /\ state = "Running"
    /\ device \in selectedDevices \ completedDevices
    /\ device \notin activeDevices
    /\ Cardinality(activeDevices) < MaxWorkers
    /\ activeDevices' = activeDevices \cup {device}
    /\ UNCHANGED <<state, selectedDevices, selectedCommands,
                    selectedTransports, completedDevices, failedDevices>>

FinishDevice(device) ==
    /\ state = "Running"
    /\ device \in activeDevices
    /\ activeDevices' = activeDevices \ {device}
    /\ completedDevices' = completedDevices \cup {device}
    /\ UNCHANGED <<state, selectedDevices, selectedCommands,
                    selectedTransports, failedDevices>>

FailDevice(device) ==
    /\ state = "Running"
    /\ device \in activeDevices
    /\ activeDevices' = activeDevices \ {device}
    /\ completedDevices' = completedDevices \cup {device}
    /\ failedDevices' = failedDevices \cup {device}
    /\ UNCHANGED <<state, selectedDevices, selectedCommands,
                    selectedTransports>>

FinishRun ==
    /\ state = "Running"
    /\ completedDevices = selectedDevices
    /\ activeDevices = {}
    /\ state' = "Completed"
    /\ UNCHANGED <<selectedDevices, selectedCommands, selectedTransports,
                    completedDevices, activeDevices, failedDevices>>

Next ==
    \/ \E devices \in SUBSET Devices, commands \in SUBSET SafeCommands,
          transports \in SUBSET (devices \X SupportedTransports):
          Start(devices, commands, transports)
    \/ \E device \in Devices: BeginDevice(device)
    \/ \E device \in Devices: FinishDevice(device)
    \/ \E device \in Devices: FailDevice(device)
    \/ FinishRun

Spec == Init /\ [][Next]_vars

NoUnsafeCommands == selectedCommands \subseteq SafeCommands
NoDeviceRunsTwice == activeDevices \cap completedDevices = {}
WorkerLimit == Cardinality(activeDevices) <= MaxWorkers
ProgressIsBounded == completedDevices \subseteq selectedDevices
FailedIsCompleted == failedDevices \subseteq completedDevices
SelectedTransportIsValid ==
    \A pair \in selectedTransports: pair[2] \in SupportedTransports
OneTransportPerSwitch ==
    \A device \in selectedDevices:
        Cardinality({transport \in SupportedTransports:
                     <<device, transport>> \in selectedTransports}) = 1

===========================================================
