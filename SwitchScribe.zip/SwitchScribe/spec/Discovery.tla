---------------- MODULE Discovery ----------------
EXTENDS Naturals, FiniteSets

CONSTANTS PrivateHosts, ManagementPorts, MaxHosts

ASSUME PrivateHosts # {}
ASSUME ManagementPorts = {22, 23}
ASSUME MaxHosts \in Nat \ {0}
ASSUME MaxHosts <= 256

VARIABLES state, authorized, requestedHosts, checkedHosts, discoveredHosts, checkedPorts

vars == <<state, authorized, requestedHosts, checkedHosts, discoveredHosts, checkedPorts>>

Init ==
    /\ state = "Idle"
    /\ authorized = FALSE
    /\ requestedHosts = {}
    /\ checkedHosts = {}
    /\ discoveredHosts = {}
    /\ checkedPorts = {}

StartDiscovery(hosts, approval) ==
    /\ state \in {"Idle", "Complete"}
    /\ approval = TRUE
    /\ hosts \subseteq PrivateHosts
    /\ hosts # {}
    /\ Cardinality(hosts) <= MaxHosts
    /\ state' = "Scanning"
    /\ authorized' = TRUE
    /\ requestedHosts' = hosts
    /\ checkedHosts' = {}
    /\ discoveredHosts' = {}
    /\ checkedPorts' = {}

RecordHost(host, openPorts) ==
    /\ state = "Scanning"
    /\ authorized = TRUE
    /\ host \in requestedHosts \ checkedHosts
    /\ openPorts \subseteq ManagementPorts
    /\ checkedHosts' = checkedHosts \cup {host}
    /\ discoveredHosts' = IF openPorts # {} THEN discoveredHosts \cup {host} ELSE discoveredHosts
    /\ checkedPorts' = checkedPorts \cup openPorts
    /\ UNCHANGED <<state, authorized, requestedHosts>>

FinishDiscovery ==
    /\ state = "Scanning"
    /\ checkedHosts = requestedHosts
    /\ state' = "Complete"
    /\ authorized' = FALSE
    /\ UNCHANGED <<requestedHosts, checkedHosts, discoveredHosts, checkedPorts>>

Next ==
    \/ \E hosts \in SUBSET PrivateHosts, approval \in BOOLEAN: StartDiscovery(hosts, approval)
    \/ \E host \in PrivateHosts, openPorts \in SUBSET ManagementPorts: RecordHost(host, openPorts)
    \/ FinishDiscovery

Spec == Init /\ [][Next]_vars

AuthorizationRequired == state = "Scanning" => authorized = TRUE
PrivateScopeOnly == requestedHosts \subseteq PrivateHosts
DiscoveryBounded == Cardinality(requestedHosts) <= MaxHosts
OnlyManagementPorts == checkedPorts \subseteq ManagementPorts
FoundHostsWereChecked == discoveredHosts \subseteq checkedHosts

===========================================================
