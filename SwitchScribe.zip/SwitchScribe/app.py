from __future__ import annotations

import threading
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, request, send_from_directory

from collector.commands import COMMAND_GROUPS, DEFAULT_GROUPS, validate_custom_commands
from collector.discovery import discover_management_hosts, validate_discovery_network
from collector.driver import collect_one
from collector.inventory import load_inventory, load_csv_text, save_inventory
from collector.report import generate_markdown

ROOT = Path(__file__).resolve().parent
app = Flask(__name__, static_folder="static", static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024
JOBS: dict[str, dict[str, Any]] = {}
JOBS_LOCK = threading.Lock()


def _public_job(job: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": job["id"], "state": job["state"], "total": job["total"],
        "completed": job["completed"], "started_at": job["started_at"],
        "finished_at": job.get("finished_at"), "summary": job.get("summary", {}),
        "devices": [{
            "name": x["target"]["name"], "ip": x["target"]["ip"],
            "status": x["status"], "duration_seconds": x.get("duration_seconds", 0),
            "error": x.get("error", ""), "neighbors": len(x.get("neighbors", [])),
            "transport": x["target"].get("transport", "ssh"),
            "connection_method": x.get("connection_method", ""),
        } for x in job.get("results", [])],
    }


def _run_job(job_id: str, targets: list[dict[str, Any]], username: str, password: str,
             secret: str, timeout: int, workers: int, selected_groups: list[str],
             custom_commands: list[str] | dict[str, list[str]]) -> None:
    with JOBS_LOCK:
        job = JOBS[job_id]
        job["state"] = "running"
    results: list[dict[str, Any]] = []
    try:
        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="switch-collector") as pool:
            futures = {
                pool.submit(collect_one, target, username, password, secret, timeout, selected_groups, custom_commands): target
                for target in targets
            }
            for future in as_completed(futures):
                target = futures[future]
                try:
                    result = future.result()
                except Exception as exc:  # last-resort isolation: one worker must not stop the run
                    result = {"target": target, "status": "failed", "outputs": [], "neighbors": [],
                              "interfaces": {}, "vlans": {}, "model": target.get("model") or "",
                              "error": f"Worker error: {type(exc).__name__}: {exc}", "duration_seconds": 0.0}
                results.append(result)
                with JOBS_LOCK:
                    JOBS[job_id]["completed"] += 1
                    JOBS[job_id]["results"] = sorted(results, key=lambda x: x["target"]["name"].casefold())
        results.sort(key=lambda x: x["target"]["name"].casefold())
        report = generate_markdown(results, selected_groups, custom_commands)
        success = sum(x["status"] == "success" for x in results)
        partial = sum(x["status"] == "partial" for x in results)
        failed = sum(x["status"] == "failed" for x in results)
        with JOBS_LOCK:
            JOBS[job_id].update({
                "state": "completed", "results": results, "report": report,
                "finished_at": datetime.now(timezone.utc).isoformat(),
                "summary": {"success": success, "partial": partial, "failed": failed},
            })
    except Exception as exc:
        with JOBS_LOCK:
            JOBS[job_id].update({
                "state": "failed", "fatal_error": f"{type(exc).__name__}: {exc}",
                "finished_at": datetime.now(timezone.utc).isoformat(),
            })
    finally:
        # Avoid retaining credentials in the job registry after the run.
        password = ""
        secret = ""


@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/api/inventory")
def get_inventory():
    return jsonify({"switches": load_inventory()})


@app.put("/api/inventory")
def put_inventory():
    payload = request.get_json(silent=True) or {}
    try:
        items = save_inventory(payload.get("switches", []))
    except (ValueError, OSError) as exc:
        return jsonify({"error": str(exc)}), 400
    return jsonify({"switches": items, "count": len(items)})


@app.post("/api/inventory/import")
def import_inventory():
    if "file" in request.files:
        csv_text = request.files["file"].read().decode("utf-8-sig")
    else:
        payload = request.get_json(silent=True) or {}
        csv_text = str(payload.get("csv", ""))
    try:
        items = load_csv_text(csv_text)
        saved = save_inventory(items)
    except (ValueError, UnicodeDecodeError, OSError) as exc:
        return jsonify({"error": str(exc)}), 400
    return jsonify({"switches": saved, "count": len(saved)})


@app.post("/api/discover")
def discover_network():
    """Find unlisted hosts exposing the standard SSH/Telnet management ports.

    This endpoint requires an explicit authorization acknowledgement and only
    accepts RFC1918 IPv4 networks of at most 256 addresses. It never logs in.
    """
    payload = request.get_json(silent=True) or {}
    if payload.get("authorized") is not True:
        return jsonify({"error": "Confirm that you are authorized to check this network before starting discovery."}), 400
    try:
        network = validate_discovery_network(str(payload.get("cidr", "")))
        timeout = max(0.15, min(float(payload.get("timeout", 0.35)), 1.0))
        result = discover_management_hosts(str(network), timeout)
        known_ips = {item["ip"] for item in load_inventory()}
        for host in result["hosts"]:
            host["already_in_inventory"] = host["ip"] in known_ips
    except (ValueError, TypeError, OSError) as exc:
        return jsonify({"error": str(exc)}), 400
    return jsonify(result)


@app.get("/api/commands")
def get_commands():
    return jsonify({"groups": [
        {"id": key, "label": value["label"], "description": value["description"]}
        for key, value in COMMAND_GROUPS.items()
    ], "defaults": DEFAULT_GROUPS})


@app.post("/api/run")
def run_collection():
    payload = request.get_json(silent=True) or {}
    username = str(payload.get("username", "")).strip()
    password = str(payload.get("password", ""))
    secret = str(payload.get("secret", ""))
    if not username or not password:
        return jsonify({"error": "Connection username and password are required for this run."}), 400
    try:
        timeout = max(5, min(int(payload.get("timeout", 10)), 45))
        workers = max(1, min(int(payload.get("workers", 4)), 8))
    except (TypeError, ValueError):
        return jsonify({"error": "Timeout and worker count must be whole numbers."}), 400
    selected_groups = payload.get("groups", DEFAULT_GROUPS)
    if not isinstance(selected_groups, list):
        return jsonify({"error": "Command groups must be a list."}), 400
    if any(not isinstance(group, str) or group not in COMMAND_GROUPS for group in selected_groups):
        return jsonify({"error": "The selected command group list contains an unsupported entry."}), 400
    try:
        custom_commands = validate_custom_commands(payload.get("custom_commands", []))
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    has_custom_commands = bool(custom_commands) and (
        any(custom_commands.values()) if isinstance(custom_commands, dict) else bool(custom_commands)
    )
    if not selected_groups and not has_custom_commands:
        return jsonify({"error": "Select at least one built-in command group or enter a profile-specific custom show command."}), 400
    inventory = load_inventory()
    targets = [item for item in inventory if item.get("enabled", True)]
    if not targets:
        return jsonify({"error": "There are no enabled switches in the inventory."}), 400
    job_id = uuid.uuid4().hex
    job = {
        "id": job_id, "state": "queued", "total": len(targets), "completed": 0,
        "started_at": datetime.now(timezone.utc).isoformat(), "finished_at": None,
        "summary": {}, "results": [], "report": "",
        "selected_groups": selected_groups, "custom_commands": custom_commands,
    }
    with JOBS_LOCK:
        JOBS[job_id] = job
        # Keep the in-memory registry bounded; never remove a running job.
        completed_ids = [key for key, value in JOBS.items() if value["state"] in {"completed", "failed"}]
        for old_id in completed_ids[:-8]:
            JOBS.pop(old_id, None)
    thread = threading.Thread(
        target=_run_job,
        args=(job_id, targets, username, password, secret, timeout, workers, selected_groups, custom_commands),
        daemon=True, name=f"switchscribe-{job_id[:8]}",
    )
    thread.start()
    return jsonify({"job_id": job_id, "total": len(targets)}), 202


@app.get("/api/jobs/<job_id>")
def get_job(job_id: str):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job:
            return jsonify({"error": "Job not found. It may have expired after a server restart."}), 404
        return jsonify(_public_job(job))


@app.get("/api/jobs/<job_id>/report.md")
def download_report(job_id: str):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job:
            return jsonify({"error": "Job not found."}), 404
        if job["state"] != "completed":
            return jsonify({"error": "The report is not ready yet."}), 409
        report = job["report"]
    return app.response_class(
        report, mimetype="text/markdown; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="switchscribe-{job_id[:8]}.md"'},
    )


@app.get("/api/jobs/<job_id>/report.json")
def download_json(job_id: str):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job:
            return jsonify({"error": "Job not found."}), 404
        if job["state"] != "completed":
            return jsonify({"error": "The export is not ready yet."}), 409
        results = job["results"]
    return jsonify({"generated_at": datetime.now(timezone.utc).isoformat(), "results": results})


if __name__ == "__main__":
    print("SwitchScribe is starting on http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, threaded=True, debug=False, use_reloader=False)
