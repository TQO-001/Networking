from network_tools.services.logs import analyse_log_text


def test_log_analysis_counts_severity_and_link_events():
    result = analyse_log_text("INFO link up\nWARNING packet loss\nERROR link down\n")
    assert result["total_lines"] == 3
    assert result["severity_counts"]["warning"] == 1
    assert result["severity_counts"]["error"] == 1
    assert [event["event"] for event in result["link_events"]] == ["link-up", "link-down"]
