from network_tools.services.subnet import calculate_subnet


def test_ipv4_subnet_summary():
    result = calculate_subnet("192.168.10.25/24")
    assert result["network"] == "192.168.10.0/24"
    assert result["first_usable"] == "192.168.10.1"
    assert result["last_usable"] == "192.168.10.254"
    assert result["usable_addresses"] == 254


def test_ipv6_has_no_broadcast_address():
    result = calculate_subnet("2001:db8::7/64")
    assert result["broadcast_address"] is None
    assert result["version"] == "IPv6"


def test_ipv4_point_to_point_prefix():
    result = calculate_subnet("192.0.2.0/31")
    assert result["usable_addresses"] == 2
