from network_tools.services.inventory import validate_inventory


def test_inventory_detects_invalid_and_duplicate_addresses():
    sample = "hostname,ip_address,role,vlan\nPLC-01,192.0.2.10,PLC,10\nHMI-01,192.0.2.10,HMI,20\nSW-01,not-an-ip,Switch,5000\n"
    result = validate_inventory(sample)
    assert result["total_rows"] == 3
    assert result["valid_rows"] == 1
    assert result["invalid_rows"] == 2
    assert result["issue_count"] >= 3
