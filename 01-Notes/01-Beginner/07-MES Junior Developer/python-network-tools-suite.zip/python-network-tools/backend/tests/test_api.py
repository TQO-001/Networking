from fastapi.testclient import TestClient

from network_tools.main import app

client = TestClient(app)


def test_health_endpoint():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_subnet_endpoint():
    response = client.post("/api/subnets/calculate", json={"cidr": "10.10.5.20/24"})
    assert response.status_code == 200
    assert response.json()["network"] == "10.10.5.0/24"


def test_inventory_endpoint():
    csv_text = "hostname,ip_address,role,vlan\nPLC-01,192.0.2.10,PLC,10\n"
    response = client.post("/api/inventory/validate", json={"csv_text": csv_text})
    assert response.status_code == 200
    assert response.json()["valid_rows"] == 1


def test_log_endpoint():
    response = client.post("/api/logs/analyze", json={"text": "ERROR link down\n"})
    assert response.status_code == 200
    assert response.json()["link_events"][0]["event"] == "link-down"


def test_demo_protocol_endpoints_do_not_connect_to_devices():
    opc = client.post("/api/opcua/read", json={"endpoint": "opc.tcp://127.0.0.1:4840", "node_ids": ["ns=2;s=Demo"], "demo_mode": True})
    modbus = client.post("/api/modbus/read", json={"demo_mode": True})
    assert opc.status_code == 200 and opc.json()["demo_mode"] is True
    assert modbus.status_code == 200 and modbus.json()["demo_mode"] is True


def test_modbus_rejects_public_target_when_not_in_demo_mode():
    response = client.post("/api/modbus/read", json={"host": "8.8.8.8", "demo_mode": False})
    assert response.status_code == 422


def test_pcap_endpoint_rejects_non_capture_file():
    response = client.post(
        "/api/pcap/analyze",
        files={"file": ("notes.txt", b"not a capture", "text/plain")},
    )
    assert response.status_code == 415


def test_interfaces_endpoint_returns_a_snapshot():
    response = client.get("/api/interfaces/snapshot")
    assert response.status_code == 200
    assert "interfaces" in response.json()
