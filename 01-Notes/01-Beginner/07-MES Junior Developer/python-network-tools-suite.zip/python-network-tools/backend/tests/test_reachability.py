import pytest

from network_tools.services.targets import require_lab_ip


def test_private_lab_address_is_allowed():
    assert require_lab_ip("192.168.1.10") == "192.168.1.10"


@pytest.mark.parametrize("host", ["example.com", "8.8.8.8", "224.0.0.1", "0.0.0.0"])
def test_non_lab_target_is_rejected(host):
    with pytest.raises(ValueError):
        require_lab_ip(host)
