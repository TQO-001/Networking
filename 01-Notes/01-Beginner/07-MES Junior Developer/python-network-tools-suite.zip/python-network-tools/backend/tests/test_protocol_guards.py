import pytest

from network_tools.services.opcua import validate_opc_endpoint
from network_tools.services.modbus import validate_modbus_target


def test_opcua_local_lab_endpoint_is_allowed():
    assert validate_opc_endpoint("opc.tcp://127.0.0.1:4840")


def test_opcua_public_endpoint_is_rejected():
    with pytest.raises(ValueError):
        validate_opc_endpoint("opc.tcp://8.8.8.8:4840")


def test_modbus_target_requires_private_ip():
    assert validate_modbus_target("10.0.0.20") == "10.0.0.20"
    with pytest.raises(ValueError):
        validate_modbus_target("public.example.com")
