from pathlib import Path

import pytest

from network_tools.services.pcap import summarize_capture


def test_demo_capture_is_readable_when_scapy_is_installed():
    pytest.importorskip("scapy")
    capture = Path(__file__).parent / "fixtures" / "demo.pcap"
    result = summarize_capture(capture.read_bytes())
    assert result["packet_count"] == 3
    assert {row["name"] for row in result["protocols"]} == {"UDP", "TCP", "ICMP"}
    assert result["payloads_included"] is False
