from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from network_tools.services.inventory import validate_inventory

router = APIRouter(prefix="/inventory", tags=["inventory"])


class InventoryRequest(BaseModel):
    csv_text: str = Field(min_length=1, max_length=1_000_000)


@router.post("/validate")
def validate(payload: InventoryRequest) -> dict[str, object]:
    try:
        return validate_inventory(payload.csv_text)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
