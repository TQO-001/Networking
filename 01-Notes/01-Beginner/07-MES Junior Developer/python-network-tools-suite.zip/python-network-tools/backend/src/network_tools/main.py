from __future__ import annotations

import os
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from network_tools.routers import interfaces, inventory, logs, modbus, opcua, pcap, reachability, subnet

app = FastAPI(
    title="Python Network Tools API",
    description=(
        "A lab-first collection of read-only networking tools. "
        "The API never performs subnet-wide discovery or writes to industrial devices."
    ),
    version="0.2.0",
)

origins = [
    value.strip()
    for value in os.getenv(
        "NETWORK_TOOLS_CORS_ORIGINS",
        "http://localhost:5173,http://127.0.0.1:5173",
    ).split(",")
    if value.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)

for router in (
    subnet.router,
    inventory.router,
    reachability.router,
    interfaces.router,
    logs.router,
    pcap.router,
    opcua.router,
    modbus.router,
):
    app.include_router(router, prefix="/api")


@app.get("/api/health", tags=["health"])
def health() -> dict[str, str]:
    return {"status": "ok", "service": "python-network-tools"}


# In production, `npm run build` creates frontend/dist. The FastAPI process can
# serve those static files from the same origin. During development, Vite proxies
# /api requests to port 8000 and serves the React app on port 5173.
frontend_dist = Path(__file__).resolve().parents[3] / "frontend" / "dist"
if frontend_dist.is_dir():
    app.mount("/", StaticFiles(directory=frontend_dist, html=True), name="frontend")
