from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from network_tools.services.logs import analyse_log_text

router = APIRouter(prefix="/logs", tags=["logs"])


class LogRequest(BaseModel):
    text: str = Field(min_length=1, max_length=1_000_000)


@router.post("/analyze")
def analyze(payload: LogRequest) -> dict[str, object]:
    try:
        return analyse_log_text(payload.text)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
