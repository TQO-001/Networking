from __future__ import annotations

import re
from collections import Counter

SEVERITY_PATTERNS = {
    "critical": re.compile(r"\b(critical|emergency|panic|fatal)\b", re.I),
    "error": re.compile(r"\b(error|err|failed|failure)\b", re.I),
    "warning": re.compile(r"\b(warn|warning)\b", re.I),
    "debug": re.compile(r"\b(debug|trace)\b", re.I),
}


def analyse_log_text(text: str) -> dict[str, object]:
    if not text.strip():
        raise ValueError("Paste or load a log sample before analysing it.")
    lines = text.splitlines()
    if len(lines) > 10_000:
        raise ValueError("The sample is limited to 10,000 lines.")
    counts: Counter[str] = Counter()
    events: list[dict[str, object]] = []
    for line_number, line in enumerate(lines, start=1):
        lowered = line.lower()
        severity = next((name for name, pattern in SEVERITY_PATTERNS.items() if pattern.search(line)), "info")
        counts[severity] += 1
        event = None
        if any(token in lowered for token in ("link down", "interface down", "carrier lost")):
            event = "link-down"
        elif any(token in lowered for token in ("link up", "interface up", "carrier restored")):
            event = "link-up"
        if event:
            events.append({"line": line_number, "event": event, "message": line[:500]})
    return {
        "total_lines": len(lines),
        "severity_counts": {key: counts.get(key, 0) for key in ("critical", "error", "warning", "info", "debug")},
        "link_events": events,
        "lines": [
            {"line": index, "severity": next((name for name, pattern in SEVERITY_PATTERNS.items() if pattern.search(line)), "info"), "message": line[:500]}
            for index, line in enumerate(lines, start=1)
        ],
    }
