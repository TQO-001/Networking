from __future__ import annotations

import socket
import time
from datetime import datetime, timezone
from threading import Lock

_previous: dict[str, tuple[float, int, int]] = {}
_lock = Lock()


def interface_snapshot() -> dict[str, object]:
    try:
        import psutil
    except ImportError as exc:
        raise RuntimeError("Install project dependencies with `uv sync` to use psutil.") from exc

    addresses = psutil.net_if_addrs()
    stats = psutil.net_if_stats()
    counters = psutil.net_io_counters(pernic=True) or {}
    now = time.monotonic()
    rows: list[dict[str, object]] = []
    with _lock:
        for name in sorted(set(addresses) | set(stats) | set(counters)):
            stat = stats.get(name)
            count = counters.get(name)
            addr_rows = []
            for address in addresses.get(name, []):
                family = "IPv4" if address.family == socket.AF_INET else "IPv6" if address.family == socket.AF_INET6 else "Other"
                if family != "Other":
                    addr_rows.append({"family": family, "address": address.address.split("%", 1)[0]})
            sent = int(getattr(count, "bytes_sent", 0))
            received = int(getattr(count, "bytes_recv", 0))
            prior = _previous.get(name)
            tx_rate = rx_rate = None
            if prior:
                prior_time, prior_sent, prior_received = prior
                elapsed = now - prior_time
                if elapsed > 0 and sent >= prior_sent and received >= prior_received:
                    tx_rate = round((sent - prior_sent) / elapsed, 2)
                    rx_rate = round((received - prior_received) / elapsed, 2)
            _previous[name] = (now, sent, received)
            rows.append({
                "name": name,
                "is_up": bool(stat.isup) if stat else None,
                "speed_mbps": int(stat.speed) if stat and stat.speed else None,
                "mtu": int(stat.mtu) if stat and stat.mtu else None,
                "addresses": addr_rows,
                "bytes_sent": sent,
                "bytes_received": received,
                "packets_sent": int(getattr(count, "packets_sent", 0)),
                "packets_received": int(getattr(count, "packets_recv", 0)),
                "errors_in": int(getattr(count, "errin", 0)),
                "errors_out": int(getattr(count, "errout", 0)),
                "drops_in": int(getattr(count, "dropin", 0)),
                "drops_out": int(getattr(count, "dropout", 0)),
                "tx_bytes_per_second": tx_rate,
                "rx_bytes_per_second": rx_rate,
            })
    return {"sampled_at": datetime.now(timezone.utc).isoformat(), "interface_count": len(rows), "interfaces": rows}
