from fastapi import APIRouter, HTTPException

from network_tools.services.interfaces import interface_snapshot

router = APIRouter(prefix="/interfaces", tags=["interfaces"])


@router.get("/snapshot")
def snapshot() -> dict[str, object]:
    try:
        return interface_snapshot()
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
