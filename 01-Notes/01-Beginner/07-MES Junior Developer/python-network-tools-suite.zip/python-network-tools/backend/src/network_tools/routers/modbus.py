from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from network_tools.services.modbus import read_holding_registers

router = APIRouter(prefix="/modbus", tags=["modbus"])


class ModbusRequest(BaseModel):
    host: str = Field(default="127.0.0.1", min_length=7, max_length=64)
    port: int = Field(default=502, ge=1, le=65535)
    unit_id: int = Field(default=1, ge=1, le=247)
    address: int = Field(default=0, ge=0, le=65535)
    count: int = Field(default=8, ge=1, le=125)
    timeout_seconds: float = Field(default=2.0, ge=0.5, le=5.0)
    demo_mode: bool = True


@router.post("/read")
def read(payload: ModbusRequest) -> dict[str, object]:
    if payload.demo_mode:
        values = [237, 1013, 1, 0, 42, 655, 12, 8][: payload.count]
        return {
            "host": "Local demo data",
            "port": payload.port,
            "unit_id": payload.unit_id,
            "starting_address": payload.address,
            "addressing_note": "PyModbus addresses registers from zero.",
            "registers": [
                {"address": payload.address + offset, "value": value}
                for offset, value in enumerate(values)
            ],
            "read_only": True,
            "demo_mode": True,
        }
    try:
        return read_holding_registers(
            payload.host, payload.port, payload.unit_id, payload.address, payload.count, payload.timeout_seconds
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except ConnectionError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
