from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from network_tools.services.opcua import read_opcua_nodes

router = APIRouter(prefix="/opcua", tags=["opcua"])


class OpcUaRequest(BaseModel):
    endpoint: str = Field(min_length=10, max_length=300)
    node_ids: list[str] = Field(min_length=1, max_length=10)
    timeout_seconds: float = Field(default=3.0, ge=0.5, le=10.0)
    demo_mode: bool = True


@router.post("/read")
async def read_nodes(payload: OpcUaRequest) -> dict[str, object]:
    if payload.demo_mode:
        return {
            "endpoint": "Local demo data",
            "read_only": True,
            "readings": [
                {"node_id": "ns=2;s=Demo.Temperature", "value": 23.7, "status": "Good", "source_timestamp": None},
                {"node_id": "ns=2;s=Demo.Pressure", "value": 101.3, "status": "Good", "source_timestamp": None},
                {"node_id": "ns=2;s=Demo.LineRunning", "value": True, "status": "Good", "source_timestamp": None},
            ],
            "demo_mode": True,
        }
    try:
        result = await read_opcua_nodes(payload.endpoint, payload.node_ids, payload.timeout_seconds)
        result["demo_mode"] = False
        return result
    except (ValueError, TimeoutError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"OPC UA read failed: {exc.__class__.__name__}") from exc
