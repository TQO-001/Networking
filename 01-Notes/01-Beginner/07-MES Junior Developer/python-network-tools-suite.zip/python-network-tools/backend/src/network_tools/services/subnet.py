from __future__ import annotations

import ipaddress


def calculate_subnet(cidr: str) -> dict[str, object]:
    network = ipaddress.ip_network(cidr.strip(), strict=False)
    total = network.num_addresses
    if network.version == 4:
        if network.prefixlen <= 30:
            first = network.network_address + 1
            last = network.broadcast_address - 1
            usable = max(total - 2, 0)
        else:
            first = network.network_address
            last = network.broadcast_address
            usable = total
        broadcast = str(network.broadcast_address)
    else:
        first = network.network_address + 1 if total > 1 else network.network_address
        last = network.broadcast_address
        usable = total - 1 if total > 1 else total
        broadcast = None

    return {
        "input": cidr,
        "version": f"IPv{network.version}",
        "network": str(network),
        "network_address": str(network.network_address),
        "prefix_length": network.prefixlen,
        "subnet_mask": str(network.netmask),
        "broadcast_address": broadcast,
        "first_usable": str(first),
        "last_usable": str(last),
        "total_addresses": total,
        "usable_addresses": usable,
        "is_private": network.is_private,
        "is_multicast": network.is_multicast,
    }
