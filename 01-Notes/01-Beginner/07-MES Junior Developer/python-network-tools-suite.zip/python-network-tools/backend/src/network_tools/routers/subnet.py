from ipaddress import AddressValueError, NetmaskValueError

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from network_tools.services.subnet import calculate_subnet

router = APIRouter(prefix="/subnets", tags=["subnets"])


class SubnetRequest(BaseModel):
    cidr: str = Field(min_length=3, max_length=80)


@router.post("/calculate")
def calculate(payload: SubnetRequest) -> dict[str, object]:
    try:
        return calculate_subnet(payload.cidr)
    except (ValueError, AddressValueError, NetmaskValueError) as exc:
        raise HTTPException(status_code=422, detail=f"Enter a valid IPv4 or IPv6 CIDR: {exc}") from exc
