from __future__ import annotations

import ipaddress


def validate_modbus_target(host: str) -> str:
    try:
        address = ipaddress.ip_address(host.strip())
    except ValueError as exc:
        raise ValueError("Use a literal IP address for a local or approved private lab simulator.") from exc
    if not (address.is_private or address.is_loopback or address.is_link_local) or address.is_multicast:
        raise ValueError("Modbus connections are limited to private or loopback lab addresses.")
    return str(address)


def read_holding_registers(
    host: str, port: int, unit_id: int, address: int, count: int, timeout_seconds: float
) -> dict[str, object]:
    safe_host = validate_modbus_target(host)
    try:
        from pymodbus.client import ModbusTcpClient
    except ImportError as exc:
        raise RuntimeError("Install project dependencies with `uv sync` to use PyModbus.") from exc

    client = ModbusTcpClient(safe_host, port=port, timeout=timeout_seconds)
    try:
        if not client.connect():
            raise ConnectionError("Could not connect to the Modbus TCP simulator.")
        # PyModbus 3.13+ uses device_id (not the older slave keyword).
        response = client.read_holding_registers(
            address=address, count=count, device_id=unit_id
        )
        if response.isError():
            raise RuntimeError(f"Modbus exception response: {response}")
        return {
            "host": safe_host,
            "port": port,
            "unit_id": unit_id,
            "starting_address": address,
            "addressing_note": "PyModbus addresses registers from zero.",
            "registers": [
                {"address": address + offset, "value": value}
                for offset, value in enumerate(response.registers)
            ],
            "read_only": True,
            "demo_mode": False,
        }
    finally:
        client.close()
