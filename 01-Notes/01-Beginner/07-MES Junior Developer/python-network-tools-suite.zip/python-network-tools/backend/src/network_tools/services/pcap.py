from __future__ import annotations

import io
from collections import Counter

MAX_CAPTURE_BYTES = 10 * 1024 * 1024
MAX_PACKETS = 20_000


def summarize_capture(data: bytes) -> dict[str, object]:
    if not data:
        raise ValueError("The capture file is empty.")
    if len(data) > MAX_CAPTURE_BYTES:
        raise ValueError(f"Capture files are limited to {MAX_CAPTURE_BYTES // (1024 * 1024)} MB.")
    try:
        from scapy.all import IP, IPv6, TCP, UDP, ICMP
        from scapy.utils import PcapReader
    except ImportError as exc:
        raise RuntimeError("Install project dependencies with `uv sync` to use Scapy.") from exc

    packet_count = 0
    total_bytes = 0
    protocols: Counter[str] = Counter()
    endpoints: Counter[str] = Counter()
    timeline: list[dict[str, object]] = []
    try:
        reader = PcapReader(io.BytesIO(data))
        try:
            for packet in reader:
                packet_count += 1
                if packet_count > MAX_PACKETS:
                    raise ValueError(f"Capture files are limited to {MAX_PACKETS:,} packets.")
                length = len(packet)
                total_bytes += length
                if IP in packet:
                    layer = packet[IP]
                    endpoints[f"{layer.src} → {layer.dst}"] += 1
                elif IPv6 in packet:
                    layer = packet[IPv6]
                    endpoints[f"{layer.src} → {layer.dst}"] += 1
                if TCP in packet:
                    protocols["TCP"] += 1
                elif UDP in packet:
                    protocols["UDP"] += 1
                elif ICMP in packet:
                    protocols["ICMP"] += 1
                elif IP in packet or IPv6 in packet:
                    protocols["Other IP"] += 1
                else:
                    protocols["Non-IP"] += 1
                if len(timeline) < 30:
                    try:
                        timestamp = float(packet.time)
                    except (AttributeError, TypeError, ValueError):
                        timestamp = None
                    timeline.append({"packet": packet_count, "length": length, "timestamp": timestamp})
        finally:
            reader.close()
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError("Scapy could not parse this PCAP/PCAPNG file. Check the file and try again.") from exc

    return {
        "packet_count": packet_count,
        "total_bytes": total_bytes,
        "average_packet_bytes": round(total_bytes / packet_count, 2) if packet_count else 0,
        "protocols": [{"name": name, "count": count} for name, count in protocols.most_common()],
        "conversations": [{"name": name, "count": count} for name, count in endpoints.most_common(12)],
        "timeline": timeline,
        "payloads_included": False,
    }
