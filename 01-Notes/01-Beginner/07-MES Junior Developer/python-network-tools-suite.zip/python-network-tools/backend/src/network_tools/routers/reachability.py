from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from network_tools.services.reachability import check_tcp_target

router = APIRouter(prefix="/reachability", tags=["reachability"])


class ReachabilityRequest(BaseModel):
    host: str = Field(min_length=2, max_length=64)
    port: int = Field(ge=1, le=65535)
    timeout_seconds: float = Field(default=1.5, ge=0.2, le=3.0)


@router.post("/check")
def check(payload: ReachabilityRequest) -> dict[str, object]:
    try:
        return check_tcp_target(payload.host, payload.port, payload.timeout_seconds)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
