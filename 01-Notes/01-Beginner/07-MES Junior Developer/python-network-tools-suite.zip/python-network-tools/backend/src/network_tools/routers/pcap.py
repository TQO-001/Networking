from fastapi import APIRouter, File, HTTPException, UploadFile

from network_tools.services.pcap import MAX_CAPTURE_BYTES, summarize_capture

router = APIRouter(prefix="/pcap", tags=["pcap"])


@router.post("/analyze")
async def analyze(file: UploadFile = File(...)) -> dict[str, object]:
    filename = (file.filename or "").lower()
    if not (filename.endswith(".pcap") or filename.endswith(".pcapng")):
        raise HTTPException(status_code=415, detail="Upload a .pcap or .pcapng file.")
    data = await file.read(MAX_CAPTURE_BYTES + 1)
    await file.close()
    if len(data) > MAX_CAPTURE_BYTES:
        raise HTTPException(status_code=413, detail="Capture files are limited to 10 MB.")
    try:
        return summarize_capture(data)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
