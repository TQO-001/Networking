from __future__ import annotations

import csv
import io
import ipaddress
from collections import Counter

REQUIRED_COLUMNS = {"hostname", "ip_address", "role", "vlan"}


def validate_inventory(csv_text: str) -> dict[str, object]:
    reader = csv.DictReader(io.StringIO(csv_text))
    if not reader.fieldnames:
        raise ValueError("The CSV needs a header row.")
    normalised_headers = {name.strip().lower() for name in reader.fieldnames if name}
    missing = sorted(REQUIRED_COLUMNS - normalised_headers)
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(missing)}")

    seen_ips: set[str] = set()
    rows: list[dict[str, object]] = []
    issues: list[dict[str, object]] = []
    for line_number, raw in enumerate(reader, start=2):
        row = {str(key or "").strip().lower(): str(value or "").strip() for key, value in raw.items()}
        row_issues: list[str] = []
        hostname = row.get("hostname", "")
        ip_text = row.get("ip_address", "")
        role = row.get("role", "")
        vlan_text = row.get("vlan", "")

        if not hostname:
            row_issues.append("Hostname is required")
        if not role:
            row_issues.append("Role is required")
        if not ip_text:
            row_issues.append("IP address is required")
        else:
            try:
                address = ipaddress.ip_address(ip_text)
                normalised_ip = str(address)
                if normalised_ip in seen_ips:
                    row_issues.append(f"Duplicate IP address: {normalised_ip}")
                seen_ips.add(normalised_ip)
            except ValueError:
                row_issues.append(f"Invalid IP address: {ip_text}")
        try:
            vlan = int(vlan_text)
            if not 1 <= vlan <= 4094:
                row_issues.append("VLAN must be between 1 and 4094")
        except ValueError:
            row_issues.append("VLAN must be a whole number")

        record = {
            "line": line_number,
            "hostname": hostname,
            "ip_address": ip_text,
            "role": role,
            "vlan": vlan_text,
            "valid": not row_issues,
            "issues": row_issues,
        }
        rows.append(record)
        for message in row_issues:
            issues.append({"line": line_number, "hostname": hostname or "(unnamed)", "message": message})

    severity = Counter("valid" if row["valid"] else "invalid" for row in rows)
    return {
        "total_rows": len(rows),
        "valid_rows": severity["valid"],
        "invalid_rows": severity["invalid"],
        "issue_count": len(issues),
        "rows": rows,
        "issues": issues,
    }
