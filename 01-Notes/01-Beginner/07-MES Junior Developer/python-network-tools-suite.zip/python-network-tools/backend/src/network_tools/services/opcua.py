from __future__ import annotations

import asyncio
import ipaddress
import re
from urllib.parse import urlparse

NODE_ID_PATTERN = re.compile(r"^(?:ns=\d+;)?(?:i=\d+|s=[A-Za-z0-9_.:/-]{1,180}|g=[0-9a-fA-F-]{36}|b=[A-Za-z0-9+/=]{1,180})$")


def validate_opc_endpoint(endpoint: str) -> str:
    parsed = urlparse(endpoint)
    if parsed.scheme != "opc.tcp" or not parsed.hostname or not parsed.port:
        raise ValueError("Use an endpoint such as opc.tcp://127.0.0.1:4840.")
    if parsed.username or parsed.password:
        raise ValueError("Do not put credentials in the endpoint URL.")
    host = parsed.hostname
    if host.lower() != "localhost":
        try:
            address = ipaddress.ip_address(host)
        except ValueError as exc:
            raise ValueError("Use localhost or a literal private IP address for a lab server.") from exc
        if not (address.is_private or address.is_loopback or address.is_link_local):
            raise ValueError("OPC UA connections are limited to private or loopback lab addresses.")
    return endpoint


async def read_opcua_nodes(endpoint: str, node_ids: list[str], timeout_seconds: float) -> dict[str, object]:
    validate_opc_endpoint(endpoint)
    if not 1 <= len(node_ids) <= 10:
        raise ValueError("Choose between 1 and 10 known node IDs.")
    for node_id in node_ids:
        if not NODE_ID_PATTERN.fullmatch(node_id.strip()):
            raise ValueError(f"Unsupported NodeId format: {node_id}")
    try:
        from asyncua import Client
    except ImportError as exc:
        raise RuntimeError("Install project dependencies with `uv sync` to use asyncua.") from exc

    client = Client(url=endpoint, timeout=timeout_seconds)
    readings: list[dict[str, object]] = []
    try:
        await asyncio.wait_for(client.connect(), timeout=timeout_seconds)
        for node_id in node_ids:
            data_value = await asyncio.wait_for(
                client.get_node(node_id.strip()).read_data_value(), timeout=timeout_seconds
            )
            value = data_value.Value.Value if data_value.Value is not None else None
            status = getattr(data_value, "StatusCode", None)
            source_timestamp = getattr(data_value, "SourceTimestamp", None)
            readings.append({
                "node_id": node_id,
                "value": value if isinstance(value, (str, int, float, bool, type(None))) else str(value),
                "status": str(status) if status is not None else "Unknown",
                "source_timestamp": source_timestamp.isoformat() if source_timestamp else None,
            })
    except asyncio.TimeoutError as exc:
        raise TimeoutError("The OPC UA operation exceeded its timeout.") from exc
    finally:
        try:
            await client.disconnect()
        except Exception:
            pass
    return {"endpoint": endpoint, "readings": readings, "read_only": True}
