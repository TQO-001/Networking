from __future__ import annotations

import socket
import time

from network_tools.services.targets import require_lab_ip


def check_tcp_target(host: str, port: int, timeout_seconds: float = 1.5) -> dict[str, object]:
    """Check one explicitly supplied TCP endpoint. This is not a scanner."""
    safe_host = require_lab_ip(host)
    started = time.perf_counter()
    try:
        with socket.create_connection((safe_host, port), timeout=timeout_seconds):
            elapsed = (time.perf_counter() - started) * 1000
            return {
                "host": safe_host,
                "port": port,
                "reachable": True,
                "latency_ms": round(elapsed, 2),
                "message": "TCP connection succeeded.",
            }
    except (TimeoutError, socket.timeout):
        elapsed = (time.perf_counter() - started) * 1000
        return {
            "host": safe_host,
            "port": port,
            "reachable": False,
            "latency_ms": round(elapsed, 2),
            "message": "Connection timed out. This does not prove the host is offline.",
        }
    except OSError as exc:
        elapsed = (time.perf_counter() - started) * 1000
        return {
            "host": safe_host,
            "port": port,
            "reachable": False,
            "latency_ms": round(elapsed, 2),
            "message": f"Connection failed: {exc.__class__.__name__}",
        }
