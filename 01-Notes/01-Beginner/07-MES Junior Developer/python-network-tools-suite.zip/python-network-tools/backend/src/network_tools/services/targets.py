from __future__ import annotations

import ipaddress


def require_lab_ip(host: str) -> str:
    """Accept only literal loopback/private/link-local IPs; never resolve DNS names."""
    try:
        address = ipaddress.ip_address(host.strip())
    except ValueError as exc:
        raise ValueError("Use a literal IP address for a local or approved private lab target.") from exc
    if address.is_multicast or address.is_unspecified or not (
        address.is_private or address.is_loopback or address.is_link_local
    ):
        raise ValueError("This tool is limited to loopback, private or link-local lab addresses.")
    return str(address)
