# Python Network Tools — FastAPI backend

This backend provides eight small, read-only networking tools for the React dashboard. It is designed for local learning and explicitly approved private lab targets.

## Requirements

- Python 3.14.x
- `uv`
- Windows 11 or a recent Ubuntu/Linux distribution

## Setup

From this directory:

```powershell
uv sync
uv run uvicorn network_tools.main:app --reload --host 127.0.0.1 --port 8000
```

Open API documentation at `http://127.0.0.1:8000/docs`.

Run tests and code checks:

```powershell
uv run pytest
uv run ruff check .
uv run ruff format --check .
```

## Important behaviour

- The reachability endpoint checks one explicitly supplied private/loopback IP and TCP port. It does not accept DNS names, ranges or batch scans.
- Packet capture analysis is offline-only, capped at 10 MB and 20,000 packets, and reports metadata rather than payloads.
- OPC UA and Modbus pages start in demo mode. Live connections are read-only, restricted to loopback/private lab IPs and must be used only with explicit authorization.
- Modbus reads use PyModbus 3.13+ `device_id=` keyword syntax and zero-based register addresses.
- The server binds to loopback by default. Do not expose it to a network without adding authentication, TLS, stricter origin policy and an access-control review.
