# Verification status — 6 November 2026

## Checks completed in the generation environment

- Backend `pytest`: **21 passed, 1 skipped**. The skipped test exercises the bundled PCAP fixture and requires Scapy; Scapy is declared in `pyproject.toml` and the test should run after `uv sync`.
- Python source compilation: `python -m compileall -q src tests` passed.
- Frontend JavaScript/JSX syntax: 12 `.js`/`.jsx` source files parsed with the installed TypeScript parser; no syntax diagnostics.
- `node --check vite.config.js` and `node --check src/api.js` passed.
- Demo packet capture is included in both the frontend public samples and backend test fixtures.
- The full source archive was checked with `unzip -t` after packaging.

## Not completed in the generation environment

- The environment runs Python 3.13.5, while this project intentionally targets Python 3.14.x. Backend tests ran on the available 3.13 interpreter; install and test with Python 3.14 before treating the 3.14 environment as verified.
- `npm install --no-audit --no-fund` timed out. No `node_modules` were produced, so `npm run build` and a real browser-based visual test were not run.
- Ruff is configured in `pyproject.toml`, but Ruff was not available in the generation environment. Run the configured lint and formatter checks locally.
- The parent Astro site's `npm install`, `npm run check` and `npm run build` were not run in this environment.

## Checks to run on your machine

1. Use Python 3.14.x and Node 22.12+.
2. In `backend/`, run `uv sync`, `uv run pytest`, `uv run ruff check .` and `uv run ruff format --check .`.
3. In `frontend/`, run `npm install` and `npm run build`.
4. Start the backend and frontend in separate terminals; verify the API badge turns green.
5. Exercise all eight screens with the built-in sample data. Test form validation, loading states and readable API errors.
6. Test one local TCP endpoint you control. Do not use a production OT endpoint.
7. If you have an approved simulator, test OPC UA/Modbus live reads against it only.
8. Inspect the interface snapshot on both Windows and Linux; available fields differ by platform.
9. Upload a small, authorised offline PCAP and confirm metadata appears without packet payloads.
10. Inspect at mobile width, keyboard-test menus/forms and check browser console errors.
11. From the portfolio root, run `npm install`, `npm run check` and `npm run build`.
12. Before publishing the source repository, review the React Bits license note in `ASSET-CREDITS.md` and replace portrait placeholders with images you have permission to use.

Do not describe the package as production-verified until the outstanding checks pass on the intended machines.
