# Python Network Tools Suite

A single React dashboard with eight independent engineering tools backed by a modular FastAPI application. The interface is consistent across the tools, but each tool has its own page, API route, service module and tests.

## Included tools

1. **Subnet calculator** — IPv4/IPv6 CIDR summary using Python's `ipaddress` module.
2. **OT asset inventory** — CSV validation for required fields, addresses, duplicate IPs and VLAN IDs.
3. **Reachability monitor** — one explicit TCP host/port check per request; private and loopback IPs only.
4. **Interface health** — local interface state, addresses, counters, errors, drops and sampled rates using psutil.
5. **Log analyser** — severity counts and simple link-state event extraction from pasted/synthetic logs.
6. **Packet capture analyser** — offline PCAP/PCAPNG metadata summary using Scapy; no live capture or payload display.
7. **OPC UA monitor** — demo telemetry by default; optional read-only node reads from a private/local lab server.
8. **Modbus TCP monitor** — demo registers by default; optional read-only holding-register reads from a private/local simulator.

## Architecture

```text
python-network-tools/
├── backend/
│   ├── pyproject.toml
│   ├── src/network_tools/
│   │   ├── main.py
│   │   ├── routers/       # HTTP request/response contracts
│   │   └── services/      # Python engineering logic
│   └── tests/
└── frontend/
    ├── package.json
    ├── vite.config.js
    └── src/
        ├── App.jsx
        ├── api.js
        ├── components/
        └── pages/         # Eight React tool screens
```

## Requirements

- Python **3.14.x** (Windows or Linux)
- Node.js **22.12+** (Node 22 LTS recommended)
- `uv` and npm

## Run on Windows

Open two terminals in VS Code.

**Terminal 1 — backend:**

```powershell
cd applications/python-network-tools/backend
uv sync
uv run uvicorn network_tools.main:app --reload --host 127.0.0.1 --port 8000
```

**Terminal 2 — frontend:**

```powershell
cd applications/python-network-tools/frontend
npm install
npm run dev
```

Open `http://127.0.0.1:5173`. The Vite development server proxies `/api` calls to `http://127.0.0.1:8000`.

## Run on Linux

Open two terminals.

**Terminal 1 — backend:**

```bash
cd applications/python-network-tools/backend
uv sync
uv run uvicorn network_tools.main:app --reload --host 127.0.0.1 --port 8000
```

**Terminal 2 — frontend:**

```bash
cd applications/python-network-tools/frontend
npm install
npm run dev
```

Open `http://127.0.0.1:5173`.

## Tests and quality checks

From `applications/python-network-tools/backend`:

```bash
uv run pytest
uv run ruff check .
uv run ruff format --check .
```

From `frontend/`, `npm run build` compiles the React app. The included JavaScript/JSX is also organised as focused page components so each tool can be studied separately.

From `applications/python-network-tools/frontend`:

```bash
npm run build
```

## Production-style single process

Build the React app first:

```bash
cd applications/python-network-tools/frontend
npm run build
```

Then start FastAPI from the backend directory:

```bash
cd ../backend
uv run uvicorn network_tools.main:app --host 127.0.0.1 --port 8000
```

If `frontend/dist` exists, FastAPI serves the built UI and API from the same origin on port 8000.

## Safety and privacy notes

- The backend binds to `127.0.0.1` by default. Do not bind it to `0.0.0.0` or expose it publicly without authentication, TLS, access controls, rate limiting, request-size controls and an explicit security review.
- Reachability accepts one private/loopback IP and one TCP port. It does not resolve hostnames, scan ranges or run batch jobs.
- OPC UA and Modbus live modes validate private/loopback IP literals and only perform read operations. They must only be used against a local simulator or equipment you are explicitly authorised to test. The UI defaults to demo mode.
- The packet capture tool reads uploaded offline captures only, limits file size and packet count, and does not expose payload contents. Use only captures you own or are authorised to inspect.
- The interface tool observes the local machine where the backend runs. It does not change network settings.
- Sample hostnames and addresses are fictional/documentation examples. Replace nothing with company data before publishing.

## Version notes

- The Modbus client uses PyModbus 3.13+ syntax: `read_holding_registers(..., device_id=...)`. The `slave=` keyword belongs to older examples and is intentionally not used here.
- OPC UA node reads use `Client.get_node(...).read_data_value()` and close the client in a `finally` block.
- Scapy is used for offline capture reading, not live packet capture.

## Learning workflow

Each tool screen maps to a project in the Autism For Evil portfolio. Read the project brief, explore the GUI, inspect the backend service, inspect its API router, then run the tests. Try changing the Python service only after you understand the request/response flow.
