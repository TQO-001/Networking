import { useEffect, useState } from 'react';
import {
  Activity, ArrowUpRight, Boxes, BarChart3, Building2, ChevronRight, Command,
  FileSearch, Gauge, Github, Layers, LayoutDashboard, Menu, Network, Radio,
  ShieldCheck, X,
} from 'lucide-react';
import { apiRequest } from './api';
import SubnetPage from './pages/SubnetPage';
import InventoryPage from './pages/InventoryPage';
import ReachabilityPage from './pages/ReachabilityPage';
import InterfacesPage from './pages/InterfacesPage';
import LogsPage from './pages/LogsPage';
import PcapPage from './pages/PcapPage';
import OpcuaPage from './pages/OpcuaPage';
import ModbusPage from './pages/ModbusPage';
import { Metric, Panel } from './components/UI';

const tools = [
  { id:'subnet', number:'01', label:'Subnet calculator', group:'Network foundations', icon:Network, description:'IPv4 and IPv6 network breakdown', component:SubnetPage },
  { id:'inventory', number:'02', label:'OT asset inventory', group:'Network foundations', icon:Boxes, description:'CSV validation and inventory health', component:InventoryPage },
  { id:'reachability', number:'03', label:'Reachability monitor', group:'Monitoring', icon:Activity, description:'Single-target TCP service check', component:ReachabilityPage },
  { id:'interfaces', number:'04', label:'Interface health', group:'Monitoring', icon:Gauge, description:'Local interface counters and rates', component:InterfacesPage },
  { id:'logs', number:'05', label:'Log analyser', group:'Troubleshooting', icon:FileSearch, description:'Severity and link-event summary', component:LogsPage },
  { id:'pcap', number:'06', label:'Packet capture', group:'Troubleshooting', icon:BarChart3, description:'Offline PCAP / PCAPNG analysis', component:PcapPage },
  { id:'opcua', number:'07', label:'OPC UA monitor', group:'Industrial protocols', icon:Building2, description:'Read-only lab telemetry', component:OpcuaPage },
  { id:'modbus', number:'08', label:'Modbus TCP monitor', group:'Industrial protocols', icon:Radio, description:'Read-only holding registers', component:ModbusPage },
];

function Overview({ onOpen, apiStatus }) {
  return <>
    <div className="overview-hero">
      <div><span className="eyebrow">AUTISM FOR EVIL / ENGINEERING LAB</span><h1>Python Network<br/><em>Tools.</em></h1><p>Eight small engineering tools. One consistent workspace. Python does the work; React makes the results easier to explore.</p><div className="hero-actions"><button className="button" onClick={() => onOpen('subnet')}>Open first tool <ChevronRight size={16}/></button><a className="text-link" href="https://github.com/TQO-001" target="_blank" rel="noreferrer">GitHub profile <ArrowUpRight size={14}/></a></div></div>
      <div className="hero-orb" aria-hidden="true"><div className="orb-ring ring-one"/><div className="orb-ring ring-two"/><div className="orb-core"><Command size={45}/><span>PY</span></div><div className="orb-chip chip-a">Python API</div><div className="orb-chip chip-b">React UI</div></div>
    </div>
    <div className="metric-grid three overview-metrics"><Metric label="Project tools" value="08" icon={Layers}/><Metric label="Architecture" value="Full stack" detail="React + FastAPI"/><Metric label="Default mode" value="Lab first" detail="Demo and read-only workflows"/></div>
    <div className="section-heading"><div><span className="eyebrow">TOOLBOX / 01—08</span><h2>Choose a project</h2></div><span className="section-count">08 APPLICATIONS</span></div>
    <div className="tool-grid">{tools.map(tool=><button className="tool-card" key={tool.id} onClick={()=>onOpen(tool.id)}><div className="tool-card-top"><span>{tool.number}</span><tool.icon size={20}/></div><h3>{tool.label}</h3><p>{tool.description}</p><span className="tool-card-link">Open tool <ArrowUpRight size={14}/></span></button>)}</div>
    <Panel title="The architecture" description="The interface and engineering logic are deliberately separate.">
      <div className="architecture-row"><div><span>01 / FRONTEND</span><strong>React + Vite</strong><small>Forms, dashboards, tables and visual feedback</small></div><ChevronRight/><div><span>02 / API</span><strong>FastAPI + Pydantic</strong><small>HTTP contracts, validation and error handling</small></div><ChevronRight/><div><span>03 / ENGINE</span><strong>Python services</strong><small>Addressing, monitoring, parsing and protocols</small></div></div>
    </Panel>
    <div className="footnote-panel"><ShieldCheck size={18}/><p><strong>Lab-first by design.</strong> Live network and OT protocol actions are narrowly scoped. Industrial protocol pages start in demo mode and the live paths are read-only. Never experiment against production equipment.</p></div>
  </>;
}

export default function App() {
  const [active, setActive] = useState('overview');
  const [apiStatus, setApiStatus] = useState('checking');
  const [mobileOpen, setMobileOpen] = useState(false);
  const selected = tools.find(item => item.id === active);
  useEffect(() => { apiRequest('/health').then(() => setApiStatus('online')).catch(() => setApiStatus('offline')); }, []);
  function openTool(id) { setActive(id); setMobileOpen(false); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  const Page = selected?.component;
  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
      <div className="brand-lockup"><div className="brand-symbol">A<span>F</span></div><div><strong>AUTISM FOR EVIL</strong><small>PYTHON NETWORK LAB</small></div><button className="mobile-close" onClick={()=>setMobileOpen(false)} aria-label="Close menu"><X size={18}/></button></div>
      <div className="sidebar-scroll">
        <div className="nav-section"><span className="nav-label">WORKSPACE</span><button className={`nav-item ${active==='overview'?'active':''}`} onClick={()=>openTool('overview')}><LayoutDashboard size={17}/><span>Overview</span></button></div>
        {['Network foundations','Monitoring','Troubleshooting','Industrial protocols'].map(group=><div className="nav-section" key={group}><span className="nav-label">{group.toUpperCase()}</span>{tools.filter(t=>t.group===group).map(tool=><button className={`nav-item ${active===tool.id?'active':''}`} onClick={()=>openTool(tool.id)} key={tool.id}><tool.icon size={17}/><span>{tool.label}</span><small>{tool.number}</small></button>)}</div>)}
      </div>
      <div className="sidebar-bottom"><div className="api-health"><span className={`health-light ${apiStatus}`}/><div><strong>Python API</strong><small>{apiStatus==='online'?'Connected':apiStatus==='offline'?'Not running':'Checking…'}</small></div><button title="Recheck API" onClick={()=>{setApiStatus('checking');apiRequest('/health').then(()=>setApiStatus('online')).catch(()=>setApiStatus('offline'));}}><Activity size={15}/></button></div><a href="/autism-for-evil/" className="back-link"><ArrowUpRight size={15}/> Back to portfolio</a></div>
    </aside>
    {mobileOpen&&<button className="mobile-scrim" aria-label="Close navigation" onClick={()=>setMobileOpen(false)}/>}
    <main className="main-area">
      <header className="topbar"><button className="mobile-menu" onClick={()=>setMobileOpen(true)} aria-label="Open navigation"><Menu size={20}/></button><div className="breadcrumbs"><span>PYTHON NETWORK TOOLS</span><ChevronRight size={14}/><strong>{selected?.label??'Overview'}</strong></div><div className="topbar-actions"><span className="api-chip"><i className={`health-light ${apiStatus}`}/>{apiStatus==='online'?'API online':apiStatus==='offline'?'API offline':'Connecting'}</span><a href="https://github.com/TQO-001" target="_blank" rel="noreferrer" className="top-icon" aria-label="GitHub"><Github size={18}/></a></div></header>
      <div className="content-wrap">{selected ? <Page/> : <Overview onOpen={openTool} apiStatus={apiStatus}/>}</div>
      <footer className="app-footer"><span>PYTHON NETWORK TOOLS <i>·</i> BUILT WHILE LEARNING</span><span>WINDOWS <i>·</i> LINUX <i>·</i> LAB FIRST</span></footer>
    </main>
  </div>;
}
