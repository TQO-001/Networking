import { useState } from 'react';
import { Upload, ShieldCheck, Download } from 'lucide-react';
import { apiRequest } from '../api';
import { Button, Metric, Notice, PageIntro, Panel } from '../components/UI';
export default function PcapPage(){
 const [file,setFile]=useState(null);const [result,setResult]=useState(null);const [error,setError]=useState('');const [loading,setLoading]=useState(false);
 async function analyze(e){e.preventDefault();if(!file)return;setError('');setLoading(true);try{const form=new FormData();form.append('file',file);setResult(await apiRequest('/pcap/analyze',{method:'POST',body:form}));}catch(err){setError(err.message);setResult(null);}finally{setLoading(false);}}
 async function loadDemo(){try{const response=await fetch('/samples/demo.pcap');if(!response.ok)throw new Error('Sample capture could not be loaded.');const blob=await response.blob();setFile(new File([blob],'demo.pcap',{type:'application/vnd.tcpdump.pcap'}));setResult(null);setError('');}catch(err){setError(err.message);}}
 return <>
  <PageIntro eyebrow="06 / OFFLINE TRAFFIC" title="Packet capture analyser" description="Upload an approved PCAP or PCAPNG file and inspect packet metadata, protocol counts and observed conversations." />
  <Panel title="Offline capture" description="No live capture is started. The file is parsed locally by the Python backend.">
   <form className="upload-box" onSubmit={analyze}>
    <label className="upload-target"><Upload size={27}/><strong>{file?.name??'Choose a capture file'}</strong><span>PCAP / PCAPNG · maximum 10 MB · maximum 20,000 packets</span><input type="file" accept=".pcap,.pcapng,application/vnd.tcpdump.pcap" onChange={e=>setFile(e.target.files?.[0]??null)}/></label>
    <div className="form-actions"><Button type="button" variant="secondary" icon={Download} onClick={loadDemo}>Load demo capture</Button><Button icon={Upload} disabled={!file} loading={loading}>Analyse capture</Button></div>
   </form>
   <Notice type="info">Only analyse captures you own or are authorised to inspect. Payload contents are not displayed or exported by this tool.</Notice>
   {error&&<div className="notice error">{error}</div>}
  </Panel>
  {result&&<>
   <div className="metric-grid three"><Metric label="Packets" value={result.packet_count.toLocaleString()}/><Metric label="Total size" value={`${(result.total_bytes/1024).toFixed(1)} KB`}/><Metric label="Average packet" value={`${result.average_packet_bytes} B`}/></div>
   <div className="two-column-panels">
    <Panel title="Protocol distribution"><div className="bar-list">{result.protocols.map(row=><div className="bar-row" key={row.name}><div><span>{row.name}</span><strong>{row.count}</strong></div><div className="bar-track"><i style={{width:`${Math.max(2,row.count/Math.max(1,result.packet_count)*100)}%`}}/></div></div>)}</div></Panel>
    <Panel title="Observed conversations"><div className="conversation-list">{result.conversations.map(row=><div key={row.name}><code>{row.name}</code><span>{row.count} packets</span></div>)}</div></Panel>
   </div>
   <Notice type="info"><ShieldCheck size={16}/> Packet payloads were excluded from this summary.</Notice>
  </>}
 </>;
}
