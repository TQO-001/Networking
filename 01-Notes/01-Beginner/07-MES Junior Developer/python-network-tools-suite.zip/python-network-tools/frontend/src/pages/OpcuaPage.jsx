import { useState } from 'react';
import { Building2, Radio, ShieldCheck } from 'lucide-react';
import { postJson } from '../api';
import { Button, Field, Metric, Notice, PageIntro, Panel } from '../components/UI';
export default function OpcuaPage(){
 const [endpoint,setEndpoint]=useState('opc.tcp://127.0.0.1:4840');const [nodeIds,setNodeIds]=useState('ns=2;s=Demo.Temperature\nns=2;s=Demo.Pressure');const [demo,setDemo]=useState(true);const [result,setResult]=useState(null);const [error,setError]=useState('');const [loading,setLoading]=useState(false);
 async function read(e){e.preventDefault();setError('');setLoading(true);try{setResult(await postJson('/opcua/read',{endpoint,node_ids:nodeIds.split(/\r?\n/).map(x=>x.trim()).filter(Boolean),timeout_seconds:3,demo_mode:demo}));}catch(err){setError(err.message);setResult(null);}finally{setLoading(false);}}
 return <>
  <PageIntro eyebrow="07 / INDUSTRIAL DATA" title="OPC UA monitor" description="Read selected variables from a local OPC UA lab server. The learning interface is read-only and begins with demo data." badge="OT LAB TOOL"/>
  <Panel title="Connection setup" description="Use a simulator or an explicitly approved private lab endpoint.">
   <form className="stack-form" onSubmit={read}>
    <div className="form-grid"><Field label="OPC UA endpoint"><input value={endpoint} onChange={e=>setEndpoint(e.target.value)} disabled={demo}/></Field><Field label="Node IDs" hint="One known NodeId per line, up to 10"><textarea rows={3} value={nodeIds} onChange={e=>setNodeIds(e.target.value)} disabled={demo}/></Field></div>
    <label className="toggle-row"><input type="checkbox" checked={demo} onChange={e=>setDemo(e.target.checked)}/><span><strong>Use sample telemetry</strong><small>Turn off only when a local/approved simulator is ready.</small></span></label>
    <div className="form-actions"><Button icon={Radio} loading={loading}>Read selected nodes</Button></div>
   </form>
   <Notice type="info">This client calls read methods only. It never writes values or invokes methods on a controller.</Notice>
   {error&&<div className="notice error">{error}</div>}
  </Panel>
  {result&&<Panel title="Variable readings" description={result.demo_mode?'Illustrative local demo values. No OPC UA connection was opened.':`Read-only response from ${result.endpoint}`}>
   <div className="metric-grid three"><Metric label="Variables" value={result.readings.length} icon={Building2}/><Metric label="Mode" value={result.demo_mode?'Demo':'Connected'}/><Metric label="Permission" value="Read only" icon={ShieldCheck}/></div>
   <div className="telemetry-grid">{result.readings.map(row=><article className="telemetry-card" key={row.node_id}><span className="eyebrow">{row.node_id}</span><strong>{String(row.value)}</strong><div><span className="status-pill good">{row.status}</span></div>{row.source_timestamp&&<small>{row.source_timestamp}</small>}</article>)}</div>
  </Panel>}
 </>;
}
