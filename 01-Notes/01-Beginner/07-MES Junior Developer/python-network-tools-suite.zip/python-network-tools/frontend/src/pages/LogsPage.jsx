import { useState } from 'react';
import { FileText } from 'lucide-react';
import { postJson } from '../api';
import { Button, Metric, PageIntro, Panel } from '../components/UI';

const sample = `[2026-11-06 09:00:02] INFO SW-LAB-01 interface Gi0/1 link up\n[2026-11-06 09:02:18] WARNING SW-LAB-01 packet loss above threshold\n[2026-11-06 09:03:47] ERROR HMI-SIM-01 connection failed\n[2026-11-06 09:04:05] INFO SW-LAB-01 interface Gi0/1 link down\n[2026-11-06 09:05:11] DEBUG retry counter=1\n`;
export default function LogsPage(){
 const [text,setText]=useState(sample);const [result,setResult]=useState(null);const [error,setError]=useState('');const [loading,setLoading]=useState(false);
 async function analyze(e){e.preventDefault();setError('');setLoading(true);try{setResult(await postJson('/logs/analyze',{text}));}catch(err){setError(err.message);setResult(null);}finally{setLoading(false);}}
 const counts=result?.severity_counts ?? {};
 return <>
  <PageIntro eyebrow="05 / EVENT ANALYSIS" title="Network log analyser" description="Turn a sample or sanitised syslog export into severity counts and a traceable event timeline." />
  <Panel title="Log input" description="Paste a sample or use the included synthetic dataset." action={<Button variant="quiet" onClick={()=>setText(sample)}>Load sample</Button>}>
   <form className="stack-form" onSubmit={analyze}><textarea className="code-input" rows={10} value={text} onChange={e=>setText(e.target.value)} spellCheck="false"/><div className="form-actions"><Button icon={FileText} loading={loading}>Analyse logs</Button></div></form>
   {error&&<div className="notice error">{error}</div>}
  </Panel>
  {result&&<>
   <div className="metric-grid five">{['critical','error','warning','info','debug'].map(level=><Metric key={level} label={level} value={counts[level]??0}/>)}</div>
   <Panel title="Link-state events" description="Recognised link-up and link-down messages, with original line numbers.">
    {result.link_events.length ? <div className="event-list">{result.link_events.map((event,i)=><div className="event-row" key={`${event.line}-${i}`}><span className={`event-dot ${event.event}`} /><span className="mono">Line {event.line}</span><strong>{event.event.replace('-',' ')}</strong><p>{event.message}</p></div>)}</div> : <p className="muted-copy">No link-state events matched the simple rules.</p>}
   </Panel>
   <Panel title="Parsed messages" description={`${result.total_lines} original lines, with source order preserved.`}>
    <div className="log-list">{result.lines.map(line=><div className="log-line" key={line.line}><span className="line-number">{line.line}</span><span className={`severity severity-${line.severity}`}>{line.severity}</span><code>{line.message}</code></div>)}</div>
   </Panel>
  </>}
 </>;
}
