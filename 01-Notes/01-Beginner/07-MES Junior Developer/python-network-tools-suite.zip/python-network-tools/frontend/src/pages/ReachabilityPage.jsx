import { useState } from 'react';
import { Activity, Plug } from 'lucide-react';
import { postJson } from '../api';
import { Button, Field, Metric, Notice, PageIntro, Panel } from '../components/UI';

export default function ReachabilityPage() {
  const [host,setHost] = useState('127.0.0.1');
  const [port,setPort] = useState('8000');
  const [timeout,setTimeout] = useState('1.5');
  const [result,setResult] = useState(null);
  const [error,setError] = useState('');
  const [loading,setLoading] = useState(false);
  async function check(event) {
    event.preventDefault(); setError(''); setLoading(true);
    try { setResult(await postJson('/reachability/check', { host, port: Number(port), timeout_seconds: Number(timeout) })); }
    catch(err) { setError(err.message); setResult(null); }
    finally { setLoading(false); }
  }
  return <>
    <PageIntro eyebrow="03 / CONNECTIVITY" title="Reachability monitor" description="Check one explicitly configured TCP endpoint at a time and record the response. A failed connection is not proof that a host is offline." />
    <Panel title="Single endpoint check" description="Use a local or approved private lab IP address and a known TCP service port.">
      <form className="form-grid" onSubmit={check}>
        <Field label="Host IP" hint="Private or loopback IP only"><input value={host} onChange={e => setHost(e.target.value)} /></Field>
        <Field label="TCP port"><input type="number" min="1" max="65535" value={port} onChange={e => setPort(e.target.value)} /></Field>
        <Field label="Timeout (seconds)"><input type="number" min="0.2" max="3" step="0.1" value={timeout} onChange={e => setTimeout(e.target.value)} /></Field>
        <div className="form-actions align-end"><Button icon={Plug} loading={loading}>Check endpoint</Button></div>
      </form>
      <Notice type="info">This tool intentionally has no range scanner or batch mode. Use it only with targets you own or are authorised to test.</Notice>
      {error && <div className="notice error">{error}</div>}
    </Panel>
    {result && <Panel title="Latest result" description={`${result.host}:${result.port}`}>
      <div className="reach-result">
        <div className={`reach-indicator ${result.reachable ? 'online' : 'offline'}`}><Activity size={25}/></div>
        <div><span className={`status-pill ${result.reachable ? 'good' : 'bad'}`}>{result.reachable ? 'TCP reachable' : 'No TCP response'}</span><h3>{result.message}</h3><p>{result.reachable ? 'The three-way handshake completed for this check.' : 'Firewall rules, service state, routing or timeout may explain this result.'}</p></div>
      </div>
      <div className="metric-grid two"><Metric label="Measured time" value={`${result.latency_ms} ms`} /><Metric label="Endpoint" value={`${result.host}:${result.port}`} /></div>
    </Panel>}
  </>;
}
