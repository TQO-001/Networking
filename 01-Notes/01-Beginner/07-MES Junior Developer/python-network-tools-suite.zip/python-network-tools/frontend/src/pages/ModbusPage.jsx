import { useState } from 'react';
import { Radio, ShieldCheck, Table2 } from 'lucide-react';
import { postJson } from '../api';
import { Button, Field, Metric, Notice, PageIntro, Panel } from '../components/UI';
export default function ModbusPage(){
 const [host,setHost]=useState('127.0.0.1');const [port,setPort]=useState('502');const [unit,setUnit]=useState('1');const [address,setAddress]=useState('0');const [count,setCount]=useState('8');const [demo,setDemo]=useState(true);const [result,setResult]=useState(null);const [error,setError]=useState('');const [loading,setLoading]=useState(false);
 async function read(e){e.preventDefault();setError('');setLoading(true);try{setResult(await postJson('/modbus/read',{host,port:Number(port),unit_id:Number(unit),address:Number(address),count:Number(count),timeout_seconds:2,demo_mode:demo}));}catch(err){setError(err.message);setResult(null);}finally{setLoading(false);}}
 return <>
  <PageIntro eyebrow="08 / INDUSTRIAL DATA" title="Modbus TCP monitor" description="Read a bounded range of holding registers from a simulator, or explore the interface using sample values." badge="OT LAB TOOL"/>
  <Panel title="Register read" description="Function code 03 only. Register addresses use the zero-based convention expected by PyModbus.">
   <form className="stack-form" onSubmit={read}>
    <div className="form-grid three"><Field label="Lab host IP"><input value={host} onChange={e=>setHost(e.target.value)} disabled={demo}/></Field><Field label="TCP port"><input type="number" value={port} onChange={e=>setPort(e.target.value)} disabled={demo}/></Field><Field label="Unit ID"><input type="number" min="1" max="247" value={unit} onChange={e=>setUnit(e.target.value)}/></Field><Field label="Start address (0-based)"><input type="number" min="0" max="65535" value={address} onChange={e=>setAddress(e.target.value)}/></Field><Field label="Register count (1–125)"><input type="number" min="1" max="125" value={count} onChange={e=>setCount(e.target.value)}/></Field></div>
    <label className="toggle-row"><input type="checkbox" checked={demo} onChange={e=>setDemo(e.target.checked)}/><span><strong>Use sample register values</strong><small>Disable only when a local/approved Modbus simulator is running.</small></span></label>
    <div className="form-actions"><Button icon={Radio} loading={loading}>Read holding registers</Button></div>
   </form>
   <Notice type="info">This application sends read requests only. No coils or holding registers are written. Do not connect to production controllers for practice.</Notice>
   {error&&<div className="notice error">{error}</div>}
  </Panel>
  {result&&<Panel title="Register values" description={result.demo_mode?'Illustrative data; no TCP connection was opened.':`${result.host}:${result.port} · Unit ${result.unit_id}`}>
   <div className="metric-grid three"><Metric label="Registers read" value={result.registers.length} icon={Table2}/><Metric label="Mode" value={result.demo_mode?'Demo':'Connected'}/><Metric label="Access" value="Read only" icon={ShieldCheck}/></div>
   <div className="table-wrap"><table><thead><tr><th>Address (zero-based)</th><th>Unsigned 16-bit value</th><th>Hex</th><th>Bit view</th></tr></thead><tbody>{result.registers.map(reg=><tr key={reg.address}><td className="mono">{reg.address}</td><td><strong>{reg.value}</strong></td><td className="mono">0x{reg.value.toString(16).padStart(4,'0').toUpperCase()}</td><td className="mono">{reg.value.toString(2).padStart(16,'0')}</td></tr>)}</tbody></table></div>
   <p className="muted-copy">{result.addressing_note}</p>
  </Panel>}
 </>;
}
