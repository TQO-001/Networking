import { useState } from 'react';
import { ClipboardCheck, Download, FileSpreadsheet } from 'lucide-react';
import { postJson } from '../api';
import { Button, Field, Metric, PageIntro, Panel } from '../components/UI';

const sample = 'hostname,ip_address,role,vlan\nPLC-SIM-01,192.0.2.10,PLC,10\nHMI-SIM-01,192.0.2.20,HMI,20\nSW-SIM-01,192.0.2.2,Switch,10\nPLC-DUPLICATE,192.0.2.10,PLC,10\n';
export default function InventoryPage() {
  const [csv, setCsv] = useState(sample);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  async function analyze(event) {
    event.preventDefault(); setError(''); setLoading(true);
    try { setResult(await postJson('/inventory/validate', { csv_text: csv })); }
    catch (err) { setError(err.message); setResult(null); }
    finally { setLoading(false); }
  }
  function exportCsv() {
    if (!result) return;
    const rows = [['line','hostname','ip_address','role','vlan','valid','issues'], ...result.rows.map(r => [r.line,r.hostname,r.ip_address,r.role,r.vlan,r.valid,r.issues.join('; ')])];
    const content = rows.map(row => row.map(value => `"${String(value ?? '').replaceAll('"','""')}"`).join(',')).join('\n');
    const url = URL.createObjectURL(new Blob([content], { type: 'text/csv' }));
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'inventory-validation-report.csv'; anchor.click(); URL.revokeObjectURL(url);
  }
  return <>
    <PageIntro eyebrow="02 / ASSET DATA" title="OT asset inventory" description="Validate a CSV inventory without connecting to a single device. Find missing fields, duplicate IPs and invalid VLANs." />
    <Panel title="Inventory CSV" description="Required columns: hostname, ip_address, role, vlan." action={<Button variant="quiet" icon={FileSpreadsheet} onClick={() => setCsv(sample)}>Load sample</Button>}>
      <form onSubmit={analyze} className="stack-form">
        <Field label="CSV content" hint="Use fictional or sanitised device information in this learning tool.">
          <textarea className="code-input" rows={9} value={csv} onChange={e => setCsv(e.target.value)} spellCheck="false" />
        </Field>
        <div className="form-actions"><Button icon={ClipboardCheck} loading={loading}>Validate inventory</Button>{result && <Button type="button" variant="secondary" icon={Download} onClick={exportCsv}>Export report</Button>}</div>
      </form>
      {error && <div className="notice error">{error}</div>}
    </Panel>
    {result && <>
      <div className="metric-grid three">
        <Metric label="Rows checked" value={result.total_rows} />
        <Metric label="Valid rows" value={result.valid_rows} detail="Passed all checks" />
        <Metric label="Issues" value={result.issue_count} detail={`${result.invalid_rows} rows need attention`} />
      </div>
      <Panel title="Validation results" description="Each row keeps its source line number so findings are easy to trace.">
        <div className="table-wrap"><table><thead><tr><th>Line</th><th>Hostname</th><th>IP address</th><th>Role</th><th>VLAN</th><th>Status</th><th>Findings</th></tr></thead><tbody>
          {result.rows.map(row => <tr key={row.line}><td>{row.line}</td><td>{row.hostname || '—'}</td><td className="mono">{row.ip_address || '—'}</td><td>{row.role || '—'}</td><td>{row.vlan || '—'}</td><td><span className={`status-pill ${row.valid ? 'good' : 'bad'}`}>{row.valid ? 'Valid' : 'Review'}</span></td><td>{row.issues.join(' · ') || 'No issues'}</td></tr>)}
        </tbody></table></div>
      </Panel>
    </>}
  </>;
}
