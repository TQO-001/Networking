import { useState } from 'react';
import { RefreshCw, Network } from 'lucide-react';
import { apiRequest } from '../api';
import { Button, Metric, PageIntro, Panel } from '../components/UI';

function bytes(value) { if (value == null) return '—'; const units=['B','KB','MB','GB','TB']; let n=value, i=0; while(n>=1024 && i<units.length-1){n/=1024;i++;} return `${n.toFixed(i ? 1 : 0)} ${units[i]}`; }
export default function InterfacesPage() {
  const [data,setData] = useState(null); const [error,setError] = useState(''); const [loading,setLoading] = useState(false);
  async function refresh(){setLoading(true);setError('');try{setData(await apiRequest('/interfaces/snapshot'));}catch(e){setError(e.message);}finally{setLoading(false);}}
  return <>
    <PageIntro eyebrow="04 / LOCAL TELEMETRY" title="Interface health" description="Inspect the network interfaces on the computer running the backend. Compare counters and interface state without changing configuration." />
    <Panel title="Local machine snapshot" description="The backend reads psutil counters from its own host." action={<Button variant="secondary" icon={RefreshCw} loading={loading} onClick={refresh}>Refresh snapshot</Button>}>
      {!data && <p className="muted-copy">Take a snapshot to inspect local interfaces. Run the backend on the machine you want to observe.</p>}
      {error && <div className="notice error">{error}</div>}
      {data && <>
        <div className="metric-grid three"><Metric label="Interfaces" value={data.interface_count} icon={Network}/><Metric label="Sampled at" value={new Date(data.sampled_at).toLocaleTimeString()} /><Metric label="Source" value="Local host" detail="Backend machine" /></div>
        <div className="interface-list">{data.interfaces.map(item => <article className="interface-card" key={item.name}>
          <div className="interface-title"><div><h3>{item.name}</h3><p>{item.addresses.map(a => `${a.family} ${a.address}`).join(' · ') || 'No IP address reported'}</p></div><span className={`status-pill ${item.is_up ? 'good' : 'bad'}`}>{item.is_up ? 'Up' : 'Down / unknown'}</span></div>
          <div className="interface-metrics"><div><span>Sent</span><strong>{bytes(item.bytes_sent)}</strong></div><div><span>Received</span><strong>{bytes(item.bytes_received)}</strong></div><div><span>TX rate</span><strong>{item.tx_bytes_per_second == null ? 'Take another sample' : `${bytes(item.tx_bytes_per_second)}/s`}</strong></div><div><span>RX rate</span><strong>{item.rx_bytes_per_second == null ? 'Take another sample' : `${bytes(item.rx_bytes_per_second)}/s`}</strong></div><div><span>Speed</span><strong>{item.speed_mbps ? `${item.speed_mbps} Mbps` : 'Unknown'}</strong></div><div><span>Errors / drops</span><strong>{item.errors_in + item.errors_out} / {item.drops_in + item.drops_out}</strong></div></div>
        </article>)}</div>
      </>}
    </Panel>
  </>;
}
