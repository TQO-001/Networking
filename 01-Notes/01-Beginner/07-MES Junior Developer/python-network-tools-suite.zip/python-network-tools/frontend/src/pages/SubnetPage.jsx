import { useState } from 'react';
import { Calculator, Network } from 'lucide-react';
import { postJson } from '../api';
import { Button, CopyButton, Field, Metric, Notice, PageIntro, Panel } from '../components/UI';

export default function SubnetPage() {
  const [cidr, setCidr] = useState('192.168.10.25/24');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  async function calculate(event) {
    event.preventDefault(); setError(''); setLoading(true);
    try { setResult(await postJson('/subnets/calculate', { cidr })); }
    catch (err) { setError(err.message); setResult(null); }
    finally { setLoading(false); }
  }
  return <>
    <PageIntro eyebrow="01 / ADDRESSING" title="Subnet calculator" description="Turn a CIDR address into a clear network summary. IPv4 and IPv6 are both supported." />
    <Panel title="Network input" description="Enter an address with its prefix length.">
      <form className="form-row" onSubmit={calculate}>
        <Field label="IP address / CIDR" hint="Example: 192.168.10.25/24 or 2001:db8::1/64">
          <input value={cidr} onChange={e => setCidr(e.target.value)} spellCheck="false" autoComplete="off" />
        </Field>
        <Button icon={Calculator} loading={loading}>Calculate subnet</Button>
      </form>
      {error && <div className="notice error">{error}</div>}
    </Panel>
    {result && <>
      <div className="metric-grid three">
        <Metric label="Network" value={result.network} detail={result.version} icon={Network} />
        <Metric label="Total addresses" value={Number(result.total_addresses).toLocaleString()} detail="Address space" />
        <Metric label="Usable addresses" value={Number(result.usable_addresses).toLocaleString()} detail="Protocol-aware estimate" />
      </div>
      <Panel title="Address breakdown" description="Copy any value directly into your notes or configuration worksheet.">
        <div className="result-grid">
          {[
            ['Network address', result.network_address],
            ['Prefix length', `/${result.prefix_length}`],
            ['Subnet mask', result.subnet_mask],
            ['First usable', result.first_usable],
            ['Last usable', result.last_usable],
            ['Broadcast address', result.broadcast_address ?? 'Not defined for IPv6'],
          ].map(([label, value]) => <div className="result-item" key={label}><span>{label}</span><strong>{value}</strong><CopyButton value={value} /></div>)}
        </div>
        <Notice type="info">The usable-host count follows conventional IPv4 subnet rules. IPv6 does not use a broadcast address.</Notice>
      </Panel>
    </>}
  </>;
}
