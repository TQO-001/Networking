import { AlertCircle, CheckCircle2, LoaderCircle, Copy, Check } from 'lucide-react';
import { useState } from 'react';

export function Panel({ title, description, action, children, className = '' }) {
  return (
    <section className={`panel ${className}`}>
      {(title || action) && <div className="panel-heading">
        <div>{title && <h2>{title}</h2>}{description && <p>{description}</p>}</div>
        {action}
      </div>}
      {children}
    </section>
  );
}

export function Field({ label, hint, children, className = '' }) {
  return <label className={`field ${className}`}>
    <span className="field-label">{label}</span>
    {children}
    {hint && <small>{hint}</small>}
  </label>;
}

export function Button({ children, icon: Icon, variant = 'primary', loading = false, ...props }) {
  return <button {...props} className={`button ${variant}`} disabled={Boolean(props.disabled) || loading}>
    {loading ? <LoaderCircle className="spin" size={16} /> : Icon && <Icon size={16} />}
    {children}
  </button>;
}

export function Notice({ type = 'info', children }) {
  const Icon = type === 'error' ? AlertCircle : CheckCircle2;
  return <div className={`notice ${type}`} role="status"><Icon size={17} /> <span>{children}</span></div>;
}

export function Metric({ label, value, detail, icon: Icon }) {
  return <div className="metric-card">
    <div className="metric-top"><span>{label}</span>{Icon && <Icon size={17} />}</div>
    <strong>{value ?? '—'}</strong>
    {detail && <small>{detail}</small>}
  </div>;
}

export function CopyButton({ value }) {
  const [copied, setCopied] = useState(false);
  async function copy() {
    try {
      await navigator.clipboard.writeText(String(value));
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    } catch {
      setCopied(false);
    }
  }
  return <button className="copy-button" type="button" onClick={copy} aria-label="Copy value">
    {copied ? <Check size={14} /> : <Copy size={14} />}
  </button>;
}

export function EmptyState({ title, description }) {
  return <div className="empty-state"><div className="empty-orbit">◎</div><h3>{title}</h3><p>{description}</p></div>;
}

export function PageIntro({ eyebrow, title, description, badge = 'LAB TOOL' }) {
  return <div className="page-intro">
    <div className="eyebrow-row"><span className="eyebrow">{eyebrow}</span><span className="mini-badge">{badge}</span></div>
    <h1>{title}</h1>
    <p>{description}</p>
  </div>;
}
