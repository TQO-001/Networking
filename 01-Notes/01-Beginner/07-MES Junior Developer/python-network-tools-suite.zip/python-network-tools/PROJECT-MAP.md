# Project map — eight GUI-backed tools

| # | Portfolio project | React page | FastAPI route | Python service | Test coverage |
|---|---|---|---|---|---|
| 01 | IP subnet calculator | `SubnetPage.jsx` | `POST /api/subnets/calculate` | `services/subnet.py` | IPv4, IPv6, /31 |
| 02 | OT asset inventory | `InventoryPage.jsx` | `POST /api/inventory/validate` | `services/inventory.py` | duplicates, invalid rows |
| 03 | Reachability monitor | `ReachabilityPage.jsx` | `POST /api/reachability/check` | `services/reachability.py` | lab-IP guard |
| 04 | Interface health | `InterfacesPage.jsx` | `GET /api/interfaces/snapshot` | `services/interfaces.py` | local psutil snapshot |
| 05 | Network log analyser | `LogsPage.jsx` | `POST /api/logs/analyze` | `services/logs.py` | severities and link events |
| 06 | Packet capture analyser | `PcapPage.jsx` | `POST /api/pcap/analyze` | `services/pcap.py` | size and file-format guard |
| 07 | OPC UA monitor | `OpcuaPage.jsx` | `POST /api/opcua/read` | `services/opcua.py` | endpoint guard and demo mode |
| 08 | Modbus TCP monitor | `ModbusPage.jsx` | `POST /api/modbus/read` | `services/modbus.py` | private-target guard and demo mode |

## Request lifecycle

1. A React page collects user input.
2. `src/api.js` sends JSON or `FormData` to the FastAPI route.
3. Pydantic validates the request model.
4. The router maps expected input errors to readable HTTP responses.
5. A Python service performs the engineering calculation or approved lab read.
6. FastAPI returns JSON and the React page renders the result, loading state or error.

## Extension rules

- Keep protocol logic out of React.
- Keep HTTP request parsing out of pure service functions.
- Add a test when adding a validation rule or fixing a bug.
- Keep I/O bounded by an explicit timeout or size limit.
- Keep all OT protocol examples read-only and simulator-first.
