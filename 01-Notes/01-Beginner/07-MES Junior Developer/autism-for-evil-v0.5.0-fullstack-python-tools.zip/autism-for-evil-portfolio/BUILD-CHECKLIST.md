# Build, publication and QA checklist

## Content / packaging checks

- [x] Added 144 curated networking Markdown pages from `Networking.zip`.
- [x] Sorted notes into topic shelves rather than preserving the original messy folder hierarchy.
- [x] Withheld personal journal and operational task folders from the initial public export.
- [x] Withheld two raw device transcripts containing real-looking identifiers/configuration material and a customer-specific project note.
- [x] Generalized employer/customer-identifying host and domain values in otherwise useful educational notes. Likely environment-specific switch-management, NTP and syslog addresses in walkthrough copies were replaced with reserved documentation values.
- [x] Replaced explicit sample credential values and a pasted type-5 secret hash with placeholders.
- [x] Removed unverified raster screenshots/photos and created 17 original SVG diagrams for the public notes.
- [x] Added About and Contact routes.
- [x] Integrated the supplied PlasmaWave React component with a purple/blue theme and reduced-quality settings for the main hero.
- [x] Added a name-only root gateway (`/`) that links to `/autism-for-evil/`.
- [x] Added `TechText`, `SideRays`, and `GhostCursor` Canvas 2D adaptations to the gateway, with reduced-motion handling and a keyboard-accessible anchor.
- [x] Added `.env.example` and documented the mailto-only contact form.
- [x] Added a list of temporary portrait placeholder sources and a warning to replace them before public launch.

## Still to verify locally before publication

- [ ] Install packages: `npm install`.
- [ ] Run the Astro check: `npm run check`.
- [ ] Build static routes: `npm run build`.
- [ ] Browse each route at desktop and mobile widths.
- [ ] Verify PlasmaWave on a WebGL2-capable device and confirm graceful fallback if WebGL2 is not available.
- [ ] Verify the gateway effects, click-through, touch behaviour, canvas fallback and performance in a real browser.
- [ ] Keyboard-test navigation, theme switch, search/filter, lesson progress and contact form.
- [ ] Confirm contrast and reduced-motion behaviour in the browser.
- [ ] Replace or license the two remote portrait placeholders.
- [ ] Configure the contact destination (or connect a real contact-form service).
- [ ] Read every public networking page before making the repository public; verify no employer/customer details or operational records remain, and check that documentation-only IPs are not copied into a real environment.
- [ ] Generate and commit `package-lock.json` after a successful install.
- [ ] Set `site` in `astro.config.mjs` when the final domain is known.

## Run locally

Requires a compatible Node 22 installation (use `.nvmrc` as the starting point):

```bash
npm install
npm run check
npm run build
npm run dev
```

The content migration and basic source checks were performed in the generation environment. The gateway route and component integration are not browser-verified yet. Package downloads timed out, so a full Astro build and actual browser-based visual/accessibility pass were not completed here. Do not mark any of the unchecked items as passed until they have genuinely been verified.

## Gateway update verification — 23 October 2026

- [x] Root `/` now renders a name-only gateway; the `Thulani Langa` link opens `/autism-for-evil/`.
- [x] Moved the full content homepage to `src/pages/autism-for-evil/index.astro` and repaired the relative imports.
- [x] Added `GhostCursor`, `TechText`, and `SideRays` canvas effects to the gateway; kept the existing `PlasmaWave` on the full site homepage.
- [x] Static source audit: 16 Astro page routes detected, 0 broken relative imports, migration manifest valid, required gateway/component routes present.
- [x] `node --check astro.config.mjs` passed.
- [x] Python subnet calculator tests passed: 5/5.
- [ ] Full Astro build remains unverified because `node_modules` is not present and the `astro` executable is unavailable in the build environment. Run `npm install`, `npm run check`, and `npm run build` locally before deployment.
- [ ] Browser test gateway click-through, mobile layout, touch cursor behavior and reduced-motion mode before publishing.


## Curriculum expansion verification — 27 October 2026

- [x] Shared Python Foundations catalogue: 15 lessons.
- [x] Python for Network Engineers continuation: 14 lessons.
- [x] Python for Developers: 16 lessons.
- [x] Database Systems for Developers & Network Engineers: 18 lessons.
- [x] Imported 13 database reference notes and classified them separately from Python reference notes.
- [x] Validated lesson frontmatter, required content fields, unique per-course lesson orders and the checked internal Markdown links.
- [x] Parsed 64 fenced Python examples in guided lessons and 35 in the database reference notes; no syntax errors found.
- [x] Updated the Modbus lesson to state its PyModbus API/version assumptions and use the current `device_id` calling convention.
- [ ] A full Astro type check and static build remain unverified: dependency installation timed out in the generation environment. Run the commands in the README locally.
- [ ] Browser-test course catalogues, lesson navigation, reference filters, saved completion boxes, narrow/mobile layouts and reduced-motion behaviour.


## Development / Networking information architecture — 5 November 2026

- [x] Added a dedicated Development hub at `/development/`.
- [x] Added a separate Developer Notes index at `/development/notes/`, with topic filters and search.
- [x] Grouped the 28 Python/developer reference notes into foundations, core Python, quality/performance, APIs/backend, automation/security and exercises.
- [x] Added a dedicated shared Database Systems hub at `/databases/`, showing the 13 database reference notes and both application/network-operations use cases.
- [x] Kept the Networking hub distinct at `/networking/`.
- [x] Updated primary navigation and footer links so Development and Networking are equally discoverable.
- [x] Added home-page entry cards for Development and Networking, plus the shared Database Systems link.
- [x] Updated the complete reference-library filter label from “Python notes” to “Development notes”.
- [x] Updated reference-note detail pages to return readers to the relevant Development or Database hub and guided course.
- [ ] Run `npm install`, `npm run check`, and `npm run build` in a Node 22 environment.
- [ ] Browser-test all three knowledge hubs, navigation at tablet/mobile widths, category filtering, and note detail return links.


## Full-stack Python Network Tools — 6 November 2026

- [x] Added a React + Vite dashboard with eight independent tool screens in one shared interface.
- [x] Added FastAPI routes and separated Python service modules for all eight tools.
- [x] Added demo modes for OPC UA and Modbus; live paths are read-only and restricted to local/private lab IPs.
- [x] Reachability checks accept one private/loopback IP and one TCP port per request; no ranges or DNS names.
- [x] Packet capture upload is offline-only, limited to 10 MB and 20,000 packets, and does not return payload contents.
- [x] Added a synthetic PCAP demo file and a frontend button to load it.
- [x] Added `/tools/` portfolio page, main navigation link and project-page links to the suite.
- [x] Added a developer-course lesson explaining React + FastAPI integration and linked the tool suite from both specialist Python courses.
- [x] Backend tests: 21 passed, 1 skipped because Scapy is not installed in the generation environment (the Scapy fixture test runs after `uv sync`).
- [x] Python source compilation passed.
- [x] JavaScript/JSX syntax parsing passed for 12 frontend files using the installed TypeScript parser.
- [ ] Run `uv sync` under Python 3.14.x, then `uv run pytest`, `uv run ruff check .` and `uv run ruff format --check .`.
- [ ] Run `npm install` and `npm run build` in `applications/python-network-tools/frontend/`. Package downloads timed out in this environment, so the frontend bundle was not built here.
- [ ] Run the full portfolio `npm install`, `npm run check` and `npm run build`; the Astro production build remains unverified.
- [ ] Browser-test all eight screens at desktop and mobile sizes, including form validation, loading/error states, CSV import, sample PCAP upload and the two protocol demo modes.
- [ ] Verify live OPC UA/Modbus reads only against an isolated simulator or explicitly approved lab endpoint. Do not use production equipment for the first live test.


## Full-stack GUI expansion — 6 November 2026

- [x] Added a unified React + Vite workspace with eight distinct tool screens.
- [x] Added a modular FastAPI backend with eight API routers and separate Python service modules.
- [x] Added backend tests, synthetic CSV/log/PCAP samples, and a local-first Windows/Linux README.
- [x] Added a `/tools/` landing page with GUI suite download and local launch commands.
- [x] Added the React + FastAPI architecture lesson to Python for Developers and linked both specialist Python courses to the tools workspace.
- [x] Backend tests: 21 passed, 1 skipped because Scapy is not installed in the generation environment.
- [x] Python compilation and JavaScript/JSX source syntax checks passed.
- [ ] Install backend dependencies with Python 3.14 and run pytest + Ruff.
- [ ] Install frontend dependencies and run `npm run build`; npm install timed out in the generation environment.
- [ ] Run parent Astro `npm run check` and `npm run build`; not verified here.
- [ ] Browser-test the eight tool screens at desktop and mobile sizes, including errors, uploads and demo modes.
- [ ] Replace or license portrait placeholders and review React Bits license terms before publishing the full source repository.
