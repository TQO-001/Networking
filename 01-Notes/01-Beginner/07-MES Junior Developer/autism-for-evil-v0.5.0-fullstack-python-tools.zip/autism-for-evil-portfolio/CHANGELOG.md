# Changelog

## 0.5.0 — Full-stack Python Network Tools (6 November 2026)

- Added a unified React + Vite workspace with eight dedicated tool screens.
- Added a modular Python 3.14 + FastAPI backend with individual routers, services and tests.
- Added a standalone source bundle at `public/downloads/python-network-tools-suite.zip`.
- Added a `/tools/` portfolio page with local Windows/Linux run instructions and links to each project brief.
- Kept OT protocol functions demo-first and read-only; constrained reachability checks and offline packet capture analysis.
- Added a shared Python-for-developers lesson explaining React frontends and Python APIs.

## 0.4.1 — Python code highlighting (6 November 2026)

- Added dual Shiki themes: Catppuccin Latte for light mode and Catppuccin Mocha for dark mode.
- Connected code-block colours to the website's existing theme toggle.
- Replaced the former muted green code-block surface with a branded purple/blue surface.
- Added common Python and shell fence aliases and normalised uppercase `Python` fences in the content collection.
- Kept long code lines horizontally scrollable to preserve indentation and CLI formatting.

## 0.4.0 — Development and Networking hubs (5 November 2026)

- Added a dedicated Development hub at `/development/`.
- Added a searchable Developer Notes index at `/development/notes/` for the original 28 Python/Foundation reference notes.
- Grouped developer references into Python foundations, Core Python, quality/performance, APIs/backend, automation, language/security, and exercises.
- Added a dedicated Database Systems hub at `/databases/`, with all 13 reference notes grouped by subject.
- Kept Networking independent at `/networking/`.
- Updated primary navigation, footer links, homepage workbench cards, the reference library filters, note-detail breadcrumbs and global search labels.
- Retained the shared Python foundation and cross-discipline database course architecture.
