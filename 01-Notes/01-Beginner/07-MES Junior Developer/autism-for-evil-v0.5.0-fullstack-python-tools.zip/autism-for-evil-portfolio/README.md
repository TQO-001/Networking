# Autism For Evil — technical portfolio

A portfolio-style publication for tutorials, courses, software development, networking, database systems, build logs and project write-ups. Development and Networking have distinct hubs; Python foundations and Database Systems are shared where the disciplines overlap. This is a prototype for a future personal portfolio, not a claim that every project brief is already implemented.

## Visual direction

Purple-and-blue technical editorial style. The first visit is a minimal, name-only gateway; clicking **Thulani Langa** opens the full Autism For Evil portfolio. The portfolio includes a plasma-wave hero, canvas cursor/text/rays effects, portrait placeholders, an accessible light/dark theme switch, and content designed to grow. The name **Autism For Evil** is the current working brand supplied by the site owner.

## Stack

- Astro for content-first pages and static generation.
- React integration for the WebGL2 `PlasmaWave` hero plus lightweight canvas adaptations of `GhostCursor`, `TechText`, and `SideRays` for the gateway page.
- Markdown content collections for courses, articles, project briefs, the Python reference shelf and curated networking notes.
- Plain CSS design tokens for responsive layouts, purple/blue themes, portrait placement and reduced-motion styling.

Astro's official React integration supports rendering React components and hydrating selected components on the client. See the [Astro React integration guide](https://docs.astro.build/en/guides/integrations-guide/react/).

## Run locally

Requirements: Node.js `22.22.0` or a newer compatible Node 22 release, npm, and an internet connection for the first dependency installation.

```bash
npm install
npm run dev
```

Open the local URL shown in the terminal (usually `http://localhost:4321`).

Build and preview:

```bash
npm run build
npm run preview
```

Generated static files are written to `dist/`.

## Contact form setup

The current contact form is a static mailto composer, not a server-side form handler. To configure its destination, copy `.env.example` to `.env` and set `PUBLIC_CONTACT_EMAIL` to the email address you intend to publish. It opens the visitor's email application with a prepared draft; it does not send messages by itself. Before a serious launch, consider a privacy-conscious form service or a server-side endpoint with spam protection.

Do not add a private address to the repo until you are ready for it to be public. `.env` is ignored by Git; only `.env.example` is tracked.

## Main routes

- `/` — minimal intro gateway showing only the owner’s name; click the name to enter the portfolio.
- `/autism-for-evil/` — main site home page and featured content.
- `/courses/` — catalogue of four connected learning paths.
- `/courses/python-foundations/` — the beginner-first shared Python foundation (15 lessons).
- `/courses/python-for-network-engineers/` — the network/OT engineering continuation (14 lessons).
- `/courses/python-for-developers/` — the Python software development series (16 lessons).
- `/courses/database-systems/` — the shared SQL/PostgreSQL course (18 lessons) for both developers and network engineers.
- `/articles/` — editorial notes and learning posts.
- `/projects/` — project briefs and build records.
- `/tools/` — the full-stack Python Network Tools overview and downloadable source bundle.
- `/development/` — software-development hub with links to the guided Python developer path and its reference shelves.
- `/development/notes/` — searchable, topic-grouped developer notes migrated from the original Foundation Notes.
- `/networking/` — dedicated searchable networking reference library.
- `/databases/` — shared database hub for application-development and network-operations use cases.
- `/networking/<note-path>/` — individual note pages.
- `/library/` — complete reference index for development and database notes, with subject and level filters.
- `/about/` — public professional introduction.
- `/contact/` — contact page.
- `/search/` — search over the site's content.

## Where content lives

- `src/content/lessons/python-for-network-engineers/` — the original 10 beginner-first lessons, preserved at their existing URLs, plus 5 shared workflow lessons.
- `src/content/lessons/python-network-engineer-series/` — the 14-lesson continuation into practical network/OT tools.
- `src/content/lessons/python-for-developers/` — the 16-lesson software development track.
- `src/content/lessons/database-management/` — the 18-lesson SQL/PostgreSQL track.
- `src/content/lessons/` — 63 guided lessons total across the four paths.
- `src/content/articles/` — articles / field notes; initial entries are drafts.
- `src/content/projects/` — eight project briefs linked to their React screens and FastAPI services. Keep their status in progress until frontend build and local browser verification are complete.
- `applications/python-network-tools/` — one React + Vite dashboard and modular Python + FastAPI backend containing all eight GUI-backed tools.
- `public/downloads/python-network-tools-suite.zip` — standalone source download for the Python Network Tools application.
- `src/content/library/` — browser-ready versions of the original developer/Python Foundation Notes (28 references) and 13 curated database reference notes in `database-management/`.
- `src/content/networking/` — 144 curated networking notes sorted into topic-based shelves.
- `public/networking-assets/` — 17 original, hand-authored SVG diagrams used by the notes; unverified imported raster screenshots and photos were removed.
- `legacy-notes/` — source copies of the initial Python notes, excluding editor caches and virtual environments.
- `src/pages/` — Astro page routes.
- `src/components/react/PlasmaWave.jsx` and `.css` — supplied WebGL2 plasma visual for the main hero.
- `src/components/react/GhostCursor.jsx`, `TechText.jsx`, and `SideRays.jsx` with companion CSS — lighter Canvas 2D adaptations used on the intro gateway. They preserve the requested visual interactions/props where implemented; they are not byte-for-byte copies of the full WebGL/advanced upstream source.
- `CONTENT-ROADMAP.md` — course map, lesson counts, content locations and teaching standards.
- `docs/NETWORKING-NOTES-MIGRATION.md` — how the networking notes were regrouped and what was withheld.
- `networking-notes-manifest.json` — machine-readable migration manifest.
- `ASSET-CREDITS.md` — temporary portrait sources and publishing caveats.

## Networking notes: public-safety curation

The uploaded vault contained a mixture of study material, raw device transcripts and notes that were not suitable for immediate public publication. The site deliberately does **not** include the private journal, workplace task records, raw switch boot/config dumps or a customer-specific project note. Device names and corporate/local domains used in suitable educational notes were generalized; likely environment-specific IP examples for switch management, NTP and syslog were replaced with reserved documentation addresses; specific credential examples were replaced with placeholders. Unverified imported raster screenshots and photos were replaced with original SVG diagrams. This is cautious filtering, not a substitute for reviewing every page before publication.

Before making this repo public, do a final read-through of `/networking/` and the project pages. Never publish real company IP inventories, device configurations, credentials, SSH key material, network diagrams or unredacted logs without explicit authorization.

## Portrait placeholders

The portrait images on the home and About pages are remote, temporary stock placeholders, not photos of Thulani. They may fail to load if the provider blocks hotlinking, and their reuse/licensing status has not been confirmed for a production public website. The pages hide failed images and retain the initials/artwork as a fallback. Replace both images with properly licensed portraits you choose before launch. See `ASSET-CREDITS.md`.

## React Bits-inspired visual components

The gateway uses `TechText` for the name, `SideRays` for the ambient lighting, and `GhostCursor` for the cursor trail. These are lightweight Canvas 2D adaptations shaped around the JavaScript/CSS prop interface from the request, keeping the name readable and avoiding multiple full-screen WebGL effects at once. They are decorative; the actual link is a semantic anchor and remains keyboard accessible. All effects stop or reduce activity when possible under `prefers-reduced-motion`, the page is hidden, or the section leaves view.

`PlasmaWave` remains on the main `/autism-for-evil/` home page.


`src/components/react/PlasmaWave.jsx` and `PlasmaWave.css` contain the WebGL2 visual component adapted from the source supplied for this build. It is decorative and marked `aria-hidden`; the content remains readable if WebGL2 is unavailable. The home page loads it with Astro's `client:visible` directive, uses the purple/blue palette, and lowers quality to moderate GPU work. Test on mobile and reduce `quality` or set `paused` if needed. Respect `prefers-reduced-motion`; the component's source checks that preference.

Upstream attribution: [React Bits by David Haz](https://github.com/DavidHDev/react-bits). The repository's current [license](https://github.com/DavidHDev/react-bits/blob/main/LICENSE.md) is MIT + Commons Clause: it allows use in an application or website but restricts redistribution of the component itself, including in a bundle. The deployed portfolio may use it under those terms; before publishing this source repository publicly, review that clause carefully. Keep this repo private or replace the component if source redistribution is not permitted for your intended setup. Full note: `ASSET-CREDITS.md`.

## Verification status

The content and packaging structure was checked locally, including path-based curation, redaction searches, JSON manifest parsing, gateway-route wiring, component import paths, and JavaScript syntax where available. The package-install step for Astro/React dependencies timed out in this environment, so a full `npm run build` and browser-based visual/accessibility test could not be completed here. Do not treat the project as production-verified until those checks pass on your machine. See `BUILD-CHECKLIST.md`.

## Keep the content honest

- Mark planned work as planned.
- State what has actually been tested.
- Separate personal learning notes from workplace records.
- Use synthetic or redacted data in public examples.
- Keep secrets in protected environment variables, never source files.


## Knowledge-area architecture

The site presents two specialist workbenches and one shared discipline:

- **Development** (`/development/`) is the home for Python, software engineering, backend/API development, testing and developer tooling. Its dedicated notes index (`/development/notes/`) exposes the supplied Foundation Notes by topic.
- **Networking** (`/networking/`) is the home for CCNA, enterprise and industrial networking, OT operations, network automation and networking reference notes.
- **Database Systems** (`/databases/`) is shared because relational design, SQL and PostgreSQL support both application software and network-operations tooling.
- **Courses** remains the combined catalogue. Shared Python foundations are taught once; specialist learning paths link back to those foundations instead of repeating them.

The complete reference library remains at `/library/`. It is useful for cross-discipline searches, while each hub provides a focused entry point.


## Markdown code highlighting

Markdown fenced code blocks are highlighted with Shiki using the Catppuccin Latte theme in light mode and Catppuccin Mocha in dark mode. The code blocks follow the site's existing light/dark theme toggle. Python fence labels are normalised through Shiki aliases (`Python`, `py`, and `pyw` map to `python`).

The code surface uses the site's purple/blue design tokens; inline code has a separate, quieter treatment. Long code lines remain horizontally scrollable rather than being broken in ways that could damage indentation or command examples.


## Interactive Python Network Tools

The eight Python networking projects now have a shared React + Vite GUI backed by a modular FastAPI API. The portfolio landing page is `/tools/`; each tool has its own React screen, FastAPI route, Python service module and project brief. The suite is designed to run locally: React on `127.0.0.1:5173` and FastAPI on `127.0.0.1:8000` during development. It is not a hosted, remotely accessible network scanner.

Source code is in `applications/python-network-tools/`; the standalone source download is `public/downloads/python-network-tools-suite.zip`. See `applications/python-network-tools/README.md` for Windows/Linux setup, the two-terminal workflow, tests, frontend build, API docs and safety boundaries. The suite starts with demo data for industrial protocols; live OPC UA and Modbus functions are read-only and restricted to explicit local/private lab endpoints. Reachability accepts one explicit private/loopback IP and port per request; packet capture analysis is offline-only.
