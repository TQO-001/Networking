# Content architecture and curriculum roadmap

Autism For Evil uses one shared Python foundation and three connected specialist paths. The guided courses are authored in Markdown and rendered from the Astro content collection. Notes are reference material; lessons are sequenced teaching experiences.

## Learning paths

| Path | Course ID | Lessons | Purpose |
|---|---|---:|---|
| Shared Python Foundations | `shared-python-foundations` | 15 | The common starting point: running Python, values, decisions, loops, functions, files, validation, project structure, Git, pytest, Ruff, type hints, JSON and logging. |
| Python for Network Engineers | `python-for-network-engineers` | 14 | Continues with inventory validation, IP planning, safe reachability, TCP service checks, interface metrics, logs, offline PCAP analysis, HTTP APIs, bounded concurrency and read-only OT protocols. |
| Python for Developers | `python-for-developers` | 16 | Reusable packages, type hints, errors/resources, composition, iterators, pragmatic decorators, HTTP/JSON, FastAPI, Pydantic, configuration/security, tests, async tasks, PostgreSQL integration and profiling. |
| Database Systems for Developers & Network Engineers | `database-management` | 18 | Relational modelling, SQL, joins, transactions, normalization, constraints, PostgreSQL roles, Python integration, MVCC, indexes, migrations, recovery, monitoring, advanced features and two applied data models. |

Total: **63 guided lessons**. The 13 original database reference notes and the Python foundation reference notes are also available in the library; they are not counted as guided lessons.

## Why foundations are shared

Python syntax, collections, functions, files, exceptions, Git, testing and basic project hygiene are taught once. Network and developer courses link back to that foundation rather than rebuilding the same beginner lessons in different scenarios. Database fundamentals are also taught once, then applied to application data and network operations. Each specialist course includes its own introduction, context, projects and capstone.

## Lesson locations

- Shared Python Foundations: `src/content/lessons/python-for-network-engineers/` (the first ten original beginner lesson URLs remain stable), plus lessons 10–14 in the same folder.
- Network Engineer continuation: `src/content/lessons/python-network-engineer-series/`.
- Python for Developers: `src/content/lessons/python-for-developers/`.
- Database Systems: `src/content/lessons/database-management/`.
- Python reference notes: `src/content/library/` except the database subfolder.
- Database Management reference notes: `src/content/library/database-management/`.
- Curated networking notes: `src/content/networking/`.

The `[...slug].astro` lesson route uses the frontmatter `course` ID to show the correct course title, sequence, progress reminder and return link. Each lesson folder may have its own URL prefix; the frontmatter course ID—not the physical folder name—controls the learning path. Existing first-course URLs are intentionally preserved.

## Standards for every new lesson

1. State prerequisites and the learner outcome in plain language.
2. Explain new terms before relying on them.
3. Give small, runnable examples with expected behaviour where possible.
4. Tell learners which project folder and command to use.
5. Include an exercise, hint or guided question, and checkpoint.
6. Teach failure cases, validation and limits—not only the happy path.
7. Teach tests, logging, Git and documentation as part of the workflow.
8. Keep examples cross-platform where reasonable, and call out Windows/Linux differences.
9. Use synthetic data, bounded operations and approved labs for networking work. OT examples are read-only by default; no lesson should direct learners to experiment against production equipment.
10. Mark planned work as a plan, not as a finished portfolio project.

## Future expansions

- Add fully worked answer keys as separate, clearly labelled solution sections after exercises.
- Add small synthetic datasets/simulator instructions to projects where they will improve reproducibility.
- Add CI only after a generated package lockfile and local successful build have been verified.
- Add lesson-level Python smoke tests for runnable course examples where it is practical.
- Continue converting high-value portions of the uploaded notes into guided lessons when they are more useful as a sequence than as reference pages.

## Publication caution

The notes came from personal learning archives and have been reorganised for the site, but this is not a guarantee that all content has been reviewed for public release. Audit rendered pages before making the repository public. Do not publish credentials, private keys, company/customer names, raw production device output or unapproved network diagrams.


## Website information architecture — 5 November 2026

The portfolio now separates its knowledge areas without duplicating shared learning:

- `/development/` — development hub for Python, software engineering, APIs, testing and developer tooling.
- `/development/notes/` — focused searchable index of the 28 original Python/developer reference notes supplied in `01-Foundation Notes.zip`, grouped by topic.
- `/networking/` — separate network engineering and OT knowledge hub, containing 144 curated notes.
- `/databases/` — shared database hub, featuring all 13 database reference notes and application/network-operations use cases.
- `/courses/` — combined learning catalogue. Shared Python foundations are taught once, then specialist tracks branch into development and network engineering.
- `/library/` — cross-discipline reference index with Development and Database filters.

Developer note topic groups: Python foundations (6), Core Python (5), Quality & performance (3), APIs & backend (4), Automation (1), Language tools & security (2), and Exercises & practice (7).

Database note topic groups: relational design (3), PostgreSQL storage architecture (1), integrity & transactions (2), performance & operations (5), and application integration (2).


## Full-stack Python Network Tools

The eight project briefs now map to the shared React + Vite / FastAPI suite in `applications/python-network-tools/`. Each screen has an API route and a dedicated Python service module. The new Developer lesson `15-react-frontends-for-python-apis.md` explains the request lifecycle and frontend/backend separation.
