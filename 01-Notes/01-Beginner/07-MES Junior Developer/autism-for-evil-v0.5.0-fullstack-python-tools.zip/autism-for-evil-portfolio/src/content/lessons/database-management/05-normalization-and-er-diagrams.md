---
title: "Design schemas by avoiding unnecessary repetition"
description: "Use functional dependencies and normalisation to reduce update anomalies without normalising blindly."
order: 5
minutes: 28
level: "Intermediate"
course: "database-management"
module: "Relational design"
tags: ["normalization", "3nf", "erd", "schema-design"]
kind: "lesson"
---

## One fact, one authoritative place

Normalisation is about identifying facts and dependencies so that updates do not leave contradictory copies. Suppose a table repeats device name and location on every interface observation. If the name changes, hundreds of rows must be updated, and some may be missed. Store device identity once, then reference it from related tables.

First Normal Form commonly requires values to be atomic for the intended model and repeating groups to be represented as related rows. Second Normal Form concerns dependencies on only part of a composite key. Third Normal Form addresses non-key attributes depending on other non-key attributes. In practice, begin by naming the entities, their keys and the rules that determine each fact.

## Draw before you code

An entity-relationship diagram identifies entities, attributes, primary keys, foreign keys and cardinalities. It gives developers, DBAs and network engineers a shared way to discuss data before implementation.

For network telemetry, `devices`, `interfaces` and `observations` are natural entities. An observation should include a timestamp and the measured value/status; do not overwrite yesterday's measurement when today's data arrives.

## Denormalise deliberately

Sometimes a read-optimised report or materialized view is useful. Denormalisation adds duplication or precomputed values, so define how it stays consistent and measure whether the benefit is real. Do not denormalise merely because joins seem intimidating.

## Exercise

Take a deliberately messy spreadsheet where each row contains device, interface and last-seen observation details. Draw the normalised tables and write which foreign key connects them. Document one useful uniqueness constraint.

## Checkpoint

Explain one update anomaly your design prevents and where a denormalised reporting view might still be justified.
