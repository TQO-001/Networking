---
title: "Capstone: build a tested task API"
description: "Bring package structure, validation, tests and persistence architecture into a small developer portfolio project."
order: 16
minutes: 35
level: "Intermediate–Advanced"
course: "python-for-developers"
module: "Capstone"
tags: ["capstone", "fastapi", "pytest", "portfolio"]
kind: "project"
---

## Brief

Build a task API for learning and demonstration. The first release can use the in-memory repository so you can finish the service contract; then replace that adapter with PostgreSQL using the shared database course.

## Required features

- `GET /health` with a documented response.
- `POST /tasks` with input validation and a `201` response.
- `GET /tasks` with bounded pagination.
- `GET /tasks/{task_id}` with a clear `404`.
- A service layer containing business rules.
- A repository interface and separate in-memory implementation.
- pytest coverage for success, invalid input and not-found behaviour.
- Ruff, type hints, meaningful error handling and logs without secrets.
- README containing setup, routes, examples, test commands, security assumptions and limitations.

## Suggested structure

```text
src/task_api/
├── main.py
├── schemas.py
├── services.py
├── repositories.py
└── config.py
tests/
├── test_services.py
└── test_routes.py
```

## Definition of done

A clean checkout can be installed and tested. Tests do not depend on a production service. Input sizes and pagination are limited. The API does not expose debug tracebacks or credentials. Database credentials are provided at runtime, and database integration tests use a dedicated test database.

## Stretch goals

Add database migrations, API authentication, request IDs and a CI pipeline. Treat each as a separate feature with its own tests and documentation.

## Portfolio write-up

Explain one architectural decision, one bug found by tests, how you handle secrets, what you measured and what you would improve next. Never label planned features as complete.
