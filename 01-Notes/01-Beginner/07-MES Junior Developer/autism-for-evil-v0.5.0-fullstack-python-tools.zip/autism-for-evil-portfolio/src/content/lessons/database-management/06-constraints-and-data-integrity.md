---
title: "Let the database protect its own rules"
description: "Use NOT NULL, UNIQUE, CHECK and foreign keys to prevent invalid states at the persistence boundary."
order: 6
minutes: 22
level: "Intermediate"
course: "database-management"
module: "Relational design"
tags: ["constraints", "integrity", "foreign-keys"]
kind: "lesson"
---

## Application validation is not enough

A form may validate data, but rows can also be inserted by a script, an admin tool, a migration or another service. Constraints make key rules authoritative at the database boundary.

```sql
CREATE TABLE observations (
    observation_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    interface_id BIGINT NOT NULL REFERENCES interfaces(interface_id),
    observed_at TIMESTAMPTZ NOT NULL,
    metric_name TEXT NOT NULL CHECK (metric_name <> ''),
    numeric_value DOUBLE PRECISION,
    status TEXT NOT NULL CHECK (status IN ('ok', 'uncertain', 'bad'))
);
```

The example uses `TIMESTAMPTZ` for a timestamp representing an instant. It allows numeric values to be absent, because not every observation is numeric. More validation may be needed based on the data contract.

`UNIQUE` prevents duplicate keys or business identifiers; `NOT NULL` prevents missing values; `CHECK` enforces a row-level predicate; a foreign key ensures the referenced row exists. Triggers can implement certain cross-row actions, but are harder to reason about and test. Prefer declarative constraints when they express the rule clearly.

## Audit trails

For important changes, consider who changed what, when and why. An audit record should be designed intentionally: it can have retention, access and privacy requirements. A trigger is not automatically a complete audit system, especially if privileged users can bypass or modify it.

## Exercise

Add constraints to a sample device and observation schema. Write failing inserts that demonstrate each constraint, but run them in your disposable database only. Document whether a rejected operation should return a user-facing validation error or indicate an internal integrity bug.

## Checkpoint

Explain why important integrity rules belong in both the right application layer and the database, and why duplicated validation should not disagree.
