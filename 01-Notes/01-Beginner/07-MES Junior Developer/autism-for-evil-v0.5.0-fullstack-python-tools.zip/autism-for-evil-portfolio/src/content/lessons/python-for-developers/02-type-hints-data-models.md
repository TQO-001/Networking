---
title: "Use type hints to make intent visible"
description: "Annotate public functions and learn when a data class or a validation library adds value."
order: 2
minutes: 20
level: "Intermediate"
course: "python-for-developers"
module: "Maintainable Python"
tags: ["typing", "dataclasses", "pydantic"]
kind: "lesson"
---

## Type hints are documentation with tooling benefits

```python
from dataclasses import dataclass

@dataclass(frozen=True)
class Task:
    task_id: int
    title: str
    completed: bool = False

def is_complete(task: Task) -> bool:
    return task.completed
```

A data class reduces repetitive code for simple data objects. `frozen=True` prevents ordinary reassignment of fields after creation, though it does not make every object reachable from a field deeply immutable.

Python does not enforce annotations automatically. External input—JSON, environment variables, form submissions and database rows—must still be validated. A function annotation of `int` does not stop a JSON client from sending `"hello"`.

## Choose the tool that fits the boundary

- Use a plain dictionary for lightweight, flexible internal records.
- Use a `dataclass` for structured internal data with a stable shape.
- Use Pydantic when untrusted or external data needs runtime validation and useful error messages.

Do not introduce a data-model framework for a one-line script without a reason. Conversely, do not rely on raw dictionaries throughout a large service when a clear model would make the program easier to reason about.

## Exercise

Define a `Device` data class with name, IP address and role. Add a function whose parameter and return types are explicit. Then write tests for valid and invalid values, remembering that the dataclass alone does not validate the IP address.

## Checkpoint

Explain the difference between a type hint and runtime validation, and name one place in an application where external data must be validated even when hints exist.
