---
title: "Use objects when they clarify the design"
description: "Learn classes, composition and protocols through a small application service rather than classifying everything as an object."
order: 4
minutes: 22
level: "Intermediate"
course: "python-for-developers"
module: "Maintainable Python"
tags: ["oop", "composition", "interfaces"]
kind: "lesson"
---

## Classes should represent a useful concept

Object-oriented programming combines data and behaviour around a concept. A class is useful when it creates a coherent boundary; it is not automatically better than a function.

Composition means one object uses another object to do a job. A `ReportService` might use a repository to load rows and a formatter to write output. That is usually easier to replace and test than one huge class that owns everything.

```python
from collections.abc import Iterable
from dataclasses import dataclass

@dataclass(frozen=True)
class Task:
    title: str
    done: bool = False

class TaskService:
    def __init__(self, tasks: Iterable[Task] = ()) -> None:
        self._tasks = list(tasks)

    def add(self, title: str) -> Task:
        cleaned = title.strip()
        if not cleaned:
            raise ValueError("Task title cannot be empty")
        task = Task(title=cleaned)
        self._tasks.append(task)
        return task

    def list_all(self) -> list[Task]:
        return list(self._tasks)
```

This in-memory service is a teaching example, not durable storage. Returning a copy from `list_all()` prevents callers from mutating the service's internal list accidentally, although the contained `Task` values are already frozen.

## Don't build a framework too early

Inheritance can be useful for true “is-a” relationships, but often creates tight coupling. Composition and small interfaces make it easier to test with fake implementations. Start with the simplest model that fits current requirements.

## Exercise

Add a `TaskRepository` boundary and create an in-memory implementation for tests. Keep persistence out of `TaskService`. Write tests for blank input and successful task creation.

## Checkpoint

Explain which part owns the business rule and which part stores the data. If changing output format requires changing the domain model, revisit your boundaries.
