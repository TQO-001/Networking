---
title: "Understand decorators without magic"
description: "Read and write a simple decorator while learning when decorators improve code and when they obscure it."
order: 6
minutes: 22
level: "Intermediate"
course: "python-for-developers"
module: "Maintainable Python"
tags: ["decorators", "higher-order-functions"]
kind: "lesson"
---

## A decorator wraps behaviour

A decorator is a callable that receives a function and returns a replacement function. It is useful for cross-cutting behaviour such as timing or a carefully designed retry policy, but it should not hide important business logic.

```python
from collections.abc import Callable
from functools import wraps
from time import perf_counter
from typing import ParamSpec, TypeVar

P = ParamSpec("P")
R = TypeVar("R")

def timed(function: Callable[P, R]) -> Callable[P, R]:
    @wraps(function)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        started = perf_counter()
        try:
            return function(*args, **kwargs)
        finally:
            elapsed = perf_counter() - started
            print(f"{function.__name__} took {elapsed:.4f}s")
    return wrapper
```

`@wraps` preserves useful metadata such as the original function's name and documentation. The `finally` block records elapsed time even if the function raises, while allowing the exception to continue to the caller.

This example prints for clarity; a real application should use logging and avoid decorating every function just because it can.

## Parameterised decorators

A decorator with options adds another function layer. Learn it after you can explain the simpler version. If the result becomes difficult to debug, an explicit helper or context manager may be better.

## Exercise

Apply `@timed` to a function that processes a small sample file. Write a test confirming that the return value is unchanged and that an exception is still raised on failure.

## Checkpoint

Explain what the decorator receives, what it returns, why `@wraps` exists and how the wrapper preserves the original exception behaviour.
