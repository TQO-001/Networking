---
title: "Build your first network tool: a subnet calculator"
description: Combine the basics into a useful command-line tool by using Python's built-in ipaddress library.
order: 9
minutes: 40
level: Beginner
course: shared-python-foundations
tags: [project, ipaddress, subnetting, command-line]
kind: project

module: "Python foundations"
---
You have met output, variables, functions, input, validation and tests. Now we will combine them to build a small command-line tool. It accepts an IPv4 network in CIDR notation and prints its key details.

We will use Python's built-in `ipaddress` module instead of hand-writing subnet mathematics. That is an important engineering decision: learn the concept, but rely on a well-tested standard library implementation for the calculation.

## 1. Create the project folder

Create a folder named `subnet-calculator`, then create a file called `subnet_calculator.py` inside it. This first version is deliberately a single file. We will learn to split larger projects into packages after the behaviour is understood.

## 2. Add the code

```python
import ipaddress


def describe_network(cidr: str) -> str:
    """Return a readable summary of an IPv4 or IPv6 network."""
    network = ipaddress.ip_network(cidr, strict=False)
    lines = [
        f"Network: {network}",
        f"Network address: {network.network_address}",
        f"Prefix length: /{network.prefixlen}",
        f"Total addresses: {network.num_addresses}",
    ]

    if network.version == 4:
        lines.extend([
            f"Broadcast address: {network.broadcast_address}",
            f"Subnet mask: {network.netmask}",
        ])
        if network.num_addresses > 2:
            first = network.network_address + 1
            last = network.broadcast_address - 1
            lines.append(f"Traditional usable host range: {first} - {last}")
        else:
            lines.append("Traditional usable host range: special-case subnet; verify use case")
    else:
        lines.append("Broadcast address: not applicable (IPv6 has no broadcast)")
        lines.append("Usable host range: depends on your IPv6 allocation and addressing plan")

    return "\n".join(lines)


def main() -> None:
    cidr = input("Enter a network (for example 192.168.10.25/24): ").strip()
    try:
        print(describe_network(cidr))
    except ValueError as error:
        print(f"Invalid network: {error}")


if __name__ == "__main__":
    main()
```

## 3. Run it

```bash
python subnet_calculator.py
```

Enter `192.168.10.25/24`. Because `strict=False`, Python normalises the supplied address to the network it belongs to. The library handles the address calculation; our function turns the results into a readable report.

The “traditional usable host range” calculation is a simplified IPv4 teaching convention for ordinary subnets larger than two addresses. Special-purpose ranges and point-to-point conventions can differ. IPv6 has no broadcast address, so the program says that explicitly rather than treating the final IPv6 address as a broadcast address.

## 4. Understand the structure

- `import ipaddress` imports a standard-library module.
- `describe_network()` accepts a value and returns formatted text. It does not ask for user input, so it is easy to test independently.
- `main()` handles the user interaction and displays the result.
- `try/except` catches invalid network input and gives the user a helpful message.
- The `if __name__ == "__main__":` guard runs `main()` when this file is executed directly, while allowing another file to import the function without starting an interactive prompt.

That last pattern will become more useful once we split code into separate files.

## 5. Manual test cases

Try each input and observe what happens:

| Input | What you are checking |
|---|---|
| `192.168.10.25/24` | A common IPv4 `/24` network. |
| `10.4.8.9/16` | A different prefix and address range. |
| `192.168.1.10/32` | A single IPv4 address as a network. |
| `not-an-ip/24` | Invalid input should produce a clear message, not an unhandled traceback. |
| `2001:db8::1/64` | The program should accept IPv6 and avoid inventing a broadcast address. |

## 6. Your extension tasks

1. Display the prefix length using `network.prefixlen`.
2. Ask the user whether they want IPv4 only, and reject IPv6 when that mode is selected.
3. Move `describe_network()` into `calculator.py` and keep user input in `cli.py`.
4. Write pytest tests for a normal `/24`, a `/32` and invalid text.
5. Add a README with requirements, run commands, examples, known limitations and tests.

**Definition of done:** you can run the program, explain each function, show how invalid input is handled, and demonstrate at least three test cases. Do not call this finished because the happy path works once.

**Next:** use the [project brief](/projects/01-subnet-calculator/) to see how this grows into a maintainable portfolio project.
