---
title: "Monitor database health and capacity"
description: "Use basic PostgreSQL statistics to investigate connections, table sizes and activity without jumping straight to tuning."
order: 13
minutes: 25
level: "Intermediate–Advanced"
course: "database-management"
module: "Performance and maintenance"
tags: ["monitoring", "wal", "capacity", "postgresql"]
kind: "lesson"
---

## Observe before tuning

Start with evidence: active queries, long-running transactions, connection count, table/index size, error rates, backup freshness and disk capacity. PostgreSQL system views expose useful runtime information, but access depends on privileges and version.

```sql
SELECT pid, state, wait_event_type, wait_event,
       now() - query_start AS query_age,
       left(query, 120) AS query_preview
FROM pg_stat_activity
WHERE state <> 'idle'
ORDER BY query_start;
```

Query text can contain sensitive literal values, so restrict access and avoid publishing raw query output. `pg_stat_activity` is a diagnostic view, not a monitoring system by itself.

## WAL at a high level

Write-ahead logging records changes before database pages are considered durable, supporting crash recovery and replication. WAL volume can grow faster than expected due to bulk updates, replication lag or archive failures. Monitor according to the PostgreSQL version and deployment model; do not delete WAL files manually to free disk space.

## Memory settings are not magic percentages

Your reference notes contain rules of thumb for settings such as `shared_buffers` and `work_mem`. Treat them as starting hypotheses, not universal formulas. `work_mem` can be used by multiple operations per query and multiple concurrent sessions; a seemingly small value may multiply into significant memory pressure. Tune in the context of workload, total RAM and measured plans.

## Exercise

Use a small lab database to record table/index sizes, number of connections and one query plan. Make a one-page report listing a metric, what it means, its limitation and what action would require approval.

## Checkpoint

You can explain why monitoring evidence should precede tuning and why a database symptom does not automatically identify the root cause.
