---
title: "Configuration, secrets and safe defaults"
description: "Keep environment-specific settings separate from source and learn the security limits of configuration approaches."
order: 10
minutes: 22
level: "Intermediate"
course: "python-for-developers"
module: "Backend development"
tags: ["configuration", "secrets", "security"]
kind: "lesson"
---

## Configuration is not a secret store by itself

A development server, test runner and deployment may need different ports, database DSNs and log levels. Keep these settings out of hard-coded business logic. Environment variables are a common injection mechanism, and a `.env` file can be convenient for local development—but it must be excluded from Git and protected like any file containing credentials.

```python
import os

APP_ENV = os.getenv("APP_ENV", "development")
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
if APP_ENV not in {"development", "test", "production"}:
    raise RuntimeError("APP_ENV must be development, test, or production")
```

This is a starting point, not a complete configuration system. Validate settings once at startup, document defaults, and avoid silently falling back to insecure settings in production. Never print a complete DSN when debugging because it may contain a password.

## Security as ordinary engineering

Use least-privilege credentials; validate request data; keep dependencies patched; use TLS for remote sensitive traffic; and avoid exposing debug tracebacks to public callers. Passwords should be hashed with a suitable password-hashing library, not encrypted with a reversible scheme or stored as plaintext. Secrets should be rotated if exposed.

## Exercise

Add a configuration object that reads environment variables and validates a positive timeout. In tests, pass values directly or monkeypatch environment variables rather than relying on the machine's real environment. Confirm that malformed config fails before the service starts.

## Checkpoint

Explain why `.env` files are convenient but not magically secure, and demonstrate that your logs do not expose passwords or API tokens.
