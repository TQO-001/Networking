---
title: "Insert, update and delete data safely"
description: "Learn data modification, transactions and the habit of previewing destructive changes before running them."
order: 4
minutes: 25
level: "Beginner–Intermediate"
course: "database-management"
module: "SQL foundations"
tags: ["insert", "update", "delete", "transactions"]
kind: "lesson"
---

## Data changes should be deliberate

`INSERT` creates records, `UPDATE` changes selected records and `DELETE` removes selected records. Always inspect the target rows before issuing a broad change. A missing `WHERE` clause in an `UPDATE` or `DELETE` can affect every row in the table.

```sql
BEGIN;
UPDATE devices
SET role = 'switch'
WHERE asset_tag = 'LAB-SW-01'
RETURNING asset_tag, role;
-- Verify the returned row before deciding.
ROLLBACK;
```

This example rolls back, so it demonstrates the transaction without keeping the change. In a real transaction, use `COMMIT` only after confirming the intended result. Do not use a live production database for practice.

## Why transactions matter

A transaction groups operations so they succeed together or can be rolled back together, subject to database and isolation behaviour. Transactions do not magically correct a bad query. A transaction can faithfully commit a mistake if you do not validate the affected rows.

## Exercise

Insert fictional records, update one exact asset tag and delete one test row. Use `RETURNING` to inspect the effect. In a disposable lab, deliberately use `ROLLBACK` and verify the data remains unchanged.

## Checkpoint

You know how to preview the intended rows, constrain the operation, inspect returned values, and distinguish rollback from commit. Production change plans require approved procedures and backups, not just a SQL transaction.
