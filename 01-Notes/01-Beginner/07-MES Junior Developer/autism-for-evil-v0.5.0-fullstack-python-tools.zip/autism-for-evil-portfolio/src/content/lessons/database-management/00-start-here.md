---
title: "Start here: databases for developers and network engineers"
description: "Learn how databases support applications and network operations, then follow one shared core with two applied tracks."
order: 0
minutes: 9
level: "Beginner"
course: "database-management"
module: "Course map"
tags: ["orientation", "database", "networking", "development"]
kind: "guide"
---

## Why a shared database course?

A database stores data so applications can retrieve it, relate it, validate it and preserve it over time. Developers use databases for users, orders, settings and application workflows. Network engineers can use them for asset inventories, interface history, telemetry, change events and reports. The underlying relational concepts are shared; the data models and operational risks differ.

This course starts with SQL and relational design, then progresses to PostgreSQL operations, Python access, security, performance and reliability. The advanced topics in your uploaded notes—WAL, MVCC, query planning, indexes, replication, connection pooling, JSONB and safe migrations—remain in the advanced modules rather than being forced into the first lessons.

## How the tracks fit together

- **Developer application track:** model application entities, build parameterised data access and connect a FastAPI service to PostgreSQL.
- **Network operations track:** model devices, interfaces and timestamped observations; query history without treating the database as a real-time control system.

Both tracks share the same foundations. You do not need to study normalisation twice.

## Lab safety

Use a local PostgreSQL instance or a dedicated disposable lab database. Use fictional data. Never test destructive SQL, restore procedures or permission changes against a production database. For OT, a database that stores observations is not a substitute for a safety-rated control system or the authoritative source for device configuration.

## Checkpoint

Explain the difference between a database, a database management system (DBMS), a table and a query. Describe one useful database question from development and one from network operations.
