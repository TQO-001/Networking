---
title: "Connect a React interface to a Python API"
description: "Understand the React-to-FastAPI request lifecycle and build a small form that sends data to a Python service and renders the response."
order: 15
minutes: 45
level: "Intermediate"
course: "python-for-developers"
module: "Full-stack integration"
tags: ["react", "vite", "fastapi", "http", "full-stack"]
kind: "lesson"
---

## Why this lesson exists

A Python program does not need to be used only through a terminal. A browser interface can collect input, send it to a Python API, and display the result. The important design rule is that **React presents the interface while Python remains responsible for the engineering logic**.

The eight Python Network Tools projects use this pattern. They share one React dashboard and one modular FastAPI backend, but each tool has its own screen, endpoint, Python service and tests.

## 1. Understand the request lifecycle

```text
Person enters a CIDR address
          |
          v
React form stores the input
          |
          v
fetch() sends JSON to FastAPI
          |
          v
Pydantic validates the request
          |
          v
Python service calculates the subnet
          |
          v
FastAPI returns JSON
          |
          v
React displays the result or an error
```

React should not calculate the subnet itself. If it did, you would have two implementations of the same rule to maintain and test.

## 2. Start with the Python API

Create the backend environment and add the dependencies:

```bash
uv init --app subnet-api
cd subnet-api
uv add fastapi uvicorn
uv add --dev pytest httpx
```

Create `main.py`:

```python
import ipaddress

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="Subnet API")


class SubnetRequest(BaseModel):
    cidr: str = Field(min_length=3, max_length=80)


@app.post("/api/subnets/calculate")
def calculate_subnet(payload: SubnetRequest) -> dict[str, object]:
    try:
        network = ipaddress.ip_network(payload.cidr, strict=False)
    except ValueError as exc:
        raise HTTPException(
            status_code=422,
            detail="Enter a valid IPv4 or IPv6 CIDR address.",
        ) from exc

    return {
        "network": str(network),
        "network_address": str(network.network_address),
        "prefix_length": network.prefixlen,
        "version": f"IPv{network.version}",
        "total_addresses": network.num_addresses,
    }
```

Run it:

```bash
uv run uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/docs`. Try the endpoint there before writing React. This separates backend problems from frontend problems.

## 3. Create the React frontend

In a second terminal, create a Vite React application:

```bash
npm create vite@latest subnet-ui -- --template react
cd subnet-ui
npm install
npm run dev
```

Vite provides a local development server and a production build. Keep the frontend and backend in separate folders so each has its own dependencies and commands.

## 4. Proxy API requests during development

Open `vite.config.js` and configure a development proxy:

```javascript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
      },
    },
  },
});
```

Now React can request `/api/subnets/calculate`. Vite forwards that request to FastAPI. This avoids hard-coding a second origin in every component while developing locally.

## 5. Build a controlled React form

Replace the starter component in `src/App.jsx` with:

```jsx
import { useState } from 'react';

export default function App() {
  const [cidr, setCidr] = useState('192.168.10.25/24');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault();
    setLoading(true);
    setError('');
    setResult(null);

    try {
      const response = await fetch('/api/subnets/calculate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cidr }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.detail ?? 'The request failed.');
      }

      setResult(data);
    } catch (requestError) {
      setError(requestError.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main>
      <h1>Subnet calculator</h1>
      <form onSubmit={handleSubmit}>
        <label htmlFor="cidr">IP address / CIDR</label>
        <input
          id="cidr"
          value={cidr}
          onChange={(event) => setCidr(event.target.value)}
        />
        <button disabled={loading}>
          {loading ? 'Calculating…' : 'Calculate'}
        </button>
      </form>

      {error && <p role="alert">{error}</p>}
      {result && (
        <section aria-live="polite">
          <h2>{result.network}</h2>
          <p>Network address: {result.network_address}</p>
          <p>Prefix: /{result.prefix_length}</p>
          <p>{result.version}</p>
          <p>Total addresses: {result.total_addresses}</p>
        </section>
      )}
    </main>
  );
}
```

### What each state variable does

- `cidr` stores the current input value. The input is controlled because React owns its value and `onChange` updates it.
- `result` stores the successful JSON response.
- `error` stores a message suitable for the person using the form.
- `loading` prevents repeated submissions and gives feedback while the request is running.

`event.preventDefault()` stops a normal browser form navigation. `fetch()` sends the HTTP request. `response.ok` must be checked because HTTP errors such as `422` do not automatically reject the fetch promise.

## 6. Separate API calls from page components

As an application grows, do not copy the same fetch/error code into every page. Create `src/services/api.js`:

```javascript
export async function postJson(path, body) {
  const response = await fetch(`/api${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.detail ?? `Request failed (${response.status})`);
  }
  return data;
}
```

Then the component imports `postJson` and concentrates on state and presentation. The service module becomes the one place to add shared timeouts, request IDs or error normalisation later.

## 7. Test both halves

Test the Python service and API with pytest. Include a valid CIDR, malformed input, IPv4, IPv6 and prefix edge cases. A test should not need a browser or real network device.

For the React side, test that the form accepts text, disables while loading, displays a response and reports a failed request. At minimum, manually verify those states while developing; a mature project should add Vitest and React Testing Library tests.

## 8. Development and production are different

During development, Vite serves the React files and proxies `/api` to FastAPI. In production, build the frontend:

```bash
npm run build
```

Vite writes static files to `dist/`. You can host that directory with a static web server and configure the API URL, or have a Python application serve the built files from the same origin. If the frontend and API use different origins, configure CORS for the exact trusted frontend origin. Do not use a wildcard origin for an authenticated application.

Never put private API keys, database passwords or other secrets in React environment variables that are prefixed for browser exposure. Browser code is delivered to the visitor.

## 9. Apply the pattern to the eight tools

The Python Network Tools Suite provides a reference implementation:

| React screen | API route | Python responsibility |
|---|---|---|
| Subnet calculator | `POST /api/subnets/calculate` | Address calculation |
| OT asset inventory | `POST /api/inventory/validate` | CSV and field validation |
| Reachability monitor | `POST /api/reachability/check` | One bounded TCP check |
| Interface health | `GET /api/interfaces/snapshot` | Local psutil counters |
| Log analyser | `POST /api/logs/analyze` | Severity and event parsing |
| Packet capture | `POST /api/pcap/analyze` | Offline Scapy parsing |
| OPC UA monitor | `POST /api/opcua/read` | Read selected lab nodes |
| Modbus TCP monitor | `POST /api/modbus/read` | Read a bounded register range |

Explore `applications/python-network-tools/README.md` and `PROJECT-MAP.md`. Each tool screen maps to one React page, API router and Python service module.

## Exercises

1. Add a clear button that resets input, result and error state.
2. Show a message when the input is empty before sending the request.
3. Move the fetch logic into `services/api.js` and add a unit test for error handling.
4. Add a second API endpoint and a second React page without copying the whole application shell.
5. Write down which values belong in the browser and which values must remain on the Python server.

## Definition of done

You can explain the request lifecycle, run the frontend and backend separately, inspect the API contract, display success and error states, and run tests without contacting production services.

## Documentation

- [Vite guide](https://vite.dev/guide/)
- [React: describing the UI](https://react.dev/learn/describing-the-ui)
- [React: responding to events](https://react.dev/learn/responding-to-events)
- [FastAPI request bodies](https://fastapi.tiangolo.com/tutorial/body/)
- [FastAPI CORS](https://fastapi.tiangolo.com/tutorial/cors/)
