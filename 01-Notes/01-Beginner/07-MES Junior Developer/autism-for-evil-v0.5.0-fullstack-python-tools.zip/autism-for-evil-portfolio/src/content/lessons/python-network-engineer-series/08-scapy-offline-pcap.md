---
title: "Inspect packet captures with Scapy"
description: "Load an existing capture file and summarise protocols and endpoints without sniffing a live production interface."
order: 8
minutes: 27
level: "Intermediate"
course: "python-for-network-engineers"
module: "Troubleshooting and traffic"
tags: ["scapy", "pcap", "packet-analysis"]
kind: "lesson"
---

## Use an offline capture first

Packet captures can contain usernames, internal addresses, device names and application payloads. Use a provided training capture or one generated in your own isolated lab. Keep real workplace captures out of a public portfolio unless you have explicit approval and have sanitised them appropriately.

Install Scapy into this project when ready:

```bash
uv add scapy
```

```python
from collections import Counter
from pathlib import Path
from scapy.all import IP, IPv6, TCP, UDP, rdpcap

def summarize_capture(path: Path) -> dict[str, object]:
    packets = rdpcap(str(path))
    protocols: Counter[str] = Counter()
    endpoints: Counter[str] = Counter()
    for packet in packets:
        if TCP in packet:
            protocols["TCP"] += 1
        elif UDP in packet:
            protocols["UDP"] += 1
        else:
            protocols["other"] += 1
        if IP in packet:
            endpoints[f"{packet[IP].src} -> {packet[IP].dst}"] += 1
        elif IPv6 in packet:
            endpoints[f"{packet[IPv6].src} -> {packet[IPv6].dst}"] += 1
    return {"packets": len(packets), "protocols": dict(protocols),
            "top_endpoints": endpoints.most_common(10)}
```

Capture formats, permissions and packet structure can vary; test the function with a small sample and validate the path exists before reading it. Scapy can do far more than summaries, but this course starts with offline analysis, not packet injection.

## Interpret carefully

A packet in a capture means the capture point observed it. It does not automatically establish that the destination application received or processed it. Capture location, packet loss, VLAN mirroring configuration and clock synchronisation affect conclusions.

## Exercise

Add counts for ICMP and DNS; report the number of IPv4 and IPv6 packets; and handle an empty capture. Do not print raw payloads by default.

## Checkpoint

Explain why a capture from a switch mirror port may differ from a capture taken on the endpoint, and why the capture's source and scope belong in the report.
