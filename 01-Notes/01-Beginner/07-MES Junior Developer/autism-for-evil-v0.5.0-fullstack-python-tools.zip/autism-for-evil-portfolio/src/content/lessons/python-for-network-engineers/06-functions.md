---
title: "Functions: give a task a name"
description: Turn repeated logic into small reusable pieces and learn the difference between printing a result and returning it.
order: 6
minutes: 25
level: Beginner
course: shared-python-foundations
tags: [functions, reusable-code, return]
kind: lesson

module: "Python foundations"
---
As your scripts grow, you will notice blocks of logic that belong together. A **function** gives that work a name so you can call it where needed. Functions also make testing easier because you can check one small task at a time.

## 1. Define and call a function

```python
def make_device_label(hostname, ip_address):
    return f"{hostname} ({ip_address})"

label = make_device_label("SW-LAB-01", "192.168.10.2")
print(label)
```

Break it down:

- `def` begins a function definition.
- `make_device_label` is the function's name.
- `hostname` and `ip_address` are **parameters**—names for information the function receives.
- `return` sends a result back to the code that called the function.
- The final line calls the function with two **arguments**: the actual values passed in.

The function does not run merely because you defined it. The call on the next line asks Python to run it.

## 2. `print()` is not the same as `return`

`print()` displays something to a person. `return` gives a value back to the rest of the program. This is easier to see with a calculation:

```python
def is_valid_hostname(hostname):
    return hostname != ""

result = is_valid_hostname("SW-LAB-01")
print(result)  # True
```

The function returns `True` or `False`. Another part of the program can use that value in an `if` statement, a test or a report. If a function only prints a message, it is much harder for the rest of your program to reuse the result.

## 3. Make one function do one job

```python
def count_devices(devices):
    return len(devices)

lab_devices = ["SW-LAB-01", "HMI-SIM-01", "PLC-SIM-01"]
print(f"Inventory contains {count_devices(lab_devices)} devices")
```

The name says what the function does. It is short enough to understand. Later, you can use `count_devices()` with a different list without rewriting the counting logic.

A helpful beginner rule is: **one function, one clear responsibility**. It is not an absolute law, but it is a good default while you learn.

## 4. Type hints: optional signposts

Python allows you to add hints describing what types a function expects and returns:

```python
def count_devices(devices: list[str]) -> int:
    return len(devices)
```

`list[str]` says we expect a list of strings. `-> int` says that the function returns an integer. Type hints help humans, editor tools and type checkers understand the intended use. Python does not automatically reject every mismatched value just because a hint exists.

You do not need to add hints to every tiny exercise immediately, but we will use them more often as our code becomes a shared project.

## Exercise: device role checker

Write a function named `is_switch(role)` that returns `True` when `role` is equal to `"switch"` and `False` otherwise. Call it twice with different values and print both returned results.

**Done when:** you can explain what a function definition does, what its arguments are, and why `return` makes its result reusable.

**Next:** [Read a CSV asset inventory](/learn/python-for-network-engineers/07-reading-csv/).
