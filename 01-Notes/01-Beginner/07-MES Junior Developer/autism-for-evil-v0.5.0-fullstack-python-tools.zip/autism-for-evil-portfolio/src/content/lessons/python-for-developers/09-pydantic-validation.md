---
title: "Validate incoming data with Pydantic"
description: "Distinguish Python type hints from runtime request validation and design helpful, bounded schemas."
order: 9
minutes: 22
level: "Intermediate"
course: "python-for-developers"
module: "Backend development"
tags: ["pydantic", "validation", "schemas"]
kind: "lesson"
---

## Validate at the boundary

Applications receive data they did not create: API bodies, query strings, configuration, database values and files. Validate at the boundary before passing data into business logic. Type hints help readers and tools; they do not by themselves validate JSON at runtime.

```python
from pydantic import BaseModel, ConfigDict, Field

class DeviceInput(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    name: str = Field(min_length=1, max_length=80)
    address: str = Field(min_length=1, max_length=45)
    vlan: int = Field(ge=1, le=4094)
```

This model applies length limits and a VLAN range. It does not confirm that `address` is a valid IP address or that VLAN 200 exists in a particular network. Those are separate domain checks. Use specific validators only when you know the accepted format and can explain the rule.

## Prefer precise constraints

A model should not be “strict” just for the sake of it. `extra="forbid"` is useful when unexpected fields indicate a client bug; a public evolving API may instead need versioning or a documented tolerance policy. Limits should be based on the application contract, not arbitrary values that cause valid requests to fail.

## Exercise

Add an IP address validator using `ipaddress.ip_address`. Test IPv4, IPv6, whitespace, a malformed string, VLAN 0 and VLAN 4095. Decide how the API should present errors without leaking stack traces.

## Checkpoint

Explain which checks belong in a request model and which belong in the service layer—for example, validating address syntax versus verifying that an address is allowed by a specific inventory policy.
