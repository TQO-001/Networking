---
title: "Build a network inventory validator"
description: "Read device records, validate required fields and flag duplicate IP addresses without contacting any device."
order: 1
minutes: 25
level: "Beginner–Intermediate"
course: "python-for-network-engineers"
module: "Inventory and data"
tags: ["csv", "json", "validation", "ipaddress"]
kind: "lesson"
---

## The task

Network inventories drift. A spreadsheet can contain duplicate addresses, missing device names, malformed prefixes, or a VLAN value stored as free text. Validate the data before using it for monitoring.

We will keep the first version offline. It reads a JSON file and reports problems; it does not resolve hostnames, ping addresses or connect to equipment.

`sample-inventory.json`:

```json
[
  {"name": "SW-LAB-01", "address": "192.0.2.10", "vlan": 10, "role": "switch"},
  {"name": "PLC-SIM-01", "address": "192.0.2.20", "vlan": 20, "role": "simulator"}
]
```

Create `inventory.py`:

```python
import json
from ipaddress import ip_address
from pathlib import Path

REQUIRED = {"name", "address", "vlan", "role"}

def validate_records(records: list[dict[str, object]]) -> list[str]:
    errors: list[str] = []
    seen: dict[str, str] = {}
    for row_number, record in enumerate(records, start=1):
        missing = REQUIRED - record.keys()
        if missing:
            errors.append(f"Row {row_number}: missing {', '.join(sorted(missing))}")
            continue
        name = str(record["name"]).strip()
        address_text = str(record["address"]).strip()
        if not name:
            errors.append(f"Row {row_number}: name is empty")
        try:
            parsed = ip_address(address_text)
        except ValueError:
            errors.append(f"Row {row_number}: invalid IP address {address_text!r}")
            continue
        normalized = str(parsed)
        if normalized in seen:
            errors.append(f"Row {row_number}: address duplicates {seen[normalized]}")
        else:
            seen[normalized] = name or f"row {row_number}"
        vlan = record["vlan"]
        if not isinstance(vlan, int) or isinstance(vlan, bool) or not 1 <= vlan <= 4094:
            errors.append(f"Row {row_number}: VLAN must be an integer from 1 to 4094")
    return errors

def load_inventory(path: Path) -> list[dict[str, object]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, list) or not all(isinstance(item, dict) for item in data):
        raise ValueError("Inventory must be a JSON list of objects")
    return data
```

The VLAN range above covers ordinary 802.1Q VLAN IDs but does not decide whether a VLAN is valid in your environment; reserved IDs and local design rules need additional validation.

## Why normalise an IP address?

`ipaddress.ip_address()` turns the string into a typed object and rejects malformed input. Converting it back to a string gives a normal representation to compare, so equivalent IPv6 formats do not accidentally bypass duplicate detection.

## Your exercise

Add tests for a missing name, invalid IP, duplicate address, invalid VLAN and a valid inventory. Add a CSV loader only after the JSON path passes.

## Checkpoint

The tool should produce a useful list of errors without opening a socket or sending traffic. That separation keeps data quality checks safe and easy to test.
