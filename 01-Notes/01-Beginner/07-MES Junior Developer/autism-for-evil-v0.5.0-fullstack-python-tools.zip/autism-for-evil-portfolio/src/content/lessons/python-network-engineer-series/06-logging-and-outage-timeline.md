---
title: "Turn checks into an outage timeline"
description: "Record timestamped, structured monitoring events that can be reviewed after an issue."
order: 6
minutes: 20
level: "Intermediate"
course: "python-for-network-engineers"
module: "Monitoring and diagnostics"
tags: ["logging", "timestamps", "outage-analysis"]
kind: "lesson"
---

## Don't make a monitoring tool depend on terminal output

`print()` is useful while learning. Logging adds levels, timestamps and a central way to control messages. Keep human-readable output separate from the machine-readable record that can be analysed later.

```python
import logging
from datetime import datetime, timezone

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger("ot_monitor")

def record_result(target: str, reachable: bool) -> dict[str, str | bool]:
    event = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "target": target,
        "reachable": reachable,
    }
    if reachable:
        logger.info("Reachability check succeeded for %s", target)
    else:
        logger.warning("Reachability check failed for %s", target)
    return event
```

UTC timestamps simplify comparison across systems and daylight-saving changes. Store event time explicitly; a row's position in a file is not a safe substitute for event time.

## What belongs in the record?

A useful monitoring event might include target ID, check method, time, duration, outcome and a reason code. Avoid putting credentials, complete command output or sensitive packet payloads into the log. Logging should help explain what happened, not create a second security problem.

## Calculate an outage window carefully

A failed check is a point-in-time observation. If checks happen every 30 seconds, the exact failure start is not known; you can bound it between the last success and the first failure. Likewise, a recovered status observed at 10:05 does not prove the service recovered at precisely 10:05.

## Exercise

Write event records as JSON Lines (one JSON object per line). Create a report from a provided sample where events alternate between success and failure. Calculate the observed failure interval and label it as an estimate.

## Checkpoint

A report must distinguish the observation from the conclusion, include timestamps with time zones, and avoid claiming root cause from reachability data alone.
