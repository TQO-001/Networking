---
title: "A project is more than a Python file"
description: "Learn to arrange code, tests, configuration and documentation so another developer can understand and run your work."
order: 10
minutes: 18
level: "Beginner–Intermediate"
course: "shared-python-foundations"
module: "Professional workflow"
tags: ["structure", "src-layout", "uv", "readme"]
kind: "lesson"
---

## The problem this solves

A file named `main.py` is a perfectly good place to begin. It becomes harder to maintain when it must parse input, validate data, print reports, handle errors and talk to other systems. Professional structure separates responsibilities without making the project unnecessarily complicated.

```text
subnet-tool/
├── pyproject.toml       # project and tool configuration
├── README.md            # what it does and how to run it
├── .gitignore           # files Git should not track
├── src/
│   └── subnet_tool/
│       ├── __init__.py
│       ├── calculator.py  # reusable network calculations
│       └── cli.py         # arguments and terminal output
└── tests/
    └── test_calculator.py
```

`calculator.py` contains logic that can be tested without running a terminal command. `cli.py` is the boundary between a person and that logic. In a web API, the boundary might be an HTTP endpoint instead.

## Create a project with uv

From the folder where you keep your learning repositories:

```bash
uv init --package subnet-tool
cd subnet-tool
uv python pin 3.14
uv add --dev pytest ruff
```

uv creates project files and manages an isolated environment. The exact initial files can differ by uv version; read `pyproject.toml` rather than assuming the tool did something invisible. `uv.lock` records resolved dependencies after a sync.

## The rule of small responsibilities

A function should generally do one understandable job. A reusable calculation should not also ask for keyboard input, write a file and print a banner. Separating these jobs makes it easier to test, reuse and change the program.

## Exercise

Take one of your existing scripts and draw three boxes: input, core logic, output. Identify which lines belong to each box. You do not need to split the code yet.

**Hint:** input/output are the edges of the program; the core logic should be testable without either.

## Checkpoint

Explain why `calculate_subnet()` is easier to test when it returns a result instead of printing it directly. Then add a README with purpose, requirements, setup, an example command, and known limitations.
