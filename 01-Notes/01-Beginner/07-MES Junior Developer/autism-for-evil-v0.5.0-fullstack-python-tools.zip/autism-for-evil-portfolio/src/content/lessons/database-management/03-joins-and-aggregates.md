---
title: "Join related rows and summarise them"
description: "Use JOIN, GROUP BY and aggregate functions to answer questions across related tables."
order: 3
minutes: 25
level: "Beginner–Intermediate"
course: "database-management"
module: "SQL foundations"
tags: ["sql", "joins", "group-by", "aggregates"]
kind: "lesson"
---

## Joins combine related facts

A join uses a relationship to produce a result across tables. An inner join only returns matching rows. A left join keeps rows from the left table even when no matching row exists on the right.

```sql
SELECT d.asset_tag, i.interface_name
FROM devices AS d
JOIN interfaces AS i ON i.device_id = d.device_id
ORDER BY d.asset_tag, i.interface_name;
```

Use `LEFT JOIN` when you need to identify devices that do not yet have an interface record:

```sql
SELECT d.asset_tag
FROM devices AS d
LEFT JOIN interfaces AS i ON i.device_id = d.device_id
WHERE i.interface_id IS NULL;
```

## Aggregation

```sql
SELECT d.asset_tag, COUNT(i.interface_id) AS interface_count
FROM devices AS d
LEFT JOIN interfaces AS i ON i.device_id = d.device_id
GROUP BY d.device_id, d.asset_tag
ORDER BY interface_count DESC, d.asset_tag;
```

`COUNT(*)` counts joined rows, including a null-extended row from a left join; `COUNT(i.interface_id)` counts non-null interface identifiers. That distinction is easy to miss.

## Exercise

Create three devices and a few interfaces in a lab database. Write queries for interfaces per device, devices with no interfaces and roles by count. Verify the output against the sample rows instead of trusting that SQL syntax alone means the result is right.

## Checkpoint

Explain the difference between inner and left joins and why aggregate queries need grouping rules.
