---
title: "Build a reliable API client"
description: "Learn HTTP methods, status codes, JSON validation, timeouts and separation between transport and application logic."
order: 7
minutes: 26
level: "Intermediate"
course: "python-for-developers"
module: "HTTP and APIs"
tags: ["http", "json", "api-client"]
kind: "lesson"
---

## What HTTP gives you

HTTP defines requests and responses. A client sends a method, URL, headers and sometimes a body; the server responds with a status code, headers and a body. JSON is a common representation, but `Content-Type: application/json` is not proof that the body matches your expected schema.

The shared foundations already introduced JSON. Here the extra work is handling the network boundary: timeout, HTTP errors, decoding and validation. Start with Python's standard library so the request lifecycle stays visible. You can adopt `httpx` or `requests` later if a project benefits from their ergonomics.

```python
import json
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

def fetch_status(url: str) -> dict[str, object]:
    request = Request(url, headers={"Accept": "application/json"})
    try:
        with urlopen(request, timeout=3) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        raise RuntimeError(f"API HTTP error {exc.code}") from exc
    except (URLError, TimeoutError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("Could not retrieve a valid API response") from exc
    if not isinstance(payload, dict):
        raise ValueError("Expected an object in the API response")
    return payload
```

This only checks the top-level shape. For a real API, validate required fields and types using explicit checks or Pydantic. Avoid exposing a route that lets public users supply arbitrary URLs; that can create server-side request forgery risks when the client can reach internal services.

## Exercise

Mock the HTTP call and test valid JSON, malformed JSON, HTTP 404, timeout and a list returned where an object is expected. Tests should run offline.

## Checkpoint

Describe which failures are transport failures, which are HTTP status failures and which are response-validation failures.
