---
title: "Start here: how this course works"
description: A friendly map of the course, the tools we will use, and what it means to learn Python by building network tools.
order: 0
minutes: 8
level: Beginner
course: shared-python-foundations
tags: [orientation, beginner, study-skills]
kind: guide

module: "Python foundations"
---
Welcome. This course assumes you have **little or no Python experience**. You do not need to memorise everything, and you do not need to understand all the code at first glance. Your job is to build a mental model one small piece at a time.

The point is to become an OT/network engineer who can make useful tools: check an inventory, make sense of logs, measure availability, and eventually read telemetry from industrial systems in an approved lab.

## What we are going to build

Our path goes from tiny programs to engineering tools:

1. Run a Python file and understand what the terminal is doing.
2. Store and compare values.
3. Make decisions and repeat tasks.
4. Organise code into functions.
5. Read a device inventory from a CSV file.
6. Handle invalid data and test your work.
7. Build a first subnet calculator.
8. Extend that foundation into monitoring and industrial protocol projects.

The first few steps may feel simple. That is deliberate. Professional tools are made from small ideas combined carefully.

## A few words in plain language

| Word | What it means here |
|---|---|
| **Program** | Instructions written so a computer can perform a task. |
| **Script** | A small program commonly run from a terminal. |
| **Terminal** | A text-based place to run commands and see output. |
| **Input** | Information a program receives. |
| **Output** | Information a program produces. |
| **Bug** | A mistake that makes a program behave incorrectly. |
| **Library** | Code somebody has already written that your program can reuse. |
| **Test** | A repeatable check that a piece of code behaves as expected. |

## How to study each lesson

**Read → type → run → change → explain.** Type the example yourself rather than pasting every line. Run it. Change one value and predict the result before running it again. Then explain—in your own words—what changed and why.

When something breaks, copy the complete error message into your notes. An error is information. Learning to read it is part of learning to program.

> [!TIP]
> Keep a `learning-log.md` file. After each session, write three things: what you learned, what confused you, and one question you can investigate next time.

## Your working rules

- Use fictional data or systems you own or are explicitly allowed to test.
- Never put real workplace credentials or confidential network details in a public repository.
- Make one small change at a time; that makes errors easier to locate.
- Keep your working code even when you improve it. Git will later help you track that history.
- Do not move ahead because a page is finished. Move ahead when you can complete the checkpoint.

## Checkpoint

Before moving on, you should be able to explain the difference between a program, an input, an output and a bug. No code is required for this checkpoint.

**Next:** open [Set up your environment](/learn/python-for-network-engineers/01-set-up-your-environment/).
