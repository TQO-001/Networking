---
title: "Measure performance before optimising"
description: "Use repeatable measurements and profiling to locate expensive work before changing algorithms or adding caches."
order: 14
minutes: 22
level: "Intermediate–Advanced"
course: "python-for-developers"
module: "Quality and performance"
tags: ["profiling", "performance", "benchmarking"]
kind: "lesson"
---

## Guessing is a poor profiler

If an application feels slow, first measure where the time goes. `time.perf_counter()` is useful for a small elapsed-time measurement. `cProfile` can profile Python call counts and cumulative time. For accurate comparisons, use representative data, run multiple iterations and record the environment.

```python
from time import perf_counter

def measure(label: str, operation) -> None:
    started = perf_counter()
    operation()
    elapsed = perf_counter() - started
    print(f"{label}: {elapsed:.4f}s")
```

The helper is useful for quick experiments but is not a benchmarking framework. Printing, disk I/O, cold caches, virtual machines and background processes can distort measurements. Keep benchmark inputs stable and avoid timing one tiny run and calling it proof.

## A safe optimisation order

1. Reproduce and measure the problem.
2. Profile the code to find the costly section.
3. Check whether the cost is CPU, memory, network waiting or database waiting.
4. Make one change.
5. Run the tests and measure again.
6. Keep the change only if it improves the relevant outcome without breaking behaviour.

Caching adds invalidation and staleness problems. Async adds concurrency complexity. Indexes consume storage and write overhead. Optimisation should address measured bottlenecks rather than fashionable techniques.

## Exercise

Create a synthetic list of records and compare a simple loop with a comprehension for readability and speed. Do not assume the shorter version is faster. Use `cProfile` on a more substantial operation and write a short result note.

## Checkpoint

Your performance note includes the measurement method, input size, environment, before/after result and remaining limitations.
