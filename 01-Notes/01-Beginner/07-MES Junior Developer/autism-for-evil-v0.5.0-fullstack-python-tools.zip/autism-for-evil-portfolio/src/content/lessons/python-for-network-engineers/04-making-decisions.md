---
title: "Make decisions with if, elif and else"
description: Teach a program to choose what to do based on device status and inventory rules.
order: 4
minutes: 20
level: Beginner
course: shared-python-foundations
tags: [conditions, booleans, logic]
kind: lesson

module: "Python foundations"
---
So far, our program has printed the same message every time. Real tools need to respond to the data they receive. A reachability checker might report one device as reachable and another as unreachable. An inventory validator might reject a record with a missing hostname.

Conditions let a program choose a path.

## 1. A simple condition

```python
is_reachable = True

if is_reachable:
    print("Device responded")
```

Read this as: “if `is_reachable` is true, print the message.” The colon `:` begins the block of code that belongs to the condition. The indented line is part of that block. Python uses indentation to define structure, so keep it consistent (VS Code will usually help).

Set `is_reachable = False` and run the program again. Because the condition is false, the indented line does not run.

## 2. Add an alternative

```python
is_reachable = False

if is_reachable:
    print("Device responded")
else:
    print("No response recorded")
```

`else` describes what to do when the `if` condition is false. This example reports a failed check; it does not prove a device is physically broken. A device might block the chosen test, be offline, or have a connectivity issue. Good tools describe what they measured without claiming more than the measurement supports.

## 3. Choose from more than two paths

```python
status = "unknown"

if status == "reachable":
    print("Response received")
elif status == "unreachable":
    print("No response within the test window")
else:
    print("No check has been completed yet")
```

`==` compares two values. It is different from the assignment symbol `=`. `elif` means “otherwise, if this other condition is true.” Python checks conditions from top to bottom and runs the first matching branch.

## 4. Compare numbers and combine conditions

```python
vlan_id = 20

if vlan_id < 1 or vlan_id > 4094:
    print("VLAN ID is outside the usual VLAN range")
else:
    print("VLAN ID is within the usual numeric range")
```

The operators `>`, `<`, `>=`, `<=`, `==` and `!=` compare values. `and` requires both conditions to be true; `or` requires at least one to be true; `not` reverses a boolean value.

This example only validates a numeric range. Real device configurations can impose additional rules, so keep the scope of your validation clear.

## Exercise: inventory checks

Start with these values:

```python
hostname = ""
ip_address = "192.168.10.20"
```

Write conditions that print `Missing hostname` when the hostname is empty, otherwise print `Hostname provided`. Then add a check that reports whether the IP-address variable is empty. Do not try to validate a complete IP address yet; we will use Python's `ipaddress` library for that later.

**Done when:** you can explain `if`, `elif`, `else`, `=` and `==`, and your program behaves differently when you change its input values.

**Next:** [Lists and loops](/learn/python-for-network-engineers/05-lists-and-loops/).
