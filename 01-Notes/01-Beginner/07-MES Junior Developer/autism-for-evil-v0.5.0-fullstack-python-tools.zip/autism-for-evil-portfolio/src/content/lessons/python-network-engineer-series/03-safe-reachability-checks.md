---
title: "Build a bounded reachability checker"
description: "Learn subprocess, timeout handling and platform-aware ping behaviour without turning the tool into a scanner."
order: 3
minutes: 25
level: "Intermediate"
course: "python-for-network-engineers"
module: "Monitoring and diagnostics"
tags: ["subprocess", "timeouts", "safe-monitoring"]
kind: "lesson"
---

## Define the scope first

This lesson uses a tiny explicit list of documentation addresses and checks at most one host at a time. In an actual workplace, use only targets approved by the network owner. Start with a VM or simulator; do not discover targets by scanning a production OT network.

ICMP echo is not a universal health check. Some systems block ping while their application works, and an online machine may still have a failed service. Report the result as **ICMP response observed** rather than “device healthy”.

## Why subprocess and timeouts?

The operating system's `ping` utility is not perfectly identical across Windows and Linux. Flags for count and timeout differ, and the process can fail to start. A robust helper chooses the platform-specific arguments and always uses a bounded process timeout.

```python
import platform
import subprocess
from dataclasses import dataclass

@dataclass(frozen=True)
class PingResult:
    target: str
    responded: bool
    detail: str

def ping_once(target: str, timeout_seconds: float = 2.0) -> PingResult:
    if timeout_seconds <= 0:
        raise ValueError("timeout_seconds must be positive")
    system = platform.system().lower()
    if system == "windows":
        command = ["ping", "-n", "1", "-w", str(int(timeout_seconds * 1000)), target]
    elif system in {"linux", "darwin"}:
        command = ["ping", "-c", "1", "-W", str(max(1, int(timeout_seconds))), target]
    else:
        return PingResult(target, False, f"Unsupported operating system: {system}")
    try:
        result = subprocess.run(command, capture_output=True, text=True,
                                timeout=timeout_seconds + 1, check=False)
    except subprocess.TimeoutExpired:
        return PingResult(target, False, "ping process exceeded timeout")
    except OSError as exc:
        return PingResult(target, False, f"could not execute ping: {exc}")
    return PingResult(target, result.returncode == 0,
                      "response observed" if result.returncode == 0 else "no response observed")
```

Operating-system `ping` timeout semantics vary by implementation. Treat this as a learning example, test it on both systems, and document its limits. Validate targets against an approved inventory before polling in any real environment; string validation alone is not authorisation.

## Exercise

Write tests for an invalid timeout and unsupported platform using a mocked `platform.system` and mocked `subprocess.run`. Do not require a live target to run your test suite.

## Checkpoint

Your monitor must never wait indefinitely. It must report the method used, a timestamp, and the difference between a timeout and an observed response where the available signals allow it.
