---
title: "Use ipaddress for network planning"
description: "Compare IP addresses and subnets using the standard library instead of manually manipulating address strings."
order: 2
minutes: 20
level: "Intermediate"
course: "python-for-network-engineers"
module: "Inventory and data"
tags: ["ipaddress", "subnets", "address-planning"]
kind: "lesson"
---

## Why use a library?

An IPv4 address is a 32-bit value and an IPv6 address is 128 bits. Parsing, prefix arithmetic, host membership and canonical formatting are easy to get wrong if you treat an address as a string. Python's `ipaddress` module handles these rules.

```python
from ipaddress import ip_address, ip_network

network = ip_network("192.0.2.0/27")
address = ip_address("192.0.2.12")
print(network.network_address)       # 192.0.2.0
print(network.netmask)               # 255.255.255.224
print(address in network)             # True
print(network.num_addresses)          # 32
```

The `192.0.2.0/24` block is reserved for documentation examples. It is not a real target network.

## Be careful with IPv4 and IPv6 differences

IPv4 broadcast addresses are meaningful in a way that IPv6 does not use. Do not label the last IPv6 address as a broadcast address. Use the module's IPv4/IPv6-specific properties, and do not rely on older rules like “subtract two” without considering special prefixes such as `/31` and `/32`.

`ip_network(value, strict=True)` rejects host bits set in a network address. If you intentionally want to normalise a host address to its network, `strict=False` may be appropriate—but it should be a deliberate design choice, not a way to hide a typo.

## Check whether two networks overlap

```python
from ipaddress import ip_network

production = ip_network("192.0.2.0/26")
management = ip_network("192.0.2.32/27")
print(production.overlaps(management))  # True
```

An overlap checker can identify conflicting address plans before a change is made. Whether two subnets are allowed to overlap depends on context; the program can detect overlap, but a human design rule determines whether it is an error.

## Exercise

Read a list of CIDR ranges and report pairs that overlap. Ignore malformed records with a clearly labelled error instead of crashing the whole report. Add IPv4 and IPv6 tests.

## Checkpoint

Be able to explain the difference between an IP address, a network interface address and a subnet. Your program should use `ipaddress`, not string slicing, for the calculation.
