---
title: "Handle failures and clean up resources"
description: "Use exceptions for exceptional cases, logs for diagnostics and context managers for reliable cleanup."
order: 3
minutes: 24
level: "Intermediate"
course: "python-for-developers"
module: "Maintainable Python"
tags: ["exceptions", "logging", "context-managers"]
kind: "lesson"
---

## Handle errors at the level that can respond

A low-level function should usually raise a meaningful exception when it cannot fulfil its contract. The caller can then decide whether to show a message, retry, return an HTTP error or stop the job. Catching every exception and returning `None` hides the difference between valid empty data and a failed operation.

```python
from pathlib import Path
import json

def load_settings(path: Path) -> dict[str, object]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"Settings file does not exist: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Settings file is not valid JSON: {path}") from exc
    if not isinstance(value, dict):
        raise ValueError("Settings must be a JSON object")
    return value
```

## Context managers

`with` makes resource cleanup predictable. File objects and database connections often need cleanup even if an exception is raised. A context manager packages setup and cleanup so callers do not have to remember every exit path.

```python
from pathlib import Path

with Path("report.txt").open("w", encoding="utf-8") as report:
    report.write("Report generated\n")
```

The context manager closes the file after the block. For sockets and database transactions, the exact context-manager behaviour is library-specific: check whether exiting commits, rolls back, or merely closes the connection.

## Logging

Use `logging` rather than scattering debug `print()` calls in production code. Log operational context such as request IDs and error categories, but do not log secrets or sensitive payloads. Keep the user-facing message useful without exposing stack traces to untrusted clients.

## Exercise

Write a configuration loader. Test missing file, malformed JSON and an unexpected top-level type. Log the error once at the application boundary rather than duplicating a stack trace in every helper.

## Checkpoint

Show how a file or connection is closed on both success and failure, and explain why broad `except Exception: pass` is dangerous.
