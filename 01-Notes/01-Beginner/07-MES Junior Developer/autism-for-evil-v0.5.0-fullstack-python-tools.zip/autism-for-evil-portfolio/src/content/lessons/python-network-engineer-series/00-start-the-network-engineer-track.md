---
title: "Start here: from Python basics to network tools"
description: "Map the specialist series, understand prerequisites and learn the safe workflow used for all network exercises."
order: 0
minutes: 8
level: "Beginner–Intermediate"
course: "python-for-network-engineers"
module: "Course map"
tags: ["orientation", "networking", "safety"]
kind: "guide"
---

## Where this track begins

You have already completed the first beginner course: Python syntax, control flow, functions, CSV files, validation, tests and a first subnet calculator. This series **does not repeat those lessons**. It applies them to bigger, more realistic tools.

Before starting, revisit the [shared Python foundations](/courses/python-foundations/), especially project structure, Git, pytest, Ruff, JSON and logging. Those skills are shared with the developer course.

## The path ahead

1. **Data and inventory:** validate structured asset records and reason about IP addresses.
2. **Monitoring:** make bounded reachability checks, observe interfaces and record useful logs.
3. **Troubleshooting:** analyse exported logs and packet captures without requiring live production access.
4. **Network services:** understand HTTP APIs, timeouts, limited concurrency and failure handling.
5. **Industrial protocols:** use OPC UA and Modbus only against an isolated simulator or explicitly approved lab endpoint.
6. **Capstone:** combine an inventory, polling cycle, event history and report.

## The operational safety model

A script can repeat an action much faster than a person. Start with read-only operations, explicit target lists, strict timeouts, small request rates and logs. Do not scan a production OT subnet or poll controllers because an exercise says to do so. Confirm scope with the responsible engineer first, and prefer simulators for practice.

Throughout this course we use reserved documentation IP addresses and simulated data. Successful TCP connections or failed pings are observations, not complete proof of device health. Firewalls, ICMP policy, routing, rate limits and application-level faults all affect what you see.

## Checkpoint

Write a short note describing which targets your lab permits, who approved them, and which checks are safe. If you have no approved lab yet, use offline fixtures and simulators for now.
