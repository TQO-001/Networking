---
title: "Parse logs into useful evidence"
description: "Build a defensive parser for a known log format and summarise events without making assumptions about every vendor log."
order: 7
minutes: 25
level: "Intermediate"
course: "python-for-network-engineers"
module: "Troubleshooting and traffic"
tags: ["re", "datetime", "parsing", "logs"]
kind: "lesson"
---

## Parse a known format, not “all logs”

Logs differ across operating systems, switches, firewalls and applications. A parser should state the format it expects, reject or count lines that do not match, and preserve the original file. Do not modify production logs to make the parser happy.

For a simple training format:

```text
2026-10-27T08:10:00Z WARN interface=Gi1/0/1 event=link_down
2026-10-27T08:10:12Z INFO interface=Gi1/0/1 event=link_up
```

A regular expression can capture fields from this known shape:

```python
import re

PATTERN = re.compile(
    r"^(?P<timestamp>\S+) (?P<severity>DEBUG|INFO|WARN|ERROR) "
    r"interface=(?P<interface>\S+) event=(?P<event>[a-z_]+)$"
)

def parse_line(line: str) -> dict[str, str] | None:
    match = PATTERN.fullmatch(line.strip())
    return match.groupdict() if match else None
```

This is intentionally narrow. Real syslog has multiple shapes; first inspect samples and define the exact subset you support. Avoid one enormous regex intended to guess everything.

## Summarise, don't overinterpret

Count events by severity and interface; identify link-down events followed by link-up events. A parser can show a sequence of observations, but cannot conclude a cable is faulty without further evidence. Interfaces can go down for maintenance, administrative shutdown or many other reasons.

## Exercise

Write a script that processes a sample file, counts parse failures and writes valid events to CSV. Add tests for a normal line, unknown severity, missing field and extra characters. Preserve invalid lines in a separate review file if the report requires an audit trail.

## Checkpoint

The output must say which format was parsed, how many lines were processed, and how many were skipped. This prevents a clean-looking report from hiding a parser that discarded half the file.
