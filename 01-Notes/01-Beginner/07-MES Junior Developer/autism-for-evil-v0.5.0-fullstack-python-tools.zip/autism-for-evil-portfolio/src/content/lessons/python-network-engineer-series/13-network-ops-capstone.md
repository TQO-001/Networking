---
title: "Capstone: build a small network operations toolkit"
description: "Bring inventory validation, bounded checks, structured events, reporting and tests into one maintainable application."
order: 13
minutes: 35
level: "Intermediate–Advanced"
course: "python-for-network-engineers"
module: "Capstone"
tags: ["capstone", "architecture", "observability", "portfolio"]
kind: "project"
---

## The brief

Build a command-line tool for a fictional or isolated lab inventory. It should validate records, run explicitly selected checks, write a timestamped report and make failures easy to review. This is a training project, not a replacement for a production NMS.

## Functional requirements

- Load a JSON or CSV inventory and validate it before any check runs.
- Require an explicit `--check` option and default to offline validation only.
- Permit only targets from the approved inventory; never scan a range implicitly.
- Use bounded timeouts, conservative concurrency and one polling cycle at a time.
- Record UTC timestamps, check method, outcome, duration and reason code.
- Write JSON Lines for event records and a concise human-readable summary.
- Exit with a documented code for invalid inventory or an operational failure.

## Suggested structure

```text
network-ops-tool/
├── pyproject.toml
├── README.md
├── src/network_ops/
│   ├── __init__.py
│   ├── inventory.py
│   ├── checks.py
│   ├── events.py
│   ├── reports.py
│   └── cli.py
└── tests/
    ├── test_inventory.py
    ├── test_checks.py
    └── test_reports.py
```

The boundaries are intentional: tests can provide fake checks and sample inventories without reaching a real network. Later you may add a PostgreSQL backend after completing the shared database course.

## Definition of done

1. A new developer can follow the README on Windows and Linux.
2. `uv sync`, `uv run pytest`, and Ruff checks work from a clean checkout.
3. Malformed input yields actionable errors and never starts network checks.
4. No credentials or real workplace data appear in source, fixtures, logs or screenshots.
5. Tests cover expected results, timeouts, duplicate inventory addresses and output encoding.
6. The README states scope, limitations, safety assumptions and what the tool does *not* prove.

## Stretch goals

Add an offline PCAP report, one simulator-only industrial-protocol adapter or a PostgreSQL event store. Do not add all three at once. Keep each addition behind an interface and prove it with tests.

## Portfolio write-up

Explain the problem, architecture, trade-offs, safety boundaries, example report and what you learned from a bug. Screenshots should use synthetic data. Clearly identify which features are implemented and which remain planned.
