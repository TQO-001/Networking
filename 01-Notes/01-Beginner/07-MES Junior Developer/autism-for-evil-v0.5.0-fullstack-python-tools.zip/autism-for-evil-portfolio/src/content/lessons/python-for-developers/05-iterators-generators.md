---
title: "Use iterators and generators for streams of data"
description: "Process records one at a time when reading a large file or event stream instead of holding every row in memory."
order: 5
minutes: 20
level: "Intermediate"
course: "python-for-developers"
module: "Maintainable Python"
tags: ["iterators", "generators", "memory"]
kind: "lesson"
---

## Lists versus streams

A list contains all its elements at once. A generator produces values as the program asks for them. Streaming is useful when reading a large log, processing packet summaries or returning rows from a data source in batches.

```python
from collections.abc import Iterator
from pathlib import Path

def nonempty_lines(path: Path) -> Iterator[str]:
    with path.open(encoding="utf-8") as source:
        for line in source:
            cleaned = line.strip()
            if cleaned:
                yield cleaned
```

Calling `nonempty_lines(path)` returns a generator; it does not immediately read the whole file. The file remains open while iteration is active and closes when the generator finishes or is closed. Consume it promptly and avoid keeping abandoned generators around.

## Generator expressions

```python
large_lines = (line for line in nonempty_lines(Path("sample.log")) if len(line) > 100)
for line in large_lines:
    print(line[:80])
```

This is memory-efficient for sequential work, but it is not always faster. If you need to traverse data repeatedly, sort it, or index it, a list or database query may be more appropriate.

## Exercise

Create a generator that yields only events with severity `ERROR` from a fictional log fixture. Count matching events without creating an intermediate list. Test that a second iteration over the same generator yields no items, then explain why a generator is normally consumed once.

## Checkpoint

Explain the difference between returning a list and yielding values, and name one case where streaming makes the program simpler or more memory-efficient.
