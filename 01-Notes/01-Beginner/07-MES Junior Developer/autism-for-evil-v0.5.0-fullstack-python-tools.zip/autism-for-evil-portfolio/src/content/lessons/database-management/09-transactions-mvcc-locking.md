---
title: "Understand transactions, MVCC and locking"
description: "Learn why concurrent database sessions see different versions of data and how to reason about contention."
order: 9
minutes: 28
level: "Intermediate–Advanced"
course: "database-management"
module: "Reliability and concurrency"
tags: ["transactions", "mvcc", "locking", "isolation"]
kind: "lesson"
---

## More than one user can change data

A database often serves several requests at once. PostgreSQL uses multiversion concurrency control (MVCC) so a transaction can read a consistent view of rows while other transactions make changes. This improves concurrency, but does not eliminate all conflicts.

Isolation levels describe which concurrent anomalies a transaction may observe. `READ COMMITTED` is PostgreSQL's default and each statement generally sees a snapshot taken when that statement begins. `REPEATABLE READ` keeps a transaction snapshot more stable. `SERIALIZABLE` aims to make successful transactions behave as if they ran in some serial order, but a transaction may need to be retried after a serialization failure.

## Keep transactions short

Long-running transactions can hold locks, delay cleanup and increase operational pressure. Do not keep a transaction open while waiting for user input, calling a slow external API or polling an industrial device. Fetch what you need, keep database writes bounded and commit/rollback promptly.

## Deadlocks and retries

A deadlock occurs when transactions wait on each other's locks in a cycle. PostgreSQL detects deadlocks and aborts one transaction. Consistent lock ordering and short transactions reduce the chance. A retry must be limited, use backoff, and repeat a transaction whose effects are safe to retry. Not every failure should be retried.

## Exercise

In two sessions on a disposable database, begin transactions and update rows in opposite orders to observe lock waiting and a deadlock. Do this only in a lab database. Document the error and what PostgreSQL did.

## Checkpoint

Explain why a transaction does not mean “nobody else can touch the database” and why a long transaction around a network request is poor design.
