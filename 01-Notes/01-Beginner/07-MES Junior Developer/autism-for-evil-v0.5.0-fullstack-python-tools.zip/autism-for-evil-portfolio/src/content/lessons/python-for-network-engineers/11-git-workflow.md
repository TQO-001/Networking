---
title: "Git as a safety net"
description: "Practise a small, repeatable Git workflow for changes, experiments and recovery."
order: 11
minutes: 15
level: "Beginner–Intermediate"
course: "shared-python-foundations"
module: "Professional workflow"
tags: ["git", "github", "commits", "workflow"]
kind: "lesson"
---

## What Git does

Git records snapshots of your project and the changes between them. GitHub hosts a copy and adds collaboration tools; it is not a replacement for local Git. A commit is a named checkpoint, not a backup of everything on your computer.

## The everyday loop

```bash
git status
git add README.md src/subnet_tool/calculator.py
git commit -m "Add subnet calculation logic"
git log --oneline --max-count=5
```

`git status` is important because it tells you which changes are staged, unstaged or untracked. Stage only the files you intend to include. Before committing, inspect what will be recorded:

```bash
git diff
git diff --staged
```

## Ignore generated and private material

A Python `.gitignore` should normally exclude `.venv/`, `__pycache__/`, `.pytest_cache/`, `.ruff_cache/`, `.env`, and local build output. Never commit credentials, private keys, real workplace exports or identifiable network configurations. If a secret is committed, deleting it in a later commit does not remove it from the repository history; rotate it and follow your organisation's incident process.

## Branches without fear

A branch gives you a separate line of development for an experiment. Keep the default branch in a known-good state when possible. Branch names describe the task, for example `feature/json-export` or `fix/invalid-prefix`.

```bash
git switch -c feature/json-export
# make and test one focused change
git status
git add .
git commit -m "Add JSON report export"
git switch main
```

The example assumes your default branch is named `main`; check `git branch` if yours differs. Merging should be a deliberate action after tests pass.

## Exercise

Create a repository for one learning project. Make one commit for the README and a separate commit for a working feature. Intentionally edit a file without saving it to a commit, then use `git diff` to inspect the change.

## Checkpoint

You should be able to answer: what has changed, what is staged, what will enter the commit, and how would you inspect the last few commits?
