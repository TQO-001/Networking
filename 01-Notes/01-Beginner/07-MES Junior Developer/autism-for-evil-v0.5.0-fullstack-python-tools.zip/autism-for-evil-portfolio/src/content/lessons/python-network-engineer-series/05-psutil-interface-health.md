---
title: "Collect local interface health statistics"
description: "Use psutil to inspect the machine running your script and understand counter deltas over time."
order: 5
minutes: 24
level: "Intermediate"
course: "python-for-network-engineers"
module: "Monitoring and diagnostics"
tags: ["psutil", "network-interfaces", "metrics"]
kind: "lesson"
---

## Start with the local machine

`psutil` can report network interfaces and counters for the operating system where Python runs. It does not magically read all counters from a remote managed switch. To inspect a remote device, you need an approved management interface such as SNMP, a vendor API, or a device-specific telemetry service.

Install this project dependency only when the lesson starts:

```bash
uv add psutil
```

```python
import psutil

for name, counters in psutil.net_io_counters(pernic=True).items():
    print(name)
    print(f"  bytes sent: {counters.bytes_sent}")
    print(f"  bytes received: {counters.bytes_recv}")
    print(f"  errors in/out: {counters.errin}/{counters.errout}")
    print(f"  drops in/out: {counters.dropin}/{counters.dropout}")
```

Not every operating system or interface exposes every counter meaningfully. Some values may stay at zero or be unavailable. The interface names differ between Windows and Linux, so do not hard-code `eth0` or `Ethernet` as if it were universal.

## Why deltas are more useful than totals

The counter may be a cumulative total since boot. To measure traffic over a period, sample two readings and subtract the earlier counter from the later one. If the machine reboots or an interface resets, the counter may decrease; detect that instead of reporting a negative rate.

For example, bytes per second can be estimated as `(new_bytes - old_bytes) / elapsed_seconds`, provided the counter did not reset and elapsed time is positive. This is an estimate of the local interface counter, not application throughput.

## Exercise

Write a function that accepts two counter values and a duration. Reject a zero or negative duration; report a counter reset separately from a normal delta. Test it with fixed values instead of waiting in tests.

## Checkpoint

Your README must state that these are local OS counters. Add a screenshot or sample report generated from your own machine, but remove usernames, private IPs and other personal/workplace details before publishing it.
