---
title: "Treat schema changes as versioned code"
description: "Use repeatable migration files, review destructive changes and learn the expand/contract approach to safer deployments."
order: 11
minutes: 26
level: "Intermediate–Advanced"
course: "database-management"
module: "Reliability and concurrency"
tags: ["migrations", "schema-versioning", "deployment"]
kind: "lesson"
---

## A schema changes over time

Once an application depends on a database, changing a column can break old code, background jobs, reports or another service. A migration records a database change as versioned code, so deployments can apply and review changes consistently. Migration tools track which migrations ran; do not manually edit old migrations that have already been applied to shared environments without a coordinated plan.

## Expand, migrate, contract

For a potentially disruptive change, use stages:

1. **Expand:** add a compatible column or table while old code still works.
2. **Migrate:** write or backfill data, deploy code that reads/writes the new representation, verify consistency.
3. **Contract:** remove the old representation only after no deployed code depends on it.

This is safer than renaming or dropping a column in one deployment while old application instances still expect it.

## Index creation

PostgreSQL supports `CREATE INDEX CONCURRENTLY` to reduce write blocking compared with ordinary index creation, but it has operational trade-offs and restrictions (including not running inside an ordinary transaction block). Follow the version-specific PostgreSQL documentation and plan for failure/retry behaviour.

## Exercise

Write a migration plan adding a `description` field to a task API. State which versions of the application can run before and after each step, what happens during a failed backfill and how you would verify the data before removing an old field.

## Checkpoint

Your migration is reviewed, tested on a disposable copy, backed by a rollback/recovery plan and compatible with the intended deployment sequence. “It worked on my laptop” is not a migration strategy.
