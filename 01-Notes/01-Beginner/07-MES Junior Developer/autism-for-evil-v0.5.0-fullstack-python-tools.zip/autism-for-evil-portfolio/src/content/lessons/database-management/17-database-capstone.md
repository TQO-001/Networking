---
title: "Capstone: one database, two engineering contexts"
description: "Demonstrate the same relational skills in a Python application and in network operations without duplicating the foundational course."
order: 17
minutes: 35
level: "Intermediate–Advanced"
course: "database-management"
module: "Capstone"
tags: ["capstone", "database", "portfolio"]
kind: "project"
---

## Choose one implementation and explain the second

This capstone has two possible applications. You can build one first and describe how the same concepts transfer to the other; you do not have to complete two full systems at once.

**Developer option:** persist tasks behind a FastAPI service. Include migrations, parameterised queries, unique IDs, constraints, pagination and API tests.

**Network operations option:** store a fictional device inventory and timestamped monitoring events. Add queries for the latest observation, failure counts over a time range and assets with no recent observation. Keep actual polling in a separate Python service with explicit approved targets.

## Required engineering evidence

- ER diagram and a short rationale for relationships.
- Versioned schema/migrations.
- Seed data that is fully fictional.
- SQL queries that answer named questions.
- pytest coverage for the application's data-access boundary.
- Least-privilege database role and a documented backup/restore exercise.
- One measured query plan and an explanation of any index added.
- README explaining setup, environment variables, test isolation, limitations and safe-data policy.

## Definition of done

A new developer can reproduce the lab from instructions. No credentials are committed. Destructive tests run only against a disposable database. Reports distinguish missing observations from actual outages. Data is timestamped, queries are bounded where appropriate and schema changes are reviewed before application rollout.

## Stretch goals

Add audit history, JSONB for a clearly justified flexible attribute, or a time-based partition only if your dataset and query patterns justify the complexity. Show evidence for the decision instead of adding features to make the project look advanced.

## Portfolio write-up

Describe the problem, data model, integrity choices, query trade-offs, test strategy and recovery assumptions. If you deploy the demo publicly, publish synthetic data and disable any action that could reach real devices.
