---
title: "Protect database access and plan recovery"
description: "Apply least privilege, understand backup types and prove that a recovery plan can restore usable data."
order: 12
minutes: 27
level: "Intermediate–Advanced"
course: "database-management"
module: "Security and recovery"
tags: ["roles", "backup", "restore", "least-privilege"]
kind: "lesson"
---

## Permission design

PostgreSQL roles can own objects and receive privileges. Separate application access from administration. Grant only the needed schema/table privileges and avoid using a superuser account from application code. Row-level security (RLS) can restrict visible rows for multi-tenant designs, but it must be designed and tested carefully; table owners and privileged roles may bypass policies depending on the configuration.

## Backup is not complete until restore is tested

A logical backup exports database objects/data; a physical backup captures the database files in a supported way. Point-in-time recovery may require a compatible base backup plus a continuous archive of write-ahead log (WAL) segments. Which approach fits depends on size, recovery objectives and operations capability.

A backup job that reports success does not prove that restoration works. Run a restore test in an isolated environment, verify schema and critical rows, check ownership/permissions, and time how long the process takes. Define RPO (how much data loss is acceptable) and RTO (how long recovery may take) with stakeholders rather than choosing numbers arbitrarily.

## Exercise

For a disposable lab, create a backup, restore it into a separate database and verify row counts and a few known records. Document the commands and version. Never overwrite the source database as part of a learning restore.

## Checkpoint

Explain the role used by the application, the privilege boundary, what the backup includes, where it is stored and what evidence proves the restore worked.
