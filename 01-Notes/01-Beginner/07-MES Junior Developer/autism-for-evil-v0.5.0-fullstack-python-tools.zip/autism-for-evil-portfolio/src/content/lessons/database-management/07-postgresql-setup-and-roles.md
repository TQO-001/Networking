---
title: "Set up a safe PostgreSQL learning database"
description: "Learn how a database server, database, schema and role differ, and keep the lab separate from production."
order: 7
minutes: 24
level: "Beginner–Intermediate"
course: "database-management"
module: "PostgreSQL operations"
tags: ["postgresql", "setup", "roles", "permissions"]
kind: "lesson"
---

## The pieces

PostgreSQL is a database management system (DBMS). A PostgreSQL server manages connections and databases. A database contains schemas; schemas group objects such as tables, views and functions. Roles are used for identities and permissions. A role may be able to connect to a database without having unrestricted access to every table.

For learning, use an isolated local instance or disposable lab. Do not reuse workplace credentials or connect a tutorial to production. On Windows, a local installation may use the Windows service; on Linux, the installation and service manager vary by distribution. Follow the official installation path for your platform and record the PostgreSQL major version.

## Least privilege

Create separate roles for application access and administrative maintenance. An application role generally needs only the privileges required by its operations; it should not own the whole database or have superuser power. A read-only reporting account should not be able to write rows.

Connection strings can include passwords. Keep them out of source control, command history, screenshots and logs. Use a secret manager or deployment environment appropriate to the environment, and rotate credentials if exposed.

## Exercise

Create a disposable database and a role limited to a lab schema. Test both a permitted query and a denied action. Record the PostgreSQL version and the commands you used, but don't put passwords in your notes.

## Checkpoint

Explain the difference between a server, database, schema and role. Identify which account your Python application uses and why it should not be a superuser.
