---
title: "Understand tables, rows, keys and relationships"
description: "Learn the relational model and use primary and foreign keys to describe real entities."
order: 1
minutes: 22
level: "Beginner"
course: "database-management"
module: "SQL foundations"
tags: ["relational-model", "tables", "keys"]
kind: "lesson"
---

## What a relational database represents

A table represents one kind of thing or relationship. A row is one record; a column describes an attribute. A primary key uniquely identifies a row. A foreign key references a row in another table and helps enforce the relationship.

For example, an OT inventory may have `devices`, `interfaces` and `observations` tables. One device can have many interfaces; an interface can have many observations over time. Storing all interface and observation history in one giant table repeats device details and makes updates error-prone.

A developer application might have `users`, `tasks` and `comments`. The vocabulary changes, but the concepts are identical.

## A simple schema

```sql
CREATE TABLE devices (
    device_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    asset_tag TEXT NOT NULL UNIQUE,
    display_name TEXT NOT NULL,
    role TEXT NOT NULL
);

CREATE TABLE interfaces (
    interface_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    device_id BIGINT NOT NULL REFERENCES devices(device_id),
    interface_name TEXT NOT NULL,
    UNIQUE (device_id, interface_name)
);
```

The foreign key prevents an interface from referring to a nonexistent device. The composite unique constraint prevents two interface records on the same device having the same name. Whether the interface name should be case-sensitive depends on the intended data rules and database collation; decide that explicitly if it matters.

## Relationships

One-to-one, one-to-many and many-to-many relationships are different modelling decisions. A many-to-many relationship is normally represented by a junction table with two foreign keys. Do not store a comma-separated list of foreign IDs in one column when you need referential integrity and joins.

## Exercise

Draw an ER diagram for either a task tracker or a network inventory. Mark primary keys, foreign keys and the relationship cardinalities. Write down which table is the source of truth for each fact.

## Checkpoint

You can explain why the interface table needs a `device_id` foreign key and why an observation should refer to the interface it describes.
