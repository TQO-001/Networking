---
title: "Read OPC UA values from a lab server"
description: "Connect to a controlled OPC UA server, read selected values and record timestamps without writing to nodes."
order: 11
minutes: 28
level: "Intermediate–Advanced"
course: "python-for-network-engineers"
module: "OT protocols"
tags: ["opc-ua", "asyncua", "industrial-networking"]
kind: "lesson"
---

## Start with a simulator

OPC UA represents information as nodes in an address space. A client needs the endpoint, security policy, identity and node identifiers that the server actually exposes. These details are lab-specific; do not guess endpoint URLs or browse real OT networks looking for servers.

Install the library for this project:

```bash
uv add asyncua
```

A minimal asynchronous read-only client looks like this:

```python
import asyncio
from asyncua import Client

async def read_one(endpoint: str, node_id: str) -> object:
    async with Client(url=endpoint) as client:
        node = client.get_node(node_id)
        value = await node.read_value()
        return value

async def main() -> None:
    # Replace these lab values with the endpoint and node your simulator documents.
    value = await read_one("opc.tcp://127.0.0.1:4840", "ns=2;s=Demo.Temperature")
    print(value)

if __name__ == "__main__":
    asyncio.run(main())
```

The endpoint and node ID are examples and will only work if your simulator is configured to expose them. Do not weaken certificate validation or security policy just to make a connection succeed. Configure the client according to your lab's security setup.

## Record more than a number

Industrial data also has status/quality and source timestamps. A real monitor should record which node was read, when it was observed, the value's type, quality/status, errors and the configured polling interval. Handle timeouts and reconnects with bounded backoff. Do not run aggressive retry loops against a controller.

## Exercise

Use a local simulator to read one scalar value, then read a second node. Store values in JSON Lines with UTC timestamps. Add a fake client boundary so pytest can verify the reporting logic without an OPC UA server.

## Checkpoint

Your application only reads known test nodes, closes sessions cleanly and never writes values. Explain why “read-only in code” is not a replacement for correct credentials and server-side permissions.
