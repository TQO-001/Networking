---
title: "Understand async I/O and background work"
description: "Learn when asynchronous code helps, how to avoid blocking the event loop and why a background task needs operational rules."
order: 12
minutes: 25
level: "Intermediate–Advanced"
course: "python-for-developers"
module: "Backend development"
tags: ["asyncio", "async", "background-tasks"]
kind: "lesson"
---

## What async is—and is not

Asynchronous programming helps a program handle many operations that spend time waiting for I/O. It does not automatically make CPU-heavy code faster. An `async def` function returns a coroutine; it needs to be awaited or scheduled by an event loop.

```python
import asyncio

async def pretend_to_wait(name: str, seconds: float) -> str:
    await asyncio.sleep(seconds)
    return f"{name} finished"

async def main() -> None:
    results = await asyncio.gather(
        pretend_to_wait("first", 0.2),
        pretend_to_wait("second", 0.2),
    )
    print(results)

if __name__ == "__main__":
    asyncio.run(main())
```

`asyncio.sleep()` yields control to the event loop. Replacing it with `time.sleep()` would block the loop during the wait. The example is illustrative; no network requests are made.

## Concurrency needs limits

A server that starts an unlimited number of background tasks can exhaust memory, connections or device capacity. Use queues, semaphores, timeouts, cancellation and explicit capacity. Long-running work may need a separate worker system; in-process tasks can disappear when the server restarts.

## Exercise

Modify the example to compare sequential awaits with `asyncio.gather`. Then add a semaphore to limit concurrent simulated work to two tasks. Do not use a real industrial endpoint for this exercise.

## Checkpoint

Explain the difference between concurrency and parallelism, why blocking calls are a problem inside an async function and how you would bound background work.
