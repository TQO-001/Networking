---
title: "JSON, configuration and useful logs"
description: "Learn shared techniques for exchanging structured data, controlling settings and recording events."
order: 14
minutes: 22
level: "Beginner–Intermediate"
course: "shared-python-foundations"
module: "Professional workflow"
tags: ["json", "configuration", "logging", "cross-platform"]
kind: "lesson"
---

## JSON is a data format

CSV is useful for flat tables. JSON can represent nested objects and lists, so it is common in API responses and configuration files.

```python
import json
from pathlib import Path

settings = {
    "timeout_seconds": 3,
    "targets": ["192.0.2.10", "192.0.2.20"],
}
Path("settings.json").write_text(json.dumps(settings, indent=2), encoding="utf-8")
loaded = json.loads(Path("settings.json").read_text(encoding="utf-8"))
print(loaded["timeout_seconds"])
```

The `192.0.2.0/24` range is reserved for documentation examples. Do not replace example target addresses with workplace devices unless you have approval and a safe test plan.

## Configuration versus code

Configuration controls choices such as report paths, timeouts and approved target lists. Keep it separate from the logic so the same program can run in a classroom, test environment or workplace without editing source code. Validate configuration at startup and fail with a clear message if a required setting is missing or invalid.

Do not put credentials into a public JSON file or commit a `.env` file containing secrets. Environment variables are one way to provide deployment-specific secrets, but they are not encryption and can still leak through logs, process inspection or bad diagnostics.

## Logging is evidence

```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)
logger.info("Loaded %d targets", 2)
```

Use levels consistently: `DEBUG` for detail, `INFO` for ordinary events, `WARNING` for unusual but recoverable conditions, `ERROR` for a failed operation and `CRITICAL` for a serious failure. Never log passwords, tokens, private keys or sensitive packet contents.

## Exercise

Add a JSON settings file to a practice project. Validate that `timeout_seconds` is positive and `targets` is a list of strings. Log how many targets were loaded, but do not log credentials.

## Checkpoint

Explain why a configuration error should be detected before the application begins polling devices or accepting API requests.
