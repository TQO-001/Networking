---
title: "Apply the database foundations to a Python API"
description: "Connect relational design to a developer application and plan the schema, repository and migration boundaries."
order: 16
minutes: 30
level: "Intermediate"
course: "database-management"
module: "Applied track: developers"
tags: ["fastapi", "postgresql", "repository-pattern", "migrations"]
kind: "project"
---

## Use case

A task API needs durable records. The schema should represent tasks directly, validate constraints and give each record a stable ID. Its API is responsible for request/response contracts; the database is responsible for durable integrity; the repository translates between service operations and SQL.

```sql
CREATE TABLE tasks (
    task_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    title TEXT NOT NULL CHECK (length(trim(title)) BETWEEN 1 AND 120),
    completed BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

This schema does not automatically update `updated_at` when a row changes; the application or a deliberately designed database mechanism must do that. If users own tasks, add a `users` table and foreign key, then enforce tenant filtering in the service/repository and appropriate database security model.

## Avoid mixing layers

A route should not build SQL by string concatenation. Use parameterised queries, return only fields the API contract allows, and do not leak internal IDs or errors without considering whether they are appropriate to expose. Migrations belong in version control and must be tested against disposable data.

## Exercise

Sketch repository methods for creating, retrieving, listing and completing tasks. Add pagination with a stable ordering and a maximum page size. Write an integration test plan for the PostgreSQL adapter and a unit test plan for the business rules.

## Checkpoint

Explain which rule belongs in request validation, which belongs in the database constraint, and how schema changes will be deployed without unexpectedly breaking old application versions.
