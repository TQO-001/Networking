---
title: "Explore JSONB, partitioning and connection pooling"
description: "Survey advanced PostgreSQL capabilities from your notes and learn when they are appropriate rather than using them by default."
order: 14
minutes: 30
level: "Advanced"
course: "database-management"
module: "Advanced PostgreSQL"
tags: ["jsonb", "partitioning", "pooling", "replication", "fts"]
kind: "lesson"
---

## Advanced features solve specific problems

**JSONB** stores a structured JSON value in a binary form with operators and index options. It is helpful when part of a record is genuinely flexible, but a stable, frequently queried attribute may belong in a normal typed column. Do not use JSONB as an excuse to avoid modelling known relationships.

**Partitioning** divides a logical large table into smaller physical partitions, often by time or category. It can help with retention and pruning when queries align with the partition key. It adds operational complexity and requires partition maintenance; it is rarely necessary for a beginner-sized dataset.

**Connection pooling** reuses database connections and can prevent excessive connection setup. Transaction-pooling modes have limitations, including around session state and certain prepared-statement behaviours depending on pooler and versions. Test the exact client and pooler combination.

**Replication** can improve availability and distribute reads, but it introduces lag, failover and consistency considerations. A replicated database is not automatically a backup; accidental deletion can propagate.

**Full-text search** uses text-search configurations and indexes for document-like search. It is distinct from exact equality and pattern matching.

## Your advanced source notes

The attached material covers storage pages and heap files, TOAST, WAL, MVCC, B-tree/GIN/GiST/BRIN indexes, query planning, row-level security, backups, monitoring, migrations, tuning, partitioning, connection pooling, full-text search and JSONB. Use the Reference Library for the deeper treatment after you understand the shared core.

## Exercise

For one hypothetical workload, explain the problem before choosing JSONB, a partitioned table or a connection pool. State the expected query pattern, operational cost, backup impact and what measurement would justify the choice.

## Checkpoint

You can describe at least one trade-off for each feature and explain why “advanced” is not a synonym for “better”.
