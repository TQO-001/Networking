---
title: "Create your first FastAPI service"
description: "Build a small local REST API and understand routes, methods, request bodies and status codes."
order: 8
minutes: 28
level: "Intermediate"
course: "python-for-developers"
module: "Backend development"
tags: ["fastapi", "rest", "http"]
kind: "lesson"
---

## Start with one route

FastAPI maps Python functions to HTTP endpoints and uses type annotations to help describe input and output. Create the project using uv and add dependencies only for this backend project:

```bash
uv init --app task-api
cd task-api
uv add fastapi uvicorn
uv add --dev pytest httpx
```

Create `main.py`:

```python
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="Learning Task API")

class TaskCreate(BaseModel):
    title: str = Field(min_length=1, max_length=120)

TASKS: dict[int, dict[str, object]] = {}
NEXT_ID = 1

@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}

@app.post("/tasks", status_code=201)
def create_task(payload: TaskCreate) -> dict[str, object]:
    global NEXT_ID
    task_id = NEXT_ID
    NEXT_ID += 1
    task = {"id": task_id, "title": payload.title.strip(), "completed": False}
    if not task["title"]:
        raise HTTPException(status_code=422, detail="Title cannot be blank")
    TASKS[task_id] = task
    return task

@app.get("/tasks/{task_id}")
def get_task(task_id: int) -> dict[str, object]:
    task = TASKS.get(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task
```

Run locally with `uv run uvicorn main:app --reload`. The in-memory dictionary is deliberate for the first lesson; restarting the process deletes the data and concurrent updates are not a production-safe persistence solution. The next database track teaches the durable alternative.

## Understand the HTTP contract

`GET` should retrieve information without mutating state. `POST` creates a resource and returns `201 Created`. `404` means the requested task was not found; validation errors should produce a clear client error. Avoid returning raw exception details from internal systems.

## Exercise

Add `GET /tasks` to list tasks and write API tests using FastAPI's `TestClient`. Test both success and unknown IDs. Do not test by calling a public production service.

## Checkpoint

You can explain the route, request model, response, status code and why an in-memory dictionary is not a database.
