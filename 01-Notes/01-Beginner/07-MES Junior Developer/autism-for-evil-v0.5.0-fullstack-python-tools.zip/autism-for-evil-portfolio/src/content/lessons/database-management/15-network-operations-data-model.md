---
title: "Apply the database foundations to network operations"
description: "Design a schema for devices, interfaces, observations and events while keeping historical facts and safety boundaries explicit."
order: 15
minutes: 30
level: "Intermediate"
course: "database-management"
module: "Applied track: network operations"
tags: ["networking", "asset-inventory", "telemetry", "schema-design"]
kind: "project"
---

## Use case

A network operations toolkit needs a trusted inventory and a history of observations. The inventory describes the known device and its interfaces; observations record when a check happened and what it saw. Avoid overwriting the current status alone, because that erases history and makes outage analysis difficult.

A starter design:

```sql
CREATE TABLE devices (
    device_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    asset_tag TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    role TEXT NOT NULL,
    environment TEXT NOT NULL CHECK (environment IN ('lab', 'staging', 'production'))
);

CREATE TABLE observations (
    observation_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    device_id BIGINT NOT NULL REFERENCES devices(device_id),
    observed_at TIMESTAMPTZ NOT NULL,
    method TEXT NOT NULL,
    result TEXT NOT NULL CHECK (result IN ('success', 'failure', 'unknown')),
    duration_ms INTEGER CHECK (duration_ms IS NULL OR duration_ms >= 0),
    detail_code TEXT
);

CREATE INDEX observations_device_time_idx
    ON observations (device_id, observed_at DESC);
```

This design is a teaching baseline. Real inventory may require separate interface, site, VLAN, ownership and source-of-truth entities. Choose them based on business rules. Avoid storing secrets or sensitive raw packet payloads in the inventory database.

## Operational considerations

The database stores observations; it should not issue network checks from a trigger. Keep polling separate and bounded. Store UTC timestamps and the check method. If a poll fails, record the observation without rewriting the authoritative device inventory.

## Exercise

Add fictional devices, write a query for the latest observation by device, and identify assets with no recent check. Decide how “recent” is defined and how to avoid treating an unmonitored device as offline.

## Checkpoint

Document data ownership, retention, permissions and how your schema distinguishes “failed check” from “device is definitely down”.
