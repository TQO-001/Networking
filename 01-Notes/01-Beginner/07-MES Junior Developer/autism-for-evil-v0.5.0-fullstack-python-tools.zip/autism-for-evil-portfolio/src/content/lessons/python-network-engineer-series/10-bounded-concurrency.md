---
title: "Poll multiple lab targets without overwhelming them"
description: "Use a small thread pool for independent checks while setting strict limits on concurrency and request frequency."
order: 10
minutes: 22
level: "Intermediate"
course: "python-for-network-engineers"
module: "Network services"
tags: ["concurrency", "threadpoolexecutor", "rate-limits"]
kind: "lesson"
---

## Why concurrency exists

A sequential script waits for one check to finish before starting the next. If each check spends most of its time waiting on a timeout, a small bounded thread pool can improve elapsed time. It also makes the tool more capable of sending many requests quickly, so concurrency must be limited deliberately—especially around OT systems.

```python
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections.abc import Callable, Iterable

def run_bounded(targets: Iterable[str], check: Callable[[str], object], workers: int = 2) -> list[object]:
    if not 1 <= workers <= 4:
        raise ValueError("For this lab, workers must be between 1 and 4")
    items = list(targets)
    results: list[object] = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(check, target) for target in items]
        for future in as_completed(futures):
            results.append(future.result())
    return results
```

This sample caps concurrency at four for teaching; that is not a universal safe rate for real devices. Order of results follows completion time rather than input order. A production design should include a global request budget, spacing between polling cycles, cancellation, per-target limits, clear error aggregation and an operationally agreed schedule.

## Avoid overlapping polling cycles

If a monitoring cycle takes longer than its interval, starting another cycle can multiply load. Use one scheduler loop, skip or delay a cycle when the previous one is still running, and use monotonic time for measuring elapsed durations. Wall clocks are for timestamps; monotonic clocks are for timing.

## Exercise

Add a fake check function that sleeps for a short duration. Compare sequential and two-worker execution in a test or local demo. Test the worker limit and confirm that an exception from one target becomes a visible per-target failure, not an unexplained disappearance.

## Checkpoint

Explain why “more threads” is not automatically better and describe the safeguards you would require before using concurrency on an approved network.
