---
title: "Read and filter data with SQL"
description: "Write SELECT, WHERE, ORDER BY and LIMIT queries and understand NULL handling."
order: 2
minutes: 24
level: "Beginner"
course: "database-management"
module: "SQL foundations"
tags: ["sql", "select", "where", "null"]
kind: "lesson"
---

## Read before you modify

`SELECT` retrieves columns. `WHERE` filters rows. `ORDER BY` sorts the result, and `LIMIT` bounds the number of rows returned. A readable query states what it is selecting instead of relying on `SELECT *` forever.

```sql
SELECT asset_tag, display_name, role
FROM devices
WHERE role = 'switch'
ORDER BY asset_tag
LIMIT 50;
```

The result order is only guaranteed when you specify `ORDER BY`. If you use `LIMIT` without ordering, repeated queries may return different subsets.

## Combine conditions carefully

```sql
SELECT asset_tag, role
FROM devices
WHERE role IN ('switch', 'firewall')
  AND asset_tag LIKE 'LAB-%'
ORDER BY asset_tag;
```

`NULL` means unknown or absent, not a string and not the number zero. Use `IS NULL` and `IS NOT NULL`, not `= NULL`. SQL uses three-valued logic, so an expression involving `NULL` can evaluate to unknown rather than true or false.

```sql
SELECT asset_tag
FROM devices
WHERE retired_at IS NULL;
```

## Exercise

Using fictional rows, find active devices of two roles, sort by asset tag, and return at most ten. Then find rows without a retirement timestamp. Add an explicit column list to every query.

## Checkpoint

Explain why `ORDER BY` is important when pagination uses `LIMIT`, and why `column = NULL` does not work as expected.
