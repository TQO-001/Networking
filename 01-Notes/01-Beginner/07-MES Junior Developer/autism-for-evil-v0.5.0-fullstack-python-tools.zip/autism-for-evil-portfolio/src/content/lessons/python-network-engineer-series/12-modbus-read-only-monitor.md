---
title: "Read Modbus TCP registers in a simulator"
description: "Understand register addresses, response validation and safe read-only polling in a controlled Modbus lab."
order: 12
minutes: 28
level: "Intermediate–Advanced"
course: "python-for-network-engineers"
module: "OT protocols"
tags: ["modbus-tcp", "pymodbus", "industrial-networking"]
kind: "lesson"
---

## Modbus data is register-oriented

Modbus TCP reads coils, discrete inputs, input registers or holding registers depending on the function and server. Register values are 16-bit units, so a 32-bit number or floating-point value may need multiple registers and a documented word/byte order. A register address is not a universal semantic label: always use the simulator's map.

Install a recent PyModbus 3.x release inside this project:

```bash
uv add "pymodbus>=3.11,<4"
```

This lesson uses the `device_id` keyword supported by current PyModbus 3.x documentation. Older releases used other names, including `slave`; never mix code examples from different versions. `uv.lock` records the exact resolved version for this project. See the [PyModbus client reference](https://pymodbus.readthedocs.io/en/stable/source/client.html) and check the documentation matching your installed version if the API changes.

A read-only client follows this general pattern:

```python
from pymodbus.client import ModbusTcpClient

def read_holding_registers(host: str, port: int, address: int, count: int) -> list[int]:
    if not 0 <= address <= 65535 or not 1 <= count <= 125:
        raise ValueError("Register address/count outside the supported lab range")
    client = ModbusTcpClient(host=host, port=port, timeout=2)
    try:
        if not client.connect():
            raise ConnectionError("Could not connect to the Modbus simulator")
        # device_id=1 is the simulated server's configured unit ID.
        response = client.read_holding_registers(address=address, count=count, device_id=1)
        if response.isError():
            raise RuntimeError(f"Modbus returned an error response: {response}")
        return list(response.registers)
    finally:
        client.close()
```

Here `device_id=1` is a simulator setting, not a universal value. Use the matching release recorded in `uv.lock`, and adjust the ID to the simulator's configuration. The command and example intentionally target the modern 3.x API rather than trying to support several incompatible calling conventions in one code sample.

## The safety boundary

Use a simulator or an approved test server. Do not issue write-register or write-coil commands against real equipment as part of this course. Poll slowly, use connection/read timeouts, and match the device documentation for address offsets and register meaning.

## Exercise

Read a known register from the simulator and label the output using the simulator's register map. Add tests for invalid address/count and a fake error response. Document the assumed byte order for any multi-register value.

## Checkpoint

Your tool is read-only, times out safely, validates responses, and explains the register map and version-specific client API it relies on.
