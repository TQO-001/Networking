---
title: "Test APIs without running a real deployment"
description: "Use pytest and FastAPI TestClient to check endpoint contracts, validation and failure responses."
order: 11
minutes: 24
level: "Intermediate"
course: "python-for-developers"
module: "Backend development"
tags: ["pytest", "fastapi", "api-testing"]
kind: "lesson"
---

## A test for an HTTP contract

An API test verifies more than the Python function's return value: it can check status codes, JSON shape and validation behaviour. Tests should be deterministic and local; they must not require a production database or an external host unless the test is explicitly classified as an integration test.

```python
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_health_endpoint() -> None:
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}

def test_create_task_returns_created() -> None:
    response = client.post("/tasks", json={"title": "Document an API"})
    assert response.status_code == 201
    body = response.json()
    assert body["title"] == "Document an API"
    assert body["completed"] is False

def test_unknown_task_returns_404() -> None:
    response = client.get("/tasks/999999")
    assert response.status_code == 404
```

Because the example stores data in module-level memory, tests can affect each other. A mature test suite needs a fixture that resets the application state, or a service instance with an explicit test lifecycle. That is a useful design signal, not a reason to abandon tests.

## Unit, integration and end-to-end tests

Unit tests check a small function in isolation. Integration tests verify that components work together, such as a repository with a disposable test database. End-to-end tests check the wider application boundary. Keep test layers deliberate; don't turn every test into a slow end-to-end process.

## Exercise

Add a test for a blank title and an input that exceeds the maximum length. Add a fixture that creates clean state for each test. Run `uv run pytest -q` before committing.

## Checkpoint

A test failure should tell you which behaviour broke. Avoid tests that merely re-assert implementation details or depend on shared state left by another test.
