---
title: "Check a TCP service with sockets"
description: "Understand TCP connection checks, timeouts and why a successful connection proves less than people often assume."
order: 4
minutes: 22
level: "Intermediate"
course: "python-for-network-engineers"
module: "Monitoring and diagnostics"
tags: ["socket", "tcp", "timeouts"]
kind: "lesson"
---

## Reachability is layered

ICMP tells you whether an echo request received a reply. A TCP connection test asks whether a destination accepted a connection on a particular port. An application health check verifies a meaningful response at the protocol level. These are different questions, and your report should state which one it answered.

Use a simulator or a local service you control. Documentation addresses are not meant to host your test service.

```python
import socket
from dataclasses import dataclass

@dataclass(frozen=True)
class TcpCheck:
    host: str
    port: int
    connected: bool
    detail: str

def check_tcp(host: str, port: int, timeout: float = 2.0) -> TcpCheck:
    if not 1 <= port <= 65535:
        raise ValueError("port must be between 1 and 65535")
    if timeout <= 0:
        raise ValueError("timeout must be positive")
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return TcpCheck(host, port, True, "TCP connection established")
    except (TimeoutError, socket.timeout):
        return TcpCheck(host, port, False, "connection timed out")
    except OSError as exc:
        return TcpCheck(host, port, False, f"connection failed: {exc.__class__.__name__}")
```

This records the exception category instead of dumping every low-level detail. Avoid storing sensitive information in reports. DNS errors, refused connections, timeouts and routing errors can require different investigation, so production tools may use structured error codes.

## Bound the destinations

Do not accept arbitrary host and port values from an untrusted request and then connect to them. For a real inventory-driven monitor, load targets from a reviewed config, validate addresses, restrict ports, enforce rate limits and expose only the intended operation. This also prevents the tool becoming an unintended proxy to internal services.

## Exercise

Start a tiny local development server, test the port while it is listening, then stop it and compare the results. Keep the test bound to `127.0.0.1`. Add a unit test that mocks `socket.create_connection` for success, timeout and generic OS error.

## Checkpoint

Explain why a successful TCP handshake does not prove that the application is functioning correctly or that a PLC is safe to command.
