---
title: "Organise code into modules and packages"
description: "Split code by responsibility and import reusable functions without creating circular dependencies."
order: 1
minutes: 22
level: "Intermediate"
course: "python-for-developers"
module: "Maintainable Python"
tags: ["modules", "packages", "architecture"]
kind: "lesson"
---

## When one file becomes uncomfortable

If one file handles HTTP requests, validation, storage and reports, every change risks affecting unrelated behaviour. A module groups related code. A package groups related modules. The goal is not “many files”; the goal is clearer responsibilities.

```text
src/task_api/
├── __init__.py
├── models.py       # data shapes
├── service.py      # business rules
├── repository.py   # persistence boundary
└── cli.py          # command-line entry point
```

A useful direction is that `cli.py` calls the service, and the service calls a repository interface. The repository should not import the CLI. Circular imports often indicate that responsibilities or dependency direction are tangled.

## Absolute imports are easier to follow

```python
from task_api.service import create_task
```

Avoid naming your own modules `json.py`, `typing.py`, `logging.py` or `email.py`. These names can shadow standard-library modules and cause confusing import failures.

## Keep reusable logic independent from the boundary

A service function should accept values and return a result or a meaningful error. It should not prompt for input or print to the terminal. That lets a CLI, a test and a web endpoint reuse it.

## Exercise

Take a tiny task tracker with add/list operations. Put the domain rules in `service.py` and terminal interaction in `cli.py`. Ensure importing the package does not immediately run the program.

## Checkpoint

You can tell a teammate which module owns each responsibility and why changing terminal output should not require rewriting the business rules.
