---
title: "Values and variables"
description: Give information a name, recognise basic data types, and see why network addresses should usually be stored as text.
order: 3
minutes: 20
level: Beginner
course: shared-python-foundations
tags: [variables, data-types, strings]
kind: lesson

module: "Python foundations"
---
A useful program needs to remember information. A **value** is a piece of information; a **variable** is a name you give it so that you can refer to it later.

## 1. Give data a name

In `device_summary.py`, write:

```python
device_name = "PLC-SIM-01"
ip_address = "192.168.10.20"
vlan_id = 20
is_lab_device = True

print(device_name)
print(ip_address)
print(vlan_id)
print(is_lab_device)
```

The equals sign `=` assigns a value to a variable. It does not mean “is equal to” in the mathematical comparison sense. It means “store the value on the right under the name on the left.”

Names such as `device_name` and `ip_address` are intentionally descriptive. Later, when you return to this code, the name should help you understand what the value represents.

## 2. Meet four common data types

| Type | Plain-language meaning | Example |
|---|---|---|
| `str` | Text | `"SW-LAB-01"` |
| `int` | Whole number | `20` |
| `float` | Decimal number | `2.5` |
| `bool` | True/false value | `True` |

Python is dynamically typed, so you normally do not declare the type before assigning a value. You can inspect a value with `type()`:

```python
print(type(ip_address))  # <class 'str'>
print(type(vlan_id))     # <class 'int'>
```

## 3. Why is an IP address text?

An address like `"192.168.10.20"` looks numeric, but it is not one whole number for most of the things our inventory program needs to do. We need to preserve the dots, validate the address and compare it with a subnet. Keep it as a string until a networking library interprets it as an IP address.

This is a useful engineering habit: **choose a type because of what the value means, not just because the value contains digits.** A switch name is text, an interface counter may be an integer, and an enabled/disabled flag is a boolean.

## 4. Combine values with f-strings

An f-string lets you place variable values inside a text message:

```python
device_name = "SW-LAB-01"
ip_address = "192.168.10.2"
status = "reachable"

print(f"{device_name} ({ip_address}) is {status}.")
```

The `f` before the opening quote tells Python to evaluate expressions inside `{}`. The result is:

```text
SW-LAB-01 (192.168.10.2) is reachable.
```

## 5. Ask for input

`input()` pauses and waits for the person running the program to type something. Important detail: `input()` always returns text, even if the person types `20`.

```python
device_name = input("Enter a lab device name: ")
print(f"You entered: {device_name}")
```

When a value truly represents a number, you can convert it:

```python
vlan_text = input("Enter a VLAN ID: ")
vlan_id = int(vlan_text)
print(f"VLAN {vlan_id} recorded")
```

This conversion can fail if the input is not a whole number. We will learn to handle that safely in a later lesson. For now, try valid numeric input first.

## Exercise: label three devices

Create three variables for a fictional switch: its hostname, management IP and whether it belongs to your lab. Print a readable sentence with an f-string.

**Stretch:** call `type()` on each variable and explain why the types make sense.

**Done when:** you can explain the difference between a string, an integer and a boolean, and why you would not store an IP address as an integer.

**Next:** [Make decisions with `if`](/learn/python-for-network-engineers/04-making-decisions/).
