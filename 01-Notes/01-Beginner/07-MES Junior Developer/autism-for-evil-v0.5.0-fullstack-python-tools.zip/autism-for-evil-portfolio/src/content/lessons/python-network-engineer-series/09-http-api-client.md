---
title: "Talk to a network API responsibly"
description: "Make an HTTP GET request, handle status codes and timeouts, and understand the difference between transport and application errors."
order: 9
minutes: 25
level: "Intermediate"
course: "python-for-network-engineers"
module: "Network services"
tags: ["http", "api", "json", "urllib"]
kind: "lesson"
---

## What an API adds

A management API is an interface exposed by a device or platform. It may provide structured inventory, interface state or configuration information. Availability and schema depend on the product, firmware, enabled services and access rights. Use a mock endpoint or a service designed for the lab; never discover device APIs by probing production equipment.

Python's standard library `urllib` can teach the HTTP lifecycle without immediately adding an HTTP client dependency:

```python
import json
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

def get_json(url: str) -> object:
    request = Request(url, headers={"Accept": "application/json"}, method="GET")
    try:
        with urlopen(request, timeout=3) as response:
            if response.status < 200 or response.status >= 300:
                raise RuntimeError(f"Unexpected HTTP status: {response.status}")
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        raise RuntimeError(f"API returned HTTP {exc.code}") from exc
    except (URLError, TimeoutError) as exc:
        raise RuntimeError("API request failed or timed out") from exc
```

Do not make this a generic URL-fetching endpoint for untrusted users. Validate and allow-list the API base URL in a real tool, use TLS verification, authenticate using the documented method, and avoid including secrets in exceptions and logs.

## Status codes are not the whole story

`200 OK` means the server returned success for the HTTP request; the body can still be malformed or semantically invalid. `401` and `403` indicate different access problems; `404` may mean a resource isn't present or the service intentionally hides it; `429` may indicate rate limiting; `5xx` indicates a server-side failure.

## Exercise

Write tests by mocking the HTTP layer. Cover a valid JSON response, invalid JSON, HTTP error and timeout. The tests should not call the internet or a production endpoint.

## Checkpoint

Your client uses a timeout, handles failures explicitly and does not silently retry dangerous operations. The first version should be read-only.
