---
title: "Connect Python to PostgreSQL safely"
description: "Use a Python driver, parameterised SQL and explicit transaction boundaries from application code."
order: 8
minutes: 30
level: "Intermediate"
course: "database-management"
module: "Python integration"
tags: ["python", "postgresql", "psycopg", "parameterized-sql"]
kind: "lesson"
---

## Keep SQL parameters separate from SQL text

Your notes cover PostgreSQL with Python. The most important habit is to use the driver's parameter binding instead of concatenating user input into a query. Parameter binding reduces injection risk and handles value encoding appropriately.

Install the driver in the application project (the PostgreSQL Python section uses Psycopg 3):

```bash
uv add "psycopg[binary]"
```

A minimal example, assuming `DATABASE_URL` is already supplied securely to the environment and the lab database contains `devices`:

```python
import os
import psycopg

DATABASE_URL = os.environ["DATABASE_URL"]

def find_device(asset_tag: str) -> tuple | None:
    with psycopg.connect(DATABASE_URL) as connection:
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT asset_tag, display_name, role FROM devices WHERE asset_tag = %s",
                (asset_tag,),
            )
            return cursor.fetchone()
```

The context manager commits on normal exit and rolls back on exceptions according to Psycopg's connection behaviour; confirm the driver's documentation for your version. Avoid logging `DATABASE_URL`. A DSN contains credentials in many deployments.

## Build a repository boundary

Application routes should not embed SQL in every endpoint. A repository layer centralises queries, mapping and transaction decisions. Unit-test service logic with a fake repository, and test the PostgreSQL adapter against a dedicated test database with known fixtures.

## Exercise

Implement a parameterised lookup and a safe insert in your local lab. Test a string containing quotes and verify it is treated as data, not as executable SQL. Test rollback using the disposable database.

## Checkpoint

Show where the DSN comes from, demonstrate parameter binding and explain the difference between a unit test with a fake repository and an integration test against PostgreSQL.
