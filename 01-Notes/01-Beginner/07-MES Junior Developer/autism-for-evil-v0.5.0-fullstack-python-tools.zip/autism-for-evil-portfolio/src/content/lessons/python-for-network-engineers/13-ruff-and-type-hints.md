---
title: "Ruff and type hints without the mystery"
description: "Use static checks and type annotations to catch mistakes earlier and make intent easier to read."
order: 13
minutes: 16
level: "Beginner–Intermediate"
course: "shared-python-foundations"
module: "Professional workflow"
tags: ["ruff", "type-hints", "quality"]
kind: "lesson"
---

## Three tools, three jobs

- **Python** executes the program.
- **pytest** runs checks you have written about behaviour.
- **Ruff** checks style and many common coding mistakes; it can also format files.

They answer different questions. A clean Ruff run does not prove the program is correct, and passing tests do not guarantee readable code.

```bash
uv run ruff check .
uv run ruff format --check .
uv run pytest
```

When Ruff reports an issue, read the rule and decide whether the finding is valid. Avoid blanket suppression. If a rule genuinely does not apply, document a narrow exception instead of turning off all checking.

## Type hints describe expected values

```python
from ipaddress import IPv4Network

def contains_address(network: IPv4Network, address: str) -> bool:
    return address in network
```

The annotation tells the reader and type-checking tools what kind of values the function expects and returns. Python generally does not enforce these annotations at runtime. The function above may still need validation if `address` can be malformed; `ipaddress.ip_address()` can parse it and raise a useful exception.

## The professional habit

Run tests and lint checks after a meaningful change, before committing it. Keep a known baseline and fix one category of problem at a time. Formatting is most useful when the entire team agrees on it, because code reviews can focus on logic instead of whitespace.

## Exercise

Introduce a deliberate unused import and a poorly formatted function, then run Ruff. Fix the reported issues. Add type hints to one function and explain what they document—and what they do not guarantee.

## Checkpoint

You can tell someone why the project uses pytest and Ruff, and you do not treat their green output as proof that the application has no bugs.
