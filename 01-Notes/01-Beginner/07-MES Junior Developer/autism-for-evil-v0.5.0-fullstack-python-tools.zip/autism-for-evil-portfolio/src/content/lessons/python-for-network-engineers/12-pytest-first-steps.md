---
title: "Test behaviour, not just the happy path"
description: "Write and run automated tests for normal values, boundary conditions and invalid inputs."
order: 12
minutes: 20
level: "Beginner–Intermediate"
course: "shared-python-foundations"
module: "Professional workflow"
tags: ["pytest", "testing", "edge-cases"]
kind: "lesson"
---

## Why tests matter

A program that worked once is not proof that it works now. A test is a repeatable example of expected behaviour. Tests are especially useful for engineering tools because wrong outputs can be more dangerous than obvious crashes.

Suppose `parse_prefix()` should accept a prefix from 0 to 32. The normal path is not enough: test zero, the largest valid value, negative input and an input that is not a number.

```python
# src/example.py
def usable_hosts(prefix: int) -> int:
    if not 0 <= prefix <= 32:
        raise ValueError("IPv4 prefix must be between 0 and 32")
    addresses = 2 ** (32 - prefix)
    if prefix >= 31:
        return addresses
    return addresses - 2
```

```python
# tests/test_example.py
import pytest
from example import usable_hosts

def test_typical_subnet():
    assert usable_hosts(24) == 254

def test_point_to_point_prefix():
    assert usable_hosts(31) == 2

def test_invalid_prefix_is_rejected():
    with pytest.raises(ValueError):
        usable_hosts(33)
```

This intentionally uses a simplified rule for IPv4 host counts and is an exercise in testing. For the real subnet calculator, use Python's `ipaddress` module and make its network/broadcast semantics explicit.

Run the tests with:

```bash
uv run pytest
uv run pytest -v
```

## Arrange, act, assert

A readable test sets up inputs, calls the function, and checks the result. Prefer tests that explain the behaviour through their names. Tests should not depend on the order in which pytest happens to run them.

## Exercise

Add tests for prefix `/0`, `/32`, `-1`, and a string passed where an integer is expected. Decide whether the function should reject the string with a clear `TypeError`/`ValueError`, and implement that behaviour deliberately.

## Checkpoint

A good test suite covers ordinary cases, boundaries and errors. It should be fast and safe to run repeatedly, without touching real devices or production services.
