---
title: "Connect an application to PostgreSQL"
description: "Learn the correct place for persistence in the developer track and reuse the shared database course rather than duplicating its SQL lessons."
order: 13
minutes: 18
level: "Intermediate"
course: "python-for-developers"
module: "Persistence"
tags: ["postgresql", "database", "integration"]
kind: "guide"
---

This is a bridge lesson, not a second database course. Complete the [Database Systems course](/courses/database-systems/) through its Python integration module before building persistent application features.

## The layers

A typical small backend has an HTTP layer, a service layer and a repository/data-access layer. HTTP validates the request shape; the service applies business rules; the repository translates operations into parameterised SQL and maps rows into application values. This separation makes unit tests possible without a database and integration tests possible with a disposable test database.

Do not concatenate user input into SQL strings. Use the driver's parameter binding. Do not use a production database for learning migrations or destructive tests. Use a separate development database with fake data and restricted privileges.

## Dependency policy

The database track introduces PostgreSQL and a Python driver as needed. The application course will adopt the driver and migration approach selected there rather than inventing a second stack. The database connection string is configuration and may contain a password; never commit it or print it in logs.

## Exercise

Sketch a repository interface for a task API: `create`, `get_by_id`, `list` and `update_status`. Write an in-memory implementation for unit tests. Then implement a PostgreSQL-backed adapter only after the database integration lesson.

## Checkpoint

You can describe which tests need a database, which can use a fake repository, and how the application avoids leaking database credentials.
