---
title: "Use indexes and EXPLAIN to investigate queries"
description: "Understand why indexes help some reads, cost storage and writes, and must be justified by measured query plans."
order: 10
minutes: 28
level: "Intermediate"
course: "database-management"
module: "Performance and maintenance"
tags: ["indexes", "explain", "query-planning"]
kind: "lesson"
---

## An index is a trade-off

An index is an additional data structure that can help PostgreSQL locate rows without scanning an entire table. It also consumes storage and makes inserts, updates and deletes more expensive because relevant indexes must be maintained. More indexes do not automatically mean faster applications.

B-tree indexes are a common default for equality and range queries. Other index types serve different operators: GIN can help with arrays, JSONB and full-text search; GiST supports range and geometric-style operations; BRIN can be useful for very large tables whose values correlate with physical row order. Choose based on the actual query and data distribution.

## Inspect a plan

```sql
EXPLAIN
SELECT observation_id, observed_at, status
FROM observations
WHERE interface_id = 42
ORDER BY observed_at DESC
LIMIT 100;
```

`EXPLAIN` shows the planner's estimated plan. `EXPLAIN ANALYZE` executes the statement and reports actual timing/row information, so use it carefully on a query that is safe to execute. Never casually run a modifying query with `EXPLAIN ANALYZE` against production—the statement actually executes.

## Read estimates critically

Compare estimated and actual rows, scan types, sort operations and buffer information where available. A sequential scan is not automatically bad; for a small table or query returning a large portion of the data, it may be the cheapest plan. Planner statistics and data distribution matter.

## Exercise

Create a large synthetic observations table, run a query before and after adding a candidate index, and compare plans under the same conditions. Record table size and query shape. Do not report a microbenchmark as a universal performance rule.

## Checkpoint

Explain why indexes should be added in response to a real query pattern and why `EXPLAIN ANALYZE` must be used carefully.
