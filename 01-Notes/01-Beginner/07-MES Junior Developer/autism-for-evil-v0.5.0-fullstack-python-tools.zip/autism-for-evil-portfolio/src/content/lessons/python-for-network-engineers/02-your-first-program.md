---
title: "Your first Python program"
description: Create a Python file, run it from the terminal, and understand the difference between code and the program's output.
order: 2
minutes: 15
level: Beginner
course: shared-python-foundations
tags: [python-basics, setup, terminal]
kind: lesson

module: "Python foundations"
---
In this lesson, we will write a program that prints a short network operations message. You will learn three things: what a Python file is, how to run it, and where its output appears.

## 1. Create a workspace

Create a folder somewhere easy to find, such as `python-network-lab`. Open that folder in VS Code. Inside it, create a new file named `hello_network.py`.

The `.py` ending tells you—and your editor—that this file contains Python code. File names should be descriptive, written in lowercase, with underscores separating words.

## 2. Write your first line

Type this into `hello_network.py`:

```python
print("OT network lab ready")
```

Save the file. The `print()` function displays information in the terminal. The text inside the quotation marks is called a **string**: a piece of text.

## 3. Run it from the terminal

In VS Code, open **Terminal → New Terminal**. Make sure the terminal is in the `python-network-lab` folder.

On Windows, try:

```powershell
py -3.14 hello_network.py
```

On Linux, try:

```bash
python3.14 hello_network.py
```

If your environment uses `python` or `python3` to refer to Python 3.14, that can work too. We will standardise the environment with `uv` later; do not let the command name distract you from the concept.

You should see:

```text
OT network lab ready
```

That line is **output**. It is not part of your Python file; it is what the Python interpreter printed after running your file.

## 4. Make a small change

Change the line to:

```python
print("Inventory check starting")
print("3 lab devices configured")
print("No production systems contacted")
```

Save and run again. You should see three output lines in the same order.

That is the basic programming loop: edit a file, save it, run it, inspect what happened, and repeat.

## What if it does not run?

- **The terminal says the command is not recognised.** Python may not be installed or may not be available on your `PATH`. Check the installation before changing the code.
- **It says the file cannot be found.** The terminal may be in the wrong directory, or the file may have a different name.
- **You see a syntax error.** Check quotation marks, brackets and spelling. Python uses exact syntax.
- **Nothing changed.** Save the file before running it again.

Do not randomly reinstall tools in response to every error. First read the message and identify whether it is about the Python installation, the file path or the code.

## Exercise: a tiny status report

Create `status_report.py`. Make it print three lines: a fictional lab name, a device count, and a reminder that this is a lab environment.

**Done when:** you can run the file twice, change one line, and explain where code ends and terminal output begins.

<details>
<summary>Hint</summary>

Use one `print()` call per line. Every text value needs matching quotation marks.

</details>

**Next:** [Values and variables](/learn/python-for-network-engineers/03-values-and-variables/).
