---
title: "Modbus TCP lab monitor"
description: "Read selected registers from a Modbus simulator and record values over time, with careful treatment of register addressing and numeric conversion."
order: 8
stage: "Industrial protocols"
status: "in-progress"
technologies: ["Python 3.14", "FastAPI", "React", "PyModbus 3.13+", "Modbus TCP"]
tags: ["OT", "Modbus", "telemetry"]
---
## Problem

Modbus exposes register values that need context before they mean anything useful. This project will use a simulator so you can practise request/response logic without touching production equipment.

## Intended behaviour

- Connect to an approved simulator endpoint.
- Read only an explicitly configured set of registers.
- Document zero-based/address-offset assumptions and register data types.
- Convert register values according to a documented example map.
- Record time, result and errors, and close the client cleanly.

## Safety boundary

Begin with read-only polling in an isolated lab. Do not use this project to write coils/registers or experiment against a real PLC without a formal, approved test plan.


## GUI implementation

This project now has a React interface in the **Python Network Tools Suite**, backed by a FastAPI endpoint and a dedicated Python service. The suite lives at `applications/python-network-tools/`; see its `README.md` for Windows/Linux setup and its `PROJECT-MAP.md` for the file-by-file mapping.

The GUI is a working implementation, but keep this portfolio record marked **in progress** until the frontend build, backend test suite and local browser workflow have been run successfully on your machine.
