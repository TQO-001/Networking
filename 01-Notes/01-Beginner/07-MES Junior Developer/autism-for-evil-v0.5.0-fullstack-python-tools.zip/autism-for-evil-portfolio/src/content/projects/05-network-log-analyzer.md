---
title: "Network log analyser"
description: "Parse sample syslog-style text and summarise severities, link-state events and repeated messages with explainable rules."
order: 5
stage: "Troubleshooting"
status: "in-progress"
technologies: ["Python 3.14", "FastAPI", "React", "re", "pytest"]
tags: ["logs", "troubleshooting"]
---
## Problem

Logs can be long, repetitive and difficult to skim. This tool turns sample or exported log text into a structured summary while retaining the original source line for traceability.

## Intended behaviour

- Read a local log file without modifying it.
- Count messages by severity or known event pattern.
- Highlight link-up/link-down style messages in a test dataset.
- Handle lines that do not match the expected format.
- Export a short summary and preserve a reference to the original line number.

Use sanitised sample data. Do not publish unredacted company logs, hostnames, public IPs or tokens.


## GUI implementation

This project now has a React interface in the **Python Network Tools Suite**, backed by a FastAPI endpoint and a dedicated Python service. The suite lives at `applications/python-network-tools/`; see its `README.md` for Windows/Linux setup and its `PROJECT-MAP.md` for the file-by-file mapping.

The GUI is a working implementation, but keep this portfolio record marked **in progress** until the frontend build, backend test suite and local browser workflow have been run successfully on your machine.
