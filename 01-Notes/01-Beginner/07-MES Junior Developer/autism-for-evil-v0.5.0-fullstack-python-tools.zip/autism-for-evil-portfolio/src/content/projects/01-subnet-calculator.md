---
title: "IP subnet calculator"
description: "A command-line helper that explains a subnet from a CIDR input, with a strong emphasis on input validation and testable functions."
order: 1
stage: "Python fundamentals"
status: "in-progress"
technologies: ["Python 3.14", "FastAPI", "React", "Vite", "pytest"]
tags: ["addressing", "beginner"]
---
## Problem

Subnet calculations are routine in network engineering, but this project is also a safe way to learn input, functions, standard-library usage and testing.

## Intended behaviour

- Accept an IPv4 or IPv6 CIDR input.
- Report the normalised network address, prefix, mask where applicable and address count.
- Handle malformed input with a useful message.
- Keep calculations separate from user interaction so the logic can be tested.

## Build sequence

1. Start with one function that returns a network summary.
2. Run it from a tiny command-line interface.
3. Add tests for a `/24`, a `/32`, IPv6 and invalid input.
4. Add a README with examples and limitations.
5. Split into `calculator.py` and `cli.py` after the single-file version is understood.

## Definition of done

A clean environment can install the project, its automated tests pass, and a new user can follow the README to reproduce at least three examples. The current starter tutorial lives in [Lesson 09: Build your first network tool](/learn/python-for-network-engineers/09-build-subnet-calculator/).

## Status

The first learning implementation is defined in the course. The polished package, automated test suite and public release should remain marked in progress until those parts have been verified together.


## GUI implementation

This project now has a React interface in the **Python Network Tools Suite**, backed by a FastAPI endpoint and a dedicated Python service. The suite lives at `applications/python-network-tools/`; see its `README.md` for Windows/Linux setup and its `PROJECT-MAP.md` for the file-by-file mapping.

The GUI is a working implementation, but keep this portfolio record marked **in progress** until the frontend build, backend test suite and local browser workflow have been run successfully on your machine.
