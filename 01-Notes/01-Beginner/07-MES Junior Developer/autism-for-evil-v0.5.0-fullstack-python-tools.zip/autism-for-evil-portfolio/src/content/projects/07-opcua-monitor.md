---
title: "OPC UA monitoring client"
description: "Connect to a lab OPC UA server, read explicitly selected variables and write timestamped values to a local file."
order: 7
stage: "Industrial protocols"
status: "in-progress"
technologies: ["Python 3.14", "FastAPI", "React", "asyncua", "OPC UA"]
tags: ["OT", "OPC UA", "telemetry"]
---
## Problem

OPC UA is used to expose structured industrial data. The learning goal is to understand a client/server interaction and capture read-only telemetry from a deliberately configured lab service.

## Intended behaviour

- Connect to a documented local or approved test endpoint.
- Read a small allowlist of known node IDs.
- Record values, timestamps and quality/status information when provided.
- Handle timeouts, disconnects and missing nodes.
- Close the client cleanly.

Start with a simulator and anonymous or lab credentials only where that configuration is explicitly intended for testing. Do not embed secrets in source control. Never add writes to a real controller as a beginner exercise.


## GUI implementation

This project now has a React interface in the **Python Network Tools Suite**, backed by a FastAPI endpoint and a dedicated Python service. The suite lives at `applications/python-network-tools/`; see its `README.md` for Windows/Linux setup and its `PROJECT-MAP.md` for the file-by-file mapping.

The GUI is a working implementation, but keep this portfolio record marked **in progress** until the frontend build, backend test suite and local browser workflow have been run successfully on your machine.
