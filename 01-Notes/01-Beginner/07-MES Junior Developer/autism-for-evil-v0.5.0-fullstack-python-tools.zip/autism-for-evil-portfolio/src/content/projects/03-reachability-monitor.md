---
title: "Network reachability monitor"
description: "Poll a small, explicit list of approved lab targets and record check results over time without claiming more than the measurements prove."
order: 3
stage: "Monitoring basics"
status: "in-progress"
technologies: ["Python 3.14", "FastAPI", "React", "socket", "pytest"]
tags: ["monitoring", "network-ops"]
---
## Problem

A single manual check is only a snapshot. A small monitor can record a history of whether a chosen check succeeded during a test window.

## Intended behaviour

- Read an explicit configured list of lab targets.
- Use one documented reachability method per target.
- Record timestamps, result, elapsed time where supported, and errors.
- Apply a timeout and a bounded polling interval.
- Export results so they can be graphed later.

## Engineering notes

ICMP ping availability and command-line flags differ across Windows and Linux. The implementation must account for platform differences and should test those paths separately. A failed ping does not always mean a host is down; a host may filter ICMP or a path may block it.

## Safety boundary

Do not run broad address-range scans or unapproved polling against production OT. Start with a few explicit addresses in a personal or approved lab.


## GUI implementation

This project now has a React interface in the **Python Network Tools Suite**, backed by a FastAPI endpoint and a dedicated Python service. The suite lives at `applications/python-network-tools/`; see its `README.md` for Windows/Linux setup and its `PROJECT-MAP.md` for the file-by-file mapping.

The GUI is a working implementation, but keep this portfolio record marked **in progress** until the frontend build, backend test suite and local browser workflow have been run successfully on your machine.
