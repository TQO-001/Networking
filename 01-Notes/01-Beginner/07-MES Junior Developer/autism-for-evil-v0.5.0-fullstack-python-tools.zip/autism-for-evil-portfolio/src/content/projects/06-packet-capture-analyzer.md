---
title: "Offline packet capture analyser"
description: "Summarise an existing capture file to learn packet structure, protocol counts and conversations without beginning with live capture."
order: 6
stage: "Packet analysis"
status: "in-progress"
technologies: ["Python 3.14", "FastAPI", "React", "Scapy", "PCAP"]
tags: ["packet-analysis", "Scapy"]
---
## Problem

Packet captures contain detailed evidence about network conversations. The first version should read an existing approved capture file and produce a summary rather than capture traffic from a live network.

## Intended behaviour

- Open a local `.pcap` or `.pcapng` file.
- Count packet types and observed IP endpoints.
- Report packet lengths and timestamps where available.
- Handle an empty or unreadable capture clearly.
- Keep output concise and avoid exposing sensitive payload data by default.

## Safety boundary

Only inspect captures you own or are authorised to use. For public portfolio screenshots, use synthetic or sanitised data and hide sensitive payloads.


## GUI implementation

This project now has a React interface in the **Python Network Tools Suite**, backed by a FastAPI endpoint and a dedicated Python service. The suite lives at `applications/python-network-tools/`; see its `README.md` for Windows/Linux setup and its `PROJECT-MAP.md` for the file-by-file mapping.

The GUI is a working implementation, but keep this portfolio record marked **in progress** until the frontend build, backend test suite and local browser workflow have been run successfully on your machine.
