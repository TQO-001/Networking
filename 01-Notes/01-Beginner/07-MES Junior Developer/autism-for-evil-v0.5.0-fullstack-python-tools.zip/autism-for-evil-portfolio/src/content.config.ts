import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

const lessons = defineCollection({
  loader: glob({ base: './src/content/lessons', pattern: '**/*.md' }),
  schema: z.object({
    title: z.string(),
    description: z.string(),
    order: z.number(),
    minutes: z.number().default(10),
    level: z.string().default('Beginner'),
    course: z.string(),
    module: z.string().default('Core'),
    tags: z.array(z.string()).default([]),
    kind: z.enum(['lesson', 'guide', 'project']).default('lesson'),
  }),
});

const articles = defineCollection({
  loader: glob({ base: './src/content/articles', pattern: '**/*.md' }),
  schema: z.object({
    title: z.string(),
    description: z.string(),
    date: z.string(),
    tags: z.array(z.string()).default([]),
    status: z.enum(['published', 'draft']).default('draft'),
    featured: z.boolean().default(false),
  }),
});

const projects = defineCollection({
  loader: glob({ base: './src/content/projects', pattern: '**/*.md' }),
  schema: z.object({
    title: z.string(),
    description: z.string(),
    order: z.number(),
    stage: z.string(),
    status: z.enum(['brief', 'in-progress', 'complete']).default('brief'),
    technologies: z.array(z.string()).default([]),
    tags: z.array(z.string()).default([]),
  }),
});

const library = defineCollection({
  loader: glob({ base: './src/content/library', pattern: '**/*.md' }),
  schema: z.object({
    title: z.string(),
    description: z.string(),
    section: z.string(),
    level: z.string(),
    sourcePath: z.string(),
    tags: z.array(z.string()).default([]),
  }),
});

const networking = defineCollection({
  loader: glob({ base: './src/content/networking', pattern: '**/*.md' }),
  schema: z.object({
    title: z.string(),
    description: z.string(),
    category: z.string(),
    level: z.string().default('Reference'),
    sourcePath: z.string(),
    tags: z.array(z.string()).default([]),
  }),
});

export const collections = { lessons, articles, projects, library, networking };
