# Code block theme

Autism For Evil uses Astro's built-in Shiki highlighter for fenced Markdown code blocks.

- Light theme: Catppuccin Latte
- Dark theme: Catppuccin Mocha
- Theme selection: follows `html[data-theme]`, controlled by the site's theme toggle
- Language aliases: `Python`, `py`, and `pyw` map to `python`; `sh` and `shell` map to `bash`; `ps1` maps to `powershell`

## Authoring notes

Always add a language identifier to fenced blocks:

```python
def greet(name: str) -> str:
    return f"Hello, {name}!"
```

Use `text` for plain terminal output, logs, or examples that should not be token-coloured. Use `bash`, `powershell`, `sql`, `json`, `ini`, `cisco`, or another accurate language identifier when appropriate. Keep indentation intact.

The global styles live in `src/styles/global.css`; the Shiki theme configuration lives in `astro.config.mjs`. No extra syntax-highlighting package is required because Astro includes Shiki for Markdown highlighting.
