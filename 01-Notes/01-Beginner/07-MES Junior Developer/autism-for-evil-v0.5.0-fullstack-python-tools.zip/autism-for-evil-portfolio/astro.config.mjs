import { defineConfig } from 'astro/config';
import react from '@astrojs/react';

export default defineConfig({
  integrations: [react()],
  trailingSlash: 'always',
  output: 'static',
  markdown: {
    // Use Shiki's dual themes so code follows the site's light/dark toggle.
    shikiConfig: {
      themes: {
        light: 'catppuccin-latte',
        dark: 'catppuccin-mocha',
      },
      // Let CSS select the active theme through the site's data-theme attribute.
      defaultColor: false,
      // Normalise common fence labels found in the imported notes.
      langAlias: {
        Python: 'python',
        py: 'python',
        pyw: 'python',
        sh: 'bash',
        shell: 'bash',
        ps1: 'powershell',
      },
      // Keep code formatting intact; long lines can scroll horizontally.
      wrap: false,
    },
  },
});
