Unified Automation UaExpert
---------------------------------------------------------

----------------------
Content
----------------------
(0) UaExpert
(1) UaExpert Plugins
(2) Third-Party Libraries
(3) Release Notes
----------------------

===================================================================
(0) UaExpert
===================================================================

UaExpert is a free test client for OPC UA and supports OPC UA to its
core. It provides graphical user interfaces for different purposes
regarding the features of OPC UA. UaExpert consists of a frame
application providing reusable base functionality used by different,
specialized plugins.

UaExpert's base frame consists of:
- the main GUI
- Address Space Browser
- Attribute Window
- Reference Window
- Trace/Log Window

===================================================================
(1) UaExpert Plugins
===================================================================

UaExpert can load plugins within its main GUI. Those plugins contain
documents that have specialized functionality. Currently, UaExpert
comes with following document types:

- Data Access View
    This document type offers a table view which automatically updates
    its values on data changes like in the old COM DA days. It uses
    the new UA publish/subscribe mechanism for updating the data.

- Event View
    This document type can be used to subscribe to events and alarms
    of the UA server. It supports the selection of event fields and
    can acknowledge and confirm alarms. It also supports reading of
    historical event data for a given time period.

- History Trend View
    This document type can be used for obtaining historical data for
    one or more OPC UA Nodes. The received values are displayed in a
    graphical trend view.

- Trend View
    This document type allows for monitoring of one or more OPC UA Nodes.
    The received values are continuously updated and displayed in
    a graphical trend view.

- Performance View
    This document type measures the performance of certain UA service
    calls to a UA Server. It can be configured to call a service for
    a defined number of times or to call a service as often as
    possible in a specified time span.

- Image Viewer
    This simple document type can display images contained in OPC UA
    variables and currently supports the image types as defined by the
    OPC UA type system. It subscribes to the image, hence it can also
    be used for "streaming" if a server provides a frequently changing
    image (video).

- Server Diagnostics View
    This document type reads out the standardized diagnostic information
    provided by the server. The diagnostic information as defined by the
    OPC Foundation is grouped and displayed in different tabs.

- Data Logger View
    This document type is a simple data logger that subscribes to value
    changes of a given Node and logs the information into a comma
    separated file.

- Device View
    This document type is a specialized view for the
    OPC UA Devices Information Model.

- PubSub Config View
    This document type is a specialized view for the
    OPC UA PubSub configuration.

- OPC UA FX Config View
    This document type is a specialized view for the
    OPC UA Field eXchange configuration for controller to controller
    and controller to device communication.

- XML Nodeset Export View
    This document type can be used for exporting (parts of) the address
    space of a server to XML files.
    Each selected OPC UA namespace is exported as UANodeSet XML file.

- GDS Push View
    This document type allows configuring servers using the
    GDS (Gloabal Discovery Server) Push Model. With this, the server's
    trust lists and application instance certificate can be configured
    remotely.

===================================================================
(2) Third-Party Libraries
===================================================================

UaExpert includes a number of third-party libraries that are used to
provide certain features. Third-party software may impose additional
restrictions and it is the user's responsibility to ensure that they
have met the licensing requirements of the respective libraries. The
following enumeration lists all third-party libraries used by
UaExpert with additional information about version, configuration, and
used licenses. The third-party licenses are stored in the license
folder distributed with UaExpert.

* Unified Automation

    UaExpert uses the C++ based OPC UA Client SDK for all OPC UA
    functionalities.
    Home: https://unifiedautomation.com
    License: Software License Agreement ("SLA") Version 2.8
    Unless explicitly acquired and licensed from Licensor under another
    license, the UaExpert is subject to the Software License
    Agreement ("SLA") Version 2.8, or subsequent versions as allowed
    by the SLA, and You may not copy or use this Software, except in
    compliance with the terms and conditions of the SLA.

    The complete license agreement can be found here:
    https://unifiedautomation.com/License/SLA/2.8/

* OPC UA Stack

    Unified Automation maintains an own version of the OPC UA Stack which
    was originally based on the official OPC Foundation OPC UA Stack but is
    now different and released independently from the OPC Foundation version.

* OpenSSL 3.x

    Home: https://www.openssl.org
    License: Apache License 2.0

    Copyright (c) 1998-2021 The OpenSSL Project Authors
    Copyright (c) 1995-1998 Eric A. Young, Tim J. Hudson
    All rights reserved

    Unified Automation distributes a minimal version of OpenSSL, that was
    compiled from source and with unnecessary algorithms and dependencies
    removed.

* LibXML2

    Home: http://xmlsoft.org/
    License: MIT License (MIT)

    Unified Automation distributes a minimal version of LibXml2, that was
    compiled from source and with unnecessary algorithms and dependencies
    removed.

* Qt5.x

    The Qt library is used for the GUI of UaExpert
    Home: https://www.qt.io
    License: GNU LESSER GENERAL PUBLIC LICENSE

    Unified Automation distributes a minimal version of Qt5 libraries, that
    were compiled from source and with unnecessary algorithms and dependencies
    removed.

* Qwt6

    The Qt Widgets for Technical Applications are used for the graphical
    display elements of several plugins in the UaExpert.
    Home: http://qwt.sourceforge.net
    License: Qwt License, Version 1.0

    Unified Automation distributes a minimal version of Qwt6, that was
    compiled from source and with unnecessary algorithms and dependencies
    removed.

===================================================================
(3) Release Notes
===================================================================
Known issues:

- none
