# Holly Bibley discovery snapshot format — version 1

This is the adapter-neutral format that discovery integrations convert into before importing the results into Holly Bibley. It is a data interchange format, not a scanner: importing a file does not probe a network.

A snapshot must use the schema name `holly-bibley-discovery-snapshot`, version `1`, and include `devices`, `vlans` and `links` arrays. Each device requires a stable `key`. Links reference those keys using `sourceKey` and `targetKey`. VLAN references use numeric or string tags from 1 through 4094.

## Example

```json
{
  "schema": "holly-bibley-discovery-snapshot",
  "version": 1,
  "source": { "name": "LibreNMS adapter", "adapter": "librenms" },
  "collectedAt": "2026-10-28T07:30:00.000Z",
  "scope": { "cidr": "192.0.2.0/24", "label": "Example network" },
  "warnings": [],
  "vlans": [
    { "tag": 20, "name": "OT-CONTROL", "subnet": "192.0.2.32/27", "gateway": "192.0.2.33" }
  ],
  "devices": [
    {
      "key": "sw-ot-01",
      "hostname": "SW-OT-01",
      "type": "Industrial switch",
      "model": "Managed switch",
      "managementIp": "192.0.2.3",
      "macAddress": "02:00:00:00:30:03",
      "confidence": "confirmed",
      "lastSeenAt": "2026-10-28T07:30:00.000Z",
      "interfaces": [
        { "vlanTag": 20, "name": "Vlan20", "ip": "192.0.2.35/27", "status": "up", "confidence": "confirmed" }
      ],
      "ports": [
        { "name": "Gi1/0/5", "mode": "access", "accessVlanTag": 20, "status": "up", "speed": "1 Gbps", "confidence": "confirmed" }
      ]
    }
  ],
  "links": [
    {
      "key": "sw-to-endpoint",
      "sourceKey": "sw-ot-01",
      "sourcePort": "Gi1/0/5",
      "targetKey": "plc-01",
      "targetPort": "Ethernet1",
      "mediaType": "Copper Ethernet",
      "label": "",
      "confidence": "confirmed",
      "observedAt": "2026-10-28T07:30:00.000Z"
    }
  ]
}
```

## Supported values

- Device `type` must match a role in Holly Bibley's device catalog. Unknown types are imported as `Other` and reported as a warning.
- Port `mode`: `unknown`, `access`, `trunk`, `routed`, or `virtual`.
- Port and interface `status`: `up`, `down`, or `unknown`.
- `confidence`: `confirmed`, `inferred`, or `unknown`. If omitted or unrecognised it becomes `unknown`.
- Link `mediaType`: `Copper Ethernet`, `Fiber optic`, `Wireless`, `Console`, `Virtual link`, or `Other`.
- Optional device attributes: `managementIp`, `ipAddress` or `ip`, `macAddress`, `notes`, `lastSeenAt`.
- Optional port attributes: `accessVlanTag`, `allowedVlanTags`, `status`, `speed`, `confidence`, `notes`.
- Optional interface attributes: `vlanTag`, `name`, `ip`, `peerPort`, `status`, `macAddress`, `confidence`.
- Optional link attributes: `mediaType`, `label`, `notes`, `confidence`, `observedAt`.

Missing values are not guessed. If a link references an absent device, it is skipped and a warning is recorded. VLAN references not present in the VLAN list are not invented. All imports should be reviewed before being treated as authoritative network documentation.
