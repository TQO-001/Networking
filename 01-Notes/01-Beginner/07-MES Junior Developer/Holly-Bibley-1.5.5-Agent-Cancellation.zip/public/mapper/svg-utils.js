export const svgNS = 'http://www.w3.org/2000/svg';
export function svgElement(tag, attrs = {}, text) {
  const element = document.createElementNS(svgNS, tag);
  Object.entries(attrs).forEach(([key, value]) => { if (value !== undefined && value !== null) element.setAttribute(key, String(value)); });
  if (text !== undefined) element.textContent = String(text);
  return element;
}
export function addSvgText(parent, x, y, text, className, attrs = {}) {
  const element = svgElement('text', { x, y, ...attrs }, text);
  if (className) element.setAttribute('class', className);
  parent.appendChild(element);
  return element;
}
export function estimateTextWidth(text, size = 10) { return Math.max(50, String(text || '').length * size * 0.58 + 16); }
export function roundedRect(parent, x, y, width, height, rx, attrs = {}) {
  return parent.appendChild(svgElement('rect', { x, y, width, height, rx, ...attrs }));
}
export function escapeHtml(value = '') {
  return String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
}
export function diagramPalette(theme = 'light') {
  return theme === 'dark'
    ? { bg: '#212121', grid: '#343434', lane: '#2f2f2f', border: '#454545', text: '#ececec', sub: '#b4b4b4', card: '#2f2f2f', port: '#303030', shadow: '#000000', accent: '#d4a72c', gateway: '#b4b4b4', legend: '#b4b4b4', muted: '#8f8f8f', multiBg: '#3b3320', multiBorder: '#80641d', multiText: '#f1d777', connectionLabel: '#242424' }
    : { bg: '#ffffff', grid: '#f0f0f0', lane: '#f8f7f3', border: '#e5e1d6', text: '#0d0d0d', sub: '#676767', card: '#ffffff', port: '#fffdf5', shadow: '#000000', accent: '#b88708', gateway: '#676767', legend: '#676767', muted: '#929292', multiBg: '#fff4d1', multiBorder: '#e6c96b', multiText: '#8c6800', connectionLabel: '#ffffff' };
}
