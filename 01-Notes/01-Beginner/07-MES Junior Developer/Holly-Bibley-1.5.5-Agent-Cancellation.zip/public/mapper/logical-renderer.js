
export function createLogicalRenderer(getContext) {
  return function drawLogicalDiagram() {
    const { project, selected, zoom, theme, $, icons, typeLabels, typeColors, vlanById, deviceById, select, startDrag, updateCounts, openAddVlan, isHostGroup, getHostChildEntries, getDragState, svgElement: sv, addSvgText: addText, estimateTextWidth: estimateWidth, roundedRect, diagramPalette } = getContext();
    const hostChildEntries = (host) => getHostChildEntries(project, host);
    const groupColumns = (host) => Math.min(3, Math.max(1, hostChildEntries(host).length));
    const vlanCurveAmplitude = (v) => v?.lineStyle === 'curve' ? 34 : v?.lineStyle === 'deep-curve' ? 64 : 0;
    const vlanYAt = (v, x, x1, x2, baseY) => {
      const amp = vlanCurveAmplitude(v);
      if (!amp) return baseY;
      const t = Math.max(0, Math.min(1, (x - x1) / (x2 - x1 || 1)));
      return baseY + 2 * amp * t * (1 - t);
    };
    const vlanPath = (v, x1, x2, y) => {
      const amp = vlanCurveAmplitude(v);
      return amp ? `M ${x1} ${y} Q ${(x1 + x2) / 2} ${y + amp} ${x2} ${y}` : `M ${x1} ${y} L ${x2} ${y}`;
    };
    const nodeWidth = (d) => isHostGroup(d) && hostChildEntries(d).length ? Math.max(500, 30 + groupColumns(d) * 140 + (groupColumns(d) - 1) * 10) : 202;
    const nodeHeight = (d) => {
      if (isHostGroup(d) && hostChildEntries(d).length) {
        const count = hostChildEntries(d).length, rows = Math.ceil(count / groupColumns(d));
        return 124 + rows * 78 + 10;
      } return 98 + (d.hostedDevices?.length ? 14 + 14 * Math.min(d.hostedDevices.length, 6) : 0);
    };
    const T = diagramPalette(theme), mount = $('canvasMount');
    mount.innerHTML = '';
    if (project.vlans.length === 0) {
      mount.innerHTML = `<div class="canvas-empty">
      <div class="empty-icon">${icons.network}</div>
      <h2>Start with a VLAN segment</h2>
      <p>Add the first logical network, give it a VLAN ID and subnet, then attach device cards. You can later add a firewall, router or remote-session relationships.</p>
      <button class="btn primary" id="emptyAddVlan">＋ Create first VLAN</button>
      </div>`;
      $('emptyAddVlan').onclick = openAddVlan;
      updateCounts();
      return;
    }
    const n = Math.max(1, project.vlans.length), maxX = project.devices.reduce((m, d) => Math.max(m, d.x || 300), 300), width = Math.max(1000, maxX + 190 + 70), busStart = 250, laneY = idx => 390 + idx * 360, busEnd = width - 38;
    const height = Math.max(520, laneY(n - 1) + 112);
    const svg = sv('svg', { xmlns: 'http://www.w3.org/2000/svg', width: width * zoom, height: height * zoom, viewBox: `0 0 ${width} ${height}`, class: 'canvas-stage', role: 'img', 'aria-label': 'Editable logical network diagram' });
    roundedRect(svg, 0, 0, width, height, 14, { fill: T.bg });
    for (let x = busStart; x < width; x += 80)svg.appendChild(sv('line', { x1: x, y1: 35, x2: x, y2: height - 24, stroke: T.grid, 'stroke-width': 1 }));
    const defs = sv('defs');
    const marker = sv('marker', { id: 'hb-arrow-gold', markerWidth: 8, markerHeight: 8, refX: 6, refY: 3, orient: 'auto', markerUnits: 'strokeWidth' });
    marker.appendChild(sv('path', { d: 'M0,0 L6,3 L0,6 z', fill: T.accent }));
    defs.appendChild(marker);
    svg.appendChild(defs);
    project.vlans.forEach((v, i) => {
      const y = laneY(i), color = v.color || '#c99a18';
      roundedRect(svg, 20, y - 40, 205, 80, 10, { fill: T.lane, stroke: T.border, 'stroke-width': 1 });
      roundedRect(svg, 20, y - 40, 4, 80, 2, { fill: color });
      addText(svg, 36, y - 22, `VLAN ${v.tag}`, null, { fill: color, 'font-size': 10, 'font-weight': 800, 'letter-spacing': '.08em' });
      addText(svg, 36, y - 5, v.name || 'Unnamed VLAN', 'lane-name');
      addText(svg, 36, y + 11, v.subnet || 'Subnet not set', 'lane-sub');
      if (v.gateway) addText(svg, 36, y + 27, `GW ${v.gateway}`, null, { fill: T.gateway, 'font-size': 9, 'font-weight': 700 });
      svg.appendChild(sv('path', { d: vlanPath(v, busStart, busEnd, y), fill: 'none', stroke: color, 'stroke-width': 3, 'stroke-linecap': 'round', 'stroke-linejoin': 'round', opacity: .95 }));
      svg.appendChild(sv('circle', { cx: busStart, cy: y, r: 4, fill: color }));
      svg.appendChild(sv('circle', { cx: busEnd, cy: y, r: 4, fill: color }));
      const g = sv('g', { class: 'vlan-label', tabindex: 0, role: 'button', 'aria-label': `Edit VLAN ${v.tag} ${v.name}`, 'data-vlan-id': v.id });
      g.appendChild(sv('rect', { x: 15, y: y - 39, width: 215, height: 78, fill: 'transparent' }));
      g.addEventListener('click', () => select('vlan', v.id));
      g.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          select('vlan', v.id);
        }
      });
      svg.appendChild(g);
    });
    // Compute one or several visual instances per device. The data remains one device record.
    const nodeLists = new Map(), nodeInstances = [];
    project.devices.forEach(d => {
      if (d.parentHostId) return;
      const valid = (d.interfaces || []).filter(it => vlanById(it.vlanId));
      if (!valid.length) return;
      const h = nodeHeight(d), w = nodeWidth(d);
      let entries = [];
      if (d.displayMode === 'per-vlan' && valid.length > 1) {
        entries = valid.map(it => {
          const idx = project.vlans.findIndex(v => v.id === it.vlanId), y = laneY(idx);
          return { d, valid: [it], instanceVlanId: it.vlanId, idxs: [idx], top: y, bottom: y, x: d.x || 350, y: y - h - 21, w, h, perVlan: true };
        });
      }
      else {
        const idxs = valid.map(it => project.vlans.findIndex(v => v.id === it.vlanId)).sort((a, b) => a - b), top = laneY(idxs[0]), bottom = laneY(idxs[idxs.length - 1]), y = idxs.length === 1 ? top - h - 21 : ((top + bottom) / 2) - (h / 2);
        entries = [{ d, valid, instanceVlanId: null, idxs, top, bottom, x: d.x || 350, y, w, h, perVlan: false }];
      }
      nodeLists.set(d.id, entries);
      entries.forEach((info, j) => {
        info.instanceKey = `${d.id}::${info.instanceVlanId || 'shared'}::${j}`;
        nodeInstances.push(info);
      });
    });
    // Child VMs get visual anchor points inside their outer host group for remote/service arrows,
    // but are intentionally not part of nodeInstances and therefore never get their own VLAN connector.
    nodeInstances.forEach(info => {
      if (!isHostGroup(info.d)) return;
      const items = hostChildEntries(info.d);
      if (!items.length) return;
      const cols = groupColumns(info.d), cw = 140, ch = 66;
      info.childLayouts = items.map((entry, i) => {
        const col = i % cols, row = Math.floor(i / cols), x = info.x - info.w / 2 + 20 + cw / 2 + col * (cw + 10), y = info.y + 120 + row * 78;
        return { entry, x, y, w: cw, h: ch, hostInfo: info };
      });
    });
    nodeInstances.forEach(info => {
      (info.childLayouts || []).forEach(layout => {
        if (!layout.entry.device) return;
        const list = nodeLists.get(layout.entry.device.id) || [];
        list.push({ d: layout.entry.device, x: layout.x, y: layout.y, w: layout.w, h: layout.h, nested: true, hostInfo: info });
        nodeLists.set(layout.entry.device.id, list);
      });
    });
    // Network-interface associations terminate at each visual instance. These remain different from remote-session links.
    nodeInstances.forEach(info => {
      const { d, valid, idxs, y, h } = info;
      valid.forEach(it => {
        const laneIdx = project.vlans.findIndex(v => v.id === it.vlanId), ly = vlanYAt(vlanById(it.vlanId), info.x, busStart, busEnd, laneY(laneIdx)), color = vlanById(it.vlanId)?.color || '#c99a18';
        let startY, endY = ly;
        if (info.perVlan) {
          startY = y + h;
        } else if (idxs.length === 1) {
          startY = y + h;
        } else {
          startY = ly < y ? y : (ly > y + h ? y + h : (ly < y + h / 2 ? y : y + h));
        }
        const lo = Math.min(startY, endY), hi = Math.max(startY, endY);
        let segments = [[lo, hi]];
        project.vlans.forEach((other, oi) => {
          if (other.id === it.vlanId) return;
          const oy = laneY(oi);
          if (oy > lo + 2 && oy < hi - 2) segments = segments.flatMap(([a, b]) => oy > a && oy < b ? [[a, oy - 5], [oy + 5, b]] : [[a, b]]);
        });
        segments.forEach(([a, b]) => {
          if (b - a > 1) svg.appendChild(sv('line', { x1: info.x, y1: a, x2: info.x, y2: b, stroke: color, 'stroke-width': 1.8, opacity: .95 }));
        });
        svg.appendChild(sv('circle', { cx: info.x, cy: ly, r: 4, fill: color, stroke: T.bg, 'stroke-width': 1.5 }));
        const peer = it.peerPort ? `↔ ${it.peerPort}` : '';
        const label = [it.name || 'Interface', it.ip || '', peer].filter(Boolean).join(' · ');
        if (label) {
          const maxChars = 34, shortLabel = label.length > maxChars ? label.slice(0, maxChars - 1) + '…' : label, labelY = ly + 15, labelW = Math.min(250, estimateWidth(shortLabel, 9)), lx = Math.max(busStart, Math.min(info.x - labelW / 2, busEnd - labelW));
          roundedRect(svg, lx, labelY - 10, labelW, 17, 4, { fill: T.port, stroke: T.border, 'stroke-width': .8 });
          addText(svg, lx + 7, labelY + 1, shortLabel, 'port-label');
        }
      });
    });
    // A virtual firewall/router can remain nested in its ESXi host group while its vNICs reach external VLAN segments.
    const nestedDrawn = new Set();
    nodeInstances.forEach(hostInfo => {
      (hostInfo.childLayouts || []).forEach(layout => {
        const child = layout.entry.device;
        if (!child || !['Firewall', 'VPN gateway', 'Remote access gateway', 'Router', 'Layer 3 switch'].includes(child.type) || nestedDrawn.has(child.id)) return;
        nestedDrawn.add(child.id);
        (child.interfaces || []).forEach(it => {
          const laneIdx = project.vlans.findIndex(v => v.id === it.vlanId);
          if (laneIdx < 0) return;
          const vlan = project.vlans[laneIdx];
          const ly = vlanYAt(vlan, layout.x, busStart, busEnd, laneY(laneIdx));
          const startY = layout.y + layout.h;
          const lo = Math.min(startY, ly), hi = Math.max(startY, ly), color = vlan.color || '#c99a18';
          let segments = [[lo, hi]];
          project.vlans.forEach((other, oi) => {
            if (other.id === it.vlanId) return;
            const oy = laneY(oi);
            if (oy > lo + 2 && oy < hi - 2) segments = segments.flatMap(([a, b]) => oy > a && oy < b ? [[a, oy - 5], [oy + 5, b]] : [[a, b]]);
          });
          segments.forEach(([a, b]) => {
            if (b - a > 1) svg.appendChild(sv('line', { x1: layout.x, y1: a, x2: layout.x, y2: b, stroke: color, 'stroke-width': 2, 'stroke-dasharray': '5 3', opacity: .98 }));
          });
          svg.appendChild(sv('circle', { cx: layout.x, cy: ly, r: 4, fill: color, stroke: T.bg, 'stroke-width': 1.5 }));
          const label = [it.name || 'vNIC', it.ip || '', it.peerPort ? `↔ ${it.peerPort}` : ''].filter(Boolean).join(' · ');
          const short = label.length > 34 ? label.slice(0, 33) + '…' : label;
          if (short) {
            const labelW = Math.min(250, estimateWidth(short, 9));
            const lx = Math.max(busStart, Math.min(layout.x - labelW / 2, busEnd - labelW));
            roundedRect(svg, lx, ly + 13, labelW, 17, 4, { fill: T.port, stroke: T.border, 'stroke-width': .8 });
            addText(svg, lx + 7, ly + 24, short, 'port-label');
          }
        });
      });
    });
    // Draw directional remote/session relationships as dashed curved arrows, visually distinct from VLAN attachment lines.
    function representative(deviceId, other) {
      const list = nodeLists.get(deviceId) || [];
      if (!list.length) return null;
      return list.reduce((best, node) => Math.abs((node.y + node.h / 2) - (other.y + other.h / 2)) < Math.abs((best.y + best.h / 2) - (other.y + other.h / 2)) ? node : best, list[0]);
    }
    (project.connections || []).forEach(c => {
      const fromList = nodeLists.get(c.fromDeviceId), toList = nodeLists.get(c.toDeviceId);
      if (!fromList?.length || !toList?.length) return;
      let best = null;
      fromList.forEach(a => toList.forEach(b => {
        const cost = Math.abs((a.y + a.h / 2) - (b.y + b.h / 2)) + Math.abs(a.x - b.x) * .02;
        if (!best || cost < best.cost) best = { a, b, cost };
      }));
      if (!best) return;
      const a = best.a, b = best.b, ay = a.y + a.h / 2, by = b.y + b.h / 2;
      let sx, sy, ex, ey, cx1, cy1, cx2, cy2;
      if (Math.abs(b.x - a.x) < 230) {
        const side = 1, sourceAbove = ay <= by;
        sx = a.x;
        sy = sourceAbove ? a.y + a.h : a.y;
        ex = b.x;
        ey = sourceAbove ? b.y : b.y + b.h;
        cx1 = sx + side * 110;
        cy1 = sy + (sourceAbove ? 32 : -32);
        cx2 = ex + side * 110;
        cy2 = ey + (sourceAbove ? -32 : 32);
      } else {
        const dir = b.x >= a.x ? 1 : -1;
        sx = a.x + dir * (a.w / 2);
        sy = ay;
        ex = b.x - dir * (b.w / 2);
        ey = by;
        const lift = Math.max(30, Math.min(78, Math.abs(ex - sx) * .12 + 20));
        const curveY = Math.min(ay, by) - lift;
        cx1 = sx + (ex - sx) * .30;
        cy1 = curveY;
        cx2 = sx + (ex - sx) * .70;
        cy2 = curveY;
      } const path = sv('path', { d: `M ${sx} ${sy} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${ex} ${ey}`, fill: 'none', stroke: T.accent, 'stroke-width': 2, 'stroke-dasharray': '7 5', 'marker-end': 'url(#hb-arrow-gold)', opacity: .95 });
      svg.appendChild(path);
      const mx = (sx + ex) / 2, my = (sy + ey + 2 * Math.min(cy1, cy2)) / 4 - 5;
      const label = String(c.label || c.type || 'Remote link'), short = label.length > 28 ? label.slice(0, 27) + '…' : label, lw = Math.min(210, estimateWidth(short, 8));
      roundedRect(svg, mx - lw / 2, my - 10, lw, 17, 5, { fill: T.connectionLabel, stroke: T.accent, 'stroke-width': .9 });
      addText(svg, mx, my + 1, short, 'connection-label', { 'text-anchor': 'middle' });
    });
    // Device cards: VM guests render as small cards inside a larger host group.
    nodeInstances.forEach(info => {
      const { d, valid, x, y, w, h, instanceVlanId } = info;
      const color = typeColors[d.type] || typeColors.Other, selectedNow = selected?.kind === 'device' && selected.id === d.id, g = sv('g', { class: `device-node${selectedNow ? ' selected' : ''}`, transform: `translate(${x - w / 2},${y})`, tabindex: 0, role: 'button', 'aria-label': `Select ${d.hostname}${instanceVlanId ? ` on VLAN ${vlanById(instanceVlanId)?.tag || ''}` : ''}`, 'data-device-id': d.id });
      g.appendChild(sv('rect', { class: 'node-shadow', x: 2, y: 4, width: w, height: h, rx: 11, fill: T.shadow, opacity: .10 }));
      g.appendChild(sv('rect', { class: 'node-shell', x: 0, y: 0, width: w, height: h, rx: 11, fill: T.card, stroke: selectedNow ? T.accent : T.border, 'stroke-width': selectedNow ? 2.3 : 1.1 }));
      roundedRect(g, 0, 0, 5, h, 2, { fill: color });
      addText(g, 14, 25, typeLabels[d.type] || typeLabels.Other, 'node-type');
      addText(g, 14, 59, d.hostname || 'Unnamed device', 'node-name');
      let displayIps = [];
      if (instanceVlanId) {
        displayIps = valid.filter(it => it.vlanId === instanceVlanId).map(it => it.ip).filter(Boolean);
      } else {
        displayIps = [...new Set(valid.map(it => it.ip).filter(Boolean))];
      };
      const detail = instanceVlanId ? (displayIps.length === 1 ? displayIps[0] : (displayIps.length > 1 ? `${displayIps.length} interface IPs` : 'No IP on this VLAN')) : (displayIps.length === 1 ? displayIps[0] : (displayIps.length > 1 ? `${displayIps.length} interface IPs` : (d.managementIp || (valid.length > 1 ? `${valid.length} VLAN interfaces` : 'IP not set'))));
      addText(g, 14, 76, detail.length > 36 ? detail.slice(0, 35) + '…' : detail, 'node-detail');
      const model = d.model || d.type;
      addText(g, 14, 90, model.length > Math.floor(w / 7) ? model.slice(0, Math.floor(w / 7) - 1) + '…' : model, 'svg-muted', { 'font-size': 9 });
      const entries = info.childLayouts || [];
      if (entries.length) {
        g.appendChild(sv('line', { x1: 10, y1: 99, x2: w - 10, y2: 99, stroke: T.border, 'stroke-width': .8 }));
        addText(g, 14, 110, `VIRTUAL MACHINES / WORKLOADS · ${entries.length}`, null, { fill: T.sub, 'font-size': 8, 'font-weight': 800, 'letter-spacing': '.04em' });
        entries.forEach(layout => {
          const entry = layout.entry, child = entry.device, cg = sv('g', { class: `nested-device${child && selected?.kind === 'device' && selected.id === child.id ? ' selected' : ''}`, transform: `translate(${layout.x - (x - w / 2)},${layout.y - y})`, 'data-child-device-id': child?.id || '' });
          const guestColor = child ? (typeColors[child.type] || typeColors.Other) : T.accent;
          const fill = theme === 'dark' ? '#303030' : '#fffdf8';
          cg.appendChild(sv('rect', { x: 0, y: 0, width: layout.w, height: layout.h, rx: 7, fill, stroke: child && selected?.kind === 'device' && selected.id === child.id ? T.accent : T.border, 'stroke-width': child && selected?.kind === 'device' && selected.id === child.id ? 2 : 1 }));
          roundedRect(cg, 0, 0, 4, layout.h, 2, { fill: guestColor });
          if (child) {
            const ip = (child.interfaces || []).map(it => it.ip).find(Boolean) || child.managementIp || 'IP not set';
            const vlanText = [...new Set((child.interfaces || []).map(it => {
              const v = vlanById(it.vlanId);
              return v ? `VLAN ${v.tag}` : '';
            }).filter(Boolean))].join(' · ');
            const hostname = child.hostname.length > 20 ? child.hostname.slice(0, 19) + '…' : child.hostname;
            const guestType = typeLabels[child.type] || child.type;
            const ipText = ip.length > 23 ? ip.slice(0, 22) + '…' : ip;
            addText(cg, 10, 18, guestType, null, { fill: guestColor, 'font-size': 7, 'font-weight': 800 });
            addText(cg, 10, 35, hostname, null, { fill: T.text, 'font-size': 10, 'font-weight': 800 });
            addText(cg, 10, 49, ipText, null, { fill: T.sub, 'font-size': 8 });
            addText(cg, 10, 60, vlanText || 'Guest network not specified', null, { fill: T.sub, 'font-size': 7 });
            cg.setAttribute('tabindex', '0');
            cg.setAttribute('role', 'button');
            cg.setAttribute('aria-label', `Select guest ${child.hostname}`);
            cg.addEventListener('click', e => {
              e.stopPropagation();
              select('device', child.id);
            });
            cg.addEventListener('keydown', e => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                e.stopPropagation();
                select('device', child.id);
              }
            });
            cg.addEventListener('pointerdown', e => e.stopPropagation());
          } else {
            const raw = entry.label, parts = raw.split(/[·|–—]/), name = (parts[0] || raw).trim(), desc = parts.slice(1).join(' · ').trim();
            addText(cg, 10, 27, name.length > 19 ? name.slice(0, 18) + '…' : name, null, { fill: T.text, 'font-size': 10, 'font-weight': 800 });
            addText(cg, 10, 45, desc.length > 22 ? desc.slice(0, 21) + '…' : desc, null, { fill: T.sub, 'font-size': 8 });
            addText(cg, 10, 59, 'Legacy workload note', null, { fill: T.sub, 'font-size': 7 });
          }
          g.appendChild(cg);
        });
      } else {
        const hosted = (d.hostedDevices || []).slice(0, 6);
        if (hosted.length) {
          g.appendChild(sv('line', { x1: 10, y1: 99, x2: w - 10, y2: 99, stroke: T.border, 'stroke-width': .8 }));
          addText(g, 14, 111, 'HOSTED DEVICES / WORKLOADS', null, { fill: T.sub, 'font-size': 8, 'font-weight': 800, 'letter-spacing': '.04em' });
          hosted.forEach((entry, i) => {
            const label = String(entry).length > Math.floor(w / 6) ? String(entry).slice(0, Math.floor(w / 6) - 1) + '…' : String(entry);
            addText(g, 14, 124 + i * 14, '• ' + label, 'hosted-list-row', { 'font-size': 9, 'fill': T.sub });
          });
          if ((d.hostedDevices || []).length > 6) addText(g, 14, 124 + 6 * 14, `+ ${(d.hostedDevices || []).length - 6} more…`, null, { fill: T.sub, 'font-size': 9 });
        }
      }
      if (valid.length > 1 || info.perVlan) {
        roundedRect(g, w - 60, 11, 47, 18, 6, { fill: T.multiBg, stroke: T.multiBorder });
        addText(g, w - 36.5, 23, info.perVlan ? `VLAN ${vlanById(instanceVlanId)?.tag || ''}` : `${valid.length}× VLAN`, null, { fill: T.multiText, 'font-size': 8, 'font-weight': 800, 'text-anchor': 'middle' });
      }
      g.addEventListener('click', e => {
        if (getDragState()?.moved) return;
        select('device', d.id);
      });
      g.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          select('device', d.id);
        }
      });
      g.addEventListener('pointerdown', e => {
        if (e.target.closest && e.target.closest('.nested-device')) return;
        startDrag(e, d.id, g);
      });
      svg.appendChild(g);
    });
    const legendY = height - 37;
    svg.appendChild(sv('line', { x1: 24, y1: legendY - 14, x2: width - 24, y2: legendY - 14, stroke: T.border, 'stroke-width': 1 }));
    svg.appendChild(sv('line', { x1: 32, y1: legendY, x2: 62, y2: legendY, stroke: '#c99a18', 'stroke-width': 3, 'stroke-linecap': 'round' }));
    addText(svg, 70, legendY + 4, 'Logical VLAN segment', null, { fill: T.legend, 'font-size': 10 });
    svg.appendChild(sv('line', { x1: 225, y1: legendY - 6, x2: 225, y2: legendY + 6, stroke: T.sub, 'stroke-width': 1.7 }));
    addText(svg, 237, legendY + 4, 'Device interface association', null, { fill: T.legend, 'font-size': 10 });
    svg.appendChild(sv('line', { x1: 455, y1: legendY, x2: 485, y2: legendY, stroke: T.accent, 'stroke-width': 2, 'stroke-dasharray': '6 4' }));
    addText(svg, 492, legendY + 4, 'Remote/session relationship', null, { fill: T.legend, 'font-size': 10 });
    addText(svg, width - 20, legendY + 4, 'Illustrative logical view — verify configuration', null, { fill: T.muted, 'font-size': 9, 'text-anchor': 'end' });
    mount.appendChild(svg);
    updateCounts();
  };
}
