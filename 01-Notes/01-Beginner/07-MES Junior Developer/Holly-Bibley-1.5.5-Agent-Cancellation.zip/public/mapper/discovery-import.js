import { defaultPalette, normalizeProject, physicalMediaTypes, portModes } from './project-model.js';
import { typeLabels } from './device-catalog.js';

const MAX_DEVICES = 20000;
const MAX_VLANS = 4094;
const MAX_LINKS = 100000;
const CONFIDENCE_VALUES = new Set(['confirmed', 'inferred', 'unknown']);
const STATUS_VALUES = new Set(['up', 'down', 'unknown']);

function text(value, max = 500) {
  return String(value ?? '').trim().slice(0, max);
}

function slug(value) {
  const valueSlug = text(value, 120).toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '');
  return valueSlug || 'item';
}

function uniqueId(prefix, rawKey, usedIds) {
  const base = `${prefix}-${slug(rawKey)}`;
  let id = base;
  let suffix = 2;
  while (usedIds.has(id)) id = `${base}-${suffix++}`;
  usedIds.add(id);
  return id;
}

function normaliseVlanTag(value) {
  const raw = text(value, 10);
  if (!/^\d{1,4}$/.test(raw)) throw new Error(`Invalid VLAN tag "${raw || '(empty)'}". Use an integer from 1 to 4094.`);
  const tag = Number(raw);
  if (tag < 1 || tag > 4094) throw new Error(`Invalid VLAN tag "${raw}". Use an integer from 1 to 4094.`);
  return String(tag);
}

/**
 * Validate and constrain the versioned adapter-neutral discovery snapshot format.
 * This module only converts collected data; it performs no network activity.
 */
export function normaliseDiscoverySnapshot(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    throw new Error('The file must contain a JSON discovery snapshot object.');
  }
  if (raw.schema !== 'holly-bibley-discovery-snapshot' || raw.version !== 1) {
    throw new Error('Unsupported discovery snapshot. Expected schema "holly-bibley-discovery-snapshot" version 1.');
  }
  if (!Array.isArray(raw.devices) || !Array.isArray(raw.vlans) || !Array.isArray(raw.links)) {
    throw new Error('A discovery snapshot must contain devices, vlans and links arrays.');
  }
  if (raw.devices.length > MAX_DEVICES || raw.vlans.length > MAX_VLANS || raw.links.length > MAX_LINKS) {
    throw new Error(`Snapshot exceeds the supported size (${MAX_DEVICES} devices, ${MAX_VLANS} VLANs or ${MAX_LINKS} links).`);
  }

  const warnings = Array.isArray(raw.warnings) ? raw.warnings.map((warning) => text(warning, 500)).filter(Boolean).slice(0, 100) : [];
  const sourceInput = typeof raw.source === 'string' ? { name: raw.source, adapter: 'external' } : (raw.source || {});
  const source = {
    name: text(sourceInput.name, 120) || 'Unknown discovery source',
    adapter: text(sourceInput.adapter, 80) || 'unknown',
  };
  const scopeInput = raw.scope && typeof raw.scope === 'object' ? raw.scope : {};
  const scope = { cidr: text(scopeInput.cidr, 80), label: text(scopeInput.label, 120) };
  const collectedAt = text(raw.collectedAt, 40);

  const vlanTags = new Set();
  const vlans = raw.vlans.map((vlan, index) => {
    if (!vlan || typeof vlan !== 'object') throw new Error(`VLAN entry ${index + 1} is not an object.`);
    const tag = normaliseVlanTag(vlan.tag);
    if (vlanTags.has(tag)) throw new Error(`Duplicate VLAN tag ${tag} in discovery snapshot.`);
    vlanTags.add(tag);
    return {
      tag,
      name: text(vlan.name, 100) || `VLAN ${tag}`,
      subnet: text(vlan.subnet, 80),
      gateway: text(vlan.gateway, 80),
      notes: text(vlan.notes, 1000),
    };
  });

  const deviceKeys = new Set();
  const devices = raw.devices.map((device, index) => {
    if (!device || typeof device !== 'object') throw new Error(`Device entry ${index + 1} is not an object.`);
    const key = text(device.key, 120);
    if (!key) throw new Error(`Device entry ${index + 1} is missing its stable "key".`);
    if (deviceKeys.has(key)) throw new Error(`Duplicate device key "${key}" in discovery snapshot.`);
    deviceKeys.add(key);
    const ports = Array.isArray(device.ports) ? device.ports : [];
    const interfaces = Array.isArray(device.interfaces) ? device.interfaces : [];
    if (ports.length > 300 || interfaces.length > 300) throw new Error(`${text(device.hostname, 80) || key} has more than 300 ports or interfaces.`);
    return {
      key,
      hostname: text(device.hostname, 80) || text(device.name, 80) || key,
      type: text(device.type, 80) || 'Other',
      model: text(device.model, 100),
      managementIp: text(device.managementIp || device.ipAddress || device.ip, 120),
      macAddress: text(device.macAddress, 80),
      discoveryConfidence: CONFIDENCE_VALUES.has(device.confidence) ? device.confidence : 'unknown',
      lastSeenAt: text(device.lastSeenAt, 40),
      notes: text(device.notes, 5000),
      ports: ports.map((port, portIndex) => {
        if (!port || typeof port !== 'object') throw new Error(`${key} port entry ${portIndex + 1} is not an object.`);
        return {
          name: text(port.name, 80),
          mode: portModes.includes(port.mode) ? port.mode : 'unknown',
          accessVlanTag: port.accessVlanTag == null || port.accessVlanTag === '' ? '' : normaliseVlanTag(port.accessVlanTag),
          allowedVlanTags: Array.isArray(port.allowedVlanTags) ? [...new Set(port.allowedVlanTags.map(normaliseVlanTag))] : [],
          status: STATUS_VALUES.has(port.status) ? port.status : 'unknown',
          speed: text(port.speed, 40),
          confidence: CONFIDENCE_VALUES.has(port.confidence) ? port.confidence : 'unknown',
          notes: text(port.notes, 500),
        };
      }).filter((port) => port.name),
      interfaces: interfaces.map((iface, interfaceIndex) => {
        if (!iface || typeof iface !== 'object') throw new Error(`${key} interface entry ${interfaceIndex + 1} is not an object.`);
        return {
          vlanTag: iface.vlanTag == null || iface.vlanTag === '' ? '' : normaliseVlanTag(iface.vlanTag),
          name: text(iface.name, 80),
          ip: text(iface.ip, 120),
          peerPort: text(iface.peerPort, 120),
          status: STATUS_VALUES.has(iface.status) ? iface.status : 'unknown',
          macAddress: text(iface.macAddress, 80),
          confidence: CONFIDENCE_VALUES.has(iface.confidence) ? iface.confidence : 'unknown',
        };
      }).filter((iface) => iface.vlanTag || iface.name || iface.ip),
    };
  });

  const links = raw.links.map((link, index) => {
    if (!link || typeof link !== 'object') throw new Error(`Link entry ${index + 1} is not an object.`);
    return {
      key: text(link.key, 120) || `link-${index + 1}`,
      sourceKey: text(link.sourceKey, 120),
      sourcePort: text(link.sourcePort, 80),
      targetKey: text(link.targetKey, 120),
      targetPort: text(link.targetPort, 80),
      mediaType: physicalMediaTypes.includes(link.mediaType) ? link.mediaType : 'Copper Ethernet',
      label: text(link.label, 120),
      notes: text(link.notes, 1000),
      confidence: CONFIDENCE_VALUES.has(link.confidence) ? link.confidence : 'unknown',
      observedAt: text(link.observedAt, 40),
    };
  });

  return {
    schema: 'holly-bibley-discovery-snapshot', version: 1,
    source, collectedAt, scope, warnings, vlans, devices, links,
  };
}

/** Convert a validated discovery snapshot to a canonical, editable Holly Bibley project. */
export function discoverySnapshotToProject(raw, options = {}) {
  const snapshot = normaliseDiscoverySnapshot(raw);
  const warnings = [...snapshot.warnings];
  const vlanIdByTag = new Map(snapshot.vlans.map((vlan) => [vlan.tag, `disc-vlan-${vlan.tag}`]));
  const usedDeviceIds = new Set();
  const deviceIdByKey = new Map();
  const unknownTypes = new Set();

  const vlans = snapshot.vlans.map((vlan, index) => ({
    id: vlanIdByTag.get(vlan.tag), tag: vlan.tag, name: vlan.name, subnet: vlan.subnet, gateway: vlan.gateway,
    notes: vlan.notes || `Imported from ${snapshot.source.name}. Verify against the authoritative VLAN configuration.`,
    lineStyle: 'straight', color: defaultPalette[index % defaultPalette.length],
  }));

  const devices = snapshot.devices.map((device, index) => {
    const id = uniqueId('disc-dev', device.key, usedDeviceIds);
    deviceIdByKey.set(device.key, id);
    const type = Object.prototype.hasOwnProperty.call(typeLabels, device.type) ? device.type : 'Other';
    if (type === 'Other' && device.type !== 'Other') unknownTypes.add(device.type);
    const ports = device.ports.map((port) => {
      const accessVlanId = vlanIdByTag.get(port.accessVlanTag) || '';
      const allowedVlanIds = port.allowedVlanTags.map((tag) => vlanIdByTag.get(tag)).filter(Boolean);
      if (port.accessVlanTag && !accessVlanId) warnings.push(`${device.hostname} ${port.name}: access VLAN ${port.accessVlanTag} was not present in the snapshot VLAN list.`);
      const allowedMissing = port.allowedVlanTags.filter((tag) => !vlanIdByTag.has(tag));
      if (allowedMissing.length) warnings.push(`${device.hostname} ${port.name}: unknown allowed VLAN tag(s) ${allowedMissing.join(', ')} were omitted.`);
      let mode = port.mode;
      if (mode === 'access' && !accessVlanId) mode = 'unknown';
      if (mode === 'trunk' && !allowedVlanIds.length) warnings.push(`${device.hostname} ${port.name}: trunk has no recognised allowed VLANs.`);
      return {
        name: port.name, mode, accessVlanId, allowedVlanIds, status: port.status, speed: port.speed,
        discoveryConfidence: port.confidence, notes: port.notes,
      };
    });
    const interfaces = device.interfaces.map((iface) => {
      const vlanId = vlanIdByTag.get(iface.vlanTag);
      if (iface.vlanTag && !vlanId) {
        warnings.push(`${device.hostname} ${iface.name || 'interface'}: VLAN ${iface.vlanTag} was not present in the snapshot VLAN list; the interface was retained without a VLAN association.`);
      } else if (!vlanId && (iface.name || iface.ip || iface.peerPort)) {
        warnings.push(`${device.hostname} ${iface.name || 'interface'}: no VLAN association was supplied. The interface details were retained, but it will not be shown on a VLAN line until assigned.`);
      }
      return {
        vlanId: vlanId || '', name: iface.name, ip: iface.ip, peerPort: iface.peerPort, status: iface.status,
        macAddress: iface.macAddress, discoveryConfidence: iface.confidence,
      };
    }).filter(Boolean);
    const x = 100 + (index % 4) * 300;
    const y = 100 + Math.floor(index / 4) * 230;
    return {
      id, type, hostname: device.hostname, model: device.model, managementIp: device.managementIp,
      macAddress: device.macAddress, discoveryStatus: 'discovered', discoveryConfidence: device.discoveryConfidence,
      lastSeenAt: device.lastSeenAt, notes: device.notes, x: x + 110, displayMode: 'single', parentHostId: '', hostedDevices: [],
      physicalPosition: { x, y }, ports, interfaces,
    };
  });

  for (const unknownType of unknownTypes) warnings.push(`Device type "${unknownType}" is not in Holly Bibley's catalog and was mapped to Other.`);

  const usedLinkIds = new Set();
  const physicalLinks = [];
  for (const link of snapshot.links) {
    const sourceDeviceId = deviceIdByKey.get(link.sourceKey);
    const targetDeviceId = deviceIdByKey.get(link.targetKey);
    if (!sourceDeviceId || !targetDeviceId) {
      warnings.push(`Link ${link.key}: endpoint ${!sourceDeviceId ? link.sourceKey : link.targetKey} is missing from the device list; link omitted.`);
      continue;
    }
    if (sourceDeviceId === targetDeviceId) {
      warnings.push(`Link ${link.key}: self-referential link was omitted.`);
      continue;
    }
    const id = uniqueId('disc-link', link.key, usedLinkIds);
    physicalLinks.push({
      id, sourceDeviceId, sourcePort: link.sourcePort, targetDeviceId, targetPort: link.targetPort,
      mediaType: link.mediaType, label: link.label, notes: link.notes,
      discoveryConfidence: link.confidence, discoverySource: snapshot.source.name, observedAt: link.observedAt || snapshot.collectedAt,
    });
  }

  const importedAt = new Date().toISOString();
  const projectName = (text(options.projectName, 100) || `Discovered network${snapshot.scope.cidr ? ` — ${snapshot.scope.cidr}` : ''}`).slice(0, 100);
  const provenanceNotes = [
    `Imported discovery snapshot from ${snapshot.source.name}.`,
    snapshot.collectedAt ? `Collection time: ${snapshot.collectedAt}.` : '',
    snapshot.scope.cidr ? `Scope: ${snapshot.scope.cidr}.` : '',
    warnings.length ? `${warnings.length} discovery warning(s) were recorded; review before using this as authoritative documentation.` : '',
  ].filter(Boolean).join('\n');

  const project = normalizeProject({
    schema: 'holly-bibley-project', version: 6, projectName, updatedAt: importedAt,
    vlans, devices, physicalLinks, connections: [], notes: provenanceNotes,
    discovery: {
      source: snapshot.source, collectedAt: snapshot.collectedAt, importedAt, scope: snapshot.scope, warnings: warnings.slice(0, 100),
    },
  });

  return { project, snapshot, summary: { devices: project.devices.length, vlans: project.vlans.length, links: project.physicalLinks.length, warnings: warnings.length } };
}
