// Small utility glyphs for editor controls; topology device cards are text-first.
const icon = paths => `
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
       stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    ${paths}
  </svg>
`;

export const icons = {
  network: icon(`
    <rect x="3" y="4" width="7" height="6" rx="1" />
    <rect x="14" y="4" width="7" height="6" rx="1" />
    <rect x="8.5" y="15" width="7" height="6" rx="1" />
    <path d="M6.5 10v2h11v-2M12 12v3" />
  `),
  device: icon(`
    <rect x="3" y="4" width="18" height="13" rx="2" />
    <path d="M8 21h8M12 17v4M7 8h2m2 0h2m2 0h2" />
  `),
  server: icon(`
    <rect x="4" y="3" width="16" height="7" rx="1.4" />
    <rect x="4" y="14" width="16" height="7" rx="1.4" />
    <path d="M7 6.5h.01M7 17.5h.01M10 6.5h6M10 17.5h6" />
  `),
  shield: icon(`
    <path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z" />
    <path d="m9 12 2 2 4-4" />
  `),
  route: icon(`
    <circle cx="6" cy="6" r="2" />
    <circle cx="18" cy="18" r="2" />
    <path d="M8 6h5a3 3 0 0 1 3 3v6M16 15l-3 0m3 0v-3" />
  `),
  sun: icon(`
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42" />
  `),
  moon: icon('<path d="M20.5 14A8.5 8.5 0 0 1 10 3.5 8.5 8.5 0 1 0 20.5 14Z" />'),
};
