// Download helpers and diagram exports live outside the editor controller.
import { svgElement as sv, diagramPalette } from './svg-utils.js';

export function createExportActions({ getProject, getTheme, getCurrentSvg, saveCloud, toast }) {
  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1200);
  }

  function safeFilename(value) {
    return String(value || 'network')
      .toLowerCase()
      .replace(/[^a-z0-9-_]+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 55) || 'network';
  }

  function addExportStyles(svg) {
    const style = sv('style');
    const palette = diagramPalette(getTheme());

    style.textContent = `
      text { font-family: Arial, Helvetica, sans-serif; }
      .port-label { font-family: Consolas, monospace; font-size: 10px; fill: ${palette.sub}; }
      .lane-name { font-size: 13px; font-weight: 800; fill: ${palette.text}; }
      .lane-sub { font-size: 10px; fill: ${palette.sub}; }
      .node-name { font-size: 12px; font-weight: 800; fill: ${palette.text}; }
      .node-type { font-size: 9px; font-weight: 800; letter-spacing: .08em; fill: #b88708; }
      .node-detail { font-size: 10px; fill: ${palette.sub}; }
      .svg-muted { fill: ${palette.sub}; }
      .connection-label {
        font-family: Arial, Helvetica, sans-serif;
        font-size: 9px;
        font-weight: 800;
        fill: #987000;
        paint-order: stroke;
        stroke: ${palette.connectionLabel};
        stroke-width: 4px;
        stroke-linejoin: round;
      }
      .nested-device.selected rect:first-child { stroke: ${palette.accent}; stroke-width: 2; }
      .device-node.selected .node-shell { stroke: ${palette.accent}; stroke-width: 2.4; }
    `;
    svg.insertBefore(style, svg.firstChild);
  }

  function exportJson() {
    const project = getProject();
    saveCloud();
    downloadBlob(
      new Blob([JSON.stringify(project, null, 2)], { type: 'application/json' }),
      `${safeFilename(project.projectName)}.holly-bibley.json`,
    );
    toast('Editable project exported');
  }

  function cloneDiagramForExport() {
    const current = getCurrentSvg();
    if (!current) {
      toast('Add a device or VLAN before exporting the diagram.');
      return null;
    }

    const clone = current.cloneNode(true);
    const [, , width, height] = current.getAttribute('viewBox').split(' ').map(Number);
    clone.setAttribute('width', width);
    clone.setAttribute('height', height);
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    addExportStyles(clone);
    return { clone, width, height };
  }

  function exportSvg() {
    const prepared = cloneDiagramForExport();
    if (!prepared) return;

    const { clone } = prepared;
    const project = getProject();
    const xml = '<?xml version="1.0" encoding="UTF-8"?>\n' + new XMLSerializer().serializeToString(clone);
    downloadBlob(new Blob([xml], { type: 'image/svg+xml;charset=utf-8' }), `${safeFilename(project.projectName)}.svg`);
    toast('SVG diagram exported — vector quality, ideal for reports');
  }

  function exportPng() {
    const prepared = cloneDiagramForExport();
    if (!prepared) return;

    const { clone, width, height } = prepared;
    const project = getProject();
    const blob = new Blob([new XMLSerializer().serializeToString(clone)], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const image = new Image();

    image.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = width * 2;
      canvas.height = height * 2;
      const context = canvas.getContext('2d');
      if (!context) {
        URL.revokeObjectURL(url);
        toast('PNG export failed; use SVG export instead');
        return;
      }

      context.scale(2, 2);
      context.drawImage(image, 0, 0, width, height);
      URL.revokeObjectURL(url);
      canvas.toBlob(png => {
        if (!png) {
          toast('PNG export failed; use SVG export instead');
          return;
        }
        downloadBlob(png, `${safeFilename(project.projectName)}.png`);
        toast('PNG diagram exported');
      });
    };

    image.onerror = () => {
      URL.revokeObjectURL(url);
      toast('PNG export failed; use SVG export instead');
    };
    image.src = url;
  }

  return { exportJson, exportSvg, exportPng };
}
