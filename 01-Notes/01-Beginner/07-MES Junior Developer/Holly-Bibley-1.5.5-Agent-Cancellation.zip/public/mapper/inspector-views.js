// Sidebar lists and the properties inspector are kept separate from state/event wiring.
import { deriveLogicalProject } from './project-model.js';
import { escapeHtml } from './svg-utils.js';

export function createSidebarRenderer(getContext) {
  return function renderSidebar() {
    const { $, project, selected, icons, vlanById, deviceById, select, updateCounts } = getContext();

    $('vlanList').innerHTML = '';
    $('deviceList').innerHTML = '';
    $('physicalLinkList').innerHTML = '';
    project.vlans.forEach(v => {
      const row = document.createElement('div');
      row.className = `object-row${selected?.kind === 'vlan' && selected.id === v.id ? ' active' : ''}`;
      row.innerHTML = `<div class="obj-mark vlan">${icons.network}</div>
      <div class="obj-meta">
      <div class="obj-title">VLAN ${escapeHtml(v.tag)} · ${escapeHtml(v.name)}</div>
      <div class="obj-sub">${escapeHtml(v.subnet || 'Subnet not set')} · ${escapeHtml(v.lineStyle || 'straight')}</div>
      </div>
      <button class="tiny-action" title="Edit VLAN" aria-label="Edit VLAN">›</button>`;
      row.onclick = () => select('vlan', v.id);
      $('vlanList').appendChild(row);
    });
    const derivedDeviceById = new Map(deriveLogicalProject(project).devices.map(device => [device.id, device]));
    project.devices.forEach(d => {
      const row = document.createElement('div');
      row.className = `object-row${selected?.kind === 'device' && selected.id === d.id ? ' active' : ''}`;
      const sym = /firewall|gateway/i.test(d.type) ? icons.shield : /switch|router/i.test(d.type) ? icons.route : /server|esxi|hypervisor|storage|virtual machine|rds|historian/i.test(d.type) ? icons.server : icons.device;
      const derived = derivedDeviceById.get(d.id) || d;
      const vlans = [...new Set((derived.interfaces || []).map(it => vlanById(it.vlanId)?.tag).filter(Boolean))];
      const parent = d.parentHostId ? deviceById(d.parentHostId) : null;
      row.innerHTML = `<div class="obj-mark">${sym}</div>
      <div class="obj-meta">
      <div class="obj-title">${escapeHtml(d.hostname)}</div>
      <div class="obj-sub">${escapeHtml(d.type)}${parent ? ' · VM on ' + escapeHtml(parent.hostname) : ' · ' + escapeHtml(vlans.length ? `VLAN ${vlans.join(', ')}` : 'Unassigned')}</div>
      </div>
      <button class="tiny-action" title="Edit device" aria-label="Edit device">›</button>`;
      row.onclick = () => select('device', d.id);
      $('deviceList').appendChild(row);
    });
    (project.physicalLinks || []).forEach(link => {
      const source = deviceById(link.sourceDeviceId), target = deviceById(link.targetDeviceId);
      if (!source || !target) return;
      const row = document.createElement('div');
      row.className = `object-row${selected?.kind === 'physicalLink' && selected.id === link.id ? ' active' : ''}`;
      row.innerHTML = `<div class="obj-mark">${icons.route}</div>
      <div class="obj-meta">
      <div class="obj-title">${escapeHtml(link.label || `${source.hostname} ↔ ${target.hostname}`)}</div>
      <div class="obj-sub">${escapeHtml(link.sourcePort || '?')} ↔ ${escapeHtml(link.targetPort || '?')} · ${escapeHtml(link.mediaType)}</div>
      </div>
      <button class="tiny-action" title="Edit physical link" aria-label="Edit physical link">›</button>`;
      row.onclick = () => select('physicalLink', link.id);
      $('physicalLinkList').appendChild(row);
    });
    updateCounts();
  };
}

export function createInspectorRenderer(getContext) {
  return function renderInspector() {
    const {
      $, project, selected, selectedItem, icons, typeLabels, isHostGroup, vlanById, deviceById,
      openEditVlan, deleteVlan, toast, markDirty, renderSidebar, drawDiagram,
      openEditPhysicalLink, deletePhysicalLink, openEditDevice, openAddPhysicalLink, openAddDevice,
      openAddConnection, deleteConnection, deleteDevice,
    } = getContext();

    const box = $('inspectorContent'), item = selectedItem();
    if (!item) {
      $('inspectorTitle').textContent = 'Properties';
      box.innerHTML = `<div class="inspector-empty">${icons.network}<br>
      <strong>Select a VLAN, device or cable</strong>
      <br>Port mode and cable information create the logical memberships.</div>`;
      return;
    }
    if (selected.kind === 'vlan') {
      const v = item;
      $('inspectorTitle').textContent = 'VLAN properties';
      const derived = deriveLogicalProject(project);
      const attached = derived.devices.filter(d => d.interfaces.some(it => it.vlanId === v.id));
      box.innerHTML = `<div class="prop-header">
      <div class="obj-mark vlan">${icons.network}</div>
      <div class="obj-meta">
      <div class="obj-title">VLAN ${escapeHtml(v.tag)}</div>
      <div class="obj-sub">Logical network segment</div>
      </div>
      </div>
  <div class="field">
      <label for="pTag">VLAN ID / tag</label>
      <input id="pTag" value="${escapeHtml(v.tag)}" maxlength="12">
      </div>
      <div class="field">
      <label for="pName">VLAN name</label>
      <input id="pName" value="${escapeHtml(v.name)}" maxlength="80">
      </div>
      <div class="field">
      <label for="pSubnet">Subnet / prefix</label>
      <input id="pSubnet" value="${escapeHtml(v.subnet)}" placeholder="10.20.20.0/24">
      </div>
      <div class="field">
      <label for="pGateway">Default gateway (if applicable)</label>
      <input id="pGateway" value="${escapeHtml(v.gateway)}" placeholder="10.20.20.1">
      </div>
      <div class="field">
      <label for="pLineStyle">VLAN line style</label>
      <select id="pLineStyle">
      <option value="straight" ${v.lineStyle === 'straight' ? 'selected' : ''}>Straight</option>
      <option value="curve" ${v.lineStyle === 'curve' ? 'selected' : ''}>Gentle curve</option>
      <option value="deep-curve" ${v.lineStyle === 'deep-curve' ? 'selected' : ''}>Deep curve</option>
      </select>
      <div class="field-help">Curves change presentation only, not the real network.</div>
      </div>
      <div class="field">
      <label for="pVlanNotes">Notes</label>
      <textarea id="pVlanNotes">${escapeHtml(v.notes)}</textarea>
      </div>
      <div class="info-card">
      <strong>Devices inferred or assigned to this VLAN</strong>
      <br>${attached.map(d => escapeHtml(d.hostname)).join(', ') || 'No connected ports or explicit interfaces yet.'}</div>
      <div class="inspector-actions">
      <button class="btn" id="editVlanBtn">Edit full form</button>
      <button class="btn danger-action" id="deleteVlanBtn">Delete</button>
      </div>`;
      ['pTag', 'pName', 'pSubnet', 'pGateway', 'pLineStyle', 'pVlanNotes'].forEach(id => $(id).addEventListener('change', () => {
        if (id === 'pTag' && project.vlans.some(x => x.id !== v.id && x.tag === $('pTag').value.trim())) {
          toast('That VLAN tag already exists.');
          $('pTag').value = v.tag;
          return;
        } v.tag = $('pTag').value.trim();
        v.name = $('pName').value.trim();
        v.subnet = $('pSubnet').value.trim();
        v.gateway = $('pGateway').value.trim();
        v.lineStyle = $('pLineStyle').value;
        v.notes = $('pVlanNotes').value;
        markDirty();
        renderSidebar();
        drawDiagram();
        renderInspector();
      }));
      $('editVlanBtn').onclick = () => openEditVlan(v.id);
      $('deleteVlanBtn').onclick = () => deleteVlan(v.id);
      return;
    }
    if (selected.kind === 'physicalLink') {
      const link = item, source = deviceById(link.sourceDeviceId), target = deviceById(link.targetDeviceId);
      $('inspectorTitle').textContent = 'Physical link properties';
      const portDescription = (device, name) => {
        const p = (device?.ports || []).find(item => item.name === name);
        if (!p) return 'Port mode not configured';
        if (p.mode === 'access') return `Access · VLAN ${escapeHtml(vlanById(p.accessVlanId)?.tag || '?')}`;
        if (p.mode === 'trunk') return `Trunk · VLANs ${(p.allowedVlanIds || []).map(id => vlanById(id)?.tag || '?').join(', ') || 'none allowed'}`;
        return escapeHtml(p.mode || 'unknown');
      };
      box.innerHTML = `<div class="prop-header">
      <div class="obj-mark">${icons.route}</div>
      <div class="obj-meta">
      <div class="obj-title">${escapeHtml(link.label || 'Physical link')}</div>
      <div class="obj-sub">${escapeHtml(link.mediaType)}</div>
      </div>
      </div>
      <div class="connection-item">
      <strong>${escapeHtml(source?.hostname || 'Unknown')} · ${escapeHtml(link.sourcePort || '?')}</strong>
      <div>${portDescription(source, link.sourcePort)}</div>
      <div class="connection-meta">Source endpoint</div>
      </div>
      <div class="connection-item">
      <strong>${escapeHtml(target?.hostname || 'Unknown')} · ${escapeHtml(link.targetPort || '?')}</strong>
      <div>${portDescription(target, link.targetPort)}</div>
      <div class="connection-meta">Target endpoint</div>
      </div>
      <div class="field">
      <label>Link label</label>
      <div>${escapeHtml(link.label || 'No label')}</div>
      </div>
      <div class="field">
      <label>Notes</label>
      <p>${escapeHtml(link.notes || 'No notes')}</p>
      </div>
      ${link.discoverySource || link.discoveryConfidence !== 'unknown' ? `<div class="info-card"><strong>Discovery details</strong><br>Confidence: ${escapeHtml(link.discoveryConfidence || 'unknown')}${link.discoverySource ? `<br>Source: ${escapeHtml(link.discoverySource)}` : ''}${link.observedAt ? `<br>Observed: ${escapeHtml(link.observedAt)}` : ''}</div>` : ''}
      <div class="info-card">
      <strong>Logical inference</strong>
      <br>Access VLANs infer Layer 2 membership. Trunk membership is inferred only for VLANs allowed at both ends. IP addresses, gateway roles and firewall policies are never invented.</div>
      <div class="inspector-actions">
      <button class="btn primary" id="editPhysicalLinkBtn">Edit link / port configuration</button>
      <button class="btn danger-action" id="deletePhysicalLinkBtn">Delete link</button>
      </div>`;
      $('editPhysicalLinkBtn').onclick = () => openEditPhysicalLink(link.id);
      $('deletePhysicalLinkBtn').onclick = () => deletePhysicalLink(link.id);
      return;
    }
    const d = item;
    $('inspectorTitle').textContent = 'Device properties';
    const discoveryMetaHtml = d.discoveryStatus === 'discovered'
      ? `<div class="info-card"><strong>Discovered asset</strong><br>Confidence: ${escapeHtml(d.discoveryConfidence || 'unknown')}${d.lastSeenAt ? `<br>Last seen: ${escapeHtml(d.lastSeenAt)}` : ''}</div>`
      : '';
    const vlanInterfaces = (d.interfaces || []).filter(it => it.vlanId).map(it => {
      const v = vlanById(it.vlanId);
      return `<div class="interface-row">
      <div class="interface-title">
      <span>VLAN ${escapeHtml(v?.tag || '?')} · ${escapeHtml(v?.name || 'Unknown')}</span>
      <span class="muted">${escapeHtml(it.name || 'Interface')}</span>
      </div>
      <div class="form-grid">
      <div class="field">
      <label>Interface name / role</label>
      <input data-iface="${escapeHtml(it.vlanId)}" data-field="name" value="${escapeHtml(it.name)}" placeholder="port2 / Gi1/0/1">
      </div>
      <div class="field">
      <label>Interface IP / prefix</label>
      <input data-iface="${escapeHtml(it.vlanId)}" data-field="ip" value="${escapeHtml(it.ip)}" placeholder="10.20.20.1/24">
      </div>
      </div>
      <div class="field">
      <label>Peer / virtual port group</label>
      <input data-iface="${escapeHtml(it.vlanId)}" data-field="peerPort" value="${escapeHtml(it.peerPort)}" placeholder="ESXi port group / switch port">
      </div>
      <div class="connection-meta">${it.status && it.status !== 'unknown' ? escapeHtml(it.status) : ''}${it.macAddress ? (it.status && it.status !== 'unknown' ? ' · ' : '') + escapeHtml(it.macAddress) : ''}${it.discoveryConfidence && it.discoveryConfidence !== 'unknown' ? ' · ' + escapeHtml(it.discoveryConfidence) : ''}</div>
      </div>`;
    }).join('');
    const unassignedInterfaces = (d.interfaces || []).filter(it => !it.vlanId);
    const unassignedInterfaceHtml = unassignedInterfaces.length ? `<div class="info-card"><strong>Interfaces without VLAN mapping</strong><div class="field-help">These interface details were discovered, but no reliable VLAN association was available. They are retained in the project and excluded from logical VLAN lines.</div>${unassignedInterfaces.map(it => `<div class="connection-item"><strong>${escapeHtml(it.name || 'Unnamed interface')}</strong><div>${escapeHtml(it.ip || 'No IP address')}</div><div class="connection-meta">${escapeHtml(it.status || 'unknown')}${it.macAddress ? ` · ${escapeHtml(it.macAddress)}` : ''}${it.discoveryConfidence && it.discoveryConfidence !== 'unknown' ? ` · ${escapeHtml(it.discoveryConfidence)}` : ''}</div></div>`).join('')}</div>` : '';
    const isPerVlan = d.displayMode === 'per-vlan';
    const vlanPorts = (d.ports || []).map(port => {
      const mode = port.mode === 'access' ? `Access · VLAN ${vlanById(port.accessVlanId)?.tag || '?'}` : port.mode === 'trunk' ? `Trunk · VLAN ${(port.allowedVlanIds || []).map(id => vlanById(id)?.tag || '?').join(', ')}` : (port.mode || 'unknown');
      const links = (project.physicalLinks || []).filter(l => (l.sourceDeviceId === d.id && l.sourcePort === port.name) || (l.targetDeviceId === d.id && l.targetPort === port.name)).length;
      return `<div class="connection-item">
      <strong>${escapeHtml(port.name)}</strong>
      <div>${escapeHtml(mode)}</div>
      <div class="connection-meta">${links} linked cable${links === 1 ? '' : 's'}${port.status && port.status !== 'unknown' ? ' · ' + escapeHtml(port.status) : ''}${port.speed ? ' · ' + escapeHtml(port.speed) : ''}${port.discoveryConfidence && port.discoveryConfidence !== 'unknown' ? ' · ' + escapeHtml(port.discoveryConfidence) : ''}${port.notes ? ' · ' + escapeHtml(port.notes) : ''}</div>
      </div>`;
    }).join('') || '<div class="field-help">No physical port configuration yet. Use Connect to define a port at each end of a cable.</div>';
    const related = (project.connections || []).filter(c => c.fromDeviceId === d.id || c.toDeviceId === d.id);
    const relHtml = related.length ? related.map(c => {
      const from = deviceById(c.fromDeviceId), to = deviceById(c.toDeviceId);
      return `<div class="connection-item">
      <button class="tiny-action" data-delete-connection="${escapeHtml(c.id)}" title="Remove relationship" aria-label="Remove relationship">×</button>
      <strong>${escapeHtml(from?.hostname || 'Unknown')} → ${escapeHtml(to?.hostname || 'Unknown')}</strong>
      <div>${escapeHtml(c.type || 'Relationship')}</div>
      <div class="connection-meta">${escapeHtml(c.label || 'No label')}${c.protocolPort ? ' · ' + escapeHtml(c.protocolPort) : ''}</div>
      </div>`;
    }).join('') : '<div class="field-help">No remote/session relationships mapped.</div>';
    box.innerHTML = `<div class="prop-header">
      <div class="obj-mark">${/firewall|gateway/i.test(d.type) ? icons.shield : /switch|router/i.test(d.type) ? icons.route : /server|esxi|hypervisor|storage|virtual machine|rds/i.test(d.type) ? icons.server : icons.device}</div>
      <div class="obj-meta">
      <div class="obj-title">${escapeHtml(d.hostname)}</div>
      <div class="obj-sub">${escapeHtml(d.type)}</div>
      </div>
      </div>
      ${discoveryMetaHtml}
 <div class="field">
      <label for="pHost">Hostname</label>
      <input id="pHost" value="${escapeHtml(d.hostname)}" maxlength="80">
      </div>
      <div class="field">
      <label for="pType">Device type</label>
      <select id="pType">${Object.keys(typeLabels).map(t => `<option ${t === d.type ? 'selected' : ''} value="${escapeHtml(t)}">${escapeHtml(t)}</option>`).join('')}</select>
      </div>
      <div class="field">
      <label for="pModel">Role / model / description</label>
      <input id="pModel" value="${escapeHtml(d.model)}" maxlength="100">
      </div>
      <div class="form-grid">
      <div class="field">
      <label for="pMgmt">Management IP (optional)</label>
      <input id="pMgmt" value="${escapeHtml(d.managementIp)}" placeholder="10.20.20.15">
      </div>
      <div class="field">
      <label for="pMac">MAC address (optional)</label>
      <input id="pMac" value="${escapeHtml(d.macAddress || '')}" placeholder="00:11:22:33:44:55" maxlength="80">
      </div>
      </div>
      <div class="field">
      <label for="pParentHost">Contained in server / VM group</label>
      <select id="pParentHost">
      <option value="">No group — independent device</option>${project.devices.filter(h => isHostGroup(h) && h.id !== d.id && !h.parentHostId).map(h => `<option value="${escapeHtml(h.id)}" ${d.parentHostId === h.id ? 'selected' : ''}>${escapeHtml(h.hostname)} · ${escapeHtml(h.type)}</option>`).join('')}</select>
      <div class="field-help">Virtual firewalls may be contained inside an ESXi group while their vNIC interfaces connect to VLANs in Logical view.</div>
      </div>
      <div class="field">
      <label for="pDisplayMode">Logical view placement</label>
      <select id="pDisplayMode">
      <option value="single" ${!isPerVlan ? 'selected' : ''}>One shared device box</option>
      <option value="per-vlan" ${isPerVlan ? 'selected' : ''}>Repeat on each assigned VLAN</option>
      </select>
      </div>
 <div class="divider-label">Physical ports & cables</div>
      <div class="connection-list">${vlanPorts}</div>
      <button class="btn small full-width-action" id="addPhysicalLinkFromDevice">＋ Connect this device</button>
      <div class="field-help">Set each port's access/trunk mode in the Connect dialog. This is what drives automatic Layer 2 VLAN membership.</div>
 <div class="divider-label">Explicit VLAN interfaces / IPs</div>${vlanInterfaces || '<div class="info-card">No explicit interfaces. Physical access/trunk port configuration can infer Layer 2 membership, but does not invent IPs.</div>'}<button class="btn small full-width-action action-spaced" id="editInterfacesBtn">＋ Manage VLAN interfaces</button>
 ${unassignedInterfaceHtml}
 ${isHostGroup(d) ? `<button class="btn primary small full-width-action action-block-spaced" id="addVmToGroupBtn">＋ Add VM to this group</button>` : ''}<div class="field">
      <label for="pHosted">Legacy workload notes (optional)</label>
      <textarea id="pHosted">${escapeHtml((d.hostedDevices || []).join('\n'))}</textarea>
      </div>
      <div class="field">
      <label for="pDevNotes">Notes</label>
      <textarea id="pDevNotes">${escapeHtml(d.notes)}</textarea>
      </div>
      <div class="divider-label">Remote access & session relationships</div>
      <p class="relationship-hint">Dashed arrows describe sessions/services, not physical cables or proof that access is permitted.</p>
      <div class="connection-list">${relHtml}</div>
      <button class="btn small full-width-action" id="addConnectionBtn">＋ Add remote / service relationship</button>
      <div class="inspector-actions">
      <button class="btn" id="editDeviceBtn">Edit full form</button>
      <button class="btn danger-action" id="deleteDeviceBtn">Delete</button>
      </div>`;
    const sync = () => {
      const oldType = d.type;
      d.hostname = $('pHost').value.trim();
      d.type = $('pType').value;
      if (oldType !== d.type && !isHostGroup(d)) project.devices.forEach(child => {
        if (child.parentHostId === d.id) child.parentHostId = '';
      });
      d.model = $('pModel').value.trim();
      d.managementIp = $('pMgmt').value.trim();
      d.macAddress = $('pMac')?.value.trim() || '';
      d.notes = $('pDevNotes').value;
      d.displayMode = $('pDisplayMode').value;
      d.parentHostId = $('pParentHost')?.value || '';
      if (d.parentHostId === d.id || isHostGroup(d)) d.parentHostId = '';
      d.hostedDevices = $('pHosted').value.split('\n').map(x => x.trim()).filter(Boolean).slice(0, 12);
      document.querySelectorAll('[data-iface]').forEach(input => {
        const it = d.interfaces.find(item => item.vlanId === input.dataset.iface);
        if (it) it[input.dataset.field] = input.value.trim();
      });
      markDirty();
      renderSidebar();
      drawDiagram();
    };
    ['pHost', 'pType', 'pModel', 'pMgmt', 'pMac', 'pParentHost', 'pDevNotes', 'pDisplayMode', 'pHosted'].forEach(id => $(id)?.addEventListener('change', () => {
      sync();
      renderInspector();
    }));
    document.querySelectorAll('[data-iface]').forEach(input => input.addEventListener('change', () => {
      sync();
      renderInspector();
    }));
    $('editDeviceBtn').onclick = () => openEditDevice(d.id);
    $('editInterfacesBtn').onclick = () => openEditDevice(d.id);
    $('addPhysicalLinkFromDevice').onclick = () => openAddPhysicalLink(d.id);
    if ($('addVmToGroupBtn')) $('addVmToGroupBtn').onclick = () => openAddDevice(d.id);
    $('addConnectionBtn').onclick = () => openAddConnection(d.id);
    document.querySelectorAll('[data-delete-connection]').forEach(btn => btn.addEventListener('click', () => deleteConnection(btn.dataset.deleteConnection)));
    $('deleteDeviceBtn').onclick = () => deleteDevice(d.id);
  };
}
