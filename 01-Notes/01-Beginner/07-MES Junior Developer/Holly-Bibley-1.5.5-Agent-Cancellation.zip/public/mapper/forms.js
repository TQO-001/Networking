// HTML builders for mapper dialogs. Keep user-facing fields and form markup in one place.
export function createMapperForms(getContext) {
  function vlanFormHtml(v) {
    const { escapeHtml } = getContext();

    return `<div class="form-grid">
      <div class="field">
      <label>VLAN ID / tag *</label>
      <input name="tag" required value="${escapeHtml(v.tag)}" placeholder="20">
      </div>
      <div class="field">
      <label>VLAN name *</label>
      <input name="name" required value="${escapeHtml(v.name)}" placeholder="OT-CONTROL">
      </div>
      </div>
      <div class="field">
      <label>Subnet / prefix</label>
      <input name="subnet" value="${escapeHtml(v.subnet)}" placeholder="10.20.20.0/24">
      </div>
      <div class="field">
      <label>Default gateway (optional)</label>
      <input name="gateway" value="${escapeHtml(v.gateway)}" placeholder="10.20.20.1">
      </div>
      <div class="field">
      <label>VLAN line style</label>
      <select name="lineStyle">
      <option value="straight" ${v.lineStyle === 'straight' ? 'selected' : ''}>Straight</option>
      <option value="curve" ${v.lineStyle === 'curve' ? 'selected' : ''}>Gentle curve</option>
      <option value="deep-curve" ${v.lineStyle === 'deep-curve' ? 'selected' : ''}>Deep curve</option>
      </select>
      <div class="field-help">Curves make long segments easier to distinguish while keeping device connectors attached.</div>
      </div>
      <div class="field">
      <label>Purpose / notes</label>
      <textarea name="notes" placeholder="VLAN purpose, zone, verification notes…">${escapeHtml(v.notes)}</textarea>
      </div>`;
  }

  function deviceFormHtml(d) {
    const { project, isHostGroup, escapeHtml, typeLabels } = getContext();

    const selectedIds = new Set(d.interfaces.map(it => it.vlanId));
    const options = project.vlans.map(v => `<label class="check-option">
      <input type="checkbox" name="vlanIds" value="${escapeHtml(v.id)}" ${selectedIds.has(v.id) ? 'checked' : ''}>
      <span>
      <strong>VLAN ${escapeHtml(v.tag)}</strong>
      <br>
      <span class="muted">${escapeHtml(v.name)}</span>
      </span>
      </label>`).join('');
    const ifaceRows = project.vlans.map(v => {
      const it = d.interfaces.find(x => x.vlanId === v.id) || { name: '', ip: '', peerPort: '' };
      return `<div class="interface-row ${selectedIds.has(v.id) ? '' : 'hidden'}" data-config-vlan="${escapeHtml(v.id)}">
      <div class="interface-title">
      <span>VLAN ${escapeHtml(v.tag)} · ${escapeHtml(v.name)}</span>
      </div>
      <div class="form-grid">
      <div class="field">
      <label>Interface name / role</label>
      <input data-config-field="name" data-config-id="${escapeHtml(v.id)}" value="${escapeHtml(it.name)}" placeholder="vmk0 / Ethernet0 / port2">
      </div>
      <div class="field">
      <label>Interface IP / prefix</label>
      <input data-config-field="ip" data-config-id="${escapeHtml(v.id)}" value="${escapeHtml(it.ip)}" placeholder="10.20.20.1/24 (if assigned)">
      </div>
      </div>
      <div class="field">
      <label>Peer device / switch port / port group</label>
      <input data-config-field="peerPort" data-config-id="${escapeHtml(v.id)}" value="${escapeHtml(it.peerPort)}" placeholder="SW-OT-01 Gi1/0/12">
      </div>
      </div>`;
    }).join('');
    const hosted = (d.hostedDevices || []).join('\n');
    return `<div class="form-grid">
      <div class="field">
      <label>Hostname *</label>
      <input name="hostname" required value="${escapeHtml(d.hostname)}" placeholder="ESXI-OT-01 / TC-OT-01" maxlength="80">
      </div>
      <div class="field">
      <label>Device type *</label>
      <select name="type">${Object.keys(typeLabels).map(t => `<option ${t === d.type ? 'selected' : ''} value="${escapeHtml(t)}">${escapeHtml(t)}</option>`).join('')}</select>
      </div>
      </div>
      <div class="field">
      <label>Role / model / description</label>
      <input name="model" value="${escapeHtml(d.model)}" placeholder="VMware ESXi host, operator thin client…" maxlength="100">
      </div>
      <div class="form-grid">
      <div class="field">
      <label>Management IP (optional)</label>
      <input name="managementIp" value="${escapeHtml(d.managementIp)}" placeholder="10.20.20.15">
      </div>
      <div class="field">
      <label>MAC address (optional)</label>
      <input name="macAddress" value="${escapeHtml(d.macAddress || '')}" placeholder="00:11:22:33:44:55" maxlength="80">
      </div>
      </div>
      <div class="field">
      <label>Contained in server / VM group</label>
      <select name="parentHostId">
      <option value="">No group — independent device</option>${project.devices.filter(h => isHostGroup(h) && h.id !== d.id && !h.parentHostId).map(h => `<option value="${escapeHtml(h.id)}" ${d.parentHostId === h.id ? 'selected' : ''}>${escapeHtml(h.hostname)} · ${escapeHtml(h.type)}</option>`).join('')}</select>
      <div class="field-help">Choose an ESXi host, hypervisor or server to place this device inside its larger group box. Grouped devices do not draw their own VLAN connectors.</div>
      </div>
      <div class="field">
      <label>Display style</label>
      <select name="displayMode">
      <option value="single" ${d.displayMode === 'per-vlan' ? '' : 'selected'}>One shared box for all interfaces</option>
      <option value="per-vlan" ${d.displayMode === 'per-vlan' ? 'selected' : ''}>Repeat the device on each selected VLAN</option>
      </select>
      <div class="field-help">Use repeat mode when the same server should be visible on separate VLAN lines. The cards are views of the same device record, not separate assets.</div>
      </div>
      <div class="divider-label">VLANs this device attaches to</div>
      <div class="check-grid">${options}</div>
      <div class="field-help field-help-spaced" >Choose one VLAN for an endpoint. A firewall, router, or multihomed host can have multiple interfaces. For ESXi VM networks, document the verified port-group/trunk relationship; don't invent a host IP where none exists.</div>
      <div class="divider-label">Interface details</div>
      <div id="configInterfaces">${ifaceRows}</div>
      <div class="field">
      <label>Hosted devices / virtual machines / sessions (one per line)</label>
      <textarea name="hostedDevices" placeholder="RDS-01 · Remote Desktop server&#10;APP-VM-01 · Application VM">${escapeHtml(hosted)}</textarea>
      <div class="field-help">Legacy entries appear as simple mini-cards inside a host group. For editable VM cards with their own IP, VLAN labels and remote/session relationships, create a separate device record and select this server in the 'Contained in server / VM group' field.</div>
      </div>
      <div class="field">
      <label>Notes</label>
      <textarea name="notes" placeholder="Purpose, policy notes, confidence/verification…">${escapeHtml(d.notes)}</textarea>
      </div>`;
  }

  function physicalPortFields(prefix, device, portName) {
    const { project, vlanById, portByName, tagsForIds, portModes, escapeHtml } = getContext();
    const port = portByName(device, portName) || {};
    const accessTag = vlanById(port.accessVlanId)?.tag || '';
    return `<div class="divider-label">${prefix === 'source' ? 'Source' : 'Target'} port configuration</div>
      <div class="form-grid">
      <div class="field">
      <label>${prefix === 'source' ? 'Source' : 'Target'} interface / switch port *</label>
      <input name="${prefix}Port" required maxlength="80" value="${escapeHtml(portName || '')}" placeholder="Gi1/0/12 / Ethernet0">
      </div>
      <div class="field">
      <label>Port mode</label>
      <select name="${prefix}Mode">${portModes.map(mode => `<option value="${mode}" ${(port.mode || 'unknown') === mode ? 'selected' : ''}>${mode[0].toUpperCase() + mode.slice(1)}</option>`).join('')}</select>
      </div>
      </div>
      <div class="form-grid">
      <div class="field">
      <label>Access VLAN tag</label>
      <input name="${prefix}AccessVlanTag" inputmode="numeric" value="${escapeHtml(accessTag)}" placeholder="20">
      <div class="field-help">Used only when port mode is Access.</div>
      </div>
      <div class="field">
      <label>Allowed trunk VLAN tags</label>
      <input name="${prefix}AllowedVlanTags" value="${escapeHtml(tagsForIds(port.allowedVlanIds))}" placeholder="10, 20, 30">
      <div class="field-help">Comma-separated; only common VLANs on both trunk ends are inferred.</div>
      </div>
      </div>`;
  }
  function physicalLinkFormHtml(link = null, defaultSourceId = '') {
    const { project, deviceById, physicalPortFields, physicalMediaTypes, escapeHtml } = getContext();
    const sourceId = link?.sourceDeviceId || defaultSourceId || project.devices[0]?.id || '';
    const targetId = link?.targetDeviceId || project.devices.find(device => device.id !== sourceId)?.id || '';
    const source = deviceById(sourceId), target = deviceById(targetId);
    const sourcePort = link?.sourcePort || source?.ports?.[0]?.name || '';
    const targetPort = link?.targetPort || target?.ports?.[0]?.name || '';
    const deviceOptions = (picked, exclude = '') => project.devices.filter(device => device.id !== exclude).map(device => `<option value="${escapeHtml(device.id)}" ${device.id === picked ? 'selected' : ''}>${escapeHtml(device.hostname)} · ${escapeHtml(device.type)}</option>`).join('');
    return `<div class="info-card">
      <strong>Physical cabling drives the logical view.</strong>
      <br>Choose the device at each end, name the interface/port, and record each port's access/trunk mode. A connected access port can infer a VLAN; two trunks infer only the VLAN tags allowed at both ends. IP addresses and firewall policy are not inferred.</div>
      <div class="form-grid">
      <div class="field">
      <label>Source device *</label>
      <select name="sourceDeviceId" required>${deviceOptions(sourceId)}</select>
      </div>
      <div class="field">
      <label>Target device *</label>
      <select name="targetDeviceId" required>${deviceOptions(targetId, sourceId)}</select>
      </div>
      </div>
      <div class="physical-port-source">${physicalPortFields('source', source, link?.sourcePort || '')}</div>
      <div class="physical-port-target">${physicalPortFields('target', target, link?.targetPort || '')}</div>
      <div class="field">
      <label>Physical media *</label>
      <select name="mediaType">${physicalMediaTypes.map(type => `<option value="${escapeHtml(type)}" ${type === (link?.mediaType || 'Copper Ethernet') ? 'selected' : ''}>${escapeHtml(type)}</option>`).join('')}</select>
      </div>
      <div class="field">
      <label>Link label / purpose</label>
      <input name="label" maxlength="120" value="${escapeHtml(link?.label || '')}" placeholder="Core uplink / VLAN trunk / ESXi uplink">
      </div>
      <div class="field">
      <label>Notes</label>
      <textarea name="physicalLinkNotes" maxlength="1000" placeholder="Cable ID, patch panel, bundle, verification notes">${escapeHtml(link?.notes || '')}</textarea>
      </div>`;
  }

  function remoteConnectionFormHtml(defaultFrom = '', existing = null) {
    const { project, escapeHtml, connectionTypes } = getContext();

    const c = existing || { fromDeviceId: defaultFrom, toDeviceId: '', type: 'RDP / Remote Desktop', label: 'Remote session', protocolPort: '', connectionNotes: '' };
    const choices = project.devices.map(d => `<option value="${escapeHtml(d.id)}" ${d.id === c.fromDeviceId ? 'selected' : ''}>${escapeHtml(d.hostname)} · ${escapeHtml(d.type)}</option>`).join('');
    const selectedTargets = new Set(existing ? [existing.toDeviceId] : []);
    const targets = project.devices.filter(d => d.id !== c.fromDeviceId).map(d => `<label class="check-option">
      <input type="checkbox" name="toDeviceIds" value="${escapeHtml(d.id)}" ${selectedTargets.has(d.id) ? 'checked' : ''}>
      <span>
      <strong>${escapeHtml(d.hostname)}</strong>
      <br>
      <span class="muted">${escapeHtml(d.type)}${d.managementIp ? ' · ' + escapeHtml(d.managementIp) : ''}</span>
      </span>
      </label>`).join('');
    return `<div class="field">
      <label>Initiating / source device *</label>
      <select id="connectionFrom" name="fromDeviceId" required>${choices}</select>
      <div class="field-help">One source can be linked to several targets in one action, such as a dedicated support workstation that remotes into multiple thin clients.</div>
      </div>
      <div class="field">
      <label>Remote target devices * (select one or more)</label>
      <div class="check-grid" id="connectionTargets">${targets}</div>
      <div class="field-help">Each checked target becomes its own directional arrow, so relationships can be removed or documented individually.</div>
      </div>
      <div class="field">
      <label>Relationship type *</label>
      <select name="type">${connectionTypes.map(t => `<option value="${escapeHtml(t)}" ${t === c.type ? 'selected' : ''}>${escapeHtml(t)}</option>`).join('')}</select>
      </div>
      <div class="form-grid">
      <div class="field">
      <label>Label</label>
      <input name="label" value="${escapeHtml(c.label || '')}" placeholder="Remote support">
      </div>
      <div class="field">
      <label>Protocol / port (optional)</label>
      <input name="protocolPort" value="${escapeHtml(c.protocolPort || '')}" placeholder="TCP 3389 (verify)">
      </div>
      </div>
      <div class="field">
      <label>Notes / policy verification</label>
      <textarea name="connectionNotes" placeholder="Is the relationship intended or verified? Which policy applies?">${escapeHtml(c.notes || c.connectionNotes || '')}</textarea>
      </div>
      <div class="info-card">
      <strong>Diagram meaning</strong>
      <br>A dashed arrow represents a remote session or service relationship. It does not represent a physical cable and does not prove the firewall permits that traffic.</div>`;
  }
  return { vlanFormHtml, deviceFormHtml, physicalPortFields, physicalLinkFormHtml, remoteConnectionFormHtml };
}
