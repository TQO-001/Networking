import { svgElement as sv, addSvgText as addText, estimateTextWidth, roundedRect, diagramPalette } from './svg-utils.js';
import { isHostGroup, hostChildEntries } from './project-model.js';

const card = { width: 204, height: 132, childWidth: 142, childHeight: 72, gap: 10 };
const cableStyle = {
  'Copper Ethernet': { stroke: '#858b93', width: 2.4, dash: '' },
  'Fiber optic': { stroke: '#9a78d2', width: 3, dash: '' },
  Wireless: { stroke: '#4e9ab0', width: 2.2, dash: '3 6' },
  Console: { stroke: '#bf9850', width: 1.8, dash: '2 5' },
  'Virtual link': { stroke: '#c99a18', width: 2.2, dash: '7 5' },
  Other: { stroke: '#858b93', width: 2, dash: '5 4' },
};
function hostLayout(project, host) {
  const children = hostChildEntries(project, host).filter((entry) => entry.device);
  const cols = Math.min(3, Math.max(1, children.length));
  const rows = Math.max(1, Math.ceil(children.length / cols));
  const width = children.length ? Math.max(430, 28 + cols * card.childWidth + (cols - 1) * card.gap + 28) : card.width;
  const height = children.length ? 132 + rows * (card.childHeight + card.gap) + 18 : card.height;
  return { children, cols, rows, width, height };
}
function boundsFor(project, device) {
  const pos = device.physicalPosition || { x: 80, y: 80 };
  const group = isHostGroup(device) ? hostLayout(project, device) : null;
  return { x: pos.x, y: pos.y, width: group?.width || card.width, height: group?.height || card.height, group };
}
function center(rect) {
  return { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
}
function edgePoint(rect, toward) {
  const c = center(rect);
  const dx = toward.x - c.x;
  const dy = toward.y - c.y;
  if (Math.abs(dx) > Math.abs(dy)) return { x: dx >= 0 ? rect.x + rect.width : rect.x, y: c.y };
  return { x: c.x, y: dy >= 0 ? rect.y + rect.height : rect.y };
}
function getPort(device, portName) {
  return (device?.ports || []).find((port) => port.name === portName) || null;
}
function visibleBoundsForEndpoint(project, device, mediaType, parentBounds) {
  if (!device?.parentHostId) return parentBounds.get(device?.id);
  const parent = project.devices.find((candidate) => candidate.id === device.parentHostId);
  const parentRect = parentBounds.get(parent?.id);
  if (!parentRect) return parentBounds.get(device.id);
  if (mediaType !== 'Virtual link') return parentRect;
  return childBounds.get(device.id) || parentRect;
}
let childBounds = new Map();

export function createPhysicalRenderer(getContext) {
  return function drawPhysicalTopology() {
    const { project, selected, zoom, theme, $, select, startPhysicalDrag, updateCounts, openAddDevice, openAddPhysicalLink, deviceById } = getContext();
    const T = diagramPalette(theme);
    const mount = $('canvasMount');
    mount.innerHTML = '';
    childBounds = new Map();
    if (!project.devices.length) {
      mount.innerHTML = `<div class="canvas-empty">
      <div class="empty-icon">${getContext().icons.network}</div>
      <h2>Start with the physical network</h2>
      <p>Add the switches, servers, firewalls, endpoints and links you can verify. VLAN assignments on port configurations will generate the logical view automatically.</p>
      <div class="empty-actions">
      <button class="btn primary" id="physicalEmptyAddDevice">＋ Add first device</button>
      <button class="btn" id="physicalEmptyAddVlan">＋ Add VLAN</button>
      </div>
      </div>`;
      $('physicalEmptyAddDevice').onclick = () => openAddDevice();
      $('physicalEmptyAddVlan').onclick = () => getContext().openAddVlan();
      updateCounts();
      return;
    }

    const visibleDevices = project.devices.filter((device) => !device.parentHostId);
    const rects = new Map();
    visibleDevices.forEach((device) => rects.set(device.id, boundsFor(project, device)));
    // Register contained VM rectangles so virtual links can terminate on the actual VM inside its host group.
    visibleDevices.filter((device) => rects.get(device.id)?.group?.children.length).forEach((host) => {
      const rect = rects.get(host.id);
      const { children, cols } = rect.group;
      children.forEach((entry, index) => {
        const child = entry.device;
        const col = index % cols;
        const row = Math.floor(index / cols);
        const nested = { x: rect.x + 18 + col * (card.childWidth + card.gap), y: rect.y + 120 + row * (card.childHeight + card.gap), width: card.childWidth, height: card.childHeight };
        childBounds.set(child.id, nested);
      });
    });

    const maxRight = Math.max(1180, ...[...rects.values()].map((rect) => rect.x + rect.width + 100));
    const maxBottom = Math.max(760, ...[...rects.values()].map((rect) => rect.y + rect.height + 90));
    const width = Math.ceil(maxRight);
    const height = Math.ceil(maxBottom);
    const svg = sv('svg', { xmlns: 'http://www.w3.org/2000/svg', width: width * zoom, height: height * zoom, viewBox: `0 0 ${width} ${height}`, class: 'canvas-stage physical-stage', role: 'img', 'aria-label': 'Editable physical network topology' });
    roundedRect(svg, 0, 0, width, height, 14, { fill: T.bg });
    const grid = sv('g', { opacity: theme === 'dark' ? .24 : .5 });
    for (let x = 24; x < width; x += 32) grid.appendChild(sv('line', { x1: x, y1: 0, x2: x, y2: height, stroke: T.grid, 'stroke-width': 1 }));
    for (let y = 24; y < height; y += 32) grid.appendChild(sv('line', { x1: 0, y1: y, x2: width, y2: y, stroke: T.grid, 'stroke-width': 1 }));
    svg.appendChild(grid);

    const defs = sv('defs');
    const glow = sv('filter', { id: 'hb-physical-shadow', x: '-30%', y: '-30%', width: '160%', height: '160%' });
    glow.appendChild(sv('feDropShadow', { dx: 0, dy: 5, stdDeviation: 5, 'flood-color': '#000000', 'flood-opacity': theme === 'dark' ? .32 : .09 }));
    defs.appendChild(glow);
    svg.appendChild(defs);

    (project.physicalLinks || []).forEach((link, index) => {
      const sourceDevice = deviceById(link.sourceDeviceId);
      const targetDevice = deviceById(link.targetDeviceId);
      if (!sourceDevice || !targetDevice) return;
      const sourceRect = visibleBoundsForEndpoint(project, sourceDevice, link.mediaType, rects);
      const targetRect = visibleBoundsForEndpoint(project, targetDevice, link.mediaType, rects);
      if (!sourceRect || !targetRect) return;
      const a = edgePoint(sourceRect, center(targetRect));
      const b = edgePoint(targetRect, center(sourceRect));
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const bend = Math.min(78, Math.max(-78, ((index % 3) - 1) * 34));
      const cx1 = a.x + dx * .36 - dy / Math.max(1, Math.hypot(dx, dy)) * bend;
      const cy1 = a.y + dy * .36 + dx / Math.max(1, Math.hypot(dx, dy)) * bend;
      const cx2 = a.x + dx * .64 - dy / Math.max(1, Math.hypot(dx, dy)) * bend;
      const cy2 = a.y + dy * .64 + dx / Math.max(1, Math.hypot(dx, dy)) * bend;
      const style = cableStyle[link.mediaType] || cableStyle.Other;
      const group = sv('g', { class: `physical-link${selected?.kind === 'physicalLink' && selected.id === link.id ? ' selected' : ''}`, tabindex: 0, role: 'button', 'aria-label': `Edit link ${sourceDevice.hostname} ${link.sourcePort} to ${targetDevice.hostname} ${link.targetPort}`, 'data-link-id': link.id });
      group.appendChild(sv('path', { d: `M ${a.x} ${a.y} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${b.x} ${b.y}`, fill: 'none', stroke: T.bg, 'stroke-width': style.width + 5, opacity: .68, 'stroke-linecap': 'round', class: 'physical-link-halo' }));
      group.appendChild(sv('path', { d: `M ${a.x} ${a.y} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${b.x} ${b.y}`, fill: 'none', stroke: selected?.kind === 'physicalLink' && selected.id === link.id ? T.accent : style.stroke, 'stroke-width': style.width, 'stroke-dasharray': style.dash, 'stroke-linecap': 'round', class: 'physical-link-line' }));
      const midX = (a.x + b.x) / 2;
      const midY = (a.y + b.y) / 2 - (link.label ? 10 : 0);
      const portText = [link.sourcePort ? `${sourceDevice.hostname} · ${link.sourcePort}` : sourceDevice.hostname, link.targetPort ? `${targetDevice.hostname} · ${link.targetPort}` : targetDevice.hostname].join(' ↔ ');
      const primaryLabel = link.label || link.mediaType;
      const labelWidth = Math.min(270, Math.max(104, estimateTextWidth(primaryLabel, 9)));
      roundedRect(group, midX - labelWidth / 2, midY - 9, labelWidth, link.label ? 32 : 18, 6, { fill: T.card, stroke: selected?.kind === 'physicalLink' && selected.id === link.id ? T.accent : T.border, 'stroke-width': 1, opacity: .96 });
      addText(group, midX, midY + 2, primaryLabel.length > 34 ? `${primaryLabel.slice(0, 33)}…` : primaryLabel, 'physical-link-label', { 'text-anchor': 'middle', fill: T.text, 'font-size': 9, 'font-weight': 800 });
      if (link.label) addText(group, midX, midY + 14, portText.length > 46 ? `${portText.slice(0, 45)}…` : portText, 'physical-link-meta', { 'text-anchor': 'middle', fill: T.sub, 'font-size': 7.5 });
      group.addEventListener('click', (event) => {
        event.stopPropagation();
        select('physicalLink', link.id);
      });
      group.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          event.stopPropagation();
          select('physicalLink', link.id);
        }
      });
      svg.appendChild(group);
    });

    // Draw devices after links so the connection ends visually tuck under their icon cards.
    visibleDevices.forEach((device) => {
      const rect = rects.get(device.id);
      const x = rect.x;
      const y = rect.y;
      const selectedNow = selected?.kind === 'device' && selected.id === device.id;
      const isGroup = Boolean(rect.group?.children.length);
      const colour = selectedNow ? T.accent : '#b9a36d';
      const node = sv('g', { class: `physical-device${selectedNow ? ' selected' : ''}`, transform: `translate(${x},${y})`, tabindex: 0, role: 'button', 'aria-label': `Select ${device.hostname}`, 'data-device-id': device.id });
      roundedRect(node, 2, 6, rect.width, rect.height, 15, { fill: T.shadow, opacity: .08 });
      roundedRect(node, 0, 0, rect.width, rect.height, 15, { fill: T.card, stroke: selectedNow ? T.accent : T.border, 'stroke-width': selectedNow ? 2.4 : 1.2, filter: 'url(#hb-physical-shadow)', class: 'physical-node-shell' });
      roundedRect(node, 0, 0, rect.width, 5, 3, { fill: typeColor(device.type) });
      addText(node, 16, 29, device.hostname || 'Unnamed device', 'physical-node-name', { fill: T.text, 'font-size': 13, 'font-weight': 800 });
      addText(node, 16, 47, device.type, 'physical-node-type', { fill: T.sub, 'font-size': 9, 'font-weight': 700 });
      const ip = (device.interfaces || []).map((item) => item.ip).find(Boolean) || device.managementIp || 'IP / interface not recorded';
      addText(node, 16, isGroup ? 77 : 85, ip.length > 34 ? `${ip.slice(0, 33)}…` : ip, 'physical-node-ip', { fill: T.text, 'font-size': 10 });
      addText(node, 16, isGroup ? 92 : 105, device.model || 'Description not set', 'physical-node-meta', { fill: T.sub, 'font-size': 9 });
      const portCount = (device.ports || []).length;
      roundedRect(node, rect.width - 88, rect.height - 26, 76, 17, 8, { fill: T.lane, stroke: T.border, 'stroke-width': .7 });
      addText(node, rect.width - 50, rect.height - 14, `${portCount} port${portCount === 1 ? '' : 's'}`, 'physical-node-meta', { fill: T.sub, 'font-size': 8, 'text-anchor': 'middle' });

      if (isGroup) {
        node.appendChild(sv('line', { x1: 12, y1: 102, x2: rect.width - 12, y2: 102, stroke: T.border, 'stroke-width': 1 }));
        addText(node, 16, 113, `VIRTUAL MACHINES / WORKLOADS · ${rect.group.children.length}`, 'physical-group-kicker', { fill: T.sub, 'font-size': 8, 'font-weight': 800, 'letter-spacing': '.06em' });
        rect.group.children.forEach((entry, index) => {
          const child = entry.device;
          const childRect = childBounds.get(child.id);
          const localX = childRect.x - x;
          const localY = childRect.y - y;
          const nested = sv('g', { class: `physical-vm${selected?.kind === 'device' && selected.id === child.id ? ' selected' : ''}`, transform: `translate(${localX},${localY})`, tabindex: 0, role: 'button', 'aria-label': `Select virtual machine ${child.hostname}`, 'data-child-device-id': child.id });
          roundedRect(nested, 0, 0, childRect.width, childRect.height, 8, { fill: T.lane, stroke: selected?.kind === 'device' && selected.id === child.id ? T.accent : T.border, 'stroke-width': selected?.kind === 'device' && selected.id === child.id ? 2 : 1 });
          roundedRect(nested, 0, 0, 4, childRect.height, 2, { fill: typeColor(child.type) });
          addText(nested, 8, 21, child.hostname.length > 17 ? `${child.hostname.slice(0, 16)}…` : child.hostname, 'physical-vm-name', { fill: T.text, 'font-size': 9, 'font-weight': 800 });
          addText(nested, 8, 35, child.type.length > 18 ? `${child.type.slice(0, 17)}…` : child.type, 'physical-vm-type', { fill: T.sub, 'font-size': 7.5 });
          const childIp = (child.interfaces || []).map((item) => item.ip).find(Boolean) || child.managementIp || 'IP not set';
          addText(nested, 8, 58, childIp.length > 28 ? `${childIp.slice(0, 27)}…` : childIp, 'physical-vm-ip', { fill: T.sub, 'font-size': 7.6 });
          nested.addEventListener('click', (event) => {
            event.stopPropagation();
            select('device', child.id);
          });
          nested.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
              event.preventDefault();
              event.stopPropagation();
              select('device', child.id);
            }
          });
          nested.addEventListener('pointerdown', (event) => event.stopPropagation());
          node.appendChild(nested);
        });
      } else if (device.parentHostId) {
        addText(node, 16, 121, `Contained in ${device.parentHostId}`, 'physical-node-meta', { fill: T.sub, 'font-size': 8 });
      }
      node.addEventListener('click', (event) => {
        if (getContext().getDragState()?.moved) return;
        select('device', device.id);
      });
      node.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          select('device', device.id);
        }
      });
      node.addEventListener('pointerdown', (event) => {
        if (event.target.closest?.('.physical-vm')) return;
        startPhysicalDrag(event, device.id, node);
      });
      svg.appendChild(node);
    });

    addText(svg, 20, height - 20, 'PHYSICAL LINKS · solid = copper/fiber   dashed = wireless/virtual/console', 'physical-legend', { fill: T.sub, 'font-size': 10 });
    addText(svg, width - 20, height - 20, 'Illustrative topology · verify port media and VLAN configuration', 'physical-legend', { fill: T.sub, 'font-size': 9, 'text-anchor': 'end' });
    mount.appendChild(svg);
    updateCounts();
  };
}
function typeColor(type) {
  if (/firewall|gateway|vpn/i.test(type)) return '#c94c60';
  if (/switch/i.test(type)) return '#5287a8';
  if (/router/i.test(type)) return '#8560c5';
  if (/esxi|hypervisor|virtual machine|vmware/i.test(type)) return '#b88708';
  if (/plc|controller|io|sensor|hmi/i.test(type)) return '#a66c19';
  if (/server|historian|database|storage/i.test(type)) return '#8a7a4d';
  return '#4c8bba';
}
