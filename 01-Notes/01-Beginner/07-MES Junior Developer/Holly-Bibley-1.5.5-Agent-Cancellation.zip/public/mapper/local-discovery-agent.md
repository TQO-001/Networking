# Holly Bibley Local Discovery Agent — integrated agent and manual CLI

Holly Bibley 1.5.0 introduced an outbound-only agent connection. Version 1.5.1 adds agent activity status and job-retention/recovery hardening. Version 1.5.2 ensures that heartbeat, completion and failure requests are rejected when the job lease has expired. Version 1.5.5 aborts in-progress local probes/SNMP sessions when the agent lease is lost and stops the agent loop on a revoked token. Instead of writing JSON and uploading it manually, a paired local agent can claim discovery jobs created from the mapper, run the approved collector locally, and send a validated snapshot back for review.

This remains a discovery aid, not a guarantee of complete network documentation. A basic subnet scan sees only ICMP-responsive endpoints and available operating-system neighbour entries. Switch discovery can read interface/VLAN/LLDP information exposed by the switch's SNMPv3 agent. Keep inferred or unavailable data clearly marked.

## Requirements

- Node.js 22.12 or newer and npm on the computer running the agent.
- A reachable Holly Bibley server origin. Remote connections must use HTTPS; HTTP is accepted only for localhost development.
- The agent process must be running when you start a discovery job in the mapper.
- For switch jobs, the agent computer needs a local `.env` with a dedicated SNMPv3 `authPriv` read-only account. Those SNMP secrets remain on the agent computer and are never sent to Holly Bibley.
- Permission to discover the selected devices and networks. Production/OT scanning must follow site authorisation and safety procedures.

**Important for a separate agent computer:** the full development ZIP includes a local-only `.env` for running the Holly Bibley server and its tests. Do not carry that file over to a separate discovery computer. Remove it from the agent copy; for switch discovery, create a fresh `.env` containing only the `HB_SNMPV3_*` and `HB_SNMP_TIMEOUT_MS` values shown below. The agent does not need `DATABASE_URL`, the PostgreSQL password, SMTP settings or the server's app-origin settings.

## 1. Update and migrate Holly Bibley

Deploy the 1.5.2 source, install dependencies, and apply the schema. The normal local development launcher applies migrations automatically; for an explicit deployment migration run:

```powershell
npm install
npm run db:migrate
```

Restart the API/web application after updating.

## 2. Generate a pairing code

1. Sign in and open the topology mapper.
2. Select **Discover network**.
3. Under **Local discovery agent**, select **Generate pairing code**.
4. Copy the one-time code. It expires after 10 minutes and can be used once.

Pairing codes are stored hashed in PostgreSQL. The agent token is returned only once, saved locally in a user-specific config file, and stored on the server as a hash. Use **Revoke selected agent** to invalidate a paired token and cancel its queued/running jobs. The agent checks its lease before starting, renews it every five seconds while scanning, stops in-flight ping/SNMP work when the server rejects the lease, and exits its poll loop if its token is revoked.

## 3. Pair and run the agent

On the computer that can reach the target network, obtain the Holly Bibley source package and install its dependencies. Do **not** copy the server's private `.env` file or its database credentials onto a discovery computer. The agent does not need `DATABASE_URL` or the PostgreSQL password.

From the extracted project directory, run:

```powershell
npm install
npm run discovery:agent -- --server https://holly.example.com --name "OT engineering laptop"
```

Replace the URL with your real HTTPS Holly Bibley origin. When prompted, paste the pairing code from the mapper. The agent stores its token in a per-user configuration file (Windows: `%APPDATA%\HollyBibley\discovery-agent.json`; macOS: `~/Library/Application Support/HollyBibley/discovery-agent.json`; Linux: `~/.config/holly-bibley/discovery-agent.json`). On non-Windows platforms the file is restricted to owner read/write. Treat it as a credential and do not share it.

For development where the web app and agent run on the **same computer**, use `http://127.0.0.1:5173` as the server URL. Do not use clear-text HTTP over a shared LAN. For an agent on a separate computer, deploy/use HTTPS.

Keep the process running. It makes outbound requests to claim jobs every few seconds and does not open a listening port. Press Ctrl+C to stop it. After pairing, rerun the same command without the code to reuse its saved token.

## 4. Run discovery from the mapper

1. Refresh the paired-agent list and choose the connected agent.
2. Choose one discovery type.

### Local subnet

Enter a private IPv4 CIDR such as `192.168.10.0/24`. The worker verifies that the scope is fully inside an RFC 1918 range and is contained within one of the agent computer's directly assigned private interface networks. The run is limited to 256 IPv4 addresses and sends one rate-limited ICMP echo request per usable host, then reads the local OS neighbour/ARP cache.

The scanner intentionally refuses routed/remote subnets. It does not port-scan, fingerprint arbitrary services, or guess switch-port/VLAN information.

### Switches

Enter explicit management IPv4 addresses, separated by commas, spaces, or newlines; at most 64 private IPv4 targets are accepted. Configure these variables in the **agent computer's local `.env`**:

```dotenv
HB_SNMPV3_USERNAME=holly-readonly
HB_SNMPV3_AUTH_PASSPHRASE=your-local-auth-passphrase
HB_SNMPV3_PRIV_PASSPHRASE=your-local-privacy-passphrase
HB_SNMPV3_AUTH_PROTOCOL=sha256
HB_SNMPV3_PRIV_PROTOCOL=aes
HB_SNMP_TIMEOUT_MS=1500
```

Use your own secrets, never the example strings. Configure a matching read-only SNMPv3 account and restrict its access on the switch. The collector uses `authPriv`, uses read-only Get/Table/Subtree requests, and does not issue SNMP Set. Secret values are not included in job requests, logs, or snapshots.

The collector reads standard interface, Q-BRIDGE-MIB VLAN membership, IP-interface and LLDP data where devices expose those objects. Port access/trunk classifications may still be inferred, and vendor implementations vary. If no SNMP credentials are set, the job fails with an actionable error instead of silently falling back to SNMPv1/v2c.

3. Start discovery and monitor the job status. The job result will open in a **Review discovery results** preview if the mapper remains open.
4. Inspect the warning list, then choose **Save as new diagram** first. Replace an existing diagram only after exporting a backup and confirming the result.

## Agent security and job lifecycle

- The browser must be signed in to pair agents, create jobs, list agents, view results, and revoke agents. SQL predicates scope these operations to the owning user.
- The pairing code expires after 10 minutes, is one-time-use, and is stored only as a hash.
- Agent tokens are random bearer secrets. Only hashes are stored by the server; the raw token is returned once during pairing.
- The local agent uses an authenticated HTTPS outbound connection, validates every queued job locally, and accepts only two fixed job types. It does not execute remote shell commands or accept arbitrary target URLs.
- Subnet jobs must be private and directly attached to an agent interface. Switch jobs require explicit private IPv4 targets.
- Jobs and result snapshots expire after 24 hours; an hourly cleanup removes expired jobs and old pairing records. Revoking an agent invalidates its token and cancels its active jobs.
- Discovery data contains sensitive network inventory. Apply the same retention, access-control, backup and incident-handling policies used for other infrastructure documentation.

## Manual CLI alternatives

You can still generate a snapshot locally without pairing an agent.

List local IPv4 interfaces without scanning:

```powershell
node scripts/discover-network.js --list
```

Run a separately scoped subnet discovery and write JSON:

```powershell
node scripts/discover-network.js --cidr 192.168.10.0/24 --out snapshot.json
```

Run switch discovery against explicit management addresses:

```powershell
npm run discover:switches -- --targets 192.168.10.2,192.168.10.3 --out switches.json
```

Import a JSON file through **Discover network → Import snapshot JSON**.

## Troubleshooting

- **Pairing code rejected:** generate another code and enter it before the 10-minute expiry. Do not reuse a code after a successful pairing.
- **Agent does not appear:** confirm the process is running, the server URL points to the correct Holly Bibley origin, and outbound HTTPS access is allowed. Refresh the paired-agent list.
- **Agent has not seen jobs:** verify the agent isn't offline and that the selected record is the intended machine.
- **Subnet job reports no attached interface:** run `node scripts/discover-network.js --list` on the agent computer and choose a directly connected private subnet. Routed subnet discovery is intentionally not supported by this agent.
- **Switch job fails:** check reachability of UDP/161 from the agent, the SNMPv3 username/passphrases and algorithms, the device ACL, and the configured read-only MIB view. Check the agent terminal for the sanitised error.
- **Missing VLANs or LLDP links:** the switch may not expose the standard MIBs, LLDP may be disabled, or the read-only view may exclude those objects. Do not treat missing data as proof that a VLAN or link does not exist.
- **Job stuck running:** check that the agent process is still connected. Job leases expire after two minutes and can be reclaimed when the agent reconnects; an older worker's lease token cannot complete the reclaimed job.
- **Snapshot rejected:** check the agent/server versions match and inspect the agent terminal. Results are limited to 2.5 MB and the supported snapshot schema.

## OT/production note

Even a rate-limited ICMP scan creates active traffic, and SNMP polling still contacts managed devices. Use an approved lab first; obtain explicit authorisation and follow the site's change and safety requirements before scanning production OT networks. Where active discovery is prohibited, prefer an approved passive sensor or an existing inventory platform such as LibreNMS.
