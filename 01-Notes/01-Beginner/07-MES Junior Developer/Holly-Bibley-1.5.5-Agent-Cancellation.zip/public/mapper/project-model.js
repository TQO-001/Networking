import { typeLabels, connectionTypes, switchTypes } from './device-catalog.js';

const uid = (prefix) => `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-3)}`;
export const physicalMediaTypes = ['Copper Ethernet', 'Fiber optic', 'Wireless', 'Console', 'Virtual link', 'Other'];
export const portModes = ['unknown', 'access', 'trunk', 'routed', 'virtual'];
export const defaultPalette = ['#c99a18', '#8f79b8', '#3f89bb', '#3d967d', '#d18a32', '#c45a6b', '#7d91a9'];

export function isHostGroup(device) {
  return Boolean(device && ['ESXi host', 'Hypervisor', 'Server'].includes(device.type));
}

export function hostChildEntries(project, host) {
  const children = project.devices.filter((device) => device.parentHostId === host.id);
  const known = new Set(children.map((device) => device.hostname.toLowerCase()));
  const legacy = (host.hostedDevices || []).filter((entry) => {
    const key = String(entry).split(/[·|–—]/)[0].trim().toLowerCase();
    return key && !known.has(key);
  }).map((label, index) => ({ id: `legacy-${host.id}-${index}`, legacy: true, label: String(label) }));
  return [...children.map((device) => ({ id: device.id, device, legacy: false, label: device.hostname })), ...legacy];
}

export function blankProject(projectName = 'Untitled network topology') {
  return {
    schema: 'holly-bibley-project', version: 6, projectName,
    updatedAt: new Date().toISOString(), vlans: [], devices: [], physicalLinks: [], connections: [], notes: '', discovery: null,
  };
}

function normalizePort(port, vlanIdSet) {
  const mode = portModes.includes(port?.mode) ? port.mode : 'unknown';
  const allowedVlanIds = Array.isArray(port?.allowedVlanIds)
    ? [...new Set(port.allowedVlanIds.map(String).filter((id) => vlanIdSet.has(id)))]
    : [];
  const accessVlanId = vlanIdSet.has(String(port?.accessVlanId || '')) ? String(port.accessVlanId) : '';
  return {
    name: String(port?.name || '').trim().slice(0, 80), mode,
    accessVlanId: mode === 'access' ? accessVlanId : '',
    allowedVlanIds: mode === 'trunk' ? allowedVlanIds : [],
    notes: String(port?.notes || '').slice(0, 500),
    status: ['up', 'down', 'unknown'].includes(port?.status) ? port.status : 'unknown',
    speed: String(port?.speed || '').slice(0, 40),
    discoveryConfidence: ['confirmed', 'inferred', 'unknown'].includes(port?.discoveryConfidence) ? port.discoveryConfidence : 'unknown',
  };
}

export function normalizeProject(input) {
  if (!input || typeof input !== 'object' || !Array.isArray(input.vlans) || !Array.isArray(input.devices)) {
    throw new Error('This file does not look like a Holly Bibley project.');
  }
  const vlanIds = new Set();
  const vlans = input.vlans.map((vlan, index) => {
    const id = String(vlan.id || uid('vlan'));
    if (vlanIds.has(id)) throw new Error('Duplicate VLAN IDs are not allowed.');
    vlanIds.add(id);
    return {
      id, tag: String(vlan.tag ?? (index + 1)), name: String(vlan.name || `VLAN ${index + 1}`),
      subnet: String(vlan.subnet || ''), gateway: String(vlan.gateway || ''), notes: String(vlan.notes || ''),
      lineStyle: ['straight', 'curve', 'deep-curve'].includes(vlan.lineStyle) ? vlan.lineStyle : 'straight',
      color: /^#[0-9a-f]{6}$/i.test(vlan.color || '') ? vlan.color : defaultPalette[index % defaultPalette.length],
    };
  });

  const deviceIds = new Set();
  const devices = input.devices.map((device, index) => {
    const id = String(device.id || uid('dev'));
    if (deviceIds.has(id)) throw new Error('Duplicate device IDs are not allowed.');
    deviceIds.add(id);
    const rawHosted = Array.isArray(device.hostedDevices)
      ? device.hostedDevices
      : (typeof device.hostedDevices === 'string' ? device.hostedDevices.split('\n') : []);
    const fallbackX = 120 + (index % 4) * 250;
    const fallbackY = 110 + Math.floor(index / 4) * 220;
    const rawPosition = device.physicalPosition || {};
    return {
      id,
      type: typeLabels[device.type] ? device.type : 'Other',
      hostname: String(device.hostname || `DEVICE-${index + 1}`).slice(0, 80),
      model: String(device.model || '').slice(0, 100),
      managementIp: String(device.managementIp || '').slice(0, 120),
      macAddress: String(device.macAddress || '').slice(0, 80),
      discoveryStatus: device.discoveryStatus === 'discovered' ? 'discovered' : 'manual',
      discoveryConfidence: ['confirmed', 'inferred', 'unknown'].includes(device.discoveryConfidence) ? device.discoveryConfidence : 'unknown',
      lastSeenAt: String(device.lastSeenAt || '').slice(0, 40),
      notes: String(device.notes || '').slice(0, 5000),
      x: Number.isFinite(Number(device.x)) ? Math.max(0, Number(device.x)) : fallbackX + 200,
      displayMode: device.displayMode === 'per-vlan' ? 'per-vlan' : 'single',
      parentHostId: String(device.parentHostId || ''),
      hostedDevices: rawHosted.map((entry) => String(entry).trim()).filter(Boolean).slice(0, 12),
      physicalPosition: {
        x: Number.isFinite(Number(rawPosition.x)) ? Math.max(20, Number(rawPosition.x)) : fallbackX,
        y: Number.isFinite(Number(rawPosition.y)) ? Math.max(20, Number(rawPosition.y)) : fallbackY,
      },
      ports: Array.isArray(device.ports)
        ? device.ports.map((port) => normalizePort(port, vlanIds)).filter((port) => port.name).slice(0, 300)
        : [],
      interfaces: Array.isArray(device.interfaces)
        ? device.interfaces.filter((item) => !String(item.vlanId || '') || vlanIds.has(String(item.vlanId))).map((item) => ({
          vlanId: String(item.vlanId || ''), name: String(item.name || '').slice(0, 80), ip: String(item.ip || '').slice(0, 120), peerPort: String(item.peerPort || '').slice(0, 120),
          status: ['up', 'down', 'unknown'].includes(item.status) ? item.status : 'unknown',
          macAddress: String(item.macAddress || '').slice(0, 80),
          discoveryConfidence: ['confirmed', 'inferred', 'unknown'].includes(item.discoveryConfidence) ? item.discoveryConfidence : 'unknown',
        })).slice(0, 300)
        : [],
    };
  });

  // Old projects stored a plain text list of guests. Migrate any exact hostname matches into host-group membership.
  devices.forEach((child) => {
    if (child.parentHostId) return;
    for (const host of devices) {
      if (host.id === child.id || !isHostGroup(host)) continue;
      const match = (host.hostedDevices || []).some((entry) => String(entry).split(/[·|–—]/)[0].trim().toLowerCase() === child.hostname.toLowerCase());
      if (match) {
        child.parentHostId = host.id;
        break;
      }
    }
  });
  devices.forEach((device) => {
    if (!device.parentHostId) return;
    const parent = devices.find((candidate) => candidate.id === device.parentHostId);
    if (!parent || !isHostGroup(parent) || parent.id === device.id || isHostGroup(device)) device.parentHostId = '';
  });

  const deviceIdSet = new Set(devices.map((device) => device.id));
  const linkIds = new Set();
  const physicalLinks = (Array.isArray(input.physicalLinks) ? input.physicalLinks : []).filter((link) =>
    link && deviceIdSet.has(String(link.sourceDeviceId)) && deviceIdSet.has(String(link.targetDeviceId)) && String(link.sourceDeviceId) !== String(link.targetDeviceId),
  ).map((link) => {
    const id = String(link.id || uid('plink'));
    if (linkIds.has(id)) return null;
    linkIds.add(id);
    return {
      id, sourceDeviceId: String(link.sourceDeviceId), sourcePort: String(link.sourcePort || '').trim().slice(0, 80),
      targetDeviceId: String(link.targetDeviceId), targetPort: String(link.targetPort || '').trim().slice(0, 80),
      mediaType: physicalMediaTypes.includes(link.mediaType) ? link.mediaType : 'Copper Ethernet',
      label: String(link.label || '').slice(0, 120), notes: String(link.notes || '').slice(0, 1000),
      discoveryConfidence: ['confirmed', 'inferred', 'unknown'].includes(link.discoveryConfidence) ? link.discoveryConfidence : 'unknown',
      discoverySource: String(link.discoverySource || '').slice(0, 100),
      observedAt: String(link.observedAt || '').slice(0, 40),
    };
  }).filter(Boolean);

  // Version 6 retains discovered interface details even when no VLAN association is known. Older projects migrate forward without losing topology data.
  const connectionIds = new Set();
  const connections = (Array.isArray(input.connections) ? input.connections : []).filter((connection) =>
    connection && deviceIdSet.has(String(connection.fromDeviceId)) && deviceIdSet.has(String(connection.toDeviceId)) && String(connection.fromDeviceId) !== String(connection.toDeviceId),
  ).map((connection) => {
    const id = String(connection.id || uid('conn'));
    if (connectionIds.has(id)) return null;
    connectionIds.add(id);
    return {
      id, fromDeviceId: String(connection.fromDeviceId), toDeviceId: String(connection.toDeviceId),
      type: connectionTypes.includes(connection.type) ? connection.type : 'Custom relationship',
      label: String(connection.label || ''), protocolPort: String(connection.protocolPort || ''), notes: String(connection.notes || ''),
    };
  }).filter(Boolean);

  const rawDiscovery = input.discovery && typeof input.discovery === 'object' ? input.discovery : null;
  const discovery = rawDiscovery ? {
    source: {
      name: String(rawDiscovery.source?.name || 'Unknown discovery source').slice(0, 120),
      adapter: String(rawDiscovery.source?.adapter || 'unknown').slice(0, 80),
    },
    collectedAt: String(rawDiscovery.collectedAt || '').slice(0, 40),
    importedAt: String(rawDiscovery.importedAt || '').slice(0, 40),
    scope: {
      cidr: String(rawDiscovery.scope?.cidr || '').slice(0, 80),
      label: String(rawDiscovery.scope?.label || '').slice(0, 120),
    },
    warnings: Array.isArray(rawDiscovery.warnings) ? rawDiscovery.warnings.map((warning) => String(warning).slice(0, 500)).slice(0, 100) : [],
  } : null;

  return {
    schema: 'holly-bibley-project', version: 6, projectName: String(input.projectName || 'Imported project'),
    updatedAt: new Date().toISOString(), vlans, devices, physicalLinks, connections, notes: String(input.notes || '').slice(0, 20000), discovery,
  };
}

function hasVlanInterface(device, vlanId) {
  return (device.interfaces || []).some((item) => item.vlanId === vlanId);
}
function portOf(device, name) {
  return (device?.ports || []).find((port) => port.name === name) || null;
}

/**
 * Build the logical view from the canonical physical model without writing inferred data back to it.
 * Explicit IP/interface configuration wins; inferred Layer 2 membership never invents IP addresses.
 */
export function deriveLogicalProject(canonical) {
  const derived = structuredClone(canonical);
  const deviceMap = new Map(derived.devices.map((device) => [device.id, device]));
  const addMembership = (deviceId, vlanId, interfaceName, peerPort, reason) => {
    const device = deviceMap.get(deviceId);
    if (!device || !derived.vlans.some((vlan) => vlan.id === vlanId) || hasVlanInterface(device, vlanId)) return;
    if (!device._inferredInterfaces) device._inferredInterfaces = new Set();
    if (device._inferredInterfaces.has(vlanId)) return;
    device._inferredInterfaces.add(vlanId);
    device.interfaces.push({ vlanId, name: interfaceName || reason || 'Physical port', ip: '', peerPort: peerPort || '', inferred: true });
  };

  for (const link of derived.physicalLinks || []) {
    const source = deviceMap.get(link.sourceDeviceId);
    const target = deviceMap.get(link.targetDeviceId);
    if (!source || !target) continue;
    const sourcePort = portOf(source, link.sourcePort);
    const targetPort = portOf(target, link.targetPort);
    const sourceLabel = link.sourcePort ? `${source.hostname} ${link.sourcePort}` : source.hostname;
    const targetLabel = link.targetPort ? `${target.hostname} ${link.targetPort}` : target.hostname;

    // An access VLAN configured on one side establishes the attached Layer 2 segment for both endpoints,
    // unless the other end explicitly states a contradictory access assignment.
    const accessPorts = [
      { own: sourcePort, ownDevice: source, otherPort: targetPort, otherDevice: target, ownPeer: targetLabel, otherPeer: sourceLabel },
      { own: targetPort, ownDevice: target, otherPort: sourcePort, otherDevice: source, ownPeer: sourceLabel, otherPeer: targetLabel },
    ];
    for (const item of accessPorts) {
      if (item.own?.mode !== 'access' || !item.own.accessVlanId) continue;
      const otherMode = item.otherPort?.mode || 'unknown';
      // A routed port is Layer 3; a trunk needs explicit trunk-to-trunk semantics. The native VLAN
      // is not modeled yet, so an access-to-trunk mismatch is deliberately left unresolved.
      if (otherMode === 'routed' || otherMode === 'virtual' || otherMode === 'trunk') continue;
      if (otherMode === 'access' && item.otherPort.accessVlanId !== item.own.accessVlanId) continue;
      addMembership(item.ownDevice.id, item.own.accessVlanId, item.own.name, item.ownPeer, 'Access port');
      addMembership(item.otherDevice.id, item.own.accessVlanId, item.otherPort?.name || '', item.otherPeer, 'Connected access VLAN');
    }

    // Trunks pass only the VLANs explicitly allowed at both ends. Unknown or empty lists imply no inference.
    if (sourcePort?.mode === 'trunk' && targetPort?.mode === 'trunk' && sourcePort.allowedVlanIds.length && targetPort.allowedVlanIds.length) {
      const targetAllowed = new Set(targetPort.allowedVlanIds);
      const commonVlanIds = sourcePort.allowedVlanIds.filter((vlanId) => targetAllowed.has(vlanId));
      for (const vlanId of commonVlanIds) {
        addMembership(source.id, vlanId, sourcePort.name, targetLabel, 'Trunk port');
        addMembership(target.id, vlanId, targetPort.name, sourceLabel, 'Trunk port');
      }
    }
  }

  // Internal helper metadata is never persisted or exported.
  derived.devices.forEach((device) => {
    delete device._inferredInterfaces;
  });
  return derived;
}

export function createDemoProject() {
  const vlan10 = 'vlan-10';
  const vlan20 = 'vlan-20';
  const vlan30 = 'vlan-30';
  const vlan40 = 'vlan-40';
  const vlans = [
    { id: vlan10, tag: '10', name: 'SERVER-MGMT', subnet: '10.20.10.0/24', gateway: '10.20.10.1', notes: 'Example management subnet.', color: '#c99a18', lineStyle: 'curve' },
    { id: vlan20, tag: '20', name: 'OT-CONTROL', subnet: '10.20.20.0/24', gateway: '10.20.20.1', notes: 'Example control network.', color: '#b88708', lineStyle: 'straight' },
    { id: vlan30, tag: '30', name: 'OT-SUPERVISORY', subnet: '10.20.30.0/24', gateway: '10.20.30.1', notes: 'Example supervisory network.', color: '#8f79b8', lineStyle: 'deep-curve' },
    { id: vlan40, tag: '40', name: 'OT-DMZ', subnet: '10.20.40.0/24', gateway: '10.20.40.1', notes: 'Example DMZ; validate actual zoning and rules.', color: '#3f89bb', lineStyle: 'straight' },
  ];
  const device = (id, type, hostname, model, x, y, options = {}) => ({
    id, type, hostname, model, managementIp: options.managementIp || '', notes: options.notes || '',
    x: x + 110, displayMode: 'single', parentHostId: options.parentHostId || '', hostedDevices: [],
    physicalPosition: { x, y }, ports: options.ports || [], interfaces: options.interfaces || [],
  });
  const devices = [
    device('dev-core', 'Core switch', 'SW-CORE-01', 'Core / distribution', 610, 70, {
      ports: [
        { name: 'Gi1/0/1', mode: 'trunk', allowedVlanIds: [vlan10, vlan20, vlan30, vlan40] },
        { name: 'Gi1/0/2', mode: 'trunk', allowedVlanIds: [vlan10, vlan20, vlan30] },
      ]
    }),
    device('dev-ot-switch', 'Industrial switch', 'SW-OT-01', 'OT access switch', 180, 310, {
      ports: [
        { name: 'Gi1/0/1', mode: 'trunk', allowedVlanIds: [vlan20, vlan30] },
        { name: 'Gi1/0/5', mode: 'access', accessVlanId: vlan20 }, { name: 'Gi1/0/12', mode: 'access', accessVlanId: vlan20 },
        { name: 'Gi1/0/18', mode: 'access', accessVlanId: vlan20 }, { name: 'Gi1/0/24', mode: 'access', accessVlanId: vlan20 }, { name: 'Gi1/0/26', mode: 'access', accessVlanId: vlan20 },
      ]
    }),
    device('dev-srv-switch', 'Switch', 'SW-SRV-01', 'Server access / virtualization uplinks', 1080, 310, {
      ports: [
        { name: 'Gi1/0/1', mode: 'trunk', allowedVlanIds: [vlan10, vlan30] }, { name: 'Gi1/0/20', mode: 'trunk', allowedVlanIds: [vlan10, vlan20, vlan30] },
        { name: 'Gi1/0/10', mode: 'access', accessVlanId: vlan30 },
      ]
    }),
    device('dev-esxi', 'ESXi host', 'ESXI-OT-01', 'VMware ESXi host', 760, 600, {
      managementIp: '10.20.10.12', ports: [
        { name: 'vmnic0', mode: 'trunk', allowedVlanIds: [vlan10, vlan20, vlan30] },
      ], interfaces: [{ vlanId: vlan10, name: 'vmk0', ip: '10.20.10.12/24', peerPort: 'SW-SRV-01 Gi1/0/20' }]
    }),
    device('dev-plc', 'PLC', 'PLC-01', 'Control PLC', 30, 100, { managementIp: '10.20.20.21', ports: [{ name: 'Ethernet1', mode: 'unknown' }] }),
    device('dev-eng', 'Workstation', 'ENG-WS-01', 'Engineering workstation', 35, 515, { managementIp: '10.20.20.31', ports: [{ name: 'Ethernet', mode: 'unknown' }] }),
    device('dev-jump', 'Jump workstation', 'OT-JUMP-01', 'Dedicated remote support workstation', 360, 535, { managementIp: '10.20.20.40', ports: [{ name: 'Ethernet', mode: 'unknown' }] }),
    device('dev-tc1', 'Thin client', 'TC-OT-01', 'Operator thin client', 20, 700, { managementIp: '10.20.20.51', ports: [{ name: 'Ethernet0', mode: 'unknown' }] }),
    device('dev-tc2', 'Thin client', 'TC-OT-02', 'Operator thin client', 250, 700, { managementIp: '10.20.20.52', ports: [{ name: 'Ethernet0', mode: 'unknown' }] }),
    device('dev-scada', 'Server', 'SCADA-01', 'SCADA server', 1390, 100, { managementIp: '10.20.30.10', ports: [{ name: 'Ethernet0', mode: 'unknown' }] }),
    device('dev-fw', 'Firewall', 'FW-OT-01', 'Virtual inter-VLAN security gateway', 0, 0, {
      parentHostId: 'dev-esxi', interfaces: [
        { vlanId: vlan20, name: 'vNIC1 / OT-Control', ip: '10.20.20.1/24', peerPort: 'ESXi distributed switch / VLAN 20' },
        { vlanId: vlan30, name: 'vNIC2 / OT-Supervisory', ip: '10.20.30.1/24', peerPort: 'ESXi distributed switch / VLAN 30' },
      ]
    }),
    device('dev-rds', 'Terminal server / RDS', 'RDS-01', 'Remote desktop session host VM', 0, 0, { parentHostId: 'dev-esxi', managementIp: '10.20.30.11', interfaces: [{ vlanId: vlan30, name: 'vNIC0', ip: '10.20.30.11/24', peerPort: 'OT-VMs port group' }] }),
    device('dev-appvm', 'Virtual machine', 'APP-VM-01', 'Application VM', 0, 0, { parentHostId: 'dev-esxi', managementIp: '10.20.30.12', interfaces: [{ vlanId: vlan30, name: 'vNIC0', ip: '10.20.30.12/24', peerPort: 'OT-VMs port group' }] }),
    device('dev-hmi', 'HMI', 'HMI-VM-01', 'HMI / SCADA virtual machine', 0, 0, { parentHostId: 'dev-esxi', managementIp: '10.20.30.13', interfaces: [{ vlanId: vlan30, name: 'vNIC0', ip: '10.20.30.13/24', peerPort: 'OT-VMs port group' }] }),
  ];
  const link = (id, sourceDeviceId, sourcePort, targetDeviceId, targetPort, mediaType = 'Copper Ethernet', label = '') => ({ id, sourceDeviceId, sourcePort, targetDeviceId, targetPort, mediaType, label, notes: '' });
  const physicalLinks = [
    link('phy-core-ot', 'dev-core', 'Gi1/0/2', 'dev-ot-switch', 'Gi1/0/1', 'Fiber optic', 'OT VLAN trunk'),
    link('phy-core-srv', 'dev-core', 'Gi1/0/1', 'dev-srv-switch', 'Gi1/0/1', 'Fiber optic', 'Server uplink trunk'),
    link('phy-ot-plc', 'dev-ot-switch', 'Gi1/0/5', 'dev-plc', 'Ethernet1'),
    link('phy-ot-eng', 'dev-ot-switch', 'Gi1/0/12', 'dev-eng', 'Ethernet'),
    link('phy-ot-jump', 'dev-ot-switch', 'Gi1/0/18', 'dev-jump', 'Ethernet'),
    link('phy-ot-tc1', 'dev-ot-switch', 'Gi1/0/24', 'dev-tc1', 'Ethernet0'),
    link('phy-ot-tc2', 'dev-ot-switch', 'Gi1/0/26', 'dev-tc2', 'Ethernet0'),
    link('phy-srv-esxi', 'dev-srv-switch', 'Gi1/0/20', 'dev-esxi', 'vmnic0', 'Fiber optic', 'ESXi uplink trunk'),
    link('phy-srv-scada', 'dev-srv-switch', 'Gi1/0/10', 'dev-scada', 'Ethernet0'),
  ];
  return normalizeProject({
    schema: 'holly-bibley-project', version: 6, projectName: 'OT Network — Physical-first example',
    vlans, devices, physicalLinks,
    connections: [
      { id: 'conn-jump-tc1', fromDeviceId: 'dev-jump', toDeviceId: 'dev-tc1', type: 'RDP / Remote Desktop', label: 'Remote support', protocolPort: 'TCP 3389 (example)' },
      { id: 'conn-jump-tc2', fromDeviceId: 'dev-jump', toDeviceId: 'dev-tc2', type: 'RDP / Remote Desktop', label: 'Remote support', protocolPort: 'TCP 3389 (example)' },
      { id: 'conn-tc1-rds', fromDeviceId: 'dev-tc1', toDeviceId: 'dev-rds', type: 'RDP / Remote Desktop', label: 'Operator session', protocolPort: 'TCP 3389 (example)' },
      { id: 'conn-tc2-rds', fromDeviceId: 'dev-tc2', toDeviceId: 'dev-rds', type: 'RDP / Remote Desktop', label: 'Operator session', protocolPort: 'TCP 3389 (example)' },
    ], notes: 'Illustrative topology only. Replace sample addresses, ports, VLAN membership and firewall policy with verified information.',
  });
}
