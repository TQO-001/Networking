# Mapper code map

The mapper has one canonical project document. Physical devices, port configurations and physical links are stored in that document. The logical renderer receives a derived, read-only view from `project-model.js`; do not store inferred VLAN membership back into the canonical data.

## Where to make changes

| If you are changing… | Edit this module |
|---|---|
| Project format, migration, physical-to-logical inference | `project-model.js` |
| Device roles, labels, palette and connection types | `device-catalog.js` |
| Physical cable geometry and device placement | `physical-renderer.js` |
| VLAN lanes, interface labels and remote-session arrows | `logical-renderer.js` |
| Add/edit dialog content | `forms.js` |
| Sidebar and property inspector | `inspector-views.js` |
| JSON/SVG/PNG export | `exports.js` |
| Small application chrome icons | `ui-icons.js` |
| SVG helpers and diagram theme palette | `svg-utils.js` |
| Button handlers, selection, drag state and account persistence | `../mapper-app.js` |

## Auto-derived logical topology rules

- Access VLANs infer endpoint membership only when the peer port does not conflict.
- A trunk only carries inferred VLANs that are allowed on the relevant port; trunk-to-trunk inference uses the intersection of both allowed lists.
- Routed interfaces do not infer Layer 2 VLAN membership.
- Explicit interface IPs/gateway information are preserved; routes, firewall policy, and missing IPs are never guessed.
- VM containment is independent from network connectivity; a virtual firewall can remain inside its ESXi host group while its interfaces connect to logical VLAN lanes.

## Validate changes

Run `npm run check:mapper` for syntax checks and the dependency-free topology model tests. Run `npm run format` after edits. Run `npm run check` to include the Vite production build once npm dependencies are installed.

## Device presentation

Physical and logical diagrams use text-first device cards with role-colored accent strips. Vendor device artwork is not loaded from external URLs; small utility glyphs remain in the editor chrome only. This keeps diagrams visually quieter, makes labels easier to scan, and avoids external image dependencies.
