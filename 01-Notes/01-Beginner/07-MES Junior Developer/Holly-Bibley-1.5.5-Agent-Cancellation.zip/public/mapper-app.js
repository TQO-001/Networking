import { typeLabels, typeColors, connectionTypes, perVlanTypes, switchTypes, routedDeviceTypes } from './mapper/device-catalog.js';
import { blankProject, normalizeProject, createDemoProject, deriveLogicalProject, isHostGroup, hostChildEntries as modelHostChildEntries, physicalMediaTypes, portModes, defaultPalette } from './mapper/project-model.js';
import { discoverySnapshotToProject } from './mapper/discovery-import.js';
import { createLogicalRenderer } from './mapper/logical-renderer.js';
import { createPhysicalRenderer } from './mapper/physical-renderer.js';
import { escapeHtml, svgElement as sv, addSvgText as addText, estimateTextWidth as estimateWidth, roundedRect, diagramPalette } from './mapper/svg-utils.js';
import { createMapperForms } from './mapper/forms.js';
import { createInspectorRenderer, createSidebarRenderer } from './mapper/inspector-views.js';
import { createExportActions } from './mapper/exports.js';
import { icons } from './mapper/ui-icons.js';

(() => {
  'use strict';
  const THEME_KEY = 'holly-bibley-theme-v1';
  let serverProjectId = new URLSearchParams(location.search).get('projectId');
  let serverProjectRevision = 1;
  let saveInFlight = false;
  let saveAgain = false;
  let dirtyVersion = 0;
  const $ = (id) => document.getElementById(id);
  const uid = (prefix) => `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-3)}`;
  let project, selected = null, zoom = 1, modalMode = null, toastTimer = null, saveTimer = null, dragState = null, theme = 'light', viewMode = 'physical';
  const forms = createMapperForms(() => ({ project, vlanById, deviceById, portByName, tagsForIds, escapeHtml, isHostGroup, typeLabels, portModes, physicalMediaTypes, connectionTypes }));
  function vlanById(id) {
    return project.vlans.find(v => v.id === id);
  }
  function deviceById(id) {
    return project.devices.find(d => d.id === id);
  }
  function selectedItem() {
    if (selected?.kind === 'vlan') return vlanById(selected.id);
    if (selected?.kind === 'device') return deviceById(selected.id);
    if (selected?.kind === 'physicalLink') return (project.physicalLinks || []).find(link => link.id === selected.id) || null;
    return null;
  }
  function markDirty() {
    dirtyVersion++;
    $('saveStatus').textContent = 'Unsaved changes…';
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => saveCloud(), 650);
  }
  async function saveCloud() {
    if (saveInFlight) {
      saveAgain = true;
      return;
    } saveInFlight = true;
    try {
      do {
        saveAgain = false;
        const version = dirtyVersion;
        project.updatedAt = new Date().toISOString();
        project.schema = 'holly-bibley-project';
        project.version = 6;
        project.projectName = $('projectName').value.trim() || 'Untitled network topology';
        const documentSnapshot = JSON.parse(JSON.stringify(project));
        let response;
        if (serverProjectId) {
          response = await fetch(`/api/projects/${encodeURIComponent(serverProjectId)}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: JSON.stringify({ document: documentSnapshot, expectedRevision: serverProjectRevision }) });
        } else {
          response = await fetch('/api/projects', { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: JSON.stringify({ title: documentSnapshot.projectName, document: documentSnapshot }) });
        } const data = await response.json().catch(() => ({}));
        if (response.status === 401) {
          location.replace('/login');
          return;
        } if (response.status === 409) {
          $('saveStatus').textContent = 'Save conflict — reload this diagram';
          toast(data.error || 'This diagram changed elsewhere.');
          return;
        } if (!response.ok) throw new Error(data.error || 'Could not save to your account.');
        serverProjectId = data.project.id;
        serverProjectRevision = data.project.revision;
        if (!new URLSearchParams(location.search).get('projectId')) history.replaceState({}, '', `/mapper.html?projectId=${encodeURIComponent(serverProjectId)}`);
        if (version !== dirtyVersion) saveAgain = true;
        else $('saveStatus').textContent = 'Saved to your account';
      } while (saveAgain);
    } catch (e) {
      $('saveStatus').textContent = 'Save failed';
      toast(e.message || 'Cloud save failed. Export a JSON backup if needed.');
      console.error(e);
    } finally {
      saveInFlight = false;
      if (saveAgain) {
        saveAgain = false;
        saveCloud();
      }
    }
  }

  function toast(msg) {
    const t = $('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
  }
  function getHostChildEntries(host) {
    return modelHostChildEntries(project, host);
  }
  function logicalRenderContext() {
    const displayProject = deriveLogicalProject(project);
    return {
      project: displayProject, selected, zoom, theme, $, icons, typeLabels, typeColors,
      vlanById: (id) => displayProject.vlans.find(v => v.id === id),
      deviceById: (id) => displayProject.devices.find(d => d.id === id),
      select, startDrag, updateCounts, openAddVlan, isHostGroup,
      getHostChildEntries: (p, host) => modelHostChildEntries(p, host),
      getDragState: () => dragState, svgElement: sv, addSvgText: addText,
      estimateTextWidth: estimateWidth, roundedRect, diagramPalette,
    };
  }
  function physicalRenderContext() {
    return { project, selected, zoom, theme, $, select, startPhysicalDrag, updateCounts, openAddDevice, openAddPhysicalLink, deviceById, icons, openAddVlan, getDragState: () => dragState };
  }
  const logicalRenderer = createLogicalRenderer(logicalRenderContext);
  const physicalRenderer = createPhysicalRenderer(physicalRenderContext);
  function drawDiagram() {
    if (viewMode === 'physical') physicalRenderer();
    else logicalRenderer();
  }
  function startDrag(e, id, g) {
    if (e.button !== 0) return;
    e.preventDefault();
    const svg = g.ownerSVGElement, rect = svg.getBoundingClientRect();
    const scaleX = rect.width / (Number(svg.getAttribute('viewBox').split(' ')[2]) || 1);
    const device = deviceById(id);
    if (!device || !Number.isFinite(scaleX) || scaleX <= 0) return;
    const startDeviceX = device.x;
    dragState = { id, startX: e.clientX, startDeviceX, scaleX, moved: false, mode: 'logical' };
    select('device', id);
    const move = ev => {
      if (!dragState || dragState.id !== id) return;
      const dx = (ev.clientX - dragState.startX) / dragState.scaleX;
      if (Math.abs(dx) > 4) dragState.moved = true;
      deviceById(id).x = Math.max(320, Math.round((dragState.startDeviceX + dx) / 10) * 10);
      drawDiagram();
    };
    const up = () => {
      if (dragState && dragState.id === id) {
        dragState = null;
        document.removeEventListener('pointermove', move);
        document.removeEventListener('pointerup', up);
        markDirty();
        renderSidebar();
        renderInspector();
      }
    };
    document.addEventListener('pointermove', move);
    document.addEventListener('pointerup', up, { once: true });
  }
  function startPhysicalDrag(e, id, g) {
    if (e.button !== 0 || e.target.closest?.('.physical-vm')) return;
    e.preventDefault();
    const svg = g.ownerSVGElement, viewBox = (svg.getAttribute('viewBox') || '0 0 1200 800').split(' ').map(Number), rect = svg.getBoundingClientRect();
    const scaleX = rect.width / (viewBox[2] || 1), scaleY = rect.height / (viewBox[3] || 1);
    const device = deviceById(id);
    if (!device || !Number.isFinite(scaleX) || scaleX <= 0 || scaleY <= 0) return;
    const position = device.physicalPosition || { x: 80, y: 80 };
    dragState = { id, startX: e.clientX, startY: e.clientY, startDeviceX: position.x, startDeviceY: position.y, scaleX, scaleY, moved: false, mode: 'physical' };
    select('device', id);
    const move = ev => {
      if (!dragState || dragState.id !== id) return;
      const dx = (ev.clientX - dragState.startX) / dragState.scaleX, dy = (ev.clientY - dragState.startY) / dragState.scaleY;
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) dragState.moved = true;
      const next = { x: Math.max(10, Math.round((dragState.startDeviceX + dx) / 10) * 10), y: Math.max(10, Math.round((dragState.startDeviceY + dy) / 10) * 10) };
      const current = deviceById(id);
      current.physicalPosition = next;
      current.x = next.x + 110;
      drawDiagram();
    };
    const up = () => {
      if (dragState && dragState.id === id) {
        dragState = null;
        document.removeEventListener('pointermove', move);
        document.removeEventListener('pointerup', up);
        markDirty();
        renderSidebar();
        renderInspector();
      }
    };
    document.addEventListener('pointermove', move);
    document.addEventListener('pointerup', up, { once: true });
  }
  function updateCounts() {
    $('vlanCount').textContent = project.vlans.length;
    $('deviceCount').textContent = project.devices.length;
    $('physicalLinkCount').textContent = (project.physicalLinks || []).length;
    $('canvasStats').textContent = `${project.vlans.length} VLAN${project.vlans.length === 1 ? '' : 's'} · ${project.devices.length} devices · ${(project.physicalLinks || []).length} physical links`;
    $('projectName').value = project.projectName || 'Untitled network topology';
  }
  const renderSidebar = createSidebarRenderer(() => ({
    $, project, selected, icons, vlanById, deviceById, select, updateCounts,
  }));
  function select(kind, id) {
    selected = { kind, id };
    renderSidebar();
    renderInspector();
    drawDiagram();
    if (window.innerWidth <= 1180) $('inspector').classList.add('open');
  }
  const renderInspector = createInspectorRenderer(() => ({
    $, project, selected, selectedItem, icons, typeLabels, isHostGroup, vlanById, deviceById,
    openEditVlan, deleteVlan, toast, markDirty, renderSidebar, drawDiagram,
    openEditPhysicalLink, deletePhysicalLink, openEditDevice, openAddPhysicalLink, openAddDevice,
    openAddConnection, deleteConnection, deleteDevice,
  }));
  function showModal(title, subtitle, body, submitText) {
    $('modalSubmit').hidden = false;
    $('modalTitle').textContent = title;
    $('modalSubtitle').textContent = subtitle;
    $('modalBody').innerHTML = body;
    $('modalSubmit').textContent = submitText || 'Save';
    $('modalBackdrop').classList.add('open');
    setTimeout(() => $('modalBody').querySelector('input,select,textarea')?.focus(), 20);
  }
  function closeModal() {
    $('modalBackdrop').classList.remove('open');
    activeDiscoveryJobId = '';
    $('modalSubmit').hidden = false;
    modalMode = null;
  }
  function openAddVlan() {
    const highestTag = Math.max(0, ...project.vlans.map(vlan => parseInt(vlan.tag, 10) || 0));
    const nextVlan = {
      tag: String(highestTag + 1),
      name: 'NEW-VLAN',
      subnet: '',
      gateway: '',
      notes: '',
      color: '#c99a18',
    };

    modalMode = { kind: 'vlan', id: null };
    showModal(
      'Add VLAN segment',
      'Create a logical network line on the canvas.',
      forms.vlanFormHtml(nextVlan),
      'Add VLAN',
    );
  }
  function openEditVlan(id) {
    const v = vlanById(id);
    if (!v) return;
    modalMode = { kind: 'vlan', id };
    showModal('Edit VLAN segment', 'Update this segment. Existing device assignments will be retained.', forms.vlanFormHtml(v), 'Save changes');
  }
  function openAddDevice(parentHostId = '') {
    const roots = project.devices.filter(device => !device.parentHostId);
    const isNestedVm = Boolean(parentHostId);
    const defaultType = isNestedVm ? 'Virtual machine' : (viewMode === 'physical' ? 'Switch' : 'Thin client');
    const defaultHostname = isNestedVm
      ? 'NEW-VM-01'
      : (viewMode === 'physical' ? 'SW-NEW-01' : 'TC-NEW-01');
    const initialPosition = {
      x: 80 + (roots.length % 4) * 260,
      y: 80 + Math.floor(roots.length / 4) * 220,
    };
    const deviceDraft = {
      type: defaultType,
      hostname: defaultHostname,
      model: '',
      managementIp: '',
      notes: '',
      x: 320 + roots.length * 220,
      physicalPosition: initialPosition,
      displayMode: 'single',
      parentHostId,
      hostedDevices: [],
      ports: [],
      interfaces: [],
    };
    const title = isNestedVm ? 'Add VM to server group' : 'Add physical network device';
    const subtitle = isNestedVm
      ? 'Create an editable VM/workload card inside the selected server group.'
      : 'Create a device, then use Connect to define the cable endpoints and port VLAN modes.';

    modalMode = { kind: 'device', id: null };
    showModal(title, subtitle, forms.deviceFormHtml(deviceDraft), isNestedVm ? 'Add VM' : 'Add device');
  }
  function openEditDevice(id) {
    const d = deviceById(id);
    if (!d) return;
    modalMode = { kind: 'device', id };
    showModal('Edit network device', 'Configure the device, its VLAN interfaces, optional hosted workloads and how it appears on VLAN lines.', forms.deviceFormHtml(d), 'Save device');
  }
  function portByName(device, name) {
    return (device?.ports || []).find(port => String(port.name).toLowerCase() === String(name || '').toLowerCase()) || null;
  }
  function tagsForIds(ids) {
    return (ids || []).map(id => vlanById(id)?.tag).filter(tag => tag !== undefined).join(', ');
  }
  function wirePhysicalLinkForm() {
    const sourceSelect = $('modalBody').querySelector('[name="sourceDeviceId"]');
    const targetSelect = $('modalBody').querySelector('[name="targetDeviceId"]');
    if (!sourceSelect || !targetSelect) return;

    const rebuildOptions = (select, excludedDeviceId, preferredId) => {
      const choices = project.devices.filter(device => device.id !== excludedDeviceId);
      const nextId = choices.some(device => device.id === preferredId) ? preferredId : (choices[0]?.id || '');
      select.innerHTML = choices.map(device => `<option value="${escapeHtml(device.id)}" ${device.id === nextId ? 'selected' : ''}>${escapeHtml(device.hostname)} · ${escapeHtml(device.type)}</option>`).join('');
      select.value = nextId;
      return nextId !== preferredId;
    };

    const refreshPort = side => {
      const select = side === 'source' ? sourceSelect : targetSelect;
      const block = $('modalBody').querySelector(side === 'source' ? '.physical-port-source' : '.physical-port-target');
      const device = deviceById(select.value);
      if (!block) return;
      const currentName = block.querySelector(`[name="${side}Port"]`)?.value || '';
      const knownPort = device?.ports?.find(port => port.name.toLowerCase() === currentName.toLowerCase());
      const name = knownPort?.name || device?.ports?.[0]?.name || '';
      block.innerHTML = forms.physicalPortFields(side, device, name);
    };

    // Keep the endpoint selectors mutually exclusive. Changing a device also refreshes the port fields
    // from that device's own port inventory, avoiding stale switch-port names on endpoint devices.
    // Rebuild the target first so a requested source device stays selected when the form opens.
    rebuildOptions(targetSelect, sourceSelect.value, targetSelect.value);
    rebuildOptions(sourceSelect, targetSelect.value, sourceSelect.value);
    refreshPort('source');
    refreshPort('target');

    sourceSelect.addEventListener('change', () => {
      const preferredSourceId = sourceSelect.value;
      const targetChanged = rebuildOptions(targetSelect, preferredSourceId, targetSelect.value);
      rebuildOptions(sourceSelect, targetSelect.value, preferredSourceId);
      refreshPort('source');
      if (targetChanged) refreshPort('target');
    });

    targetSelect.addEventListener('change', () => {
      const preferredTargetId = targetSelect.value;
      const sourceChanged = rebuildOptions(sourceSelect, preferredTargetId, sourceSelect.value);
      rebuildOptions(targetSelect, sourceSelect.value, preferredTargetId);
      refreshPort('target');
      if (sourceChanged) refreshPort('source');
    });
  }

  function openAddPhysicalLink(sourceId = '') {
    if (project.devices.length < 2) {
      toast('Add at least two devices before connecting them.');
      return;
    }
    modalMode = { kind: 'physicalLink', id: null };
    showModal('Connect physical devices', 'Define the two cable endpoints and their port modes. Changes automatically update inferred VLAN membership in Logical view.', forms.physicalLinkFormHtml(null, sourceId), 'Add physical link');
    wirePhysicalLinkForm();
  }

  function openEditPhysicalLink(id) {
    const link = (project.physicalLinks || []).find(item => item.id === id);
    if (!link) return;
    modalMode = { kind: 'physicalLink', id };
    showModal('Edit physical link', 'Update cable endpoints, media and port-level VLAN configuration.', forms.physicalLinkFormHtml(link), 'Save link');
    wirePhysicalLinkForm();
  }
  function ensureVlanByTag(rawTag) {
    const tag = String(rawTag || '').trim();
    if (!tag) return null;
    if (!/^\d{1,4}$/.test(tag) || Number(tag) < 1 || Number(tag) > 4094) throw new Error(`VLAN tag "${tag}" must be an integer from 1 to 4094.`);
    let vlan = project.vlans.find(item => String(item.tag) === tag);
    if (!vlan) {
      vlan = { id: uid('vlan'), tag, name: `VLAN-${tag}`, subnet: '', gateway: '', notes: 'Automatically created from a physical port configuration. Complete subnet/gateway details if verified.', lineStyle: 'straight', color: defaultPalette[project.vlans.length % defaultPalette.length] };
      project.vlans.push(vlan);
    } return vlan;
  }
  function savePortConfiguration(device, portName, mode, accessVlanTag, allowedVlanTags) {
    const name = String(portName || '').trim();
    if (!device || !name) throw new Error('Both endpoints need an interface or switch-port name.');
    if (!portModes.includes(mode)) throw new Error('Choose a supported port mode.');
    let accessVlanId = '', allowedVlanIds = [];
    if (mode === 'access') {
      const vlan = ensureVlanByTag(accessVlanTag);
      if (!vlan) throw new Error(`${device.hostname} ${name}: enter an access VLAN tag.`);
      accessVlanId = vlan.id;
    }

    if (mode === 'trunk') {
      const tags = [...new Set(
        String(allowedVlanTags || '')
          .split(/[\s,;]+/)
          .map(tag => tag.trim())
          .filter(Boolean),
      )];
      for (const tag of tags) {
        const vlan = ensureVlanByTag(tag);
        if (vlan) allowedVlanIds.push(vlan.id);
      }
    }
    if (!Array.isArray(device.ports)) device.ports = [];
    const existing = portByName(device, name);
    const next = { name, mode, accessVlanId, allowedVlanIds, notes: existing?.notes || '', status: existing?.status || 'unknown', speed: existing?.speed || '', discoveryConfidence: existing?.discoveryConfidence || 'unknown' };
    if (existing) Object.assign(existing, next);
    else device.ports.push(next);
  }
  function syncInterfaceRows() {
    const selectedIds = new Set([...document.querySelectorAll('input[name="vlanIds"]:checked')].map(x => x.value));
    document.querySelectorAll('[data-config-vlan]').forEach(row => row.classList.toggle('hidden', !selectedIds.has(row.dataset.configVlan)));
  }
  function readModalForm() {
    const form = $('modalForm');
    const data = Object.fromEntries(new FormData(form).entries());
    if (modalMode.kind === 'vlan') return data;
    if (modalMode.kind === 'physicalLink') return data;
    if (modalMode.kind === 'connection') {
      const toDeviceIds = [...document.querySelectorAll('input[name="toDeviceIds"]:checked')]
        .map(input => input.value);
      return { ...data, toDeviceIds };
    }
    const chosen = [...document.querySelectorAll('input[name="vlanIds"]:checked')].map(input => input.value);
    const existing = modalMode.id ? deviceById(modalMode.id) : null;
    const unassignedInterfaces = (existing?.interfaces || [])
      .filter(item => !item.vlanId)
      .map(item => ({ ...item, vlanId: '' }));
    const interfaces = [...unassignedInterfaces, ...chosen.map(vlanId => {
      const oldInterface = existing?.interfaces.find(item => item.vlanId === vlanId);
      const read = field => document.querySelector(
        `[data-config-field="${field}"][data-config-id="${CSS.escape(vlanId)}"]`,
      )?.value.trim() || '';

      return {
        vlanId,
        name: read('name') || oldInterface?.name || '',
        ip: read('ip') || oldInterface?.ip || '',
        peerPort: read('peerPort') || oldInterface?.peerPort || '',
        status: oldInterface?.status || 'unknown',
        macAddress: oldInterface?.macAddress || '',
        discoveryConfidence: oldInterface?.discoveryConfidence || 'unknown',
      };
    })];
    const physicalPosition = existing?.physicalPosition || {
      x: 80 + (project.devices.length % 4) * 260,
      y: 80 + Math.floor(project.devices.length / 4) * 220,
    };
    const hostedDevices = String(data.hostedDevices || '')
      .split('\n')
      .map(item => item.trim())
      .filter(Boolean)
      .slice(0, 12);

    return {
      ...data,
      hostedDevices,
      parentHostId: String(data.parentHostId || ''),
      displayMode: data.displayMode === 'per-vlan' ? 'per-vlan' : 'single',
      interfaces,
      physicalPosition,
      x: existing?.x ?? physicalPosition.x + 110,
      ports: existing?.ports || [],
    };
  }
  function submitModal(event) {
    event.preventDefault();
    if (!modalMode) return;
    const mode = { ...modalMode }, wasEditing = Boolean(mode.id), data = readModalForm();
    let successMessage = '';
    if (mode.kind === 'vlan') {
      const tag = String(data.tag || '').trim();
      if (project.vlans.some(v => v.id !== mode.id && v.tag === tag)) {
        toast('That VLAN ID already exists.');
        return;
      }
      const next = {
        tag,
        name: String(data.name || '').trim(),
        subnet: String(data.subnet || '').trim(),
        gateway: String(data.gateway || '').trim(),
        lineStyle: ['straight', 'curve', 'deep-curve'].includes(data.lineStyle) ? data.lineStyle : 'straight',
        notes: String(data.notes || ''),
      };
      if (mode.id) Object.assign(vlanById(mode.id), next);
      else {
        const vlan = { id: uid('vlan'), ...next, color: defaultPalette[project.vlans.length % defaultPalette.length] };
        project.vlans.push(vlan);
        selected = { kind: 'vlan', id: vlan.id };
      } successMessage = wasEditing ? 'VLAN updated' : 'VLAN added';
    } else if (mode.kind === 'physicalLink') {
      const sourceId = String(data.sourceDeviceId || ''), targetId = String(data.targetDeviceId || '');
      const source = deviceById(sourceId), target = deviceById(targetId);
      if (!source || !target || source.id === target.id) {
        toast('Choose two different endpoint devices.');
        return;
      }
      const sourcePort = String(data.sourcePort || '').trim(), targetPort = String(data.targetPort || '').trim();
      try {
        savePortConfiguration(source, sourcePort, String(data.sourceMode || 'unknown'), String(data.sourceAccessVlanTag || ''), String(data.sourceAllowedVlanTags || ''));
        savePortConfiguration(target, targetPort, String(data.targetMode || 'unknown'), String(data.targetAccessVlanTag || ''), String(data.targetAllowedVlanTags || ''));
      }
      catch (error) {
        toast(error.message || 'Port configuration is invalid.');
        return;
      }
      const existingLink = mode.id ? project.physicalLinks.find(item => item.id === mode.id) : null;
      const link = {
        id: mode.id || uid('plink'),
        sourceDeviceId: sourceId,
        sourcePort,
        targetDeviceId: targetId,
        targetPort,
        mediaType: physicalMediaTypes.includes(data.mediaType) ? data.mediaType : 'Copper Ethernet',
        label: String(data.label || '').trim(),
        notes: String(data.physicalLinkNotes || '').trim(),
        discoveryConfidence: existingLink?.discoveryConfidence || 'unknown',
        discoverySource: existingLink?.discoverySource || '',
        observedAt: existingLink?.observedAt || '',
      };
      if (mode.id) {
        const index = project.physicalLinks.findIndex(item => item.id === mode.id);
        if (index >= 0) project.physicalLinks[index] = link;
        else project.physicalLinks.push(link);
      } else project.physicalLinks.push(link);
      selected = { kind: 'physicalLink', id: link.id };
      viewMode = 'physical';
      successMessage = wasEditing ? 'Physical link updated' : 'Physical link added';
    } else if (mode.kind === 'connection') {
      if (!Array.isArray(project.connections)) project.connections = [];
      const from = String(data.fromDeviceId || '');
      const targets = [...new Set((Array.isArray(data.toDeviceIds) ? data.toDeviceIds : (data.toDeviceId ? [data.toDeviceId] : [])).map(String))].filter(id => deviceById(id) && id !== from);
      if (!deviceById(from) || !targets.length) {
        toast('Choose a source and at least one different target device.');
        return;
      }
      const common = {
        type: connectionTypes.includes(data.type) ? data.type : 'Custom relationship',
        label: String(data.label || '').trim(),
        protocolPort: String(data.protocolPort || '').trim(),
        notes: String(data.connectionNotes || '').trim(),
      };
      if (mode.id) {
        const existing = project.connections.find(item => item.id === mode.id);
        if (existing) Object.assign(existing, { fromDeviceId: from, toDeviceId: targets[0], ...common });
        else project.connections.push({ id: mode.id, fromDeviceId: from, toDeviceId: targets[0], ...common });
        successMessage = 'Relationship updated';
      }
      else {
        targets.forEach(to => project.connections.push({ id: uid('conn'), fromDeviceId: from, toDeviceId: to, ...common }));
        successMessage = targets.length === 1 ? 'Relationship added' : `${targets.length} relationships added`;
      }
      selected = { kind: 'device', id: from };
    } else {
      const hostname = String(data.hostname || '').trim();
      if (!hostname) {
        toast('Enter a device hostname.');
        return;
      } if (project.devices.some(item => item.id !== mode.id && item.hostname.toLowerCase() === hostname.toLowerCase())) {
        toast('A device with that hostname already exists.');
        return;
      }
      const parentHostId = String(data.parentHostId || '');
      const parent = parentHostId ? deviceById(parentHostId) : null;
      if (parentHostId && (!parent || !isHostGroup(parent) || isHostGroup({ type: data.type }))) {
        toast('Choose a valid ESXi host, hypervisor or server group for this VM.');
        return;
      }
      const existing = mode.id ? deviceById(mode.id) : null;
      const physicalPosition = data.physicalPosition || existing?.physicalPosition || { x: 80 + (project.devices.length % 4) * 260, y: 80 + Math.floor(project.devices.length / 4) * 220 };
      const device = {
        id: mode.id || uid('dev'),
        type: typeLabels[data.type] ? data.type : 'Other',
        hostname,
        model: String(data.model || '').trim(),
        managementIp: String(data.managementIp || '').trim(),
        macAddress: String(data.macAddress || '').trim(),
        discoveryStatus: existing?.discoveryStatus || 'manual',
        discoveryConfidence: existing?.discoveryConfidence || 'unknown',
        lastSeenAt: existing?.lastSeenAt || '',
        notes: String(data.notes || ''),
        x: Number(data.x) || physicalPosition.x + 110,
        physicalPosition,
        displayMode: data.displayMode === 'per-vlan' ? 'per-vlan' : 'single',
        parentHostId,
        hostedDevices: Array.isArray(data.hostedDevices) ? data.hostedDevices : [],
        ports: Array.isArray(data.ports) ? data.ports : (existing?.ports || []),
        interfaces: Array.isArray(data.interfaces) ? data.interfaces : [],
      };
      if (mode.id) {
        if (!isHostGroup(device)) project.devices.forEach(child => {
          if (child.id !== device.id && child.parentHostId === device.id) child.parentHostId = '';
        });
        Object.assign(existing, device);
        selected = { kind: 'device', id: device.id };
      }
      else {
        project.devices.push(device);
        selected = { kind: 'device', id: device.id };
      } successMessage = wasEditing ? 'Device updated' : 'Device added';
    }
    closeModal();
    markDirty();
    renderSidebar();
    renderInspector();
    drawDiagram();
    toast(successMessage || 'Changes saved');
    modalMode = null;
  }
  function openAddConnection(fromId = '') {
    if (project.devices.length < 2) {
      toast('Add at least two devices before mapping a relationship.');
      return;
    } modalMode = { kind: 'connection', id: null };
    showModal('Add remote / service relationship', 'Choose one source and one or more targets. A separate directional arrow will be created for each target.', forms.remoteConnectionFormHtml(fromId), 'Add relationship(s)');
    const from = $('modalBody').querySelector('[name="fromDeviceId"]');
    const updateTargets = () => {
      const container = $('connectionTargets');
      if (!container) return;
      const previouslyChecked = new Set([...container.querySelectorAll('input[name="toDeviceIds"]:checked')].map(x => x.value));
      container.innerHTML = project.devices.filter(d => d.id !== from.value).map(d => `<label class="check-option">
      <input type="checkbox" name="toDeviceIds" value="${escapeHtml(d.id)}" ${previouslyChecked.has(d.id) ? 'checked' : ''}>
      <span>
      <strong>${escapeHtml(d.hostname)}</strong>
      <br>
      <span class="muted">${escapeHtml(d.type)}${d.managementIp ? ' · ' + escapeHtml(d.managementIp) : ''}</span>
      </span>
      </label>`).join('');
    };
    if (fromId) from.value = fromId;
    from?.addEventListener('change', updateTargets);
    updateTargets();
  }

  function deleteConnection(id) {
    const c = project.connections.find(x => x.id === id);
    if (!c) return;
    if (!confirm('Remove this relationship from the diagram?')) return;
    project.connections = project.connections.filter(x => x.id !== id);
    markDirty();
    renderSidebar();
    renderInspector();
    drawDiagram();
    toast('Relationship removed');
  }
  function deletePhysicalLink(id) {
    const link = (project.physicalLinks || []).find(item => item.id === id);
    if (!link) return;
    if (!confirm('Delete this physical link? Port configuration will remain on each device until you edit it.')) return;
    project.physicalLinks = project.physicalLinks.filter(item => item.id !== id);
    selected = null;
    markDirty();
    renderSidebar();
    renderInspector();
    drawDiagram();
    toast('Physical link removed');
  }

  function deleteVlan(id) {
    const v = vlanById(id);
    if (!v) return;
    const affected = project.devices.filter(d => d.interfaces.some(it => it.vlanId === id) || (d.ports || []).some(p => p.accessVlanId === id || (p.allowedVlanIds || []).includes(id))).length;
    if (!confirm(`Delete VLAN ${v.tag} — ${v.name}? ${affected ? `${affected} device(s) will lose this VLAN assignment. ` : ''}This cannot be undone unless you have an exported backup.`)) return;
    project.vlans = project.vlans.filter(x => x.id !== id);
    project.devices.forEach(d => {
      d.interfaces = d.interfaces.filter(it => it.vlanId !== id);
      (d.ports || []).forEach(p => {
        if (p.accessVlanId === id) p.accessVlanId = '';
        p.allowedVlanIds = (p.allowedVlanIds || []).filter(vlanId => vlanId !== id);
      });
    });
    selected = null;
    markDirty();
    renderSidebar();
    renderInspector();
    drawDiagram();
    toast('VLAN deleted');
  }
  function deleteDevice(id) {
    const d = deviceById(id);
    if (!d) return;
    const children = project.devices.filter(x => x.parentHostId === id);
    const impact = children.length ? ` ${children.length} contained VM/device record(s) will be kept and ungrouped.` : '';
    if (!confirm(`Delete device ${d.hostname}?${impact} This cannot be undone unless you have an exported backup.`)) return;
    project.devices.forEach(x => {
      if (x.parentHostId === id) x.parentHostId = '';
    });
    project.devices = project.devices.filter(x => x.id !== id);
    project.connections = (project.connections || []).filter(c => c.fromDeviceId !== id && c.toDeviceId !== id);
    project.physicalLinks = (project.physicalLinks || []).filter(link => link.sourceDeviceId !== id && link.targetDeviceId !== id);
    selected = null;
    markDirty();
    renderSidebar();
    renderInspector();
    drawDiagram();
    toast(children.length ? 'Device deleted; contained devices ungrouped' : 'Device deleted');
  }
  const { exportJson, exportSvg, exportPng } = createExportActions({
    getProject: () => project,
    getTheme: () => theme,
    getCurrentSvg: () => $('canvasMount').querySelector('svg'),
    saveCloud,
    toast,
  });
  function openImport() {
    $('importFile').click();
  }
  let pendingDiscoveryImport = null;

  function discoveryIntroHtml() {
    return `<div class="discovery-intro">
      <p>Generate an editable topology from monitored inventory or a local discovery agent. Review the findings and warnings before changing any diagram.</p>
      <div class="discovery-status" id="librenmsStatus" role="status" aria-live="polite">Checking whether this deployment has a LibreNMS connection…</div>
      <div class="discovery-actions">
        <button type="button" class="btn primary" id="importLibreNmsBtn" hidden>Import from LibreNMS</button>
        <button type="button" class="btn" id="testLibreNmsBtn" hidden>Test connection</button>
        <button type="button" class="btn" id="loadDiscoverySampleBtn">Load sample snapshot</button>
        <button type="button" class="btn" id="uploadDiscoverySnapshotBtn">Import snapshot JSON</button>
      </div>
      <section class="discovery-agent-panel" aria-labelledby="discoveryAgentHeading">
        <div class="discovery-section-heading"><h3 id="discoveryAgentHeading">Local discovery agent</h3><span class="discovery-mini-label">New</span></div>
        <p class="field-help">Pair a computer inside the network you need to document. The agent connects outbound to Holly Bibley and does not open a listening port.</p>
        <div class="discovery-status" id="localAgentStatus" role="status" aria-live="polite">Checking paired agents…</div>
        <div class="discovery-actions">
          <button type="button" class="btn primary" id="createAgentPairingBtn">Generate pairing code</button>
          <button type="button" class="btn" id="refreshDiscoveryAgentsBtn">Refresh agents</button>
        </div>
        <div class="discovery-pairing-code" id="agentPairingPanel" hidden>
          <div><strong>One-time pairing code</strong><p class="field-help">Run the agent command on the computer to be paired, then enter this code when prompted. It expires after 10 minutes.</p></div>
          <code id="agentPairingCode"></code>
          <div class="discovery-actions">
            <button type="button" class="btn" id="copyAgentPairingCodeBtn">Copy code</button>
          </div>
          <p class="field-help" id="agentPairingExpiry"></p>
          <div class="discovery-pairing-command"><strong>Run on the computer that will perform discovery</strong><code id="agentPairingCommand"></code><button type="button" class="btn" id="copyAgentCommandBtn">Copy command</button></div>
          <p class="field-help" id="agentPairingCommandHelp"></p>
        </div>
        <div class="discovery-agent-controls">
          <label class="field"><span class="field-label">Paired agent</span><select id="discoveryAgentSelect"><option value="">No paired agent available</option></select></label>
          <label class="field"><span class="field-label">Discovery type</span><select id="agentDiscoveryKind"><option value="subnet">Local subnet — reachable hosts and neighbour cache</option><option value="switches">Switches — SNMPv3 interfaces, VLANs and LLDP</option></select></label>
          <div class="field" id="agentSubnetFields"><label for="agentSubnetCidr">Subnet (CIDR)</label><input id="agentSubnetCidr" type="text" placeholder="192.168.10.0/24" autocomplete="off" spellcheck="false" /><small>Only a private subnet directly attached to the agent's own interface can be scanned; maximum 256 addresses.</small><label for="agentInterfaceName">Interface name (optional)</label><input id="agentInterfaceName" type="text" maxlength="100" placeholder="Ethernet" autocomplete="off" /></div>
          <div class="field" id="agentSwitchFields" hidden><label for="agentSwitchTargets">Switch management IPs</label><textarea id="agentSwitchTargets" rows="3" placeholder="192.168.10.2, 192.168.10.3" spellcheck="false"></textarea><small>Enter up to 64 explicit private IPv4 addresses. SNMPv3 credentials must be configured on the agent computer.</small></div>
        </div>
        <div class="discovery-actions">
          <button type="button" class="btn primary" id="startAgentDiscoveryBtn" disabled>Start discovery</button>
          <button type="button" class="btn danger" id="revokeDiscoveryAgentBtn" disabled>Revoke selected agent</button>
        </div>
        <div class="discovery-status" id="agentDiscoveryJobStatus" role="status" aria-live="polite">Pair an agent and keep its process running to start discovery from this screen.</div>
        <p class="field-help">Subnet scans use ICMP and the local ARP/neighbour table. Switch discovery uses read-only SNMPv3 authPriv and LLDP data where supported. Results may be incomplete; all links and VLAN deductions must be reviewed. Do not run active discovery on production/OT equipment without the site's approval.</p>
      </section>
      <a class="discovery-format-link" href="/mapper/discovery-snapshot-format.md" target="_blank" rel="noopener">Read the snapshot format</a>
      <a class="discovery-format-link" href="/mapper/local-discovery-agent.md" target="_blank" rel="noopener">Local discovery agent guide</a>
      <div class="discovery-notice"><strong>What the result means:</strong> a reachable endpoint is not proof of its physical switch port. Switch-port links require switch management data and advertised neighbours. Unknown details remain unknown instead of being invented.</div>
      <div class="field-help">The built-in sample is synthetic documentation data, not a real scan. Live LibreNMS inventory requires server-side configuration. Active discovery must be explicitly authorised.</div>
    </div>`;
  }

  function discoveryRequestError(payload, status) {
    return new Error(payload?.error || `Discovery request failed (HTTP ${status}).`);
  }

  async function discoveryApiRequest(url, method = 'GET', body = undefined) {
    const response = await fetch(url, {
      method,
      credentials: 'same-origin',
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw discoveryRequestError(payload, response.status);
    return payload;
  }

  async function refreshLibreNmsStatus() {
    const status = $('librenmsStatus');
    const importButton = $('importLibreNmsBtn');
    const testButton = $('testLibreNmsBtn');
    try {
      const result = await discoveryApiRequest('/api/discovery/librenms/status');
      status.textContent = result.message || (result.available ? 'LibreNMS is configured for this account.' : 'LibreNMS import is not available for this account.');
      status.classList.toggle('is-ready', Boolean(result.available));
      status.classList.toggle('is-error', Boolean(result.message && result.message.includes('not enabled for this account')));
      importButton.hidden = !result.available;
      testButton.hidden = !result.available;
    } catch (error) {
      status.textContent = error.message || 'Could not check LibreNMS integration status.';
      status.classList.add('is-error');
      importButton.hidden = true;
      testButton.hidden = true;
    }
  }

  let activeDiscoveryJobId = '';
  let pairedDiscoveryAgents = [];

  function setDiscoveryStatus(element, message, tone = '') {
    if (!element) return;
    element.textContent = message;
    element.classList.toggle('is-ready', tone === 'ready');
    element.classList.toggle('is-error', tone === 'error');
  }

  function renderDiscoveryAgents(agents) {
    pairedDiscoveryAgents = Array.isArray(agents) ? agents : [];
    const select = $('discoveryAgentSelect');
    if (!select) return;
    const previous = select.value;
    const presence = pairedDiscoveryAgents.map((agent) => {
      const lastSeenAt = agent.lastSeenAt ? new Date(agent.lastSeenAt) : null;
      const validLastSeen = lastSeenAt && Number.isFinite(lastSeenAt.getTime());
      const ageMs = validLastSeen ? Math.max(0, Date.now() - lastSeenAt.getTime()) : Infinity;
      const state = ageMs <= 90_000 ? 'recently active' : validLastSeen ? 'stale' : 'never connected';
      const timestamp = validLastSeen ? ` · last seen ${lastSeenAt.toLocaleString()}` : '';
      return { agent, state, label: `${agent.name} · ${state}${timestamp}` };
    });
    select.innerHTML = '<option value="">Select a paired agent</option>' + presence.map(({ agent, label }) => {
      return `<option value="${escapeHtml(agent.id)}">${escapeHtml(label)}</option>`;
    }).join('');
    select.value = pairedDiscoveryAgents.some((agent) => agent.id === previous) ? previous : (pairedDiscoveryAgents[0]?.id || '');
    $('startAgentDiscoveryBtn').disabled = !select.value;
    $('revokeDiscoveryAgentBtn').disabled = !select.value;
  }

  async function refreshDiscoveryAgents() {
    const status = $('localAgentStatus');
    if (!status) return;
    status.textContent = 'Checking paired agents…';
    try {
      const result = await discoveryApiRequest('/api/discovery/agents');
      renderDiscoveryAgents(result.agents);
      if (!result.agents?.length) {
        setDiscoveryStatus(status, 'No paired local agents. Generate a pairing code, then run the agent on a computer inside the target network.');
      } else {
        const recentCutoff = Date.now() - 90_000;
        const activeCount = result.agents.filter((agent) => {
          const seen = Date.parse(agent.lastSeenAt || '');
          return Number.isFinite(seen) && seen >= recentCutoff;
        }).length;
        const staleCount = result.agents.length - activeCount;
        setDiscoveryStatus(status, `${result.agents.length} paired agent${result.agents.length === 1 ? '' : 's'} · ${activeCount} recently active · ${staleCount} stale or never connected.`, activeCount ? 'ready' : '');
      }
    } catch (error) {
      renderDiscoveryAgents([]);
      setDiscoveryStatus(status, error.message || 'Could not load paired agents.', 'error');
    }
  }

  function updateAgentDiscoveryFields() {
    const switches = $('agentDiscoveryKind')?.value === 'switches';
    if ($('agentSubnetFields')) $('agentSubnetFields').hidden = switches;
    if ($('agentSwitchFields')) $('agentSwitchFields').hidden = !switches;
    const button = $('startAgentDiscoveryBtn');
    if (button) button.textContent = switches ? 'Discover switches' : 'Discover subnet';
  }

  async function waitForAgentJob(jobId, agentName) {
    const status = $('agentDiscoveryJobStatus');
    const maxAttempts = 240;
    for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
      if (activeDiscoveryJobId !== jobId || !$('modalBackdrop').classList.contains('open')) return;
      await new Promise((resolve) => setTimeout(resolve, 3000));
      if (activeDiscoveryJobId !== jobId || !$('modalBackdrop').classList.contains('open')) return;
      try {
        const result = await discoveryApiRequest(`/api/discovery/jobs/${encodeURIComponent(jobId)}`);
        if (activeDiscoveryJobId !== jobId || !$('modalBackdrop').classList.contains('open')) return;
        const job = result.job;
        if (job.status === 'completed' && job.snapshot) {
          activeDiscoveryJobId = '';
          showDiscoveryPreview(job.snapshot, `${agentName} · ${job.kind} discovery`);
          return;
        }
        if (job.status === 'failed' || job.status === 'cancelled') {
          activeDiscoveryJobId = '';
          setDiscoveryStatus(status, job.error || `Discovery ${job.status}.`, 'error');
          $('startAgentDiscoveryBtn').disabled = false;
          return;
        }
        setDiscoveryStatus(status, job.status === 'running' ? 'Discovery is running on the paired computer. This screen will update when results arrive…' : 'Discovery job is queued. Waiting for the paired computer…');
      } catch (error) {
        activeDiscoveryJobId = '';
        setDiscoveryStatus(status, error.message || 'Could not check discovery job status.', 'error');
        $('startAgentDiscoveryBtn').disabled = false;
        return;
      }
    }
    if (activeDiscoveryJobId === jobId) {
      activeDiscoveryJobId = '';
      setDiscoveryStatus(status, 'No result arrived within 12 minutes. The agent may be offline or still working; refresh the agent list and check its terminal.', 'error');
      $('startAgentDiscoveryBtn').disabled = false;
    }
  }

  async function startAgentDiscovery() {
    const agentId = $('discoveryAgentSelect')?.value;
    const agent = pairedDiscoveryAgents.find((entry) => entry.id === agentId);
    if (!agentId || !agent) {
      setDiscoveryStatus($('agentDiscoveryJobStatus'), 'Select a paired discovery agent first.', 'error');
      return;
    }
    const kind = $('agentDiscoveryKind').value;
    let request;
    if (kind === 'subnet') {
      request = {
        kind,
        cidr: $('agentSubnetCidr').value.trim(),
        interfaceName: $('agentInterfaceName').value.trim(),
      };
    } else {
      const targets = $('agentSwitchTargets').value.split(/[\s,;]+/).map((value) => value.trim()).filter(Boolean);
      request = { kind: 'switches', targets };
    }
    const button = $('startAgentDiscoveryBtn');
    button.disabled = true;
    setDiscoveryStatus($('agentDiscoveryJobStatus'), 'Submitting discovery job…');
    try {
      const result = await discoveryApiRequest(`/api/discovery/agents/${encodeURIComponent(agentId)}/jobs`, 'POST', request);
      activeDiscoveryJobId = result.job.id;
      setDiscoveryStatus($('agentDiscoveryJobStatus'), `Job queued for ${agent.name}. Keep the agent process running while it discovers the network.`);
      void waitForAgentJob(result.job.id, agent.name);
    } catch (error) {
      button.disabled = false;
      setDiscoveryStatus($('agentDiscoveryJobStatus'), error.message || 'Could not submit the discovery job.', 'error');
    }
  }

  async function pairDiscoveryAgent() {
    const button = $('createAgentPairingBtn');
    const panel = $('agentPairingPanel');
    button.disabled = true;
    button.textContent = 'Generating…';
    try {
      const result = await discoveryApiRequest('/api/discovery/agents/pairing', 'POST', {});
      $('agentPairingCode').textContent = result.pairingCode;
      $('agentPairingExpiry').textContent = `Expires ${new Date(result.expiresAt).toLocaleTimeString()}. The code can be used once.`;
      panel.hidden = false;
      const isSecureOrigin = location.protocol === 'https:';
      const isLoopback = ['localhost', '127.0.0.1', '[::1]'].includes(location.hostname);
      const agentOrigin = isSecureOrigin || isLoopback ? location.origin : `${location.protocol}//127.0.0.1:${location.port || '5173'}`;
      $('agentPairingCommand').textContent = `npm run discovery:agent -- --server ${agentOrigin} --name "Holly Bibley agent"`;
      $('agentPairingCommandHelp').textContent = !isSecureOrigin && !isLoopback
        ? 'This page uses plain HTTP on a LAN address. The copied command is for the same computer as the web app using loopback; pair an agent on another computer only after deploying Holly Bibley over HTTPS.'
        : 'The agent will prompt for the one-time code, then store its token in a per-user config file.';
      setDiscoveryStatus($('localAgentStatus'), result.message || 'Pairing code generated.', 'ready');
    } catch (error) {
      setDiscoveryStatus($('localAgentStatus'), error.message || 'Could not generate a pairing code.', 'error');
    } finally {
      button.disabled = false;
      button.textContent = 'Generate pairing code';
    }
  }

  async function revokeSelectedDiscoveryAgent() {
    const agentId = $('discoveryAgentSelect')?.value;
    const agent = pairedDiscoveryAgents.find((entry) => entry.id === agentId);
    if (!agentId || !agent) return;
    if (!confirm(`Revoke the local discovery agent "${agent.name}"? Its token will stop working and queued jobs will be cancelled.`)) return;
    const button = $('revokeDiscoveryAgentBtn');
    button.disabled = true;
    try {
      await discoveryApiRequest(`/api/discovery/agents/${encodeURIComponent(agentId)}`, 'DELETE');
      setDiscoveryStatus($('agentDiscoveryJobStatus'), 'Agent revoked. Its saved token can no longer access Holly Bibley.');
      await refreshDiscoveryAgents();
    } catch (error) {
      setDiscoveryStatus($('agentDiscoveryJobStatus'), error.message || 'Could not revoke the selected agent.', 'error');
      button.disabled = false;
    }
  }

  function openDiscovery() {
    pendingDiscoveryImport = null;
    modalMode = null;
    showModal('Network discovery', 'Import collected network inventory and convert it into an editable topology.', discoveryIntroHtml(), 'Close');
    $('modalSubmit').hidden = true;
    refreshLibreNmsStatus();
    refreshDiscoveryAgents();
    $('createAgentPairingBtn').onclick = pairDiscoveryAgent;
    $('refreshDiscoveryAgentsBtn').onclick = refreshDiscoveryAgents;
    // Use replaceable handlers so repeatedly opening the modal does not accumulate listeners.
    $('discoveryAgentSelect').onchange = () => {
      $('startAgentDiscoveryBtn').disabled = !$('discoveryAgentSelect').value;
      $('revokeDiscoveryAgentBtn').disabled = !$('discoveryAgentSelect').value;
    };
    $('agentDiscoveryKind').onchange = updateAgentDiscoveryFields;
    $('startAgentDiscoveryBtn').onclick = startAgentDiscovery;
    $('revokeDiscoveryAgentBtn').onclick = revokeSelectedDiscoveryAgent;
    $('copyAgentPairingCodeBtn').onclick = async () => {
      const code = $('agentPairingCode').textContent;
      try {
        await navigator.clipboard.writeText(code);
        toast('Pairing code copied');
      } catch {
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents($('agentPairingCode'));
        selection?.removeAllRanges();
        selection?.addRange(range);
        toast('Select the code and copy it manually');
      }
    };
    $('copyAgentCommandBtn').onclick = async () => {
      const command = $('agentPairingCommand').textContent;
      try {
        await navigator.clipboard.writeText(command);
        toast('Agent command copied');
      } catch {
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents($('agentPairingCommand'));
        selection?.removeAllRanges();
        selection?.addRange(range);
        toast('Select the command and copy it manually');
      }
    };
    updateAgentDiscoveryFields();
    $('loadDiscoverySampleBtn').onclick = async () => {
      const button = $('loadDiscoverySampleBtn');
      button.disabled = true;
      button.textContent = 'Loading sample…';
      try {
        const response = await fetch('/mapper/discovery-sample.json', { credentials: 'same-origin' });
        if (!response.ok) throw new Error('The sample snapshot could not be loaded.');
        const snapshot = await response.json();
        showDiscoveryPreview(snapshot, 'Built-in sample snapshot');
      } catch (error) {
        toast(error.message || 'Could not load sample discovery data.');
        button.disabled = false;
        button.textContent = 'Load sample snapshot';
      }
    };
    $('uploadDiscoverySnapshotBtn').onclick = () => $('discoverySnapshotFile').click();
    $('testLibreNmsBtn').onclick = async () => {
      const button = $('testLibreNmsBtn');
      const status = $('librenmsStatus');
      button.disabled = true;
      button.textContent = 'Testing…';
      try {
        const result = await discoveryApiRequest('/api/discovery/librenms/test', 'POST');
        status.textContent = result.message || 'LibreNMS connection succeeded.';
        status.classList.add('is-ready');
        status.classList.remove('is-error');
      } catch (error) {
        status.textContent = error.message || 'LibreNMS connection failed.';
        status.classList.add('is-error');
        status.classList.remove('is-ready');
      } finally {
        button.disabled = false;
        button.textContent = 'Test connection';
      }
    };
    $('importLibreNmsBtn').onclick = async () => {
      const button = $('importLibreNmsBtn');
      button.disabled = true;
      button.textContent = 'Reading inventory…';
      try {
        const result = await discoveryApiRequest('/api/discovery/librenms/snapshot', 'POST');
        showDiscoveryPreview(result.snapshot, 'LibreNMS monitored inventory');
      } catch (error) {
        const status = $('librenmsStatus');
        status.textContent = error.message || 'LibreNMS inventory could not be imported.';
        status.classList.add('is-error');
        status.classList.remove('is-ready');
      } finally {
        button.disabled = false;
        button.textContent = 'Import from LibreNMS';
      }
    };
  }

  function showDiscoveryPreview(rawSnapshot, filename) {
    pendingDiscoveryImport = null;
    try {
      const prepared = discoverySnapshotToProject(rawSnapshot);
      pendingDiscoveryImport = { ...prepared, filename: String(filename || 'Discovery snapshot') };
      const { snapshot, summary } = pendingDiscoveryImport;
      const allWarnings = pendingDiscoveryImport.project.discovery?.warnings || snapshot.warnings;
      const warningsHtml = allWarnings.length
        ? `<ul class="discovery-warning-list">${allWarnings.slice(0, 8).map((warning) => `<li>${escapeHtml(warning)}</li>`).join('')}</ul>`
        : '<p class="field-help">The input snapshot did not include source warnings. You should still verify discovered facts before relying on them.</p>';
      const additionalWarnings = Math.max(0, summary.warnings - Math.min(allWarnings.length, 8));
      const body = `<div class="discovery-preview">
        <div class="discovery-notice"><strong>Preview only.</strong> No changes have been made to your current diagram yet.</div>
        <p><strong>Source:</strong> ${escapeHtml(snapshot.source.name)} <span class="muted">(${escapeHtml(snapshot.source.adapter)})</span></p>
        <p><strong>File:</strong> ${escapeHtml(pendingDiscoveryImport.filename)}</p>
        <p><strong>Scope:</strong> ${escapeHtml(snapshot.scope.cidr || snapshot.scope.label || 'Not specified')}</p>
        <div class="discovery-summary-grid">
          <div><strong>${summary.devices}</strong><span>Devices</span></div>
          <div><strong>${summary.vlans}</strong><span>VLANs</span></div>
          <div><strong>${summary.links}</strong><span>Physical links</span></div>
          <div class="${summary.warnings ? 'has-warnings' : ''}"><strong>${summary.warnings}</strong><span>Warnings</span></div>
        </div>
        ${warningsHtml}
        ${additionalWarnings > 0 ? `<p class="field-help">${additionalWarnings} additional warning(s) were generated during conversion. They will be preserved with the imported diagram.</p>` : ''}
        <div class="discovery-actions discovery-preview-actions">
          <button type="button" class="btn" id="replaceWithDiscoveryBtn">Replace current diagram</button>
          <button type="button" class="btn primary" id="createDiscoveryProjectBtn">Save as new diagram</button>
        </div>
        <p class="field-help">Replace overwrites the open diagram after confirmation. Save as new keeps this diagram and creates a separate project.</p>
      </div>`;
      modalMode = null;
      showModal('Review discovery results', 'Inspect the proposed import before changing any saved project.', body, 'Close');
      $('modalSubmit').hidden = true;
      $('replaceWithDiscoveryBtn').onclick = () => applyDiscoveryImport(false);
      $('createDiscoveryProjectBtn').onclick = () => applyDiscoveryImport(true);
    } catch (error) {
      toast(error.message || 'This file is not a supported discovery snapshot.');
    }
  }

  let discoveryImportApplying = false;

  async function applyDiscoveryImport(asNewProject) {
    if (discoveryImportApplying) return;
    if (saveInFlight) {
      toast('The current diagram is still saving. Try the import again when the save finishes.');
      return;
    }
    if (!pendingDiscoveryImport?.project) {
      toast('Load a discovery snapshot before importing.');
      return;
    }
    if (!asNewProject && !confirm('Replace the current diagram with these discovery results? Export a JSON backup first if you need to keep the current version.')) return;

    discoveryImportApplying = true;
    const actionButtons = [$('replaceWithDiscoveryBtn'), $('createDiscoveryProjectBtn')].filter(Boolean);
    actionButtons.forEach((button) => {
      button.disabled = true;
      button.textContent = 'Saving…';
    });

    try {
      clearTimeout(saveTimer);
      await saveCloud();
      if (['Save failed', 'Save conflict — reload this diagram', 'Could not open diagram'].includes($('saveStatus').textContent)) {
        toast('The current diagram could not be saved safely. Resolve the save issue before importing discovery results.');
        actionButtons.forEach((button, index) => {
          button.disabled = false;
          button.textContent = index === 0 ? 'Replace current diagram' : 'Save as new diagram';
        });
        return;
      }

      const importedProject = pendingDiscoveryImport.project;
      if (asNewProject) {
        serverProjectId = null;
        serverProjectRevision = 1;
        history.replaceState({}, '', '/mapper.html');
      }
      project = importedProject;
      selected = null;
      $('projectName').value = project.projectName;
      setViewMode(project.physicalLinks.length ? 'physical' : (project.vlans.length ? 'logical' : 'physical'));
      renderSidebar();
      renderInspector();
      drawDiagram();
      pendingDiscoveryImport = null;
      closeModal();
      markDirty();
      clearTimeout(saveTimer);
      await saveCloud();

      if ($('saveStatus').textContent === 'Saved to your account') {
        toast(asNewProject ? 'Discovery topology saved as a new diagram' : 'Discovery topology imported and saved');
      } else {
        toast('Discovery topology is loaded, but the cloud save failed. Check the save status and export a JSON backup.');
      }
    } finally {
      discoveryImportApplying = false;
    }
  }

  function readDiscoverySnapshotFile(file) {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast('Discovery snapshots must be 5 MB or smaller.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      try {
        showDiscoveryPreview(JSON.parse(String(reader.result || '')), file.name);
      } catch (error) {
        toast(error.message || 'Could not read the discovery snapshot JSON.');
      }
    };
    reader.onerror = () => toast('The discovery snapshot file could not be read.');
    reader.readAsText(file);
  }

  function importFile(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const incoming = normalizeProject(JSON.parse(reader.result));
        if (!confirm('Replace the current project with the imported project? Export a backup first if you need to keep this version.')) return;
        project = incoming;
        selected = null;
        $('projectName').value = project.projectName;
        markDirty();
        const nextView = project.physicalLinks.length ? 'physical' : (project.vlans.length ? 'logical' : 'physical');
        setViewMode(nextView);
        toast('Project imported');
      } catch (e) {
        toast(e.message || 'Could not import project file');
      }
    };
    reader.readAsText(file);
  }
  function newProject() {
    if (!confirm('Start a new blank project? Export a JSON backup first if you need to keep the current diagram.')) return;
    project = blankProject();
    selected = null;
    $('projectName').value = project.projectName;
    markDirty();
    setViewMode('physical');
    toast('Blank project created');
  }
  function setViewMode(next) {
    viewMode = next === 'logical' ? 'logical' : 'physical';
    $('physicalViewBtn').setAttribute('aria-pressed', String(viewMode === 'physical'));
    $('logicalViewBtn').setAttribute('aria-pressed', String(viewMode === 'logical'));
    $('canvasTitle').textContent = viewMode === 'physical' ? 'Physical topology' : 'Logical topology';
    $('canvasSubtitle').textContent = viewMode === 'physical' ? 'Map hardware, virtual hosts and cable endpoints. Access/trunk port settings derive the logical view.' : 'Derived from physical port settings plus explicit interfaces. IP addresses and security policy remain manually verified.';
    $('canvasHint').innerHTML = viewMode === 'physical' ? '<span class="key-pill">DRAG</span> move devices <span class="key-pill">CLICK</span> edit properties <span class="key-pill">CONNECT</span> define both ends and port VLAN modes' : '<span class="key-pill">DERIVED</span> VLAN membership from access/trunk ports <span class="key-pill">CLICK</span> edit devices/VLANs <span class="key-pill">CURVES</span> adjust VLAN line style';
    drawDiagram();
    renderSidebar();
    renderInspector();
  }
  function loadExample() {
    if ((project.devices.length || project.vlans.length || project.physicalLinks?.length) && !confirm('Replace the current diagram with the example topology? Export JSON first if you want to keep your work.')) return;
    project = createDemoProject();
    selected = null;
    $('projectName').value = project.projectName;
    markDirty();
    setViewMode('physical');
    renderSidebar();
    renderInspector();
    toast('Physical-first example loaded. Switch to Logical to inspect inferred VLAN membership.');
  }
  function setZoom(v) {
    zoom = Math.max(.55, Math.min(1.5, v));
    $('zoomLabel').textContent = `${Math.round(zoom * 100)}%`;
    drawDiagram();
  }

  function setTheme(next, notify = false) {
    theme = next === 'dark' ? 'dark' : 'light';
    document.body.classList.toggle('dark', theme === 'dark');
    const meta = $('themeColorMeta');
    if (meta) meta.content = theme === 'dark' ? '#212121' : '#ffffff';
    const button = $('themeBtn');
    if (button) {
      button.title = theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme';
      button.setAttribute('aria-label', button.title);
      button.innerHTML = theme === 'dark' ? icons.sun : icons.moon;
    }
    try {
      localStorage.setItem(THEME_KEY, theme);
    } catch (e) { }
    if (project && $('canvasMount')) drawDiagram();
    if (notify) toast(`${theme === 'dark' ? 'Dark' : 'Light'} theme enabled`);
  }
  let guideStep = 0;
  function showGuide() {
    document.querySelector('.app').classList.add('guide-mode');
    $('guideView').hidden = false;
    $('guideBtn').hidden = true;
    $('editorBtn').hidden = false;
    setGuideStep(guideStep);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  function showEditor() {
    document.querySelector('.app').classList.remove('guide-mode');
    $('guideView').hidden = true;
    $('guideBtn').hidden = false;
    $('editorBtn').hidden = true;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  function setGuideStep(step) {
    guideStep = Math.max(0, Math.min(4, Number(step) || 0));
    document.querySelectorAll('[data-guide-pane]').forEach(p => {
      p.hidden = Number(p.dataset.guidePane) !== guideStep;
      p.classList.toggle('active', Number(p.dataset.guidePane) === guideStep);
    });
    document.querySelectorAll('[data-guide-step]').forEach(b => {
      const active = Number(b.dataset.guideStep) === guideStep;
      b.classList.toggle('active', active);
      b.setAttribute('aria-current', active ? 'step' : 'false');
    });
    $('prevGuideBtn').disabled = guideStep === 0;
    $('nextGuideBtn').textContent = guideStep === 4 ? 'Back to the start ↺' : 'Next chapter →';
    $('guideChapterCount').textContent = `Chapter ${guideStep + 1} of 5`;
    $('guideProgressText').textContent = `${guideStep + 1} of 5`;
    $('guideProgressBar').style.width = `${(guideStep + 1) * 20}%`;
  }

  async function init() {
    try {
      const me = await fetch('/api/auth/me', { credentials: 'same-origin' });
      if (!me.ok) {
        location.replace('/login');
        return;
      } if (!serverProjectId) {
        location.replace('/dashboard');
        return;
      } const response = await fetch(`/api/projects/${encodeURIComponent(serverProjectId)}`, { credentials: 'same-origin' });
      if (response.status === 401) {
        location.replace('/login');
        return;
      } if (!response.ok) throw new Error('This diagram could not be opened. Return to My diagrams and try again.');
      const data = await response.json();
      project = normalizeProject(data.project.document);
      serverProjectRevision = data.project.revision;
      project.projectName = data.project.title || project.projectName;
    } catch (e) {
      $('saveStatus').textContent = 'Could not open diagram';
      toast(e.message || 'Unable to load this diagram');
      return;
    } if (!Array.isArray(project.connections)) project.connections = [];
    if (!Array.isArray(project.physicalLinks)) project.physicalLinks = [];
    viewMode = project.physicalLinks.length ? 'physical' : (project.vlans.length ? 'logical' : 'physical');
    $('projectName').value = project.projectName;
    let savedTheme = 'light';
    try {
      savedTheme = localStorage.getItem(THEME_KEY) || 'light';
    } catch (e) { };
    setTheme(savedTheme === 'dark' ? 'dark' : 'light', false);
    setViewMode(viewMode);
    renderSidebar();
    renderInspector();
    drawDiagram();
  }
  $('addVlanBtn').onclick = openAddVlan;
  $('addDeviceBtn').onclick = openAddDevice;
  $('addPhysicalLinkBtn').onclick = () => openAddPhysicalLink();
  $('physicalViewBtn').onclick = () => setViewMode('physical');
  $('logicalViewBtn').onclick = () => setViewMode('logical');
  $('exampleBtn').onclick = loadExample;
  $('newProjectBtn').onclick = () => location.assign('/dashboard?create=1');
  $('myDiagramsBtn').onclick = () => location.assign('/dashboard');
  $('signOutBtn').onclick = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' });
    } finally {
      location.assign('/signed-out');
    }
  };
  $('importBtn').onclick = openImport;
  $('discoveryBtn').onclick = openDiscovery;
  $('discoverySnapshotFile').addEventListener('change', e => {
    readDiscoverySnapshotFile(e.target.files?.[0]);
    e.target.value = '';
  });
  $('importFile').addEventListener('change', e => {
    importFile(e.target.files?.[0]);
    e.target.value = '';
  });
  $('exportJsonBtn').onclick = exportJson;
  $('exportSvgBtn').onclick = exportSvg;
  // Extra diagram export is offered through a small secondary action beside fit view.
  $('fitBtn').insertAdjacentHTML('afterend', '<button class="btn small" id="exportPngBtn" title="Export a PNG image">PNG</button>');
  $('exportPngBtn').onclick = exportPng;
  $('zoomInBtn').onclick = () => setZoom(zoom + .1);
  $('zoomOutBtn').onclick = () => setZoom(zoom - .1);
  $('fitBtn').onclick = () => {
    setZoom(1);
    $('canvasScroller').scrollTo({ left: 0, top: 0, behavior: 'smooth' });
  };
  $('themeBtn').onclick = () => setTheme(theme === 'light' ? 'dark' : 'light', true);
  $('guideBtn').onclick = showGuide;
  $('editorBtn').onclick = showEditor;
  $('startGuideBtn').onclick = () => setGuideStep(0);
  $('finishGuideBtn').onclick = showEditor;
  $('prevGuideBtn').onclick = () => setGuideStep(guideStep - 1);
  $('nextGuideBtn').onclick = () => {
    if (guideStep === 4) setGuideStep(0);
    else setGuideStep(guideStep + 1);
  };
  document.querySelectorAll('[data-guide-step]').forEach(b => b.addEventListener('click', () => setGuideStep(b.dataset.guideStep)));
  $('projectName').addEventListener('change', () => {
    project.projectName = $('projectName').value.trim() || 'Untitled network topology';
    markDirty();
  });
  $('modalForm').addEventListener('submit', submitModal);
  $('modalClose').onclick = closeModal;
  $('modalCancel').onclick = closeModal;
  $('modalBackdrop').addEventListener('click', e => {
    if (e.target === $('modalBackdrop')) closeModal();
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeModal();
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      exportJson();
    }
  });
  $('modalBody').addEventListener('change', e => {
    if (e.target.name === 'vlanIds') syncInterfaceRows();
  });
  $('explorerBtn').onclick = () => {
    $('sidebar').classList.toggle('open');
  };
  $('sidebarClose').onclick = () => $('sidebar').classList.remove('open');
  $('inspectorBtn').onclick = () => $('inspector').classList.toggle('open');
  $('inspectorClose').onclick = () => $('inspector').classList.remove('open');
  init();
})();
