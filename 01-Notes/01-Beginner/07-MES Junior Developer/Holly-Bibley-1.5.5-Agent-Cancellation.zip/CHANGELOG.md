# Changelog

## 1.5.5 — In-progress discovery cancellation

- Added `AbortSignal` propagation through the local subnet collector. Revocation or lease loss stops in-flight ping processes, prevents new probes from starting, and skips neighbour-table collection.
- Added abortable SNMP callback wrappers. Cancellation closes the active SNMP session and stops polling later switch targets.
- Agent heartbeats now run every five seconds, avoid overlapping requests, and abort the active collector when the server rejects the job lease with HTTP 401/404.
- The persistent agent now exits instead of retrying forever when the server rejects a revoked/invalid token.
- Added three regression tests for local-scan cancellation, in-flight SNMP session closure, and stopping before later switch targets. Added checks for lease-loss cancellation and revoked-agent shutdown.
- Verification: `npm run check:mapper` passes with **82 tests, 0 failures**. Production build and live database/network tests are still blocked in this workspace because external package downloads are unreachable and no PostgreSQL/container runtime or lab switch is available.

## 1.5.4 — Atomic agent revocation and lease preflight

- Agent revocation and cancellation of queued/running jobs now commit in one PostgreSQL transaction. Cancellation clears the lease expiry/token, preventing a late completion from being accepted.
- Job claiming now re-locks and verifies the agent's active state inside the claim transaction, closing the middleware-to-claim revocation race.
- The local agent confirms its lease with a heartbeat before beginning a subnet or SNMP discovery operation. Explicit HTTP 401/404 responses are retained so revoked/expired work is not misreported as an ordinary discovery failure.
- Expanded the guarded HTTP/PostgreSQL integration scenario to claim a second synthetic job, revoke the agent, and assert the job is cancelled, has no snapshot, and cannot heartbeat or claim again.
- Added regression checks for transactional revocation and the pre-scan lease check. `npm run check:mapper`: **79 tests passed, 0 failed**.
- Production build and live HTTP/PostgreSQL execution remain unverified in this workspace: npm registry DNS resolution returns `EAI_AGAIN`, Vite/Express/pg are not installed, and no local PostgreSQL service or container runtime is available.

## 1.5.3 — Release-test consistency and verification status

- Corrected two stale tests that still required a bundled `.env` file and a machine-specific LAN IP, despite the 1.5.2 source package intentionally excluding `.env`.
- Updated the README so local configuration and credential guidance consistently describes `.env.example`-based first-run setup.
- Confirmed `npm run check:mapper` passes: 77 tests passed, 0 failed, including JavaScript syntax checks.
- Attempted dependency installation, but it timed out in this environment; `npm run build` remains blocked because Vite is not installed. There is no local PostgreSQL server, `psql`, Docker or Podman available here, so the live API/database test cannot be truthfully marked complete.

## 1.5.2 — Lease-expiry correctness and release safety

- Heartbeat, completion, and failure updates now require the currently assigned lease to remain unexpired. A worker whose lease expired can no longer extend or finish a job after ownership should have lapsed.
- Added regression tests guarding the lease-expiry condition on all three transport operations and the integration test harness opt-in guard.
- Added a guarded real-HTTP/PostgreSQL lifecycle test command that only accepts a loopback database with `test` in its name; the live run remains pending because dependencies and a PostgreSQL service are unavailable here.
- Source release packaging for this version omits the machine-local `.env`; first startup can generate one from `.env.example`, avoiding accidental distribution of per-machine settings.
- Verification note: the original 1.5.2 ZIP contained two stale local-configuration tests that still expected a bundled `.env` and fixed LAN IP. Version 1.5.3 updates those tests to match the documented safer packaging behaviour.

## 1.5.1 — Verification hardening

- Fixed lease recovery so a running job with a missing/null lease expiry can be reclaimed instead of remaining stuck.
- Job status reads now enforce the documented 24-hour retention window directly, not only through periodic cleanup.
- The agent picker now labels agents as recently active, stale, or never connected and summarizes recent activity.
- Added regression checks for the lease-recovery and retention query conditions and the presence-status UI.
- Verification: `npm run check:mapper` passes with 75 tests. `npm run build` remains blocked because dependency installation cannot reach the npm registry in this environment (`EAI_AGAIN`). No live PostgreSQL or managed-switch test was available.


## 1.5.0 — Persistent local discovery agent

- Added account-owned discovery-agent pairing using expiring one-time pairing codes and random bearer tokens hashed at rest.
- Added secure outbound agent polling, leased jobs with claim tokens, heartbeat renewal, result validation, agent revocation, and short-lived discovery job retention.
- Added mapper controls to pair/refresh/revoke agents and submit either local private-subnet or explicit SNMPv3 switch discovery jobs without manually importing a JSON file.
- Added a cross-platform agent CLI that stores its token in a per-user configuration location and uses the existing collectors; switch credentials remain on the agent machine.
- Added automated validation for target scope, pairing data, URLs, claim identifiers, and snapshot sizes.
- Corrected the mapper auto-save version marker to match the current version-6 topology schema.
- Verification: 73 automated tests passed in the current workspace; production build and live-device execution remain unverified because project dependencies are not installed in this environment.


## 1.4.0 — SNMPv3 switch discovery (2026-10-28)
- Added a read-only SNMPv3 `authPriv` switch collector using the `net-snmp` library; no SNMP Set operations or SNMPv1/v2c fallback are used.
- Added explicit private IPv4 management targets (maximum 64), bounded per-request timeouts, secure environment-only credential inputs, and snapshot output that never includes passphrases.
- Added IF-MIB interface inventory (name, status, speed and physical address where available), Q-BRIDGE-MIB VLAN names and egress/untagged membership, BRIDGE-MIB port-to-ifIndex mapping, IP-MIB interface addresses, and LLDP neighbour discovery where exposed by devices.
- Added conservative port-mode inference from VLAN membership bitmaps. Access/trunk interpretations are labelled inferred and warn that the running configuration was not read.
- Added LLDP-advertised link candidates, de-duplication across polled neighbours, and inferred non-polled neighbours without inventing their management IP addresses.
- Added `npm run discover:switches`, SNMPv3 setup/safety documentation and mock-network tests for target validation, credential policy, VLAN bitmap decoding, interfaces, LLDP links, session closure, partial results and discovery-import compatibility.
- Live hardware behaviour and the full Vite production build remain to be verified on an authorised lab network after installing dependencies; active scans must follow OT safety/change controls.

## 1.3.0 — Local IPv4 discovery agent (2026-10-28)
- Added a cross-platform Node.js CLI to list local IPv4 interfaces and discover one explicitly selected directly attached private IPv4 subnet.
- Added a CIDR validator that requires an RFC 1918 private scope contained in a local interface network, rejects ambiguous interface selection, and caps each run at 256 addresses.
- Added bounded-concurrency, rate-limited single-ICMP probes and Windows/Linux/macOS neighbour-cache parsing to capture observed IP/MAC inventory.
- Added compatible version-1 discovery snapshot output that can be imported through the existing Discover network → Import snapshot JSON UI. Unresponsive hosts are not invented; ARP-only observations are marked inferred.
- Added an in-app local-agent guide, CLI usage documentation, and unit tests for subnet containment, safety bounds, ARP parsing, snapshot output and scan orchestration.
- The local agent does not query switches or infer VLANs, switch ports, firewall rules or physical links. Live scanning is not run as part of the automated tests; production/OT use requires authorisation and site safety/change controls.

## 1.2.0 — LibreNMS read-only import (2026-10-28)
- Added an optional, deployment-configured LibreNMS connector that imports monitored devices, port data, reported VLAN associations, interface IPs, and discovered neighbor links into the existing discovery snapshot pipeline.
- Added read-only API status, connection-test, and snapshot endpoints. The connector never accepts a user-supplied host or token, requires an email allowlist, limits request rates and import size, and requires HTTPS in production.
- Added conservative handling for unknown interface/VLAN relationships and neighbor details, with explicit warnings instead of fabricated configuration.
- Retained canonical version-6 interface data when VLAN membership is unknown, without rendering those interfaces as logical VLAN membership.
- Added mock-API tests for access control, authentication, device/port/VLAN/IP/link conversion, API failure paths, and conversion compatibility.

## 1.1.9 — Discovery import foundation (2026-10-28)
- Added a versioned, adapter-neutral discovery snapshot format and a documented sample file. The built-in sample is clearly marked as synthetic documentation data; it does not scan any live network.
- Added a Network Discovery review workflow to validate a snapshot, inspect device/VLAN/link counts and warnings, and either replace the open diagram or save the generated topology as a new diagram.
- Added conversion into Holly Bibley's canonical model, including device MAC addresses, management IPs, port modes/status/speed, VLANs, interfaces, physical links, source details, observation time and confidence labels.
- Bumped the canonical project document to version 6 so interface metadata without a confirmed VLAN can be retained without inventing logical VLAN membership. Older diagrams are normalized forward while preserving their devices, VLANs and physical connections.
- Added model/converter regression tests for malformed snapshots, missing endpoints, unknown VLANs and types, logical VLAN inference, provenance retention and legacy project migration.
- Live network scanning and LibreNMS integration were not included in this release; the connector is optional and is disabled until configured by a server administrator.

## 1.1.8
- Disabled email verification for account creation and sign-in. New accounts are marked active and signed in immediately after successful registration.
- In development, password-reset links are still printed in the API terminal and now automatically open in a new browser tab on the computer running the API.
- Kept automatic browser opening disabled in production; production password resets continue to use configured email delivery.

## 1.1.6 — LAN-ready package

- Preconfigured local-network access for `10.10.22.76` on Vite port `5173`.
- Set `HB_LAN_HOST`, `APP_ORIGIN`, and `PUBLIC_APP_URL` consistently in the included `.env`.
- Updated setup instructions with the exact share URL and a Windows Private-profile firewall rule.
- Kept the API and PostgreSQL bound to localhost; only the frontend port is intended to be reachable from trusted LAN clients.

## 1.1.4 — Minimal text-first device cards

- Removed externally hosted Cisco-style and server image artwork from physical and logical topology cards.
- Returned device representation to text-first cards with role-colored accent strips; host/VM grouping, port labels, VLAN memberships, remote links and selection remain unchanged.
- Removed the unused external artwork module and its attribution folder; the topology no longer depends on third-party SVG image URLs.
- Kept small utility glyphs in the application interface; the change applies to device artwork in topology canvases.
- Added a regression test ensuring physical/logical renderers do not import or render image-based device artwork.
- Updated source documentation and bumped the project version to 1.1.4.

## 1.1.3 — Local PostgreSQL password recovery

- Includes a local `.env` configured with the requested `123password` password for the bundled development database.
- Keeps `DATABASE_URL` and Docker Compose `POSTGRES_PASSWORD` aligned in both `.env` and `.env.example`.
- Development startup now attempts a local Compose-only role-password synchronization after `28P01` authentication failures, then retries PostgreSQL before migrations and API startup.
- The password synchronizer validates host, port, database, role and matching password values before running `ALTER ROLE`; it never drops a database or volume.
- Documents the local-only nature of the default credential and recovery commands.

## 1.1.2 — 2026-10-26

- Fixed diagram opening from the dashboard, new-diagram flow, and JSON import. These actions now perform a full document navigation to the standalone `/mapper.html` entry point instead of asking React Router to render it as an SPA route.
- Added a regression test guarding the static mapper hand-off.
- Added a defensive `/mapper.html` route hand-off so accidental SPA navigation reloads the real static mapper instead of showing the catch-all page.
- Added regression tests for React Router links, navigation targets, and the static mapper hand-off.
- No database schema changes; existing data and migration state are preserved.
- Validation: `npm test` and `npm run check:mapper` pass (19 tests); a full Vite production build remains unverified because dependency installation timed out in the authoring environment.

## 1.1.0 — 2026-10-23

### Physical-first topology

- Added/retained a physical topology view for actual devices, cables, endpoint ports, cable media, and access/trunk configurations.
- Derived the logical topology from the same saved project model instead of maintaining a separate manually drawn logical copy.
- Kept inference deliberately conservative: access/access assignments must agree; trunk-to-trunk inference uses only the allowed VLAN intersection; access-to-trunk ambiguity and routed links do not invent Layer 2 membership.
- Preserved explicit firewall interface addresses when the virtual firewall is contained in an ESXi/server group; virtual interface associations are rendered outward to the appropriate logical VLANs.

### Icons and code structure

- Added device-role icon mappings for common Cisco routers, switches, Nexus/core switches and ASA firewalls, plus VMware/server/client artwork and labelled fallbacks.
- Separated project modeling, device catalog/icon mapping, physical rendering, logical rendering, forms, inspector/sidebar, exports, and editor UI icons into individual modules.
- Added Prettier configuration and repeatable `format`, `format:check`, `check:mapper`, and `check` scripts.
- Fixed the physical-link endpoint/port form to keep source/target choices distinct and refresh each side's own port inventory.
- Added dependency-free tests for model inference, safe handling of uncertain port combinations, module references, device icon mappings, and dynamic UI hooks.

### Verification status

- `npm run check:mapper`: 13 tests passed, with JavaScript syntax checks passing.
- React JSX files passed a TypeScript transpilation/syntax smoke check.
- The Vite production build was not completed in the authoring environment because dependencies were not installed (`vite` was unavailable). Install dependencies and run `npm run check` locally for the production build.

## 1.1.1 — Local database startup and signup recovery

- `npm run dev` now creates a missing local `.env` from the example, checks PostgreSQL, attempts to start the bundled Compose database when appropriate, applies schema migrations, then starts the web and API processes.
- The API listener no longer waits for the database to be reachable before binding port 3001.
- Health checks and API errors return actionable HTTP 503 PostgreSQL diagnostics without exposing credentials.
- Added `npm run db:doctor`, database recovery documentation, and regression tests for connection, authentication and schema errors.
- Setup does not delete or reset the existing PostgreSQL volume.


## 1.1.5 — Local network sharing

- Vite binds to `0.0.0.0:5173` so trusted computers on the same LAN can reach the frontend.
- Development launcher detects a private IPv4 address and sets the runtime origin and email-verification/reset URL to the shareable LAN URL. `HB_LAN_HOST` supports hosts with multiple adapters.
- API remains bound to loopback in development and PostgreSQL remains loopback-only.
- Development origin checks continue to permit localhost access on the host computer.
- README documents the Windows Private firewall rule and warns against exposing API/database ports.

## 1.1.7 — Mobile and installability pass

- Added the supplied transparent `Angel.png` to the landing page and included it in the project assets.
- Added a web app manifest, Android install icons, Apple touch icon metadata, and a minimal service worker.
- Kept authentication, API requests, and saved diagrams out of the service-worker cache.
- Improved phone layouts, touch targets, safe-area padding, and the topology editor's narrow-screen layout.
- Expanded the README with phone installation, HTTPS, LAN address, and formatting instructions.
- Reformatted the CSS files into editable multi-line rules.
