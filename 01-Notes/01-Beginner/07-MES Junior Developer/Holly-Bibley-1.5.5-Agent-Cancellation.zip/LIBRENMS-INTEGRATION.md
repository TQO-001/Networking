# LibreNMS integration for Holly Bibley

Holly Bibley can optionally import the monitored inventory from one administrator-configured LibreNMS instance. This is a **read-only inventory importer**, not a general network scanner and not a promise to discover every device. The integration imports what the configured LibreNMS account can see and what LibreNMS has already learned.

## What is imported

- Monitored device names, management IPs, vendor/model hints and selected metadata.
- Interface/port names, operational status, speed, descriptions, and reported VLAN associations when LibreNMS returns them.
- IP interface addresses exposed by the LibreNMS device-IP endpoint.
- VLAN IDs and names exposed by the LibreNMS VLAN endpoint.
- Neighbour relationships from LibreNMS's discovered link inventory, including local/remote port names where available.

The imported data passes through Holly Bibley's versioned discovery snapshot converter before it becomes an editable topology. Incomplete data produces warnings. A trunk's allowed VLAN list is not treated as proof that an IP interface belongs to one particular VLAN; unknown assignments are retained without being forced into the logical view.

## Requirements

- A reachable LibreNMS instance with its API enabled.
- A LibreNMS API token belonging to a dedicated account with the minimum read permissions your LibreNMS setup supports.
- Holly Bibley running on a server that can reach the LibreNMS API.
- HTTPS for the configured LibreNMS API when Holly Bibley runs in production.

LibreNMS documents API authentication using a bearer token. Its device endpoints expose device inventories, ports and IP address data, while switching-resource endpoints expose VLAN and neighbour-link information. Actual response coverage depends on the LibreNMS version, device polling support, configured protocols and account permissions.

## Configure the deployment

Set these variables in the server process environment or your secret manager. They are listed blank in `.env.example` intentionally; never put a live token in source control, a client-side environment variable, or frontend JavaScript.

```dotenv
LIBRENMS_BASE_URL=https://monitoring.example.com
LIBRENMS_API_TOKEN=replace-with-a-real-token-in-the-server-secret-store
LIBRENMS_ALLOWED_EMAILS=network.engineer@example.com,admin@example.com
LIBRENMS_MAX_DEVICES=100
LIBRENMS_REQUEST_TIMEOUT_MS=8000
```

`LIBRENMS_BASE_URL` is the LibreNMS instance base URL; do not append `/api/v0`. A LibreNMS installation under a URL path is supported (for example, `https://monitoring.example.com/librenms`). Production configuration requires HTTPS. The connector does not allow a signed-in user to specify a URL, hostname, port, path, or token, preventing the API routes from being used as an arbitrary internal-network proxy.

`LIBRENMS_ALLOWED_EMAILS` is a comma-separated allowlist of Holly Bibley login email addresses. Matching is case-insensitive. If this variable is blank, no user receives access. This controls which Holly Bibley users may view/import the configured LibreNMS inventory; it does not replace authorization inside LibreNMS.

`LIBRENMS_MAX_DEVICES` defaults to 100 and is clamped to a maximum of 300 devices per import. `LIBRENMS_REQUEST_TIMEOUT_MS` defaults to 8000 milliseconds and is clamped to 1000–20000 milliseconds. Discovery POST endpoints are rate-limited. If the device list reaches the cap, the import includes a warning. Optional VLAN and link endpoint failures result in a partial inventory and explicit warnings instead of failing the entire device import.

Restart the API/server process after changing the environment. In the Holly Bibley editor, open **Discover network**. If the logged-in user's email is allowlisted and configuration is complete, the **Test connection** and **Import from LibreNMS** actions appear. Test the connection first, then import and review the resulting snapshot and warnings before saving a diagram.

## API access and data flow

The server calls the configured origin using the bearer token and performs read-only GET requests to the LibreNMS API. The token is never returned to the browser. The connector reads monitored devices, per-device port/VLAN data, per-device IP data, VLAN inventory, and discovered links; it does not configure network devices.

Holly Bibley's routes are:

- `GET /api/discovery/librenms/status` — returns whether this integration is available to the logged-in account without revealing secrets.
- `POST /api/discovery/librenms/test` — verifies that the configured API can be reached and authenticated.
- `POST /api/discovery/librenms/snapshot` — reads the monitored inventory and returns an adapter-neutral snapshot for review/import.

All three routes require Holly Bibley authentication. The two POST routes are rate-limited. No endpoint accepts target hosts or credentials from the request body.

## Important limitations

- This connector imports devices returned by the configured LibreNMS inventory, subject to the configured cap; it does not yet provide a LibreNMS-specific subnet/VLAN selector. The separate local CLI (`node scripts/discover-network.js`) can perform a bounded, explicitly scoped ICMP/ARP discovery on a directly attached private IPv4 subnet, but it does not query switches or replace this connector's richer inventory.
- A device not monitored by LibreNMS may be visible as a neighbour if a switch reports it through a supported discovery protocol, but that does not guarantee the device's address, model, ports or VLANs can be filled in.
- Port/VLAN associations may be missing or differ by vendor and polling support. Interface IPs are not assigned to a VLAN unless the association is unambiguous under the current importer rules.
- The connector does not retrieve or infer firewall ACL/policy rules, every switch's running configuration, all MAC forwarding entries, or the full physical cabling map.
- A link reported by LLDP/CDP is useful evidence, but labels and confidence should still be checked against the device's configuration and physical environment.
- This is not a safe substitute for a site change process. Avoid introducing new active probes against OT devices; this integration reads LibreNMS data, but LibreNMS's own collection and polling settings still need to follow the site's approved change/safety process.
- If importing a large monitored estate, use a narrower LibreNMS inventory/account where possible and review the returned warnings before treating the result as authoritative.

## Troubleshooting

- **Integration unavailable:** confirm all three required environment variables are configured and restart the server.
- **Not enabled for this account:** make sure the signed-in email appears in `LIBRENMS_ALLOWED_EMAILS`.
- **Authentication denied:** verify the token and the LibreNMS account's API permissions. Errors intentionally do not echo the token or raw upstream response bodies.
- **Cannot reach LibreNMS:** verify DNS, routing and firewall rules from the Holly Bibley server to the configured origin. Do not expose LibreNMS to the public internet merely to make integration work; prefer private routing or an approved secure connection.
- **Missing VLAN/port/link information:** check that LibreNMS has successfully polled the devices, that the relevant discovery protocols are enabled and permitted, and that the account can see the needed records.
- **Import reaches device cap:** lower the scope of the monitored inventory or intentionally increase `LIBRENMS_MAX_DEVICES` up to 300, then review diagram performance before using the larger import.
