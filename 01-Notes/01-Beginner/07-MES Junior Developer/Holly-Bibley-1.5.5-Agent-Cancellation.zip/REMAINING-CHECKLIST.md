# Holly Bibley 1.5.5 — Remaining Acceptance Checklist

This checklist records only checks performed in this workspace. Passing mocked/unit tests is not treated as proof of a live API, database, or network-device run.

## Completed

- [x] Discovery snapshots convert into Holly Bibley's canonical version-6 topology model and can be previewed/imported.
- [x] LibreNMS inventory import and local subnet/SNMPv3 collectors are implemented.
- [x] Paired local agent APIs implement one-time pairing, owner-scoped jobs, leases, result validation, retention and revocation.
- [x] Agent revocation and outstanding-job cancellation now commit in one PostgreSQL transaction; active claims re-check the agent row under lock.
- [x] Agent confirms its lease before starting subnet or SNMP discovery.
- [x] Five-second lease heartbeats detect lost/revoked jobs without overlapping heartbeat requests.
- [x] Lease loss aborts local ICMP child processes or closes active SNMP sessions, and prevents later probes/targets.
- [x] Persistent agent stops retrying when the server rejects an invalid/revoked agent token.
- [x] Guarded HTTP/PostgreSQL integration harness now covers an outstanding job being cancelled by revocation and rejects later heartbeat/claim attempts (live run not yet executed).
- [x] Machine-local `.env` excluded from source release; `.env.example` used for first-run config.
- [x] `npm run check:mapper`: **82 passed, 0 failed**, including syntax checks.
- [x] Release ZIP integrity checked; no `.env` or `node_modules` bundled.

## Remaining acceptance gates

- [ ] **Production build:** run `npm install` successfully and pass `npm run build` / `npm run check`.
- [ ] **Live application integration:** run `npm run test:discovery-integration` against a dedicated loopback PostgreSQL database whose name contains `test`; verify the full API/database lifecycle over HTTP.
- [ ] **Real network lab:** verify subnet discovery on authorised Windows/Linux networks and compare SNMPv3 interface, VLAN and LLDP results against at least one managed lab switch.
- [ ] **Release readiness:** validate config-file permissions and cancellation/reconnect behaviour in a live deployment; complete deployment-security plus OT change/safety review. The code-level cancellation/shutdown regression tests now pass.

## Evidence and limitations

- `npm run check:mapper` — passed, 82 tests.
- `npm run build` — expected to fail in this workspace with `vite: not found`; Vite is not installed.
- `registry.npmjs.org` DNS lookup — `EAI_AGAIN`; npm cache is empty and dependency installation cannot complete in this environment.
- PostgreSQL port `127.0.0.1:5432` is closed; no `psql`, `postgres`, Docker or Podman executable is available.
- No live PostgreSQL-backed HTTP lifecycle has completed.
- No real switch or production OT network has been scanned.
- Revocation atomically cancels a job and stops accepted results. The local agent now heartbeats every five seconds and propagates lease loss as an abort signal: in-flight ping commands are terminated, the active SNMP session is closed, and later probes/targets are not started. This behaviour is unit-tested; the real server/agent/database cancellation path still requires the blocked live integration run.
