# Holly Bibley tests

Run from the project root with `npm test`. Tests use Node's built-in test runner and do not require PostgreSQL, Vite, or third-party test dependencies.

The tests cover:

- The physical-first project schema and import normalization.
- Access-port inference, VLAN trunk intersections, contradictory access VLANs, access-to-trunk ambiguity, and routed-port behavior.
- Nested ESXi/VM/firewall containment while preserving explicit firewall interface addresses.
- VLAN curve styles, physical-link validity, local module paths, text-first device cards without external image artwork, and dynamic editor element hooks.

Use `npm run check:mapper` to syntax-check the mapper and API JavaScript modules, then run the model and source-structure tests. Once project dependencies are installed, `npm run check` also performs the production Vite build.
