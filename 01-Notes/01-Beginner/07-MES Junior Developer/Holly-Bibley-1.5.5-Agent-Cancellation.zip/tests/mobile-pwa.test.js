import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';

const read = (path) => readFileSync(new URL(path, import.meta.url), 'utf8');

test('PWA manifest includes valid install icons and standalone display', () => {
  const manifest = JSON.parse(read('../public/manifest.webmanifest'));
  assert.equal(manifest.display, 'standalone');
  assert.ok(manifest.icons.some((icon) => icon.sizes === '192x192'));
  assert.ok(manifest.icons.some((icon) => icon.sizes === '512x512'));
  assert.ok(existsSync(new URL('../public/icons/holly-bibley-192.png', import.meta.url)));
  assert.ok(existsSync(new URL('../public/icons/holly-bibley-512.png', import.meta.url)));
});

test('landing page uses the supplied angel artwork and responsive viewport metadata', () => {
  const app = read('../src/App.jsx');
  const html = read('../index.html');
  assert.match(app, /src="\/assets\/Angel\.png"/);
  assert.ok(existsSync(new URL('../public/assets/Angel.png', import.meta.url)));
  assert.match(html, /viewport-fit=cover/);
  assert.match(html, /manifest\.webmanifest/);
});

test('service worker does not cache account API responses', () => {
  const worker = read('../public/service-worker.js');
  assert.match(worker, /url\.pathname\.startsWith\('\/api\/'\)/);
  assert.match(worker, /request\.method !== 'GET'/);
  assert.match(worker, /APP_SHELL/);
});

test('mobile editor rules provide narrow-screen layout and safe-area padding', () => {
  const css = read('../public/mapper.css');
  assert.match(css, /@media \(max-width: 760px\)/);
  assert.match(css, /env\(safe-area-inset-bottom\)/);
  assert.match(css, /\.canvas-stage/);
});
