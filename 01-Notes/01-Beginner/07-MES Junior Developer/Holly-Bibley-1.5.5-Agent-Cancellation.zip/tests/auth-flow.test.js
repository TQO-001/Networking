import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const server = await readFile(new URL('../server/index.js', import.meta.url), 'utf8');
const app = await readFile(new URL('../src/App.jsx', import.meta.url), 'utf8');

test('signup activates the account and creates a session without email verification', () => {
  assert.match(server, /INSERT INTO users\(display_name,email,password_hash,email_verified_at\) VALUES\(\$1,\$2,\$3,now\(\)\)/);
  assert.match(server, /await createSession\(user\.id, req, res\);\s*res\.status\(201\)\.json\(\{ user: safeUser\(user\)/);
  assert.doesNotMatch(server, /if \(!user\.email_verified_at\) return res\.status\(403\)/);
  assert.doesNotMatch(server, /AND u\.email_verified_at IS NOT NULL LIMIT 1/);
});

test('signup UI proceeds directly to the dashboard', () => {
  assert.match(app, /api\('\/api\/auth\/signup'[\s\S]*?navigate\('\/dashboard', \{ replace: true \}\)/);
});

test('development password-reset link is opened automatically in a new browser tab', () => {
  assert.match(server, /function openDevelopmentLink\(url\)/);
  assert.match(server, /openDevelopmentLink\(url\)/);
  assert.match(server, /command = 'cmd';[\s\S]*?args = \['\/c', 'start', '', url\]/);
  assert.match(server, /if \(IS_PROD\) return;/);
});
