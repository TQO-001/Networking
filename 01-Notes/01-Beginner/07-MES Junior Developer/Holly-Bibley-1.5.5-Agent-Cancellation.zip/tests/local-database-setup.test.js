import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const root = process.cwd();

function parseEnv(text) {
  return Object.fromEntries(
    text
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line && !line.startsWith('#') && line.includes('='))
      .map((line) => {
        const index = line.indexOf('=');
        return [line.slice(0, index), line.slice(index + 1)];
      }),
  );
}

test('downloadable source excludes machine-local .env and example credentials are internally consistent', () => {
  assert.equal(existsSync(resolve(root, '.env')), false, 'the downloadable source must not bundle machine-local configuration');
  const env = parseEnv(readFileSync(resolve(root, '.env.example'), 'utf8'));
  const url = new URL(env.DATABASE_URL);
  const gitignore = readFileSync(resolve(root, '.gitignore'), 'utf8');

  assert.match(gitignore, /^\.env$/m, '.env must remain excluded from version control');
  assert.equal(env.NODE_ENV, 'development');
  assert.equal(env.POSTGRES_USER, 'holly_bibley');
  assert.equal(env.POSTGRES_DB, 'holly_bibley');
  assert.equal(env.POSTGRES_PASSWORD, '123password');
  assert.equal(decodeURIComponent(url.password), env.POSTGRES_PASSWORD);
  assert.equal(decodeURIComponent(url.username), env.POSTGRES_USER);
  assert.equal(decodeURIComponent(url.pathname.slice(1)), env.POSTGRES_DB);
  assert.equal(url.hostname, '127.0.0.1');
  assert.equal(url.port, '5432');
});

test('.env.example defaults are internally consistent for first-run startup', () => {
  const env = parseEnv(readFileSync(resolve(root, '.env.example'), 'utf8'));
  const url = new URL(env.DATABASE_URL);

  assert.equal(env.POSTGRES_PASSWORD, '123password');
  assert.equal(decodeURIComponent(url.password), env.POSTGRES_PASSWORD);
  assert.equal(decodeURIComponent(url.username), env.POSTGRES_USER);
  assert.equal(decodeURIComponent(url.pathname.slice(1)), env.POSTGRES_DB);
});

test('dev startup has an authentication-failure recovery path before migrations', () => {
  const source = readFileSync(resolve(root, 'scripts/dev-preflight.js'), 'utf8');
  assert.match(source, /async function recoverLocalAuthentication\(/);
  assert.match(source, /diagnostic\?\.code !== 'DATABASE_AUTH_FAILED'/);
  assert.match(source, /syncLocalDatabasePassword\(\)/);
  assert.match(source, /await probeConnectionString\(\)/);
  assert.match(source, /HB_SKIP_DOCKER_DB/);
  assert.match(source, /Applying safe, additive schema migrations/);
});

test('password synchronizer restricts itself to localhost and matching database credentials', () => {
  const source = readFileSync(resolve(root, 'scripts/db-sync-local-password.js'), 'utf8');
  assert.match(source, /localHosts\.has\(host\)/);
  assert.match(source, /port !== 5432/);
  assert.match(source, /DATABASE_URL username must match POSTGRES_USER/);
  assert.match(source, /DATABASE_URL database name must match POSTGRES_DB/);
  assert.match(source, /DATABASE_URL password must match POSTGRES_PASSWORD/);
  assert.match(source, /ALTER ROLE/);
  assert.doesNotMatch(source, /docker', 'compose', 'down', '-v/);
});


test('LAN access is configurable and does not embed a machine-specific IP address', () => {
  const envText = readFileSync(new URL('../.env.example', import.meta.url), 'utf8');
  const preflight = readFileSync(resolve(root, 'scripts/dev-preflight.js'), 'utf8');
  assert.match(envText, /^HB_LAN_MODE=1$/m);
  assert.match(envText, /^HB_LAN_HOST=$/m, 'blank host uses automatic private-IPv4 detection');
  assert.match(envText, /^APP_ORIGIN=http:\/\/127\.0\.0\.1:5173$/m);
  assert.doesNotMatch(envText, /10\.10\.22\.76/);
  assert.match(preflight, /function findLanIPv4\(\)/);
  assert.match(preflight, /process\.env\.HB_LAN_HOST/);
  assert.match(preflight, /process\.env\.APP_ORIGIN = origin/);
});
