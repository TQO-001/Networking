import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { discoverySnapshotToProject, normaliseDiscoverySnapshot } from '../public/mapper/discovery-import.js';
import { deriveLogicalProject, normalizeProject } from '../public/mapper/project-model.js';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const readSample = () => JSON.parse(readFileSync(resolve(root, 'public/mapper/discovery-sample.json'), 'utf8'));

test('sample discovery snapshot converts to an editable version-6 Holly Bibley project', () => {
  const { project, snapshot, summary } = discoverySnapshotToProject(readSample());
  assert.equal(snapshot.source.adapter, 'fixture');
  assert.equal(project.version, 6);
  assert.equal(project.schema, 'holly-bibley-project');
  assert.equal(summary.devices, 5);
  assert.equal(summary.vlans, 2);
  assert.equal(summary.links, 4);
  assert.ok(summary.warnings >= 1, 'the synthetic-data warning must remain visible');
  assert.equal(project.discovery.scope.cidr, '192.0.2.0/24');
  assert.equal(project.devices.find((device) => device.hostname === 'PLC-01').macAddress, '02:00:00:00:40:35');
  assert.equal(project.devices.find((device) => device.hostname === 'SW-OT-01').ports.find((port) => port.name === 'Gi1/0/5').accessVlanId, 'disc-vlan-20');
  assert.equal(project.physicalLinks.find((link) => link.id === 'disc-link-ot-switch-to-plc').discoveryConfidence, 'confirmed');
});

test('logical derivation uses imported access-port data without inventing an IP address', () => {
  const snapshot = readSample();
  snapshot.devices.find((device) => device.key === 'plc-01').interfaces = [];
  const { project } = discoverySnapshotToProject(snapshot);
  const logical = deriveLogicalProject(project);
  const plc = logical.devices.find((device) => device.hostname === 'PLC-01');
  assert.equal(plc.interfaces.length, 1);
  assert.equal(plc.interfaces[0].vlanId, 'disc-vlan-20');
  assert.equal(plc.interfaces[0].ip, '');
  assert.equal(project.devices.find((device) => device.hostname === 'PLC-01').interfaces.length, 0, 'derived membership must not mutate canonical imported data');
});

test('unmatched link endpoints are skipped and reported instead of creating phantom devices', () => {
  const snapshot = readSample();
  snapshot.links.push({ key: 'bad-link', sourceKey: 'sw-ot-01', sourcePort: 'Gi1/0/49', targetKey: 'missing-device', targetPort: 'eth0', confidence: 'confirmed' });
  const { project, summary } = discoverySnapshotToProject(snapshot);
  assert.equal(project.devices.length, 5);
  assert.equal(project.physicalLinks.length, 4);
  assert.ok(summary.warnings >= 2);
  assert.ok(project.discovery.warnings.some((warning) => warning.includes('missing-device')));
});


test('discovery provenance and interface metadata survive project save/load normalization', () => {
  const { project } = discoverySnapshotToProject(readSample());
  const reloaded = normalizeProject(JSON.parse(JSON.stringify(project)));
  assert.deepEqual(reloaded.discovery, project.discovery);
  const switchDevice = reloaded.devices.find((device) => device.hostname === 'SW-OT-01');
  assert.equal(switchDevice.discoveryStatus, 'discovered');
  assert.equal(switchDevice.macAddress, '02:00:00:00:30:03');
  const accessPort = switchDevice.ports.find((port) => port.name === 'Gi1/0/5');
  assert.equal(accessPort.status, 'up');
  assert.equal(accessPort.speed, '100 Mbps');
  assert.equal(accessPort.discoveryConfidence, 'confirmed');
  assert.equal(reloaded.physicalLinks[0].discoverySource, 'Holly Bibley sample adapter');
});

test('duplicate VLAN tags, duplicate device keys and unsupported schema versions are rejected', () => {
  const duplicateVlan = readSample();
  duplicateVlan.vlans.push({ ...duplicateVlan.vlans[0] });
  assert.throws(() => normaliseDiscoverySnapshot(duplicateVlan), /Duplicate VLAN tag/);

  const duplicateDevice = readSample();
  duplicateDevice.devices.push({ ...duplicateDevice.devices[0] });
  assert.throws(() => normaliseDiscoverySnapshot(duplicateDevice), /Duplicate device key/);

  const unsupported = readSample();
  unsupported.version = 2;
  assert.throws(() => normaliseDiscoverySnapshot(unsupported), /Unsupported discovery snapshot/);
});

test('interfaces without a VLAN association are retained without appearing on a logical VLAN', () => {
  const snapshot = readSample();
  snapshot.devices.find((device) => device.key === 'plc-01').interfaces = [
    { name: 'Ethernet1', ip: '192.0.2.35/27' },
  ];
  const { project, summary } = discoverySnapshotToProject(snapshot);
  const plc = project.devices.find((device) => device.hostname === 'PLC-01');
  assert.equal(plc.interfaces.length, 1);
  assert.equal(plc.interfaces[0].vlanId, '');
  assert.equal(plc.interfaces[0].ip, '192.0.2.35/27');
  assert.ok(summary.warnings >= 2);
  assert.ok(project.discovery.warnings.some((warning) => warning.includes('no VLAN association')));
});

test('unrecognised device types and unknown VLAN references become warnings, not invented configuration', () => {
  const snapshot = readSample();
  const plc = snapshot.devices.find((device) => device.key === 'plc-01');
  plc.type = 'Unknown Vendor Controller';
  plc.interfaces = [{ vlanTag: 999, name: 'eth0', ip: '192.0.2.35/27' }];
  plc.ports[0].mode = 'access';
  plc.ports[0].accessVlanTag = 999;
  const { project, summary } = discoverySnapshotToProject(snapshot);
  const importedPlc = project.devices.find((device) => device.hostname === 'PLC-01');
  assert.equal(importedPlc.type, 'Other');
  assert.equal(importedPlc.interfaces.length, 1);
  assert.equal(importedPlc.interfaces[0].vlanId, '');
  assert.equal(importedPlc.interfaces[0].ip, '192.0.2.35/27');
  assert.equal(importedPlc.ports[0].mode, 'unknown');
  assert.ok(summary.warnings >= 3);
});

test('version-4 projects migrate to version 6 and retain their existing topology', () => {
  const legacy = {
    schema: 'holly-bibley-project', version: 4, projectName: 'Legacy topology',
    vlans: [{ id: 'v20', tag: '20', name: 'OT', subnet: '', gateway: '' }],
    devices: [
      { id: 'sw', type: 'Switch', hostname: 'SW-01', managementIp: '192.0.2.2', ports: [{ name: 'Gi1/0/1', mode: 'access', accessVlanId: 'v20' }] },
      { id: 'plc', type: 'PLC', hostname: 'PLC-01', ports: [{ name: 'Ethernet0', mode: 'unknown' }] },
    ],
    physicalLinks: [{ id: 'link1', sourceDeviceId: 'sw', sourcePort: 'Gi1/0/1', targetDeviceId: 'plc', targetPort: 'Ethernet0' }],
    connections: [], notes: '',
  };
  const migrated = normalizeProject(legacy);
  assert.equal(migrated.version, 6);
  assert.equal(migrated.physicalLinks.length, 1);
  assert.equal(migrated.devices[0].managementIp, '192.0.2.2');
  assert.equal(migrated.discovery, null);
});
