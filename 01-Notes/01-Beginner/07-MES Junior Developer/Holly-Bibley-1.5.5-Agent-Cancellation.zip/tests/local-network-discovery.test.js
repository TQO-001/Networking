import test from 'node:test';
import assert from 'node:assert/strict';
import { discoverySnapshotToProject } from '../public/mapper/discovery-import.js';
import {
  createLocalDiscoverySnapshot,
  enumerateUsableHosts,
  ipv4ToNumber,
  listLocalIPv4Interfaces,
  normaliseMac,
  numberToIPv4,
  parseIPv4Cidr,
  parseNeighbourOutput,
  runLocalDiscovery,
  selectLocalScanScope,
} from '../scripts/lib/local-network-discovery.js';

const ethernetInterfaces = () => ({
  Ethernet: [{
    address: '192.168.10.2',
    netmask: '255.255.255.0',
    family: 'IPv4',
    internal: false,
    mac: 'aa-bb-cc-dd-ee-02',
  }],
  Loopback: [{
    address: '127.0.0.1',
    netmask: '255.0.0.0',
    family: 'IPv4',
    internal: true,
    mac: '00:00:00:00:00:00',
  }],
});

test('IPv4 conversion accepts valid addresses and rejects malformed octets', () => {
  assert.equal(ipv4ToNumber('192.168.10.1'), 3232238081);
  assert.equal(numberToIPv4(ipv4ToNumber('10.20.30.40')), '10.20.30.40');
  assert.equal(ipv4ToNumber('300.1.1.1'), null);
  assert.equal(ipv4ToNumber('192.168.1'), null);
});

test('CIDR input is normalised to its network and bounded to at most 256 addresses', () => {
  const parsed = parseIPv4Cidr('192.168.10.17/24');
  assert.equal(parsed.cidr, '192.168.10.0/24');
  assert.equal(parsed.totalAddresses, 256);
  assert.throws(() => parseIPv4Cidr('192.168.10.0/23'), /limited to 256/);
  assert.throws(() => parseIPv4Cidr('192.168.10.0/31'), /at least two usable/);
  assert.throws(() => parseIPv4Cidr('192.168.10.0'), /CIDR/);
});

test('interface listing ignores loopback and reports direct private interface networks', () => {
  const list = listLocalIPv4Interfaces(ethernetInterfaces());
  assert.equal(list.length, 1);
  assert.equal(list[0].name, 'Ethernet');
  assert.equal(list[0].cidr, '192.168.10.0/24');
  assert.equal(list[0].private, true);
  assert.equal(list[0].macAddress, 'aa:bb:cc:dd:ee:02');
});

test('selected scope must be private and contained in a directly attached interface network', () => {
  const networkInterfaces = ethernetInterfaces();
  const selected = selectLocalScanScope('192.168.10.64/26', networkInterfaces);
  assert.equal(selected.cidr, '192.168.10.64/26');
  assert.equal(selected.interface.name, 'Ethernet');
  assert.throws(() => selectLocalScanScope('192.168.11.0/24', networkInterfaces), /not contained in a private IPv4 network directly assigned/);
  assert.throws(() => selectLocalScanScope('8.8.8.0/24', networkInterfaces), /only scans RFC 1918/);
  assert.throws(() => selectLocalScanScope('192.168.10.0/24', networkInterfaces, 'Wi-Fi'), /on interface "Wi-Fi"/);
});

test('ambiguous matching interfaces require an explicit interface selection', () => {
  const networkInterfaces = {
    Ethernet: [{ address: '192.168.10.2', netmask: '255.255.255.0', family: 'IPv4', internal: false }],
    'VPN Adapter': [{ address: '192.168.10.3', netmask: '255.255.255.0', family: 'IPv4', internal: false }],
  };
  assert.throws(() => selectLocalScanScope('192.168.10.0/24', networkInterfaces), /matches multiple local interfaces/);
  assert.equal(selectLocalScanScope('192.168.10.0/24', networkInterfaces, 'VPN Adapter').interface.name, 'VPN Adapter');
});

test('usable host enumeration excludes network and broadcast addresses', () => {
  const scope = parseIPv4Cidr('192.168.10.0/30');
  assert.deepEqual(enumerateUsableHosts(scope), ['192.168.10.1', '192.168.10.2']);
  assert.equal(enumerateUsableHosts(parseIPv4Cidr('192.168.10.0/24')).length, 254);
});

test('neighbour cache parser handles Windows ARP, Linux ip neigh and macOS arp output', () => {
  const windows = parseNeighbourOutput('  192.168.10.30        aa-bb-cc-dd-ee-ff     dynamic\n  192.168.10.31        00-00-00-00-00-00     static', 'win32');
  assert.deepEqual([...windows], [['192.168.10.30', 'aa:bb:cc:dd:ee:ff']]);

  const linux = parseNeighbourOutput('192.168.10.32 dev eth0 lladdr aa:bb:cc:dd:ee:32 REACHABLE\n192.168.10.33 dev eth0 INCOMPLETE', 'linux');
  assert.deepEqual([...linux], [['192.168.10.32', 'aa:bb:cc:dd:ee:32']]);

  const mac = parseNeighbourOutput('? (192.168.10.34) at aa:bb:cc:dd:ee:34 on en0 ifscope [ethernet]', 'darwin');
  assert.deepEqual([...mac], [['192.168.10.34', 'aa:bb:cc:dd:ee:34']]);
  assert.equal(normaliseMac('AA-BB-CC-DD-EE-FF'), 'aa:bb:cc:dd:ee:ff');
  assert.equal(normaliseMac('not-a-mac'), '');
});

test('snapshot includes only observed devices and does not invent VLANs or physical links', () => {
  const scope = selectLocalScanScope('192.168.10.0/29', ethernetInterfaces());
  const snapshot = createLocalDiscoverySnapshot({
    scope,
    interfaces: listLocalIPv4Interfaces(ethernetInterfaces()),
    replies: ['192.168.10.3'],
    neighbours: new Map([['192.168.10.3', 'aa:bb:cc:dd:ee:03'], ['192.168.10.4', 'aa:bb:cc:dd:ee:04']]),
    hostname: 'test-host',
    now: new Date('2026-10-28T08:00:00.000Z'),
  });
  assert.equal(snapshot.schema, 'holly-bibley-discovery-snapshot');
  assert.equal(snapshot.scope.cidr, '192.168.10.0/29');
  assert.equal(snapshot.devices.length, 3);
  assert.deepEqual(snapshot.devices.map((device) => device.managementIp), ['192.168.10.2', '192.168.10.3', '192.168.10.4']);
  assert.equal(snapshot.vlans.length, 0);
  assert.equal(snapshot.links.length, 0);
  assert.equal(snapshot.devices.find((device) => device.managementIp === '192.168.10.4').confidence, 'inferred');
  assert.ok(snapshot.warnings.some((warning) => warning.includes('does not query switches')));
  const converted = discoverySnapshotToProject(snapshot);
  assert.equal(converted.project.devices.length, 3, 'local agent snapshot must pass through the current importer');
  assert.equal(converted.project.discovery.scope.cidr, '192.168.10.0/29');
});

test('scanner probes only usable addresses in the selected scope and creates an importable snapshot', async () => {
  const probed = [];
  const progress = [];
  const result = await runLocalDiscovery({
    cidr: '192.168.10.0/29',
    interfaces: ethernetInterfaces(),
    hostname: 'test-host',
    now: () => new Date('2026-10-28T08:00:00.000Z'),
    concurrency: 4,
    minPingIntervalMs: 0,
    pingAddress: async (ip) => {
      probed.push(ip);
      return ip === '192.168.10.3';
    },
    readNeighbourTable: async () => ({ neighbours: new Map([['192.168.10.4', 'aa:bb:cc:dd:ee:04']]) }),
    onProgress: (entry) => progress.push(entry),
  });
  assert.equal(probed.length, 5, 'the local interface address should not be pinged');
  assert.equal(probed.includes('192.168.10.2'), false);
  assert.ok(probed.every((ip) => ip.startsWith('192.168.10.')));
  assert.equal(result.summary.icmpResponded, 1);
  assert.equal(result.summary.devicesFound, 3);
  assert.equal(result.summary.macAddressesFound, 2);
  assert.equal(progress.length, 5);
  assert.equal(result.snapshot.devices.find((device) => device.managementIp === '192.168.10.3').interfaces[0].status, 'up');
});

test('scanner reports missing neighbour-table access but can still return ICMP results', async () => {
  const result = await runLocalDiscovery({
    cidr: '192.168.10.0/30',
    interfaces: ethernetInterfaces(),
    hostname: 'test-host',
    now: () => new Date('2026-10-28T08:00:00.000Z'),
    concurrency: 1,
    minPingIntervalMs: 0,
    pingAddress: async () => true,
    readNeighbourTable: async () => { throw new Error('permission denied'); },
  });
  assert.equal(result.summary.devicesFound, 2);
  assert.ok(result.snapshot.warnings.some((warning) => warning.includes('permission denied')));
});


test('aborting a local scan stops in-flight probes and skips neighbour-table collection', async () => {
  const controller = new AbortController();
  let probeStarted = false;
  let neighbourTableRead = false;
  const scan = runLocalDiscovery({
    cidr: '192.168.10.0/30',
    interfaces: ethernetInterfaces(),
    concurrency: 1,
    minPingIntervalMs: 0,
    signal: controller.signal,
    pingAddress: async (_ip, { signal }) => {
      probeStarted = true;
      return new Promise((_resolve, reject) => {
        if (signal.aborted) return reject(signal.reason);
        signal.addEventListener('abort', () => reject(signal.reason || Object.assign(new Error('cancelled'), { name: 'AbortError' })), { once: true });
      });
    },
    readNeighbourTable: async () => { neighbourTableRead = true; return { neighbours: new Map() }; },
  });
  const abortWhenStarted = async () => {
    for (let attempt = 0; attempt < 50 && !probeStarted; attempt += 1) await new Promise((resolve) => setTimeout(resolve, 2));
    assert.equal(probeStarted, true, 'the scanner should start a probe before cancellation');
    controller.abort(Object.assign(new Error('revoked'), { name: 'AbortError' }));
  };
  await Promise.all([assert.rejects(scan, /revoked/), abortWhenStarted()]);
  assert.equal(neighbourTableRead, false, 'cancelled scans must not continue into neighbour-table collection');
});
