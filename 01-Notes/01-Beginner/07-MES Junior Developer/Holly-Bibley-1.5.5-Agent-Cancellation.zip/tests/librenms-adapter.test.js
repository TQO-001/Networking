import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createLibreNmsSnapshot,
  getLibreNmsConfig,
  getLibreNmsIntegrationStatus,
  LibreNmsIntegrationError,
  testLibreNmsConnection,
} from '../server/librenms-adapter.js';
import { discoverySnapshotToProject } from '../public/mapper/discovery-import.js';

const baseEnv = {
  NODE_ENV: 'test',
  LIBRENMS_BASE_URL: 'https://monitor.example.test',
  LIBRENMS_API_TOKEN: 'test-readonly-token',
  LIBRENMS_ALLOWED_EMAILS: 'network@example.test, administrator@example.test',
  LIBRENMS_MAX_DEVICES: '100',
  LIBRENMS_REQUEST_TIMEOUT_MS: '5000',
};
const authorizedEmail = 'Network@Example.Test';
const fixedNow = new Date('2026-10-28T08:00:00.000Z');

function jsonResponse(payload, status = 200) {
  const body = JSON.stringify(payload);
  return {
    ok: status >= 200 && status < 300,
    status,
    headers: { get: (name) => name.toLowerCase() === 'content-length' ? String(Buffer.byteLength(body)) : null },
    text: async () => body,
  };
}

function createFakeFetch(overrides = {}) {
  const calls = [];
  const fetchImpl = async (url, options = {}) => {
    const parsed = new URL(url);
    calls.push({ url: parsed, options });
    assert.equal(options.method, 'GET', 'LibreNMS connector must only use GET requests');
    assert.equal(options.headers.Authorization, `Bearer ${baseEnv.LIBRENMS_API_TOKEN}`);
    assert.equal(options.headers.Accept, 'application/json');
    assert.equal(options.redirect, 'error');
    assert.ok(options.signal, 'requests have a timeout signal');

    const route = `${parsed.pathname}${parsed.search}`;
    if (overrides[route]) return overrides[route](parsed, options);
    if (route === '/api/v0/') return jsonResponse({ status: 'ok', message: 'Welcome to LibreNMS API' });
    if (route === '/api/v0/devices?type=all&order=hostname') {
      return jsonResponse({ status: 'ok', count: 2, devices: [
        { device_id: 1, hostname: 'sw-core', ip: '192.0.2.1', hardware: 'Cisco Catalyst 9300', os: 'ios', last_polled: '2026-10-28T07:59:00Z', serial: 'SW123' },
        { device_id: 2, hostname: 'router-01', ip: '192.0.2.2', hardware: 'Juniper MX204', os: 'junos', last_polled: '2026-10-28T07:58:00Z' },
      ] });
    }
    if (route === '/api/v0/resources/vlans') {
      return jsonResponse({ status: 'ok', vlans: [
        { vlan_vlan: '10', vlan_name: 'Management' },
        { vlan_vlan: '20', vlan_name: 'OT' },
      ] });
    }
    if (route === '/api/v0/resources/links') {
      return jsonResponse({ status: 'ok', links: [
        { id: 90, local_device_id: 1, local_port_id: 101, remote_device_id: 2, remote_hostname: 'router-01', remote_port: 'xe-0/0/1', protocol: 'lldp', active: 1 },
      ] });
    }
    if (route === '/api/v0/devices/1/ports?with=vlans') {
      return jsonResponse({ status: 'ok', ports: [
        { port_id: 101, ifName: 'Gi1/0/1', ifOperStatus: 1, ifSpeed: 1000000000, ifAlias: 'Uplink to router', vlans: [
          { vlan: 10, vlan_name: 'Management', untagged: 1 },
          { vlan: 20, vlan_name: 'OT', untagged: 0 },
        ] },
        { port_id: 102, ifName: 'Gi1/0/2', ifOperStatus: 1, ifSpeed: 100000000, vlans: [
          { vlan: 20, vlan_name: 'OT', untagged: 1 },
        ] },
      ] });
    }
    if (route === '/api/v0/devices/1/ip') {
      return jsonResponse({ status: 'ok', addresses: [
        { ipv4_address: '192.0.2.1', ipv4_prefixlen: 24, port_id: 101 },
        { ipv4_address: '192.0.2.25', ipv4_prefixlen: 24, port_id: 102 },
      ] });
    }
    if (route === '/api/v0/devices/2/ports?with=vlans') {
      return jsonResponse({ status: 'ok', ports: [
        { port_id: 201, ifName: 'xe-0/0/1', ifOperStatus: 1, ifSpeed: 0, ifHighSpeed: 10000, vlans: [] },
      ] });
    }
    if (route === '/api/v0/devices/2/ip') {
      return jsonResponse({ status: 'ok', addresses: [
        { ipv4_address: '192.0.2.2', ipv4_prefixlen: 24, port_id: 201 },
      ] });
    }
    throw new Error(`Unexpected mock route ${route}`);
  };
  fetchImpl.calls = calls;
  return fetchImpl;
}

test('LibreNMS integration remains disabled until deployment config is complete', () => {
  assert.equal(getLibreNmsIntegrationStatus({}, authorizedEmail).available, false);
  assert.equal(getLibreNmsIntegrationStatus(baseEnv, 'other@example.test').available, false);
  assert.equal(getLibreNmsIntegrationStatus(baseEnv, authorizedEmail).available, true);
  assert.equal(getLibreNmsConfig({ ...baseEnv, LIBRENMS_MAX_DEVICES: '999999' }).maxDevices, 300);
});

test('production rejects an insecure LibreNMS URL and credentials embedded in the URL', () => {
  const insecure = getLibreNmsConfig({ ...baseEnv, NODE_ENV: 'production', LIBRENMS_BASE_URL: 'http://monitor.example.test' });
  assert.equal(insecure.configured, false);
  assert.match(insecure.configError, /HTTPS in production/i);
  const withCredentials = getLibreNmsConfig({ ...baseEnv, LIBRENMS_BASE_URL: 'https://user:pass@monitor.example.test' });
  assert.equal(withCredentials.configured, false);
  assert.match(withCredentials.configError, /must not contain credentials/i);
});

test('connection test calls only the configured LibreNMS base URL with a bearer token', async () => {
  const fetchImpl = createFakeFetch();
  const result = await testLibreNmsConnection({ env: baseEnv, userEmail: authorizedEmail, fetchImpl });
  assert.deepEqual(result, { ok: true, provider: 'LibreNMS' });
  assert.equal(fetchImpl.calls.length, 1);
  assert.equal(fetchImpl.calls[0].url.origin, 'https://monitor.example.test');
  assert.equal(fetchImpl.calls[0].url.pathname, '/api/v0/');
});

test('unauthorised users are rejected before the adapter makes any network request', async () => {
  let called = false;
  await assert.rejects(
    createLibreNmsSnapshot({ env: baseEnv, userEmail: 'attacker@example.test', fetchImpl: async () => { called = true; } }),
    (error) => error instanceof LibreNmsIntegrationError && error.statusCode === 403 && error.code === 'LIBRENMS_FORBIDDEN',
  );
  assert.equal(called, false);
});

test('LibreNMS device, port, VLAN, IP and neighbour data convert into an editable topology snapshot', async () => {
  const fetchImpl = createFakeFetch();
  const snapshot = await createLibreNmsSnapshot({ env: baseEnv, userEmail: authorizedEmail, fetchImpl, now: fixedNow });
  assert.equal(snapshot.schema, 'holly-bibley-discovery-snapshot');
  assert.equal(snapshot.version, 1);
  assert.deepEqual(snapshot.source, { name: 'LibreNMS', adapter: 'librenms-api-v0' });
  assert.equal(snapshot.collectedAt, fixedNow.toISOString());
  assert.equal(snapshot.devices.length, 2);
  assert.equal(snapshot.vlans.length, 2);
  assert.equal(snapshot.links.length, 1);

  const sw = snapshot.devices.find((device) => device.hostname === 'sw-core');
  assert.equal(sw.type, 'Switch');
  assert.equal(sw.model, 'Cisco Catalyst 9300');
  assert.equal(sw.managementIp, '192.0.2.1');
  assert.match(sw.notes, /Serial: SW123/);
  const trunk = sw.ports.find((port) => port.name === 'Gi1/0/1');
  assert.equal(trunk.mode, 'trunk');
  assert.deepEqual(trunk.allowedVlanTags, ['10', '20']);
  assert.equal(trunk.speed, '1 Gbps');
  const access = sw.ports.find((port) => port.name === 'Gi1/0/2');
  assert.equal(access.mode, 'access');
  assert.equal(access.accessVlanTag, '20');
  assert.equal(access.speed, '100 Mbps');
  assert.equal(sw.interfaces.find((iface) => iface.ip === '192.0.2.1/24').vlanTag, '', 'trunk IPs are not assigned to one VLAN from an allowed-VLAN list');
  assert.equal(sw.interfaces.find((iface) => iface.ip === '192.0.2.1/24').peerPort, '', 'interface IP collection should not mislabel the local port description as its peer port');
  assert.equal(sw.interfaces.find((iface) => iface.ip === '192.0.2.25/24').vlanTag, '20');

  const link = snapshot.links[0];
  assert.equal(link.sourceKey, sw.key);
  assert.equal(link.sourcePort, 'Gi1/0/1');
  assert.equal(link.targetKey, snapshot.devices.find((device) => device.hostname === 'router-01').key);
  assert.equal(link.targetPort, 'xe-0/0/1');
  assert.equal(snapshot.devices.find((device) => device.hostname === 'router-01').ports[0].speed, '10 Gbps', 'ifHighSpeed is converted from Mbps when ifSpeed is unavailable');
  assert.equal(link.confidence, 'confirmed');
  assert.ok(fetchImpl.calls.every((call) => call.url.origin === 'https://monitor.example.test'), 'all requests stay on the configured API origin');

  const { project, summary } = discoverySnapshotToProject(snapshot);
  assert.equal(project.devices.length, 2);
  assert.equal(project.physicalLinks.length, 1);
  assert.equal(project.version, 6);
  assert.equal(summary.vlans, 2);
  assert.equal(project.devices.find((device) => device.hostname === 'sw-core').interfaces.find((iface) => iface.ip === '192.0.2.1/24').vlanId, '');
});

test('ambiguous VLAN-only and conflicting untagged-port data are not promoted to a guessed mode', async () => {
  const fetchImpl = createFakeFetch({
    '/api/v0/devices/1/ports?with=vlans': async () => jsonResponse({ status: 'ok', ports: [
      { port_id: 103, ifName: 'Gi1/0/3', ifOperStatus: 1, vlans: [{ vlan: 30, untagged: 0 }] },
      { port_id: 104, ifName: 'Gi1/0/4', ifOperStatus: 1, vlans: [{ vlan: 10, untagged: 1 }, { vlan: 20, untagged: 1 }] },
    ] }),
  });
  const snapshot = await createLibreNmsSnapshot({ env: baseEnv, userEmail: authorizedEmail, fetchImpl, now: fixedNow });
  const sw = snapshot.devices.find((device) => device.hostname === 'sw-core');
  const vlanOnly = sw.ports.find((port) => port.name === 'Gi1/0/3');
  assert.equal(vlanOnly.mode, 'unknown');
  assert.deepEqual(vlanOnly.allowedVlanTags, ['30']);
  const conflicting = sw.ports.find((port) => port.name === 'Gi1/0/4');
  assert.equal(conflicting.mode, 'unknown');
  assert.ok(snapshot.warnings.some((warning) => warning.includes('multiple untagged VLANs')));
  assert.ok(snapshot.warnings.some((warning) => warning.includes('port mode left unknown')));
});

test('upstream authentication failures are sanitised and never echo the token', async () => {
  const fetchImpl = async () => jsonResponse({ message: `bad token ${baseEnv.LIBRENMS_API_TOKEN}` }, 401);
  await assert.rejects(
    testLibreNmsConnection({ env: baseEnv, userEmail: authorizedEmail, fetchImpl }),
    (error) => error instanceof LibreNmsIntegrationError
      && error.code === 'LIBRENMS_AUTH_FAILED'
      && !error.message.includes(baseEnv.LIBRENMS_API_TOKEN),
  );
});

test('optional VLAN and link endpoints failing still return inventory with explicit warnings', async () => {
  const all = createFakeFetch({
    '/api/v0/resources/vlans': async () => jsonResponse({ error: 'not available' }, 503),
    '/api/v0/resources/links': async () => jsonResponse({ error: 'not available' }, 503),
  });
  const snapshot = await createLibreNmsSnapshot({ env: baseEnv, userEmail: authorizedEmail, fetchImpl: all, now: fixedNow });
  assert.equal(snapshot.devices.length, 2);
  assert.equal(snapshot.links.length, 0);
  assert.ok(snapshot.warnings.some((warning) => warning.includes('VLAN inventory could not be retrieved')));
  assert.ok(snapshot.warnings.some((warning) => warning.includes('link inventory could not be retrieved')));
});
