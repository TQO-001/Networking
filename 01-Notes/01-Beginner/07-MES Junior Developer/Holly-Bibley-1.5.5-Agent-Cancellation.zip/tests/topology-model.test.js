import test from 'node:test';
import assert from 'node:assert/strict';
import {
  blankProject,
  createDemoProject,
  deriveLogicalProject,
  normalizeProject,
} from '../public/mapper/project-model.js';

const vlan = (id, tag) => ({ id, tag, name: `VLAN-${tag}`, subnet: '', gateway: '', lineStyle: 'straight', color: '#c99a18' });
const device = (id, hostname, ports = [], interfaces = [], extra = {}) => ({
  id, type: 'Switch', hostname, model: '', managementIp: '', notes: '',
  physicalPosition: { x: 100, y: 100 }, ports, interfaces, hostedDevices: [],
  displayMode: 'single', parentHostId: '', ...extra,
});
const link = (id, sourceDeviceId, sourcePort, targetDeviceId, targetPort) => ({
  id, sourceDeviceId, sourcePort, targetDeviceId, targetPort,
  mediaType: 'Copper Ethernet', label: '', notes: '',
});

function projectWith({ vlans, devices, physicalLinks }) {
  return normalizeProject({
    schema: 'holly-bibley-project', version: 4, projectName: 'Test topology',
    vlans, devices, physicalLinks, connections: [], notes: '',
  });
}

test('blank projects use the physical-first versioned schema', () => {
  const project = blankProject();
  assert.equal(project.version, 6);
  assert.deepEqual(project.physicalLinks, []);
  assert.deepEqual(project.connections, []);
});

test('access VLAN on a physical link derives segment membership at both ends', () => {
  const project = projectWith({
    vlans: [vlan('v20', '20')],
    devices: [
      device('sw', 'SW-01', [{ name: 'Gi1/0/1', mode: 'access', accessVlanId: 'v20' }]),
      device('plc', 'PLC-01', [{ name: 'Ethernet0', mode: 'unknown' }]),
    ],
    physicalLinks: [link('p1', 'sw', 'Gi1/0/1', 'plc', 'Ethernet0')],
  });
  const logical = deriveLogicalProject(project);
  assert.deepEqual(logical.devices.find((item) => item.id === 'sw').interfaces.map((item) => item.vlanId), ['v20']);
  assert.deepEqual(logical.devices.find((item) => item.id === 'plc').interfaces.map((item) => item.vlanId), ['v20']);
  assert.equal(project.devices.find((item) => item.id === 'plc').interfaces.length, 0, 'inference must not mutate the canonical project');
});

test('trunk-to-trunk links infer only VLANs allowed at both ends', () => {
  const project = projectWith({
    vlans: [vlan('v10', '10'), vlan('v20', '20'), vlan('v30', '30')],
    devices: [
      device('a', 'SW-A', [{ name: 'Te1/1', mode: 'trunk', allowedVlanIds: ['v10', 'v20'] }]),
      device('b', 'SW-B', [{ name: 'Te1/1', mode: 'trunk', allowedVlanIds: ['v20', 'v30'] }]),
    ],
    physicalLinks: [link('p1', 'a', 'Te1/1', 'b', 'Te1/1')],
  });
  const logical = deriveLogicalProject(project);
  for (const id of ['a', 'b']) {
    assert.deepEqual(logical.devices.find((item) => item.id === id).interfaces.map((item) => item.vlanId), ['v20']);
  }
});

test('access-to-trunk links do not infer VLAN membership without native-VLAN semantics', () => {
  const vlans = [vlan('v10', '10'), vlan('v20', '20')];
  const source = device('sw', 'SW-01', [{ name: 'Gi1/0/1', mode: 'access', accessVlanId: 'v20' }]);
  const target = device('uplink', 'UPLINK-01', [{ name: 'Gi1/0/1', mode: 'trunk', allowedVlanIds: ['v20'] }]);
  const project = projectWith({ vlans, devices: [source, target], physicalLinks: [link('p1', 'sw', 'Gi1/0/1', 'uplink', 'Gi1/0/1')] });

  const logical = deriveLogicalProject(project);
  assert.equal(logical.devices.find(item => item.id === 'sw').interfaces.length, 0);
  assert.equal(logical.devices.find(item => item.id === 'uplink').interfaces.length, 0);
});

test('routed physical ports do not manufacture VLAN membership', () => {
  const project = projectWith({
    vlans: [vlan('v10', '10')],
    devices: [
      device('a', 'RTR-A', [{ name: 'Gi0/0', mode: 'access', accessVlanId: 'v10' }]),
      device('b', 'RTR-B', [{ name: 'Gi0/0', mode: 'routed' }]),
    ],
    physicalLinks: [link('p1', 'a', 'Gi0/0', 'b', 'Gi0/0')],
  });

  const logical = deriveLogicalProject(project);
  assert.equal(logical.devices.find(item => item.id === 'a').interfaces.length, 0);
  assert.equal(logical.devices.find(item => item.id === 'b').interfaces.length, 0);
});

test('contradictory access VLAN settings do not infer a false shared VLAN', () => {
  const project = projectWith({
    vlans: [vlan('v10', '10'), vlan('v20', '20')],
    devices: [
      device('a', 'SW-A', [{ name: 'Gi1/0/1', mode: 'access', accessVlanId: 'v10' }]),
      device('b', 'PLC-01', [{ name: 'Ethernet0', mode: 'access', accessVlanId: 'v20' }]),
    ],
    physicalLinks: [link('p1', 'a', 'Gi1/0/1', 'b', 'Ethernet0')],
  });
  const logical = deriveLogicalProject(project);
  assert.equal(logical.devices.find((item) => item.id === 'a').interfaces.length, 0);
  assert.equal(logical.devices.find((item) => item.id === 'b').interfaces.length, 0);
});

test('explicit firewall interface IPs remain intact while the firewall stays inside its ESXi group', () => {
  const project = createDemoProject();
  const host = project.devices.find((item) => item.id === 'dev-esxi');
  const firewall = project.devices.find((item) => item.id === 'dev-fw');
  assert.equal(firewall.parentHostId, host.id);
  assert.deepEqual(firewall.interfaces.map((item) => [item.vlanId, item.ip]), [
    ['vlan-20', '10.20.20.1/24'], ['vlan-30', '10.20.30.1/24'],
  ]);
  const logical = deriveLogicalProject(project);
  const derivedFirewall = logical.devices.find((item) => item.id === 'dev-fw');
  assert.equal(derivedFirewall.parentHostId, host.id);
  assert.deepEqual(derivedFirewall.interfaces.map((item) => item.ip), ['10.20.20.1/24', '10.20.30.1/24']);
});

test('VM group migration and nested workloads survive normalization', () => {
  const project = normalizeProject({
    projectName: 'legacy', vlans: [],
    devices: [
      device('esxi', 'ESXi host', [], [], { type: 'ESXi host', hostedDevices: ['VM-01 · RDS workload'] }),
      device('vm', 'VM-01', [], [], { type: 'Virtual machine' }),
    ],
  });
  assert.equal(project.version, 6);
  assert.equal(project.devices.find((item) => item.id === 'vm').parentHostId, 'esxi');
  assert.deepEqual(project.physicalLinks, []);
});

test('duplicate and invalid physical links are removed on import', () => {
  const normalized = projectWith({
    vlans: [vlan('v20', '20')],
    devices: [device('a', 'A'), device('b', 'B')],
    physicalLinks: [
      link('p1', 'a', 'eth0', 'b', 'eth0'),
      link('p1', 'a', 'eth1', 'b', 'eth1'),
      link('bad-self', 'a', 'eth2', 'a', 'eth2'),
      link('bad-unknown', 'a', 'eth3', 'missing', 'eth3'),
    ],
  });
  assert.equal(normalized.physicalLinks.length, 1);
  assert.equal(normalized.physicalLinks[0].id, 'p1');
});

test('VLAN curve styles persist through import normalization', () => {
  const project = projectWith({ vlans: [{ ...vlan('v20', '20'), lineStyle: 'deep-curve' }], devices: [], physicalLinks: [] });
  assert.equal(project.vlans[0].lineStyle, 'deep-curve');
});
