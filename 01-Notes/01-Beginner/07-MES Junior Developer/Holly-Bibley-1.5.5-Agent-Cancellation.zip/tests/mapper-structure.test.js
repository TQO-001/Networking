import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const mapperFiles = [
  'public/mapper-app.js',
  'public/mapper/device-catalog.js',
  'public/mapper/discovery-import.js',
  'public/mapper/exports.js',
  'public/mapper/forms.js',
  'public/mapper/inspector-views.js',
  'public/mapper/logical-renderer.js',
  'public/mapper/physical-renderer.js',
  'public/mapper/project-model.js',
  'public/mapper/svg-utils.js',
  'public/mapper/ui-icons.js',
];

test('mapper modules only reference existing local source files', () => {
  for (const relativeFile of mapperFiles) {
    const source = readFileSync(resolve(root, relativeFile), 'utf8');
    const importPattern = /\bfrom\s+['"](\.{1,2}\/[^'"]+)['"]/g;
    for (const match of source.matchAll(importPattern)) {
      const dependencyPath = resolve(dirname(resolve(root, relativeFile)), match[1]);
      assert.ok(existsSync(dependencyPath), `${relativeFile} imports missing ${match[1]}`);
    }
  }
});

test('physical and logical topology use text-first device cards with no external image artwork', () => {
  const physical = readFileSync(resolve(root, 'public/mapper/physical-renderer.js'), 'utf8');
  const logical = readFileSync(resolve(root, 'public/mapper/logical-renderer.js'), 'utf8');

  assert.doesNotMatch(physical, /appendDeviceIcon|device-icons\.js|createElementNS\([^\n]*['\"]image['\"]/);
  assert.doesNotMatch(logical, /appendDeviceIcon|device-icons\.js|createElementNS\([^\n]*['\"]image['\"]/);
  assert.match(physical, /physical-node-name/);
  assert.match(logical, /node-type/);
  assert.equal(existsSync(resolve(root, 'public/mapper/device-icons.js')), false);
  assert.equal(existsSync(resolve(root, 'public/assets/cisco-icons')), false);
});

test('dynamic editor controls are created by the module that owns them', () => {
  const controller = readFileSync(resolve(root, 'public/mapper-app.js'), 'utf8');
  const forms = readFileSync(resolve(root, 'public/mapper/forms.js'), 'utf8');

  assert.match(controller, /id="exportPngBtn"/);
  assert.match(controller, /discoverySnapshotToProject/);
  assert.match(readFileSync(resolve(root, 'public/mapper.html'), 'utf8'), /id="discoveryBtn"/);
  assert.ok(existsSync(resolve(root, 'public/mapper/discovery-sample.json')));
  assert.ok(existsSync(resolve(root, 'public/mapper/discovery-snapshot-format.md')));
  assert.match(forms, /id="connectionTargets"/);
});


test('dashboard opens the static mapper with a full document navigation', () => {
  const app = readFileSync(resolve(root, 'src/App.jsx'), 'utf8');
  assert.match(app, /function openMapper\(projectId\)/);
  assert.match(app, /window\.location\.assign\(target\)/);
  assert.match(app, /openMapper\(data\.project\.id\)/);
  assert.match(app, /onClick=\{\(\) => openMapper\(project\.id\)\}/);
  assert.doesNotMatch(app, /navigate\(`\/mapper\.html\?projectId=/);
  assert.ok(existsSync(resolve(root, 'public/mapper.html')), 'static mapper entry point must exist');
});

test('LibreNMS integration keeps credentials server-side and requires authenticated API routes', () => {
  const server = readFileSync(resolve(root, 'server/index.js'), 'utf8');
  const adapter = readFileSync(resolve(root, 'server/librenms-adapter.js'), 'utf8');
  const client = readFileSync(resolve(root, 'public/mapper-app.js'), 'utf8');
  assert.match(server, /app\.get\('\/api\/discovery\/librenms\/status', requireAuth/);
  assert.match(server, /app\.post\('\/api\/discovery\/librenms\/test', requireAuth, discoveryLimiter/);
  assert.match(server, /app\.post\('\/api\/discovery\/librenms\/snapshot', requireAuth, discoveryLimiter/);
  assert.match(adapter, /Authorization: `Bearer \$\{config\.token\}`/);
  assert.match(adapter, /config\.allowedEmails\.includes/);
  assert.doesNotMatch(client, /LIBRENMS_API_TOKEN|LIBRENMS_BASE_URL/);
});

test('dashboard creates blank projects with the current canonical schema version', () => {
  const app = readFileSync(resolve(root, 'src/App.jsx'), 'utf8');
  assert.match(app, /schema: 'holly-bibley-project', version: 6, projectName/);
});

test('React Router links and navigations target declared pages', () => {
  const app = readFileSync(resolve(root, 'src/App.jsx'), 'utf8');
  const declaredRoutes = new Set([...app.matchAll(/<Route\s+path="([^"]+)"/g)].map((match) => match[1]));
  const internalLinks = [...app.matchAll(/\bto="(\/[^"]+)"/g)].map((match) => match[1]);
  const navigations = [...app.matchAll(/navigate\(([`'\"])([\s\S]*?)\1/g)]
    .map((match) => match[2].replace(/\$\{[^}]*\}/g, 'value'))
    .map((target) => new URL(target, 'http://holly-bibley.local').pathname);

  for (const target of [...internalLinks, ...navigations]) {
    assert.ok(declaredRoutes.has(target), `Internal SPA target ${target} has no React Router route.`);
  }
  assert.ok(existsSync(resolve(root, 'public/mapper.html')), 'The mapper is a standalone static page.');
  assert.match(app, /<Route path="\/mapper\.html" element=\{<MapperRouteHandoff\/>\}/, 'A defensive route handoff must exist if the mapper is ever opened by SPA navigation.');
  assert.match(app, /function MapperRouteHandoff\(\)/);
  assert.match(app, /window\.location\.replace\(\`\$\{location\.pathname\}\$\{location\.search\}\$\{location\.hash\}\`\)/);
  assert.ok(existsSync(resolve(root, 'public/logical-network-mapping-guide.md')), 'The full field guide is served as a static asset.');
});

test('local discovery agent API uses pairing, hashed tokens, owner-scoped jobs, and revocation', () => {
  const server = readFileSync(resolve(root, 'server/index.js'), 'utf8');
  const agentModule = readFileSync(resolve(root, 'server/discovery-agent.js'), 'utf8');
  const runtime = readFileSync(resolve(root, 'scripts/lib/discovery-agent-runtime.js'), 'utf8');
  const client = readFileSync(resolve(root, 'public/mapper-app.js'), 'utf8');
  const packageJson = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'));

  assert.match(server, /app\.post\('\/api\/discovery\/agents\/pairing', requireAuth/);
  assert.match(server, /app\.post\('\/api\/discovery\/agent-transport\/pair'/);
  assert.match(server, /app\.post\('\/api\/discovery\/agent-transport\/claim', agentTransportLimiter, requireDiscoveryAgent/);
  assert.match(server, /hashSecret\(rawAgentToken\)/);
  assert.match(server, /WHERE id=\$1 AND user_id=\$2 AND revoked_at IS NULL RETURNING id/);
  assert.match(server, /lease_token=\$4/);
  assert.match(server, /normaliseDiscoverySnapshot\(validated\)/);
  assert.match(agentModule, /validateDiscoveryJobRequest/);
  assert.match(agentModule, /validateAgentSnapshot/);
  assert.match(runtime, /runLocalDiscovery/);
  assert.match(runtime, /runSnmpSwitchDiscovery/);
  assert.doesNotMatch(runtime, /HB_SNMPV3_AUTH_PASSPHRASE\s*:\s*job/);
  assert.match(client, /createAgentPairingBtn/);
  assert.match(client, /startAgentDiscoveryBtn/);
  assert.match(client, /revokeDiscoveryAgentBtn/);
  assert.equal(packageJson.scripts['discovery:agent'], 'node scripts/discovery-agent.js');
});


test('discovery agent picker visibly distinguishes active and stale agents', () => {
  const mapper = readFileSync(resolve(root, 'public/mapper-app.js'), 'utf8');
  assert.match(mapper, /recently active/);
  assert.match(mapper, /stale/);
  assert.match(mapper, /never connected/);
  assert.match(mapper, /90_000/);
});
