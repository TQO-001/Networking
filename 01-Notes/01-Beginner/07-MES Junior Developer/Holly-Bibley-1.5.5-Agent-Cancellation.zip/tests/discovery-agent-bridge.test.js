import test from 'node:test';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { validateAgentSnapshot, validateDiscoveryJobRequest, validatePairingRequest } from '../server/discovery-agent.js';
import { normaliseAgentServerUrl, validateClaimedAgentJob } from '../scripts/lib/discovery-agent-runtime.js';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const uuid = '20f0c90e-4df2-44b8-9dd2-401db46d9750';
const leaseToken = 'e02b52af-4ac7-4be6-b146-35e88d410eb1';

function minimalSnapshot() {
  return {
    schema: 'holly-bibley-discovery-snapshot',
    version: 1,
    source: { name: 'Test Agent', adapter: 'test' },
    collectedAt: '2026-10-28T00:00:00.000Z',
    scope: { cidr: '192.168.10.0/24', label: 'test' },
    warnings: [],
    vlans: [],
    devices: [],
    links: [],
  };
}

test('discovery job validator canonicalises a private CIDR and bounds the subnet size', () => {
  assert.deepEqual(validateDiscoveryJobRequest({ kind: 'subnet', cidr: '192.168.10.18/24', interfaceName: 'Ethernet' }), {
    kind: 'subnet', request: { cidr: '192.168.10.0/24', interfaceName: 'Ethernet' },
  });
  assert.throws(() => validateDiscoveryJobRequest({ kind: 'subnet', cidr: '8.8.8.0/24' }), /RFC 1918/);
  assert.throws(() => validateDiscoveryJobRequest({ kind: 'subnet', cidr: '10.0.0.0/16' }), /limited to 256/);
  assert.throws(() => validateDiscoveryJobRequest({ kind: 'subnet', cidr: 'not-a-cidr' }), /CIDR/);
});

test('switch jobs accept only explicit private IPv4 addresses and cap target count', () => {
  assert.deepEqual(validateDiscoveryJobRequest({ kind: 'switches', targets: ['192.168.1.2', '10.1.2.3'] }), {
    kind: 'switches', request: { targets: ['192.168.1.2', '10.1.2.3'] },
  });
  assert.throws(() => validateDiscoveryJobRequest({ kind: 'switches', targets: ['switch.example.com'] }), /literal IPv4/);
  assert.throws(() => validateDiscoveryJobRequest({ kind: 'switches', targets: ['1.1.1.1'] }), /outside the RFC 1918/);
  assert.throws(() => validateDiscoveryJobRequest({ kind: 'switches', targets: [] }), /Provide one or more/);
  assert.throws(() => validateDiscoveryJobRequest({ kind: 'other' }), /Unsupported discovery job/);
});

test('pairing code input is constrained and names are cleaned', () => {
  assert.deepEqual(validatePairingRequest({ pairingCode: 'A'.repeat(32), name: '  OT Laptop\n' }), {
    pairingCode: 'A'.repeat(32), name: 'OT Laptop',
  });
  assert.throws(() => validatePairingRequest({ pairingCode: 'short', name: 'laptop' }), /malformed/);
});

test('agent server URL requires HTTPS except localhost development and rejects embedded credentials or paths', () => {
  assert.equal(normaliseAgentServerUrl('https://holly.example.com/'), 'https://holly.example.com');
  assert.equal(normaliseAgentServerUrl('http://127.0.0.1:3001'), 'http://127.0.0.1:3001');
  assert.throws(() => normaliseAgentServerUrl('http://holly.example.com'), /HTTPS/);
  assert.throws(() => normaliseAgentServerUrl('https://user:pass@holly.example.com'), /credentials/);
  assert.throws(() => normaliseAgentServerUrl('https://holly.example.com/base/path'), /origin only/);
});

test('agent validates claimed job identifiers and subnet scope before running it', () => {
  assert.deepEqual(validateClaimedAgentJob({ id: uuid, leaseToken, kind: 'subnet', request: { cidr: '192.168.10.0/24' } }), {
    id: uuid, leaseToken, kind: 'subnet', request: { cidr: '192.168.10.0/24', interfaceName: '' },
  });
  assert.throws(() => validateClaimedAgentJob({ id: 'bad', leaseToken, kind: 'subnet', request: { cidr: '192.168.10.0/24' } }), /job and lease IDs/);
  assert.throws(() => validateClaimedAgentJob({ id: uuid, leaseToken, kind: 'subnet', request: { cidr: '8.8.8.0/24' } }), /private IPv4/);
  assert.throws(() => validateClaimedAgentJob({ id: uuid, leaseToken, kind: 'switches', request: { targets: ['192.168.1.2', '10.1.2.3:161'] } }), /literal IPv4/);
});

test('agent result size and snapshot schema are checked before storage', () => {
  assert.deepEqual(validateAgentSnapshot(minimalSnapshot()), minimalSnapshot());
  assert.throws(() => validateAgentSnapshot({ schema: 'unknown', version: 1, devices: [], vlans: [], links: [] }), /unsupported snapshot/);
  assert.throws(() => validateAgentSnapshot({ ...minimalSnapshot(), devices: 'not-an-array' }), /device list/);
  const oversized = { ...minimalSnapshot(), source: { name: 'Test', adapter: 'test' }, warnings: ['x'.repeat(2_500_100)] };
  assert.throws(() => validateAgentSnapshot(oversized), /too large/);
});


test('agent leases can reclaim legacy running jobs without an expiry and job reads enforce retention', () => {
  const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
  const server = readFileSync(resolve(root, 'server/index.js'), 'utf8');
  assert.match(server, /lease_expires_at IS NULL OR lease_expires_at < now\(\)/);
  assert.match(server, /FROM discovery_jobs WHERE id=\$1 AND user_id=\$2 AND expires_at > now\(\) LIMIT 1/);
});


test('expired leases cannot heartbeat, complete, or fail a reclaimed discovery job', () => {
  const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
  const server = readFileSync(resolve(root, 'server/index.js'), 'utf8');
  const heartbeatRoute = server.match(/app\.post\('\/api\/discovery\/agent-transport\/jobs\/:id\/heartbeat'[\s\S]*?\n\}\);/)?.[0] || '';
  const completeRoute = server.match(/app\.post\('\/api\/discovery\/agent-transport\/jobs\/:id\/complete'[\s\S]*?\n\}\);/)?.[0] || '';
  const failRoute = server.match(/app\.post\('\/api\/discovery\/agent-transport\/jobs\/:id\/fail'[\s\S]*?\n\}\);/)?.[0] || '';
  assert.match(heartbeatRoute, /lease_expires_at > now\(\)/, 'heartbeat must require a still-valid lease');
  assert.match(completeRoute, /lease_expires_at > now\(\)/, 'completion must reject expired leases');
  assert.match(failRoute, /lease_expires_at > now\(\)/, 'failure reports must reject expired leases');
});


test('agent revocation and queued-job cancellation are transactional', () => {
  const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
  const server = readFileSync(resolve(root, 'server/index.js'), 'utf8');
  const revokeRoute = server.match(/app\.delete\('\/api\/discovery\/agents\/:id'[\s\S]*?\n\}\);/)?.[0] || '';
  const claimRoute = server.match(/app\.post\('\/api\/discovery\/agent-transport\/claim'[\s\S]*?\n\}\);/)?.[0] || '';
  assert.ok(revokeRoute, 'revocation route must exist');
  assert.ok(claimRoute, 'claim route must exist');
  assert.match(revokeRoute, /client\.query\('BEGIN'\)/);
  assert.match(revokeRoute, /UPDATE discovery_agents SET revoked_at=now\(\)/);
  assert.match(revokeRoute, /UPDATE discovery_jobs SET status='cancelled'[\s\S]*?lease_expires_at=NULL[\s\S]*?lease_token=NULL/);
  assert.match(revokeRoute, /client\.query\('COMMIT'\)/);
  assert.match(revokeRoute, /client\.query\('ROLLBACK'\)/);
  assert.match(claimRoute, /SELECT id FROM discovery_agents WHERE id=\$1 AND revoked_at IS NULL FOR UPDATE/);
  assert.ok(claimRoute.indexOf('activeAgent') < claimRoute.indexOf('SELECT id,kind,request'), 'claim must lock/check the agent before selecting jobs');
});

test('agent confirms its lease before beginning host or SNMP discovery', () => {
  const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
  const agent = readFileSync(resolve(root, 'scripts/discovery-agent.js'), 'utf8');
  const executionRoute = agent.match(/async function executeClaimedJob\([\s\S]*?\n\}/)?.[0] || '';
  assert.ok(executionRoute, 'job execution function must exist');
  assert.ok(executionRoute.indexOf('await renewLease(config, job)') < executionRoute.indexOf('await executeAgentJob(job'), 'lease must be renewed before any local discovery starts');
  assert.match(agent, /error\.statusCode = response\.status/);
  assert.match(executionRoute, /\[401, 404\]\.includes\(error\?\.statusCode\)/, 'revoked/expired lease responses must not be treated as ordinary discovery errors');
  assert.match(executionRoute, /signal: controller\.signal/, 'active discovery must receive an abort signal');
  assert.match(agent, /setInterval\(\(\) => \{[\s\S]*?heartbeatInFlight[\s\S]*?heartbeat\(config, job, controller\)[\s\S]*?\}, 5000\)/, 'active jobs must refresh their lease frequently enough to detect revocation');
  assert.match(agent, /controller\.abort\(/, 'a revoked or expired lease must abort in-progress discovery');
  assert.match(agent, /if \(\[401, 403\]\.includes\(error\?\.statusCode\)\)[\s\S]*?Stopping; pair the agent again/, 'a revoked agent must stop retrying instead of looping forever');
});

test('live HTTP integration harness refuses to run without explicit opt-in before loading database dependencies', () => {
  const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
  const result = spawnSync(process.execPath, [resolve(root, 'scripts/run-discovery-agent-integration.js')], {
    cwd: root,
    env: { ...process.env, HB_RUN_DISCOVERY_INTEGRATION: '', HB_DISCOVERY_TEST_DATABASE_URL: '' },
    encoding: 'utf8',
    timeout: 5000,
  });
  const output = `${result.stdout || ''}\n${result.stderr || ''}`;
  assert.equal(result.status, 1);
  assert.match(output, /Set HB_RUN_DISCOVERY_INTEGRATION=1 to opt in/);
  assert.doesNotMatch(output, /ERR_MODULE_NOT_FOUND|connect ECONNREFUSED/);
});
