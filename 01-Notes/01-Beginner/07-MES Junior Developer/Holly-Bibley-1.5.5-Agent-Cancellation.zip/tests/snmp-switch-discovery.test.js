import test from 'node:test';
import assert from 'node:assert/strict';
import {
  MAX_SNMP_TARGETS,
  buildSnmpDiscoverySnapshot,
  decodeVlanPortBitmaps,
  runSnmpSwitchDiscovery,
  snmpSwitchDiscoveryOids as OID,
  validateSnmpTargets,
  validateSnmpv3Credentials,
  pollSnmpSwitchTarget,
} from '../scripts/lib/snmp-switch-discovery.js';
import { discoverySnapshotToProject } from '../public/mapper/discovery-import.js';

const validCredentials = {
  username: 'holly-ro',
  authPassphrase: 'example-auth-phrase-123',
  privPassphrase: 'example-privacy-phrase-456',
  authProtocol: 'sha256',
  privProtocol: 'aes',
};

const fakeSnmpLibrary = {
  Version3: 3,
  SecurityLevel: { authPriv: 'authPriv' },
  AuthProtocols: { sha: 'sha', sha224: 'sha224', sha256: 'sha256', sha384: 'sha384', sha512: 'sha512' },
  PrivProtocols: { aes: 'aes', aes256b: 'aes256b', aes256r: 'aes256r' },
  isVarbindError: () => false,
  varbindError: () => 'SNMP varbind error',
};

function vb(oid, value) {
  return { oid, value };
}

function fakeSessionFactory({ target, user, options }) {
  const state = { target, user, options, closed: false, methods: [] };
  const system = new Map([
    [OID.sysName, Buffer.from(target.endsWith('.2') ? 'SW-CORE-01' : 'SW-ACCESS-01')],
    [OID.sysDescr, Buffer.from('Example managed Ethernet switch')],
    [OID.sysObjectID, '1.3.6.1.4.1.9.1.1'],
    [OID.lldpLocalChassisId, Buffer.from([0x00, 0x11, 0x22, 0x33, 0x44, target.endsWith('.2') ? 0x02 : 0x03])],
  ]);
  const interfaceTable = {
    1: { 2: Buffer.from('GigabitEthernet1/0/1'), 3: 6, 5: 1000000000, 6: Buffer.from([0x00, 0x11, 0x22, 0x33, 0x44, 0x55]), 7: 1, 8: 1 },
    2: { 2: Buffer.from('Vlan10'), 3: 53, 5: 1000000000, 6: Buffer.from([0x00, 0x11, 0x22, 0x33, 0x44, 0x56]), 7: 1, 8: 1 },
  };
  const ifXTable = {
    1: { 1: Buffer.from('Gi1/0/1'), 15: 1000, 18: Buffer.from('uplink') },
    2: { 1: Buffer.from('Vlan10'), 15: 1000, 18: Buffer.from('management SVI') },
  };
  const prefix = (base, suffix, value) => vb(`${base}.${suffix}`, value);
  const responseByBase = new Map([
    [OID.bridgePortIfIndex, [prefix(OID.bridgePortIfIndex, '1', 1)]],
    [OID.vlanStaticName, [prefix(OID.vlanStaticName, '10', Buffer.from('MGMT'))]],
    [OID.vlanCurrentEgress, [prefix(OID.vlanCurrentEgress, '0.10', Buffer.from([0x80]))]],
    [OID.vlanCurrentUntagged, [prefix(OID.vlanCurrentUntagged, '0.10', Buffer.from([0x80]))]],
    [OID.ipAddressIfIndex, [prefix(OID.ipAddressIfIndex, '192.168.10.2', 2)]],
    [OID.ipAddressNetmask, [prefix(OID.ipAddressNetmask, '192.168.10.2', '255.255.255.0')]],
    [OID.lldpLocalPortId, [prefix(OID.lldpLocalPortId, '1', Buffer.from('Gi1/0/1'))]],
    [OID.lldpLocalPortDesc, [prefix(OID.lldpLocalPortDesc, '1', Buffer.from('Uplink'))]],
    [OID.lldpRemoteSysName, [prefix(OID.lldpRemoteSysName, '123.1.1', Buffer.from(target.endsWith('.2') ? 'SW-ACCESS-01' : 'SW-CORE-01'))]],
    [OID.lldpRemoteChassisId, [prefix(OID.lldpRemoteChassisId, '123.1.1', Buffer.from([0x00, 0x11, 0x22, 0x33, 0x44, target.endsWith('.2') ? 0x03 : 0x02]))]],
    [OID.lldpRemotePortId, [prefix(OID.lldpRemotePortId, '123.1.1', Buffer.from(target.endsWith('.2') ? 'Gi1/0/48' : 'Gi1/0/1'))]],
    [OID.lldpRemotePortDesc, [prefix(OID.lldpRemotePortDesc, '123.1.1', Buffer.from('Uplink port'))]],
  ]);
  const session = {
    on() {},
    get(oids, callback) {
      state.methods.push('get');
      callback(null, oids.map((oid) => ({ oid, value: system.get(oid) ?? '' })));
    },
    table(oid, repetitions, callback) {
      state.methods.push('table');
      if (oid === OID.ifTable) return callback(null, interfaceTable);
      if (oid === OID.ifXTable) return callback(null, ifXTable);
      return callback(null, {});
    },
    subtree(oid, repetitions, feed, done) {
      state.methods.push('subtree');
      feed(responseByBase.get(oid) || []);
      done(null);
    },
    close() { state.closed = true; },
  };
  return { session, state };
}

test('SNMP discovery accepts unique explicit private IPv4 addresses only', () => {
  assert.deepEqual(validateSnmpTargets('192.168.10.2, 10.20.0.4,192.168.10.2'), ['192.168.10.2', '10.20.0.4']);
  assert.throws(() => validateSnmpTargets('switch-a.example.com'), /literal IPv4/);
  assert.throws(() => validateSnmpTargets('8.8.8.8'), /outside the RFC 1918/);
  assert.throws(() => validateSnmpTargets('192.168.10.2:161'), /literal IPv4/);
  assert.throws(() => validateSnmpTargets(Array.from({ length: MAX_SNMP_TARGETS + 1 }, (_, i) => `10.0.0.${i + 1}`)), /limited to/);
});

test('SNMP credentials require authPriv and reject MD5 and DES', () => {
  const validated = validateSnmpv3Credentials({
    HB_SNMPV3_USERNAME: validCredentials.username,
    HB_SNMPV3_AUTH_PASSPHRASE: validCredentials.authPassphrase,
    HB_SNMPV3_PRIV_PASSPHRASE: validCredentials.privPassphrase,
    HB_SNMPV3_AUTH_PROTOCOL: 'sha256',
    HB_SNMPV3_PRIV_PROTOCOL: 'aes',
  }, fakeSnmpLibrary);
  assert.equal(validated.authProtocol, 'sha256');
  assert.equal(validated.privProtocol, 'aes');
  assert.throws(() => validateSnmpv3Credentials({
    HB_SNMPV3_USERNAME: 'user',
    HB_SNMPV3_AUTH_PASSPHRASE: '12345678',
    HB_SNMPV3_PRIV_PASSPHRASE: '12345678',
    HB_SNMPV3_AUTH_PROTOCOL: 'md5',
    HB_SNMPV3_PRIV_PROTOCOL: 'aes',
  }), /MD5 is intentionally disabled/);
  assert.throws(() => validateSnmpv3Credentials({
    HB_SNMPV3_USERNAME: 'user',
    HB_SNMPV3_AUTH_PASSPHRASE: '12345678',
    HB_SNMPV3_PRIV_PASSPHRASE: '12345678',
    HB_SNMPV3_AUTH_PROTOCOL: 'sha256',
    HB_SNMPV3_PRIV_PROTOCOL: 'des',
  }), /DES is intentionally disabled/);
  assert.throws(() => validateSnmpv3Credentials({ HB_SNMPV3_USERNAME: 'user' }), /AUTH_PASSPHRASE/);
});

test('Q-BRIDGE port bitmaps map bridge ports to ifIndex without assuming the indexes match', () => {
  const egress = [vb(`${OID.vlanCurrentEgress}.0.10`, Buffer.from([0xa0]))]; // ports 1 and 3
  const untagged = [vb(`${OID.vlanCurrentUntagged}.0.10`, Buffer.from([0x80]))]; // port 1
  const bridgeMapping = [vb(`${OID.bridgePortIfIndex}.1`, 51), vb(`${OID.bridgePortIfIndex}.3`, 99)];
  const rows = decodeVlanPortBitmaps(egress, untagged, bridgeMapping);
  assert.deepEqual(rows, [{ tag: 10, egressIfIndices: [51, 99], untaggedIfIndices: [51] }]);
});

test('SNMP snapshot includes only known switch targets and LLDP-advertised neighbours', () => {
  const snapshot = buildSnmpDiscoverySnapshot({
    collectedAt: '2026-10-28T09:00:00.000Z',
    switchRecords: [
      {
        target: '192.168.10.2', hostname: 'SW-CORE-01', description: 'Cisco Catalyst switch', sysObjectId: '1.3.6.1.4.1.9.1.1', chassisId: '00:11:22:33:44:02', macAddress: '00:11:22:33:44:02', warnings: [],
        vlans: [{ tag: 10, name: 'MGMT' }, { tag: 20, name: 'OT-CONTROL' }],
        ports: [{ name: 'Gi1/0/1', mode: 'trunk', accessVlanTag: '', allowedVlanTags: ['10', '20'], status: 'up', speed: '1 Gbps', confidence: 'inferred', notes: 'Observed VLAN membership.' }],
        interfaceAddresses: [{ vlanTag: '10', name: 'Vlan10', ip: '192.168.10.2/24', status: 'up', confidence: 'inferred' }],
        neighbors: [{ localPort: 'Gi1/0/1', remoteSystemName: 'SW-ACCESS-01', remoteChassisId: '00:11:22:33:44:03', remotePortId: 'Gi1/0/48', remotePortDescription: 'Uplink' }],
      },
      {
        target: '192.168.10.3', hostname: 'SW-ACCESS-01', description: 'Managed Ethernet switch', sysObjectId: '1.3.6.1.4.1.9.1.2', chassisId: '00:11:22:33:44:03', macAddress: '00:11:22:33:44:03', warnings: [],
        vlans: [{ tag: 10, name: 'MGMT' }, { tag: 20, name: 'OT-CONTROL' }],
        ports: [{ name: 'Gi1/0/48', mode: 'trunk', accessVlanTag: '', allowedVlanTags: ['10', '20'], status: 'up', speed: '1 Gbps', confidence: 'inferred', notes: 'Observed VLAN membership.' }],
        interfaceAddresses: [],
        neighbors: [{ localPort: 'Gi1/0/48', remoteSystemName: 'SW-CORE-01', remoteChassisId: '00:11:22:33:44:02', remotePortId: 'Gi1/0/1', remotePortDescription: 'Uplink' }],
      },
    ],
  });
  assert.equal(snapshot.devices.length, 2, 'the already-polled LLDP peer must not be duplicated');
  assert.equal(snapshot.vlans.length, 2, 'VLANs from two switches must be de-duplicated by tag');
  assert.equal(snapshot.links.length, 1, 'the same LLDP link reported by both ends must be de-duplicated');
  assert.equal(snapshot.links[0].confidence, 'confirmed');
  assert.equal(snapshot.links[0].sourcePort.length > 0, true);
  assert.equal(JSON.stringify(snapshot).includes(validCredentials.authPassphrase), false);

  const imported = discoverySnapshotToProject(snapshot, { projectName: 'SNMP lab test' });
  assert.equal(imported.project.devices.length, 2);
  assert.equal(imported.project.vlans.length, 2);
  assert.equal(imported.project.physicalLinks.length, 1);
  assert.deepEqual(imported.project.devices[0].ports[0].allowedVlanIds, ['disc-vlan-10', 'disc-vlan-20']);
});

test('unpolled LLDP neighbours are represented as inferred devices with no invented management IP', () => {
  const snapshot = buildSnmpDiscoverySnapshot({
    switchRecords: [{
      target: '10.10.10.2', hostname: 'SW-EDGE', description: 'Managed switch', sysObjectId: '', chassisId: '00:00:00:00:00:02', macAddress: '',
      vlans: [], ports: [{ name: 'Eth1', mode: 'unknown', accessVlanTag: '', allowedVlanTags: [], status: 'up', speed: '', confidence: 'confirmed', notes: '' }],
      interfaceAddresses: [], warnings: [],
      neighbors: [{ localPort: 'Eth1', remoteSystemName: 'SW-UNKNOWN', remoteChassisId: '00:00:00:00:00:09', remotePortId: 'Eth3', remotePortDescription: 'Uplink' }],
    }],
  });
  const peer = snapshot.devices.find((device) => device.hostname === 'SW-UNKNOWN');
  assert.ok(peer);
  assert.equal(peer.managementIp, '');
  assert.equal(peer.confidence, 'inferred');
  assert.equal(snapshot.links.length, 1);
});

test('actual SNMPv3 adapter closes sessions and exports importable VLAN, interface and LLDP data', async () => {
  const sessions = [];
  const library = {
    ...fakeSnmpLibrary,
    createV3Session(target, user, options) {
      const mocked = fakeSessionFactory({ target, user, options });
      sessions.push(mocked);
      return mocked.session;
    },
  };
  const result = await runSnmpSwitchDiscovery({
    targets: ['192.168.10.2'],
    credentials: validCredentials,
    snmpLibrary: library,
    pollTarget: pollSnmpSwitchTarget,
    collectedAt: '2026-10-28T09:30:00.000Z',
  });
  assert.equal(sessions.length, 1);
  assert.equal(sessions[0].state.closed, true);
  assert.equal(sessions[0].state.user.level, 'authPriv');
  assert.equal(sessions[0].state.user.authProtocol, 'sha256');
  assert.equal(sessions[0].state.user.privProtocol, 'aes');
  assert.equal(sessions[0].state.options.port, 161);
  assert.equal(sessions[0].state.options.retries, 0);
  assert.equal(sessions[0].state.methods.includes('set'), false);
  assert.equal(result.summary.responding, 1);
  assert.equal(result.snapshot.devices[0].hostname, 'SW-CORE-01');
  assert.equal(result.snapshot.vlans[0].name, 'MGMT');
  assert.equal(result.snapshot.devices[0].ports.find((port) => port.name === 'Gi1/0/1').mode, 'access');
  assert.equal(result.snapshot.devices[0].interfaces[0].ip, '192.168.10.2/24');
  assert.equal(result.snapshot.links.length, 1);
  const imported = discoverySnapshotToProject(result.snapshot);
  assert.equal(imported.project.devices.length, 2);
  assert.equal(imported.project.physicalLinks.length, 1);
});

test('discovery continues with partial results when one explicit target fails', async () => {
  const result = await runSnmpSwitchDiscovery({
    targets: ['192.168.10.2', '192.168.10.3'],
    credentials: validCredentials,
    snmpLibrary: fakeSnmpLibrary,
    pollTarget: async ({ target }) => {
      if (target.endsWith('.3')) throw new Error('request timed out');
      return {
        target, hostname: 'SW-ONE', description: 'Managed switch', sysObjectId: '', chassisId: '', macAddress: '',
        interfaces: [], interfaceAddresses: [], ports: [], vlans: [], neighbors: [], warnings: [],
      };
    },
  });
  assert.equal(result.summary.responding, 1);
  assert.equal(result.summary.failed, 1);
  assert.ok(result.snapshot.warnings.some((warning) => warning.includes('192.168.10.3')));
});


test('aborting an in-flight SNMP request closes its session and stops polling', async () => {
  const controller = new AbortController();
  let closed = false;
  let getStarted = false;
  const session = {
    on() { return this; },
    get() { getStarted = true; },
    close() { closed = true; },
  };
  const snmp = {
    ...fakeSnmpLibrary,
    Version3: 3,
    createV3Session() { return session; },
  };
  const poll = pollSnmpSwitchTarget({
    target: '192.168.10.2',
    credentials: validCredentials,
    snmp,
    signal: controller.signal,
    timeoutMs: 1500,
  });
  for (let attempt = 0; attempt < 50 && !getStarted; attempt += 1) await new Promise((resolve) => setTimeout(resolve, 2));
  assert.equal(getStarted, true, 'the poll should have started an SNMP request');
  controller.abort(Object.assign(new Error('lease revoked'), { name: 'AbortError' }));
  await assert.rejects(poll, /lease revoked/);
  assert.equal(closed, true, 'aborting must close the active SNMP session');
});

test('aborted SNMP discovery does not continue to later switch targets', async () => {
  const controller = new AbortController();
  const visited = [];
  const scan = runSnmpSwitchDiscovery({
    targets: ['192.168.10.2', '192.168.10.3'],
    credentials: validCredentials,
    snmpLibrary: fakeSnmpLibrary,
    signal: controller.signal,
    pollTarget: async ({ target, signal }) => {
      visited.push(target);
      return new Promise((_resolve, reject) => {
        signal.addEventListener('abort', () => reject(signal.reason || Object.assign(new Error('cancelled'), { name: 'AbortError' })), { once: true });
      });
    },
  });
  for (let attempt = 0; attempt < 50 && visited.length === 0; attempt += 1) await new Promise((resolve) => setTimeout(resolve, 2));
  controller.abort(Object.assign(new Error('cancelled'), { name: 'AbortError' }));
  await assert.rejects(scan, /cancelled/);
  assert.deepEqual(visited, ['192.168.10.2']);
});
