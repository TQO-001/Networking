import test from 'node:test';
import assert from 'node:assert/strict';
import { diagnosePostgresError } from '../server/database-diagnostics.js';

test('connection refused produces an actionable local PostgreSQL diagnostic', () => {
  const result = diagnosePostgresError({ code: 'ECONNREFUSED', message: 'connect ECONNREFUSED 127.0.0.1:5432' });
  assert.equal(result.code, 'DATABASE_UNAVAILABLE');
  assert.match(result.message, /cannot reach PostgreSQL/i);
  assert.match(result.action, /docker compose up -d --wait db/i);
});

test('bad database credentials do not recommend deleting the existing database', () => {
  const result = diagnosePostgresError({ code: '28P01', message: 'password authentication failed' });
  assert.equal(result.code, 'DATABASE_AUTH_FAILED');
  assert.match(result.message, /does not change automatically/i);
  assert.doesNotMatch(result.action, /down -v|delete.*volume/i);
});

test('a missing database is distinguished from a missing schema', () => {
  assert.equal(diagnosePostgresError({ code: '3D000' }).code, 'DATABASE_NOT_FOUND');
  assert.equal(diagnosePostgresError({ code: '42P01' }).code, 'DATABASE_SCHEMA_OUTDATED');
});

test('unknown application errors are not mislabeled as database connection errors', () => {
  assert.equal(diagnosePostgresError(new Error('render failed')), null);
});
