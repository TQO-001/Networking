# Holly Bibley — physical-first network topology studio

Holly Bibley is a React web application with an Express API and PostgreSQL storage. It keeps the mapper's VLANs, devices, VM groups, firewall interface relationships, remote-session links, field guide, and SVG/PNG/JSON export workflow, while adding real user accounts and server-side private diagram storage.

## Included

- Minimal dark-cinematic homepage with a gold theme and two actions: Login and Sign Up.
- Login, signup, password-reset request, password-reset completion, and signed-out pages. Signup activates the account and signs the user in immediately without email verification. Argon2id password hashes; random opaque session tokens stored only as SHA-256 hashes; HttpOnly, SameSite=Strict cookies; Secure cookies in production; login/signup rate limits; same-origin enforcement on state-changing API requests.
- PostgreSQL users, sessions, reset tokens, and JSONB diagrams. Read/update/delete operations filter by the authenticated user's ID. Optimistic revisions prevent silent overwrites when a diagram is changed in another session.
- SMTP password reset in production. Development without SMTP logs the reset URL to the API console; production startup refuses to run without SMTP configured.
- Physical-first topology editor and 5-chapter practical guide. A physical network is entered once; the logical view is derived from the same device, port, cable, VLAN and explicit interface data.
- Network Discovery: import JSON snapshots, read monitored inventory from deployment-configured LibreNMS, run the local IPv4 discovery CLI, run the SNMPv3 switch collector, or pair an outbound-only local agent and submit discovery jobs directly from the mapper. The paired agent can execute approved local-subnet and explicit SNMPv3 switch jobs, then return a validated snapshot for review. The ICMP/ARP collector creates an initial reachable-host inventory; the SNMPv3 collector can add interface details, VLAN membership and LLDP neighbour links where the switches expose those MIBs.
- Per-VLAN line styling: straight, gentle curve, and deep curve. Device interface connectors are routed to their actual position on the curved segment; the setting is saved in project JSON and stored in PostgreSQL.
- Virtual firewall containment and network connectivity are separate relationships. A virtual firewall can appear as a VM inside its ESXi/server outer group while dashed, interface-specific connectors extend to external VLANs.
- Gold-accent light/dark theme, supplied transparent praying-angel artwork on the landing page, React Bits SideRays, GhostCursor, and WarpText components.

## Requirements

- Node.js 22.12 or later
- npm
- Docker Desktop (or a PostgreSQL 16 instance)
- For real password-reset email in production: an SMTP service and a sender address authorized by that service

## Run locally on Windows

1. Extract the ZIP into a normal folder. Do not open the mapper HTML with `file://`; the authenticated app must run on the same origin as its API.
2. This release intentionally omits any machine-local `.env` file. On first startup, `npm run dev` creates `.env` from `.env.example`; the example uses development-only credentials, so never expose this configuration publicly. If you need to recreate it manually, run `Copy-Item .env.example .env`.
3. In the project folder run:

   ```powershell
   npm install
   npm run dev
   ```

   The development launcher checks/starts the bundled PostgreSQL container, safely aligns the local database role password with `.env` if PostgreSQL rejects the configured credentials, applies migrations, then starts the API and frontend. No manual migration command is required for the normal first run.
4. The launcher detects a private LAN IPv4 address when LAN mode is enabled and prints the URL to use. Open that printed URL on the host or share it with trusted computers on the same reachable LAN. If automatic detection chooses the wrong network adapter, set `HB_LAN_HOST` in `.env` to the host computer’s private IPv4 address, then restart the app.
5. If Windows Firewall blocks other computers, open PowerShell **as Administrator** and add a rule for the frontend only:

   ```powershell
   New-NetFirewallRule -DisplayName "Holly Bibley LAN (TCP 5173)" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 5173 -Profile Private
   ```

   Do not expose ports 3001 (API) or 5432 (PostgreSQL). Other users only need a browser; the host computer must remain powered on with `npm run dev` running. On a managed workplace network, follow your organisation’s firewall policy.
6. For password reset during local development without SMTP, look at the API terminal for the development link. When LAN mode is enabled, the launcher sets the link origin to the detected/configured LAN address.

Stop the local database with `docker compose down`. The named `holly_bibley_data` volume persists your local database. `docker compose down -v` deletes that volume and permanently removes its data.

## Network discovery and LibreNMS import

The persistent local-agent workflow is documented in [`public/mapper/local-discovery-agent.md`](public/mapper/local-discovery-agent.md). In the mapper, choose **Discover network → Generate pairing code**, then run `npm run discovery:agent -- --server https://your-hostname --name "OT engineering laptop"` on a computer inside the target network. The command prompts for the one-time code, saves its bearer token in a per-user config file, and polls for jobs over outbound HTTPS. Pairing and job creation require an authenticated account; tokens are hashed server-side and can be revoked in the mapper. Do not copy the application server's `.env` or database credentials onto the agent machine.

In the mapper, choose **Discover network** to load the included sample snapshot, import a JSON snapshot from another authorised collector, or—when enabled by the server administrator—import monitored inventory from LibreNMS. Review the scope label, devices, VLANs, links and warnings before replacing the current diagram or saving the result as a separate diagram.

The adapter-neutral format is documented in [`public/mapper/discovery-snapshot-format.md`](public/mapper/discovery-snapshot-format.md), with a synthetic sample at [`public/mapper/discovery-sample.json`](public/mapper/discovery-sample.json). Version-4 and version-5 diagrams continue to normalize into the current version-6 canonical model. Interfaces whose VLAN assignment cannot be established are preserved but not drawn as members of a logical VLAN.

LibreNMS import is disabled unless the server administrator sets `LIBRENMS_BASE_URL`, `LIBRENMS_API_TOKEN`, and `LIBRENMS_ALLOWED_EMAILS`. See [`LIBRENMS-INTEGRATION.md`](LIBRENMS-INTEGRATION.md) for setup and permissions. The optional local discovery CLI can be run from the project root with `node scripts/discover-network.js --list`, followed by an explicitly scoped command such as `node scripts/discover-network.js --cidr 192.168.10.0/24 --out snapshot.json`. See [`public/mapper/local-discovery-agent.md`](public/mapper/local-discovery-agent.md). It is limited to private IPv4 scopes within a local interface's directly assigned network, at most 256 addresses, and one rate-limited ICMP echo per host. It does not scan ports or discover VLANs/switch-port links. Active discovery on production/OT networks must be authorised and follow site safety procedures.

### Validate the agent API lifecycle (local test database only)

The source includes `npm run test:discovery-integration`, an end-to-end HTTP test for signup/session, one-time pairing, job creation/claim, heartbeat, snapshot completion/retrieval, and agent revocation. It uses the bundled synthetic sample and does not scan the network. It also queues a second job, revokes the agent while that job is running, and checks that the job is cancelled and subsequent heartbeat/claim requests are rejected. It creates a throwaway user and deletes it during cleanup.

Do not point this test at your normal development or production database. Create a separate local PostgreSQL database whose name contains `test`, such as `holly_bibley_test`, then set these PowerShell variables using the credentials for that local test database:

```powershell
$env:HB_RUN_DISCOVERY_INTEGRATION = "1"
$env:HB_DISCOVERY_TEST_DATABASE_URL = "postgres://YOUR_LOCAL_USER:URL_ENCODED_TEST_PASSWORD@127.0.0.1:5432/holly_bibley_test"
npm run test:discovery-integration
Remove-Item Env:HB_RUN_DISCOVERY_INTEGRATION
Remove-Item Env:HB_DISCOVERY_TEST_DATABASE_URL
```

The script refuses non-loopback database hosts and database names without `test`, runs the additive schema migration against that test database, starts a local API on an unused loopback port, exercises the HTTP flow, and removes the test account. The agent also rechecks its lease before starting local discovery. It sends heartbeats every five seconds; if the server rejects the lease, the agent aborts in-flight local ping processes or closes its active SNMP session and does not start later probes/targets. Revocation cancels the server-side job atomically, and the revoked token cannot renew the lease or submit a result. A successful run verifies the application/database integration; the normal unit suite alone does not.

For direct switch discovery, create a dedicated SNMPv3 user with authentication and privacy (`authPriv`) and a restrictive read-only view/ACL on the devices. Set `HB_SNMPV3_USERNAME`, `HB_SNMPV3_AUTH_PASSPHRASE`, and `HB_SNMPV3_PRIV_PASSPHRASE` in the local runtime environment; the CLI never accepts secrets as command-line arguments and never writes them to the snapshot. SHA-256 and AES-128 are the defaults. Older algorithms such as MD5 and DES are intentionally disabled. Run `npm run discover:switches -- --targets 192.168.10.2,192.168.10.3 --out switches.json` with actual, explicitly authorised private management IPs, then import the JSON through **Discover network → Import snapshot JSON**. See [`SNMP-SWITCH-DISCOVERY.md`](SNMP-SWITCH-DISCOVERY.md). This direct collector is not a subnet sweep: it polls only the supplied targets. VLAN and LLDP MIB access varies by vendor and switch configuration; access/trunk mode is inferred from membership and must be reviewed. Treat all inventory as sensitive and follow OT change/safety controls.

## Local network sharing notes

- The `.env.example` enables LAN mode and leaves `HB_LAN_HOST` blank for automatic private IPv4 detection. If the machine has multiple adapters, configure `HB_LAN_HOST` in your local `.env`; the launcher sets the runtime app origin and verification-link origin to the detected/configured address.
- Vite listens on all interfaces at port 5173. The Express API stays bound to `127.0.0.1:3001` in development, and PostgreSQL remains bound to `127.0.0.1:5432`; only the frontend port should be allowed through the host firewall.
- Use this only on a trusted private network. The development configuration uses HTTP and the example database password; it is not suitable for untrusted networks or the public internet. For regular team use, deploy behind HTTPS with strong secrets and SMTP.

## Production deployment checklist

This repository is a deployable application foundation, not a hosted service. Before exposing it to users:

1. Use HTTPS end-to-end. Set `NODE_ENV=production`, `APP_ORIGIN=https://your-real-origin`, and `PUBLIC_APP_URL=https://your-real-origin`.
2. Set a unique, strong `DATABASE_URL`, `POSTGRES_PASSWORD` (if using the included Compose file), `SMTP_URL`, and `SMTP_FROM` via your platform's secret manager. Never commit `.env` or secrets.
3. For managed PostgreSQL, enable TLS and set `PGSSL=true` when the service supports a trusted server certificate. Enable provider-managed encryption at rest, automated encrypted backups, restore testing, and a retention policy.
4. Build the frontend with `npm run build`; start the API/static server with `npm start`. Put a properly configured reverse proxy in front if your hosting platform requires one, and forward client IPs correctly only from trusted proxies.
5. Test signup, login, session expiration/logout, reset emails, reset-token expiry/one-use semantics, ownership isolation between two users, revision conflicts, backups/restores, and import/export in the production-like environment.
6. Set monitoring and alerting for API errors, database saturation, disk capacity, backups, and failed email delivery. Configure rate limiting at the edge too if the application runs across multiple API processes.

## Security and data handling

- Passwords are hashed with Argon2id, never stored in plaintext.
- Session tokens are high-entropy random values. The raw value is sent only in a Secure/HttpOnly/SameSite cookie (Secure in production); only its SHA-256 hash is saved in PostgreSQL.
- Diagram ownership is enforced in SQL predicates on each diagram read/write/delete, not merely hidden in the frontend.
- Reset tokens are random, hashed at rest, expire after 30 minutes, can only be used once, and revoke existing sessions after a successful password change.
- State-changing API calls are rejected unless the request's `Origin` exactly matches `APP_ORIGIN`.
- Diagram JSON is not field-level encrypted by the app. Use TLS, database access restrictions, encryption at rest, secure backups, and approved retention policies. Network diagrams can reveal sensitive infrastructure details.
- Production password resets require SMTP. Development-mode reset links are written to the API console only when SMTP is absent. Do not use development mode or console reset links for production.
- Rate limits in Express are process-local. For a multi-instance deployment, add a shared rate-limit store or edge rate limiting.

## VLAN line curves

Select a VLAN and choose its **VLAN line style** in the properties panel, or set it while creating/editing the VLAN:

- **Straight** — conventional horizontal segment.
- **Gentle curve** — a shallow arc for long or visually crowded segments.
- **Deep curve** — a more pronounced arc to distinguish the segment from nearby VLANs.

Connector points and interface labels follow the curve. Curving is a readability convention only; it doesn't imply a physical cable curve or a different VLAN configuration.

## Project files

- `src/` — React pages, styles, and the supplied React Bits effects.
- `server/index.js` — API, authentication, sessions, password resets, owner-scoped diagram storage, and the configured LibreNMS integration endpoints.
- `server/librenms-adapter.js` — read-only LibreNMS API client, response normalization, import limits and access checks.
- `scripts/discover-switches.js` and `scripts/lib/snmp-switch-discovery.js` — local, explicit-target SNMPv3 switch collection and snapshot conversion.
- `scripts/discovery-agent.js` and `scripts/lib/discovery-agent-runtime.js` — paired outbound-only agent loop, job validation, and local execution.
- `server/discovery-agent.js` — server-side job/snapshot validation.
- `discovery_agents`, `discovery_agent_pairings`, and `discovery_jobs` tables in `server/schema.sql` — pairing, token hashes, queued work, lease tokens, and short-lived results.
- `server/schema.sql` — PostgreSQL schema.
- `server/migrate.js` — schema setup.
- `server/database-diagnostics.js` — safe PostgreSQL error classification.
- `scripts/dev-preflight.js` — local database preflight and development startup.
- `scripts/db-doctor.js` — connection, credentials, and schema diagnostics.
- `scripts/db-sync-local-password.js` — opt-in, local-only role password alignment for an existing Compose database volume.
- `DATABASE-RECOVERY.md` — step-by-step recovery for signup/database failures.
- `public/mapper.html` and `public/mapper-app.js` — editor shell, API saves, state, interaction wiring, and export controls.
- `public/assets/praying-person-placeholder.svg` — transparent decorative placeholder illustration; replaceable with your own licensed transparent image asset.
- `public/logical-network-mapping-guide.md` — complete written guide.

## Local database credentials

The downloadable source package intentionally does not include a machine-local `.env`. On first startup, `npm run dev` copies `.env.example` to `.env` if the file does not exist. The example uses `123password` for the bundled PostgreSQL role as a local-development convenience only. Change it before sharing the environment or exposing any service beyond your own computer; never use these defaults in production. `DATABASE_URL` and `POSTGRES_PASSWORD` must use the same value.

For a separate local discovery-agent computer, do not copy the server `.env`. Create a minimal agent-side `.env` containing only the SNMPv3 read-only settings if switch discovery is needed. The agent never needs the server database or SMTP credentials.

If PostgreSQL reports `password authentication failed`, `npm run dev` attempts a **local Compose-only** repair: it starts/ensures the bundled database is running, uses the container's local `psql` socket to set the configured role password to the value in `.env`, and verifies the application connection again. This changes only the local database role password; it does not delete the volume, accounts, or diagrams. The repair is disabled when `HB_SKIP_DOCKER_DB=1` is set, and the helper explicitly refuses non-local hosts.

Manual recovery, if needed:

```powershell
npm run db:sync-local-password
npm run db:doctor
npm run dev
```

The generated `.env` is excluded from the source release and from version control. Keep it local and do not commit or share it.

## Useful commands

```powershell
npm run dev       # React/Vite frontend + API watch mode
npm run build     # Production frontend bundle
npm start         # Serve production bundle and API
npm run db:migrate
npm run check:mapper # Syntax checks and automated tests
npm run format      # Format the codebase consistently
npm run check       # Model tests and production build
```


## Physical-first mapping architecture

Holly Bibley now uses one canonical project document for both views. Add devices and physical links in **Physical** view, specify both endpoint interfaces, and configure each port's VLAN mode. The **Logical** view is derived from those records:

- An access port's configured VLAN can infer the segment for the attached link, unless the other endpoint explicitly has a conflicting access VLAN.
- A trunk-to-trunk link infers only VLAN tags allowed at both endpoints.
- Routed links and virtual links are recorded separately; the drawing does not guess routes or firewall policy.
- IP addresses, gateway roles, firewall rules, and virtual-switch port-group assignments must be entered and verified; they are never manufactured from a VLAN tag.
- Curves change only how a VLAN lane is drawn. They do not change model relationships.

### Source layout (where to edit things)

- `public/mapper/project-model.js` — project schema, device/port validation, legacy project migration, and automatic logical inference.
- `public/mapper/forms.js` — VLAN, device, physical-link, port-mode, and remote-session dialog markup.
- `public/mapper/inspector-views.js` — sidebar and selected-object properties panel.
- `public/mapper/exports.js` — JSON, SVG and PNG export logic.
- `public/mapper/ui-icons.js` — small interface glyphs used by the editor controls.
- `public/mapper/device-catalog.js` — supported device types, labels and role colors.
- `public/mapper/physical-renderer.js` — physical devices, parent/VM groups, cable paths and physical selection.
- `public/mapper/logical-renderer.js` — VLAN lanes, interface labels, gateways, connections and logical layout.
- `public/mapper/svg-utils.js` — shared SVG helpers and light/dark drawing palette.
- `package.json` and `.prettierrc.json` — standard scripts and formatting rules; run `npm run format` after editing to keep files consistently formatted.
- `tests/topology-model.test.js` — dependency-free tests for physical-to-logical inference and import compatibility.
- `public/mapper-app.js` — editor interaction wiring, forms, account-backed saves and view switching. Keep domain inference out of this file; add it to `project-model.js` and test it separately.
- `server/index.js` — authenticated API and diagram document validation.
- `src/App.jsx` — landing/authentication/workspace routes and blank-project creation.

### Device presentation

Physical and logical diagrams use text-first device cards with role-colored accent strips. External Cisco-style SVG artwork has been removed from the topology canvas. Small utility glyphs remain in the application interface, where they help identify actions rather than competing with device labels.

## PostgreSQL troubleshooting

- `ECONNREFUSED 127.0.0.1:3001` is the browser/Vite failing to reach the API process. Check the `[api]` startup output first; in older builds, an unavailable PostgreSQL server caused the API to exit before opening port 3001. The updated dev preflight starts/checks PostgreSQL and migrates before starting Vite.
- `ECONNREFUSED 127.0.0.1:5432` means the API cannot reach PostgreSQL itself. Run `docker compose up -d --wait db` and then `npm run db:doctor`.
- `DATABASE_AUTH_FAILED` means `.env` credentials do not match the role password inside the existing database volume. Changing `POSTGRES_PASSWORD` in `.env` does not rotate a role password in an already-initialized PostgreSQL volume. Do not run `docker compose down -v` as a troubleshooting shortcut; that deletes local users and diagrams. Use `npm run db:doctor`, confirm which `.env` and database volume you intended, then correct the role password with an authorized PostgreSQL session or restore the matching password in `.env`.
- `DATABASE_SCHEMA_OUTDATED` means the database is reachable but missing a required table/column; run `npm run db:migrate`.
- The API now keeps port 3001 open if PostgreSQL temporarily goes down and returns an actionable HTTP 503 response rather than making Vite report a generic proxy connection refusal.

## Troubleshooting: diagram opens to “We lost this route”

The topology editor is a standalone static page (`public/mapper.html`), while login, signup and the dashboard are React Router pages. The dashboard must open the mapper with a full browser navigation. Version 1.1.2 fixes this for opening an existing diagram, creating a new diagram, and importing JSON. If you still see the old route page after updating, stop the development server, replace the project source with the new package, then restart `npm run dev` and hard-refresh the browser.


## Mobile and cross-platform use

Holly Bibley includes a web app manifest, install icons, safe-area-aware mobile layouts, and a service worker for caching a small static shell. The topology editor and account features still require a live connection; authentication, API responses, and diagram saves are deliberately never cached.

### Install on a phone or tablet

1. Deploy the app behind **HTTPS** (recommended for real use). Browser installation of PWAs generally requires HTTPS; plain HTTP on a LAN IP is not sufficient on most phones.
2. Open the HTTPS address in Safari on iPhone/iPad or Chrome/Edge on Android.
3. On iPhone/iPad, use **Share → Add to Home Screen**. On Android, use the browser menu and choose **Install app** or **Add to Home screen**. The wording depends on browser version.
4. Sign in normally. Keep the server reachable while editing; the service worker does not make account or diagram operations available offline.

### Local network testing

The release does not include a machine-local `.env`. The development launcher creates it from `.env.example` and derives the LAN address at startup. If DHCP changes the address or automatic detection picks the wrong adapter, update `HB_LAN_HOST` in your local `.env` and restart the app; the launcher sets runtime origin variables accordingly. For phone access over plain HTTP, use it for browser testing; PWA installation may be unavailable until HTTPS is configured. Do not port-forward this development server to the public internet.

### Code formatting

The repository includes Prettier configuration and a `format` script. Run `npm install`, then `npm run format` to consistently format JSX, JavaScript, CSS, HTML, JSON, Markdown, and tests on your development machine. Run `npm run format:check` to check formatting without changing files.

## Network discovery release checklist

Version 1.5.5 adds in-progress collector cancellation when an agent lease is lost; version 1.5.4 makes agent revocation and job cancellation transactional and adds lease preflight before discovery; version 1.5.3 corrects release tests and documentation to match `.env.example`-based setup; version 1.5.2 tightens lease-expiry enforcement and excludes machine-local `.env` files from the source release; version 1.5.1 hardened job recovery/retention and shows recent agent activity; version 1.5.0 introduced the paired outbound local discovery agent. See [`DISCOVERY-ROADMAP.md`](./DISCOVERY-ROADMAP.md) for implemented functionality, known verification limits, and the remaining checklist. Use [`public/mapper/local-discovery-agent.md`](./public/mapper/local-discovery-agent.md) for setup and safety instructions.
