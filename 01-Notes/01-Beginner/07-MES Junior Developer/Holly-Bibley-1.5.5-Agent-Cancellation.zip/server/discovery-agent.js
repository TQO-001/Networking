import { parseIPv4Cidr, isPrivateIPv4Cidr } from '../scripts/lib/local-network-discovery.js';
import { validateSnmpTargets } from '../scripts/lib/snmp-switch-discovery.js';

const cleanText = (value, max = 120) => String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, max);

/** Validate job data at both the browser API boundary and the local agent boundary. */
export function validateDiscoveryJobRequest(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new Error('A discovery job object is required.');
  }

  if (input.kind === 'subnet') {
    let scope;
    try {
      scope = parseIPv4Cidr(String(input.cidr ?? ''));
    } catch (error) {
      throw new Error(error.message || 'A valid IPv4 CIDR is required.');
    }
    if (!isPrivateIPv4Cidr(scope.cidr)) {
      throw new Error('Only RFC 1918 private IPv4 subnets are allowed.');
    }
    const interfaceName = cleanText(input.interfaceName, 100);
    return {
      kind: 'subnet',
      request: { cidr: scope.cidr, interfaceName },
    };
  }

  if (input.kind === 'switches') {
    let targets;
    try {
      targets = validateSnmpTargets(Array.isArray(input.targets) ? input.targets : []);
    } catch (error) {
      throw new Error(error.message || 'Explicit private IPv4 switch targets are required.');
    }
    return { kind: 'switches', request: { targets } };
  }

  throw new Error('Unsupported discovery job type. Choose subnet or switches.');
}

export function validatePairingRequest(input) {
  const pairingCode = String(input?.pairingCode ?? '').trim();
  const name = cleanText(input?.name, 120) || 'Holly Bibley discovery agent';
  if (!/^[A-Za-z0-9_-]{24,80}$/.test(pairingCode)) throw new Error('The pairing code is malformed or incomplete.');
  return { pairingCode, name };
}

export function validateAgentSnapshot(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('The discovery agent did not provide a snapshot object.');
  const encoded = JSON.stringify(input);
  if (Buffer.byteLength(encoded, 'utf8') > 2_500_000) throw new Error('The discovery snapshot is too large (maximum 2.5 MB).');
  if (input.schema !== 'holly-bibley-discovery-snapshot' || input.version !== 1) {
    throw new Error('The discovery agent returned an unsupported snapshot format.');
  }
  if (!Array.isArray(input.devices) || input.devices.length > 5000) throw new Error('The snapshot has an invalid or oversized device list.');
  if (!Array.isArray(input.vlans) || input.vlans.length > 4094) throw new Error('The snapshot has an invalid VLAN list.');
  if (!Array.isArray(input.links) || input.links.length > 10000) throw new Error('The snapshot has an invalid or oversized link list.');
  return input;
}
