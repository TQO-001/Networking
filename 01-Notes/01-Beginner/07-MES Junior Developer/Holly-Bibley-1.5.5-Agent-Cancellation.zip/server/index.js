import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import argon2 from 'argon2';
import nodemailer from 'nodemailer';
import pg from 'pg';
import { createHash, randomBytes } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { z } from 'zod';
import { diagnosePostgresError } from './database-diagnostics.js';
import { createLibreNmsSnapshot, getLibreNmsIntegrationStatus, LibreNmsIntegrationError, testLibreNmsConnection } from './librenms-adapter.js';
import { validateAgentSnapshot, validateDiscoveryJobRequest, validatePairingRequest } from './discovery-agent.js';
import { normaliseDiscoverySnapshot } from '../public/mapper/discovery-import.js';

const { Pool } = pg;
const app = express();
const PORT = Number(process.env.PORT || 3001);
const NODE_ENV = process.env.NODE_ENV || 'development';
const IS_PROD = NODE_ENV === 'production';
const APP_ORIGIN = (process.env.APP_ORIGIN || 'http://localhost:5173').replace(/\/$/, '');
const PUBLIC_APP_URL = (process.env.PUBLIC_APP_URL || APP_ORIGIN).replace(/\/$/, '');
const COOKIE_NAME = process.env.COOKIE_NAME || 'hb_session';
const SESSION_DAYS = Math.max(1, Math.min(30, Number(process.env.SESSION_DAYS || 7)));
const SESSION_MS = SESSION_DAYS * 24 * 60 * 60 * 1000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIST_DIR = path.resolve(__dirname, '../dist');

if (!process.env.DATABASE_URL) {
  console.error('DATABASE_URL is required. Copy .env.example to .env, then start PostgreSQL.');
  process.exit(1);
}
if (IS_PROD && !/^https:\/\//i.test(APP_ORIGIN)) {
  console.error('Production APP_ORIGIN must be an HTTPS origin.');
  process.exit(1);
}
if (IS_PROD && !/^https:\/\//i.test(PUBLIC_APP_URL)) {
  console.error('Production PUBLIC_APP_URL must be an HTTPS URL.');
  process.exit(1);
}
if (IS_PROD && !process.env.SMTP_URL) {
  console.error('Production requires SMTP_URL so password reset is delivered rather than silently discarded.');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: Number(process.env.PG_POOL_MAX || 10),
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,
  ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: true } : undefined,
});
pool.on('error', (error) => console.error('[database pool error]', error.message));

app.disable('x-powered-by');
if (IS_PROD) app.set('trust proxy', 1);
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      baseUri: ["'self'"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'", 'data:'],
      formAction: ["'self'"],
      frameAncestors: ["'none'"],
      imgSrc: ["'self'", 'data:', 'blob:', 'https://raw.githubusercontent.com'],
      objectSrc: ["'none'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      upgradeInsecureRequests: IS_PROD ? [] : null,
    },
  },
  referrerPolicy: { policy: 'no-referrer' },
}));
app.use(express.json({ limit: '3mb', strict: true }));
app.use((req, res, next) => {
  res.setHeader('Cache-Control', req.path.startsWith('/api/') ? 'no-store' : 'no-cache');
  next();
});

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many account attempts. Please wait a little before trying again.' } });
const resetLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 5, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many password-reset requests. Please try again later.' } });
const discoveryLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 6, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many discovery requests. Please wait before trying again.' } });
const agentTransportLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 3000, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many discovery agent requests. Slow down and retry.' } });
const jsonString = (max = 120) => z.string().trim().min(1).max(max);
const authEmail = z.string().trim().email().max(254).transform((v) => v.toLowerCase());
const passwordSchema = z.string().min(12, 'Use at least 12 characters.').max(128);
const signupSchema = z.object({ displayName: jsonString(80), email: authEmail, password: passwordSchema });
const loginSchema = z.object({ email: authEmail, password: z.string().min(1).max(128) });
const resetRequestSchema = z.object({ email: authEmail });
const resetCompleteSchema = z.object({ token: z.string().min(32).max(200), password: passwordSchema });
const diagramDocumentSchema = z.object({
  schema: z.literal('holly-bibley-project'),
  version: z.number().int().min(1).max(20),
  projectName: z.string().trim().min(1).max(120),
  vlans: z.array(z.record(z.string(), z.unknown())).max(300),
  devices: z.array(z.record(z.string(), z.unknown())).max(5000),
  physicalLinks: z.array(z.record(z.string(), z.unknown())).max(10000).optional().default([]),
  connections: z.array(z.record(z.string(), z.unknown())).max(10000).optional().default([]),
}).passthrough();
const createDiagramSchema = z.object({ title: z.string().trim().min(1).max(120).optional(), document: diagramDocumentSchema });
const updateDiagramSchema = z.object({ document: diagramDocumentSchema, expectedRevision: z.number().int().positive() });

const hashSecret = (raw) => createHash('sha256').update(raw).digest('hex');
const nowPlus = (ms) => new Date(Date.now() + ms);
const safeUser = (row) => ({ id: row.id, displayName: row.display_name, email: row.email, emailVerified: Boolean(row.email_verified_at), createdAt: row.created_at });
function setSessionCookie(res, token) {
  res.cookie(COOKIE_NAME, token, { httpOnly: true, secure: IS_PROD, sameSite: 'strict', path: '/', maxAge: SESSION_MS });
}
function clearSessionCookie(res) {
  res.clearCookie(COOKIE_NAME, { httpOnly: true, secure: IS_PROD, sameSite: 'strict', path: '/' });
}
function assertSameOrigin(req, res, next) {
  const origin = req.get('origin');
  const normalizedOrigin = origin?.replace(/\/$/, '');
  const localDevelopmentOrigins = !IS_PROD && ['http://127.0.0.1:5173', 'http://localhost:5173'];
  if (!normalizedOrigin || (normalizedOrigin !== APP_ORIGIN && !localDevelopmentOrigins.includes(normalizedOrigin))) {
    return res.status(403).json({ error: 'Request origin could not be verified. Refresh the app and try again.' });
  }
  next();
}
async function requireAuth(req, res, next) {
  try {
    const rawToken = req.cookies?.[COOKIE_NAME] || parseCookie(req.headers.cookie, COOKIE_NAME);
    if (!rawToken) return res.status(401).json({ error: 'Please sign in to continue.' });
    const result = await pool.query(
      `SELECT s.id AS session_id, s.expires_at, u.id, u.display_name, u.email, u.created_at, u.email_verified_at
       FROM sessions s JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = $1 AND s.expires_at > now() LIMIT 1`,
      [hashSecret(rawToken)],
    );
    if (!result.rowCount) {
      clearSessionCookie(res);
      return res.status(401).json({ error: 'Your session has expired. Please sign in again.' });
    }
    req.authUser = result.rows[0];
    req.sessionId = result.rows[0].session_id;
    req.rawSessionToken = rawToken;
    next();
  } catch (error) { next(error); }
}

async function requireDiscoveryAgent(req, res, next) {
  try {
    const match = String(req.get('authorization') || '').match(/^Bearer\s+([A-Za-z0-9_-]{32,100})$/i);
    if (!match) return res.status(401).json({ error: 'A valid discovery agent bearer token is required.' });
    const result = await pool.query(
      `SELECT id AS agent_id, user_id, name FROM discovery_agents
       WHERE token_hash=$1 AND revoked_at IS NULL LIMIT 1`,
      [hashSecret(match[1])],
    );
    if (!result.rowCount) return res.status(401).json({ error: 'The discovery agent token is invalid or has been revoked.' });
    req.discoveryAgent = result.rows[0];
    await pool.query('UPDATE discovery_agents SET last_seen_at=now() WHERE id=$1', [req.discoveryAgent.agent_id]);
    next();
  } catch (error) { next(error); }
}

function readDiscoveryLeaseToken(req, res) {
  const parsed = z.string().uuid().safeParse(req.body?.leaseToken);
  if (!parsed.success) {
    res.status(400).json({ error: 'A valid discovery job lease token is required.' });
    return '';
  }
  return parsed.data;
}
function parseCookie(header = '', name) {
  for (const part of header.split(';')) {
    const index = part.indexOf('=');
    if (index < 0) continue;
    if (part.slice(0, index).trim() === name) {
      try { return decodeURIComponent(part.slice(index + 1).trim()); } catch { return ''; }
    }
  }
  return '';
}
function validationError(error, res) {
  if (error?.name === 'ZodError') {
    const issue = error.issues?.[0];
    const field = issue?.path?.join('.') || 'request';
    return res.status(400).json({ error: `${field}: ${issue?.message || 'Invalid value.'}` });
  }
  return false;
}
async function createSession(userId, req, res) {
  const raw = randomBytes(32).toString('base64url');
  await pool.query('INSERT INTO sessions(user_id, token_hash, expires_at, user_agent) VALUES($1,$2,$3,$4)', [
    userId, hashSecret(raw), nowPlus(SESSION_MS), String(req.get('user-agent') || '').slice(0, 500),
  ]);
  setSessionCookie(res, raw);
}

// Every state-changing browser request must be same-origin. SameSite cookies are an additional layer.
app.use('/api', (req, res, next) => {
  // Agent transport authenticates with a one-time pairing exchange or a hashed bearer token,
  // not the browser's session cookie. All browser mutations still require same-origin checks.
  const agentTransport = req.path.startsWith('/discovery/agent-transport/');
  return ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && !agentTransport
    ? assertSameOrigin(req, res, next)
    : next();
});
app.get('/api/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', database: 'ok' });
  } catch (error) {
    const diagnosis = diagnosePostgresError(error);
    res.status(503).json({
      status: 'unavailable',
      database: 'unavailable',
      code: diagnosis?.code || 'DATABASE_UNAVAILABLE',
      error: diagnosis?.message || 'Holly Bibley cannot currently access PostgreSQL.',
      action: diagnosis?.action || 'Check .env and the PostgreSQL server logs.',
    });
  }
});

app.get('/api/auth/me', requireAuth, (req, res) => res.json({ user: safeUser(req.authUser) }));
// Email verification is intentionally disabled: account creation requires only name, email, and password.
// Keep the legacy verification routes below for compatibility with old links, but new accounts are active immediately.
app.post('/api/auth/signup', authLimiter, async (req, res, next) => {
  try {
    const data = signupSchema.parse(req.body);
    const passwordHash = await argon2.hash(data.password, { type: argon2.argon2id, memoryCost: 19456, timeCost: 2, parallelism: 1 });
    const result = await pool.query(
      'INSERT INTO users(display_name,email,password_hash,email_verified_at) VALUES($1,$2,$3,now()) RETURNING id,display_name,email,created_at,email_verified_at',
      [data.displayName, data.email, passwordHash],
    );
    const user = result.rows[0];
    await createSession(user.id, req, res);
    res.status(201).json({ user: safeUser(user), message: 'Your account is ready.' });
  } catch (error) {
    if (validationError(error, res)) return;
    if (error.code === '23505') return res.status(409).json({ error: 'An account with this email already exists. Try signing in instead.' });
    next(error);
  }
});
app.post('/api/auth/email-verification/request', resetLimiter, async (req, res, next) => {
  try {
    const { email } = resetRequestSchema.parse(req.body);
    const found = await pool.query('SELECT id,email,display_name,email_verified_at FROM users WHERE email=$1 LIMIT 1', [email]);
    if (found.rowCount && !found.rows[0].email_verified_at) {
      const user = found.rows[0];
      const raw = randomBytes(32).toString('base64url');
      await pool.query('DELETE FROM email_verification_tokens WHERE user_id=$1', [user.id]);
      await pool.query('INSERT INTO email_verification_tokens(user_id,token_hash,expires_at) VALUES($1,$2,$3)', [user.id, hashSecret(raw), nowPlus(24 * 60 * 60 * 1000)]);
      await deliverEmailVerification(user, raw);
    }
    res.status(202).json({ message: 'If that address belongs to an unverified account, a new verification link will be sent.' });
  } catch (error) { if (validationError(error, res)) return; next(error); }
});
app.post('/api/auth/email-verification/complete', authLimiter, async (req, res, next) => {
  const tokenSchema = z.object({ token: z.string().min(32).max(200) });
  const client = await pool.connect().catch((error) => { next(error); return null; });
  if (!client) return;
  try {
    const { token } = tokenSchema.parse(req.body);
    await client.query('BEGIN');
    const result = await client.query('SELECT id,user_id FROM email_verification_tokens WHERE token_hash=$1 AND used_at IS NULL AND expires_at > now() LIMIT 1 FOR UPDATE', [hashSecret(token)]);
    if (!result.rowCount) { await client.query('ROLLBACK'); return res.status(400).json({ error: 'This verification link is invalid or expired. Request a new one.' }); }
    const { id: tokenId, user_id: userId } = result.rows[0];
    await client.query('UPDATE users SET email_verified_at=COALESCE(email_verified_at,now()),updated_at=now() WHERE id=$1', [userId]);
    await client.query('UPDATE email_verification_tokens SET used_at=now() WHERE id=$1', [tokenId]);
    await client.query('DELETE FROM email_verification_tokens WHERE user_id=$1 AND id<>$2', [userId, tokenId]);
    const userResult = await client.query('SELECT id,display_name,email,created_at,email_verified_at FROM users WHERE id=$1', [userId]);
    await client.query('COMMIT');
    await createSession(userId, req, res);
    res.json({ user: safeUser(userResult.rows[0]), message: 'Email verified. Your account is ready.' });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => { });
    if (validationError(error, res)) return;
    next(error);
  } finally { client.release(); }
});
app.post('/api/auth/login', authLimiter, async (req, res, next) => {
  try {
    const data = loginSchema.parse(req.body);
    const result = await pool.query('SELECT id,display_name,email,password_hash,created_at,email_verified_at FROM users WHERE email=$1 LIMIT 1', [data.email]);
    const user = result.rows[0];
    const valid = user ? await argon2.verify(user.password_hash, data.password).catch(() => false) : false;
    if (!valid) return res.status(401).json({ error: 'Email or password is incorrect.' });
    // Email verification is disabled; a valid email/password pair is sufficient to sign in.
    await createSession(user.id, req, res);
    res.json({ user: safeUser(user) });
  } catch (error) { if (validationError(error, res)) return; next(error); }
});
app.post('/api/auth/logout', async (req, res, next) => {
  try {
    const raw = req.cookies?.[COOKIE_NAME] || parseCookie(req.headers.cookie, COOKIE_NAME);
    if (raw) await pool.query('DELETE FROM sessions WHERE token_hash=$1', [hashSecret(raw)]);
    clearSessionCookie(res);
    res.json({ ok: true });
  } catch (error) { next(error); }
});

function openDevelopmentLink(url) {
  if (IS_PROD) return;
  try {
    let command;
    let args;
    if (process.platform === 'win32') {
      command = 'cmd';
      args = ['/c', 'start', '', url];
    } else if (process.platform === 'darwin') {
      command = 'open';
      args = [url];
    } else {
      command = 'xdg-open';
      args = [url];
    }
    const child = spawn(command, args, { detached: true, stdio: 'ignore', windowsHide: true });
    child.on('error', (error) => console.warn('[could not open development link automatically]', error.message));
    child.unref();
  } catch (error) {
    console.warn('[could not open development link automatically]', error.message);
  }
}

app.post('/api/auth/password-reset/request', resetLimiter, async (req, res, next) => {
  try {
    const { email } = resetRequestSchema.parse(req.body);
    const found = await pool.query('SELECT id,email,display_name FROM users WHERE email=$1 LIMIT 1', [email]);
    if (found.rowCount) {
      const user = found.rows[0];
      const raw = randomBytes(32).toString('base64url');
      await pool.query('INSERT INTO password_reset_tokens(user_id,token_hash,expires_at) VALUES($1,$2,$3)', [user.id, hashSecret(raw), nowPlus(30 * 60 * 1000)]);
      const url = `${PUBLIC_APP_URL}/reset-password?token=${encodeURIComponent(raw)}`;
      if (process.env.SMTP_URL) {
        const transport = nodemailer.createTransport(process.env.SMTP_URL);
        await transport.sendMail({
          from: process.env.SMTP_FROM || 'Holly Bibley <no-reply@example.com>',
          to: user.email,
          subject: 'Reset your Holly Bibley password',
          text: `Hello ${user.display_name},\n\nUse this link to reset your password. It expires in 30 minutes:\n${url}\n\nIf you did not request this, ignore this email.`,
          html: `<p>Hello ${escapeHtml(user.display_name)},</p><p>Use this link to reset your password. It expires in 30 minutes.</p><p><a href="${url}">Reset password</a></p><p>If you did not request this, ignore this email.</p>`,
        });
      } else if (!IS_PROD) {
        console.info(`[DEV PASSWORD RESET] ${user.email}: ${url}`);
        openDevelopmentLink(url);
      } else {
        // Startup guards against this configuration, but fail closed if the environment changes.
        throw new Error('SMTP_URL is required for production password reset.');
      }
    }
    res.status(202).json({ message: 'If that email belongs to an account, password-reset instructions will be sent.' });
  } catch (error) { if (validationError(error, res)) return; next(error); }
});
app.post('/api/auth/password-reset/complete', authLimiter, async (req, res, next) => {
  const client = await pool.connect().catch((error) => { next(error); return null; });
  if (!client) return;
  try {
    const data = resetCompleteSchema.parse(req.body);
    await client.query('BEGIN');
    const result = await client.query(
      'SELECT id,user_id FROM password_reset_tokens WHERE token_hash=$1 AND used_at IS NULL AND expires_at > now() LIMIT 1 FOR UPDATE',
      [hashSecret(data.token)],
    );
    if (!result.rowCount) { await client.query('ROLLBACK'); return res.status(400).json({ error: 'This reset link is invalid or expired. Request a new one.' }); }
    const { id: tokenId, user_id: userId } = result.rows[0];
    const passwordHash = await argon2.hash(data.password, { type: argon2.argon2id, memoryCost: 19456, timeCost: 2, parallelism: 1 });
    await client.query('UPDATE users SET password_hash=$1,updated_at=now() WHERE id=$2', [passwordHash, userId]);
    await client.query('UPDATE password_reset_tokens SET used_at=now() WHERE id=$1', [tokenId]);
    await client.query('DELETE FROM password_reset_tokens WHERE user_id=$1 AND id<>$2', [userId, tokenId]);
    await client.query('DELETE FROM sessions WHERE user_id=$1', [userId]);
    await client.query('COMMIT');
    clearSessionCookie(res);
    res.json({ ok: true, message: 'Your password has been updated. Please sign in again.' });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => { });
    if (validationError(error, res)) return;
    next(error);
  } finally { client.release(); }
});

// LibreNMS integration is deployment-configured and read-only. Credentials never reach browser code,
// and an explicit email allowlist prevents the monitored inventory from being shared with all accounts.
app.get('/api/discovery/librenms/status', requireAuth, (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.json(getLibreNmsIntegrationStatus(process.env, req.authUser.email));
});
app.post('/api/discovery/librenms/test', requireAuth, discoveryLimiter, async (req, res, next) => {
  try {
    await testLibreNmsConnection({ env: process.env, userEmail: req.authUser.email });
    res.json({ ok: true, provider: 'LibreNMS', message: 'LibreNMS connection succeeded. The API token was not stored by Holly Bibley.' });
  } catch (error) {
    if (error instanceof LibreNmsIntegrationError) {
      return res.status(error.statusCode).json({ error: error.message, code: error.code });
    }
    next(error);
  }
});
app.post('/api/discovery/librenms/snapshot', requireAuth, discoveryLimiter, async (req, res, next) => {
  try {
    const snapshot = await createLibreNmsSnapshot({ env: process.env, userEmail: req.authUser.email });
    res.json({ snapshot });
  } catch (error) {
    if (error instanceof LibreNmsIntegrationError) {
      return res.status(error.statusCode).json({ error: error.message, code: error.code });
    }
    next(error);
  }
});

// Local discovery agents connect outbound to Holly Bibley. Pair codes are one-time secrets,
// agent tokens are shown only once and only token hashes are stored in PostgreSQL.
app.get('/api/discovery/agents', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, name, created_at, last_seen_at FROM discovery_agents
       WHERE user_id=$1 AND revoked_at IS NULL ORDER BY created_at DESC`,
      [req.authUser.id],
    );
    res.setHeader('Cache-Control', 'no-store');
    res.json({ agents: result.rows.map((row) => ({ id: row.id, name: row.name, createdAt: row.created_at, lastSeenAt: row.last_seen_at })) });
  } catch (error) { next(error); }
});

app.post('/api/discovery/agents/pairing', requireAuth, discoveryLimiter, async (req, res, next) => {
  try {
    const recent = await pool.query(
      `SELECT count(*)::int AS count FROM discovery_agent_pairings
       WHERE user_id=$1 AND created_at > now() - interval '15 minutes'`,
      [req.authUser.id],
    );
    if (Number(recent.rows[0]?.count || 0) >= 5) return res.status(429).json({ error: 'Too many pairing codes were requested. Wait 15 minutes before generating another.' });
    const rawCode = randomBytes(24).toString('base64url');
    const expiresAt = nowPlus(10 * 60 * 1000);
    await pool.query(
      'INSERT INTO discovery_agent_pairings(code_hash,user_id,expires_at) VALUES($1,$2,$3)',
      [hashSecret(rawCode), req.authUser.id, expiresAt],
    );
    res.status(201).json({ pairingCode: rawCode, expiresAt, message: 'This one-time code expires in 10 minutes and can pair only one agent.' });
  } catch (error) { next(error); }
});

app.delete('/api/discovery/agents/:id', requireAuth, discoveryLimiter, async (req, res, next) => {
  const client = await pool.connect().catch((error) => { next(error); return null; });
  if (!client) return;
  try {
    // Revocation and cancellation must commit together. Otherwise a failed second query can
    // leave an agent revoked while its queued/running jobs remain eligible for processing.
    await client.query('BEGIN');
    const result = await client.query(
      `UPDATE discovery_agents SET revoked_at=now()
       WHERE id=$1 AND user_id=$2 AND revoked_at IS NULL RETURNING id`,
      [req.params.id, req.authUser.id],
    );
    if (!result.rowCount) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Paired discovery agent not found.' });
    }
    await client.query(
      `UPDATE discovery_jobs SET status='cancelled', completed_at=now(), lease_expires_at=NULL,
         lease_token=NULL, error_text='Agent was revoked.'
       WHERE agent_id=$1 AND user_id=$2 AND status IN ('queued','running')`,
      [req.params.id, req.authUser.id],
    );
    await client.query('COMMIT');
    res.json({ ok: true, message: 'Discovery agent revoked. Its token can no longer be used.' });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    next(error);
  } finally {
    client.release();
  }
});

app.post('/api/discovery/agents/:id/jobs', requireAuth, discoveryLimiter, async (req, res, next) => {
  try {
    let jobRequest;
    try { jobRequest = validateDiscoveryJobRequest(req.body); }
    catch (error) { return res.status(400).json({ error: error.message || 'Invalid discovery request.' }); }

    const agent = await pool.query(
      'SELECT id FROM discovery_agents WHERE id=$1 AND user_id=$2 AND revoked_at IS NULL LIMIT 1',
      [req.params.id, req.authUser.id],
    );
    if (!agent.rowCount) return res.status(404).json({ error: 'Paired discovery agent not found.' });
    const outstanding = await pool.query(
      `SELECT count(*)::int AS count FROM discovery_jobs
       WHERE agent_id=$1 AND user_id=$2 AND status IN ('queued','running') AND expires_at > now()`,
      [req.params.id, req.authUser.id],
    );
    if (Number(outstanding.rows[0]?.count || 0) >= 3) return res.status(429).json({ error: 'This agent already has three queued or running jobs. Wait for one to finish.' });
    const created = await pool.query(
      `INSERT INTO discovery_jobs(user_id,agent_id,kind,request)
       VALUES($1,$2,$3,$4::jsonb) RETURNING id,kind,status,created_at`,
      [req.authUser.id, req.params.id, jobRequest.kind, JSON.stringify(jobRequest.request)],
    );
    const row = created.rows[0];
    res.status(202).json({ job: { id: row.id, kind: row.kind, status: row.status, createdAt: row.created_at } });
  } catch (error) { next(error); }
});

app.get('/api/discovery/jobs/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id,kind,status,result,error_text,created_at,started_at,completed_at
       FROM discovery_jobs WHERE id=$1 AND user_id=$2 AND expires_at > now() LIMIT 1`,
      [req.params.id, req.authUser.id],
    );
    if (!result.rowCount) return res.status(404).json({ error: 'Discovery job not found.' });
    const row = result.rows[0];
    res.setHeader('Cache-Control', 'no-store');
    res.json({ job: { id: row.id, kind: row.kind, status: row.status, snapshot: row.result || null, error: row.error_text || '', createdAt: row.created_at, startedAt: row.started_at, completedAt: row.completed_at } });
  } catch (error) { next(error); }
});

// These endpoints are for the installed local agent. They do not use browser cookies and are
// deliberately outside the same-origin mutation middleware; bearer-token authentication applies.
const agentPairSchema = z.object({ pairingCode: z.string().min(24).max(80), name: z.string().trim().min(1).max(120) });
app.post('/api/discovery/agent-transport/pair', agentTransportLimiter, async (req, res, next) => {
  const client = await pool.connect().catch((error) => { next(error); return null; });
  if (!client) return;
  try {
    const data = validatePairingRequest(agentPairSchema.parse(req.body));
    const rawAgentToken = randomBytes(32).toString('base64url');
    await client.query('BEGIN');
    const pairing = await client.query(
      `SELECT code_hash,user_id FROM discovery_agent_pairings
       WHERE code_hash=$1 AND used_at IS NULL AND expires_at > now() LIMIT 1 FOR UPDATE`,
      [hashSecret(data.pairingCode)],
    );
    if (!pairing.rowCount) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'The pairing code is invalid, expired, or already used. Generate a new code in Holly Bibley.' });
    }
    const userId = pairing.rows[0].user_id;
    const activeAgents = await client.query('SELECT count(*)::int AS count FROM discovery_agents WHERE user_id=$1 AND revoked_at IS NULL', [userId]);
    if (Number(activeAgents.rows[0]?.count || 0) >= 10) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'This account already has ten paired discovery agents. Revoke an unused agent first.' });
    }
    const inserted = await client.query(
      `INSERT INTO discovery_agents(user_id,name,token_hash) VALUES($1,$2,$3)
       RETURNING id,name,created_at`,
      [userId, data.name, hashSecret(rawAgentToken)],
    );
    await client.query('UPDATE discovery_agent_pairings SET used_at=now() WHERE code_hash=$1', [pairing.rows[0].code_hash]);
    await client.query('COMMIT');
    res.status(201).json({ agent: { id: inserted.rows[0].id, name: inserted.rows[0].name, createdAt: inserted.rows[0].created_at }, token: rawAgentToken });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    if (validationError(error, res)) return;
    if (error?.message && !error?.code) return res.status(400).json({ error: error.message });
    next(error);
  } finally { client.release(); }
});

app.post('/api/discovery/agent-transport/claim', agentTransportLimiter, requireDiscoveryAgent, async (req, res, next) => {
  const client = await pool.connect().catch((error) => { next(error); return null; });
  if (!client) return;
  try {
    await client.query('BEGIN');
    // Re-check and lock the agent inside the same transaction as the claim. This closes the
    // gap between bearer-token middleware and a concurrent revocation request.
    const activeAgent = await client.query(
      'SELECT id FROM discovery_agents WHERE id=$1 AND revoked_at IS NULL FOR UPDATE',
      [req.discoveryAgent.agent_id],
    );
    if (!activeAgent.rowCount) {
      await client.query('ROLLBACK');
      return res.status(401).json({ error: 'The discovery agent token is invalid or has been revoked.' });
    }
    const result = await client.query(
      `SELECT id,kind,request FROM discovery_jobs
       WHERE agent_id=$1 AND expires_at > now()
         AND (status='queued' OR (status='running' AND (lease_expires_at IS NULL OR lease_expires_at < now())))
       ORDER BY created_at LIMIT 1 FOR UPDATE SKIP LOCKED`,
      [req.discoveryAgent.agent_id],
    );
    if (!result.rowCount) {
      await client.query('COMMIT');
      return res.json({ job: null });
    }
    const row = result.rows[0];
    const lease = await client.query(
      `UPDATE discovery_jobs SET status='running',started_at=COALESCE(started_at,now()),lease_expires_at=now()+interval '2 minutes',lease_token=gen_random_uuid()
       WHERE id=$1 RETURNING lease_token`,
      [row.id],
    );
    await client.query('UPDATE discovery_agents SET last_seen_at=now() WHERE id=$1', [req.discoveryAgent.agent_id]);
    await client.query('COMMIT');
    res.json({ job: { id: row.id, kind: row.kind, request: row.request, leaseToken: lease.rows[0]?.lease_token } });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    next(error);
  } finally { client.release(); }
});

app.post('/api/discovery/agent-transport/jobs/:id/heartbeat', agentTransportLimiter, requireDiscoveryAgent, async (req, res, next) => {
  try {
    const leaseToken = readDiscoveryLeaseToken(req, res);
    if (!leaseToken) return;
    const result = await pool.query(
      `UPDATE discovery_jobs SET lease_expires_at=now()+interval '2 minutes'
       WHERE id=$1 AND agent_id=$2 AND status='running' AND expires_at > now() AND lease_expires_at > now() AND lease_token=$3 RETURNING id`,
      [req.params.id, req.discoveryAgent.agent_id, leaseToken],
    );
    if (!result.rowCount) return res.status(404).json({ error: 'Running discovery job not found.' });
    await pool.query('UPDATE discovery_agents SET last_seen_at=now() WHERE id=$1', [req.discoveryAgent.agent_id]);
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.post('/api/discovery/agent-transport/jobs/:id/complete', agentTransportLimiter, requireDiscoveryAgent, async (req, res, next) => {
  try {
    const leaseToken = readDiscoveryLeaseToken(req, res);
    if (!leaseToken) return;
    let validated;
    try { validated = validateAgentSnapshot(req.body?.snapshot); }
    catch (error) { return res.status(400).json({ error: String(error?.message || 'Invalid discovery snapshot.').slice(0, 250) }); }
    let snapshot;
    try { snapshot = normaliseDiscoverySnapshot(validated); }
    catch (error) { return res.status(400).json({ error: `Snapshot validation failed: ${String(error?.message || 'invalid snapshot').slice(0, 220)}` }); }
    const result = await pool.query(
      `UPDATE discovery_jobs SET status='completed',result=$1::jsonb,error_text=NULL,completed_at=now(),lease_expires_at=NULL
       WHERE id=$2 AND agent_id=$3 AND status='running' AND expires_at > now() AND lease_expires_at > now() AND lease_token=$4 RETURNING id`,
      [JSON.stringify(snapshot), req.params.id, req.discoveryAgent.agent_id, leaseToken],
    );
    if (!result.rowCount) return res.status(404).json({ error: 'Running discovery job not found or expired.' });
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.post('/api/discovery/agent-transport/jobs/:id/fail', agentTransportLimiter, requireDiscoveryAgent, async (req, res, next) => {
  try {
    const leaseToken = readDiscoveryLeaseToken(req, res);
    if (!leaseToken) return;
    const message = String(req.body?.error || 'Discovery job failed.').replace(/[\r\n\t\u0000-\u001f\u007f]/g, ' ').slice(0, 500);
    const result = await pool.query(
      `UPDATE discovery_jobs SET status='failed',error_text=$1,completed_at=now(),lease_expires_at=NULL
       WHERE id=$2 AND agent_id=$3 AND status='running' AND expires_at > now() AND lease_expires_at > now() AND lease_token=$4 RETURNING id`,
      [message || 'Discovery job failed.', req.params.id, req.discoveryAgent.agent_id, leaseToken],
    );
    if (!result.rowCount) return res.status(404).json({ error: 'Running discovery job not found or expired.' });
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.get('/api/projects', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query('SELECT id,title,revision,created_at,updated_at, jsonb_array_length(document->\'vlans\') AS vlan_count, jsonb_array_length(document->\'devices\') AS device_count FROM diagrams WHERE user_id=$1 ORDER BY updated_at DESC', [req.authUser.id]);
    res.json({ projects: result.rows.map(row => ({ id: row.id, title: row.title, revision: row.revision, createdAt: row.created_at, updatedAt: row.updated_at, vlanCount: Number(row.vlan_count || 0), deviceCount: Number(row.device_count || 0) })) });
  } catch (error) { next(error); }
});
app.post('/api/projects', requireAuth, async (req, res, next) => {
  try {
    const data = createDiagramSchema.parse(req.body);
    const title = data.title || data.document.projectName;
    const result = await pool.query(
      'INSERT INTO diagrams(user_id,title,document) VALUES($1,$2,$3::jsonb) RETURNING id,title,document,revision,created_at,updated_at',
      [req.authUser.id, title, JSON.stringify(data.document)],
    );
    const row = result.rows[0];
    res.status(201).json({ project: { id: row.id, title: row.title, document: row.document, revision: row.revision, createdAt: row.created_at, updatedAt: row.updated_at } });
  } catch (error) { if (validationError(error, res)) return; next(error); }
});
app.get('/api/projects/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query('SELECT id,title,document,revision,created_at,updated_at FROM diagrams WHERE id=$1 AND user_id=$2 LIMIT 1', [req.params.id, req.authUser.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Diagram not found.' });
    const row = result.rows[0];
    res.json({ project: { id: row.id, title: row.title, document: row.document, revision: row.revision, createdAt: row.created_at, updatedAt: row.updated_at } });
  } catch (error) { next(error); }
});
app.put('/api/projects/:id', requireAuth, async (req, res, next) => {
  try {
    const data = updateDiagramSchema.parse(req.body);
    const result = await pool.query(
      'UPDATE diagrams SET title=$1,document=$2::jsonb,revision=revision+1,updated_at=now() WHERE id=$3 AND user_id=$4 AND revision=$5 RETURNING id,title,document,revision,created_at,updated_at',
      [data.document.projectName, JSON.stringify(data.document), req.params.id, req.authUser.id, data.expectedRevision],
    );
    if (!result.rowCount) {
      const exists = await pool.query('SELECT revision FROM diagrams WHERE id=$1 AND user_id=$2', [req.params.id, req.authUser.id]);
      if (!exists.rowCount) return res.status(404).json({ error: 'Diagram not found.' });
      return res.status(409).json({ error: 'This diagram changed in another session. Reload the latest copy before continuing.', currentRevision: exists.rows[0].revision });
    }
    const row = result.rows[0];
    res.json({ project: { id: row.id, title: row.title, document: row.document, revision: row.revision, createdAt: row.created_at, updatedAt: row.updated_at } });
  } catch (error) { if (validationError(error, res)) return; next(error); }
});
app.delete('/api/projects/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query('DELETE FROM diagrams WHERE id=$1 AND user_id=$2 RETURNING id', [req.params.id, req.authUser.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Diagram not found.' });
    res.json({ ok: true });
  } catch (error) { next(error); }
});

// Static client and the legacy mapper share the origin, so the HttpOnly session cookie also protects the mapper API calls.
app.use(express.static(DIST_DIR, { index: false, maxAge: IS_PROD ? '1h' : 0 }));
app.use((req, res, next) => {
  if (!['GET', 'HEAD'].includes(req.method)) return next();
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'API route not found.' });
  res.sendFile(path.join(DIST_DIR, 'index.html'), (error) => { if (error) next(error); });
});
app.use((error, _req, res, _next) => {
  if (error?.type === 'entity.too.large') return res.status(413).json({ error: 'This diagram is too large to save.' });
  if (error instanceof SyntaxError && 'body' in error) return res.status(400).json({ error: 'Invalid JSON request.' });

  const diagnosis = diagnosePostgresError(error);
  if (diagnosis) {
    console.error(`[database error] ${diagnosis.code}: ${error?.message || 'Unknown database error'}`);
    return res.status(503).json({ error: diagnosis.message, code: diagnosis.code, action: diagnosis.action });
  }

  console.error('[api error]', error?.message || 'Unknown error');
  res.status(500).json({ error: 'The request could not be completed. Check the API terminal for details.' });
});

// Do not make API availability depend on PostgreSQL being up at the exact instant the
// process starts. Keeping the listener alive avoids Vite ECONNREFUSED errors and lets
// /api/health and signup return an actionable database diagnostic while DB recovers.
if (IS_PROD) {
  try { await readFile(path.join(DIST_DIR, 'index.html')); }
  catch {
    console.error('Startup failed: Frontend build not found. Run npm run build before starting production mode.');
    process.exit(1);
  }
}

async function pruneExpiredDiscoveryData() {
  await pool.query('DELETE FROM discovery_jobs WHERE expires_at <= now()');
  await pool.query(`DELETE FROM discovery_agent_pairings
    WHERE expires_at < now() - interval '1 day'
       OR (used_at IS NOT NULL AND used_at < now() - interval '1 day')`);
}

const discoveryPruneTimer = setInterval(() => {
  pruneExpiredDiscoveryData().catch((error) => console.warn('[discovery retention cleanup]', error.message));
}, 60 * 60 * 1000);
discoveryPruneTimer.unref?.();

const server = app.listen(PORT, IS_PROD ? '0.0.0.0' : '127.0.0.1', () => {
  console.log(`Holly Bibley API ready on port ${PORT} (${NODE_ENV}).`);
  pool.query('SELECT 1')
    .then(async () => {
      console.log('[database] PostgreSQL connection OK.');
      await pruneExpiredDiscoveryData().catch((error) => console.warn('[discovery retention cleanup]', error.message));
    })
    .catch((error) => {
      const diagnosis = diagnosePostgresError(error);
      console.error(`[database] ${diagnosis?.code || 'DATABASE_UNAVAILABLE'}: ${diagnosis?.message || error.message}`);
      if (diagnosis?.action) console.error(`[database] Next step: ${diagnosis.action}`);
    });
});

server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`Startup failed: port ${PORT} is already in use. Stop the other process or change PORT in .env.`);
  } else {
    console.error('API server error:', error.message);
  }
  process.exit(1);
});

function escapeHtml(text = '') {
  return String(text).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
