/**
 * Turn common PostgreSQL errors into safe, actionable messages for local development
 * and API clients. Never include the connection string or raw credentials in output.
 */
export function diagnosePostgresError(error) {
  const code = String(error?.code || '');

  if (code === '28P01' || code === '28000') {
    return {
      code: 'DATABASE_AUTH_FAILED',
      message: 'PostgreSQL rejected the configured username or password. Check DATABASE_URL, POSTGRES_USER, and POSTGRES_PASSWORD in .env. If you changed the password after creating the Docker database volume, the existing database role password does not change automatically.',
      action: 'Correct the credentials without deleting the database volume, then restart Holly Bibley.',
    };
  }

  if (code === '3D000') {
    return {
      code: 'DATABASE_NOT_FOUND',
      message: 'The database named in DATABASE_URL does not exist. Check the database name in DATABASE_URL and POSTGRES_DB in .env.',
      action: 'Create the database or start the matching Docker Compose database, then run npm run db:migrate.',
    };
  }

  if (code === '42P01' || code === '42703') {
    return {
      code: 'DATABASE_SCHEMA_OUTDATED',
      message: 'The connected database is missing a required table or column. The application schema may not have been migrated.',
      action: 'Run npm run db:migrate from the Holly Bibley project folder, then retry.',
    };
  }

  if (code === 'ECONNREFUSED' || code === 'ECONNRESET' || code === 'ETIMEDOUT' || code === 'ENOTFOUND' || code === 'EHOSTUNREACH' || code === '57P01' || code === '57P02' || code === '57P03' || code === '53300' || code.startsWith('08')) {
    return {
      code: 'DATABASE_UNAVAILABLE',
      message: 'Holly Bibley cannot reach PostgreSQL. Start the database and confirm DATABASE_URL points to the correct host and port.',
      action: 'For the bundled local database, run docker compose up -d --wait db, then npm run db:migrate.',
    };
  }

  return null;
}
