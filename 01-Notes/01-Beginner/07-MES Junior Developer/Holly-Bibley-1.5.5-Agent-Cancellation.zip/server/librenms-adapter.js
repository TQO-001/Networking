const DEFAULT_MAX_DEVICES = 100;
const ABSOLUTE_MAX_DEVICES = 300;
const DEFAULT_TIMEOUT_MS = 8_000;
const MAX_RESPONSE_CHARS = 12 * 1024 * 1024;

export class LibreNmsIntegrationError extends Error {
  constructor(message, statusCode = 502, code = 'LIBRENMS_ERROR') {
    super(message);
    this.name = 'LibreNmsIntegrationError';
    this.statusCode = statusCode;
    this.code = code;
  }
}

function cleanText(value, limit = 300) {
  return String(value ?? '').trim().slice(0, limit);
}

function parseBaseUrl(raw, isProduction) {
  if (!raw) return null;
  let parsed;
  try {
    parsed = new URL(raw);
  } catch {
    throw new Error('LIBRENMS_BASE_URL must be a valid absolute URL.');
  }
  if (!['https:', 'http:'].includes(parsed.protocol)) throw new Error('LIBRENMS_BASE_URL must use HTTP or HTTPS.');
  if (parsed.username || parsed.password || parsed.search || parsed.hash) throw new Error('LIBRENMS_BASE_URL must not contain credentials, a query string or a fragment.');
  if (isProduction && parsed.protocol !== 'https:') throw new Error('LIBRENMS_BASE_URL must use HTTPS in production.');
  parsed.pathname = parsed.pathname.replace(/\/+$/, '').replace(/\/api\/v0$/i, '');
  return parsed.toString().replace(/\/$/, '');
}

export function getLibreNmsConfig(env = process.env) {
  const rawBaseUrl = cleanText(env.LIBRENMS_BASE_URL, 500);
  const token = cleanText(env.LIBRENMS_API_TOKEN, 1000);
  const allowedEmails = [...new Set(cleanText(env.LIBRENMS_ALLOWED_EMAILS, 4000).split(',').map((email) => email.trim().toLowerCase()).filter(Boolean))];
  const configuredInputs = Boolean(rawBaseUrl && token && allowedEmails.length);
  let baseUrl = null;
  let configError = '';
  if (rawBaseUrl) {
    try { baseUrl = parseBaseUrl(rawBaseUrl, String(env.NODE_ENV || '').toLowerCase() === 'production'); }
    catch (error) { configError = error.message; }
  }
  const numericMax = Number(env.LIBRENMS_MAX_DEVICES || DEFAULT_MAX_DEVICES);
  const maxDevices = Number.isFinite(numericMax) ? Math.max(1, Math.min(ABSOLUTE_MAX_DEVICES, Math.floor(numericMax))) : DEFAULT_MAX_DEVICES;
  const numericTimeout = Number(env.LIBRENMS_REQUEST_TIMEOUT_MS || DEFAULT_TIMEOUT_MS);
  const timeoutMs = Number.isFinite(numericTimeout) ? Math.max(1_000, Math.min(20_000, Math.floor(numericTimeout))) : DEFAULT_TIMEOUT_MS;
  return {
    baseUrl, token, allowedEmails, maxDevices, timeoutMs,
    configured: configuredInputs && Boolean(baseUrl) && !configError,
    configError,
    hasPartialConfiguration: Boolean(rawBaseUrl || token || allowedEmails.length),
  };
}

export function getLibreNmsIntegrationStatus(env = process.env, userEmail = '') {
  const config = getLibreNmsConfig(env);
  if (!config.configured) {
    return {
      available: false,
      provider: 'LibreNMS',
      message: 'LibreNMS import is not configured for this Holly Bibley deployment.',
    };
  }
  if (!config.allowedEmails.includes(cleanText(userEmail, 254).toLowerCase())) {
    return {
      available: false,
      provider: 'LibreNMS',
      message: 'LibreNMS import is not enabled for this account.',
    };
  }
  return { available: true, provider: 'LibreNMS', maxDevices: config.maxDevices };
}

function assertAllowed(config, userEmail) {
  if (!config.configured) {
    const detail = config.configError ? ' Check the LibreNMS deployment configuration.' : '';
    throw new LibreNmsIntegrationError(`LibreNMS import is not configured for this deployment.${detail}`, 503, 'LIBRENMS_NOT_CONFIGURED');
  }
  if (!config.allowedEmails.includes(cleanText(userEmail, 254).toLowerCase())) {
    throw new LibreNmsIntegrationError('LibreNMS import is not enabled for this account.', 403, 'LIBRENMS_FORBIDDEN');
  }
}

function makeEndpoint(baseUrl, route) {
  const root = `${baseUrl.replace(/\/$/, '')}/api/v0/`;
  return new URL(String(route).replace(/^\/+/, ''), root).toString();
}

async function fetchApiJson(config, route, fetchImpl) {
  let response;
  try {
    response = await fetchImpl(makeEndpoint(config.baseUrl, route), {
      method: 'GET',
      headers: { Authorization: `Bearer ${config.token}`, Accept: 'application/json' },
      redirect: 'error',
      signal: AbortSignal.timeout(config.timeoutMs),
    });
  } catch (error) {
    if (error?.name === 'TimeoutError' || error?.name === 'AbortError') {
      throw new LibreNmsIntegrationError('LibreNMS did not respond before the request timed out.', 504, 'LIBRENMS_TIMEOUT');
    }
    throw new LibreNmsIntegrationError('Holly Bibley could not reach the configured LibreNMS API.', 502, 'LIBRENMS_UNREACHABLE');
  }
  if (!response.ok) {
    if (response.status === 401 || response.status === 403) {
      throw new LibreNmsIntegrationError('LibreNMS rejected the API token or denied read access. Check the service account permissions.', 502, 'LIBRENMS_AUTH_FAILED');
    }
    if (response.status === 404) throw new LibreNmsIntegrationError('A required LibreNMS API endpoint was not found. Check the LibreNMS base URL and API version.', 502, 'LIBRENMS_ENDPOINT_NOT_FOUND');
    throw new LibreNmsIntegrationError(`LibreNMS returned HTTP ${response.status}.`, 502, 'LIBRENMS_UPSTREAM_ERROR');
  }
  const contentLength = Number(response.headers?.get?.('content-length') || 0);
  if (contentLength > MAX_RESPONSE_CHARS) throw new LibreNmsIntegrationError('LibreNMS returned a response that exceeds the supported size limit.', 502, 'LIBRENMS_RESPONSE_TOO_LARGE');
  let raw;
  try { raw = await response.text(); }
  catch { throw new LibreNmsIntegrationError('LibreNMS returned an unreadable response.', 502, 'LIBRENMS_BAD_RESPONSE'); }
  if (raw.length > MAX_RESPONSE_CHARS) throw new LibreNmsIntegrationError('LibreNMS returned a response that exceeds the supported size limit.', 502, 'LIBRENMS_RESPONSE_TOO_LARGE');
  let parsed;
  try { parsed = JSON.parse(raw); }
  catch { throw new LibreNmsIntegrationError('LibreNMS returned non-JSON data. Check that the configured URL points to the API.', 502, 'LIBRENMS_BAD_RESPONSE'); }
  if (parsed?.status && !['ok', 'success'].includes(String(parsed.status).toLowerCase())) {
    throw new LibreNmsIntegrationError('LibreNMS reported that the requested API operation failed.', 502, 'LIBRENMS_API_ERROR');
  }
  return parsed;
}

function arrayFrom(payload, property) {
  const value = payload?.[property];
  if (Array.isArray(value)) return value;
  if (value && typeof value === 'object') return Object.values(value);
  return [];
}

function normalizeStatus(value) {
  const status = String(value ?? '').toLowerCase();
  if (['up', '1', 'up(1)', 'ok'].includes(status)) return 'up';
  if (['down', '2', 'down(2)', 'critical'].includes(status)) return 'down';
  return 'unknown';
}

function formatSpeed(raw) {
  const value = Number(raw);
  if (!Number.isFinite(value) || value <= 0) return '';
  if (value >= 1_000_000_000) return `${Number((value / 1_000_000_000).toFixed(2))} Gbps`;
  if (value >= 1_000_000) return `${Number((value / 1_000_000).toFixed(2))} Mbps`;
  if (value >= 1_000) return `${Number((value / 1_000).toFixed(2))} Kbps`;
  return `${value} bps`;
}

function portSpeed(port) {
  const bitsPerSecond = Number(port?.ifSpeed ?? port?.ifSpeed_num);
  if (Number.isFinite(bitsPerSecond) && bitsPerSecond > 0) return formatSpeed(bitsPerSecond);
  // LibreNMS ifHighSpeed is expressed in megabits per second, unlike ifSpeed (bits/s).
  const megabitsPerSecond = Number(port?.ifHighSpeed);
  return Number.isFinite(megabitsPerSecond) && megabitsPerSecond > 0
    ? formatSpeed(megabitsPerSecond * 1_000_000)
    : '';
}

function inferDeviceType(device) {
  const haystack = [device?.os, device?.hardware, device?.sysDescr, device?.purpose, device?.display, device?.sysName, device?.hostname]
    .map((value) => String(value || '').toLowerCase()).join(' ');
  if (/fortiswitch|switch|catalyst|nexus|aruba cx|procurve|ethernet switch|industrial switch|switching/.test(haystack)) return 'Switch';
  if (/fortigate|palo alto|firewall|checkpoint|check point|sonicwall|firepower|pfsense|opnsense/.test(haystack)) return 'Firewall';
  if (/wireless controller|wlc|unifi controller/.test(haystack)) return 'Wireless controller';
  if (/access point|wireless ap|unifi ap/.test(haystack)) return 'Access point';
  if (/router|isr[0-9]|asr[0-9]|junos|routeros|edge router|routing/.test(haystack)) return 'Router';
  if (/vmware esxi|esxi host/.test(haystack)) return 'ESXi host';
  if (/hypervisor/.test(haystack)) return 'Hypervisor';
  if (/server|linux|windows server|freebsd/.test(haystack)) return 'Server';
  return 'Other';
}

function parseCollectedAt(value) {
  if (value == null || value === '') return '';
  const numeric = Number(value);
  const date = Number.isFinite(numeric) && numeric > 1_000_000_000
    ? new Date(numeric * (numeric < 10_000_000_000 ? 1000 : 1))
    : new Date(value);
  return Number.isNaN(date.getTime()) ? '' : date.toISOString();
}

function isVlanTag(value) {
  const number = Number(value);
  return Number.isInteger(number) && number >= 1 && number <= 4094 ? String(number) : '';
}

function normalizeIpAddress(address, prefixLength = '') {
  const ip = cleanText(address, 100);
  if (!ip) return '';
  const prefix = cleanText(prefixLength, 4);
  if (!prefix) return ip;
  const number = Number(prefix);
  const max = ip.includes(':') ? 128 : 32;
  return Number.isInteger(number) && number >= 0 && number <= max ? `${ip}/${number}` : ip;
}

function ipv4ToNumber(address) {
  const octets = String(address || '').split('.');
  if (octets.length !== 4 || octets.some((part) => !/^\d{1,3}$/.test(part) || Number(part) > 255)) return null;
  return octets.reduce((total, part) => total * 256 + Number(part), 0) >>> 0;
}

function networkPrefix(address, prefixLength) {
  const value = ipv4ToNumber(address);
  const prefix = Number(prefixLength);
  if (value === null || !Number.isInteger(prefix) || prefix < 0 || prefix > 32) return '';
  const mask = prefix === 0 ? 0 : (0xffffffff << (32 - prefix)) >>> 0;
  const network = (value & mask) >>> 0;
  return `${[network >>> 24, (network >>> 16) & 255, (network >>> 8) & 255, network & 255].join('.')}/${prefix}`;
}

function isTruthy(value) {
  return value === true || value === 1 || value === '1' || value === 'true';
}

async function mapWithConcurrency(items, concurrency, callback) {
  const results = new Array(items.length);
  let cursor = 0;
  async function worker() {
    while (true) {
      const index = cursor++;
      if (index >= items.length) return;
      results[index] = await callback(items[index], index);
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, () => worker()));
  return results;
}

function uniqueTagsFromPort(port) {
  const values = Array.isArray(port?.vlans) ? port.vlans : [];
  return [...new Set(values.map((item) => isVlanTag(item?.vlan ?? item?.vlan_vlan ?? item?.vlan_id)).filter(Boolean))];
}

function portName(port) {
  return cleanText(port?.ifName || port?.ifDescr || port?.ifAlias || (port?.ifIndex != null ? `ifIndex ${port.ifIndex}` : ''), 80);
}

function untaggedTags(port) {
  const values = Array.isArray(port?.vlans) ? port.vlans : [];
  return [...new Set(values.filter((item) => isTruthy(item?.untagged)).map((item) => isVlanTag(item?.vlan ?? item?.vlan_vlan ?? item?.vlan_id)).filter(Boolean))];
}

function makePortSnapshot(port, warnings, hostname) {
  const name = portName(port);
  const tags = uniqueTagsFromPort(port);
  const untagged = untaggedTags(port);
  if (untagged.length > 1) warnings.push(`${hostname} ${name || 'port'} reports multiple untagged VLANs (${untagged.join(', ')}); the port mode was left unknown.`);
  let mode = 'unknown';
  let accessVlanTag = '';
  let allowedVlanTags = [];
  if (untagged.length > 1) {
    // Conflicting native/untagged VLAN data is preserved in the warning, not translated into a guessed mode.
  } else if (untagged.length === 1 && tags.length === 1) {
    mode = 'access';
    accessVlanTag = untagged[0];
  } else if (tags.length > 1) {
    mode = 'trunk';
    // Include the untagged/native VLAN if LibreNMS reports it. Holly Bibley does not yet
    // model native VLAN separately, so the notes make that limitation explicit.
    allowedVlanTags = tags;
  } else if (tags.length === 1) {
    // A VLAN tag without untagged/native state could be an access port with incomplete data
    // or a single-VLAN trunk. Keep the observation, but leave the mode unclassified.
    allowedVlanTags = tags;
    warnings.push(`${hostname} ${name || 'port'} reports VLAN ${tags[0]} without untagged/native state; the VLAN was retained but port mode left unknown.`);
  }
  const alias = cleanText(port?.ifAlias || port?.ifDescr, 500);
  const notes = [alias, untagged.length && mode === 'trunk' ? `LibreNMS reports untagged/native VLAN ${untagged.join(', ')}; native VLAN is displayed as an allowed VLAN because Holly Bibley does not yet model native VLAN separately.` : '']
    .filter(Boolean).join('\n');
  return {
    _portId: cleanText(port?.port_id ?? port?.id, 80),
    name,
    mode,
    accessVlanTag,
    allowedVlanTags,
    status: normalizeStatus(port?.ifOperStatus ?? port?.ifOperStatus_num ?? port?.status),
    speed: portSpeed(port),
    confidence: name ? 'confirmed' : 'unknown',
    notes,
    _tags: tags,
  };
}

function apiArray(payload, property) {
  return arrayFrom(payload, property);
}

function displayName(device) {
  return cleanText(device?.hostname || device?.sysName || device?.display || device?.ip || device?.ip_address || device?.device_id, 120);
}

function mapDeviceBase(device, index) {
  const id = cleanText(device?.device_id ?? device?.id ?? device?.hostname ?? device?.ip ?? `unknown-${index + 1}`, 100);
  const hostname = displayName(device) || `LibreNMS device ${index + 1}`;
  const key = `librenms-device-${id}`;
  const model = cleanText(device?.hardware || device?.sysDescr || device?.version || device?.os, 100);
  const notes = [device?.os ? `OS: ${cleanText(device.os, 200)}` : '', device?.version ? `Version: ${cleanText(device.version, 200)}` : '', device?.serial ? `Serial: ${cleanText(device.serial, 100)}` : '', device?.location ? `Location: ${cleanText(device.location, 200)}` : '']
    .filter(Boolean).join('\n');
  return {
    sourceId: String(device?.device_id ?? device?.id ?? id),
    key,
    hostname,
    type: inferDeviceType(device),
    model,
    managementIp: cleanText(device?.ip || device?.ip_address || device?.ipv4, 120),
    macAddress: cleanText(device?.mac_address || device?.macAddress, 80),
    confidence: 'confirmed',
    lastSeenAt: parseCollectedAt(device?.last_polled || device?.last_discovered || device?.last_seen),
    notes,
    ports: [],
    interfaces: [],
    rawDevice: device,
  };
}

function addVlan(vlanMap, tagValue, nameValue, warnings = []) {
  const tag = isVlanTag(tagValue);
  if (!tag) return;
  const name = cleanText(nameValue, 100) || `VLAN ${tag}`;
  if (vlanMap.has(tag)) {
    const existing = vlanMap.get(tag);
    if (existing.name !== name && ![existing.name, name].every((item) => item === `VLAN ${tag}`)) {
      warnings.push(`VLAN ${tag} has different names across LibreNMS records (${existing.name} / ${name}); the first name was retained.`);
    } else if (existing.name === `VLAN ${tag}` && name !== `VLAN ${tag}`) {
      existing.name = name;
    }
    return;
  }
  vlanMap.set(tag, { tag, name, subnet: '', gateway: '', notes: 'Imported from LibreNMS. Confirm VLAN naming and Layer 3 addressing against the authoritative configuration.' });
}

function ipv4PrefixForAddress(address) {
  if (!address) return '';
  const [ip, mask] = String(address).split('/');
  if (!mask || !ip.includes('.')) return '';
  return networkPrefix(ip, mask);
}

/**
 * Read-only LibreNMS adapter. The base URL and token come only from deployment configuration;
 * callers cannot supply arbitrary URLs or credentials, preventing the endpoint becoming an SSRF proxy.
 */
export async function createLibreNmsSnapshot({ env = process.env, userEmail, fetchImpl = globalThis.fetch, now = new Date() } = {}) {
  const config = getLibreNmsConfig(env);
  assertAllowed(config, userEmail);
  if (typeof fetchImpl !== 'function') throw new LibreNmsIntegrationError('This Node.js runtime does not provide fetch(). Use Node.js 22 or newer.', 500, 'FETCH_UNAVAILABLE');

  const warnings = [];
  const devicePayload = await fetchApiJson(config, 'devices?type=all&order=hostname', fetchImpl);
  const allDeviceRows = apiArray(devicePayload, 'devices');
  const totalReported = Number(devicePayload?.count || allDeviceRows.length);
  if (!allDeviceRows.length) {
    return {
      schema: 'holly-bibley-discovery-snapshot', version: 1,
      source: { name: 'LibreNMS', adapter: 'librenms-api-v0' }, collectedAt: now.toISOString(),
      scope: { cidr: '', label: 'LibreNMS monitored inventory' },
      warnings: ['LibreNMS returned no monitored devices. Check the service account permissions and device filters.'],
      vlans: [], devices: [], links: [],
    };
  }
  const devicesRows = allDeviceRows.slice(0, config.maxDevices);
  if (allDeviceRows.length > config.maxDevices) {
    warnings.push(`LibreNMS returned ${allDeviceRows.length} devices; the configured import cap is ${config.maxDevices}. Only the first ${config.maxDevices} were processed. Raise LIBRENMS_MAX_DEVICES (maximum ${ABSOLUTE_MAX_DEVICES}) or use a narrower LibreNMS inventory.`);
  } else if (totalReported > allDeviceRows.length) {
    warnings.push(`LibreNMS reports ${totalReported} devices but returned ${allDeviceRows.length} in this response. The snapshot may be incomplete; check the API user's visibility and LibreNMS API response limits.`);
  } else if (allDeviceRows.length >= config.maxDevices) {
    warnings.push(`This import reached the configured ${config.maxDevices}-device limit. Check whether the LibreNMS inventory contains additional devices that were not returned.`);
  }

  const deviceBaseList = devicesRows.map(mapDeviceBase);
  const bySourceId = new Map(deviceBaseList.map((device) => [device.sourceId, device]));

  const [vlanPayloadResult, linksPayloadResult] = await Promise.allSettled([
    fetchApiJson(config, 'resources/vlans', fetchImpl),
    fetchApiJson(config, 'resources/links', fetchImpl),
  ]);
  const vlanMap = new Map();
  if (vlanPayloadResult.status === 'fulfilled') {
    for (const row of apiArray(vlanPayloadResult.value, 'vlans')) addVlan(vlanMap, row?.vlan_vlan ?? row?.vlan, row?.vlan_name, warnings);
  } else {
    warnings.push('LibreNMS VLAN inventory could not be retrieved. VLANs may still be recovered from per-port VLAN associations.');
  }
  let rawLinks = [];
  if (linksPayloadResult.status === 'fulfilled') rawLinks = apiArray(linksPayloadResult.value, 'links');
  else warnings.push('LibreNMS link inventory could not be retrieved. Devices and ports can still be imported, but physical links may be incomplete.');

  const deviceDetails = await mapWithConcurrency(deviceBaseList, 8, async (device) => {
    const endpointId = encodeURIComponent(device.sourceId);
    const [portsResult, ipsResult] = await Promise.allSettled([
      fetchApiJson(config, `devices/${endpointId}/ports?with=vlans`, fetchImpl),
      fetchApiJson(config, `devices/${endpointId}/ip`, fetchImpl),
    ]);
    const rawPorts = portsResult.status === 'fulfilled' ? apiArray(portsResult.value, 'ports') : [];
    const rawAddresses = ipsResult.status === 'fulfilled' ? apiArray(ipsResult.value, 'addresses') : [];
    if (portsResult.status === 'rejected') warnings.push(`${device.hostname}: LibreNMS port details could not be retrieved.`);
    if (ipsResult.status === 'rejected') warnings.push(`${device.hostname}: LibreNMS interface IP addresses could not be retrieved.`);

    const portSnapshots = rawPorts.map((port) => makePortSnapshot(port, warnings, device.hostname)).filter((port) => port.name).slice(0, 300);
    const portById = new Map(portSnapshots.filter((port) => port._portId).map((port) => [port._portId, port]));
    const interfaces = [];
    for (const address of rawAddresses.slice(0, 300)) {
      const ipv4 = cleanText(address?.ipv4_address, 100);
      const ipv6 = cleanText(address?.ipv6_address, 100);
      const addressValue = ipv4 ? normalizeIpAddress(ipv4, address?.ipv4_prefixlen) : normalizeIpAddress(ipv6, address?.ipv6_prefixlen);
      if (!addressValue) continue;
      const port = portById.get(cleanText(address?.port_id, 80));
      const vlanTags = port?._tags || [];
      // A trunk's allowed VLAN list is not proof that an interface IP belongs to one VLAN.
      // Associate IP interfaces only when the observed port is unambiguously an access port.
      const vlanTag = port?.mode === 'access' && vlanTags.length === 1 ? vlanTags[0] : '';
      if (port && vlanTags.length && !vlanTag) warnings.push(`${device.hostname} ${port.name}: IP ${addressValue} could not be safely mapped to one VLAN from the port's reported VLAN associations; the interface was retained without VLAN membership.`);
      if (vlanTag) addVlan(vlanMap, vlanTag, '', warnings);
      const subnet = ipv4PrefixForAddress(addressValue);
      if (vlanTag && subnet) {
        const vlan = vlanMap.get(vlanTag);
        if (vlan && !vlan.subnet) vlan.subnet = subnet;
        else if (vlan && vlan.subnet && vlan.subnet !== subnet) warnings.push(`VLAN ${vlanTag} has multiple observed IPv4 prefixes (${vlan.subnet} and ${subnet}); the first observed prefix was retained.`);
      }
      interfaces.push({
        vlanTag,
        name: port?.name || cleanText(address?.ifName || address?.ifDescr || address?.port_id, 80),
        ip: addressValue,
        peerPort: '',
        status: port?.status || 'unknown',
        macAddress: '',
        confidence: vlanTag ? 'confirmed' : 'unknown',
      });
    }
    const topLevelAddress = device.managementIp;
    if (!topLevelAddress && interfaces.length) device.managementIp = interfaces.find((item) => !item.ip.includes(':'))?.ip || interfaces[0].ip;

    return {
      device,
      ports: portSnapshots.map((port) => {
        for (const tag of port._tags) addVlan(vlanMap, tag, '', warnings);
        const { _portId, _tags, ...publicPort } = port;
        return publicPort;
      }),
      interfaces,
      portById,
    };
  });

  const portNameByDevicePortId = new Map();
  for (const detail of deviceDetails) {
    const sourceId = detail.device.sourceId;
    for (const [portId, port] of detail.portById) portNameByDevicePortId.set(`${sourceId}:${portId}`, port.name);
    detail.device.ports = detail.ports;
    detail.device.interfaces = detail.interfaces;
    delete detail.device.rawDevice;
    delete detail.device.sourceId;
  }

  const devices = deviceBaseList;
  const deviceByHostname = new Map(deviceBaseList.map((device) => [device.hostname.toLowerCase(), device]));
  const seenLinks = new Set();
  const links = [];
  for (const rawLink of rawLinks) {
    const localId = cleanText(rawLink?.local_device_id, 100);
    const remoteId = cleanText(rawLink?.remote_device_id, 100);
    const local = bySourceId.get(localId) || deviceByHostname.get(cleanText(rawLink?.local_hostname, 120).toLowerCase());
    if (!local) {
      warnings.push(`LibreNMS link ${cleanText(rawLink?.id, 80) || '(unknown)'} has no matching local device and was omitted.`);
      continue;
    }
    let remote = bySourceId.get(remoteId) || deviceByHostname.get(cleanText(rawLink?.remote_hostname, 120).toLowerCase());
    if (!remote) {
      const remoteHostname = cleanText(rawLink?.remote_hostname, 120);
      if (!remoteHostname) {
        warnings.push(`LibreNMS link ${cleanText(rawLink?.id, 80) || '(unknown)'} has no identifiable remote device and was omitted.`);
        continue;
      }
      const hostnameSlug = remoteHostname.toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 72) || 'unknown';
      const identity = remoteId || remoteHostname.toLowerCase();
      const identitySuffix = [...new TextEncoder().encode(identity)].map((byte) => byte.toString(16).padStart(2, '0')).join('').slice(0, 20);
      const externalKey = `librenms-neighbour-${hostnameSlug}-${identitySuffix}`.slice(0, 120);
      remote = {
        key: externalKey,
        hostname: remoteHostname,
        type: inferDeviceType({ hardware: rawLink?.remote_platform, sysDescr: rawLink?.remote_version, hostname: remoteHostname }),
        model: cleanText(rawLink?.remote_platform || rawLink?.remote_version, 100),
        managementIp: '',
        macAddress: '',
        confidence: 'inferred',
        lastSeenAt: now.toISOString(),
        notes: `Neighbour reported by LibreNMS using ${cleanText(rawLink?.protocol, 40) || 'an infrastructure discovery protocol'}. This neighbour was not in the monitored-device inventory; verify its identity and address.`,
        ports: [],
        interfaces: [],
      };
      deviceByHostname.set(remoteHostname.toLowerCase(), remote);
      devices.push(remote);
    }
    if (local.key === remote.key) continue;
    const localPort = portNameByDevicePortId.get(`${localId}:${cleanText(rawLink?.local_port_id, 80)}`) || '';
    const remotePort = cleanText(rawLink?.remote_port, 80);
    const pair = [`${local.key}:${localPort}`, `${remote.key}:${remotePort}`].sort().join('|');
    if (seenLinks.has(pair)) continue;
    seenLinks.add(pair);
    const protocol = cleanText(rawLink?.protocol, 40).toLowerCase();
    const linkIsConfirmed = isTruthy(rawLink?.active) && ['lldp', 'cdp'].includes(protocol) && Boolean(localPort && remotePort);
    links.push({
      key: `librenms-link-${cleanText(rawLink?.id, 80) || seenLinks.size}`,
      sourceKey: local.key,
      sourcePort: localPort,
      targetKey: remote.key,
      targetPort: remotePort,
      mediaType: 'Other',
      label: cleanText(rawLink?.protocol, 120).toUpperCase() || 'Discovered neighbour',
      notes: `Reported by LibreNMS${rawLink?.protocol ? ` via ${cleanText(rawLink.protocol, 40)}` : ''}. Confirm port and cabling details against the switch configuration.`,
      confidence: linkIsConfirmed ? 'confirmed' : 'inferred',
      observedAt: now.toISOString(),
    });
  }

  return {
    schema: 'holly-bibley-discovery-snapshot',
    version: 1,
    source: { name: 'LibreNMS', adapter: 'librenms-api-v0' },
    collectedAt: now.toISOString(),
    scope: { cidr: '', label: 'LibreNMS monitored inventory' },
    warnings: [...new Set(warnings)].slice(0, 100),
    vlans: [...vlanMap.values()].sort((left, right) => Number(left.tag) - Number(right.tag)),
    devices: devices.map((device) => ({
      key: device.key,
      hostname: device.hostname,
      type: device.type,
      model: device.model,
      managementIp: device.managementIp,
      macAddress: device.macAddress,
      confidence: device.confidence,
      lastSeenAt: device.lastSeenAt,
      notes: device.notes,
      ports: device.ports,
      interfaces: device.interfaces,
    })),
    links,
  };
}

export async function testLibreNmsConnection({ env = process.env, userEmail, fetchImpl = globalThis.fetch } = {}) {
  const config = getLibreNmsConfig(env);
  assertAllowed(config, userEmail);
  await fetchApiJson(config, '', fetchImpl);
  return { ok: true, provider: 'LibreNMS' };
}
