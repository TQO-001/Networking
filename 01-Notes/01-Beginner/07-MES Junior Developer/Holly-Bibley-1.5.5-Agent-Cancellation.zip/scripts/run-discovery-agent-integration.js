#!/usr/bin/env node
import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { createServer } from 'node:net';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const OPT_IN = process.env.HB_RUN_DISCOVERY_INTEGRATION === '1';
const TEST_DATABASE_URL = process.env.HB_DISCOVERY_TEST_DATABASE_URL || '';
const CHECK_TIMEOUT_MS = 20_000;

function requireSafeTestDatabase(raw) {
  if (!OPT_IN) {
    throw new Error('This test starts a local API and writes test rows. Set HB_RUN_DISCOVERY_INTEGRATION=1 to opt in.');
  }
  if (!raw) throw new Error('Set HB_DISCOVERY_TEST_DATABASE_URL to a dedicated local test database connection URL.');
  let url;
  try { url = new URL(raw); }
  catch { throw new Error('HB_DISCOVERY_TEST_DATABASE_URL is not a valid PostgreSQL URL.'); }
  const host = url.hostname.toLowerCase();
  if (!['localhost', '127.0.0.1', '::1', '[::1]'].includes(host)) {
    throw new Error('Safety stop: the integration test only accepts a loopback PostgreSQL host.');
  }
  const databaseName = decodeURIComponent(url.pathname.replace(/^\//, ''));
  if (!/(?:^|[_-])test(?:$|[_-])/i.test(databaseName)) {
    throw new Error('Safety stop: the PostgreSQL database name must clearly contain "test" (for example, holly_bibley_test).');
  }
  if (url.searchParams.has('sslmode') && ['require', 'verify-ca', 'verify-full'].includes(url.searchParams.get('sslmode'))) {
    throw new Error('Use a dedicated loopback test database URL without remote TLS options.');
  }
  return { url, databaseName };
}

async function availablePort() {
  const server = createServer();
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  const address = server.address();
  const port = typeof address === 'object' && address ? address.port : 0;
  await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  if (!port) throw new Error('Could not reserve a local TCP port for the integration test.');
  return port;
}

function runMigration(env) {
  const result = spawnSync(process.execPath, ['server/migrate.js'], {
    cwd: ROOT,
    env,
    encoding: 'utf8',
    timeout: 30_000,
    windowsHide: true,
  });
  if (result.error || result.status !== 0) {
    const detail = [result.stdout, result.stderr, result.error?.message].filter(Boolean).join('\n').trim();
    throw new Error(`Test-database migration failed. No application test was run.\n${detail.slice(-4000)}`);
  }
}

async function fetchJson(baseUrl, route, { method = 'GET', body, cookie = '', bearer = '' } = {}) {
  const headers = { accept: 'application/json', origin: baseUrl };
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (cookie) headers.cookie = cookie;
  if (bearer) headers.authorization = `Bearer ${bearer}`;
  const response = await fetch(`${baseUrl}${route}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
    redirect: 'error',
    signal: AbortSignal.timeout(10_000),
  });
  const responseText = await response.text();
  let data = {};
  try { data = responseText ? JSON.parse(responseText) : {}; }
  catch { throw new Error(`${method} ${route} returned invalid JSON (HTTP ${response.status}).`); }
  return { response, data };
}

function requireStatus(result, expected, label) {
  assert.equal(result.response.status, expected, `${label}: expected HTTP ${expected}, received ${result.response.status}; response=${JSON.stringify(result.data)}`);
}

async function waitForApi(baseUrl, child, getLog) {
  const started = Date.now();
  while (Date.now() - started < CHECK_TIMEOUT_MS) {
    if (child.exitCode !== null) throw new Error(`API process exited before becoming healthy.\n${getLog()}`);
    try {
      const { response, data } = await fetchJson(baseUrl, '/api/health');
      if (response.status === 200 && data.status === 'ok' && data.database === 'ok') return;
    } catch { /* Wait briefly while the local server starts. */ }
    await new Promise((resolve) => setTimeout(resolve, 300));
  }
  throw new Error(`API did not become healthy within ${CHECK_TIMEOUT_MS / 1000} seconds.\n${getLog()}`);
}

async function stopChild(child) {
  if (!child || child.exitCode !== null) return;
  child.kill('SIGTERM');
  await Promise.race([
    new Promise((resolve) => child.once('exit', resolve)),
    new Promise((resolve) => setTimeout(resolve, 2500)),
  ]);
  if (child.exitCode === null) child.kill('SIGKILL');
}

async function main() {
  const { databaseName } = requireSafeTestDatabase(TEST_DATABASE_URL);
  let pgModule;
  try { pgModule = await import('pg'); }
  catch { throw new Error('PostgreSQL driver is not installed. Run npm install before starting the integration test.'); }
  const { Pool } = pgModule.default || pgModule;
  console.log(`Running the discovery-agent HTTP lifecycle against the dedicated local database "${databaseName}".`);
  console.log('The test creates a throwaway account, pairs an agent, queues a synthetic job, claims it, renews the lease, submits a fixture snapshot, reads the result, revokes the agent, and deletes the test account. It does not scan a network.');

  const env = {
    ...process.env,
    DATABASE_URL: TEST_DATABASE_URL,
    NODE_ENV: 'development',
    HB_LAN_MODE: '0',
    APP_ORIGIN: 'http://127.0.0.1',
    PUBLIC_APP_URL: 'http://127.0.0.1',
    COOKIE_NAME: 'hb_session',
    SMTP_URL: '',
    PORT: '3001',
    LIBRENMS_BASE_URL: '',
    LIBRENMS_API_TOKEN: '',
    LIBRENMS_ALLOWED_EMAILS: '',
  };

  // The API origin is corrected once an unused loopback port has been selected.
  const port = await availablePort();
  const baseUrl = `http://127.0.0.1:${port}`;
  env.PORT = String(port);
  env.APP_ORIGIN = baseUrl;
  env.PUBLIC_APP_URL = baseUrl;

  runMigration(env);

  const db = new Pool({ connectionString: TEST_DATABASE_URL, max: 1, connectionTimeoutMillis: 3000 });
  const email = `hb-discovery-integration-${randomUUID()}@example.invalid`;
  const password = `HB-Test-${randomUUID()}-A9!`;
  let serverProcess;
  let serverLog = '';
  const addLog = (chunk) => {
    serverLog = `${serverLog}${String(chunk)}`.slice(-8000);
  };

  try {
    serverProcess = spawn(process.execPath, ['server/index.js'], {
      cwd: ROOT,
      env,
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
    });
    serverProcess.stdout.on('data', addLog);
    serverProcess.stderr.on('data', addLog);
    await waitForApi(baseUrl, serverProcess, () => serverLog);

    const signup = await fetchJson(baseUrl, '/api/auth/signup', {
      method: 'POST',
      body: { displayName: 'Discovery Integration Test', email, password },
    });
    requireStatus(signup, 201, 'sign up test account');
    const cookieHeader = signup.response.headers.getSetCookie?.()[0] || signup.response.headers.get('set-cookie') || '';
    const cookie = cookieHeader.split(';', 1)[0];
    assert.match(cookie, /^hb_session=/, 'signup must set the authenticated session cookie');

    const pairingCodeResponse = await fetchJson(baseUrl, '/api/discovery/agents/pairing', {
      method: 'POST', cookie, body: {},
    });
    requireStatus(pairingCodeResponse, 201, 'create one-time pairing code');
    assert.ok(pairingCodeResponse.data.pairingCode, 'pairing code must be returned once');

    const pair = await fetchJson(baseUrl, '/api/discovery/agent-transport/pair', {
      method: 'POST', body: { pairingCode: pairingCodeResponse.data.pairingCode, name: 'Integration Test Agent' },
    });
    requireStatus(pair, 201, 'pair the local agent');
    assert.ok(pair.data.agent?.id && pair.data.token, 'pairing must return the agent id and bearer token');

    const queued = await fetchJson(baseUrl, `/api/discovery/agents/${encodeURIComponent(pair.data.agent.id)}/jobs`, {
      method: 'POST', cookie, body: { kind: 'subnet', cidr: '192.168.250.0/24', interfaceName: 'integration-fixture' },
    });
    requireStatus(queued, 202, 'queue synthetic subnet job');
    const jobId = queued.data.job?.id;
    assert.ok(jobId, 'queued response must contain a job id');

    const claim = await fetchJson(baseUrl, '/api/discovery/agent-transport/claim', {
      method: 'POST', bearer: pair.data.token, body: {},
    });
    requireStatus(claim, 200, 'claim queued job');
    assert.equal(claim.data.job?.id, jobId, 'agent must claim the queued job');
    assert.ok(claim.data.job?.leaseToken, 'claim must provide a lease token');

    const heartbeat = await fetchJson(baseUrl, `/api/discovery/agent-transport/jobs/${encodeURIComponent(jobId)}/heartbeat`, {
      method: 'POST', bearer: pair.data.token, body: { leaseToken: claim.data.job.leaseToken },
    });
    requireStatus(heartbeat, 200, 'renew job lease');
    assert.equal(heartbeat.data.ok, true);

    const snapshot = JSON.parse(await readFile(path.join(ROOT, 'public/mapper/discovery-sample.json'), 'utf8'));
    const complete = await fetchJson(baseUrl, `/api/discovery/agent-transport/jobs/${encodeURIComponent(jobId)}/complete`, {
      method: 'POST', bearer: pair.data.token, body: { leaseToken: claim.data.job.leaseToken, snapshot },
    });
    requireStatus(complete, 200, 'submit fixture snapshot');

    const retrieved = await fetchJson(baseUrl, `/api/discovery/jobs/${encodeURIComponent(jobId)}`, { cookie });
    requireStatus(retrieved, 200, 'read completed job result');
    assert.equal(retrieved.data.job?.status, 'completed');
    assert.equal(retrieved.data.job?.snapshot?.schema, 'holly-bibley-discovery-snapshot');
    assert.ok(Array.isArray(retrieved.data.job.snapshot.devices), 'normalized snapshot should include a device list');

    const queuedForCancellation = await fetchJson(baseUrl, `/api/discovery/agents/${encodeURIComponent(pair.data.agent.id)}/jobs`, {
      method: 'POST', cookie, body: { kind: 'subnet', cidr: '192.168.250.0/24', interfaceName: 'integration-fixture-cancel' },
    });
    requireStatus(queuedForCancellation, 202, 'queue second synthetic job for cancellation');
    const cancellationJobId = queuedForCancellation.data.job?.id;
    assert.ok(cancellationJobId, 'cancellation job must have an id');
    const cancellationClaim = await fetchJson(baseUrl, '/api/discovery/agent-transport/claim', {
      method: 'POST', bearer: pair.data.token, body: {},
    });
    requireStatus(cancellationClaim, 200, 'claim second synthetic job before revocation');
    assert.equal(cancellationClaim.data.job?.id, cancellationJobId, 'agent must claim the cancellation fixture job');

    const revoked = await fetchJson(baseUrl, `/api/discovery/agents/${encodeURIComponent(pair.data.agent.id)}`, {
      method: 'DELETE', cookie,
    });
    requireStatus(revoked, 200, 'revoke the paired agent');

    const cancelledJob = await fetchJson(baseUrl, `/api/discovery/jobs/${encodeURIComponent(cancellationJobId)}`, { cookie });
    requireStatus(cancelledJob, 200, 'read the revoked agent job');
    assert.equal(cancelledJob.data.job?.status, 'cancelled', 'revocation must cancel an outstanding running job');
    assert.equal(cancelledJob.data.job?.snapshot, null, 'cancelled job must not contain a result snapshot');

    const heartbeatAfterRevocation = await fetchJson(baseUrl, `/api/discovery/agent-transport/jobs/${encodeURIComponent(cancellationJobId)}/heartbeat`, {
      method: 'POST', bearer: pair.data.token, body: { leaseToken: cancellationClaim.data.job.leaseToken },
    });
    requireStatus(heartbeatAfterRevocation, 401, 'reject revoked agent heartbeat');

    const rejectedAfterRevocation = await fetchJson(baseUrl, '/api/discovery/agent-transport/claim', {
      method: 'POST', bearer: pair.data.token, body: {},
    });
    requireStatus(rejectedAfterRevocation, 401, 'reject a revoked agent token');

    console.log('PASS: signup/session → one-time pairing → queued job → claim → heartbeat → snapshot completion → result retrieval.');
    console.log('PASS: revocation atomically cancels an outstanding job; the cancelled job has no snapshot and the revoked token cannot heartbeat or claim.');
    console.log('The network was not scanned; the test submitted the bundled synthetic snapshot.');
  } finally {
    await stopChild(serverProcess);
    await db.query('DELETE FROM users WHERE email=$1', [email]).catch((error) => {
      console.error(`Warning: could not remove the disposable integration-test account (${error.code || 'DB_ERROR'}).`);
    });
    await db.end().catch(() => {});
  }
}

main().catch((error) => {
  console.error(`Discovery-agent integration test failed: ${String(error?.message || error).slice(0, 5000)}`);
  process.exitCode = 1;
});
