import dotenv from 'dotenv';
import pg from 'pg';
import { diagnosePostgresError } from '../server/database-diagnostics.js';

dotenv.config({ quiet: true });
const { Client } = pg;

if (!process.env.DATABASE_URL) {
  console.error('DATABASE_URL is missing. Copy .env.example to .env and configure it first.');
  process.exit(1);
}

const client = new Client({
  connectionString: process.env.DATABASE_URL,
  connectionTimeoutMillis: 4000,
  ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: true } : undefined,
});

try {
  await client.connect();
  const identity = await client.query('SELECT current_database() AS database, current_user AS role, version() AS version');
  console.log(`PostgreSQL connection: OK\nDatabase: ${identity.rows[0].database}\nRole: ${identity.rows[0].role}\nVersion: ${identity.rows[0].version.split(',')[0]}`);
  const tables = await client.query(`SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_name = ANY($1::text[]) ORDER BY table_name`, [[ 'users', 'sessions', 'diagrams', 'email_verification_tokens', 'password_reset_tokens' ]]);
  const found = new Set(tables.rows.map((row) => row.table_name));
  const required = ['users', 'sessions', 'diagrams', 'email_verification_tokens', 'password_reset_tokens'];
  const missing = required.filter((name) => !found.has(name));
  if (missing.length) {
    console.error(`Database schema: INCOMPLETE\nMissing tables: ${missing.join(', ')}\nRun npm run db:migrate.`);
    process.exitCode = 1;
  } else {
    console.log('Database schema: OK (all required Holly Bibley tables exist).');
  }
} catch (error) {
  const diagnostic = diagnosePostgresError(error);
  console.error(`PostgreSQL connection: FAILED\n${diagnostic?.message || error.message}`);
  if (diagnostic?.action) console.error(diagnostic.action);
  process.exitCode = 1;
} finally {
  await client.end().catch(() => {});
}
