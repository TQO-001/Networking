#!/usr/bin/env node
import 'dotenv/config';
import os from 'node:os';
import path from 'node:path';
import { chmod, mkdir, readFile, writeFile } from 'node:fs/promises';
import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import { fileURLToPath } from 'node:url';
import { executeAgentJob, normaliseAgentServerUrl } from './lib/discovery-agent-runtime.js';

const SCRIPT_PATH = fileURLToPath(import.meta.url);
const MAX_RESPONSE_BYTES = 2_700_000;
const POLL_MS = 3000;

function printHelp() {
  console.log(`Holly Bibley Persistent Local Discovery Agent

Usage:
  npm run discovery:agent -- --server https://holly.example.com [--name "OT laptop"]
  npm run discovery:agent -- --server http://127.0.0.1:3001 --once

Options:
  --server URL      Holly Bibley server origin. HTTPS required except localhost.
  --name NAME       Friendly name shown in Holly Bibley (defaults to this computer's hostname).
  --config FILE     Optional path for the local token file (protect this file like a credential).
  --once            Pair/load configuration, claim at most one job and exit.
  --help            Show this help.

The agent makes outbound HTTPS requests and does not listen on a network port. Discovery jobs are
validated locally before execution. Subnet jobs must be RFC 1918 and directly attached to a local
interface; switch jobs must contain explicit private IPv4 management addresses. SNMPv3 credentials
stay in this machine's local .env file and are never sent to the Holly Bibley server.`);
}

function parseArgs(argv) {
  const options = { server: '', name: '', configPath: '', once: false, help: false };
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === '--once') options.once = true;
    else if (arg === '--help' || arg === '-h') options.help = true;
    else if (['--server', '--name', '--config'].includes(arg)) {
      const value = argv[index + 1];
      if (!value || value.startsWith('--')) throw new Error(`${arg} requires a value.`);
      index += 1;
      if (arg === '--server') options.server = value;
      else if (arg === '--name') options.name = value;
      else options.configPath = value;
    } else throw new Error(`Unknown argument: ${arg}. Use --help for usage.`);
  }
  return options;
}

function defaultConfigPath() {
  if (process.env.APPDATA && process.platform === 'win32') return path.join(process.env.APPDATA, 'HollyBibley', 'discovery-agent.json');
  if (process.platform === 'darwin') return path.join(os.homedir(), 'Library', 'Application Support', 'HollyBibley', 'discovery-agent.json');
  return path.join(os.homedir(), '.config', 'holly-bibley', 'discovery-agent.json');
}

async function readConfig(configPath) {
  try {
    const parsed = JSON.parse(await readFile(configPath, 'utf8'));
    const serverUrl = normaliseAgentServerUrl(parsed.serverUrl);
    if (typeof parsed.token !== 'string' || !/^[A-Za-z0-9_-]{32,100}$/.test(parsed.token)) throw new Error('The local agent token file is invalid. Remove it and pair the agent again.');
    return { serverUrl, token: parsed.token, agentId: String(parsed.agentId || ''), name: String(parsed.name || os.hostname()) };
  } catch (error) {
    if (error?.code === 'ENOENT') return null;
    throw error;
  }
}

async function saveConfig(configPath, config) {
  const directory = path.dirname(configPath);
  await mkdir(directory, { recursive: true, mode: 0o700 });
  await writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`, { encoding: 'utf8', mode: 0o600 });
  if (process.platform !== 'win32') await chmod(configPath, 0o600).catch(() => {});
}

async function postJson(serverUrl, route, { token = '', body = {}, timeoutMs = 15000 } = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(`${serverUrl}${route}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify(body),
      signal: controller.signal,
      redirect: 'error',
    });
    const text = await response.text();
    if (Buffer.byteLength(text, 'utf8') > MAX_RESPONSE_BYTES) throw new Error('The server response exceeds the agent response limit.');
    let payload = {};
    try { payload = text ? JSON.parse(text) : {}; }
    catch { throw new Error(`Holly Bibley returned an invalid JSON response (HTTP ${response.status}).`); }
    if (!response.ok) {
      const error = new Error(payload.error || `Holly Bibley request failed (HTTP ${response.status}).`);
      error.statusCode = response.status;
      throw error;
    }
    return payload;
  } finally {
    clearTimeout(timeout);
  }
}

async function promptPairingCode() {
  const terminal = createInterface({ input: stdin, output: stdout });
  try {
    const code = await terminal.question('Paste the one-time pairing code shown in Holly Bibley: ');
    return code.trim();
  } finally { terminal.close(); }
}

async function ensurePaired(options, configPath) {
  const existing = await readConfig(configPath);
  if (existing) {
    if (options.server && normaliseAgentServerUrl(options.server) !== existing.serverUrl) {
      throw new Error(`This agent is already paired to ${existing.serverUrl}. Use --config with a different file to pair another instance, or remove the existing token file to pair again.`);
    }
    return existing;
  }
  if (!options.server) throw new Error('First-time setup requires --server. Generate a pairing code in Holly Bibley, then run this command again.');
  const serverUrl = normaliseAgentServerUrl(options.server);
  const pairingCode = await promptPairingCode();
  const name = String(options.name || os.hostname()).replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 120) || 'Local discovery agent';
  const paired = await postJson(serverUrl, '/api/discovery/agent-transport/pair', { body: { pairingCode, name } });
  if (!paired.agent?.id || typeof paired.token !== 'string') throw new Error('Holly Bibley returned an incomplete pairing response.');
  const config = { serverUrl, token: paired.token, agentId: paired.agent.id, name: paired.agent.name || name, pairedAt: new Date().toISOString() };
  await saveConfig(configPath, config);
  console.log(`Paired agent "${config.name}". Token saved to ${configPath}; it will not be printed.`);
  return config;
}

function sleep(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

async function renewLease(config, job) {
  return postJson(config.serverUrl, `/api/discovery/agent-transport/jobs/${encodeURIComponent(job.id)}/heartbeat`, {
    token: config.token,
    body: { leaseToken: job.leaseToken },
    timeoutMs: 8000,
  });
}

async function heartbeat(config, job, controller) {
  try {
    await renewLease(config, job);
  } catch (error) {
    if ([401, 404].includes(error?.statusCode)) {
      if (!controller.signal.aborted) {
        controller.abort(Object.assign(new Error('The server no longer recognises this job lease. Discovery was stopped.'), { name: 'AbortError' }));
      }
      return;
    }
    console.warn(`Heartbeat warning for job ${job.id}: ${String(error.message || error).slice(0, 160)}`);
  }
}

async function executeClaimedJob(config, rawJob) {
  const job = rawJob;
  const controller = new AbortController();
  let heartbeatTimer;
  let heartbeatInFlight = false;
  try {
    // A claim can race with a user revoking the agent. Confirm the lease once more before
    // sending any probes or SNMP requests from this computer.
    await renewLease(config, job);
    console.log(`Running ${job.kind} discovery job ${job.id}.`);
    heartbeatTimer = setInterval(() => {
      if (heartbeatInFlight || controller.signal.aborted) return;
      heartbeatInFlight = true;
      void heartbeat(config, job, controller).finally(() => { heartbeatInFlight = false; });
    }, 5000);
    heartbeatTimer.unref?.();
    const result = await executeAgentJob(job, {
      env: process.env,
      signal: controller.signal,
      onProgress: (progress) => {
        if (progress?.completed && progress?.total) console.log(`  Progress: ${progress.completed}/${progress.total}`);
      },
    });
    if (controller.signal.aborted) return;
    await postJson(config.serverUrl, `/api/discovery/agent-transport/jobs/${encodeURIComponent(job.id)}/complete`, {
      token: config.token,
      body: { leaseToken: job.leaseToken, snapshot: result.snapshot },
      timeoutMs: 20000,
    });
    console.log(`Job ${job.id} completed. ${result.summary ? JSON.stringify(result.summary) : ''}`);
  } catch (error) {
    if (controller.signal.aborted || error?.name === 'AbortError' || [401, 404].includes(error?.statusCode)) {
      console.warn(`Stopping discovery for job ${job.id}: its agent token or lease is no longer active.`);
      return;
    }
    const message = String(error?.message || 'Discovery failed.').replace(/[\r\n\t\u0000-\u001f\u007f]/g, ' ').slice(0, 400);
    try {
      await postJson(config.serverUrl, `/api/discovery/agent-transport/jobs/${encodeURIComponent(job.id)}/fail`, {
        token: config.token,
        body: { leaseToken: job.leaseToken, error: message },
        timeoutMs: 8000,
      });
    } catch (reportError) {
      console.error(`Could not report failed job: ${String(reportError.message || reportError).slice(0, 160)}`);
    }
    console.error(`Job ${job.id} failed: ${message}`);
  } finally {
    if (heartbeatTimer) clearInterval(heartbeatTimer);
  }
}

async function main() {
  let options;
  try { options = parseArgs(process.argv.slice(2)); }
  catch (error) {
    console.error(`Error: ${error.message}\nUse --help for usage.`);
    process.exitCode = 2;
    return;
  }
  if (options.help) return printHelp();
  const configPath = path.resolve(options.configPath || defaultConfigPath());
  let config;
  try { config = await ensurePaired(options, configPath); }
  catch (error) {
    console.error(`Agent setup failed: ${String(error.message || error).slice(0, 300)}`);
    process.exitCode = 1;
    return;
  }

  console.log(`Holly Bibley discovery agent "${config.name}" connected to ${config.serverUrl}.`);
  console.log('The agent does not listen on a network port. Press Ctrl+C to stop it.');
  let failures = 0;
  do {
    try {
      const response = await postJson(config.serverUrl, '/api/discovery/agent-transport/claim', { token: config.token, body: {}, timeoutMs: 12000 });
      failures = 0;
      if (response.job) await executeClaimedJob(config, response.job);
      else if (options.once) break;
      else await sleep(POLL_MS);
    } catch (error) {
      if ([401, 403].includes(error?.statusCode)) {
        console.error('The discovery agent was rejected by Holly Bibley (invalid or revoked token). Stopping; pair the agent again if access is still intended.');
        process.exitCode = 1;
        break;
      }
      failures += 1;
      const delay = Math.min(30000, 1000 * (2 ** Math.min(failures, 5)));
      console.error(`Agent connection warning: ${String(error.message || error).slice(0, 180)}. Retrying in ${Math.ceil(delay / 1000)}s.`);
      if (options.once) { process.exitCode = 1; break; }
      await sleep(delay);
    }
  } while (!options.once);
}

if (process.argv[1] && path.resolve(process.argv[1]) === SCRIPT_PATH) {
  main().catch((error) => {
    console.error(`Unexpected agent error: ${String(error?.message || error).replace(/[\r\n\t]+/g, ' ').slice(0, 250)}`);
    process.exitCode = 1;
  });
}
