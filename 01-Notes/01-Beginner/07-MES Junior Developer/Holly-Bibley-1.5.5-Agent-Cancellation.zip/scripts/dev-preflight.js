import dotenv from 'dotenv';
import os from 'node:os';
import { copyFileSync, existsSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import pg from 'pg';
import { diagnosePostgresError } from '../server/database-diagnostics.js';

const { Pool } = pg;
const root = process.cwd();
const envPath = `${root}/.env`;
const envExamplePath = `${root}/.env.example`;

function logError(message) {
  console.error(`\n[Holly Bibley setup] ${message}\n`);
}

function isPrivateIPv4(address) {
  const octets = address.split('.').map(Number);
  if (octets.length !== 4 || octets.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) return false;
  const [a, b] = octets;
  return a === 10 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168);
}

function findLanIPv4() {
  const configured = (process.env.HB_LAN_HOST || '').trim();
  if (configured) {
    if (!isPrivateIPv4(configured)) throw new Error('HB_LAN_HOST must be a private IPv4 address, such as 192.168.1.50.');
    return configured;
  }
  for (const entries of Object.values(os.networkInterfaces())) {
    for (const entry of entries || []) {
      if (entry.family === 'IPv4' && !entry.internal && isPrivateIPv4(entry.address)) return entry.address;
    }
  }
  return null;
}

function configureLanAccess() {
  if (process.env.HB_LAN_MODE !== '1') {
    console.log('[Holly Bibley setup] LAN sharing is disabled. The frontend is still bound to all interfaces; use HB_LAN_MODE=1 to enable LAN-aware origin and verification links.');
    return;
  }
  const address = findLanIPv4();
  if (!address) {
    console.warn('[Holly Bibley setup] No private LAN IPv4 address was detected. Use HB_LAN_HOST in .env if automatic detection selected no usable address.');
    return;
  }
  const origin = `http://${address}:5173`;
  process.env.APP_ORIGIN = origin;
  process.env.PUBLIC_APP_URL = origin;
  console.log(`[Holly Bibley setup] Local-network access enabled: ${origin}`);
  console.log('[Holly Bibley setup] Share this URL with trusted users on the same LAN. Allow inbound TCP 5173 on the Windows Private firewall profile only.');
}


async function verifyApiDependencies() {
  // Vite can serve the frontend even when a native backend dependency is broken.
  // Catch those failures before starting the web server, otherwise the user only sees
  // a misleading proxy ECONNREFUSED message on signup.
  const required = ['express', 'helmet', 'express-rate-limit', 'argon2', 'nodemailer', 'zod'];
  for (const name of required) {
    try {
      await import(name);
    } catch (error) {
      logError(`Backend dependency \"${name}\" could not load (${error.message}). Run npm install again. If argon2 is the failing package, try npm rebuild argon2, then rerun npm run dev.`);
      return false;
    }
  }
  return true;
}

function probeConnectionString() {
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 1,
    connectionTimeoutMillis: 2500,
    idleTimeoutMillis: 500,
    ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: true } : undefined,
  });
  return pool.query('SELECT 1').finally(() => pool.end());
}

function tryDockerCompose() {
  console.log('\n[Holly Bibley setup] PostgreSQL is not reachable. Trying to start the bundled local database with Docker Compose...');
  const result = spawnSync('docker', ['compose', 'up', '-d', '--wait', 'db'], {
    cwd: root,
    stdio: 'inherit',
    windowsHide: true,
    timeout: 90_000,
  });
  if (result.error) {
    logError(`Could not run Docker Compose: ${result.error.message}. Start PostgreSQL yourself, or start Docker Desktop and retry. For an external PostgreSQL instance, set HB_SKIP_DOCKER_DB=1 and make sure DATABASE_URL is reachable.`);
    return false;
  }
  if (result.status !== 0) {
    logError('Docker Compose could not start the database. Check that Docker Desktop is running, port 5432 is available, and POSTGRES_PASSWORD is set in .env. Your existing database volume has not been deleted.');
    return false;
  }
  return true;
}

function syncLocalDatabasePassword() {
  console.log('[Holly Bibley setup] PostgreSQL rejected DATABASE_URL credentials. Aligning the local Compose role password with .env without deleting data...');
  const result = spawnSync(process.execPath, ['scripts/db-sync-local-password.js'], {
    cwd: root,
    stdio: 'inherit',
    windowsHide: true,
    timeout: 40_000,
    env: process.env,
  });

  if (result.error) {
    logError(`Could not run the local password synchronizer: ${result.error.message}. You can run npm run db:sync-local-password manually.`);
    return false;
  }
  if (result.status !== 0) {
    logError('The local database password could not be aligned. No data was deleted. Check POSTGRES_USER, POSTGRES_DB, and POSTGRES_PASSWORD in .env, then run npm run db:doctor.');
    return false;
  }
  return true;
}

async function recoverLocalAuthentication(error) {
  const diagnostic = diagnosePostgresError(error);
  if (diagnostic?.code !== 'DATABASE_AUTH_FAILED' || process.env.HB_SKIP_DOCKER_DB === '1') {
    return { ok: false, error };
  }

  if (!tryDockerCompose()) return { ok: false, error };
  if (!syncLocalDatabasePassword()) return { ok: false, error };

  try {
    await probeConnectionString();
    console.log('[Holly Bibley setup] PostgreSQL credentials now match .env.');
    return { ok: true };
  } catch (retryError) {
    return { ok: false, error: retryError };
  }
}

async function connectOrRecover(shouldStartDocker) {
  try {
    await probeConnectionString();
    console.log('[Holly Bibley setup] PostgreSQL connection is available.');
    return { ok: true };
  } catch (error) {
    const diagnostic = diagnosePostgresError(error);

    if (diagnostic?.code === 'DATABASE_AUTH_FAILED') {
      if (!shouldStartDocker) return { ok: false, error };
      return recoverLocalAuthentication(error);
    }

    if (diagnostic?.code === 'DATABASE_NOT_FOUND') return { ok: false, error };

    if (!shouldStartDocker) return { ok: false, error };
    if (!tryDockerCompose()) return { ok: false, error };

    const result = await waitForDatabase();
    if (result.ok) return result;
    return recoverLocalAuthentication(result.error);
  }
}

async function waitForDatabase(timeoutMs = 60_000) {
  const started = Date.now();
  let lastError;
  while (Date.now() - started < timeoutMs) {
    try {
      await probeConnectionString();
      return { ok: true };
    } catch (error) {
      lastError = error;
      const diagnostic = diagnosePostgresError(error);
      // Authentication, missing database, and schema/config errors will not heal by waiting.
      if (diagnostic?.code === 'DATABASE_AUTH_FAILED' || diagnostic?.code === 'DATABASE_NOT_FOUND') {
        return { ok: false, error };
      }
      await new Promise((resolve) => setTimeout(resolve, 1500));
    }
  }
  return { ok: false, error: lastError };
}

async function main() {
  if (!existsSync(envPath)) {
    if (!existsSync(envExamplePath)) {
      logError('.env is missing and .env.example was not found. Restore the project configuration file before continuing.');
      process.exitCode = 1;
      return;
    }
    copyFileSync(envExamplePath, envPath);
    console.log('[Holly Bibley setup] Created .env from .env.example using local development settings. Change the example password before exposing anything beyond your computer.');
  }

  dotenv.config({ path: envPath, override: false, quiet: true });
  try {
    configureLanAccess();
  } catch (error) {
    logError(error.message);
    process.exitCode = 1;
    return;
  }
  if (!process.env.DATABASE_URL) {
    logError('DATABASE_URL is missing in .env. Set it to a valid PostgreSQL connection URL.');
    process.exitCode = 1;
    return;
  }

  if (!(await verifyApiDependencies())) {
    process.exitCode = 1;
    return;
  }

  const shouldStartDocker = process.env.HB_SKIP_DOCKER_DB !== '1';
  const connectionResult = await connectOrRecover(shouldStartDocker);

  if (!connectionResult.ok) {
    const diagnostic = diagnosePostgresError(connectionResult.error);
    logError(`${diagnostic?.message || connectionResult.error?.message || 'Could not connect to PostgreSQL.'}\n${diagnostic?.action || 'Check .env and the PostgreSQL server logs.'}\nNo database volume was deleted by this setup script.`);
    process.exitCode = 1;
    return;
  }

  console.log('[Holly Bibley setup] Applying safe, additive schema migrations...');
  const migration = spawnSync(process.execPath, ['server/migrate.js'], { cwd: root, stdio: 'inherit', windowsHide: true, env: process.env });
  if (migration.error || migration.status !== 0) {
    logError('Database migration did not complete. Review the migration output above. The web and API servers were not started.');
    process.exitCode = 1;
    return;
  }

  console.log('[Holly Bibley setup] Starting API and web development servers...');
  const isWindows = process.platform === 'win32';
  // npm.cmd is a shell script on Windows; launch it through cmd.exe instead of spawning it directly.
  const command = isWindows ? (process.env.ComSpec || 'cmd.exe') : 'npm';
  const args = isWindows ? ['/d', '/s', '/c', 'npm run dev:services'] : ['run', 'dev:services'];
  const child = spawn(command, args, { cwd: root, stdio: 'inherit', windowsHide: true, env: process.env });
  child.on('error', (error) => {
    logError(`Could not start the development servers: ${error.message}`);
    process.exitCode = 1;
  });
  child.on('exit', (code, signal) => {
    if (signal) process.kill(process.pid, signal);
    else process.exitCode = code ?? 1;
  });
  const forwardSignal = (signal) => { if (!child.killed) child.kill(signal); };
  process.once('SIGINT', () => forwardSignal('SIGINT'));
  process.once('SIGTERM', () => forwardSignal('SIGTERM'));
}

main().catch((error) => {
  logError(`Unexpected setup failure: ${error.message}`);
  process.exitCode = 1;
});
