#!/usr/bin/env node
import 'dotenv/config';
import { access, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  DEFAULT_SNMP_TIMEOUT_MS,
  runSnmpSwitchDiscovery,
  validateSnmpTargets,
} from './lib/snmp-switch-discovery.js';

const SCRIPT_PATH = fileURLToPath(import.meta.url);

function printHelp() {
  console.log(`Holly Bibley SNMPv3 switch discovery (read-only)

Usage:
  npm run discover:switches -- --targets 192.168.10.2,192.168.10.3 [--out switches.json]
  node scripts/discover-switches.js --targets 192.168.10.2 [--timeout 1500] [--out switches.json]

Required environment configuration (never pass secrets as command-line arguments):
  HB_SNMPV3_USERNAME            Dedicated SNMPv3 read-only user
  HB_SNMPV3_AUTH_PASSPHRASE     Authentication passphrase (8+ characters)
  HB_SNMPV3_PRIV_PASSPHRASE     Privacy/encryption passphrase (8+ characters)

Optional environment configuration:
  HB_SNMPV3_AUTH_PROTOCOL       sha256 by default; sha, sha224, sha384 or sha512 are supported
  HB_SNMPV3_PRIV_PROTOCOL       aes by default (AES-128); aes256b or aes256r are also supported
  HB_SNMP_TIMEOUT_MS            Default ${DEFAULT_SNMP_TIMEOUT_MS} milliseconds; allowed range 500–10000

Options:
  --targets IP[,IP...]  Explicit RFC 1918 private IPv4 management addresses only (max 64)
  --out FILE            Output discovery snapshot JSON (default: timestamped file in current directory)
  --timeout MS          Per-request timeout from 500 to 10000 ms
  --force               Permit overwriting the output file
  --help                Show this help

Safety and accuracy:
  - Uses SNMPv3 authPriv (authentication + encryption); no SNMPv1/v2c fallback.
  - Uses read-only Get, Table and Subtree requests only; it never issues SNMP Set operations.
  - Targets must be explicitly supplied as RFC 1918 private IPv4 addresses; no subnet sweep is performed.
  - No write credentials or SNMP passphrases are included in the exported snapshot.
  - Switch ports and VLAN membership are collected from standard MIBs where the device exposes them.
  - Access/trunk mode is inferred from VLAN membership; LLDP is used for advertised neighbour links.
  - Always verify results. Run only against authorised equipment and follow OT site change/safety procedures.`);
}

function parseArgs(argv) {
  const options = { targets: '', out: '', timeout: '', force: false, help: false };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--force') options.force = true;
    else if (arg === '--help' || arg === '-h') options.help = true;
    else if (['--targets', '--out', '--timeout'].includes(arg)) {
      const value = argv[i + 1];
      if (!value || value.startsWith('--')) throw new Error(`${arg} requires a value.`);
      i += 1;
      if (arg === '--targets') options.targets = value;
      else if (arg === '--out') options.out = value;
      else options.timeout = value;
    } else {
      throw new Error(`Unknown argument: ${arg}. Use --help to see supported options.`);
    }
  }
  return options;
}

function defaultOutputPath() {
  const date = new Date();
  const stamp = [date.getFullYear(), String(date.getMonth() + 1).padStart(2, '0'), String(date.getDate()).padStart(2, '0'), '-', String(date.getHours()).padStart(2, '0'), String(date.getMinutes()).padStart(2, '0'), String(date.getSeconds()).padStart(2, '0')].join('');
  return path.resolve(process.cwd(), `holly-bibley-switch-discovery-${stamp}.json`);
}

async function outputExists(file) {
  try { await access(file); return true; }
  catch { return false; }
}

async function main() {
  let options;
  try { options = parseArgs(process.argv.slice(2)); }
  catch (error) {
    console.error(`Argument error: ${error.message}\nRun with --help for usage.`);
    process.exitCode = 2;
    return;
  }
  if (options.help) return printHelp();

  let targets;
  try { targets = validateSnmpTargets(options.targets); }
  catch (error) {
    console.error(`Target error: ${error.message}\nRun with --help for usage.`);
    process.exitCode = 2;
    return;
  }

  const timeoutText = options.timeout || process.env.HB_SNMP_TIMEOUT_MS || String(DEFAULT_SNMP_TIMEOUT_MS);
  const timeoutMs = Number(timeoutText);
  if (!Number.isInteger(timeoutMs) || timeoutMs < 500 || timeoutMs > 10000) {
    console.error('Timeout must be an integer from 500 to 10000 milliseconds.');
    process.exitCode = 2;
    return;
  }
  const credentials = {
    username: process.env.HB_SNMPV3_USERNAME,
    authPassphrase: process.env.HB_SNMPV3_AUTH_PASSPHRASE,
    privPassphrase: process.env.HB_SNMPV3_PRIV_PASSPHRASE,
    authProtocol: process.env.HB_SNMPV3_AUTH_PROTOCOL || 'sha256',
    privProtocol: process.env.HB_SNMPV3_PRIV_PROTOCOL || 'aes',
  };

  console.log('Holly Bibley SNMPv3 switch discovery');
  console.log(`Targets: ${targets.length} explicit private IPv4 address(es)`);
  console.log(`Security: SNMPv3 authPriv · UDP/161 · timeout ${timeoutMs} ms · read-only operations`);
  console.log('Credentials are not printed or added to the output file.\n');

  let result;
  try {
    result = await runSnmpSwitchDiscovery({
      targets,
      credentials,
      timeoutMs,
      onProgress: ({ completed, total, target, ok, hostname, reason }) => {
        if (ok) console.log(`  [${completed}/${total}] ${target}: responding (${hostname})`);
        else console.warn(`  [${completed}/${total}] ${target}: ${reason}`);
      },
    });
  } catch (error) {
    console.error(`Discovery stopped: ${error.message}`);
    process.exitCode = 1;
    return;
  }

  const output = path.resolve(process.cwd(), options.out || defaultOutputPath());
  if (!options.force && await outputExists(output)) {
    console.error(`Output file already exists: ${output}\nChoose another --out path or add --force to overwrite it.`);
    process.exitCode = 1;
    return;
  }
  try {
    await writeFile(output, `${JSON.stringify(result.snapshot, null, 2)}\n`, { encoding: 'utf8', flag: options.force ? 'w' : 'wx', mode: 0o600 });
  } catch (error) {
    console.error(`Could not write discovery snapshot: ${error.code === 'EEXIST' ? 'the output file already exists' : 'file write failed'}.`);
    process.exitCode = 1;
    return;
  }

  console.log('\nDiscovery complete.');
  console.log(`  Targets supplied: ${result.summary.targets}`);
  console.log(`  Switches polled:  ${result.summary.responding}`);
  console.log(`  Failed targets:   ${result.summary.failed}`);
  console.log(`  VLANs discovered: ${result.summary.vlans}`);
  console.log(`  LLDP links seen:  ${result.summary.links}`);
  console.log(`  Snapshot:         ${output}`);
  console.log('\nNext: open Holly Bibley → Discover network → Import snapshot JSON, review confidence/warnings, then save the topology.');
  if (result.summary.failed || result.summary.warnings) console.log('This is a partial discovery where warnings are present; review the exported warning list before trusting the map.');
}

if (process.argv[1] && path.resolve(process.argv[1]) === SCRIPT_PATH) {
  main().catch((error) => {
    console.error(`Unexpected error: ${String(error?.message || 'discovery failed').replace(/[\r\n\t]+/g, ' ').slice(0, 180)}`);
    process.exitCode = 1;
  });
}
