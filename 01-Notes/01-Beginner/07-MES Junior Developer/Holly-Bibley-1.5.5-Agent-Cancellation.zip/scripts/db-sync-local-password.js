import dotenv from 'dotenv';
import { spawnSync } from 'node:child_process';

dotenv.config({ quiet: true });

function fail(message) {
  console.error(`\n[Holly Bibley database] ${message}\n`);
  process.exit(1);
}

if (!process.env.DATABASE_URL || !process.env.POSTGRES_PASSWORD) {
  fail('DATABASE_URL and POSTGRES_PASSWORD are required in .env. This command is only for the bundled local Docker database.');
}

let connection;
try {
  connection = new URL(process.env.DATABASE_URL);
} catch {
  fail('DATABASE_URL is not a valid URL. Correct it before trying to sync the local database password.');
}

const host = connection.hostname.replace(/^\[|\]$/g, '').toLowerCase();
const port = Number(connection.port || 5432);
const localHosts = new Set(['127.0.0.1', 'localhost', '::1']);
if (!localHosts.has(host) || port !== 5432 || process.env.HB_SKIP_DOCKER_DB === '1') {
  fail('Refusing to alter a non-local or externally managed database. DATABASE_URL must target localhost:5432 and HB_SKIP_DOCKER_DB must not be 1.');
}

const urlRole = decodeURIComponent(connection.username);
const urlPassword = decodeURIComponent(connection.password);
const urlDatabase = decodeURIComponent(connection.pathname.replace(/^\//, ''));
const role = process.env.POSTGRES_USER || urlRole;
const database = process.env.POSTGRES_DB || urlDatabase;
if (!role || !database) fail('Could not determine the local PostgreSQL role/database from .env.');
if (urlRole !== role) fail('DATABASE_URL username must match POSTGRES_USER before syncing the local database password.');
if (urlDatabase !== database) fail('DATABASE_URL database name must match POSTGRES_DB before syncing the local database password.');
if (urlPassword !== process.env.POSTGRES_PASSWORD) fail('DATABASE_URL password must match POSTGRES_PASSWORD before syncing. Update both values in .env to 123password.');

const quoteIdentifier = (value) => `"${String(value).replaceAll('"', '""')}"`;
const quoteLiteral = (value) => `'${String(value).replaceAll("'", "''")}'`;
const sql = `ALTER ROLE ${quoteIdentifier(role)} WITH PASSWORD ${quoteLiteral(process.env.POSTGRES_PASSWORD)};\n`;

console.log(`Updating the local Docker PostgreSQL role ${role} to match POSTGRES_PASSWORD in .env.`);
console.log('This changes a role password only; it does not delete users, diagrams, or the Docker volume.');
const result = spawnSync('docker', [
  'compose', 'exec', '-T', 'db', 'psql',
  '-U', role,
  '-d', database,
  '-v', 'ON_ERROR_STOP=1',
], {
  input: sql,
  encoding: 'utf8',
  stdio: ['pipe', 'inherit', 'inherit'],
  windowsHide: true,
  timeout: 30_000,
});

if (result.error) fail(`Could not execute Docker Compose: ${result.error.message}. Make sure Docker Desktop is running and the local db container is up.`);
if (result.status !== 0) fail('Password sync failed. Confirm POSTGRES_USER and POSTGRES_DB match the existing local database role and database; the database contents were not deleted.');
console.log('Local PostgreSQL role password updated. Run npm run db:doctor, then npm run dev.');
