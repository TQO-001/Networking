#!/usr/bin/env node
import { execFile as execFileCallback } from 'node:child_process';
import { promisify } from 'node:util';
import os from 'node:os';
import { writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  listLocalIPv4Interfaces,
  parseNeighbourOutput,
  runLocalDiscovery,
} from './lib/local-network-discovery.js';

const execFile = promisify(execFileCallback);
const SCRIPT_PATH = fileURLToPath(import.meta.url);

function help() {
  console.log(`Holly Bibley Local Network Discovery (IPv4)

Usage:
  node scripts/discover-network.js --list
  node scripts/discover-network.js --cidr 192.168.10.0/24 [--interface "Ethernet"] [--out snapshot.json] [--force]

Options:
  --list                 Show directly attached IPv4 interfaces and candidate subnets.
  --cidr CIDR            Required target subnet. Must be a private IPv4 subnet
                         directly contained in a local interface's assigned network.
  --interface NAME       Select an interface if more than one matches the subnet.
  --out FILE             Write the snapshot to a JSON file (default: timestamped file in current directory).
  --force                Permit overwriting the --out file if it already exists.
  --help                 Show this message.

Safety limits:
  - Only RFC 1918 private IPv4 ranges are allowed.
  - Maximum 256 addresses per run (normally a /24 with 254 host addresses).
  - One ICMP echo request per target, with a rate limit and bounded concurrency.
  - No TCP/UDP port scanning, exploit checks, or device configuration writes.
  - Switch ports, VLAN IDs and physical links are not inferred.

Run only on networks you are authorised to inspect. Active discovery in production OT
networks must follow the site's approved change and safety procedures.`);
}

function parseArgs(argv) {
  const options = { cidr: '', interfaceName: '', out: '', list: false, force: false, help: false };
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === '--list') options.list = true;
    else if (arg === '--force') options.force = true;
    else if (arg === '--help' || arg === '-h') options.help = true;
    else if (['--cidr', '--interface', '--out'].includes(arg)) {
      const value = argv[index + 1];
      if (!value || value.startsWith('--')) throw new Error(`${arg} requires a value.`);
      index += 1;
      if (arg === '--cidr') options.cidr = value;
      else if (arg === '--interface') options.interfaceName = value;
      else options.out = value;
    } else {
      throw new Error(`Unknown argument: ${arg}. Use --help to see supported options.`);
    }
  }
  return options;
}

function printInterfaces() {
  const interfaces = listLocalIPv4Interfaces();
  if (!interfaces.length) {
    console.log('No usable local IPv4 interfaces were found. Connect to a private IPv4 network and try again.');
    return;
  }
  console.log('Detected IPv4 interfaces:');
  for (const entry of interfaces) {
    const safety = entry.private ? 'private IPv4' : 'not RFC 1918 private (will not be scanned)';
    console.log(`  ${entry.name}: ${entry.address}/${entry.prefix}  network=${entry.cidr}  ${safety}`);
  }
  console.log('\nChoose a private subnet contained within one of the listed interface networks.');
}

function platformPingArguments(platform, ip) {
  if (platform === 'win32') return ['-n', '1', '-w', '800', ip];
  if (platform === 'darwin') return ['-n', '-c', '1', '-W', '1000', ip];
  return ['-n', '-c', '1', '-W', '1', ip];
}

export async function pingAddress(ip, { signal } = {}) {
  if (signal?.aborted) throw signal.reason instanceof Error ? signal.reason : Object.assign(new Error('Discovery was cancelled.'), { name: 'AbortError' });
  try {
    await execFile('ping', platformPingArguments(process.platform, ip), { timeout: 1800, windowsHide: true, maxBuffer: 64 * 1024, signal });
    return true;
  } catch (error) {
    if (signal?.aborted) throw signal.reason instanceof Error ? signal.reason : Object.assign(new Error('Discovery was cancelled.'), { name: 'AbortError' });
    if (error?.code === 'ENOENT') throw new Error('The system "ping" utility could not be found. Install/enable it or ensure it is available on PATH.');
    if (error?.killed && error?.signal === 'SIGTERM') return false;
    return false;
  }
}

async function readCommand(command, args, signal) {
  if (signal?.aborted) throw signal.reason instanceof Error ? signal.reason : Object.assign(new Error('Discovery was cancelled.'), { name: 'AbortError' });
  try {
    const result = await execFile(command, args, { timeout: 2500, windowsHide: true, maxBuffer: 1024 * 1024, signal });
    return result.stdout || '';
  } catch (error) {
    if (signal?.aborted) throw signal.reason instanceof Error ? signal.reason : Object.assign(new Error('Discovery was cancelled.'), { name: 'AbortError' });
    if (error?.code === 'ENOENT') return '';
    return error?.stdout || '';
  }
}

export async function readNeighbourTable({ signal } = {}) {
  const platform = process.platform;
  const commands = platform === 'win32'
    ? [['arp', ['-a']]]
    : platform === 'linux'
      ? [['ip', ['neigh', 'show']], ['arp', ['-an']]]
      : [['arp', ['-an']], ['arp', ['-a']]];
  for (const [command, args] of commands) {
    const output = await readCommand(command, args, signal);
    const neighbours = parseNeighbourOutput(output, platform);
    if (signal?.aborted) throw signal.reason instanceof Error ? signal.reason : Object.assign(new Error('Discovery was cancelled.'), { name: 'AbortError' });
    if (neighbours.size || output.trim()) return { neighbours };
  }
  return { neighbours: new Map(), warning: 'No readable OS neighbour/ARP table was available. Device MAC addresses may be missing.' };
}

function defaultOutputPath() {
  const date = new Date();
  const stamp = [date.getFullYear(), String(date.getMonth() + 1).padStart(2, '0'), String(date.getDate()).padStart(2, '0'), '-', String(date.getHours()).padStart(2, '0'), String(date.getMinutes()).padStart(2, '0'), String(date.getSeconds()).padStart(2, '0')].join('');
  return path.resolve(process.cwd(), `holly-bibley-discovery-${stamp}.json`);
}

async function main() {
  let options;
  try {
    options = parseArgs(process.argv.slice(2));
  } catch (error) {
    console.error(`Error: ${error.message}\nRun with --help for usage.`);
    process.exitCode = 2;
    return;
  }
  if (options.help) return help();
  if (options.list) return printInterfaces();
  if (!options.cidr) {
    console.error('Error: --cidr is required. Start with --list to inspect local interfaces.');
    process.exitCode = 2;
    return;
  }

  console.log('Holly Bibley Local Network Discovery');
  console.log('This sends one ICMP echo request per usable address in the selected subnet.');
  console.log('Run only with authorisation and follow site OT/production safety procedures.\n');

  let result;
  try {
    result = await runLocalDiscovery({
      cidr: options.cidr,
      requestedInterface: options.interfaceName,
      pingAddress,
      readNeighbourTable,
      hostname: os.hostname(),
      onProgress: ({ completed, total }) => {
        if (completed === total || completed % 25 === 0) console.log(`  Probed ${completed}/${total} targets…`);
      },
    });
  } catch (error) {
    console.error(`Discovery stopped: ${error.message}`);
    process.exitCode = 1;
    return;
  }

  const outPath = options.out ? path.resolve(process.cwd(), options.out) : defaultOutputPath();
  try {
    await writeFile(outPath, `${JSON.stringify(result.snapshot, null, 2)}\n`, { encoding: 'utf8', flag: options.force ? 'w' : 'wx' });
  } catch (error) {
    if (error?.code === 'EEXIST') {
      console.error(`The output file already exists: ${outPath}\nChoose another --out path or add --force to overwrite it.`);
    } else {
      console.error(`Could not write discovery snapshot: ${error.message}`);
    }
    process.exitCode = 1;
    return;
  }

  console.log('\nDiscovery complete.');
  console.log(`  Scope:            ${result.summary.scope}`);
  console.log(`  Interface:        ${result.summary.interface}`);
  console.log(`  Target addresses: ${result.summary.totalTargets}`);
  console.log(`  ICMP replies:     ${result.summary.icmpResponded}`);
  console.log(`  Devices recorded: ${result.summary.devicesFound}`);
  console.log(`  MAC addresses:    ${result.summary.macAddressesFound}`);
  console.log(`  Snapshot:         ${outPath}`);
  console.log('\nNext: open Holly Bibley → Discover network → Import snapshot JSON, then review the warnings.');
  console.log('This scan does not discover switch ports, VLAN IDs, firewall rules or physical links.');
}

if (process.argv[1] && path.resolve(process.argv[1]) === SCRIPT_PATH) {
  main().catch((error) => {
    console.error(`Unexpected discovery error: ${error.message}`);
    process.exitCode = 1;
  });
}
