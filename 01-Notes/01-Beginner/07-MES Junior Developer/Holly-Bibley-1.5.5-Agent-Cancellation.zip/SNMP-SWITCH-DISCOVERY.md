# Holly Bibley — SNMPv3 Switch Discovery

This guide describes the **local command-line collector** added in Holly Bibley 1.4.0. It polls only explicitly supplied management IP addresses and writes a discovery snapshot JSON file that can be reviewed and imported in the existing topology editor.

> **Operational safety:** only query equipment you are authorised to manage. For production and OT networks, follow site change-control procedures and test the configuration on a lab switch first. Even read-only inventory exposes sensitive network details. Use a dedicated least-privilege SNMPv3 account, restrict source IPs with an ACL, and keep passphrases out of source control, chat logs, command history and exported snapshots.

## What the collector discovers

Where a target device exposes the required MIB data and the account has permission, it attempts to collect:

- system name, description and object identifier;
- interface names/descriptions, operational status, speed and MAC addresses;
- IP addresses and subnet masks associated with interfaces;
- VLAN names and VLAN membership bitmaps using Q-BRIDGE-MIB and BRIDGE-MIB mapping;
- LLDP local/remote port identifiers, neighbour names and advertised chassis identifiers;
- physical-link candidates from LLDP observations.

The collector does **not** write configuration. It uses SNMPv3 `authPriv` (authentication and privacy/encryption) and performs read-only Get/Table/Subtree requests. It never uses SNMP Set and does not fall back to SNMPv1/v2c.

## Important limitations

- The targets are explicit IPv4 management addresses, not a subnet sweep. Maximum: 64 targets per run.
- The target must be an RFC 1918 private IPv4 address. Public addresses, hostnames and URLs are rejected.
- VLAN information and LLDP neighbours are optional on the device and may be hidden by its read view. Some vendors expose parts of this information only through vendor-specific MIBs or authenticated management APIs.
- An access/trunk mode is inferred conservatively from VLAN membership bitmaps; it is **not** proof of the running configuration. Native VLAN, voice VLAN, port-channel, STP, routed, private-VLAN and vendor-specific details can require additional sources.
- A VLAN membership table does not alone prove that a link is carrying traffic or that two interfaces form one cable. LLDP advertises adjacency; check confidence and warnings in the snapshot.
- This version requires manual JSON import. It does not push results directly from a local agent into the browser, enumerate arbitrary subnets, scan IPv6, or query Cisco CDP when LLDP is unavailable.

## 1. Install dependencies

Use the Node.js version specified by `package.json` (Node.js 22.12 or newer).

```powershell
npm install
```

If dependencies are already installed, you can skip this step.

## 2. Configure SNMPv3 credentials locally

Set these in the local `.env` file used by Holly Bibley, or in the environment of the terminal running the command:

```dotenv
HB_SNMPV3_USERNAME=holly-bibley-readonly
HB_SNMPV3_AUTH_PASSPHRASE=
HB_SNMPV3_PRIV_PASSPHRASE=
HB_SNMPV3_AUTH_PROTOCOL=sha256
HB_SNMPV3_PRIV_PROTOCOL=aes
HB_SNMP_TIMEOUT_MS=1500
```

Put actual passphrases only in your protected local environment. Do not commit them, copy them into tickets, or distribute a ZIP containing production credentials. Keep the example values blank in project templates.

The target device must have a matching SNMPv3 user configured with authentication and privacy. Defaults are SHA-256 and AES-128 where both the device and installed library support them. The collector also recognises SHA/SHA-224/SHA-384/SHA-512 and AES256B/AES256R when supported by the installed library and device. MD5 and DES are deliberately rejected. Do not weaken production device security just to make a scan work; use the strongest interoperable setting approved by your network-security policy.

Create a **read-only** view granting access only to the required standard system, IF-MIB, IP-MIB, BRIDGE-MIB, Q-BRIDGE-MIB and LLDP-MIB objects where supported. Restrict the SNMP service with an ACL to the IP address of the computer running Holly Bibley. Exact configuration syntax differs by vendor and software version; use the vendor's official documentation and have a network administrator verify the resulting access policy.

## 3. List local interfaces

This is the existing host-discovery tool and does not perform switch SNMP polling:

```powershell
node scripts/discover-network.js --list
```

## 4. Poll selected switches

Pass **actual, explicitly authorised private management IP addresses**. This command does not search a subnet:

```powershell
npm run discover:switches -- --targets 192.168.10.2,192.168.10.3 --out switches.json
```

The IPs above are examples only. Replace them with real switch-management addresses approved for your test. Use a different output path if the file already exists. By default, the collector refuses to overwrite an existing snapshot; `--force` explicitly permits replacement.

A single switch is also supported:

```powershell
npm run discover:switches -- --targets 192.168.10.2 --out switch.json
```

To see arguments and limits:

```powershell
npm run discover:switches -- --help
```

The per-request timeout defaults to 1500 ms; use `--timeout 3000` if the management network is slow. Allowed range is 500–10000 ms. A switch that fails is recorded as a warning; successful switches can still produce a partial snapshot. Do not treat a partial map as complete.

## 5. Import the snapshot

1. Open Holly Bibley and enter the topology editor.
2. Choose **Discover network**.
3. Choose **Import snapshot JSON** and select `switches.json`.
4. Inspect the discovered devices, VLANs, ports, LLDP link candidates and warnings.
5. Save as a new diagram first. Compare the result against a known-good diagram and the switch's read-only configuration before using it as operational documentation.

The snapshot contains inventory data, not authentication material. It can still disclose hostnames, IPs, MAC addresses, topology and VLAN structure, so store and share it as sensitive infrastructure data.

## Troubleshooting

| Symptom | What to check |
|---|---|
| SNMPv3 user or security error | Verify username, auth/privacy passphrases, algorithms and device SNMPv3 user configuration. Never paste secrets into logs. |
| Timeout | Check management reachability, UDP/161 ACLs, route/VPN, target IP and device control-plane policy. Use a reasonable timeout for your network. |
| Interface table unavailable | Confirm the configured read-only SNMP view permits IF-MIB reads. |
| VLAN membership unavailable | Confirm the switch supports and exposes Q-BRIDGE-MIB and BRIDGE-MIB objects to this user. Some platforms need vendor-specific access. |
| LLDP neighbour list is empty | Confirm LLDP is enabled on the relevant interfaces and the device exposes LLDP-MIB to the read-only user. CDP is not collected by this version. |
| Device appears but no access/trunk mode is shown | Membership may be incomplete or ambiguous. Check the device configuration and treat the reported mode as inferred. |
| Import shows a warning | Read the warning list; partial or inferred fields are not confirmations. |

## Implementation notes

- CLI: `scripts/discover-switches.js`
- Collector and snapshot builder: `scripts/lib/snmp-switch-discovery.js`
- Automated tests: `tests/snmp-switch-discovery.test.js`
- Snapshot schema: `holly-bibley-discovery-snapshot`, version 1
- NPM command: `npm run discover:switches`

Protocol references: [RFC 3414 — SNMPv3 User-based Security Model](https://www.rfc-editor.org/rfc/rfc3414.html) and [RFC 4363 — Q-BRIDGE-MIB VLAN objects](https://www.rfc-editor.org/rfc/rfc4363.html). Library API: [node-net-snmp project](https://github.com/markabrahams/node-net-snmp).
