# Holly Bibley — Database recovery

This note covers the local development error:

```text
[vite] http proxy error: /api/auth/signup
Error: connect ECONNREFUSED 127.0.0.1:3001
```

Port `3001` is the Holly Bibley API. This proxy error means the API process was not listening. In the earlier project, the API did not begin listening until PostgreSQL successfully answered `SELECT 1`, so a database problem could make the browser show a misleading API connection error.

## First try: updated startup workflow

1. Extract the updated application ZIP.
2. Open PowerShell in the `holly-bibley-platform` project folder.
3. Install dependencies once:

   ```powershell
   npm install
   ```

4. Make sure Docker Desktop is running.
5. Run:

   ```powershell
   npm run dev
   ```

The supplied project includes `.env` with the requested local password. The command creates `.env` from `.env.example` if missing, checks PostgreSQL, starts the included Compose database when needed, attempts a safe local role-password sync if authentication fails, verifies the connection, applies additive migrations, then starts the API and Vite. It never deletes the data volume.

## Check database health

In another PowerShell window, from the project folder, run:

```powershell
npm run db:doctor
```

The command checks whether the configured PostgreSQL server is reachable, identifies the selected database and role without printing the password, and confirms the five required application tables exist.

You can also open this URL when the dev servers are running:

```text
http://127.0.0.1:5173/api/health
```

Expected success response:

```json
{"status":"ok","database":"ok"}
```

If PostgreSQL is down, the endpoint should now return HTTP 503 with a safe diagnostic rather than Vite reporting a connection refusal to port 3001.

## Common diagnoses

### PostgreSQL is not reachable

```powershell
docker compose up -d --wait db
npm run db:migrate
npm run db:doctor
```

Then restart `npm run dev`.

### Username or password rejected

Check these values in `.env`:

- `DATABASE_URL`
- `POSTGRES_USER`
- `POSTGRES_PASSWORD`
- `POSTGRES_DB`

The database username, password, and database name in `DATABASE_URL` must match the local PostgreSQL service. If the PostgreSQL data volume was initialized previously, changing `POSTGRES_PASSWORD` in `.env` does **not** change the password already stored for the database role. `npm run dev` now attempts to synchronize the role password using the container's local socket; you can run `npm run db:sync-local-password` manually if needed. Do not solve this by deleting the volume. `docker compose down -v` destroys local account and diagram data.

### Database exists but required tables are missing

```powershell
npm run db:migrate
npm run db:doctor
```

The migration uses `CREATE ... IF NOT EXISTS` and additive `ALTER TABLE` statements; it is designed to preserve existing rows.

## If you use an external PostgreSQL server

Make sure `DATABASE_URL` points to that server, then set this environment variable before running the dev command to prevent automatic attempts to start the bundled Docker database:

```powershell
$env:HB_SKIP_DOCKER_DB = '1'
npm run dev
```

You can verify the setting using `npm run db:doctor` first.

## What changed in code

- `scripts/dev-preflight.js` checks the database, starts the bundled database when appropriate, runs migrations and launches dev services.
- `scripts/db-doctor.js` diagnoses connectivity, credentials and missing schema tables.
- `server/database-diagnostics.js` maps common PostgreSQL error codes to non-secret, actionable messages.
- `server/index.js` opens the API listener even if PostgreSQL is temporarily down; `/api/health` and failed requests return HTTP 503 with a safe explanation.
- `tests/database-diagnostics.test.js` tests diagnostic mapping and verifies recovery guidance does not recommend deleting the database volume.


## Password authentication failure (local Docker database)

The supplied local `.env` uses `123password` for both `DATABASE_URL` and `POSTGRES_PASSWORD`. This is for local development only. If the Docker volume was initialized with a different role password, changing `.env` alone does not change that existing PostgreSQL role. The current `npm run dev` preflight attempts a local-only role-password sync and retries the connection without deleting the database volume.

You can also run the safe helper manually from the project root:

```powershell
npm run db:sync-local-password
npm run db:doctor
npm run db:migrate
```

The helper refuses remote database hosts and checks that the URL username, database, and password match the Compose settings. Do not use this local development password in production.
