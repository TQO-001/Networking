# Holly Bibley Network Discovery — Acceptance Checklist

Status for **version 1.5.5**. This checklist separates checks completed in this workspace from tests that require a running database or network equipment.

## Checked off

- [x] Discovery snapshots convert into the canonical version-6 topology model and preview/import into the editor.
- [x] LibreNMS inventory import and local subnet/SNMPv3 collector source are implemented.
- [x] The paired local agent can queue, claim, heartbeat, complete/fail and return validated snapshots through the API contracts.
- [x] Agent pairing uses one-time codes; agent tokens are hashed server-side; jobs are account/agent scoped and revocable.
- [x] Agent revocation and cancellation of outstanding jobs are committed atomically; claims re-check the active agent under a row lock.
- [x] The persistent agent checks its job lease before sending discovery probes.
- [x] Five-second heartbeats detect revoked/expired jobs; heartbeat requests do not overlap.
- [x] A lost lease aborts active local ping subprocesses or closes the in-flight SNMP session, then stops subsequent targets.
- [x] A revoked/invalid agent token stops the persistent poll loop instead of retrying forever.
- [x] Expired jobs are hidden immediately by the status API and removed by retention cleanup.
- [x] Jobs in `running` state with a null/expired lease can be reclaimed.
- [x] Agent picker distinguishes recently active, stale and never-connected agents.
- [x] Heartbeat, result-completion, and failure reports require an unexpired lease.
- [x] The 1.5.3 release archive excludes the machine-local `.env` file; first-run setup creates it from `.env.example` and detects or allows configuration of the local LAN address.
- [x] Added a guarded real-HTTP/real-PostgreSQL agent lifecycle test harness that only accepts a loopback database with `test` in its name; its live run remains an outstanding acceptance gate.
- [x] `npm run check:mapper` — **82 tests passed, 0 failed**; JavaScript syntax checks also passed. Two stale `.env`/fixed-IP tests were corrected in 1.5.3.
- [x] Integration harness scenario now covers revoking an agent with an outstanding running job, checking cancellation and rejection of later heartbeat/claim requests (the live HTTP/PostgreSQL run itself remains pending).
- [x] ZIP archive integrity checked for the delivered source package.
- [x] README, changelog, and packaging tests agree that `.env` is excluded and `.env.example` is used for first-run setup.

## Remaining acceptance gates

- [ ] **Build (environment-blocked):** install dependencies and pass `npm run build` / `npm run check`. Dependency installation times out because the registry is unreachable in this workspace and Vite is absent, so build verification is not complete.
- [ ] **Application integration (environment-blocked):** run the migrated app with disposable PostgreSQL and test authenticated pairing → agent claim → heartbeat → result import → revoke over HTTP. No PostgreSQL service or container runtime is available here.
- [ ] **Network lab:** verify subnet discovery on Windows/Linux and compare IP/MAC findings; validate SNMPv3 VLAN/interface/LLDP results against at least one managed lab switch.
- [ ] **Release readiness:** verify config-file permissions and the new cancellation/shutdown behaviour in a live deployment; complete deployment-security plus OT safety review before production use. Code-level cancellation/retry tests now pass, but live validation remains pending.

## Not claimed

- No live database/API lifecycle test has been run in this workspace.
- No live managed switch or production OT network has been scanned.
- No successful Vite production build has been observed.
- Dependency installation timed out in this environment; there is no local PostgreSQL service, `psql`, Docker, or Podman available for the live HTTP/database run.
