declare module 'react' {
  const React: any;
  export default React;
  export const useCallback: any;
  export const useEffect: any;
  export const useMemo: any;
  export const useRef: any;
  export const useState: any;
  export const createContext: any;
  export const useContext: any;
  export const memo: any;
  export const Fragment: any;
}
declare module 'react-dom/client' {
  export const createRoot: any;
}
declare module '*.css' { const x: any; export default x; }
declare module '*.js' { const x: any; export default x; }
declare namespace JSX {
  interface IntrinsicElements { [elemName: string]: any; }
}
