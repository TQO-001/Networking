import { test, expect } from '@playwright/test';

async function openNavItem(page, testId, sectionName) {
  const item = page.getByTestId(testId);
  if (!(await item.isVisible())) {
    await page.getByRole('button', { name: new RegExp(sectionName, 'i') }).click();
  }
  await expect(item).toBeVisible();
  await item.click();
}

async function assertNoPageError(page) {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  return () => expect(errors, `Unexpected page errors: ${errors.join(' | ')}`).toEqual([]);
}

test('workspace boots with vertical sidebar', async ({ page }) => {
  const assertClean = await assertNoPageError(page);
  await page.goto('/');
  await expect(page.getByTestId('pf-sidebar')).toBeVisible();
  const metrics = await page.getByTestId('pf-sidebar-nav').evaluate(el => {
    const s = getComputedStyle(el);
    return {
      display: s.display,
      flexDirection: s.flexDirection,
      overflowX: s.overflowX,
      overflowY: s.overflowY,
      scrollWidth: el.scrollWidth,
      clientWidth: el.clientWidth,
    };
  });
  expect(metrics.display).toBe('flex');
  expect(metrics.flexDirection).toBe('column');
  expect(metrics.overflowX).toBe('hidden');
  expect(metrics.overflowY).toMatch(/auto|scroll/);
  expect(metrics.scrollWidth).toBeLessThanOrEqual(metrics.clientWidth + 1);
  await assertClean();
});

test('sidebar navigation switches workspace without exit buttons', async ({ page }) => {
  const assertClean = await assertNoPageError(page);
  await page.goto('/');
  await openNavItem(page, 'nav-analytics', 'PRACTICE');
  await expect(page.getByText('ANALYTICS', { exact: true })).toBeVisible();
  await openNavItem(page, 'nav-lab', 'NETWORK LAB');
  await expect(page.getByText('CLI LAB', { exact: true })).toBeVisible();
  await openNavItem(page, 'nav-topology', 'NETWORK LAB');
  await expect(page.getByText('TOPOLOGY', { exact: true })).toBeVisible();
  await openNavItem(page, 'nav-dashboard', 'START');
  await expect(page.getByRole('button', { name: /Open discovery/i })).toBeVisible();
  await assertClean();
});

test('full simulation can be started from console', async ({ page }) => {
  const assertClean = await assertNoPageError(page);
  await page.goto('/');
  await page.getByRole('button', { name: /Full simulation/i }).click();
  await expect(page.getByText(/QUESTION 001/i)).toBeVisible();
  await expect(page.getByText(/120:00|119:/)).toBeVisible();
  await assertClean();
});

test('mobile navigation opens and closes cleanly', async ({ page }) => {
  const assertClean = await assertNoPageError(page);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  await page.getByRole('button', { name: /Open navigation/i }).click();
  await expect(page.getByTestId('pf-sidebar')).toHaveClass(/mobile-open/);
  await openNavItem(page, 'nav-analytics', 'PRACTICE');
  await expect(page.getByTestId('pf-sidebar')).not.toHaveClass(/mobile-open/);
  await assertClean();
});
