# UI/UX checkpoint — 22 October 2026

This is a working checkpoint on the v64.0.6 baseline, not a final release.

## Changes in this pass

- The responsive touch-key row is now available in both Driller Bill practice and the physical-device console.
- Device-console keys provide common safe-command completion from a fixed list, `?`, pipe and slash insertion, command history, clear input, and clear output.
- Command helper functions preserve the caret, only complete against the supplied catalogue, and restore an unsent draft when navigating history.
- The physical-device input disables browser spelling and capitalization corrections.
- The touch-key row is available through 900 CSS pixels, covering common tablet portrait widths.
- The theme bridge now maps both `--ux-*` tokens and original global surface, text, muted and accent tokens so older workspaces use the selected light/dark palette.

## Verification

- `npm run check`: passed after the latest theme and terminal changes (187/187 main tests, 23/23 Device Agent, 5/5 backend) with a temporary link to the global TypeScript package.
- Main suite: 187/187 passed; Device Agent: 23/23; backend: 5/5.
- Production build: blocked by missing Vite dependency (`vite: not found`) after dependency installation timed out.
- Browser visual/E2E checks and Docker builds remain unverified.

The project version remains 64.0.6 while UI/UX work continues. Do not release until the production build and browser checks pass.
