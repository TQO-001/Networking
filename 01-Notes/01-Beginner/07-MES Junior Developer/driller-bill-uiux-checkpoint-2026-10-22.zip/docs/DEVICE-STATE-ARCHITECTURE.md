# Driller Bill — Device State Architecture

## Purpose

Driller Bill treats a network device as a structured engineering object rather than only an SSH session or a text terminal. The device layer is shared by simulated equipment and future physical transports.

## State layers

```text
Device definition
      │
      ├── identity / vendor / platform
      ├── connection metadata
      └── capabilities

Live session
      │
      ├── connect / disconnect
      ├── command execution
      └── vendor adapter

Observed state
      │
      ├── interfaces
      ├── VLANs
      ├── trunks
      ├── routes
      └── inspection signals

Configuration state
      │
      ├── running-config
      ├── startup-config
      ├── snapshots
      └── diffs

Durable agent state
      │
      ├── registered physical device definitions
      ├── configuration history
      └── latest inspection report
```

## Persistence boundary

The local Device Agent persists device definitions without storing live password values. Password authentication is represented by an environment-variable name; the secret remains in the agent process environment. SSH private-key paths are metadata only.

The default executable-agent state file is `~/.driller-bill/agent-state.json`. Override it with `DRILLER_BILL_AGENT_STATE_FILE`. State writes use an atomic temporary-file + rename operation and restrictive local file permissions.

## Inspection

The inspection layer converts vendor command evidence into structured data. Cisco IOS-style inspection currently covers:

- `show version`
- `show ip interface brief`
- `show vlan brief` on switches
- `show interfaces trunk` on switches
- `show ip route`

The result is stored as a versioned inspection report so the UI, Twin, diagnostics and future automation can consume structured state rather than scrape the CLI independently.

## Design rule

The browser operates on intent and structured data. Vendor commands belong inside the adapter. Transport details belong inside the local agent. This keeps the React workspace independent from SSH/serial implementation details and gives simulated and physical devices the same application contract.
