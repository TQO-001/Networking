# Driller Bill — Improvement Audit & Roadmap

**Baseline:** uploaded v64.0.6 archive (389 entries)  
**Working copy:** audit/UX fixes in progress; package version remains `64.0.6` until the release gate is complete.  
**Status rule:** a checkbox means the code change for that item is complete. Any unrun browser, Docker or physical-device test is stated separately; no unavailable check is treated as a pass.

## Progress tally

| Section | Done | Total |
|---|---:|---:|
| B — Broken right now (deploy, CI, runtime) | 4 | 6 |
| L — Learning experience | 4 | 7 |
| S — Security & safety | 2 | 6 |
| D — Data safety & persistence | 1 | 4 |
| P — PWA & performance | 2 | 5 |
| Q — Quality gates & testing | 2 | 5 |
| H — Codebase hygiene & identity | 4 | 6 |
| F — Features toward the long-term vision | 0 | 3 |
| **Total** | **17** | **42** |

## B — Broken right now

- [x] **B1 · Docker image builds no longer run documentation-dependent unit tests.** `Dockerfile` and `Dockerfile.cloud-web` now compile production assets only; the image context can continue excluding README/release-note files. Docker itself is not installed in this environment, so an actual image build is still outstanding. Release-pointer tests remain in `npm test` pending Q2.
- [x] **B2 · Cloud API upstream and smoke check.** nginx targets the `driller-bill-api` Compose service; `npm run smoke:cloud` checks `/api/v1/health` through the published web/nginx endpoint and verifies the database status. The test logic passes with a mocked response; Docker Compose itself cannot be run in this environment.
- [x] **B3 · Backend environment safety.** API config now uses `APP_ENV`; only explicit `development` disables production safeguards. Added tests for production-default behaviour and JWT-secret enforcement.
- [x] **B4 · API cache isolation.** The service worker bypasses `/api/`; the API sets `Cache-Control: no-store` and `Pragma: no-cache`, and nginx repeats no-store plus relevant security headers. Service-worker bypass behaviour is exercised in a VM regression test.
- [ ] **B5 · CI installation and complete gate.** Renamed the workflow and removed setup-node's npm-cache setting (the archive has no lockfile). A reviewed lockfile, `npm ci`, and all quality gates in CI remain outstanding.
- [ ] **B6 · Playwright smoke suite.** Updated tests for the current sidebar labels and collapsed navigation groups. Browser-based E2E could not be run here; validate the four tests in a browser-enabled environment before marking complete.

## L — Learning experience

- [x] **L1 · IOS tab completion and inline `?` help.** The drill terminal now wires `completeIosCommand`, lists candidates on a second Tab, emits inline context help without Enter, and handles Ctrl+C, Ctrl+Z and Ctrl+L. The misleading footer claim is gone; IOS context-help candidates have a smoke-tested helper. Browser interaction still awaits the Playwright run.
- [x] **L2 · Practice-terminal ergonomics.** Added the shared text-size, copy, clear, follow-output and expanded-mode toolbar; set an accessible labelled log and disabled browser spelling, auto-capitalization, autocorrection and autocomplete. Expanded mode traps focus, locks background scroll and exits on Escape. Fixed auto-follow to scroll the actual output pane, not the outer shell. Both the `--ux-*` foundation tokens and older `--bg` / `--panel` / `--text` / accent tokens now resolve through the selected theme. Source syntax and regression checks pass; visual/browser interaction still needs E2E verification.
- [ ] **L3 · Escalating hints.** Add nudge, pointer and reveal levels; mark reveal hints in Twin and charge XP.
- [ ] **L4 · Cross-session learning history.** Add bounded attempt history, trends, recurring error categories and spaced-repetition review; avoid reading progress from storage on every render.
- [ ] **L5 · Combined assessment & learning sheet.** Produce a printable all-in-one report with score, grouped errors, weak objectives, cue cards and next drill.
- [x] **L6 · Speed-score formula.** Score now weights accuracy 40%, objective completion 30% and speed 30%; the debrief shows the formula and each component percentage.
- [x] **L7 · Mobile terminal key row.** The Driller Bill drill and physical-device console expose an accessible, horizontally scrollable touch row for Tab/common safe-command completion, context-help marker, pipe, slash, command history and clear actions. Shared helper tests cover completion, caret insertion and history draft restoration. Browser rendering on real phone/tablet sizes remains unverified.

## S — Security & safety

- [ ] **S1 · Rate-limit trust and memory use.** nginx now overwrites `X-Forwarded-For`, but trusted-proxy configuration, shared limiting and idle-key eviction remain.
- [x] **S2 · Restrict raw physical-device `execute`.** Physical SSH/serial execution permits bounded read-only IOS commands only. Mutating commands are refused with a change-control pointer; success, blocked and error attempts are stored in a capped per-device audit history. Tests verify `reload` never reaches the adapter and that both blocked and allowed attempts are recorded.
- [x] **S3 · Device Agent hardening.** Added constant-time bearer-token comparison, 1 MiB request-body limit, loopback-only Host validation, dedicated default port 8788, and default/documented origins for Vite dev, preview and local Docker. HTTP tests verify forged Host and oversized bodies are rejected; the raw-command and default-origin tests pass.
- [ ] **S4 · Account lifecycle.** Refresh-token reuse detection/locking, generic registration responses, expiry purge, JWT claim requirements, and account export/deletion.
- [ ] **S5 · Browser security headers and API docs.** Add CSP/HSTS as deployment permits and disable API docs outside development. Existing basic headers were preserved on `/api/` responses.
- [ ] **S6 · Non-root containers and reproducible installs.** Non-root API/web runtime where appropriate, pinned image digests and `npm ci`.

## D — Data safety & persistence

- [ ] **D1 · Back up/sync all Driller Bill learning keys.** Extend frontend and backend fields together and migrate older snapshots.
- [ ] **D2 · Storage-key registry and migration.** Standardize on `driller-bill.` while copying all legacy keys forward; continue accepting old backup schema identifiers.
- [ ] **D3 · Honest storage failure state.** Report memory-only fallback as unsaved and add a persistent warning; consider IndexedDB for large history.
- [x] **D4 · 413 UX.** nginx accepts 2 MB cloud snapshots and Cloud Sync now explains the size limit without suggesting local data was lost; its message explicitly recommends exporting a local backup before reducing stored data.

## P — PWA & performance

- [ ] **P1 · Reliable offline lazy workspaces.** Generate precache manifest from Vite output and cache assets with stale-while-revalidate.
- [x] **P2 · Manifest, icons and health metadata.** Added a 192×192 icon, retained the standard 512×512 icon, created a separate safe-zone-padded 512×512 maskable icon, and set manifest `id`/`scope`. Browser title, description and manifest now describe the network-engineering workspace. Health and service-worker cache metadata are synchronized from `package.json` at build time; the build itself still awaits Vite installation.
- [ ] **P3 · Defer question banks and drill engines.** Dynamically load exam banks on exam start and only load the selected drill engine.
- [ ] **P4 · CSS consolidation.** Remove dead selectors after coverage analysis and converge styles on one token-driven system.
- [x] **P5 · Compression and cache headers.** Both Nginx configs enable gzip for text, CSS, JS, JSON, manifests and SVG. Exact `/sw.js` and `/manifest.webmanifest` locations use non-immutable expiry; the hashed-asset cache rule remains for versioned/static assets.

## Q — Quality gates & testing

- [ ] **Q1 · Rendered React tests.** Add Vitest/jsdom/Testing Library for terminal input/history, sidebar drawer and cloud sync conflicts. Current suite still has many source-text checks.
- [x] **Q2 · Single release checker.** Added `npm run release:metadata:check` to derive app, backup schema, health, service-worker, changelog and release-note pointers from `package.json`; version-pointer assertions were removed from feature tests. The checker has positive and mismatch regression tests.
- [ ] **Q3 · Lint and format.** Add ESLint with React Hooks rules and Prettier, then enforce lint in the main check.
- [ ] **Q4 · API integration tests.** Exercise registration, login, refresh rotation, conflicts, rate limits and cookie flags against throwaway PostgreSQL.
- [x] **Q5 · CI full gate.** CI now runs `npm run check`, installs Chromium, runs Playwright E2E, builds production assets, checks deployment configuration and runs a dedicated Python job. `test:cloud` uses `python3`. The workflow has not yet run on GitHub; lockfile/`npm ci` reproducibility is tracked separately under B5.

## H — Codebase hygiene & identity

- [x] **H1 · Release archive organization.** Moved all 50 versioned release-note and test-report files from the repository root into `docs/releases/`. `CHANGELOG.md` remains the canonical, newest-first summary and root indexes link to the archive.
- [x] **H2 · README restructuring.** Rebuilt README around the product definition, quick start, learning and engineering capabilities, local Device Agent, cloud deployment, data/safety notes and documentation links. Historical release details are linked rather than stacked above the product overview.
- [ ] **H3 · Penny Farthing legacy naming.** Rename remaining user-visible/internal legacy names carefully; perform storage and schema changes through D2's migration.
- [x] **H4 · Version consistency.** `npm run build` now updates the built health file and service-worker cache from `package.json`; the cloud API image copies `package.json` and accepts `DRILLER_BILL_VERSION` as a build argument, falling back to the package version. Current source health metadata also matches 64.0.6.
- [x] **H5 · Build debris and duplicates.** Removed the byte-for-byte duplicate `Dockerfile.api` (Compose uses `backend/Dockerfile`), added `__pycache__/` and `*.py[cod]` to `.gitignore`, and removed generated backend bytecode from the working archive. `.env.example` uses `APP_ENV` for the Python API.
- [ ] **H6 · Component size.** Split `DrillerBillStudio` into smaller views first, then other oversized files as touched.

## F — Long-term features (after UI/UX and core reliability)

- [ ] **F1 · Hands-on CLI practice exam.** Timed multi-module tasks, auto-grading and a pass mark; reuse PBQ scoring/reporting.
- [ ] **F2 · Topology-linked drills.** Launch a drill from a topology device with the console docked beside the map.
- [ ] **F3 · In-app cue-card review.** Turn Twin cue cards into a spaced-repetition queue seeded from learner errors.

## Validation log

| Check | Current result |
|---|---|
| `npm run validate` | PASS — 72 source files, 1,935 static questions, 387 families |
| `npm run validate:driller-bill` | PASS — 22 modules |
| `npm run validate:cloud` | PASS — 13 Python files |
| `npm run qa:content` | PASS — 387 families, 1,935 static questions, 500 exhibits, 53 objectives |
| `npm run typecheck:core` | PASS using the globally installed TypeScript compiler |
| `npm test` | PASS — 183/183. Uses a temporary local symlink to globally installed TypeScript because network installation timed out. No dependencies are included in the deliverable. |
| `npm run test:agent` | PASS — 23/23, including destructive-command refusal/audit and Host/body-size protections |
| `npm run test:cloud` | PASS — 5/5 |
| `npm run build` | NOT RUN successfully: Vite is not installed locally; `npm install --ignore-scripts` timed out. No production build claim is made. |
| `npm run browser:preflight` | PASS — Chromium 144 detected; sidebar CSS contract passes and the Playwright suite is configured. This preflight does not execute browser E2E. |
| Docker Compose / Playwright E2E / visual browser audit | NOT RUN: Docker and the Playwright package are unavailable. Chromium is installed, but the Vite build cannot run without project dependencies. |



## 22 October continuation — UI/UX pass

- [x] Mapped legacy global styling tokens (`--bg`, `--panel`, `--text`, muted and accent tokens) onto the persistent light/dark token palette; strengthened the regression test to cover both token generations.
- [x] Extended the responsive touch-key row from the drill console to the physical-device console. The row appears up to 900 CSS pixels wide, making it available on common tablet portrait widths as well as phones.
- [x] Added tested helpers for command completion from a fixed read-only command catalogue, caret-preserving symbol insertion, and history navigation that restores the unsent draft.
- [x] Disabled spellcheck, autocapitalization, autocorrection and autocomplete in the physical-device command input.
- [ ] Rendered/browser validation remains blocked because dependencies are not installed in this environment; `npm install --ignore-scripts --no-audit --no-fund` timed out.
- [ ] `npm test` currently reports 182 passing tests and one test file failing to load because `typescript` is unavailable. Targeted terminal/accessibility tests pass (15/15 at this checkpoint before the added responsive assertion; rerun results are recorded in the continuation report).
