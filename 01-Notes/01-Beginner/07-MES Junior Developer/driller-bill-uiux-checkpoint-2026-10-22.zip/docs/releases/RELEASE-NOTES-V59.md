# Driller Bill v59.0.0 — Change Control & Operational Hardening

## Overview
v59 makes configuration changes operationally auditable and safer. Physical SSH and serial/console mutations now require a short-lived preflight record tied to the exact device and intent. The local Device Agent captures a pre-change configuration baseline, classifies risk, records diagnostics and requires an explicit approval token before applying the mutation.

## Change-control pipeline
`Plan → Preflight → Approve → Apply → Verify`

Preflight reviews:
- typed intent validity
- active device session
- fresh structured inspection
- existing configuration-history baseline
- device diagnostics/health
- critical-change review
- physical-device confirmation

## Audit history
Every approved mutation receives a change ID and can retain:
- risk classification
- sanitized intent fields
- display-safe command plan
- pre/post snapshot IDs
- configuration diff summary
- verification status
- timestamps and final status

Raw intent commands and credential values remain agent-side only.

## Compatibility
Simulated devices remain compatible with direct intent application; the agent internally creates the required preflight. Physical SSH/serial devices must supply the matching preflight change ID.

## Security hardening
Configuration snapshots, command transcripts and state returned to the browser are reduced to display-safe fields. Credential-bearing commands are redacted, and simulated adapter state is no longer returned inside change-application responses.

## Validation
- Core test suite: 113/113
- Device Agent suite: 21/21
- Core typecheck: PASS
- Source validation: PASS
- Driller Bill validation: PASS
- Cloud validation: PASS
- Content QA: PASS
