# Driller Bill v64.0.5 — Engineering-first UX polish

## Product and interaction changes

- Reframed the landing console around network engineering tasks while retaining learning and assessment tools.
- Added six direct-access cards: Inspect devices, Network discovery, Configuration, Troubleshooting, Knowledge base, and CLI Lab.
- Added a clear first-run recommendation to explore Network Discovery rather than making a full CCNA simulation the only suggested action.
- Replaced text glyphs in navigation with a consistent inline SVG icon system.
- Navigation sections can collapse; the active workspace section expands automatically and user preferences persist locally.
- Improved the mobile navigation drawer with modal semantics, focus trapping, focus restoration, Escape-to-close, and scroll locking.
- Workspace search remains visible on tablets and phones as an icon button.
- Increased explanatory copy in high-value workspace panels to 16px while retaining a 12px minimum for compact metadata.

## Compatibility / safety

- No network-engineering or change-control business logic was changed.
- Sidebar section preferences use optional localStorage and safely fall back when storage is unavailable.
- The mobile drawer restores document scrolling and keyboard focus when closed.

## Validation

The project check gate passes in the current workspace: 161 application tests, 21 Device Agent tests, 3 cloud tests, core typecheck, source/module validation, content QA, and browser preflight. See `TEST-REPORT-V64.0.5.md` for exact outcomes.

The Vite production build is not claimed as verified here because Vite is not installed in the current workspace; the dependency installation attempt timed out. Run `npm run build` on Windows after `npm install` to verify the production bundle.
