# Driller Bill v63.0.0 — UX Rebuild Foundation

## Goal
A visual and interaction reset focused on readability, hierarchy, and restrained neo-brutalism. Feature development is intentionally paused during this UX phase.

## Design direction
- Soft neo-brutalism inspired by the restrained styling language of neobrutalism.dev
- Off-white application surfaces with near-black ink and cyan identity
- Modest 4–6px radii and selective 3–4px hard shadows
- Strong typography instead of micro-label density
- Technical terminal surfaces remain dark, but at readable 15–17px typography

## Readability changes
- Legacy font declarations below 12px are normalized upward
- Body baseline increased to 16px
- Secondary copy and technical metadata use a consistent readable floor
- Buttons and fields use 48px default interaction height
- Sidebar navigation uses 15px labels and 48px rows
- Terminal command/output text uses 16px by default

## UX foundation
- New `src/ux-foundation.css` canonical design layer
- Unified surfaces, borders, radii, shadows, typography, buttons, fields, tabs and terminal treatment
- Application shell, navigation, dashboards, engineering cards, labs and exam/study surfaces receive the new visual language
- Existing feature behavior is preserved; this release intentionally focuses on presentation and interaction ergonomics

## Validation note
The source-level regression suite should remain the primary compatibility gate. Browser production build/E2E requires installed dependencies and a browser runtime.
