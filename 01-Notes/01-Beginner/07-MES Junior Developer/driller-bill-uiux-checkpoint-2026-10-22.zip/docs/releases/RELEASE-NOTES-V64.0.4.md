# Driller Bill v64.0.4 — UX Performance + Windows QA

## What changed

- Fixed the `ERR_UNSUPPORTED_ESM_URL_SCHEME` failure in `npm run check` on Windows by converting the custom ESM loader path to a `file://` URL.
- Converted 20 large engineering and lab workspace imports to React lazy imports so those screens are fetched only when opened.
- Added a consistent, accessible loading skeleton while deferred workspace chunks load.
- Limited Google Sans and Google Sans Code CSS imports to Latin and Latin Extended subsets, avoiding unrelated script font assets in the browser build.
- Replaced the decorative header search affordance with a workspace command palette: `Ctrl/⌘+K`, searchable workspace aliases, arrow-key selection, Enter to navigate, Escape to close, and focus restoration.
- Versioned PWA cache and backup metadata to v64.0.4.

## Validation

Run `npm run check` and `npm run build` on a Windows machine with dependencies installed. Tests include a regression for Windows-safe loader URLs, route-level code splitting, the loading state, and font subset imports.
