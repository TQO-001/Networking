# Driller Bill 35.0.0 — Product Foundation

## Navigation and information architecture

- Reorganized the workspace sidebar around the learner journey: Start, Learn, Practice, Network Lab, and System.
- Renamed navigation labels to describe user intent rather than implementation details.
- Added live counts for due spaced-repetition cards and the mistake bank.
- Preserved the existing route IDs and canonical network workspace wiring.

## Visual foundation

- Added shared UI, display, and CLI typography tokens with Google Sans/Jost/Montserrat-style stacks and Courier-based terminal fallbacks.
- Increased hierarchy and spacing in the sidebar.
- Added clearer active navigation treatment and count badges.
- Added subtle text-fill treatment for major display headings.
- Kept the existing orange technical identity while moving the shell toward the new Driller Bill design system.

## Safety / regression scope

- No exam engine, network engine, mastery engine, Twin engine, or storage schema was changed.
- Existing source validation, content QA, cloud validation, and 29 core tests pass.
- Production build was not completed in this environment because dependency installation timed out before Vite was available.
