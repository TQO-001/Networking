# Penny Farthing 32.0.0 — Test report

This release retains the v31 browser/source QA assets and adds a cloud validation gate.

Cloud checks cover:

- required cloud files
- version consistency
- API dependency presence
- React cloud route wiring
- snapshot schema validation
- credential normalization/bounds

The API integration suite requires the server dependencies to be installed and a PostgreSQL instance for full HTTP integration testing. The schema/security tests do not require a database.
