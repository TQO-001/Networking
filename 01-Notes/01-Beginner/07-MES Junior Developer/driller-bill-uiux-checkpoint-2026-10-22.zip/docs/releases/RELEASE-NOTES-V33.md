# Driller Bill 33.0.0

## Python backend migration

- Replaced the Node/Express cloud API with Python/FastAPI.
- Preserved the existing `/api/v1` authentication and sync contract used by the React frontend.
- Added SQLAlchemy for database access and psycopg for PostgreSQL.
- Kept bcrypt-compatible password hashing so existing bcrypt hashes remain verifiable.
- Added versioned SQL migrations and a Python migration runner.
- Added Python backend unit tests for credential and snapshot policies.
- Removed the legacy Node cloud backend from the release tree.

## Deployment

- Replaced the API container with a Python 3.13 image.
- Docker Compose now runs React/Nginx + FastAPI + PostgreSQL without requiring a platform-specific deployment service.
- Added a web-only validation gate so the frontend image does not need a Python runtime during its build.
