# v64.0.6 — Workspace layouts + terminal ergonomics

## Terminal improvements

- Added a shared terminal toolbar to the stateful IOS simulator and the live SSH/serial device console.
- Added persistent terminal text sizing: 16px minimum, 18px default, 24px maximum, with two-pixel increments.
- Added follow-output on/off, copy transcript, clear screen, and expanded terminal controls.
- Added automatic scroll-follow when new output arrives (user-controllable) and Escape-to-exit expanded mode.
- Made simulator and device console outputs keyboard-focusable, labelled log regions; command inputs now have per-device accessible names.
- Kept IOS command output horizontally scrollable so columnar command output does not get mangled by wrapping.
- Redacted common password/secret lines in copied terminal transcripts.
- Added a shared `src/terminal/` implementation for settings, controls, and sanitized transcript copy.

## Workspace layout polish

- Reworked Devices into a more stable two-column desktop layout with a sticky device index and responsive single-column breakpoint.
- Increased visual hierarchy for device title, metrics, capability panels and configuration tools.
- Improved metric cards and interface/route data layouts, with wrapping for long hostnames, endpoint details and table values.
- Made physical device quick commands wrap into readable buttons instead of relying on a horizontally scrolling row.
- Updated the stateful IOS simulator console and command reference for more usable height, readable output, and responsive expanded mode.
- Preserved the existing Google Sans / Google Sans Code, restrained neo-brutalist cards, cyan identity, and light/dark tokens.

## Validation status

- Application tests, Device Agent tests, cloud tests, core typecheck and project validators are run as part of `npm run check`.
- `npm run build` must be run after dependency installation to verify the production bundle in the target environment.
