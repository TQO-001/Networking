# Driller Bill v64.0.4 — Test Report

## Scope

Address the Windows-only ESM loader failure from the supplied v64.0.3 log, improve workspace loading performance, reduce startup font assets, and make the header search a working accessible control.

## Implemented

- `scripts/validate-driller-bill.mjs` passes a `file://` loader URL to Node, avoiding the Windows `ERR_UNSUPPORTED_ESM_URL_SCHEME` failure.
- Twenty large engineering/lab workspaces load on demand with `React.lazy`; an accessible status/skeleton fallback appears while a deferred workspace loads.
- Google Sans and Google Sans Code CSS imports target Latin and Latin Extended subsets instead of loading every script subset into the initial app.
- Header search opens a workspace command palette. `Ctrl/⌘+K` opens it; arrow keys move selection; Enter navigates; Escape closes it; keyboard focus is managed and restored.
- Added regression checks for Windows-safe paths, lazy-loading contracts, font subset imports, loading-state accessibility/responsiveness, and command-palette keyboard semantics.

## Checks run in the current workspace

- `npm run check`: PASS — 154 application tests, 21 Device Agent tests, 3 cloud tests, core typecheck, module validation, source validation, and content QA.
- `npm run browser:preflight`: PASS — Chromium detected and sidebar CSS contract passes.
- `npm run build`: attempted but unavailable in this environment because Vite is not installed in the extracted workspace (`vite: not found`). The user-supplied Windows log shows that v64.0.3 built successfully, but that does not independently prove the v64.0.4 build. Run `npm run build` on the Windows development machine to verify this release's bundle.
