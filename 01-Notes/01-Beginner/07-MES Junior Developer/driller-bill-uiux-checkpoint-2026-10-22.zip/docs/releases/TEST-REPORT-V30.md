# Penny Farthing 30.0.0 — Content QA Report

## Automated results

`npm run qa:content` → PASS

- 387 authored families
- 1,935 static questions
- 500 exhibit question variants
- 53 current CCNA v1.1 objective numbers represented
- No duplicate question IDs
- No duplicate answer choices within a question
- Valid answer indexes
- Five distinct prompts per family
- Valid exhibit normalization
- No placeholder content detected

`npm run validate` → PASS

`npm test` → PASS

28 / 28 regression tests passed.

`npm run check` → PASS

The production bundle was not generated because `vite` is not installed in this environment.
