# Driller Bill v60.0.0 — Multi-device Operations & Change Sets

v60 extends the v59 change-control boundary from one target device to coordinated multi-device changes.

## Highlights

- New `change-sets` core engine with typed, per-device compilation.
- New Change Sets engineering workspace.
- Select multiple devices and describe one structured configuration intent.
- Per-device plan validation against device capabilities.
- Per-device v59 preflight and short-lived approval records.
- Sequential execution with explicit stop-on-failure or continue-on-failure strategy.
- Per-device post-apply inspection and verification evidence.
- Partial/failed execution states are preserved instead of silently rolled back.
- Local change-set history with secret-field redaction.
- Existing single-device Configuration and Runbook workflows remain unchanged.

## Operational boundary

A change set is an orchestration layer, not a bypass around change control. Every target still uses the Device Agent's preflight and apply contract. There is no automatic rollback and no hidden batch mutation path for physical devices.

## Validation

The release validation suite must include change-set normalization, target duplication checks, capability-aware planning, partial-state summaries, persistence sanitization, and the existing v59 safety suite.
