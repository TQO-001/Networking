# Driller Bill v46.0.0 — Durable device state + structured inspection

## Focus
Make the local Device Agent remember the engineering state around physical devices and turn standard inspection commands into structured network data.

## Added
- Durable local Device Agent state file for registered device definitions, configuration history, and latest inspection reports.
- Atomic state-file writes with restrictive local permissions.
- Configurable state location via `DRILLER_BILL_AGENT_STATE_FILE`.
- Default agent state location under the user's home directory.
- Structured Cisco IOS inspection for version, hostname, interfaces, VLANs, trunks and routes.
- Inspection observation signals for non-operational interfaces and missing/empty state.
- `POST /api/v1/devices/:id/inspect` for live inspection.
- `GET /api/v1/devices/:id/inspection` for persisted inspection retrieval without reconnecting.
- Devices workspace structured inspection panel.
- Inventory metadata for latest inspection state.

## Architecture
Normal programmatic `createAgentServer()` calls remain non-persistent unless a `stateFile` is supplied, which keeps tests and embedded uses isolated. The executable `startAgent()` defaults to a durable state file.

The browser remains transport-agnostic. Inspection is performed by the device adapter and persisted by the local agent.
