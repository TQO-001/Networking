# Driller Bill v58.0.0 — Unified Workflows

## Unified engineering thread

v58 connects the major Driller Bill workspaces through a persistent, local-first workflow thread. A user can carry the same context from knowledge and learning through troubleshooting, configuration, runbooks, verification and Twin documentation.

### Workflow orchestration
- Added a first-class Unified Workflows workspace.
- Added reusable workflow templates for Learn → Operate, Troubleshoot → Recover, Device Change and Engineering Case.
- Added persistent stage status, notes, artifacts, target-device context and timeline history.
- Added workflow resume and local history.
- Added controlled stage completion rather than automatic assumptions about completed work.

### Cross-workspace handoff
- Added an active-workflow context bar to Knowledge Base, Driller Bill drills, Devices/Configuration, Runbooks, Troubleshooting and Twin.
- Stage-specific workspaces can open the active workflow and explicitly complete the current stage.
- Knowledge articles and troubleshooting cases can start workflow threads directly from their domain context.
- Twin remains the documentation/reasoning endpoint rather than bypassing typed configuration or verification.

### Safety / data handling
- Workflow state is local-first and contains only engineering context, notes and non-secret artifacts.
- No device credentials are copied into workflow records.

## Verification
- Unified workflow unit tests added.
- Existing regression, Device Agent, cloud, content and core typecheck suites remain required for release.
- Browser build still requires the workspace dependencies (`npm install`).
