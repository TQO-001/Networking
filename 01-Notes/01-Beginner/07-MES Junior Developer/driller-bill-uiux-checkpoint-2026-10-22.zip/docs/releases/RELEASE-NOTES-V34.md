# Driller Bill 34.0.0 — Legacy Integration Release

## Product identity
The platform is now branded **Driller Bill**. Penny Farthing-era internal schemas remain only where necessary for backward compatibility with existing local study data and topology exports.

## Integrated legacy Driller Bill system
- 22 module engines from the Driller Bill v0.5.1 production line.
- Switch, router, server and firewall drill families.
- Guided theory → simulation → terminal practice.
- Speed Drill with timing, accuracy and objective scoring.
- Open Sandbox.
- Twin live telemetry and exportable Documentation / Errors / Improvements / Cue Cards.
- Built-in Markdown study notes.
- Declarative community Drill Builder (schema v1).
- Module XP/progress.

## Modern platform retained
- Randomized CCNA assessment engine.
- 387 authored question families / 1,935 static questions.
- Exhibits, scenario forms and advanced PBQs.
- Canonical live network state.
- Stateful CLI, topology, protocol and packet engines.
- Adaptive mastery and spaced repetition.
- Question Authoring Studio.
- Offline backup/recovery.
- Optional Python/FastAPI/PostgreSQL cloud layer.

## QA
- Project checks: PASS.
- Driller Bill catalog: 22 modules validated end-to-end.
- Existing regression suite: 29/29 PASS.
- Cloud tests: 3/3 PASS.
- Deployment preflights: PASS.

A production Vite build still requires `npm install` in a normal networked environment because npm registry access timed out in the current execution environment.
