# Driller Bill v64.0.0 — Unified UI System + Light/Dark Themes

v64 turns the v63 foundation into the first real application-wide UI system.

## Visual direction

- Restrained soft neo-brutal cards, buttons, tabs and panels.
- Google Sans for application UI and Google Sans Code for terminal/technical surfaces.
- Cyan is the primary Driller Bill interaction color rather than the entire palette.
- Larger typography, wider spacing, clearer hierarchy and stronger content grouping.
- Hard shadows are selective and reserved for important interactive surfaces.
- Terminal text defaults to a readable 17px with 1.72 line-height.

## Shell

- Unified application header across regular workspaces.
- Search affordance in the shared header.
- Persistent light/dark theme toggle.
- Theme preference stored in the existing local settings record.
- Theme toggle is also available during assessment, study and result screens.

## Dark mode

- Full design-token dark theme with charcoal surfaces, light ink and cyan accents.
- `color-scheme` follows the selected theme.
- Engineering cards, forms, navigation, buttons, metrics and study surfaces use the same token system in both themes.

## Accessibility

- Existing focus-visible, skip-link, reduced-motion, high-contrast and touch-target work remains intact.
- Theme control exposes its state through `aria-pressed` and an explicit accessible label.

## Engineering safety

No business logic or device-agent behavior was changed in this release. The work is deliberately visual and interaction-focused.
