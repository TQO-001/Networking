# Penny Farthing 29.0.0 — Production Hardening

- Added deployment preflight and combined release check.
- Added `/health.json` for container and Coolify health monitoring.
- Added Docker Compose smoke configuration.
- Hardened Nginx headers and SPA caching behavior.
- Added `.dockerignore` and Coolify deployment guide.
- Updated release version to `29.0.0`.
