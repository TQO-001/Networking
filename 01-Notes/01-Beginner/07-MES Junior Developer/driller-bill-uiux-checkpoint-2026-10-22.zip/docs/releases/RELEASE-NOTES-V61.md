# v61.0.0 — Network Discovery & Topology Synchronization

## Discovery boundary
- Added a transport-agnostic Device Agent discovery endpoint.
- The agent runs `show cdp neighbors` and `show lldp neighbors` only; discovery is read-only.
- Discovery reports are persisted locally with the existing agent state store.

## Core graph
- Added `src/core/network-discovery.js`.
- Parses standard Cisco CDP and LLDP summary output.
- Normalizes interface names such as `Gig 0/24` and `Gi0/24`.
- Deduplicates observations and coalesces reverse observations into a single graph edge.
- Builds a normalized device/relationship graph with known and discovered nodes.

## Topology synchronization
- Added non-destructive reconciliation against the Topology Workbench.
- Existing links become confirmed when independently observed.
- New discovered devices and links are proposed for synchronization.
- Previously discovered links that disappear from a scan are reported as drift.
- Existing topology objects are never deleted automatically by discovery.

## Workspace
- Added Network Discovery to Engineering navigation.
- Device targeting can scan selected devices sequentially.
- Reports show CDP/LLDP counts, observations and timestamps.
- Reconciliation provides a review surface before topology synchronization.

## Validation
- Added parser, graph, agent endpoint, simulated discovery and topology reconciliation coverage.
- Existing Driller Bill test and validation contracts remain intact.
