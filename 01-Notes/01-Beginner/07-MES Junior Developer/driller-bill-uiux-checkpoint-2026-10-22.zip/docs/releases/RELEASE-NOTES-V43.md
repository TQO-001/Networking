# Driller Bill v43 — Local Device Agent

## What changed

- Added a localhost-only Device Agent service under `agent/server.mjs` with a bearer-token boundary.
- Added browser client functions for health, inventory, connect, disconnect, command execution, snapshots and intent application.
- Added a simulated agent transport so the browser-to-agent boundary can be exercised without physical hardware.
- Extended the Devices workspace with agent configuration, connection state, live CLI, quick commands and configuration snapshots.
- Added Apply-through-agent for the existing configuration intents.
- Added agent API documentation and explicit transport status: simulated is enabled; SSH and serial remain pending.
- Exported the agent client through the canonical core index.

## Boundary

The browser does not open SSH/serial sockets or hold device transport credentials. The agent is bound to `127.0.0.1` by default and owns adapter execution.

## Next

Add an SSH transport adapter without changing the browser-facing device protocol, then add serial/console support.
