# Driller Bill v44 — Real SSH transport

## What changed

- Added a Node-only OpenSSH transport adapter under `agent/ssh-device-adapter.mjs`.
- Extended the local Device Agent protocol to `device-agent/2` while keeping the browser API shape stable.
- Added SSH device registration and removal endpoints.
- Added SSH device registration UI to the Devices workspace.
- Added key-based SSH authentication and agent-side password references via environment variables.
- Added host-key verification controls with `accept-new` as the default.
- Added physical-device inventory records alongside simulated workspace devices.
- Added real-device connect, command execution, intent application and configuration snapshot plumbing through the same adapter interface used by the simulator.
- Kept transport-specific Node dependencies outside `src/core` so the browser-safe core type-check remains isolated.

## Boundary

The browser never opens SSH sockets or receives device passwords. The local agent owns the OpenSSH process, connection state, authentication material and transport errors.

## Next

Add configuration history/diffs for physical devices, then serial/console transport and richer device-state discovery.
