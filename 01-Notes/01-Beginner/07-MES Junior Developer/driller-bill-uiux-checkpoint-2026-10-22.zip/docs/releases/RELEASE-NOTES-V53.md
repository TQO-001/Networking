# Driller Bill v53.0.0 — Knowledge Graph

## What changed

- Added a first-class knowledge graph layer connecting technical articles to drills, operational runbooks, engineering cases, typed configuration intents, and network workspaces.
- Added contextual resource actions from every indexed knowledge article.
- Added drill deep-links through the existing Driller Bill module persistence key.
- Added runbook deep-links through a focused runbook selection key.
- Added assessment launches from knowledge cases using the existing domain assessment engine.
- Added graph summary statistics to the Knowledge Base UI.
- Hardened related-article resolution so missing IDs cannot silently resolve to the first article.
- Corrected stale Knowledge Base relationships for IPv4 and SSH.
- Preserved the existing local-first model: knowledge links route into existing workflows rather than duplicating their engines.

## Knowledge workflow

`Concept → Learn → Investigate → Configure → Operate → Verify`

## Verification

- `node --test test/*.test.mjs` — **67/67 tests pass**
- `tsc -p scripts/tsconfig.core.json --noEmit` — **PASS**
- `node scripts/validate.mjs` — **PASS**
- `node scripts/validate-driller-bill.mjs` — **PASS**
- `node scripts/validate-cloud.mjs` — **PASS**
- `node scripts/content-qa.mjs` — **PASS**

The production Vite build was not run because this extracted environment has no installed `node_modules`.
