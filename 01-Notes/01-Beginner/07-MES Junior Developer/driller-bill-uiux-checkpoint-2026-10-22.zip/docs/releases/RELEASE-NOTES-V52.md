# Driller Bill v52.0.0 — Runbooks

## Highlights

- Replaced the Runbooks placeholder with a first-class engineering workspace.
- Added reusable built-in runbooks for access-switch baseline, routed-edge recovery, switch-port standardization and trunk standardization.
- Runbook steps reuse the same typed configuration intents and Device Agent pipeline as the Configuration workspace.
- Added step-level command planning, explicit Apply & Verify actions, observed-state verification and progress tracking.
- Added a local custom-runbook authoring surface. Custom procedures are stored in browser-local storage.
- Runbook execution is intentionally step-gated; there is no unattended Apply All action for live devices.

## Workflow

`Choose procedure → Select target → Connect → Review step → Apply & Verify → Advance → Complete`
