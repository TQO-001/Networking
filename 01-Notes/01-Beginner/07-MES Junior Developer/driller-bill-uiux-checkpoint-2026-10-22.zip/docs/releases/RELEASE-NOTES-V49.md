# v49.0.0 — Engineering workbench expansion

- Added richer device configuration intents: interface descriptions, administrative state, trunk policy, and bulk access VLAN assignment.
- Added the first reusable job-style device scenario: Access Switch Baseline.
- Added structured scenario verification against inspected device state.
- Extended switch inspection to include interface descriptions, switchport VLAN state and trunk allowed VLANs.
- Added a Scenarios tab to the configuration workbench with step progress and command-plan review.
- Preserved preview-before-apply workflow and vendor-neutral intent architecture.
