# Driller Bill v64.0.3 — Windows-safe QA + final font precedence fix

## Fixes

- Repaired Windows path resolution in `test/source-syntax.test.mjs`, `test/ui-accessibility.test.mjs`, and `test/deep-audit-v64.test.mjs` by using Node `fileURLToPath()`.
- Put Google Sans ahead of Jost in the legacy global display-font token.
- Added regression assertions for portable path handling and font precedence.
- Updated package version, backup app metadata, release pointers, design foundation comment, and service-worker cache namespace to `64.0.3`.

## Checks

- `npm run check`: passed (149 app tests, 21 Device Agent tests, 3 cloud tests; validation/typecheck/content checks passed).
- Browser preflight passed and detected Chromium.
- The actual Vite production build and Playwright end-to-end suite remain unverified because this environment cannot resolve `registry.npmjs.org` (`EAI_AGAIN`) to install Vite and the browser dependencies.
