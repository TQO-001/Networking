# Driller Bill v56.0.0 — Network & Device Operations

## What changed

v56 expands the device-operations layer from the existing switching/static-route workflow into a broader Cisco IOS-style engineering surface. The work is exposed through the same typed intent pipeline used by Configuration, Runbooks and Twin Intelligence.

### Routing
- OSPF process/router-ID configuration
- OSPF network advertisement
- Interface-level OSPF process/area and hello/dead timers
- OSPF passive interfaces
- IPv6 unicast routing
- IPv6 static routes

### Security and access control
- Numbered standard ACL rules
- ACL removal
- Interface ACL bindings
- Access-port hardening with port-security, PortFast and BPDU Guard

### Switching operations
- STP mode selection
- Per-VLAN STP priority
- EtherChannel member configuration with LACP/static modes

### Services
- NAT inside/outside roles
- NAT overload
- DHCP address exclusions
- DHCP pools with gateway/DNS settings

### Management
- Hostname
- SSH domain + SSH version 2
- VTY SSH login/transport policy
- Switch default gateway
- Local management-user creation with transient secret handling

### Inspection and Twin integration
Structured simulated-device inspection now exposes the protocol/service state needed for runbook verification. Twin Intelligence understands additional operational request phrases and includes redacted routing, ACL, NAT, DHCP, EtherChannel, STP, IPv6 and running-config context in its model handoff.

Credential-bearing local-user intents execute with the real secret only inside the device-agent path; UI previews/logs use a redacted display command, and reusable runbooks reject stored credential intents.

## Validation

- 92/92 Node tests pass
- 21/21 Device Agent tests pass
- Source validation passes
- Driller Bill module validation passes
- Cloud validation passes
- Content QA passes
- Core TypeScript check passes
- Browser production build not run: extracted environment has no installed `node_modules` / Vite binary
