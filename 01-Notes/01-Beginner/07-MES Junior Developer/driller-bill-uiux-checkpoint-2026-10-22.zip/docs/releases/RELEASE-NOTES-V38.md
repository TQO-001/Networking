# Driller Bill v38.0.0

## Result + Remediation

The drill result screen is now a learning debrief rather than a score-only endpoint.

### Added
- Next-step remediation surface based on the first incomplete objective.
- Outcome state for completed, mostly-complete, and remediation-needed sessions.
- Error-loop summary when the session contains recorded errors.
- Clearer separation between objective state and Twin artifacts.
- Targeted retry entry point.

### Preserved
- Existing CLI engine.
- Twin capture and ZIP export.
- Existing progress storage.
- Mastery engine.
- Network workspace and labs.

### Validation
- 29/29 core tests passing.
- Driller Bill module validation passing.
- General source/content validation passing.
