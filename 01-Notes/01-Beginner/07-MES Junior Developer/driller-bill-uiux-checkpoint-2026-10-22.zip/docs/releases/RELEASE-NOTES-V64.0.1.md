# Driller Bill v64.0.1 — Deep Audit Bugfix

## Fixed
- Google Sans is now the primary UI/display font in both UX layers; legacy Jost fallback removed.
- Raised the remaining 11px brand microcopy to 12px.
- Device Agent tokens are stored in session storage only; the persistent settings record retains the agent URL without credentials.
- PWA service-worker cache bumped from the legacy v34 cache name to v64 so deployments invalidate stale shells.
- PWA manifest and HTML theme color updated to the Driller Bill cyan identity; favicon now points at the current SVG asset.
- Backup metadata app version advanced from 32.0.0 to the current release line.
- Terminal suggestion buttons now explicitly use `type="button"`.

## Audit
- Existing application tests remain unchanged; new regression checks cover each repaired contract.
