# Penny Farthing 28.0.0 — QA Report

## Source / engine validation
- Static source validator: PASS
- Node regression suite: 28 / 28 PASS
- Chromium preflight: PASS (Chromium 144.0.7559.96 detected)
- Sidebar CSS contract: PASS
- Playwright E2E suite: configured but not executed in this environment because npm dependencies are not installed.
- Vite production build: not executed because npm registry resolution is unavailable in this environment.

## Regression coverage
The existing 28 regression tests cover question-bank uniqueness, blueprint constraints, answer randomization, topology traversal, mastery scheduling, scenarios, exhibits, Flow Lab, Packet Lab, Packet Workshop, shared network state, topology synchronization, and custom live links.

## Browser QA coverage configured
`e2e/smoke.spec.js` covers:
- application boot
- sidebar vertical layout and horizontal-overflow protection
- sidebar workspace navigation without exit-button dependence
- full simulation launch
- mobile sidebar open/close behavior
- unexpected browser page errors

Run locally after installing dependencies and Playwright Chromium:

```bash
npm install
npx playwright install chromium
npm run qa:release
```
