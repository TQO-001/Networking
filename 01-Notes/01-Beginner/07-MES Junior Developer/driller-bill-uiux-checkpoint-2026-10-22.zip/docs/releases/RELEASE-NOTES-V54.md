# Driller Bill v54.0.0 — Troubleshooting Workspace

## Product change
Driller Bill now treats troubleshooting as a first-class network-engineering workflow rather than a diagnostics screen.

## What shipped
- Structured troubleshooting case model.
- Four built-in procedures:
  - Interface Down
  - VLAN Missing Across Trunk
  - Missing IPv4 Route
  - OSPF Neighbor Down
- Symptom framing and explicit evidence target.
- Deterministic observation/evidence engine backed by device inspection and diagnostics.
- Ranked hypotheses with evidence-derived confidence.
- Targeted read-only tests.
- Typed remediation planning through the existing configuration-intent engine.
- Runbook handoff for mapped remediation paths.
- Local simulation fault injection and reset support.
- Physical/live device inspection through the existing Device Agent.
- Local custom troubleshooting case authoring.
- Knowledge Graph navigation now opens the actual Troubleshooting workspace.

## Safety model
Troubleshooting never changes a device merely because a hypothesis becomes likely. Remediation is presented as a typed proposed change and follows the existing Preview → Apply → Verify path.
