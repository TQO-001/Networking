# Penny Farthing 32.0.0

## Cloud Sync Foundation

- Optional local-first accounts.
- Express/PostgreSQL API.
- Rotating refresh sessions and short-lived JWT access tokens.
- Versioned JSONB study snapshots.
- Optimistic-concurrency conflict detection.
- Explicit local-to-cloud push and cloud-to-local pull.
- Local conflict recovery backup before remote overwrite/restore.
- Docker Compose deployment stack with PostgreSQL 18.6, API, and Nginx web proxy.
- Cloud validation and API schema tests.
