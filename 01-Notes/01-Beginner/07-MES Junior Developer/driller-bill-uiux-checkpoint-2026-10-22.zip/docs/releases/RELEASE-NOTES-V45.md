# Driller Bill v45.0.0 — Configuration history + diff

## Focus
Turn configuration snapshots into an operational history system that can explain what changed on a device.

## Added
- Local Device Agent configuration history, capped at 50 snapshots per device.
- Snapshot records with source/labels and change summaries.
- Running-configuration diff endpoint between two history records.
- Sensitive credential-value redaction for stored/displayed history snapshots.
- Devices workspace configuration timeline.
- Before/after selector and line-level added/removed diff view.
- Automatic history capture after approved configuration intents.

## Architecture
Configuration history lives in the local Device Agent process. The browser receives metadata and requested diffs rather than managing device configuration persistence itself.
