# Driller Bill v47.0.0 — Device State & Diagnostics

v47 turns structured inspection into an engineering diagnostic surface.

## Highlights

- Device Agent exposes a diagnostics endpoint per device and advertises the operation in its device-agent contract.
- Devices shows interface, VLAN, trunk, and route tables from the latest inspection.
- Diagnostics combine connection state, inspection evidence, configuration history, and startup-vs-running alignment.
- The latest two configuration snapshots are summarized as a compact change view.
- Warning-level inspection observations are surfaced separately from informational facts.

## Architecture

`inspection → diagnostics + history → Devices engineering view`

The diagnostics layer is deterministic and evidence-based. It does not infer operator intent from a raw configuration change.
