# Penny Farthing 30.0.0 — Content QA Release

## Content QA

The release pipeline now validates every static question and authored family for structural correctness, answer indexes, duplicate options, duplicate prompts within families, placeholder content, exhibit normalization, five-variant family coverage, and all 53 current CCNA v1.1 objective numbers.

## Fixed content

`EX18-IP-01` was corrected from three answer choices to four and rewritten so the prompt asks a single, unambiguous routing-table question. v18 exhibit variants now include the exhibit title/concept in their stems, preserving five distinct variants without identical generic wording across unrelated families.
