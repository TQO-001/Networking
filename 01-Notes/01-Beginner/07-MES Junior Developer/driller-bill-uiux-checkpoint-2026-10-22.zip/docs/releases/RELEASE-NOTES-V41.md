# Driller Bill v41.0.0

## Knowledge foundation

This release begins the transition from a CCNA-focused simulator into a broader network engineering workspace.

### Added
- Local-first Knowledge Base
- Search across concepts, commands, tags and article content
- Category filtering
- Structured knowledge articles
- Command reference surfaces
- Related concept navigation
- Engineering workspace placeholders for Devices, Configuration and Runbooks

### Architectural direction
Knowledge entries are structured objects rather than presentation-only Markdown. They can later be referenced by drills, vendor adapters, device configuration intents, verification routines, runbooks and Twin analysis.

The physical-device work deliberately starts after the knowledge and intent layers are established.
