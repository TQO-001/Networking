# Driller Bill v40.0.0 — Twin Intelligence

v40 turns Twin from a session recorder into a deterministic local inference layer.

## What changed

- Added `analyzeTwin()` to detect repeated error categories, theory-linked friction, objective friction, typo signals, unfinished objectives, and repeated rejected commands.
- Added ranked Twin inference with a primary signal, supporting signals, and recommended next moves.
- Added a dedicated **Intelligence** view to the Twin panel.
- Added live Twin inference during practice after errors occur.
- Persisted the latest Twin inference locally alongside the latest Twin session.
- Preserved local-only processing and existing sensitive-value redaction.
- Added automated coverage for Twin inference.
- Kept existing CLI, module engines, question bank, and validation contracts intact.

## Validation

- Core tests: 30/30 passed.
- Driller Bill modules: 22/22 validated.
- Static inventory: 1,935 questions / 387 families.
