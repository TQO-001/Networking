# Penny Farthing 31.0.0 — Data Safety & Offline Resilience

## Added
- Data & Recovery workspace route in the persistent sidebar.
- Portable JSON study backups covering history, seen state, settings, mastery, authoring, live lab, topology and saved session.
- Backup schema validation before restore.
- Service worker for offline shell resilience and cached same-origin assets.
- Online/offline status in the Data & Recovery view.
- Safe import/export flow without uploading study data.

## Reliability
- Backup/restore uses only managed Penny Farthing storage keys.
- Restore rejects unknown schema versions and malformed top-level data.
- Existing data is not globally cleared during restore.
