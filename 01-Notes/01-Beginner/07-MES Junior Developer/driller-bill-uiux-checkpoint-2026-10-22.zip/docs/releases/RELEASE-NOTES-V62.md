# v62.0.0 — UI/UX Polish & Accessibility

Driller Bill’s visual system is refreshed around a cyan primary interaction color, stronger contrast, larger readable controls and consistent workspace hierarchy.

## Accessibility
- Visible keyboard focus rings and skip-to-content navigation.
- 44px minimum interactive targets for buttons and form controls.
- Keyboard-friendly evidence, configuration and device tabs with roving focus.
- Toggle state exposed with `aria-pressed`.
- Reduced-motion and high-contrast media-query support.
- Decorative navigation glyphs hidden from assistive technology.

## UX
- Higher baseline typography and clearer secondary text.
- Stronger panel boundaries and consistent 14px workspace cards.
- Improved mobile stacking and touch spacing.
- Technical terminal areas retain monospaced typography while becoming easier to read.
- Legacy engineering workflows remain functionally unchanged.
