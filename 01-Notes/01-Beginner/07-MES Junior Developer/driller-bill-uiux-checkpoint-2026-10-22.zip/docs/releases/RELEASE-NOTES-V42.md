# Driller Bill v42 — Device Architecture

## What changed

- Added a vendor-aware device model and inventory builder.
- Added a simulated device adapter that uses the existing IOS-style CLI engine through a stable connection boundary.
- Added a device-agent contract covering discovery, connect, disconnect, execute, snapshot and intent application.
- Added configuration intents for Create VLAN, Assign Access VLAN and Set Trunk VLANs.
- Added vendor command planning with validation and explanations.
- Added the Devices workspace as a real engineering surface instead of a placeholder.
- Added a non-destructive intent preview so engineers can see the modelled intent and vendor commands before later execution support is introduced.
- Exported the device architecture through `src/core/index.js`.

## Guardrail

V42 only previews configuration intents in the UI. No physical device connection or mutation is implemented yet. The architecture is intentionally ready for a local device agent with SSH/serial transport in a future release.
