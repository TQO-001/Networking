# Driller Bill v57.0.0 — Serial / Console Device Support

v57 completes the Device Agent transport boundary with a real serial/console adapter alongside the existing simulated and SSH adapters.

## Transport layer

- Added `agent/serial-device-adapter.mjs` behind the existing `device-adapter/1` interface.
- Added local COM/tty connection settings for baud rate, data bits, stop bits, parity and flow control.
- Added serial console handshake, prompt detection, command execution, inspection, snapshots and typed-intent application.
- Added enable-password environment-variable flow without returning the secret to the browser.
- Added serial transport metadata to device inventory and the public connection summary.
- Kept serial handles and credentials entirely inside the local Device Agent.

## Device Agent

- Physical device registration now accepts `ssh` or `serial` transport types.
- Adapter selection is transport-aware while keeping one browser-facing protocol.
- Device Agent contract now reports `simulated`, `ssh`, and `serial` as implemented transports.
- Existing configuration history, inspection, diagnostics, Runbooks, Troubleshooting and Twin workflows continue to operate through the same adapter boundary.

## Devices workspace

- Reworked physical-device registration into a transport selector for SSH or Serial / Console.
- Added serial configuration controls and COM/tty path entry.
- Added serial console badges and transport details to device inventory/overview.
- Updated live CLI copy to identify SSH and serial sessions accurately.

## Dependencies

- Added `serialport` `13.0.0` as the agent's cross-platform serial transport implementation.

## Verification

- `npm test`: 99/99 pass.
- Device Agent tests: 21/21 pass.
- Source validation: PASS.
- Driller Bill validation: PASS.
- Cloud validation: PASS.
- Content QA: PASS.
- Core typecheck: PASS.
- Browser build: not runnable in the extracted workspace because `node_modules`/Vite are not installed; run `npm install` before `npm run build`.
