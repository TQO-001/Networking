# Driller Bill v50.0.0 — Device operations & routed recovery

## Highlights

- Added reviewed IPv4 static-route intents for router devices.
- Added static-route removal intent.
- Expanded operational CLI quick-command palette for diagnostics.
- Added a routed-edge recovery scenario with structured-state verification.
- Added a routing workbench entry point for static-route operations.
- Preserved the intent → preview → apply → verify → snapshot pipeline.
