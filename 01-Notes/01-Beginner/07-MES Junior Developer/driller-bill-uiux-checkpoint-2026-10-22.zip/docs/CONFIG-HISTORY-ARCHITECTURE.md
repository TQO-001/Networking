# Configuration History Architecture

Driller Bill v45 treats device configuration as a sequence of observable states rather than a single text blob.

```text
Device
  │
  ├── capture running/startup config
  │
  ▼
Configuration Snapshot
  │
  ├── source: manual | intent
  ├── timestamp
  ├── redacted running-config
  └── redacted startup-config
          │
          ▼
   Configuration History
          │
          └── compare two states
                    │
                    ▼
             Added / Removed
               change summary
```

The local Device Agent owns the history store and diff operation. The browser requests metadata and pairwise diffs through the agent protocol.

History is capped at 50 records per device. In v46, history is persisted by the executable local agent to its durable state file, while programmatic `createAgentServer()` instances remain non-persistent unless a state file is explicitly supplied.
