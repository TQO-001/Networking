import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import ts from 'typescript';

const root = fileURLToPath(new URL('../', import.meta.url));
const ignoredDirectories = new Set(['.git', 'node_modules', 'dist', 'coverage', 'playwright-report', 'test-results']);
const sourceExtensions = new Set(['.js', '.jsx', '.mjs', '.cjs']);

function collectSourceFiles(directory, output = []) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      if (!ignoredDirectories.has(entry.name)) collectSourceFiles(path.join(directory, entry.name), output);
      continue;
    }
    if (sourceExtensions.has(path.extname(entry.name))) output.push(path.join(directory, entry.name));
  }
  return output;
}

test('all JavaScript/JSX modules parse before the app is bundled', () => {
  const files = collectSourceFiles(root);
  assert.ok(files.length > 0, 'expected JavaScript-family source files to validate');

  const failures = [];
  for (const file of files) {
    const source = fs.readFileSync(file, 'utf8');
    const result = ts.transpileModule(source, {
      fileName: file,
      reportDiagnostics: true,
      compilerOptions: {
        allowJs: true,
        jsx: ts.JsxEmit.ReactJSX,
        target: ts.ScriptTarget.ES2022,
        module: ts.ModuleKind.ESNext,
      },
    });
    for (const diagnostic of result.diagnostics ?? []) {
      if (diagnostic.category !== ts.DiagnosticCategory.Error) continue;
      const location = diagnostic.file && diagnostic.start != null
        ? diagnostic.file.getLineAndCharacterOfPosition(diagnostic.start)
        : null;
      const where = location ? `${location.line + 1}:${location.character + 1}` : 'unknown location';
      failures.push(`${path.relative(root, file)}:${where} ${ts.flattenDiagnosticMessageText(diagnostic.messageText, ' ')}`);
    }
  }

  assert.deepEqual(failures, [], `Source syntax failures:\n${failures.join('\n')}`);
  assert.ok(files.some(file => path.relative(root, file) === path.join('src', 'App.jsx')), 'must include the main application JSX');
});
