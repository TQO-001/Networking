import test from 'node:test';
import assert from 'node:assert/strict';
import { completeCommandPrefix, insertAtSelection, stepCommandHistory } from '../src/terminal/commandInput.js';

test('touch Tab completion uses only explicitly allowed command candidates', () => {
  const commands = ['show ip route', 'show ip interface brief', 'show vlan brief'];
  assert.equal(completeCommandPrefix('show vl', commands), 'show vlan brief');
  assert.equal(completeCommandPrefix('show ip i', commands), 'show ip interface brief');
  assert.equal(completeCommandPrefix('show ip ', commands), 'show ip ');
  assert.equal(completeCommandPrefix('reload', commands), 'reload');
});

test('touch symbol insertion preserves text after the current caret', () => {
  assert.deepEqual(insertAtSelection('show route', 4, 4, '|'), { value: 'show| route', caret: 5 });
  assert.deepEqual(insertAtSelection('abcd', 1, 3, '?'), { value: 'a?d', caret: 2 });
});

test('touch history recalls newest first and restores the unsent draft', () => {
  const history = ['show vlan brief', 'show ip route'];
  const first = stepCommandHistory({ history, index: -1, direction: 'up', draft: '', currentValue: 'show ip ' });
  assert.deepEqual(first, { index: 0, value: 'show vlan brief', draft: 'show ip ' });
  const second = stepCommandHistory({ history, index: first.index, direction: 'up', draft: first.draft, currentValue: first.value });
  assert.deepEqual(second, { index: 1, value: 'show ip route', draft: 'show ip ' });
  const restored = stepCommandHistory({ history, index: second.index, direction: 'down', draft: second.draft, currentValue: second.value });
  assert.deepEqual(restored, { index: 0, value: 'show vlan brief', draft: 'show ip ' });
  const draft = stepCommandHistory({ history, index: 0, direction: 'down', draft: restored.draft, currentValue: restored.value });
  assert.deepEqual(draft, { index: -1, value: 'show ip ', draft: '' });
});

test('device workspace exposes accessible mobile terminal controls and disables mobile keyboard corrections', async () => {
  const { readFileSync } = await import('node:fs');
  const { fileURLToPath } = await import('node:url');
  const { dirname, resolve } = await import('node:path');
  const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
  const source = readFileSync(resolve(root, 'src/Devices.jsx'), 'utf8');
  const styles = readFileSync(resolve(root, 'src/ux-system.css'), 'utf8');
  assert.match(source, /Touch-friendly device command keys/);
  assert.match(source, /handleDeviceTouchKey\('Tab'\)/);
  assert.match(source, /handleDeviceTouchKey\('ArrowUp'\)/);
  assert.match(source, /autoCapitalize="off" autoCorrect="off" autoComplete="off"/);
  assert.match(styles, /@media\s*\(max-width:\s*900px\)\s*\{\.db-cli-key-row\s*\{display:flex\}\}/);
});
