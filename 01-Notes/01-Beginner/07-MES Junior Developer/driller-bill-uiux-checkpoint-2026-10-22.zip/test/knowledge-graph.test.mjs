import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { KNOWLEDGE_ARTICLES } from '../src/knowledge/knowledge-base.js';
import { KNOWLEDGE_RESOURCES, buildKnowledgeGraph, getKnowledgeConnections, knowledgeGraphStats } from '../src/knowledge/knowledge-graph.js';

test('v53 knowledge graph exposes connected resources for every indexed article', () => {
  const graph = buildKnowledgeGraph();
  const stats = knowledgeGraphStats();
  assert.equal(graph.version, '1.0.0');
  assert.equal(stats.articles, KNOWLEDGE_ARTICLES.length);
  assert.ok(stats.resources >= 20);
  assert.ok(stats.edges >= KNOWLEDGE_ARTICLES.length);
  for (const article of KNOWLEDGE_ARTICLES) {
    const connections = getKnowledgeConnections(article.id);
    const count = Object.values(connections).reduce((sum, items) => sum + items.length, 0);
    assert.ok(count >= 1, `${article.id} should have at least one graph connection`);
  }
});

test('v53 graph contains no dangling resource references', () => {
  for (const article of KNOWLEDGE_ARTICLES) {
    const relation = getKnowledgeConnections(article.id);
    for (const resources of Object.values(relation)) {
      for (const resource of resources) assert.ok(KNOWLEDGE_RESOURCES[`${resource.type}:${resource.id}`] || KNOWLEDGE_RESOURCES[resource.id]);
    }
  }
});

test('v53 knowledge base no longer resolves missing related IDs as the first article', () => {
  for (const article of KNOWLEDGE_ARTICLES) {
    for (const relatedId of article.related || []) {
      assert.ok(KNOWLEDGE_ARTICLES.some(item => item.id === relatedId), `${article.id} -> ${relatedId} should resolve to a real article`);
    }
  }
});

test('v53 application wires Knowledge Base actions into navigation and assessment', () => {
  const app = readFileSync(new URL('../src/App.jsx', import.meta.url), 'utf8');
  const kb = readFileSync(new URL('../src/knowledge/KnowledgeBase.jsx', import.meta.url), 'utf8');
  const runbooks = readFileSync(new URL('../src/Runbooks.jsx', import.meta.url), 'utf8');
  assert.match(app, /<KnowledgeBase setView=\{navigateToView\} startAssessment=\{startAssessment\}\/>/);
  assert.match(kb, /DRILL_MODULE_KEY/);
  assert.match(kb, /RUNBOOK_FOCUS_KEY/);
  assert.match(kb, /startAssessment\('domain'/);
  assert.match(runbooks, /RUNBOOK_FOCUS_KEY/);
  assert.match(runbooks, /safeStorage\.getItem\(RUNBOOK_FOCUS_KEY\)/);
});
