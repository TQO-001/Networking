import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync, writeFileSync, mkdtempSync, mkdirSync, rmSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import vm from 'node:vm';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = (file) => readFileSync(resolve(root, file), 'utf8');

test('Docker web builds compile assets without running documentation-dependent unit tests in the image', () => {
  for (const file of ['Dockerfile', 'Dockerfile.cloud-web']) {
    const source = read(file);
    assert.match(source, /npm run build/);
    assert.doesNotMatch(source, /npm run check:web/);
  }
});

test('cloud nginx targets the Compose API service and allows the API payload limit', () => {
  const nginx = read('nginx.cloud.conf');
  assert.match(nginx, /proxy_pass http:\/\/driller-bill-api:8787;/);
  assert.match(nginx, /client_max_body_size 2m;/);
  assert.match(nginx, /proxy_set_header X-Forwarded-For \$remote_addr;/);
});

test('service worker does not intercept same-origin API GET requests', () => {
  const listeners = new Map();
  const context = {
    URL, Response,
    self: { location: { origin: 'https://driller-bill.test' }, addEventListener: (name, fn) => listeners.set(name, fn), skipWaiting: () => Promise.resolve(), clients: { claim: () => Promise.resolve() } },
    caches: { open: () => Promise.resolve({ addAll: () => Promise.resolve(), put: () => Promise.resolve() }), keys: () => Promise.resolve([]), delete: () => Promise.resolve(), match: () => Promise.resolve(undefined) },
    fetch: () => Promise.reject(new Error('fetch should not be called during request interception setup')),
  };
  vm.runInNewContext(read('public/sw.js'), context, { filename: 'public/sw.js' });
  let responded = false;
  listeners.get('fetch')({
    request: { method: 'GET', url: 'https://driller-bill.test/api/v1/me', mode: 'cors' },
    respondWith: () => { responded = true; },
  });
  assert.equal(responded, false, 'API request must bypass Cache Storage and let the browser use the network');
});

test('API middleware marks responses as non-cacheable', () => {
  const source = read('backend/app/main.py');
  assert.match(source, /async def prevent_api_response_caching/);
  assert.match(source, /response\.headers\["Cache-Control"\] = "no-store, no-cache, must-revalidate, private"/);
  assert.match(source, /response\.headers\["Pragma"\] = "no-cache"/);
});

test('Driller Bill practice terminal includes shared toolbar, accessible output and IOS-friendly input attributes', () => {
  const source = read('src/driller-bill/DrillerBillStudio.jsx');
  assert.match(source, /import TerminalToolbar from '\.\.\/terminal\/TerminalToolbar\.jsx'/);
  assert.match(source, /role="log" aria-label="Cisco terminal output" aria-live="off"/);
  assert.match(source, /spellCheck=\{false\} autoCapitalize="off" autoCorrect="off" autoComplete="off"/);
  assert.match(source, /terminal-workbench-expanded/);
  assert.match(source, /const outputRef = useRef\(null\)/);
  assert.match(source, /outputRef\.current\.scrollTop = outputRef\.current\.scrollHeight/);
  assert.match(source, /ref=\{outputRef\} className="db-cli-screen"/);
  assert.doesNotMatch(source, /Tab completes in the core CLI/);
});


test('legacy UI tokens follow the persistent theme token system', () => {
  const css = read('src/ux-system.css');
  for (const [legacy, current] of [
    ['--ux-bg', '--db-bg'], ['--ux-surface', '--db-surface'],
    ['--ux-ink', '--db-ink'], ['--ux-ink-2', '--db-ink-soft'],
    ['--ux-line', '--db-line'], ['--ux-cyan', '--db-cyan'],
    ['--ux-font-ui', '--db-font-ui'], ['--ux-font-mono', '--db-font-mono'],
    ['--bg', '--db-bg'], ['--panel', '--db-surface'], ['--panel2', '--db-surface-soft'],
    ['--text', '--db-ink'], ['--muted', '--db-ink-soft'], ['--muted2', '--db-muted'],
    ['--accent', '--db-cyan-strong'], ['--accent2', '--db-cyan'], ['--accentDim', '--db-cyan-soft'],
  ]) {
    assert.ok(css.includes(`${legacy}:var(${current})`), `${legacy} should map to ${current}`);
  }
  assert.match(css, /html\[data-theme="dark"\]\s*\{/);
});


test('cloud smoke check validates API health through the web endpoint', async () => {
  const { checkCloudHealth } = await import('../scripts/cloud-compose-smoke.mjs');
  let requestedUrl = '';
  const result = await checkCloudHealth({
    baseUrl: 'http://localhost:8080/',
    fetchImpl: async (url, options) => {
      requestedUrl = url;
      assert.equal(options.cache, 'no-store');
      return new Response(JSON.stringify({ status: 'ok', database: 'ok', service: 'driller-bill-api' }), {
        status: 200, headers: { 'Content-Type': 'application/json' },
      });
    },
  });
  assert.equal(requestedUrl, 'http://localhost:8080/api/v1/health');
  assert.equal(result.body.database, 'ok');
  await assert.rejects(() => checkCloudHealth({
    baseUrl: 'http://localhost:8080',
    fetchImpl: async () => new Response(JSON.stringify({ status: 'degraded', database: 'unavailable', service: 'driller-bill-api' }), { status: 200 }),
  }), /API\/database is not healthy/);
});


test('built release metadata is synchronized from package.json version', async () => {
  const { syncDistMetadata } = await import('../scripts/sync-dist-metadata.mjs');
  const dir = mkdtempSync(resolve(tmpdir(), 'driller-bill-meta-'));
  try {
    const distDir = resolve(dir, 'dist');
    mkdirSync(distDir);
    writeFileSync(resolve(distDir, 'health.json'), JSON.stringify({ status: 'ok', service: 'driller-bill', release: '51.0.0', version: '51.0.0', backend: 'fastapi' }));
    writeFileSync(resolve(distDir, 'sw.js'), "const CACHE = 'driller-bill-shell-v64.0.6';\n");
    const result = syncDistMetadata({ distDir, version: '65.1.2' });
    const health = JSON.parse(readFileSync(resolve(distDir, 'health.json'), 'utf8'));
    const serviceWorker = readFileSync(resolve(distDir, 'sw.js'), 'utf8');
    assert.equal(result.release, '65.1.2');
    assert.equal(health.release, '65.1.2');
    assert.equal(health.version, '65.1.2');
    assert.match(serviceWorker, /driller-bill-shell-v65\.1\.2/);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('cloud API release defaults to package metadata and supports an explicit build-arg override', () => {
  const main = read('backend/app/main.py');
  const dockerfile = read('backend/Dockerfile');
  const compose = read('docker-compose.cloud.yml');
  assert.match(main, /def _application_version\(\)/);
  assert.match(main, /Path\("\/app\/package.json"\)/);
  assert.match(dockerfile, /ARG DRILLER_BILL_VERSION=/);
  assert.match(dockerfile, /COPY package\.json \.\/package\.json/);
  assert.ok(compose.includes('DRILLER_BILL_VERSION: ${DRILLER_BILL_VERSION:-}'));
  assert.doesNotMatch(compose, /DRILLER_BILL_VERSION: 34\.0\.0/);
});

test('physical command policy only permits bounded read-only IOS commands', async () => {
  const { isReadOnlyDeviceCommand } = await import('../agent/command-policy.mjs');
  for (const command of ['show version', 'show vlan brief', 'ping 10.0.0.1', 'traceroute 10.0.0.1', 'terminal length 0', 'terminal length 512']) {
    assert.equal(isReadOnlyDeviceCommand(command), true, `${command} should be read-only`);
  }
  for (const command of ['reload', 'write erase', 'delete flash:', 'configure terminal', 'show version; reload', 'show version | include IOS', 'terminal length 999', 'ping 10.0.0.1\nreload']) {
    assert.equal(isReadOnlyDeviceCommand(command), false, `${command} should be rejected`);
  }
});


test('device agent defaults use a dedicated port and include documented local origins', async () => {
  const { createAgentServer, DEFAULT_AGENT_PORT } = await import('../agent/server.mjs');
  const instance = createAgentServer({ token: 'test-token' });
  assert.equal(DEFAULT_AGENT_PORT, 8788);
  assert.equal(instance.port, 8788);
  for (const origin of [
    'http://localhost:5173', 'http://127.0.0.1:5173',
    'http://localhost:4173', 'http://127.0.0.1:4173',
    'http://localhost:8080', 'http://127.0.0.1:8080',
  ]) assert.ok(instance.allowedOrigins.includes(origin), `Missing default origin ${origin}`);
});


test('release checker validates version pointers dynamically from package.json', async () => {
  const { checkReleaseMetadata } = await import('../scripts/release-check.mjs');
  const fixture = mkdtempSync(resolve(tmpdir(), 'driller-release-check-'));
  const put = (file, content) => {
    const path = resolve(fixture, file);
    mkdirSync(dirname(path), { recursive: true });
    writeFileSync(path, content);
  };
  try {
    put('package.json', JSON.stringify({ version: '1.2.3' }));
    put('public/health.json', JSON.stringify({ release: '1.2.3', version: '1.2.3' }));
    put('public/sw.js', "const CACHE = 'driller-bill-shell-v1.2.3';");
    put('src/core/data-safety.js', "export const APP_DATA_VERSION = '1.2.3';");
    put('README.md', 'Current release: **v1.2.3 — Test**');
    put('RELEASE-NOTES.md', 'Current release: **v1.2.3 — Test**');
    put('CHANGELOG.md', '## v1.2.3 — Test\n');
    put('docs/releases/RELEASE-NOTES-V1.2.3.md', '# Test release');
    assert.equal(checkReleaseMetadata({ rootDir: fixture }).version, '1.2.3');
    put('public/health.json', JSON.stringify({ release: '1.2.2', version: '1.2.3' }));
    assert.throws(() => checkReleaseMetadata({ rootDir: fixture }), /public\/health\.json release/);
  } finally {
    rmSync(fixture, { recursive: true, force: true });
  }
});

test('PWA manifest has separate 192, standard 512 and maskable icons with scope identity', () => {
  const manifest = JSON.parse(read('public/manifest.webmanifest'));
  assert.equal(manifest.id, '/');
  assert.equal(manifest.scope, '/');
  assert.match(manifest.name, /Network Engineering Workspace/);
  assert.ok(manifest.icons.some(icon => icon.sizes === '192x192' && icon.purpose === 'any'));
  assert.ok(manifest.icons.some(icon => icon.sizes === '512x512' && icon.purpose === 'any'));
  assert.ok(manifest.icons.some(icon => icon.sizes === '512x512' && icon.purpose === 'maskable'));
  for (const icon of manifest.icons) assert.ok(existsSync(resolve(root, `public${icon.src}`)), `missing ${icon.src}`);
  assert.match(read('index.html'), /Network Engineering Workspace/);
});

test('nginx enables gzip and avoids immutable caching for service-worker and manifest', () => {
  for (const file of ['nginx.conf', 'nginx.cloud.conf']) {
    const source = read(file);
    assert.match(source, /gzip on;/);
    assert.match(source, /gzip_types[^;]*application\/javascript[^;]*application\/json/);
    assert.match(source, /location = \/sw\.js\s*\{[^}]*expires -1;/s);
    assert.match(source, /location = \/manifest\.webmanifest\s*\{[^}]*expires -1;/s);
  }
});

test('Cloud Sync explains the 413 size limit without implying local data was uploaded or lost', () => {
  const sync = read('src/cloud/CloudSync.jsx');
  assert.match(sync, /error\?\.status === 413/);
  assert.match(sync, /cloud sync limit \(2 MB\)/);
  assert.match(sync, /Your local data remains on this device/);
});

test('duplicate API Dockerfile and generated Python bytecode are excluded from the source workflow', () => {
  assert.equal(existsSync(resolve(root, 'Dockerfile.api')), false);
  const ignore = read('.gitignore');
  assert.match(ignore, /__pycache__\//);
  assert.match(ignore, /\*\.py\[cod\]/);
  assert.doesNotMatch(read('scripts/validate-cloud.mjs'), /Dockerfile\.api/);
  assert.match(read('docker-compose.cloud.yml'), /backend\/Dockerfile/);
});

test('Driller Bill CLI wires IOS completion, inline help and terminal control shortcuts', () => {
  const studio = read('src/driller-bill/DrillerBillStudio.jsx');
  const shell = read('src/driller-bill/legacy/engine/shell.ts');
  assert.match(studio, /completeIosCommand, iosHelpCandidates/);
  assert.match(studio, /event\.key === '\?'/);
  assert.match(studio, /event\.key === 'Tab'/);
  assert.match(studio, /event\.ctrlKey && event\.key\.toLowerCase\(\) === 'c'/);
  assert.match(studio, /event\.ctrlKey && event\.key\.toLowerCase\(\) === 'z'/);
  assert.match(studio, /event\.ctrlKey && event\.key\.toLowerCase\(\) === 'l'/);
  assert.match(studio, /Touch-friendly IOS terminal keys/);
  assert.match(studio, /Score = accuracy × 0\.40 \+ objectives × 0\.30 \+ speed × 0\.30/);
  assert.match(shell, /export function iosHelpCandidates/);
  assert.doesNotMatch(studio, /Tab completes in the core CLI/);
});
