import test from 'node:test';
import assert from 'node:assert/strict';
import { buildDiscoveryGraph, buildNetworkDiscoveryReport, mergeNeighborObservations, parseCdpNeighbors, parseLldpNeighbors, reconcileDiscoveryTopology } from '../src/core/network-discovery.js';
import { freshNetwork } from '../src/core/network-model.js';
import { createAgentServer } from '../agent/server.mjs';
import { demoTopology } from '../src/core/topology-engine.js';

async function jsonFetch(base, path, options = {}) {
  const response = await fetch(`${base}${path}`, {
    ...options,
    headers: { Accept: 'application/json', Authorization: 'Bearer test-token', ...(options.body ? { 'Content-Type': 'application/json' } : {}) },
  });
  const payload = await response.json();
  return { response, payload };
}

test('v61 parses standard Cisco CDP summary output', () => {
  const rows = parseCdpNeighbors(`Device ID        Local Intrfce     Holdtme    Capability   Platform    Port ID\nSW2              Gig 0/24          120        S I          C9200       Gi0/24`);
  assert.equal(rows.length, 1);
  assert.deepEqual(rows[0], {
    protocol: 'cdp', remoteName: 'SW2', localInterface: 'Gi0/24', remoteInterface: 'Gi0/24', holdTime: 120, capability: 'S I', platform: 'C9200',
  });
});

test('v61 parses standard Cisco LLDP summary output', () => {
  const rows = parseLldpNeighbors(`Device ID        Local Intf      Hold-time   Capability  Port ID\nR2               Gi0/1           120         Router      Gi0/0`);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].protocol, 'lldp');
  assert.equal(rows[0].localInterface, 'Gi0/1');
  assert.equal(rows[0].remoteInterface, 'Gi0/0');
  assert.equal(rows[0].capability, 'Router');
});

test('v61 merges duplicate CDP and LLDP observations into one relationship', () => {
  const cdp = [{ protocol:'cdp', localDeviceId:'SW1', remoteName:'SW2', localInterface:'Gi0/24', remoteInterface:'Gi0/24' }];
  const lldp = [{ protocol:'lldp', localDeviceId:'SW1', remoteName:'SW2', localInterface:'Gi0/24', remoteInterface:'Gi0/24' }];
  const merged = mergeNeighborObservations(cdp, lldp);
  assert.equal(merged.length, 1);
  const graph = buildDiscoveryGraph([
    buildNetworkDiscoveryReport({ device:{ id:'SW1', name:'SW1', kind:'switch' }, outputs:{ 'show cdp neighbors':'Device ID        Local Intrfce     Holdtme    Capability   Platform    Port ID\nSW2              Gig 0/24          120        S I          C9200       Gi0/24', 'show lldp neighbors':'Device ID        Local Intf      Hold-time   Capability  Port ID\nSW2              Gi0/24           120         Bridge      Gi0/24' } }),
  ], [{ id:'SW1', name:'SW1', kind:'switch' }, { id:'SW2', name:'SW2', kind:'switch' }]);
  assert.equal(graph.edges.length, 1);
});

test('v61 simulated Device Agent exposes a read-only discovery report', async () => {
  const instance = createAgentServer({ host:'127.0.0.1', port:0, token:'test-token' });
  await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
  try {
    const base = `http://127.0.0.1:${instance.server.address().port}`;
    await jsonFetch(base, '/api/v1/devices/SW1/connect', { method:'POST' });
    const result = await jsonFetch(base, '/api/v1/devices/SW1/discover', { method:'POST', body:'{}' });
    assert.equal(result.response.status, 200);
    assert.equal(result.payload.report.version, '1.0.0');
    assert.ok(result.payload.report.counts.unique >= 2);
    assert.ok(result.payload.report.observations.some(item => item.remoteName === 'SW2'));
    const saved = await jsonFetch(base, '/api/v1/devices/SW1/discovery');
    assert.equal(saved.response.status, 200);
    assert.equal(saved.payload.report.deviceId, 'SW1');
  } finally {
    await new Promise(resolve => instance.server.close(resolve));
  }
});


test('v61 latest discovery report survives Device Agent restart', async () => {
  const { mkdtemp, rm } = await import('node:fs/promises');
  const { tmpdir } = await import('node:os');
  const { join } = await import('node:path');
  const root = await mkdtemp(join(tmpdir(), 'driller-bill-agent-discovery-'));
  const stateFile = join(root, 'agent-state.json');
  const start = async () => {
    const instance = createAgentServer({ host:'127.0.0.1', port:0, token:'test-token', stateFile });
    await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
    return instance;
  };
  let first;
  try {
    first = await start();
    const base = `http://127.0.0.1:${first.server.address().port}`;
    await jsonFetch(base, '/api/v1/devices/SW1/connect', { method:'POST' });
    await jsonFetch(base, '/api/v1/devices/SW1/discover', { method:'POST', body:'{}' });
    await new Promise(resolve => first.server.close(resolve));
    const second = await start();
    try {
      const base2 = `http://127.0.0.1:${second.server.address().port}`;
      const saved = await jsonFetch(base2, '/api/v1/devices/SW1/discovery');
      assert.equal(saved.response.status, 200);
      assert.equal(saved.payload.report.deviceId, 'SW1');
      assert.ok(saved.payload.report.counts.unique >= 2);
    } finally {
      await new Promise(resolve => second.server.close(resolve));
    }
  } finally {
    try { if (first?.server?.listening) await new Promise(resolve => first.server.close(resolve)); } catch {}
    await rm(root, { recursive:true, force:true });
  }
});

test('v61 discovery graph contains the simulated routed and switched device relationships', async () => {
  const instance = createAgentServer({ host:'127.0.0.1', port:0, token:'test-token' });
  await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
  try {
    const base = `http://127.0.0.1:${instance.server.address().port}`;
    const reports = [];
    for (const id of ['R1','SW1','SW2','R2']) {
      await jsonFetch(base, `/api/v1/devices/${id}/connect`, { method:'POST' });
      const result = await jsonFetch(base, `/api/v1/devices/${id}/discover`, { method:'POST', body:'{}' });
      reports.push(result.payload.report);
    }
    const graph = buildDiscoveryGraph(reports, ['R1','R2','SW1','SW2'].map(id => ({ id, name:id, kind:id.startsWith('SW') ? 'switch' : 'router' })));
    assert.equal(graph.nodes.length, 4);
    assert.equal(graph.edges.length, 4);
  } finally {
    await new Promise(resolve => instance.server.close(resolve));
  }
});

test('v61 topology reconciliation adds discovered devices and links without deleting existing design', () => {
  const topology = demoTopology();
  topology.devices = topology.devices.filter(device => device.name !== 'R2');
  topology.links = topology.links.filter(link => !['R2'].includes(topology.devices.find(device => device.id === link.a)?.name || '') && !['R2'].includes(topology.devices.find(device => device.id === link.b)?.name || ''));
  const run = {
    reports: [
      { deviceId:'R1', deviceName:'R1', observations:[{ localDeviceId:'R1', localInterface:'Gi0/1', remoteName:'R2', remoteInterface:'Gi0/0', protocol:'cdp' }] },
      { deviceId:'R2', deviceName:'R2', observations:[{ localDeviceId:'R2', localInterface:'Gi0/0', remoteName:'R1', remoteInterface:'Gi0/1', protocol:'lldp' }] },
    ],
  };
  const result = reconcileDiscoveryTopology(topology, run, { inventory:[{ id:'R1', name:'R1', kind:'router' }, { id:'R2', name:'R2', kind:'router' }] });
  assert.ok(result.changes.addedDevices.includes('R2'));
  assert.equal(result.changes.addedLinks.length, 1);
  assert.ok(result.topology.devices.some(device => device.name === 'R2'));
  assert.ok(result.topology.links.some(link => link.discovered));
});

test('v61 application exposes Network Discovery in engineering navigation', async () => {
  const { readFile } = await import('node:fs/promises');
  const app = await readFile(new URL('../src/App.jsx', import.meta.url), 'utf8');
  const nav = await readFile(new URL('../src/NavigationSidebar.jsx', import.meta.url), 'utf8');
  assert.match(app, /const NetworkDiscovery = lazy\(\(\) => import\(['"]\.\/NetworkDiscovery\.jsx['"]\)\);/);
  assert.match(app, /view==='discovery'/);
  assert.match(nav, /\['discovery', 'Network discovery'/);
});

test('v61 discovery core is exported through the shared barrel', async () => {
  const core = await import('../src/core/index.js');
  assert.equal(typeof core.parseCdpNeighbors, 'function');
  assert.equal(typeof core.buildDiscoveryGraph, 'function');
  assert.equal(typeof core.reconcileDiscoveryTopology, 'function');
});
