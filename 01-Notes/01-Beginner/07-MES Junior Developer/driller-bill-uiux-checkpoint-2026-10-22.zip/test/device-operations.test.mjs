import test from 'node:test';
import assert from 'node:assert/strict';
import { CONFIG_INTENTS, buildDeviceInventory, planIntent, validateIntent } from '../src/core/device-model.js';
import { executeCommand, freshLab, normalizeLabState } from '../src/core/cli-engine.js';
import { inspectSimulatedDevice } from '../src/core/device-inspection.js';
import { verifyRunbookStep } from '../src/core/runbooks.js';
import { readFileSync } from 'node:fs';

function apply(state, device, commands) {
  let current = state;
  for (const command of commands) {
    const currentDevice = current.devices?.[device];
    if (command === 'enable' && currentDevice?.mode === 'exec') continue;
    const result = executeCommand(current, device, command);
    assert.ok(result?.state, `command did not return state: ${command}`);
    if (result.output) assert.doesNotMatch(Array.isArray(result.output) ? result.output.join('\n') : String(result.output), /Invalid|Incomplete/i, command);
    current = result.state;
  }
  return current;
}

test('v56 exposes the expanded 32-intent operations catalog', () => {
  assert.equal(CONFIG_INTENTS.length, 32);
  assert.equal(new Set(CONFIG_INTENTS.map(item => item.id)).size, CONFIG_INTENTS.length);
  for (const intent of CONFIG_INTENTS) assert.ok(intent.title && intent.category && Array.isArray(intent.fields), intent.id);
});

test('v56 router operations apply and are visible to structured inspection', () => {
  let state = freshLab();
  const router = buildDeviceInventory(state).find(item => item.id === 'R1');
  const intents = [
    { type: 'configure-ospf-process', fields: { process: 10, routerId: '10.10.10.10' } },
    { type: 'add-ospf-network', fields: { process: 10, network: '10.0.12.0', wildcard: '0.0.0.3', area: 0 } },
    { type: 'configure-ospf-interface', fields: { interface: 'Gi0/1', process: 10, area: 0, hello: 5, dead: 20 } },
    { type: 'set-ospf-passive-interface', fields: { process: 10, interface: 'Gi0/0' } },
    { type: 'set-interface-nat-role', fields: { interface: 'Gi0/0', role: 'inside' } },
    { type: 'add-standard-acl-rule', fields: { id: 10, action: 'permit', source: '10.10.10.0', wildcard: '0.0.0.255' } },
    { type: 'apply-standard-acl', fields: { id: 10, interface: 'Gi0/0', direction: 'in' } },
    { type: 'enable-ipv6-routing', fields: {} },
    { type: 'add-static-ipv6-route', fields: { prefix: '2001:db8:20::/64', nextHop: '2001:db8:12::2' } },
    { type: 'set-hostname', fields: { hostname: 'EDGE-R1' } },
    { type: 'configure-ssh', fields: { domain: 'laughtale.local' } },
    { type: 'configure-vty-ssh', fields: {} },
  ];
  for (const intent of intents) {
    const plan = planIntent(intent, router);
    assert.equal(plan.valid, true, `${intent.type}: ${plan.errors.join(' ')}`);
    state = apply(state, 'R1', plan.commands);
  }
  const normalizedForConfig = normalizeLabState(state);
  const report = inspectSimulatedDevice(normalizedForConfig, 'R1');
  assert.equal(report.overview.hostname, 'EDGE-R1');
  assert.equal(report.ospf.process, 10);
  assert.equal(report.ospf.routerId, '10.10.10.10');
  assert.deepEqual(report.ospf.networks, ['10.0.12.0 0.0.0.3 area 0']);
  const uplink = report.interfaces.find(item => item.name === 'GigabitEthernet0/1');
  const inside = report.interfaces.find(item => item.name === 'GigabitEthernet0/0');
  assert.equal(uplink.ospfProcess, 10);
  assert.equal(uplink.ospfArea, 0);
  assert.equal(uplink.ospfHello, 5);
  assert.equal(uplink.ospfDead, 20);
  assert.equal(inside.natRole, 'inside');
  assert.equal(inside.aclBindings.in, '10');
  assert.equal(report.ipv6.forwarding, true);
  assert.deepEqual(report.ipv6.routes[0], { type: 'S', prefix: '2001:db8:20::/64', next: '2001:db8:12::2' });
  const routerConfig = String(executeCommand(normalizedForConfig, 'R1', 'show running-config').output || '');
  assert.match(routerConfig, /ip domain name laughtale\.local/);
  assert.match(routerConfig, /transport input ssh/);
});

test('v56 switch security, STP and EtherChannel operations apply correctly', () => {
  let state = freshLab();
  const sw = buildDeviceInventory(state).find(item => item.id === 'SW1');
  const intents = [
    { type: 'harden-access-port', fields: { interface: 'Gi0/1', maximum: 2 } },
    { type: 'set-stp-mode', fields: { mode: 'rapid-pvst' } },
    { type: 'set-stp-vlan-priority', fields: { vlan: 10, priority: 24576 } },
    { type: 'configure-etherchannel', fields: { interfaces: 'Gi0/21,Gi0/22', group: 7, mode: 'active' } },
    { type: 'set-default-gateway', fields: { gateway: '10.10.10.254' } },
  ];
  for (const intent of intents) {
    const plan = planIntent(intent, sw);
    assert.equal(plan.valid, true, `${intent.type}: ${plan.errors.join(' ')}`);
    state = apply(state, 'SW1', plan.commands);
  }
  const report = inspectSimulatedDevice(normalizeLabState(state), 'SW1');
  const access = report.interfaces.find(item => item.name === 'GigabitEthernet0/1');
  const memberA = report.interfaces.find(item => item.name === 'GigabitEthernet0/21');
  const memberB = report.interfaces.find(item => item.name === 'GigabitEthernet0/22');
  assert.equal(access.portSecurity.enabled, true);
  assert.equal(access.portSecurity.maximum, 2);
  assert.equal(access.portfast, true);
  assert.equal(access.bpduguard, true);
  assert.equal(memberA.channelGroup, 7);
  assert.equal(memberA.channelMode, 'active');
  assert.equal(memberB.channelGroup, 7);
  assert.equal(report.overview.stpMode, 'rapid-pvst');
  assert.equal(report.overview.defaultGateway, '10.10.10.254');
  assert.equal(report.stp.vlanPriorities[10], 24576);
  const switchConfig = String(executeCommand(normalizeLabState(state), 'SW1', 'show running-config').output || '');
  assert.match(switchConfig, /channel-group 7 mode active/);
});

test('v56 DHCP and NAT service operations persist their modeled state', () => {
  let state = freshLab();
  const router = buildDeviceInventory(state).find(item => item.id === 'R1');
  const intents = [
    { type: 'add-standard-acl-rule', fields: { id: 20, action: 'permit', source: '10.20.20.0', wildcard: '0.0.0.255' } },
    { type: 'set-interface-nat-role', fields: { interface: 'Gi0/0', role: 'inside' } },
    { type: 'set-interface-nat-role', fields: { interface: 'Gi0/1', role: 'outside' } },
    { type: 'configure-nat-overload', fields: { acl: 20, interface: 'Gi0/1' } },
    { type: 'exclude-dhcp-address', fields: { start: '10.20.20.1', end: '10.20.20.20' } },
    { type: 'create-dhcp-pool', fields: { name: 'USERS', network: '10.20.20.0', mask: '255.255.255.0', gateway: '10.20.20.1', dns: '10.10.10.53' } },
  ];
  for (const intent of intents) {
    const plan = planIntent(intent, router);
    assert.equal(plan.valid, true, `${intent.type}: ${plan.errors.join(' ')}`);
    state = apply(state, 'R1', plan.commands);
  }
  const normalized = normalizeLabState(state);
  const report = inspectSimulatedDevice(normalized, 'R1');
  assert.equal(report.nat.inside.includes('GigabitEthernet0/0'), true);
  assert.equal(report.nat.outside.includes('GigabitEthernet0/1'), true);
  assert.equal(report.nat.overload.some(item => item.acl === '20'), true);
  assert.equal(report.dhcpExcluded[0], '10.20.20.1 10.20.20.20');
  assert.equal(report.dhcpPools.USERS.defaultRouter, '10.20.20.1');
  const serviceConfig = String(executeCommand(normalizeLabState(state), 'R1', 'show running-config').output || '');
  assert.match(serviceConfig, /ip nat inside source list 20 interface GigabitEthernet0\/1 overload/);
});

test('v56 sensitive local-user commands are redacted for display but preserved for execution', () => {
  const router = buildDeviceInventory(freshLab()).find(item => item.id === 'R1');
  const plan = planIntent({ type: 'create-local-user', fields: { username: 'operator', privilege: 15, secret: 'SuperSecret123!' } }, router);
  assert.equal(plan.valid, true);
  assert.match(plan.commands.join('\n'), /SuperSecret123!/);
  assert.doesNotMatch(plan.displayCommands.join('\n'), /SuperSecret123!/);
  assert.match(plan.displayCommands.join('\n'), /secret \*\*\*\*\*\*\*\*/);
});

test('v56 operational inspection exposes structured fields needed by runbook verification', () => {
  const report = inspectSimulatedDevice(normalizeLabState(freshLab()), 'SW1');
  const row = report.interfaces.find(item => item.name === 'GigabitEthernet0/1');
  assert.equal('portSecurity' in row, true);
  assert.equal('aclBindings' in row, true);
  assert.equal('channelGroup' in row, true);
  assert.equal('natRole' in row, true);
  assert.equal('ospfProcess' in row, true);
  const step = { verify: { type: 'access-hardening', interface: 'Gi0/1', maximum: 2 } };
  assert.equal(verifyRunbookStep(step, { inspection: { ...report, interfaces: [{ ...row, portSecurity: { enabled: true, maximum: 2 }, portfast: true, bpduguard: true }] } }).completed, true);
});

test('v56 configuration workbench exposes the operations categories', () => {
  const component = readFileSync(new URL('../src/DeviceConfigurationWorkbench.jsx', import.meta.url), 'utf8');
  const css = readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
  for (const label of ['Security', 'Services', 'Management']) assert.match(component, new RegExp(`>${label}<`));
  assert.match(component, /device-operation-grid/);
  assert.match(css, /\.device-operation-card\{/);
});
