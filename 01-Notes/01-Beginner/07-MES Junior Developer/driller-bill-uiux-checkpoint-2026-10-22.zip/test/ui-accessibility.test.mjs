import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const app = fs.readFileSync(path.join(root, 'src/App.jsx'), 'utf8');
const nav = fs.readFileSync(path.join(root, 'src/NavigationSidebar.jsx'), 'utf8');
const config = fs.readFileSync(path.join(root, 'src/DeviceConfigurationWorkbench.jsx'), 'utf8');
const lab = fs.readFileSync(path.join(root, 'src/StatefulLab.jsx'), 'utf8');
const css = fs.readFileSync(path.join(root, 'src/styles.css'), 'utf8');
const ux = fs.readFileSync(path.join(root, 'src/ux-foundation.css'), 'utf8');
const uxSystem = fs.readFileSync(path.join(root, 'src/ux-system.css'), 'utf8');
const main = fs.readFileSync(path.join(root, 'src/main.jsx'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

test('v63 design foundation eliminates micro-typography', () => {
  const combined = `${css}\n${ux}`;
  assert.doesNotMatch(combined, /font-size\s*:\s*[0-9](?:\.[0-9]+)?px/);
  assert.doesNotMatch(combined, /font\s*:[^;{}]*\s[0-9](?:\.[0-9]+)?px(?:\/|\s|;)/);
  assert.match(ux, /body,#root[\s\S]*font-size:16px/);
  assert.match(ux, /p8-terminal[^\{]*\{[\s\S]*font:16px\/1\.72/);
});

test('v63 UI uses the cyan primary interaction system', () => {
  assert.match(css, /--accent:#59D9FF/);
  assert.match(css, /--accent2:#A6EEFF/);
  assert.doesNotMatch(css, /--accent:#F96E15/);
});

test('v63 keyboard focus and reduced-motion contracts are present', () => {
  assert.match(css, /:focus-visible/);
  assert.match(css, /prefers-reduced-motion/);
  assert.match(css, /prefers-contrast: more/);
  assert.match(css, /\.skip-link/);
  assert.match(app, /href="#main-content"/);
});

test('v63 primary interactive targets remain touch-friendly', () => {
  assert.match(css, /button\{min-width:44px;min-height:44px/);
  assert.match(css, /input,select,textarea\{min-height:44px/);
});

test('v63 workspace tabs expose selection and roving focus', () => {
  const tabs = [app, config, lab].flatMap(source => source.match(/role="tab"[\s\S]{0,220}?aria-selected=[^\s>]+[\s\S]{0,220}?tabIndex=/g) || []);
  assert.ok(tabs.length >= 8, `expected accessible tab controls, found ${tabs.length}`);
});

test('v63 navigation glyphs are decorative to assistive technology', () => {
  assert.match(nav, /className="pf-nav-glyph"[\s\S]{0,100}<NavIcon id=\{id\} \/>/);
  assert.match(nav, /aria-hidden="true" focusable="false"/);
});

test('v63 dashboard state toggles expose pressed state', () => {
  assert.match(app, /aria-pressed=\{adaptive\}/);
  assert.match(app, /aria-pressed=\{coldStart\}/);
});


test('v64 typography uses Google Sans and Google Sans Code', () => {
  assert.equal(pkg.dependencies['@fontsource/google-sans'], '5.3.1');
  assert.equal(pkg.dependencies['@fontsource/google-sans-code'], '5.3.1');
  assert.match(main, /@fontsource\/google-sans\/latin-400\.css/);
  assert.match(main, /@fontsource\/google-sans-code\/latin-400\.css/);
  assert.match(uxSystem, /--db-font-ui:"Google Sans"/);
  assert.match(uxSystem, /--db-font-mono:"Google Sans Code"/);
  assert.match(css, /--font-display:"Google Sans"/);
  assert.doesNotMatch(css, /--font-display:"Jost"/);
});

test('v64 light and dark themes are tokenized and persistent', () => {
  assert.match(app, /const \[theme,setTheme\]=useState/);
  assert.match(app, /document\.documentElement\.dataset\.theme=theme/);
  assert.match(app, /setTheme\(t=>t==='dark'\?'light':'dark'\)/);
  assert.match(app, /aria-pressed=\{dark\}/);
  assert.match(uxSystem, /html\[data-theme="dark"\]/);
  assert.match(uxSystem, /--db-bg:#12191d/);
});

test('v64 application shell uses the shared theme control and search affordance', () => {
  assert.match(app, /className="theme-toggle"/);
  assert.match(app, /className="header-search"/);
  assert.match(uxSystem, /\.header-search\{/);
  assert.match(uxSystem, /\.theme-toggle\{/);
});
