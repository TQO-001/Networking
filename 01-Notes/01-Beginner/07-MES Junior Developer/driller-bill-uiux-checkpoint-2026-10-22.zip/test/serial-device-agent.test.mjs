import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { createSerialDeviceAdapter, serialConnectionSummary, validateSerialConnection } from '../agent/serial-device-adapter.mjs';
import { validateDeviceConnection, deviceAgentContract, planIntent, buildDeviceInventory } from '../src/core/device-model.js';
import { freshLab } from '../src/core/cli-engine.js';

class FakeSerialPort extends EventEmitter {
  constructor(options) {
    super();
    this.options = options;
    this.isOpen = false;
  }
  open(callback) {
    this.isOpen = true;
    queueMicrotask(() => callback?.());
  }
  write(value, callback) {
    const command = Buffer.from(value).toString('utf8').replace(/[\r\n]+$/, '');
    const output = command === 'show version'
      ? 'Cisco IOS Software, Version 15.2(4)M6, RELEASE SOFTWARE\r\nR1#'
      : `Command output for ${command}\r\nR1#`;
    setImmediate(() => {
      this.emit('data', Buffer.from(output));
      callback?.();
    });
  }
  drain(callback) { queueMicrotask(() => callback?.()); }
  close(callback) {
    this.isOpen = false;
    queueMicrotask(() => {
      this.emit('close');
      callback?.();
    });
  }
}

const fakeFactory = options => new FakeSerialPort(options);

test('v57 serial validation accepts a standard Cisco console configuration', () => {
  const result = validateSerialConnection({ serialPort: '/dev/ttyUSB0', baudRate: 9600, dataBits: 8, stopBits: 1, parity: 'none', flowControl: 'none' });
  assert.equal(result.valid, true);
  assert.deepEqual(serialConnectionSummary({ serialPort: '/dev/ttyUSB0' }), { port: '/dev/ttyUSB0', baudRate: 9600, dataBits: 8, stopBits: 1, parity: 'none', flowControl: 'none' });
});

test('v57 serial validation rejects unsupported transport settings', () => {
  const result = validateSerialConnection({ serialPort: 'COM3', baudRate: 12345, dataBits: 9, stopBits: 3, parity: 'mark', flowControl: 'invalid' });
  assert.equal(result.valid, false);
  assert.ok(result.errors.length >= 4);
});

test('v57 physical device validation accepts serial without SSH credentials', () => {
  const result = validateDeviceConnection({ id: 'CON1', name: 'CON1', connectionType: 'serial', serialPort: '/dev/ttyUSB0', baudRate: 9600, dataBits: 8, stopBits: 1, parity: 'none', flowControl: 'none' });
  assert.equal(result.valid, true, result.errors.join(' '));
});

test('v57 contract implements all three transports', () => {
  const contract = deviceAgentContract();
  assert.deepEqual(contract.transports, ['simulated', 'ssh', 'serial']);
});

test('v57 serial adapter performs a console handshake and command execution', async () => {
  const adapter = createSerialDeviceAdapter({ id: 'CON1', name: 'CON1', hostname: 'R1', kind: 'router', serialPort: 'COM3', baudRate: 9600, dataBits: 8, stopBits: 1, parity: 'none', flowControl: 'none', assumePrivileged: true }, { serialPortFactory: fakeFactory });
  const connected = await adapter.connect();
  assert.equal(connected.connected, true);
  assert.equal(connected.device.connection.type, 'serial');
  assert.equal(connected.device.connection.serial.baudRate, 9600);
  assert.equal(connected.device.version, '15.2(4)M6');
  const command = await adapter.execute('show interfaces status');
  assert.equal(command.command, 'show interfaces status');
  assert.match(command.output.join('\n'), /Command output for show interfaces status/);
  await adapter.disconnect();
  assert.equal(adapter.isConnected(), false);
});

test('v57 serial adapter applies a typed intent through the same command boundary', async () => {
  const connection = { id: 'CON1', name: 'CON1', hostname: 'SW1', kind: 'switch', serialPort: 'COM3', assumePrivileged: true };
  const adapter = createSerialDeviceAdapter(connection, { serialPortFactory: fakeFactory });
  await adapter.connect();
  const device = buildDeviceInventory(freshLab()).find(item => item.id === 'SW1');
  const intent = { type: 'create-vlan', fields: { id: 30, name: 'ENGINEERING' } };
  const plan = planIntent(intent, device);
  assert.equal(plan.valid, true);
  const applied = await adapter.applyIntent(intent, plan);
  assert.equal(applied.applied, true);
  assert.equal(applied.transcript.length, plan.commands.filter(command => !['enable', 'end'].includes(command)).length);
  await adapter.disconnect();
});

test('v57 serial adapter supports enable-password flow without exposing the environment value in the device record', async () => {
  class PrivilegedFakePort extends FakeSerialPort {
    write(value, callback) {
      const command = Buffer.from(value).toString('utf8').replace(/[\r\n]+$/, '');
      const output = command === 'enable' ? 'Password:' : command === 'letmein' ? 'SW1#' : `${command}\r\nSW1#`;
      setImmediate(() => { this.emit('data', Buffer.from(output)); callback?.(); });
    }
  }
  const adapter = createSerialDeviceAdapter({ id: 'CON2', name: 'CON2', serialPort: 'COM4', assumePrivileged: false, enablePasswordEnv: 'DB_ENABLE_PASSWORD' }, { env: { DB_ENABLE_PASSWORD: 'letmein' }, serialPortFactory: options => new PrivilegedFakePort(options) });
  const result = await adapter.connect();
  assert.equal(result.connected, true);
  assert.doesNotMatch(JSON.stringify(result.device), /letmein/);
  await adapter.disconnect();
});
