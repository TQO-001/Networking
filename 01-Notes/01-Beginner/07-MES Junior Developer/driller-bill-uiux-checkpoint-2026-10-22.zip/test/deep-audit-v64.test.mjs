import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

test('v64.0.5 contains no CSS font below 12px', () => {
  for (const file of ['src/styles.css','src/ux-foundation.css','src/ux-system.css']) {
    const css = read(file);
    for (const match of css.matchAll(/font(?:-size)?\s*:\s*(?:\d+(?:\.\d+)?\s*\/\s*)?(\d+(?:\.\d+)?)px/g)) {
      assert.ok(Number(match[1]) >= 12, `${file} contains font size ${match[1]}px`);
    }
  }
});

test('v64.0.5 uses Google Sans as the primary UX font in every UX layer', () => {
  const foundation = read('src/ux-foundation.css');
  const system = read('src/ux-system.css');
  assert.match(foundation, /--ux-font-ui:\"Google Sans\"/);
  assert.match(foundation, /--ux-font-display:\"Google Sans\"/);
  assert.doesNotMatch(foundation, /--ux-font-ui:\"Jost\"/);
  assert.doesNotMatch(foundation, /--ux-font-display:\"Jost\"/);
  assert.match(system, /--db-font-ui:\"Google Sans\"/);
});

test('v64.0.5 PWA shell invalidates stale cache and declares a current icon', () => {
  const sw = read('public/sw.js');
  const manifest = JSON.parse(read('public/manifest.webmanifest'));
  assert.match(sw, /driller-bill-shell-v64\.0\.6/);
  assert.equal(manifest.theme_color, '#52d8ef');
  assert.ok(manifest.icons?.some(icon => icon.src === '/driller-bill/driller-bill-icon.png' && icon.sizes === '512x512'));
});

test('v64.0.5 browser chrome theme follows the selected application theme', () => {
  const app = read('src/App.jsx');
  assert.match(app, /meta\[name=\\?\"theme-color/);
  assert.match(app, /theme==='dark'\?'#12191d':'#52d8ef'/);
});

test('v64.0.5 agent tokens are read from session storage, not persistent storage', () => {
  for (const file of ['src/Devices.jsx','src/Runbooks.jsx','src/Troubleshooting.jsx','src/NetworkDiscovery.jsx']) {
    const source = read(file);
    assert.match(source, /safeSessionStorage/);
    assert.match(source, /session\.token/);
    assert.doesNotMatch(source, /JSON\.stringify\(\{ url: agentUrl, token: agentToken \}\)/);
  }
});

test('v64.0.5 backup metadata is on the current release line', () => {
  assert.match(read('src/core/data-safety.js'), /APP_DATA_VERSION = '64\.0\.6'/);
});

test('v64.0.5 terminal suggestion controls cannot submit their parent form', () => {
  assert.match(read('src/StatefulLab.jsx'), /<button type="button" role="option" aria-selected=\{index===0\} key=\{s\}/);
});

test('v64.0.5 pins the audited Playwright version and explicitly approves the required native serial binding script', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.devDependencies['@playwright/test'], '1.64.0');
  assert.equal(pkg.allowScripts?.['@serialport/bindings-cpp@13.0.0'], true);
});


test('v64.0.5 all project-relative test paths use Windows-safe URL conversion', () => {
  for (const file of ['test/source-syntax.test.mjs', 'test/ui-accessibility.test.mjs', 'test/deep-audit-v64.test.mjs']) {
    const source = read(file);
    assert.match(source, /fileURLToPath\(new URL\('\.\.\/', import\.meta\.url\)\)/, `${file} should resolve paths portably`);
    assert.doesNotMatch(source, /new URL\('\.\.', import\.meta\.url\)\.pathname/);
  }
});


test('v64.0.5 Driller Bill validator converts the loader path to a file URL for Windows', () => {
  const validator = read('scripts/validate-driller-bill.mjs');
  assert.match(validator, /import \{ pathToFileURL \} from 'node:url'/);
  assert.match(validator, /const loader = pathToFileURL\(resolve\(root, 'scripts\/ts-loader\.mjs'\)\)\.href/);
  assert.match(validator, /'--loader', loader/);
  assert.doesNotMatch(validator, /'--loader', resolve\(root, 'scripts\/ts-loader\.mjs'\)/);
});

test('v64.0.5 heavy workspaces load on demand and have an accessible loading state', () => {
  const app = read('src/App.jsx');
  assert.match(app, /const DrillerBillStudio = lazy\(\(\) => import\('\.\/driller-bill\/DrillerBillStudio\.jsx'\)\)/);
  assert.match(app, /const Devices = lazy\(\(\) => import\('\.\/Devices\.jsx'\)\)/);
  assert.match(app, /<Suspense fallback=\{<WorkspaceLoading view=\{view\} screen=\{screen\}\s*\/>/);
  assert.match(app, /role="status"/);
  assert.match(app, /aria-busy="true"/);
});

test('v64.0.5 loads only Latin font subsets to reduce startup assets', () => {
  const main = read('src/main.jsx');
  assert.match(main, /@fontsource\/google-sans\/latin-400\.css/);
  assert.match(main, /@fontsource\/google-sans-code\/latin-400\.css/);
  assert.match(main, /@fontsource\/google-sans\/latin-ext-400\.css/);
  assert.match(main, /@fontsource\/google-sans-code\/latin-ext-400\.css/);
  assert.doesNotMatch(main, /@fontsource\/(?:google-sans|google-sans-code)\/\d{3}\.css/);
});


test('v64.0.5 workspace loading state adapts to mobile and reduced motion', () => {
  const css = read('src/ux-system.css');
  assert.match(css, /\.workspace-loading-grid[\s\S]*?grid-template-columns:repeat\(2,minmax\(0,1fr\)\)/);
  assert.match(css, /@media\(max-width:720px\)[\s\S]*?\.workspace-loading-grid[\s\S]*?grid-template-columns:minmax\(0,1fr\)/);
  assert.match(css, /@media\(prefers-reduced-motion:reduce\)[\s\S]*?\.workspace-loading-mark span,\.workspace-loading-card i[\s\S]*?animation:none/);
});


test('v64.0.5 header search is a real accessible command palette, not a decorative div', () => {
  const app = read('src/App.jsx');
  const palette = read('src/CommandPalette.jsx');
  const css = read('src/ux-system.css');
  assert.match(app, /<button type="button" className="header-search" onClick=\{onOpenSearch\}/);
  assert.match(app, /event\.ctrlKey\|\|event\.metaKey/);
  assert.match(app, /event\.key\.toLowerCase\(\)==='k'/);
  assert.match(app, /<CommandPalette open=\{commandOpen\}/);
  assert.match(palette, /role="dialog" aria-modal="true"/);
  assert.match(palette, /role="listbox"/);
  assert.match(palette, /event\.key === 'ArrowDown'/);
  assert.match(palette, /event\.key === 'ArrowUp'/);
  assert.match(palette, /event\.key === 'Enter'/);
  assert.match(palette, /event\.key === 'Escape'/);
  assert.match(palette, /const trapDialogFocus = \(event\) =>/);
  assert.match(palette, /event\.key !== 'Tab'/);
  assert.match(css, /\.command-palette-backdrop/);
});
