import test from 'node:test';
import assert from 'node:assert/strict';
import { createHealthyLiveLab, injectLiveFault } from '../src/core/live-network-engine.js';
import { inspectSimulatedDevice } from '../src/core/device-inspection.js';
import { buildDeviceInventory } from '../src/core/device-model.js';
import { buildDeviceDiagnostics } from '../src/core/device-diagnostics.js';
import {
  TWIN_INTELLIGENCE_VERSION,
  TWIN_MODES,
  buildModelContext,
  buildTwinContext,
  buildTwinProposal,
  findTwinIntent,
  generateTwinResponse,
  inferTwinMode,
  loadTwinHistory,
  retrieveTwinKnowledge,
  saveTwinHistory,
} from '../src/core/twin-intelligence.js';
import { readFileSync } from 'node:fs';

function device(state, id) { return buildDeviceInventory(state).find(item => item.id === id); }

test('v55 exposes six Twin reasoning modes', () => {
  assert.equal(TWIN_MODES.length, 6);
  assert.equal(TWIN_INTELLIGENCE_VERSION, '1.0.0');
});

test('v55 mode inference distinguishes explain, diagnose, plan, review and document', () => {
  assert.equal(inferTwinMode('Explain native VLANs'), 'explain');
  assert.equal(inferTwinMode('Why is the uplink down?'), 'diagnose');
  assert.equal(inferTwinMode('Create VLAN 30'), 'plan');
  assert.equal(inferTwinMode('Review the latest change'), 'review');
  assert.equal(inferTwinMode('Write a postmortem for this outage'), 'document');
});

test('v55 knowledge retrieval ranks directly relevant networking concepts first', () => {
  const results = retrieveTwinKnowledge('trunk native VLAN allow-list', 3);
  assert.equal(results[0].article.id, 'trunking');
  assert.ok(results[0].connections.drills.length > 0);
  assert.ok(results[0].score > 0);
});

test('v55 Twin builds redacted device context from observed state', () => {
  const state = createHealthyLiveLab();
  const target = device(state, 'SW1');
  const inspection = inspectSimulatedDevice(state, 'SW1');
  const diagnostics = buildDeviceDiagnostics({ device: target, inspection, connected: true });
  const context = buildTwinContext({ prompt: 'Explain Gi0/1 VLAN state', mode: 'explain', device: target, inspection, diagnostics, topology: { id: 'demo', name: 'Demo', nodes: [{}, {}], links: [{}] } });
  assert.equal(context.device.id, 'SW1');
  assert.equal(context.inspection.source, 'simulated');
  assert.ok(context.inspection.findings.length >= 1);
  assert.equal(context.topology.nodeCount, 2);
});

test('v55 diagnose mode prefers observed interface evidence', () => {
  const state = injectLiveFault(createHealthyLiveLab(), 'interface-down');
  const target = device(state, 'SW1');
  const inspection = inspectSimulatedDevice(state, 'SW1');
  const diagnostics = buildDeviceDiagnostics({ device: target, inspection, connected: true });
  const response = generateTwinResponse(buildTwinContext({ prompt: 'Diagnose why Gi0/1 is down', mode: 'diagnose', device: target, inspection, diagnostics }));
  assert.equal(response.mode, 'diagnose');
  assert.match(response.answer, /warning|evidence/i);
  assert.ok(response.evidence.some(item => /0\/1/i.test(item.value)));
});

test('v55 plan mode creates a validated typed proposal for a supported request', () => {
  const state = createHealthyLiveLab();
  const target = device(state, 'SW1');
  const proposal = buildTwinProposal('Create VLAN 30 named ENGINEERING.', target, 'plan');
  assert.equal(findTwinIntent('Create VLAN 30'), findTwinIntent('Create VLAN 20'));
  assert.equal(proposal.intent.id, 'create-vlan');
  assert.equal(proposal.valid, true);
  assert.ok(proposal.commands.length >= 2);
});

test('v55 refuses incomplete typed requests instead of inventing fields', () => {
  const state = createHealthyLiveLab();
  const proposal = buildTwinProposal('Create VLAN 30.', device(state, 'SW1'), 'plan');
  assert.equal(proposal.intent.id, 'create-vlan');
  assert.equal(proposal.valid, false);
  assert.ok(proposal.errors.length >= 1);
});

test('v55 model handoff contains explicit safety rules and redaction', () => {
  const context = buildTwinContext({ prompt: 'Review enable secret supersecret', mode: 'review', device: { id: 'R1', kind: 'router', capabilities: [] } });
  const exported = buildModelContext(context);
  assert.match(exported, /Do not invent device state/);
  assert.doesNotMatch(exported, /supersecret/);
});

test('v55 Twin history stores only a bounded, normalized local record', () => {
  const storage = new Map();
  const adapter = { getItem: key => storage.get(key) || null, setItem: (key, value) => storage.set(key, value) };
  let history = [];
  for (let i = 0; i < 30; i += 1) history = saveTwinHistory(adapter, history, { prompt: `Question ${i}`, answer: `Answer ${i}`, mode: 'investigate', confidence: i });
  const loaded = loadTwinHistory(adapter);
  assert.equal(loaded.length, 25);
  assert.equal(loaded[0].prompt, 'Question 5');
});

test('v55 application exposes Twin Intelligence in the engineering navigation', () => {
  const app = readFileSync(new URL('../src/App.jsx', import.meta.url), 'utf8');
  const nav = readFileSync(new URL('../src/NavigationSidebar.jsx', import.meta.url), 'utf8');
  const ui = readFileSync(new URL('../src/TwinIntelligence.jsx', import.meta.url), 'utf8');
  const index = readFileSync(new URL('../src/core/index.js', import.meta.url), 'utf8');
  assert.match(app, /const TwinIntelligence = lazy\(\(\) => import\('\.\/TwinIntelligence\.jsx'\)\);/);
  assert.match(app, /view==='twin'/);
  assert.match(nav, /\['twin', 'Twin intelligence'/);
  assert.match(ui, /No external model is required/);
  assert.match(ui, /Prepare in Configuration/);
  assert.match(index, /twin-intelligence\.js/);
});
