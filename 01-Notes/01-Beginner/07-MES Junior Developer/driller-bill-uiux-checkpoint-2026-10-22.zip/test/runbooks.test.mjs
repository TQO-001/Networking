import test from 'node:test';
import assert from 'node:assert/strict';
import { RUNBOOKS, normalizeRunbook, planRunbookStep, runbookProgress, validateRunbook, verificationForIntent, verifyRunbookStep } from '../src/core/runbooks.js';

const switchDevice = { id: 'SW1', kind: 'switch', capabilities: ['vlans', 'interfaces', 'configuration', 'config-snapshot'] };
const routerDevice = { id: 'R1', kind: 'router', capabilities: ['routing', 'interfaces', 'configuration', 'config-snapshot'] };

test('runbook library ships with usable built-in procedures', () => {
  assert.ok(RUNBOOKS.length >= 4);
  assert.equal(RUNBOOKS.every(item => validateRunbook(item).valid), true);
});

test('runbook step planning reuses typed configuration intents', () => {
  const runbook = RUNBOOKS.find(item => item.id === 'access-switch-baseline');
  const plan = planRunbookStep(runbook, 0, switchDevice);
  assert.equal(plan.valid, true);
  assert.deepEqual(plan.commands.slice(0, 3), ['enable', 'configure terminal', 'vlan 10']);
});

test('runbook verification detects VLAN and trunk state from inspection evidence', () => {
  const runbook = RUNBOOKS.find(item => item.id === 'access-switch-baseline');
  const inspection = {
    vlans: [
      { id: 10, name: 'USERS', ports: ['Gi0/1'] },
      { id: 20, name: 'ENGINEERING', ports: ['GigabitEthernet0/2'] },
    ],
    trunks: [{ interface: 'GigabitEthernet0/24', nativeVlan: 99, allowedVlans: [10, 20, 99] }],
    interfaces: [],
    routes: [],
  };
  assert.equal(verifyRunbookStep(runbook.steps[0], { inspection }).completed, true);
  assert.equal(verifyRunbookStep(runbook.steps[2], { inspection }).completed, true);
  assert.equal(verifyRunbookStep(runbook.steps[4], { inspection }).completed, true);
});


test('supported intents can generate an automatic runbook verification rule', () => {
  assert.deepEqual(verificationForIntent({ type: 'create-vlan', fields: { id: 30, name: 'ENGINEERING' } }), { type: 'vlan', id: 30, name: 'ENGINEERING' });
  assert.deepEqual(verificationForIntent({ type: 'set-trunk-policy', fields: { interface: 'Gi0/24', nativeVlan: 99, vlans: '10,20,99' } }), { type: 'trunk-policy', interface: 'Gi0/24', nativeVlan: 99, vlans: [10, 20, 99] });
  assert.equal(verificationForIntent({ type: 'set-interface-description', fields: { interface: 'Gi0/1', description: 'DESK' } }).type, 'manual');
});

test('save step requires explicit running/startup alignment evidence', () => {
  const step = RUNBOOKS.find(item => item.id === 'access-switch-baseline').steps.at(-1);
  assert.equal(verifyRunbookStep(step, { diagnostics: { latestSnapshot: { runningStartupAligned: false } } }).completed, false);
  assert.equal(verifyRunbookStep(step, { diagnostics: { latestSnapshot: { runningStartupAligned: true } } }).completed, true);
});

test('router runbook rejects switch-only target during planning', () => {
  const runbook = RUNBOOKS.find(item => item.id === 'routed-edge-recovery');
  const plan = planRunbookStep(runbook, 1, switchDevice);
  assert.equal(plan.valid, false);
  assert.match(plan.errors.join(' '), /router devices/i);
  assert.equal(planRunbookStep(runbook, 1, routerDevice).valid, true);
});

test('progress is derived from step verification records', () => {
  const runbook = RUNBOOKS.find(item => item.id === 'access-switch-baseline');
  const verification = Object.fromEntries(runbook.steps.slice(0, 2).map(step => [step.id, { completed: true, detail: 'ok' }]));
  const progress = runbookProgress(runbook, verification);
  assert.equal(progress.completed, 2);
  assert.equal(progress.total, 6);
  assert.equal(progress.percent, 33);
  assert.equal(progress.valid, false);
});

test('custom runbooks normalize stable shape without changing source semantics', () => {
  const runbook = normalizeRunbook({ id: 'custom-one', title: ' Test ', targetKind: 'router', steps: [{ id: 'one', label: 'Step one', intent: { type: 'save-running-config', fields: {} }, verify: { type: 'saved' } }] });
  assert.equal(runbook.title, 'Test');
  assert.equal(runbook.source, 'custom');
  assert.equal(validateRunbook(runbook).valid, true);
});
