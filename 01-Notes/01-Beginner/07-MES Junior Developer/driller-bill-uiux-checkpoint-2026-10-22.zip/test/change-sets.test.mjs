import test from 'node:test';
import assert from 'node:assert/strict';
import { buildChangeSet, compileChangeSet, normalizeChangeSet, progressForChangeSet, summarizeChangeSet, loadChangeSets, saveChangeSets } from '../src/core/change-sets.js';
import { planIntent, buildDeviceInventory, CONFIG_INTENTS } from '../src/core/device-model.js';
import { freshLab } from '../src/core/cli-engine.js';

const devices = buildDeviceInventory(freshLab());

function memoryStorage() {
  const data = new Map();
  return { getItem: key => data.get(key) ?? null, setItem: (key, value) => data.set(key, value) };
}

test('v60 change sets normalize and reject duplicate device targets', () => {
  const built = buildChangeSet({
    title: 'Duplicate target',
    items: [
      { deviceId: 'SW1', intent: { type: 'create-vlan', fields: { id: 30, name: 'LAB' } } },
      { deviceId: 'SW1', intent: { type: 'create-vlan', fields: { id: 31, name: 'LAB2' } } },
    ],
  });
  assert.equal(built.valid, false);
  assert.match(built.errors.join(' '), /only once/i);
});

test('v60 compiles one typed intent against multiple device capabilities', () => {
  const built = buildChangeSet({
    title: 'Hostname rollout',
    items: devices.slice(0, 2).map(device => ({
      deviceId: device.id,
      deviceType: device.kind,
      transport: device.connection.type,
      intent: { type: 'set-hostname', fields: { hostname: `${device.id}-EDGE` } },
    })),
  });
  const compiled = compileChangeSet(built.changeSet, devices, planIntent);
  assert.equal(compiled.valid, true);
  assert.equal(compiled.total, 2);
  assert.equal(compiled.ready, 2);
  assert.equal(compiled.maxRisk.level, 'medium');
  for (const item of compiled.items) {
    assert.equal(item.plan.valid, true, `${item.deviceId}: ${item.plan.errors?.join(' ')}`);
    assert.ok(item.plan.displayCommands.some(command => /hostname/.test(command)));
  }
});

test('v60 blocks an intent that is valid for one device kind but not another', () => {
  const routerOnly = { id: 'SW1', kind: 'switch', connection: { type: 'simulated' } };
  const built = buildChangeSet({
    title: 'OSPF rollout',
    items: [{ deviceId: 'SW1', deviceType: 'switch', intent: { type: 'configure-ospf-process', fields: { process: 10, routerId: '10.0.0.1' } } }],
  });
  const compiled = compileChangeSet(built.changeSet, [routerOnly], planIntent);
  assert.equal(compiled.valid, false);
  assert.equal(compiled.items[0].status, 'blocked');
  assert.ok(compiled.items[0].plan.errors.length > 0);
});

test('v60 progress and summary distinguish partial sets from completed sets', () => {
  const partial = normalizeChangeSet({
    title: 'Mixed outcome',
    status: 'partial',
    items: [
      { deviceId: 'SW1', intent: { type: 'create-vlan' }, status: 'completed', verification: { passed: true } },
      { deviceId: 'SW2', intent: { type: 'create-vlan' }, status: 'failed', error: 'Session lost.' },
      { deviceId: 'SW3', intent: { type: 'create-vlan' }, status: 'preflighted' },
    ],
  });
  const progress = progressForChangeSet(partial);
  assert.deepEqual(progress, { total: 3, completed: 1, failed: 1, percent: 33 });
  assert.match(summarizeChangeSet(partial), /^Partial/);
});

test('v60 persistence sanitizes credential fields and preserves only recent history', () => {
  const storage = memoryStorage();
  const original = normalizeChangeSet({ title: 'Credentials', items: [{ deviceId: 'SW1', intent: { type: 'create-local-user', fields: { username: 'ops', secret: 'NEVER-SAVE' } } }] });
  saveChangeSets(storage, [original]);
  const raw = storage.getItem('drillerBill.changeSets.v60');
  assert.doesNotMatch(raw, /NEVER-SAVE/);
  const loaded = loadChangeSets(storage);
  assert.equal(loaded.length, 1);
  assert.equal(loaded[0].items[0].intent.fields.secret, '[redacted]');
  assert.equal(loaded[0].status, 'draft');
  assert.equal(loaded[0].items[0].changeId, '');
});

test('v60 exposes the change-set core from the shared barrel', async () => {
  const core = await import('../src/core/index.js');
  assert.equal(typeof core.buildChangeSet, 'function');
  assert.equal(typeof core.compileChangeSet, 'function');
  assert.equal(typeof core.progressForChangeSet, 'function');
});

assert.ok(CONFIG_INTENTS.length >= 32);
