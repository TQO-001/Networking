import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const read = (relative) => fs.readFileSync(path.join(root, relative), 'utf8');

 test('v64.0.5 landing console prioritizes engineering tasks and keeps assessment tools available', () => {
  const app = read('src/App.jsx');
  assert.match(app, /NETWORK ENGINEERING \/ LOCAL-FIRST/);
  assert.match(app, /Understand the network\.<br\/><span>Change it with confidence\.<\/span>/);
  assert.match(app, /workspace-launchpad/);
  for (const view of ['devices', 'discovery', 'config', 'troubleshooting', 'knowledge', 'lab']) {
    assert.match(app, new RegExp(`id:'${view}'`), `expected ${view} quick-launch card`);
  }
  assert.match(app, /startAssessment\('full'\)/);
  assert.match(app, /Build your paper\./);
});

test('v64.0.5 navigation uses consistent SVG icons instead of Unicode glyphs', () => {
  const nav = read('src/NavigationSidebar.jsx');
  assert.match(nav, /function NavIcon\(/);
  assert.match(nav, /const ICON_PATHS = \{/);
  assert.match(nav, /<NavIcon id=\{id\} \/>/);
  assert.match(nav, /focusable=\"false\"/);
  assert.doesNotMatch(nav, /\['dashboard', 'Console', '⌂'\]/);
});

test('v64.0.5 sidebar sections are collapsible, accessible and keep the active route visible', () => {
  const nav = read('src/NavigationSidebar.jsx');
  const css = read('src/ux-system.css');
  assert.match(nav, /aria-expanded=\{!sectionCollapsed\}/);
  assert.match(nav, /aria-controls=\{sectionId\}/);
  assert.match(nav, /useEffect\(\(\) => \{\s*const activeSection = NAV\.find/);
  assert.match(nav, /drillerBillCollapsedSectionsV2/);
  assert.match(nav, /className=\"pf-sidebar-section-items\" id=\{sectionId\} hidden=\{sectionCollapsed\}/);
  assert.match(css, /\.pf-sidebar-section-items\[hidden\]\{display:none!important;\}/);
});

test('v64.0.5 mobile drawer is keyboard-safe and restores scroll and focus', () => {
  const nav = read('src/NavigationSidebar.jsx');
  assert.match(nav, /aria-modal=\{mobileOpen \? 'true' : undefined\}/);
  assert.match(nav, /event\.key === 'Escape'/);
  assert.match(nav, /event\.key !== 'Tab'/);
  assert.match(nav, /document\.body\.style\.overflow = 'hidden'/);
  assert.match(nav, /document\.body\.style\.overflow = previousOverflow/);
  assert.match(nav, /previousFocus\.focus\(\)/);
  assert.match(nav, /aria-expanded=\{mobileOpen\}/);
  assert.match(nav, /aria-controls=\"driller-bill-sidebar\"/);
});

test('v64.0.5 keeps command-palette access visible on mobile', () => {
  const css = read('src/ux-system.css');
  assert.match(css, /@media\(max-width:900px\)\{[\s\S]*?\.header-search\{display:flex!important/);
  assert.match(css, /\.header-search span,\.header-search kbd\{display:none!important;\}/);
  assert.match(css, /@media\(max-width:620px\)[\s\S]*?\.header-search,\.theme-toggle\{width:42px/);
  assert.match(read('src/App.jsx'), /className=\"header-search\" onClick=\{onOpenSearch\}/);
});

test('v64.0.5 improves explanatory copy sizing and avoids below-12px declarations in the new layer', () => {
  const css = read('src/ux-system.css');
  assert.match(css, /\.pf-workspace-main \.daily-focus-copy p,[\s\S]*?font-size:16px!important;line-height:1\.6!important/);
  for (const match of css.matchAll(/font(?:-size)?\s*:\s*(?:\d+(?:\.\d+)?\s*\/\s*)?(\d+(?:\.\d+)?)px/g)) {
    assert.ok(Number(match[1]) >= 12, `new UX layer contains ${match[1]}px text`);
  }
});

