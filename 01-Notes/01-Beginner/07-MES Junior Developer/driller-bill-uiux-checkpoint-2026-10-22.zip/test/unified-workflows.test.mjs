import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  WORKFLOW_TEMPLATES,
  UNIFIED_WORKFLOW_VERSION,
  UNIFIED_WORKFLOW_STORAGE_KEY,
  buildWorkflowContext,
  completeWorkflowStage,
  createWorkflow,
  getActiveWorkflow,
  loadWorkflowStore,
  progressForWorkflow,
  stageForView,
  startWorkflow,
  workflowFromKnowledge,
  workflowFromTroubleshooting,
} from '../src/core/unified-workflows.js';

function storage() {
  const map = new Map();
  return { getItem: k => map.get(k) ?? null, setItem: (k,v) => map.set(k,String(v)), removeItem: k => map.delete(k) };
}

test('normalizes workflow templates and stage progress', () => {
  const workflow = createWorkflow({ templateId: 'troubleshoot-to-recovery', title: 'VLAN recovery' });
  assert.equal(workflow.version, UNIFIED_WORKFLOW_VERSION);
  assert.equal(workflow.stages.length, WORKFLOW_TEMPLATES['troubleshoot-to-recovery'].stages.length);
  assert.equal(progressForWorkflow(workflow).percent, 0);
  assert.equal(progressForWorkflow(workflow).current.id, 'context');
});

test('starts, completes and archives a workflow', () => {
  const store = storage();
  const workflow = startWorkflow(store, { templateId: 'device-change', title: 'Switch rollout' });
  assert.equal(getActiveWorkflow(store).id, workflow.id);
  completeWorkflowStage(store, 'context', { note: 'Scope and target confirmed.' });
  assert.equal(getActiveWorkflow(store).currentStage, 'plan');
  const reloaded = loadWorkflowStore(store);
  assert.ok(reloaded.active);
  assert.ok(store.getItem(UNIFIED_WORKFLOW_STORAGE_KEY));
});

test('view-stage mapping covers integrated workspaces', () => {
  assert.equal(stageForView('knowledge'), 'context');
  assert.equal(stageForView('drills'), 'learn');
  assert.equal(stageForView('troubleshooting'), 'investigate');
  assert.equal(stageForView('config'), 'plan');
  assert.equal(stageForView('runbooks'), 'operate');
  assert.equal(stageForView('devices'), 'verify');
  assert.equal(stageForView('twin'), 'document');
});

test('workflow context preserves source, stages and timeline', () => {
  const workflow = createWorkflow(workflowFromKnowledge({ id: 'vlan', title: 'Virtual LANs' }));
  const context = buildWorkflowContext(workflow);
  assert.equal(context.workflow.source.id, 'vlan');
  assert.equal(context.stages[0].id, 'context');
  assert.ok(context.timeline.length >= 1);
});

test('troubleshooting workflow source maps into recovery thread', () => {
  const workflow = createWorkflow(workflowFromTroubleshooting({ id: 'interface-down', title: 'Interface Down' }));
  assert.equal(workflow.templateId, 'troubleshoot-to-recovery');
  assert.equal(workflow.stages.at(1).id, 'investigate');
});

test('v58 exposes Unified Workflows in the application navigation', () => {
  const app = fs.readFileSync(path.resolve('src/App.jsx'), 'utf8');
  const sidebar = fs.readFileSync(path.resolve('src/NavigationSidebar.jsx'), 'utf8');
  assert.match(app, /const UnifiedWorkflows = lazy\(\(\) => import\('\.\/UnifiedWorkflows\.jsx'\)\);/);
  assert.match(app, /view==='workflows'/);
  assert.match(sidebar, /\['workflows', 'Unified workflows'/);
});
