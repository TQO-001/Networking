import test from 'node:test';
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { ALL_STATIC_QUESTIONS, FAMILIES, MODE_META, makeExam, randomizeChoices, getCorrect, normalizeExhibit, V19_SCENARIO_FAMILIES, V19_SCENARIO_QUESTIONS } from '../src/core/exam-engine.js';
import { demoTopology, findPath, validateTopology } from '../src/core/topology-engine.js';
import { emptyCard, scheduleCard } from '../src/core/mastery-engine.js';
import { FLOW_SCENARIOS, freshFlowState, buildFlow, repairFlow } from '../src/core/flow-engine.js';
import { PACKET_SCENARIOS, freshPacketState, tracePacket, repairPacketCase, evaluatePacketCase, packetSnapshot } from '../src/core/packet-engine.js';

const modes = Object.entries(MODE_META);

test('question inventory is present and unique', () => {
  assert.ok(FAMILIES.length >= 340);
  assert.ok(ALL_STATIC_QUESTIONS.length >= 1700);
  assert.equal(new Set(ALL_STATIC_QUESTIONS.map((q) => q.questionId)).size, ALL_STATIC_QUESTIONS.length);
});

test('family IDs and question IDs are globally unique', () => {
  assert.equal(new Set(FAMILIES.map((x) => x.id)).size, FAMILIES.length);
  assert.equal(new Set(ALL_STATIC_QUESTIONS.map((x) => x.questionId)).size, ALL_STATIC_QUESTIONS.length);
});

test('v18 content covers every CCNA v1.1 objective with three authored families', () => {
  const counts = new Map();
  for (const q of FAMILIES.filter((x) => String(x.id).startsWith('V18-'))) counts.set(q.topic, (counts.get(q.topic) || 0) + 1);
  assert.equal(counts.size, 53);
  for (const n of counts.values()) assert.equal(n, 3);
});

test('every standard exam form keeps its contract', () => {
  const expected = { full: 100, sprint: 20, exhibits: 20, scenario: 30, remediation: 24 };
  for (const [mode, count] of Object.entries(expected)) {
    const questions = makeExam({ mode, history: [], seen: {}, adaptive: false, coldStart: true, difficulty: 'mixed' });
    assert.equal(questions.length, count, mode);
    assert.equal(new Set(questions.map((q) => q.questionId)).size, count, `${mode} duplicate`);
  }
});

test('domain drill is constrained to the requested domain', () => {
  const questions = makeExam({ mode: 'domain', domain: '3', history: [], seen: {}, adaptive: false, coldStart: true, difficulty: 'mixed' });
  assert.equal(questions.length, 20);
  assert.ok(questions.every((q) => String(q.domain) === '3'));
});

test('choice randomization preserves correctness', () => {
  const question = ALL_STATIC_QUESTIONS.find((q) => q.type === 'single');
  const randomized = randomizeChoices(question);
  assert.equal(getCorrect(randomized, randomized.answer), true);
  assert.equal(randomized.options.length, 4);
});

test('demo topology is valid and traversable', () => {
  const topology = demoTopology();
  assert.equal(validateTopology(topology).valid, true);
  assert.ok(findPath(topology, topology.devices[0].id, topology.devices.at(-1).id).length > 1);
});

test('mastery schedule advances on recall and resets on lapse', () => {
  const seed = emptyCard({ id: 'mastery-test', questionId: 'mastery-test', topic: '3.4', concept: 'OSPF', q: 'x', options: ['a','b','c','d'], answer: [0] });
  const good = scheduleCard(seed, 'good', 1700000000000);
  assert.equal(good.streak, 1);
  assert.ok(good.interval >= 1);
  const again = scheduleCard(good, 'again', 1700000000000);
  assert.equal(again.streak, 0);
  assert.equal(again.interval, 0);
  assert.equal(again.lapses, 1);
});


test('v19 scenario bank exposes five variants per family and five-step cases', () => {
  assert.equal(V19_SCENARIO_FAMILIES.length, 40);
  assert.equal(V19_SCENARIO_QUESTIONS.length, 200);
  const grouped = new Map();
  for (const q of V19_SCENARIO_QUESTIONS) grouped.set(q.familyId, (grouped.get(q.familyId) || 0) + 1);
  assert.equal(grouped.size, 40);
  for (const n of grouped.values()) assert.equal(n, 5);
  const scenario = makeExam({ mode:'scenario', history:[], seen:{}, adaptive:false, coldStart:true, difficulty:'mixed' });
  assert.equal(scenario.length, 30);
  assert.equal(new Set(scenario.map(q=>q.scenarioId)).size, 6);
  assert.ok(scenario.every(q => q.scenarioStep >= 1 && q.scenarioStep <= 5));
  assert.ok(scenario.every(q => q.scenarioTotal === 5));
});


test('v20 flow catalog builds every trace without throwing', () => {
  const state = freshFlowState();
  assert.equal(FLOW_SCENARIOS.length, 7);
  for (const scenario of FLOW_SCENARIOS) {
    const trace = buildFlow(state, scenario.id);
    assert.equal(trace.total > 0, true, scenario.id);
    assert.equal(trace.scenario.id, scenario.id);
    assert.equal(trace.passed <= trace.total, true);
  }
});

test('v20 repair sequences complete every protocol flow', () => {
  const state = freshFlowState();
  for (const scenario of FLOW_SCENARIOS) {
    const repaired = repairFlow(state, scenario.id);
    const trace = buildFlow(repaired, scenario.id);
    assert.equal(trace.complete, true, `${scenario.id} did not repair: ${trace.steps.filter(s => !s.ok).map(s => s.label).join(', ')}`);
  }
});


test('v20 navigation and release wiring are present', () => {
  const nav = readFileSync(new URL('../src/NavigationSidebar.jsx', import.meta.url), 'utf8');
  const app = readFileSync(new URL('../src/App.jsx', import.meta.url), 'utf8');
  assert.match(nav, /\['flow', 'Flow Lab'\]/);
  assert.match(app, /const FlowLab = lazy\(\(\) => import\('\.\/FlowLab\.jsx'\)\);/);
  assert.match(app, /if\(view==='flow'\)return workspace\(<FlowLab\/>\);/);
  assert.match(readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8'), /\.flow-layout\{display:grid;/);
});

test('exhibit payloads normalize across legacy and v19 formats', () => {
  const legacyRows = normalizeExhibit({ type:'address-table', data:[['A','10.0.0.1/24']] });
  assert.deepEqual(legacyRows.rows, [['A','10.0.0.1/24']]);
  const legacyCode = normalizeExhibit({ type:'code', data:'show ip route' });
  assert.equal(legacyCode.code, 'show ip route');
  const v19 = V19_SCENARIO_QUESTIONS[0].exhibit;
  assert.equal(v19.type, 'workbench');
  assert.equal(v19.tabs.length, 1);
  assert.equal(normalizeExhibit(v19).tabs.length, 1);
});


test('v21 packet lab builds every protocol trace without throwing', () => {
  const state = freshPacketState();
  assert.equal(PACKET_SCENARIOS.length, 7);
  for (const scenario of PACKET_SCENARIOS) {
    const fresh = freshPacketState(scenario.id);
    const trace = tracePacket(fresh, scenario.id);
    const result = evaluatePacketCase(fresh, scenario.id);
    assert.equal(trace.caseId, scenario.id);
    assert.ok(trace.total > 0, scenario.id);
    assert.equal(result.caseId, scenario.id);
    assert.ok(result.total > 0, scenario.id);
    assert.equal(result.score <= 100, true);
  }
  assert.deepEqual(Object.keys(packetSnapshot(state)).sort(), ['acl','dhcpRelay','etherchannel','ipv6','nat','stp']);
});

test('v21 every packet repair reaches full protocol compliance', () => {
  for (const scenario of PACKET_SCENARIOS) {
    const repaired = repairPacketCase(freshPacketState(scenario.id), scenario.id);
    const result = evaluatePacketCase(repaired, scenario.id);
    assert.equal(result.ok, true, `${scenario.id} incomplete: ${result.checks.filter(x=>!x.ok).map(x=>x.label).join(', ')}`);
    const trace = tracePacket(repaired, scenario.id);
    assert.equal(trace.complete, true, `${scenario.id} trace did not complete`);
  }
});

test('v21 packet repair changes the modeled protocol state', () => {
  const broken = freshPacketState('nat-flow');
  const fixed = repairPacketCase(broken, 'nat-flow');
  assert.equal(broken.packet.nat.inside.length, 0);
  assert.deepEqual(fixed.packet.nat.translations, [{insideLocal:'10.10.10.10',insideGlobal:'203.0.113.2',outsideGlobal:'198.51.100.10'}]);
  assert.equal(evaluatePacketCase(broken, 'nat-flow').ok, false);
  assert.equal(evaluatePacketCase(fixed, 'nat-flow').ok, true);
});

test('v21 navigation exposes Packet Lab', () => {
  const nav = readFileSync(new URL('../src/NavigationSidebar.jsx', import.meta.url), 'utf8');
  const app = readFileSync(new URL('../src/App.jsx', import.meta.url), 'utf8');
  assert.match(nav, /\['packet', 'Packet Lab'\]/);
  assert.match(app, /const PacketLab = lazy\(\(\) => import\('\.\/PacketLab\.jsx'\)\);/);
  assert.match(app, /if\(view==='packet'\)return workspace\(<PacketLab\/>\);/);
});

test('v21 packet engine has no accidental global CSS navigation collision', () => {
  const css = readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8');
  assert.doesNotMatch(css, /^nav\{/m);
  assert.match(css, /\.pf-sidebar-scroll\{[^}]*flex-direction:column;/);
});


test('v22 packet workshop builds, faults, and repairs packet flows', async () => {
  const { PACKET_PROFILES, WORKSHOP_FAULTS, freshWorkshopState, injectFault, simulatePacket, packetWorkshopSnapshot } = await import('../src/core/packet-workshop-engine.js');
  assert.equal(PACKET_PROFILES.length, 6);
  assert.equal(WORKSHOP_FAULTS.length, 8);
  const healthy = freshWorkshopState();
  for (const profile of PACKET_PROFILES) {
    const trace = simulatePacket(healthy, profile.id);
    assert.ok(trace.steps.length >= 3, profile.id);
    assert.ok(trace.frameId.startsWith('PF-'), profile.id);
  }
  const fault = injectFault(healthy, 'trunk-vlan20');
  const internal = simulatePacket(fault, 'ipv4-icmp');
  assert.equal(internal.complete, false);
  assert.equal(internal.firstFailure, 'trunk');
  const repaired = injectFault(healthy, 'none');
  const repairedTrace = simulatePacket(repaired, 'ipv4-icmp');
  assert.equal(repairedTrace.complete, true);
  assert.equal(packetWorkshopSnapshot(fault).trunkVlan20, false);
  assert.equal(packetWorkshopSnapshot(repaired).trunkVlan20, true);
});

test('v22 packet workshop faults target the intended gate', async () => {
  const { freshWorkshopState, injectFault, simulatePacket } = await import('../src/core/packet-workshop-engine.js');
  const cases = [
    ['acl-icmp', 'ipv4-icmp-wan', 'acl'],
    ['nat-inside', 'ipv4-https', 'nat'],
    ['dhcp-helper', 'dhcp', 'relay'],
    ['ipv6-forwarding', 'ipv6-icmp', 'ndp'],
    ['ipv6-route', 'ipv6-icmp', 'route6'],
    ['ospf-adjacency', 'ospf', 'hello'],
  ];
  for (const [faultId, profileId, firstFailure] of cases) {
    const trace = simulatePacket(injectFault(freshWorkshopState(), faultId), profileId);
    assert.equal(trace.complete, false, faultId);
    assert.equal(trace.firstFailure, firstFailure, faultId);
  }
});

test('v22 Packet Workshop is wired into workspace navigation', () => {
  const nav = readFileSync(new URL('../src/NavigationSidebar.jsx', import.meta.url), 'utf8');
  const app = readFileSync(new URL('../src/App.jsx', import.meta.url), 'utf8');
  assert.match(nav, /\['packet-workshop', 'Packet Workshop'\]/);
  assert.match(app, /const PacketWorkshop = lazy\(\(\) => import\('\.\/PacketWorkshop\.jsx'\)\);/);
  assert.match(app, /if\(view==='packet-workshop'\)return workspace\(<PacketWorkshop\/>\);/);
});


test('v23 shared live lab exposes the same state to CLI and packet engine', async () => {
  const { createHealthyLiveLab, simulateLivePacket, injectLiveFault } = await import('../src/core/live-network-engine.js');
  const { executeCommand } = await import('../src/core/cli-engine.js');
  let state = createHealthyLiveLab();
  assert.ok(state.devices.R2);
  let result = executeCommand(state, 'SW2', 'enable');
  state = result.state;
  result = executeCommand(state, 'SW2', 'configure terminal'); state = result.state;
  result = executeCommand(state, 'SW2', 'interface gi0/24'); state = result.state;
  result = executeCommand(state, 'SW2', 'switchport trunk allowed vlan 10,99'); state = result.state;
  assert.equal(simulateLivePacket(state, 'vlan20-icmp').complete, false);
  assert.equal(simulateLivePacket(state, 'vlan20-icmp').firstFailure, 'trunk');
  result = executeCommand(state, 'SW2', 'switchport trunk allowed vlan 10,20,99'); state = result.state;
  assert.equal(simulateLivePacket(state, 'vlan20-icmp').complete, true);
  assert.ok(simulateLivePacket(state, 'vlan20-icmp').steps.some(step => step.id === 'trunk' && step.ok));
  const broken = injectLiveFault(state, 'nat-inside');
  assert.equal(simulateLivePacket(broken, 'ipv4-https').complete, false);
  let dhcp = createHealthyLiveLab();
  result = executeCommand(dhcp, 'R1', 'configure terminal'); dhcp = result.state;
  result = executeCommand(dhcp, 'R1', 'interface gi0/0'); dhcp = result.state;
  result = executeCommand(dhcp, 'R1', 'no ip helper-address 10.10.10.100'); dhcp = result.state;
  assert.equal(simulateLivePacket(dhcp, 'dhcp').firstFailure, 'relay');
  let nat = createHealthyLiveLab();
  result = executeCommand(nat, 'R1', 'configure terminal'); nat = result.state;
  result = executeCommand(nat, 'R1', 'interface gi0/0'); nat = result.state;
  result = executeCommand(nat, 'R1', 'no ip nat inside'); nat = result.state;
  assert.equal(nat.devices.R1.interfaces['GigabitEthernet0/0'].natRole, null);
  assert.equal(nat.devices.R1.nat.inside.includes('GigabitEthernet0/0'), false);
  assert.equal(simulateLivePacket(nat, 'ipv4-https').firstFailure, 'nat');
});

test('v23 IPv6 CLI state is inspectable and configurable', async () => {
  const { freshLab, executeCommand } = await import('../src/core/cli-engine.js');
  let state = freshLab();
  let result = executeCommand(state, 'R1', 'configure terminal'); state = result.state;
  result = executeCommand(state, 'R1', 'ipv6 unicast-routing'); state = result.state;
  result = executeCommand(state, 'R1', 'ipv6 route 2001:db8:20::/64 10.0.12.2'); state = result.state;
  result = executeCommand(state, 'R1', 'end'); state = result.state;
  assert.equal(state.devices.R1.ipv6.forwarding, true);
  assert.ok(state.devices.R1.ipv6.routes.some(r => r.prefix === '2001:db8:20::/64' && r.next === '10.0.12.2'));
  assert.match(executeCommand(state, 'R1', 'show ipv6 route').output, /2001:db8:20::\/64/);
  assert.equal(executeCommand(state, 'R1', 'show ip dhcp binding').output.startsWith('Bindings from all pools'), true);
});


test('v24 canonical network workspace is shared by CLI, Packet Workshop, and topology workbench', () => {
  const app = readFileSync(new URL('../src/App.jsx', import.meta.url), 'utf8');
  const context = readFileSync(new URL('../src/context/NetworkWorkspaceContext.jsx', import.meta.url), 'utf8');
  const stateful = readFileSync(new URL('../src/StatefulLab.jsx', import.meta.url), 'utf8');
  const workshop = readFileSync(new URL('../src/PacketWorkshop.jsx', import.meta.url), 'utf8');
  const topology = readFileSync(new URL('../src/topology/TopologyBuilder.jsx', import.meta.url), 'utf8');
  assert.match(app, /NetworkWorkspaceProvider/);
  assert.match(app, /labState, setLabState, topology, setTopology/);
  assert.match(context, /createContext/);
  assert.match(stateful, /useNetworkWorkspace/);
  assert.match(workshop, /useNetworkWorkspace/);
  assert.match(topology, /useNetworkWorkspace/);
});

test('v24 packet faults preserve current live CLI state', async () => {
  const { createHealthyLiveLab, injectLiveFault, simulateLivePacket } = await import('../src/core/live-network-engine.js');
  const { executeCommand } = await import('../src/core/cli-engine.js');
  let state = createHealthyLiveLab();
  let result = executeCommand(state, 'SW2', 'enable'); state = result.state;
  result = executeCommand(state, 'SW2', 'configure terminal'); state = result.state;
  result = executeCommand(state, 'SW2', 'interface gi0/24'); state = result.state;
  result = executeCommand(state, 'SW2', 'switchport trunk allowed vlan 10,20,99'); state = result.state;
  const faulted = injectLiveFault(state, 'acl-icmp');
  assert.deepEqual(faulted.devices.SW2.interfaces['GigabitEthernet0/24'].allowedVlans, [10,20,99]);
  assert.equal(simulateLivePacket(faulted, 'ipv4-https').firstFailure, 'acl');
});

test('v25 topology builder synchronizes structure into canonical live state', async () => {
  const { createHealthyLiveLab } = await import('../src/core/live-network-engine.js');
  const { syncTopologyToLabState, projectLabStateOntoTopology } = await import('../src/core/network-topology-sync.js');
  const { demoTopology, addDevice } = await import('../src/core/topology-engine.js');
  let topology = demoTopology();
  let state = syncTopologyToLabState(createHealthyLiveLab(), topology);
  assert.equal(state.meta.topologyId, topology.id);
  assert.equal(state.devices.R1.interfaces['GigabitEthernet0/0'].link, true);
  assert.equal(state.devices.SW1.interfaces['GigabitEthernet0/24'].link, true);
  assert.equal(state.devices.SW1.interfaces['GigabitEthernet0/24'].mode, 'trunk');
  assert.equal(state.clients.PC1.vlan, 10);
  topology = addDevice(topology, 'router');
  const newRouter = topology.devices.at(-1);
  state = syncTopologyToLabState(state, topology);
  assert.ok(state.devices[newRouter.name], `new router ${newRouter.name} should become CLI-addressable`);
  const projected = projectLabStateOntoTopology(topology, state);
  assert.equal(projected.devices.find(d=>d.name===newRouter.name).runtimeEnabled, true);
});

test('v25 topology runtime projection reflects CLI state without changing design state', async () => {
  const { createHealthyLiveLab } = await import('../src/core/live-network-engine.js');
  const { syncTopologyToLabState, projectLabStateOntoTopology } = await import('../src/core/network-topology-sync.js');
  const { demoTopology } = await import('../src/core/topology-engine.js');
  let topology = demoTopology();
  let state = syncTopologyToLabState(createHealthyLiveLab(), topology);
  state.devices.SW2.interfaces['GigabitEthernet0/24'].admin = false;
  state.devices.SW2.interfaces['GigabitEthernet0/24'].link = false;
  const projected = projectLabStateOntoTopology(topology, state);
  const trunk = projected.devices.find(d=>d.name==='SW2').ports.find(p=>p.id==='Gi0/24');
  assert.equal(trunk.runtimeState, 'down');
  assert.equal(trunk.state, 'up');
  assert.equal(projected.updatedAt, topology.updatedAt);
});


test('v25 custom topology link becomes a live interface link', async () => {
  const { createHealthyLiveLab } = await import('../src/core/live-network-engine.js');
  const { syncTopologyToLabState } = await import('../src/core/network-topology-sync.js');
  const { demoTopology, addDevice, addLink } = await import('../src/core/topology-engine.js');
  let topology = demoTopology();
  const sw = topology.devices.find(d=>d.name==='SW1');
  topology = addDevice(topology, 'switch');
  const extra = topology.devices.at(-1);
  topology = addLink(topology, sw.id, extra.id, 'trunk');
  const state = syncTopologyToLabState(createHealthyLiveLab(), topology);
  assert.ok(state.devices[extra.name]);
  const link = topology.links.at(-1);
  const ai = link.ai; const bi = link.bi;
  assert.equal(state.devices.SW1.interfaces[ai.replace(/^Gi/, 'GigabitEthernet')].link, true);
  assert.equal(state.devices[extra.name].interfaces[bi.replace(/^Gi/, 'GigabitEthernet')].link, true);
  assert.equal(state.devices[extra.name].interfaces[bi.replace(/^Gi/, 'GigabitEthernet')].mode, 'trunk');
});

// v31 data safety / backup round-trip
test('v31 backup schema validates and restores safely', async () => {
  const { createStudySnapshot, validateStudySnapshot, serializeStudySnapshot, restoreStudySnapshot } = await import('../src/core/data-safety.js');
  const backup = createStudySnapshot({ now: '2026-09-28T00:00:00.000Z' });
  assert.equal(backup.schema, 'penny-farthing-study-backup');
  assert.equal(validateStudySnapshot(backup).valid, true);
  const serializedBackup = serializeStudySnapshot({ now: '2026-09-28T00:00:00.000Z' });
  assert.ok(serializedBackup.includes('penny-farthing-study-backup'));
  const invalidBackup = { ...backup, schema: 'wrong-schema' };
  assert.equal(validateStudySnapshot(invalidBackup).valid, false);
  assert.doesNotThrow(() => restoreStudySnapshot(backup));
});

import { analyzeTwin } from '../src/driller-bill/twin.js';

test('Twin intelligence identifies repeated error patterns and gives a next move', () => {
  const theory = [{ id: 'modes', title: 'IOS modes', body: ['Mode transitions'], commandRef: 'enable' }];
  const module = {
    theory,
    objectives: [{ id: 'obj', label: 'Reach target', check: (state) => state?.done === true }],
  };
  const session = { entries: [{ typo: false }, { typo: true }, { typo: false }] };
  const errors = [
    { category: 'wrong-mode', raw: 'show vlan', theoryAnchor: 'modes', relatedObjectiveId: 'obj' },
    { category: 'wrong-mode', raw: 'show vlan', theoryAnchor: 'modes', relatedObjectiveId: 'obj' },
  ];
  const result = analyzeTwin(module, session, { done: true }, errors);
  assert.equal(result.primary.type, 'theory-gap');
  assert.equal(result.stats.errors, 2);
  assert.equal(result.stats.typos, 1);
  assert.ok(result.recommendations.length >= 1);
  assert.equal(result.repeatedCommand.count, 2);
});

test('v42 device model builds vendor-aware inventory and capabilities', async () => {
  const { createHealthyLiveLab } = await import('../src/core/live-network-engine.js');
  const { buildDeviceInventory, deviceCapabilitySummary } = await import('../src/core/device-model.js');
  const inventory = buildDeviceInventory(createHealthyLiveLab());
  assert.ok(inventory.length >= 4);
  const sw2 = inventory.find(device => device.id === 'SW2');
  assert.ok(sw2);
  assert.equal(sw2.vendor, 'Cisco');
  assert.equal(sw2.connection.type, 'simulated');
  assert.ok(sw2.capabilities.includes('vlans'));
  assert.ok(sw2.capabilities.includes('configuration'));
  assert.ok(deviceCapabilitySummary(sw2).some(item => item.id === 'config-snapshot'));
});

test('v42 configuration intent plans validate before producing Cisco commands', async () => {
  const { createHealthyLiveLab } = await import('../src/core/live-network-engine.js');
  const { buildDeviceInventory, planIntent } = await import('../src/core/device-model.js');
  const sw2 = buildDeviceInventory(createHealthyLiveLab()).find(device => device.id === 'SW2');
  const plan = planIntent({ type:'create-vlan', fields:{ id:'10', name:'SALES' } }, sw2);
  assert.equal(plan.valid, true);
  assert.deepEqual(plan.commands, ['enable','configure terminal','vlan 10','name SALES','end']);
  assert.equal(plan.safety.requiresPreview, true);
  const invalid = planIntent({ type:'create-vlan', fields:{ id:'5000', name:'' } }, sw2);
  assert.equal(invalid.valid, false);
  assert.equal(invalid.commands.length, 0);
  assert.ok(invalid.errors.length >= 2);
});

test('v42 simulated device adapter executes commands and captures configs', async () => {
  const { createHealthyLiveLab } = await import('../src/core/live-network-engine.js');
  const { createSimulatedDeviceAdapter, planIntent } = await import('../src/core/device-model.js');
  const state = createHealthyLiveLab();
  const adapter = createSimulatedDeviceAdapter(state, 'SW2');
  await assert.rejects(() => adapter.execute('show version'), /not connected/);
  const connection = await adapter.connect();
  assert.equal(connection.connected, true);
  const plan = planIntent({ type:'create-vlan', fields:{ id:'30', name:'LAB' } }, connection.device);
  const applied = await adapter.applyIntent({ type:'create-vlan', fields:{ id:'30', name:'LAB' } });
  assert.equal(applied.applied, true);
  assert.equal(applied.state.devices.SW2.vlans[30], 'LAB');
  const snapshot = await adapter.snapshot();
  assert.match(snapshot.runningConfig, /vlan 30/);
  assert.equal(typeof snapshot.startupConfig, 'string');
  await adapter.disconnect();
  assert.equal(adapter.isConnected(), false);
  assert.equal(plan.valid, true);
});

test('v42 Devices workspace is wired into the main application', () => {
  const app = readFileSync(new URL('../src/App.jsx', import.meta.url), 'utf8');
  const sidebar = readFileSync(new URL('../src/NavigationSidebar.jsx', import.meta.url), 'utf8');
  const deviceUi = readFileSync(new URL('../src/Devices.jsx', import.meta.url), 'utf8');
  const model = readFileSync(new URL('../src/core/device-model.js', import.meta.url), 'utf8');
  assert.match(app, /const Devices = lazy\(\(\) => import\('\.\/Devices\.jsx'\)\);/);
  assert.match(app, /if\(view==='devices'\)return workspace\(<Devices\/>\);/);
  assert.match(sidebar, /\['devices', 'Devices'\]/);
  assert.match(deviceUi, /useNetworkWorkspace/);
  assert.match(deviceUi, /planIntent/);
  assert.match(model, /device-agent\/3/);
});
