import test from 'node:test';
import assert from 'node:assert/strict';
import { createHealthyLiveLab, injectLiveFault, resetLiveNetwork } from '../src/core/live-network-engine.js';
import { inspectSimulatedDevice } from '../src/core/device-inspection.js';
import { buildDeviceInventory } from '../src/core/device-model.js';
import { buildDeviceDiagnostics } from '../src/core/device-diagnostics.js';
import {
  TROUBLESHOOTING_CASES,
  analyzeTroubleshootingCase,
  evaluateEvidenceTest,
  loadCustomTroubleshootingCases,
  normalizeTroubleshootingCase,
  remediationPlan,
  saveCustomTroubleshootingCases,
  validateTroubleshootingCase,
} from '../src/core/troubleshooting.js';
import { readFileSync } from 'node:fs';

function device(state, id) {
  return buildDeviceInventory(state).find(item => item.id === id);
}

function evidence(state, id) {
  const report = inspectSimulatedDevice(state, id);
  return { report, diagnostics: buildDeviceDiagnostics({ device: device(state, id), inspection: report, connected: true }) };
}

test('v54 ships four evidence-driven troubleshooting cases', () => {
  assert.equal(TROUBLESHOOTING_CASES.length, 4);
  assert.equal(TROUBLESHOOTING_CASES.every(item => validateTroubleshootingCase(item).valid), true);
});

test('v54 interface case ranks administrative shutdown from observed evidence', () => {
  const state = injectLiveFault(createHealthyLiveLab(), 'interface-down');
  const { report, diagnostics } = evidence(state, 'SW1');
  const analysis = analyzeTroubleshootingCase(TROUBLESHOOTING_CASES.find(item => item.id === 'interface-down'), { inspection: report, diagnostics });
  assert.equal(analysis.topHypothesis.id, 'admin-down');
  assert.ok(analysis.topHypothesis.confidence >= 75);
  assert.equal(analysis.readyForRemediation, true);
  assert.equal(remediationPlan(TROUBLESHOOTING_CASES[0], analysis.topHypothesis, device(state, 'SW1')).valid, true);
});

test('v54 trunk case identifies a missing VLAN from the observed allow-list', () => {
  const state = injectLiveFault(createHealthyLiveLab(), 'trunk-vlan20');
  const { report } = evidence(state, 'SW2');
  const caseData = TROUBLESHOOTING_CASES.find(item => item.id === 'vlan-trunk');
  const testDef = caseData.tests.find(item => item.id === 'trunks');
  const result = evaluateEvidenceTest(testDef, { inspection: report, caseData });
  assert.equal(result.status, 'fail');
  assert.match(result.detail, /VLAN 20/);
  const analysis = analyzeTroubleshootingCase(caseData, { inspection: report, results: { trunks: result } });
  assert.equal(analysis.topHypothesis.id, 'vlan-not-allowed');
  assert.equal(analysis.readyForRemediation, true);
});

test('v54 static-route case detects a missing remote route', () => {
  const state = injectLiveFault(createHealthyLiveLab(), 'static-route');
  const { report } = evidence(state, 'R1');
  const caseData = TROUBLESHOOTING_CASES.find(item => item.id === 'static-route');
  const result = evaluateEvidenceTest(caseData.tests[0], { inspection: report, caseData });
  assert.equal(result.status, 'fail');
  const analysis = analyzeTroubleshootingCase(caseData, { inspection: report, results: { routes: result } });
  assert.equal(analysis.topHypothesis.id, 'missing-route');
  assert.ok(analysis.confidence >= 75);
});

test('v54 OSPF case uses command evidence to distinguish a missing FULL neighbor', () => {
  const state = injectLiveFault(createHealthyLiveLab(), 'ospf-adjacency');
  const output = ['Neighbor ID     Pri   State', '2.2.2.2           1   2WAY/DROTHER'];
  const caseData = TROUBLESHOOTING_CASES.find(item => item.id === 'ospf-neighbor');
  const result = evaluateEvidenceTest(caseData.tests[1], { commandResult: { output }, caseData });
  assert.equal(result.status, 'fail');
  const analysis = analyzeTroubleshootingCase(caseData, { inspection: inspectSimulatedDevice(state, 'R1'), results: { ospf: result } });
  assert.equal(analysis.topHypothesis.id, 'neighbor-missing');
});

test('v54 custom troubleshooting cases persist with a stable normalized shape', () => {
  const storage = new Map();
  const adapter = { getItem: key => storage.get(key) || null, setItem: (key, value) => storage.set(key, value) };
  const draft = normalizeTroubleshootingCase({ title: ' Branch check ', symptom: 'Users lose access.', hypotheses: [{ title: 'Uplink fault', rationale: 'The uplink is down.' }], tests: [{ label: 'Inspect', command: 'show ip interface brief' }] });
  assert.equal(validateTroubleshootingCase(draft).valid, true);
  const saved = saveCustomTroubleshootingCases(adapter, [draft]);
  const loaded = loadCustomTroubleshootingCases(adapter);
  assert.equal(saved.length, 1);
  assert.equal(loaded[0].title, 'Branch check');
  assert.equal(loaded[0].source, 'custom');
});

test('v54 application exposes Troubleshooting as an engineering workspace', () => {
  const app = readFileSync(new URL('../src/App.jsx', import.meta.url), 'utf8');
  const nav = readFileSync(new URL('../src/NavigationSidebar.jsx', import.meta.url), 'utf8');
  const troubleshooting = readFileSync(new URL('../src/Troubleshooting.jsx', import.meta.url), 'utf8');
  assert.match(app, /const Troubleshooting = lazy\(\(\) => import\('\.\/Troubleshooting\.jsx'\)\);/);
  assert.match(app, /view==='troubleshooting'/);
  assert.match(nav, /\['troubleshooting', 'Troubleshooting'/);
  assert.match(troubleshooting, /Preview|Proposed change|TYPED INTENT/);
  assert.match(troubleshooting, /Load case fault/);
});

test('v54 simulation reset restores a healthy live-network baseline', () => {
  const broken = injectLiveFault(createHealthyLiveLab(), 'static-route');
  const reset = resetLiveNetwork();
  assert.equal(reset.devices.R1.routes.some(route => route.prefix === '10.20.20.0/24'), true);
  assert.equal(broken.devices.R1.routes.some(route => route.prefix === '10.20.20.0/24'), false);
});
