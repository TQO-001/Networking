import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { formatTerminalTranscript, redactTerminalSecrets } from '../src/terminal/terminalUtils.js';

const root = fileURLToPath(new URL('../', import.meta.url));
const read = relative => fs.readFileSync(path.join(root, relative), 'utf8');

test('v64.0.6 terminal text preferences are persistent, bounded and shared by workspaces', () => {
  const prefs = read('src/terminal/terminalPreferences.js');
  const stateful = read('src/StatefulLab.jsx');
  const devices = read('src/Devices.jsx');
  assert.match(prefs, /FONT_SIZE_KEY = 'drillerBill\.terminal\.fontSize\.v1'/);
  assert.match(prefs, /MIN_FONT_SIZE = 16/);
  assert.match(prefs, /MAX_FONT_SIZE = 24/);
  assert.match(prefs, /:\s*18/);
  assert.match(prefs, /safeStorage\.setItem\(FONT_SIZE_KEY/);
  assert.match(stateful, /useTerminalPreferences\(\)/);
  assert.match(devices, /useTerminalPreferences\(\)/);
});

test('v64.0.6 simulator and physical device terminal support copy, zoom, follow and expand controls', () => {
  for (const file of ['src/StatefulLab.jsx', 'src/Devices.jsx']) {
    const source = read(file);
    assert.match(source, /<TerminalToolbar/);
    assert.match(source, /onFontSizeChange=\{changeTerminalFontSize\}/);
    assert.match(source, /onToggleAutoFollow=\{toggleTerminalAutoFollow\}/);
    assert.match(source, /onToggleExpanded=/);
    assert.match(source, /onCopy=/);
    assert.match(source, /aria-label=.*command/i);
  }
  const toolbar = read('src/terminal/TerminalToolbar.jsx');
  for (const label of ['Decrease terminal text size', 'Increase terminal text size', 'Copy output', 'Expand terminal']) assert.ok(toolbar.includes(label) || label === 'Expand terminal');
  assert.match(toolbar, /aria-pressed=\{autoFollow\}/);
  assert.match(toolbar, /aria-live="polite"/);
});

test('v64.0.6 terminal transcript copying redacts credential-bearing config lines', () => {
  const raw = [
    'hostname SW1',
    'enable secret 5 abc123hash',
    'username admin secret 0 plain-secret',
    'line vty 0 4',
    ' password 7 encoded-secret',
    'interface GigabitEthernet0/1',
  ].join('\n');
  const redacted = redactTerminalSecrets(raw);
  assert.match(redacted, /hostname SW1/);
  assert.doesNotMatch(redacted, /abc123hash|plain-secret|encoded-secret/);
  assert.equal(formatTerminalTranscript([{ command: 'show running-config', output: raw.split('\n') }], 'SW1#').includes('plain-secret'), false);
});

test('v64.0.6 terminal surfaces have readable responsive sizing and a focused expanded mode', () => {
  const css = read('src/ux-system.css');
  assert.match(css, /--terminal-font-size,18px/);
  assert.match(css, /\.terminal-v5\{height:min\(66vh,740px\)!important;min-height:500px!important/);
  assert.match(css, /\.device-terminal\{min-height:420px!important;max-height:65vh!important/);
  assert.match(css, /\.cli-workbench-v5\.terminal-workbench-expanded/);
  assert.match(css, /\.device-console\.terminal-workbench-expanded/);
  assert.match(css, /@media\(max-width:700px\)/);
});

test('v64.0.6 device workspace layouts become single-column and compact on narrow screens', () => {
  const css = read('src/ux-system.css');
  assert.match(css, /\.device-layout\{display:grid!important;grid-template-columns:minmax\(245px,\.31fr\) minmax\(0,1fr\)!important/);
  assert.match(css, /@media\(max-width:1050px\)\{[\s\S]*?\.device-layout\{grid-template-columns:minmax\(0,1fr\)!important/);
  assert.match(css, /\.device-metric-grid>div\{min-width:0!important;min-height:86px!important/);
});

