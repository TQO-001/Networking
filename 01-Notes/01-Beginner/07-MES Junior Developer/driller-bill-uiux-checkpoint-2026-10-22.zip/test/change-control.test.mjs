import test from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import { mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { buildPreflight, classifyIntentRisk, normalizeChangeRecord, reverseIntentHint } from '../src/core/change-control.js';
import { CONFIG_INTENTS, buildDeviceInventory, planIntent } from '../src/core/device-model.js';
import { createAgentServer } from '../agent/server.mjs';

const connectedInspection = { inspectedAt: new Date().toISOString(), overview: {}, interfaces: [], vlans: [], trunks: [], routes: [] };

async function jsonFetch(base, path, options = {}) {
  const response = await fetch(`${base}${path}`, {
    ...options,
    headers: { Accept: 'application/json', Authorization: 'Bearer test-token', ...(options.body ? { 'Content-Type': 'application/json' } : {}) },
  });
  const payload = await response.json();
  return { response, payload };
}

test('v59 classifies all catalog intents and puts access/security changes above documentation changes', () => {
  for (const intent of CONFIG_INTENTS) {
    const risk = classifyIntentRisk(intent);
    assert.ok(['low', 'medium', 'high', 'critical'].includes(risk.level), intent.id);
  }
  assert.equal(classifyIntentRisk({ type: 'set-interface-description' }).level, 'low');
  assert.equal(classifyIntentRisk({ type: 'create-vlan' }).level, 'medium');
  assert.equal(classifyIntentRisk({ type: 'set-trunk-policy' }).level, 'high');
  assert.equal(classifyIntentRisk({ type: 'configure-ssh' }).level, 'critical');
});

test('v59 preflight blocks invalid plans and missing sessions but exposes review checks', () => {
  const device = { id: 'SW1', kind: 'switch', connection: { type: 'ssh' } };
  const plan = planIntent({ type: 'create-vlan', fields: { id: 30, name: 'LAB' } }, device);
  const blocked = buildPreflight({ device, intent: { type: 'create-vlan', fields: { id: 30, name: 'LAB' } }, plan, connected: false });
  assert.equal(blocked.valid, false);
  assert.ok(blocked.blocking.includes('connected'));

  const good = buildPreflight({
    device, intent: { type: 'create-vlan', fields: { id: 30, name: 'LAB' } }, plan, connected: true,
    inspection: connectedInspection, diagnostics: { status: 'healthy' }, history: [{ id: 'baseline' }],
  });
  assert.equal(good.valid, true);
  assert.equal(good.risk.level, 'medium');
  assert.ok(good.checks.some(check => check.id === 'physical-confirmation'));
  assert.equal(good.checks.find(check => check.id === 'plan-valid').status, 'pass');
});

test('v59 change records persist only display-safe command metadata', () => {
  const record = normalizeChangeRecord({
    deviceId: 'SW1', deviceType: 'switch', transport: 'serial',
    intent: { type: 'create-local-user', fields: { username: 'ops', secret: 'top-secret' } },
    plan: { commands: ['username ops privilege 15 secret top-secret'], displayCommands: ['username ops privilege 15 secret ********'] },
    risk: { level: 'critical' }, status: 'preflighted',
  });
  assert.deepEqual(record.plan.commands, ['username ops privilege 15 secret ********']);
  assert.doesNotMatch(JSON.stringify(record), /top-secret/);
  assert.match(reverseIntentHint({ type: 'set-trunk-policy' }), /pre-change snapshot/i);
});

test('v59 preflight and apply responses never expose credential-bearing command text', async () => {
  const instance = createAgentServer({ host: '127.0.0.1', port: 0, token: 'test-token' });
  await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
  try {
    const base = `http://127.0.0.1:${instance.server.address().port}`;
    await jsonFetch(base, '/api/v1/devices/SW1/connect', { method: 'POST' });
    const intent = { type: 'create-local-user', fields: { username: 'audit-user', privilege: 15, secret: 'TOP-SECRET-DO-NOT-LEAK' } };
    const preflight = await jsonFetch(base, '/api/v1/devices/SW1/preflight-intent', { method: 'POST', body: JSON.stringify({ intent }) });
    assert.equal(preflight.response.status, 200);
    assert.doesNotMatch(JSON.stringify(preflight.payload), /TOP-SECRET-DO-NOT-LEAK/);
    const applied = await jsonFetch(base, '/api/v1/devices/SW1/apply-intent', { method: 'POST', body: JSON.stringify({ intent, changeId: preflight.payload.result.changeId }) });
    assert.equal(applied.response.status, 200);
    assert.doesNotMatch(JSON.stringify(applied.payload), /TOP-SECRET-DO-NOT-LEAK/);
  } finally {
    await new Promise(resolve => instance.server.close(resolve));
  }
});

test('v59 simulated agent preflight creates a change record and consumes it on apply', async () => {
  const instance = createAgentServer({ host: '127.0.0.1', port: 0, token: 'test-token' });
  await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
  try {
    const base = `http://127.0.0.1:${instance.server.address().port}`;
    const connected = await jsonFetch(base, '/api/v1/devices/SW1/connect', { method: 'POST' });
    assert.equal(connected.response.status, 200);
    const preflight = await jsonFetch(base, '/api/v1/devices/SW1/preflight-intent', {
      method: 'POST',
      body: JSON.stringify({ intent: { type: 'create-vlan', fields: { id: 31, name: 'CHANGE_CONTROL' } } }),
    });
    assert.equal(preflight.response.status, 200);
    assert.ok(preflight.payload.result.changeId);
    assert.equal(preflight.payload.result.preflight.risk.level, 'medium');
    assert.ok(preflight.payload.result.history.id);

    const apply = await jsonFetch(base, '/api/v1/devices/SW1/apply-intent', {
      method: 'POST',
      body: JSON.stringify({ changeId: preflight.payload.result.changeId, intent: { type: 'create-vlan', fields: { id: 31, name: 'CHANGE_CONTROL' } } }),
    });
    assert.equal(apply.response.status, 200);
    assert.equal(apply.payload.result.change.status, 'applied');
    assert.ok(apply.payload.result.change.preSnapshotId);
    assert.ok(apply.payload.result.change.postSnapshotId);

    const changes = await jsonFetch(base, '/api/v1/devices/SW1/change-history');
    assert.equal(changes.response.status, 200);
    assert.ok(changes.payload.history.some(item => item.id === apply.payload.result.change.id));
  } finally {
    await new Promise(resolve => instance.server.close(resolve));
  }
});

test('v59 change history survives agent restart without persisting raw intent commands', async () => {
  const dir = mkdtempSync(join(os.tmpdir(), 'driller-bill-v59-'));
  const stateFile = join(dir, 'agent-state.json');
  let instance = createAgentServer({ host: '127.0.0.1', port: 0, token: 'test-token', stateFile });
  await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
  try {
    const base = `http://127.0.0.1:${instance.server.address().port}`;
    await jsonFetch(base, '/api/v1/devices/SW1/connect', { method: 'POST' });
    const intent = { type: 'create-local-user', fields: { username: 'persist-user', privilege: 15, secret: 'PERSISTED-SECRET-MUST-NOT-APPEAR' } };
    const preflight = await jsonFetch(base, '/api/v1/devices/SW1/preflight-intent', { method: 'POST', body: JSON.stringify({ intent }) });
    assert.equal(preflight.response.status, 200);
    const applied = await jsonFetch(base, '/api/v1/devices/SW1/apply-intent', { method: 'POST', body: JSON.stringify({ intent, changeId: preflight.payload.result.changeId }) });
    assert.equal(applied.response.status, 200);
  } finally {
    await new Promise(resolve => instance.server.close(resolve));
  }

  instance = createAgentServer({ host: '127.0.0.1', port: 0, token: 'test-token', stateFile });
  await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
  try {
    const base = `http://127.0.0.1:${instance.server.address().port}`;
    const changes = await jsonFetch(base, '/api/v1/devices/SW1/change-history');
    assert.equal(changes.response.status, 200);
    assert.ok(changes.payload.history.some(item => item.intent?.fields?.secret === '[redacted]'));
    assert.doesNotMatch(JSON.stringify(changes.payload), /PERSISTED-SECRET-MUST-NOT-APPEAR/);
    assert.doesNotMatch(JSON.stringify(changes.payload), /username persist-user privilege 15 secret PERSISTED-SECRET-MUST-NOT-APPEAR/);
  } finally {
    await new Promise(resolve => instance.server.close(resolve));
    rmSync(dir, { recursive: true, force: true });
  }
});

test('v59 physical device mutation is rejected without a matching preflight approval record', async () => {
  const instance = createAgentServer({ host: '127.0.0.1', port: 0, token: 'test-token' });
  await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
  try {
    const base = `http://127.0.0.1:${instance.server.address().port}`;
    const added = await jsonFetch(base, '/api/v1/devices', { method: 'POST', body: JSON.stringify({
      id: 'PHYS-01', name: 'Physical', hostname: 'PHYS-01', kind: 'switch', host: '10.0.0.10', username: 'admin', passwordEnv: 'DB_TEST_PASSWORD', assumePrivileged: true,
    }) });
    assert.equal(added.response.status, 201);
    const attempt = await jsonFetch(base, '/api/v1/devices/PHYS-01/apply-intent', { method: 'POST', body: JSON.stringify({ intent: { type: 'create-vlan', fields: { id: 50, name: 'BLOCKED' } } }) });
    assert.equal(attempt.response.status, 409);
    assert.equal(attempt.payload.error, 'Device session is not connected.');
  } finally {
    await new Promise(resolve => instance.server.close(resolve));
  }
});

test('v59 change control module is exported through the core barrel', async () => {
  const core = await import('../src/core/index.js');
  assert.equal(typeof core.buildPreflight, 'function');
  assert.equal(typeof core.classifyIntentRisk, 'function');
});
