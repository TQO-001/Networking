import test from 'node:test';
import http from 'node:http';
import assert from 'node:assert/strict';
import { createAgentServer } from '../agent/server.mjs';
import { freshNetwork } from '../src/core/network-model.js';
import { createSimulatedDeviceAdapter, planIntent } from '../src/core/device-model.js';
import { createSshDeviceAdapter, runOpenSshSession } from '../agent/ssh-device-adapter.mjs';
import { configDiff, redactConfig } from '../src/core/config-history.js';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { buildInspectionReport, inspectSimulatedDevice } from '../src/core/device-inspection.js';
import { buildDeviceDiagnostics } from '../src/core/device-diagnostics.js';
import { DEVICE_SCENARIOS, verifyScenario } from '../src/core/device-scenarios.js';

async function jsonFetch(base, path, options = {}) {
  const response = await fetch(`${base}${path}`, {
    ...options,
    headers: { Accept: 'application/json', Authorization: 'Bearer test-token', ...(options.body ? { 'Content-Type': 'application/json' } : {}) },
  });
  const payload = await response.json();
  return { response, payload };
}

test('v43 device agent exposes a localhost protocol and protects device routes', async () => {
  const instance = createAgentServer({ host: '127.0.0.1', port: 0, token: 'test-token', allowedOrigins: ['http://localhost:5173'] });
  await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
  try {
    const port = instance.server.address().port;
    const base = `http://127.0.0.1:${port}`;
    const health = await jsonFetch(base, '/api/v1/health', { headers: { Accept: 'application/json' } });
    assert.equal(health.response.status, 200);
    assert.equal(health.payload.protocol, 'device-agent/3');
    const unauthorized = await fetch(`${base}/api/v1/devices`);
    assert.equal(unauthorized.status, 401);
    const inventory = await jsonFetch(base, '/api/v1/devices');
    assert.equal(inventory.response.status, 200);
    assert.ok(inventory.payload.devices.some(d => d.id === 'SW1'));
  } finally {
    await new Promise(resolve => instance.server.close(resolve));
  }
});

test('v43 agent session executes commands, applies intent and captures configuration', async () => {
  const instance = createAgentServer({ host: '127.0.0.1', port: 0, token: 'test-token' });
  await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
  try {
    const base = `http://127.0.0.1:${instance.server.address().port}`;
    const connected = await jsonFetch(base, '/api/v1/devices/SW1/connect', { method: 'POST' });
    assert.equal(connected.response.status, 200);
    const command = await jsonFetch(base, '/api/v1/devices/SW1/execute', { method: 'POST', body: JSON.stringify({ command: 'show vlan brief' }) });
    assert.equal(command.response.status, 200);
    assert.ok(command.payload.result.output.some(line => line.includes('10   USERS')));
    const plan = planIntent({ type: 'create-vlan', fields: { id: 30, name: 'LAB' } }, connected.payload.result.device);
    assert.equal(plan.valid, true);
    const applied = await jsonFetch(base, '/api/v1/devices/SW1/apply-intent', { method: 'POST', body: JSON.stringify({ intent: { type: 'create-vlan', fields: { id: 30, name: 'LAB' } } }) });
    assert.equal(applied.response.status, 200);
    assert.equal(applied.payload.result.applied, true);
    const snapshot = await jsonFetch(base, '/api/v1/devices/SW1/snapshot', { method: 'POST' });
    assert.equal(snapshot.response.status, 200);
    assert.match(snapshot.payload.result.runningConfig, /vlan 30/);
    assert.match(snapshot.payload.result.startupConfig, /vlan 30/);
    const refreshed = await jsonFetch(base, '/api/v1/devices');
    assert.ok(refreshed.payload.devices.find(d => d.id === 'SW1').vlanCount >= 4);
  } finally {
    await new Promise(resolve => instance.server.close(resolve));
  }
});

test('v43 simulated adapter remains compatible with direct intent execution', async () => {
  const adapter = createSimulatedDeviceAdapter(freshNetwork(), 'SW1');
  await adapter.connect();
  const result = await adapter.applyIntent({ type: 'create-vlan', fields: { id: 40, name: 'QA' } });
  assert.equal(result.applied, true);
  const snapshot = await adapter.snapshot();
  assert.match(snapshot.runningConfig, /vlan 40/);
});

test('v48 configuration intents include save-running-config and persist startup state', async () => {
  const adapter = createSimulatedDeviceAdapter(freshNetwork(), 'SW1');
  await adapter.connect();
  const plan = planIntent({ type: 'save-running-config', fields: {} }, { id: 'SW1', kind: 'switch' });
  assert.equal(plan.valid, true);
  assert.deepEqual(plan.commands, ['enable', 'write memory']);
  await adapter.applyIntent({ type: 'create-vlan', fields: { id: 88, name: 'SAVE_TEST' } });
  await adapter.applyIntent({ type: 'save-running-config', fields: {} });
  const snapshot = await adapter.snapshot();
  assert.match(snapshot.startupConfig, /vlan 88/);
});


test('v44 SSH adapter keeps secrets agent-side and executes a multi-command intent session', async () => {
  const calls = [];
  const adapter = createSshDeviceAdapter({
    id: 'REAL-SW1', name: 'REAL-SW1', hostname: 'REAL-SW1', kind: 'switch',
    host: '10.10.22.10', port: 22, username: 'netadmin', privateKeyPath: '/home/netadmin/.ssh/id_ed25519',
    assumePrivileged: true,
  }, {
    env: {},
    runSession: async (connection, options) => {
      calls.push({ connection, stdin: options.stdin });
      return { code: 0, stdout: 'Cisco IOS Software, Version 15.2(7)E\n', stderr: '' };
    },
  });

  const connected = await adapter.connect();
  assert.equal(connected.connected, true);
  assert.equal(connected.device.connection.type, 'ssh');
  assert.equal(connected.device.version, '15.2(7)E');
  const command = await adapter.execute('show vlan brief');
  assert.equal(command.command, 'show vlan brief');
  const applied = await adapter.applyIntent({ type: 'create-vlan', fields: { id: 30, name: 'LAB' } }, {
    valid: true,
    commands: ['enable', 'configure terminal', 'vlan 30', 'name LAB', 'end'],
    explanations: [],
  });
  assert.equal(applied.applied, true);
  assert.match(calls.at(-1).stdin, /vlan 30/);
  assert.match(calls.at(-1).stdin, /name LAB/);
  assert.doesNotMatch(calls.at(-1).stdin, /id_ed25519/);
});

test('v44 OpenSSH runner builds key-authenticated commands without exposing secrets', async () => {
  const { EventEmitter } = await import('node:events');
  let captured = null;
  const fakeSpawn = (command, args, options) => {
    captured = { command, args, options };
    const child = new EventEmitter();
    child.stdout = new EventEmitter();
    child.stderr = new EventEmitter();
    child.stdin = {
      write(value) { captured.stdin = value; },
      end() { queueMicrotask(() => { child.stdout.emit('data', Buffer.from('ok\\n')); child.emit('close', 0); }); },
    };
    child.kill = () => {};
    return child;
  };
  const result = await runOpenSshSession({
    host: '10.10.22.10', port: 22, username: 'netadmin', privateKeyPath: '/tmp/id_ed25519', strictHostKeyChecking: 'accept-new',
  }, { stdin: 'show version\\n', spawnImpl: fakeSpawn, env: {} });
  assert.equal(result.code, 0);
  assert.equal(captured.command, 'ssh');
  assert.ok(captured.args.includes('-i'));
  assert.ok(captured.args.includes('/tmp/id_ed25519'));
  assert.ok(captured.args.includes('-tt'));
  assert.match(captured.stdin, /show version/);
  assert.equal(Object.hasOwn(captured.options.env, 'DRILLER_BILL_ASKPASS_SECRET'), false);
});

test('v44 agent can register, inventory and remove a physical SSH device without storing its secret', async () => {
  const instance = createAgentServer({ host: '127.0.0.1', port: 0, token: 'test-token' });
  await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
  try {
    const base = `http://127.0.0.1:${instance.server.address().port}`;
    const added = await jsonFetch(base, '/api/v1/devices', { method: 'POST', body: JSON.stringify({
      id: 'REAL-SW1', name: 'Lab Switch', hostname: 'LAB-SW1', kind: 'switch',
      host: '10.10.22.10', port: 22, username: 'netadmin', passwordEnv: 'LAB_SSH_PASSWORD', assumePrivileged: true,
    }) });
    assert.equal(added.response.status, 201);
    assert.equal(added.payload.device.connection.type, 'ssh');
    assert.equal(added.payload.connection.passwordEnv, undefined);
    assert.equal(added.payload.connection.authentication, 'environment password');

    const inventory = await jsonFetch(base, '/api/v1/devices');
    const device = inventory.payload.devices.find(d => d.id === 'REAL-SW1');
    assert.ok(device);
    assert.equal(device.connection.status, 'ready');

    const removed = await jsonFetch(base, '/api/v1/devices/REAL-SW1', { method: 'DELETE' });
    assert.equal(removed.response.status, 200);
    const after = await jsonFetch(base, '/api/v1/devices');
    assert.equal(after.payload.devices.some(d => d.id === 'REAL-SW1'), false);
  } finally {
    await new Promise(resolve => instance.server.close(resolve));
  }
});


test('v45 configuration history produces stable redacted diffs', async () => {
  assert.equal(redactConfig('enable secret 0 supersecret\nusername admin secret another-secret').includes('supersecret'), false);
  const diff = configDiff('hostname SW1\nvlan 10\n name SALES', 'hostname SW1\nvlan 10\n name SALES\nvlan 20\n name LAB');
  assert.deepEqual(diff.added, ['vlan 20', ' name LAB']);
  assert.deepEqual(diff.removed, []);
  assert.equal(diff.addedCount, 2);
});

test('v45 agent records snapshots and exposes history plus running-config diff', async () => {
  const instance = createAgentServer({ host: '127.0.0.1', port: 0, token: 'test-token' });
  await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
  try {
    const base = `http://127.0.0.1:${instance.server.address().port}`;
    await jsonFetch(base, '/api/v1/devices/SW1/connect', { method: 'POST' });
    const baseline = await jsonFetch(base, '/api/v1/devices/SW1/snapshot', { method: 'POST' });
    assert.equal(baseline.response.status, 200);
    assert.equal(baseline.payload.result.history.summary, 'Baseline configuration captured.');
    const applied = await jsonFetch(base, '/api/v1/devices/SW1/apply-intent', { method: 'POST', body: JSON.stringify({ intent: { type: 'create-vlan', fields: { id: 77, name: 'HISTORY_TEST' } } }) });
    assert.equal(applied.response.status, 200);
    assert.equal(applied.payload.result.history.source, 'intent');
    assert.match(applied.payload.result.history.summary, /added/);
    const history = await jsonFetch(base, '/api/v1/devices/SW1/config-history');
    assert.equal(history.response.status, 200);
    assert.equal(history.payload.count, 2);
    const from = history.payload.history[0].id;
    const to = history.payload.history[1].id;
    const comparison = await jsonFetch(base, `/api/v1/devices/SW1/config-diff?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`);
    assert.equal(comparison.response.status, 200);
    assert.equal(comparison.payload.diff.changed, true);
    assert.ok(comparison.payload.diff.added.some(line => line.includes('vlan 77')));
  } finally {
    await new Promise(resolve => instance.server.close(resolve));
  }
});


test('v46 simulated inspection exposes structured device state', async () => {
  const report = inspectSimulatedDevice(freshNetwork(), 'SW1');
  assert.equal(report.version, '1.0.0');
  assert.equal(report.source, 'simulated');
  assert.ok(report.overview.vlanCount >= 3);
  assert.ok(report.interfaces.some(item => item.name === 'GigabitEthernet0/24'));
  assert.ok(report.trunks.some(item => item.interface === 'GigabitEthernet0/24'));
});

test('v46 SSH inspection parses standard IOS show-command evidence', async () => {
  const outputs = {
    'show version': 'Cisco IOS Software, Version 17.12.04, RELEASE SOFTWARE (fc6)\nSW-REAL-1 uptime is 3 days',
    'show ip interface brief': 'Interface              IP-Address      OK? Method Status                Protocol\nGigabitEthernet0/1     10.0.0.1        YES manual up                    up\nGigabitEthernet0/2     unassigned      YES unset  administratively down down',
    'show vlan brief': 'VLAN Name                             Status    Ports\n---- -------------------------------- --------- -------------------------------\n1    default                          active    Gi0/1\n10   SALES                            active    Gi0/2',
    'show interfaces trunk': 'Port        Mode             Encapsulation  Status        Native vlan\nGi0/24       on               802.1q         trunking      99',
    'show ip route': 'O    10.20.0.0/16 [110/20] via 10.0.0.2, 00:00:10, GigabitEthernet0/1',
  };
  const report = buildInspectionReport({ device: { id: 'REAL-SW1', kind: 'switch', vendor: 'Cisco', platform: 'IOS-style' }, outputs, source: 'ssh' });
  assert.equal(report.overview.version, '17.12.04');
  assert.equal(report.overview.hostname, 'SW-REAL-1');
  assert.equal(report.overview.upInterfaceCount, 1);
  assert.equal(report.vlans.length, 2);
  assert.equal(report.trunks[0].nativeVlan, 99);
  assert.equal(report.routes[0].network, '10.20.0.0/16');
});

test('v46 agent persists registered devices, histories and inspections across restarts', async () => {
  const root = await mkdtemp(join(tmpdir(), 'driller-bill-agent-v46-'));
  const stateFile = join(root, 'agent-state.json');
  const start = async () => {
    const instance = createAgentServer({ host: '127.0.0.1', port: 0, token: 'test-token', stateFile });
    await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
    return instance;
  };
  let first;
  try {
    first = await start();
    const base = `http://127.0.0.1:${first.server.address().port}`;
    await jsonFetch(base, '/api/v1/devices', { method: 'POST', body: JSON.stringify({
      id: 'REAL-PERSIST', name: 'Persistent Lab Switch', hostname: 'PERSIST-SW', kind: 'switch',
      host: '10.10.22.99', port: 22, username: 'netadmin', passwordEnv: 'PERSIST_SSH_PASSWORD', assumePrivileged: true,
    }) });
    await jsonFetch(base, '/api/v1/devices/SW1/connect', { method: 'POST' });
    const snapshot = await jsonFetch(base, '/api/v1/devices/SW1/snapshot', { method: 'POST' });
    assert.equal(snapshot.response.status, 200);
    const inspect = await jsonFetch(base, '/api/v1/devices/SW1/inspect', { method: 'POST' });
    assert.equal(inspect.response.status, 200);
    await new Promise(resolve => first.server.close(resolve));

    const raw = await readFile(stateFile, 'utf8');
    assert.match(raw, /REAL-PERSIST/);
    assert.doesNotMatch(raw, /actual-secret-value/);

    const second = await start();
    try {
      const base2 = `http://127.0.0.1:${second.server.address().port}`;
      const inventory = await jsonFetch(base2, '/api/v1/devices');
      assert.ok(inventory.payload.devices.some(device => device.id === 'REAL-PERSIST'));
      const history = await jsonFetch(base2, '/api/v1/devices/SW1/config-history');
      assert.equal(history.payload.count, 1);
      const savedInspection = await jsonFetch(base2, '/api/v1/devices/SW1/inspection');
      assert.equal(savedInspection.response.status, 200);
      assert.equal(savedInspection.payload.report.source, 'simulated');
    } finally {
      await new Promise(resolve => second.server.close(resolve));
    }
  } finally {
    if (first?.server.listening) await new Promise(resolve => first.server.close(resolve));
    await rm(root, { recursive: true, force: true });
  }
});


test('v47 diagnostics classify interface state and startup alignment', () => {
  const inspection = inspectSimulatedDevice(freshNetwork(), 'SW1');
  const diagnostics = buildDeviceDiagnostics({
    device: { id: 'SW1', kind: 'switch' },
    inspection,
    connected: true,
    history: [{ id: 'snap-1', capturedAt: '2026-10-04T08:00:00Z', label: 'Baseline', source: 'manual', runningConfig: 'hostname SW1', startupConfig: 'hostname SW1' }],
  });
  assert.equal(diagnostics.status, 'healthy');
  assert.equal(diagnostics.checks.find(item => item.id === 'connection').status, 'good');
  assert.equal(diagnostics.checks.find(item => item.id === 'config-save').status, 'good');
  assert.equal(diagnostics.latestSnapshot.runningStartupAligned, true);
});

test('v47 diagnostics expose unsaved configuration and recent changes', () => {
  const inspection = inspectSimulatedDevice(freshNetwork(), 'SW1');
  const diagnostics = buildDeviceDiagnostics({
    device: { id: 'SW1', kind: 'switch' },
    inspection,
    connected: true,
    history: [
      { id: 'snap-1', capturedAt: '2026-10-04T08:00:00Z', label: 'Baseline', source: 'manual', runningConfig: 'hostname SW1\nvlan 10', startupConfig: 'hostname SW1\nvlan 10' },
      { id: 'snap-2', capturedAt: '2026-10-04T08:05:00Z', label: 'After VLAN change', source: 'intent', runningConfig: 'hostname SW1\nvlan 10\nvlan 20', startupConfig: 'hostname SW1\nvlan 10' },
    ],
  });
  const saveCheck = diagnostics.checks.find(item => item.id === 'config-save');
  assert.equal(saveCheck.status, 'warning');
  assert.equal(diagnostics.latestSnapshot.runningStartupAligned, false);
  assert.equal(diagnostics.recentChanges.addedCount, 1);
  assert.match(diagnostics.recentChanges.added[0], /vlan 20/);
});

test('v47 agent diagnostics endpoint returns persisted history-aware engineering health', async () => {
  const instance = createAgentServer({ host: '127.0.0.1', port: 0, token: 'test-token' });
  await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
  try {
    const base = `http://127.0.0.1:${instance.server.address().port}`;
    await jsonFetch(base, '/api/v1/devices/SW1/connect', { method: 'POST' });
    await jsonFetch(base, '/api/v1/devices/SW1/snapshot', { method: 'POST' });
    await jsonFetch(base, '/api/v1/devices/SW1/inspect', { method: 'POST' });
    const result = await jsonFetch(base, '/api/v1/devices/SW1/diagnostics');
    assert.equal(result.response.status, 200);
    assert.equal(result.payload.diagnostics.deviceId, 'SW1');
    assert.equal(typeof result.payload.diagnostics.score, 'number');
    assert.ok(Array.isArray(result.payload.diagnostics.checks));
    assert.equal(result.payload.diagnostics.historyCount, 1);
  } finally {
    await new Promise(resolve => instance.server.close(resolve));
  }
});


test('v49 richer device intents plan interface operations and bulk access changes', () => {
  const target = { id: 'SW1', kind: 'switch' };
  const description = planIntent({ type: 'set-interface-description', fields: { interface: 'Gi0/1', description: 'USER DESK 01' } }, target);
  assert.deepEqual(description.commands, ['enable', 'configure terminal', 'interface GigabitEthernet0/1', 'description USER DESK 01', 'end']);
  const state = planIntent({ type: 'set-interface-state', fields: { interface: 'Gi0/1', state: 'down' } }, target);
  assert.ok(state.commands.includes('shutdown'));
  const bulk = planIntent({ type: 'assign-access-vlan-bulk', fields: { interfaces: 'Gi0/1, Gi0/2, Gi0/3', vlan: 20 } }, target);
  assert.equal(bulk.valid, true);
  assert.match(bulk.commands.join('\n'), /interface GigabitEthernet0\/1/);
  assert.match(bulk.commands.join('\n'), /interface GigabitEthernet0\/3/);
  const trunk = planIntent({ type: 'set-trunk-policy', fields: { interface: 'Gi0/24', nativeVlan: 99, vlans: '10,20,99' } }, target);
  assert.deepEqual(trunk.commands.slice(-4), ['switchport mode trunk', 'switchport trunk native vlan 99', 'switchport trunk allowed vlan 10,20,99', 'end']);
});

test('v49 simulated inspection exposes interface documentation and actual VLAN membership', async () => {
  const adapter = createSimulatedDeviceAdapter(freshNetwork(), 'SW1');
  await adapter.connect();
  await adapter.applyIntent({ type: 'set-interface-description', fields: { interface: 'Gi0/1', description: 'USER DESK 01' } });
  await adapter.applyIntent({ type: 'assign-access-vlan-bulk', fields: { interfaces: 'Gi0/1,Gi0/2', vlan: 20 } });
  await adapter.applyIntent({ type: 'set-trunk-policy', fields: { interface: 'Gi0/24', nativeVlan: 99, vlans: '10,20,99' } });
  const report = await adapter.inspect();
  const users = report.vlans.find(item => item.id === 20);
  assert.equal(users.name, 'SERVERS');
  assert.ok(users.ports.includes('Gi0/1'));
  assert.equal(report.interfaces.find(item => item.name === 'GigabitEthernet0/1').description, 'USER DESK 01');
  assert.ok(report.trunks.find(item => item.interface === 'GigabitEthernet0/24').allowedVlans.includes(99));
});

test('v49 access switch baseline scenario verifies from structured state', async () => {
  const adapter = createSimulatedDeviceAdapter(freshNetwork(), 'SW1');
  await adapter.connect();
  const scenario = DEVICE_SCENARIOS.find(item => item.id === 'access-switch-baseline');
  for (const step of scenario.steps) await adapter.applyIntent(step.intent);
  const inspection = await adapter.inspect();
  const snapshot = await adapter.snapshot();
  const diagnostics = buildDeviceDiagnostics({
    device: { id: 'SW1', kind: 'switch' },
    inspection,
    connected: true,
    history: [{ id: 'scenario-final', capturedAt: snapshot.capturedAt, label: 'Scenario final', source: 'intent', runningConfig: snapshot.runningConfig, startupConfig: snapshot.startupConfig }],
  });
  const verification = verifyScenario(scenario, { inspection, diagnostics });
  assert.equal(verification.valid, true);
  assert.equal(verification.completed, 6);
});

test('v50 router intents validate and render static route operations', () => {
  const target = { id: 'R1', kind: 'router' };
  const add = planIntent({ type: 'add-static-route', fields: { network: '10.20.20.0', mask: '255.255.255.0', nextHop: '10.0.12.2' } }, target);
  assert.equal(add.valid, true);
  assert.deepEqual(add.commands, ['enable', 'configure terminal', 'ip route 10.20.20.0 255.255.255.0 10.0.12.2', 'end']);
  const remove = planIntent({ type: 'remove-static-route', fields: { network: '10.20.20.0', mask: '255.255.255.0', nextHop: '10.0.12.2' } }, target);
  assert.equal(remove.valid, true);
  assert.match(remove.commands.join('\n'), /no ip route 10\.20\.20\.0 255\.255\.255\.0 10\.0\.12\.2/);
  const invalid = planIntent({ type: 'add-static-route', fields: { network: '999.20.20.0', mask: '255.255.255.0', nextHop: '10.0.12.2' } }, target);
  assert.equal(invalid.valid, false);
});

test('v50 simulated static route becomes visible in structured routing state', async () => {
  const adapter = createSimulatedDeviceAdapter(freshNetwork(), 'R1');
  await adapter.connect();
  await adapter.applyIntent({ type: 'add-static-route', fields: { network: '10.20.20.0', mask: '255.255.255.0', nextHop: '10.0.12.2' } });
  const report = await adapter.inspect();
  const route = report.routes.find(item => item.network === '10.20.20.0/24');
  assert.ok(route);
  assert.equal(route.code, 'S');
  assert.equal(route.nextHop, '10.0.12.2');
  const snapshot = await adapter.snapshot();
  assert.match(snapshot.runningConfig, /ip route 10\.20\.20\.0 255\.255\.255\.0 10\.0\.12\.2/);
});

test('v50 routed-edge recovery scenario verifies route, uplink and saved state', async () => {
  const adapter = createSimulatedDeviceAdapter(freshNetwork(), 'R1');
  await adapter.connect();
  const scenario = DEVICE_SCENARIOS.find(item => item.id === 'routed-edge-recovery');
  for (const step of scenario.steps) await adapter.applyIntent(step.intent);
  const inspection = await adapter.inspect();
  const snapshot = await adapter.snapshot();
  const diagnostics = buildDeviceDiagnostics({
    device: { id: 'R1', kind: 'router' },
    inspection,
    connected: true,
    history: [{ id: 'scenario-final', capturedAt: snapshot.capturedAt, label: 'Scenario final', source: 'intent', runningConfig: snapshot.runningConfig, startupConfig: snapshot.startupConfig }],
  });
  const verification = verifyScenario(scenario, { inspection, diagnostics });
  assert.equal(verification.valid, true);
  assert.equal(verification.completed, 3);
});

test('physical raw execute rejects destructive commands and records an audit trail', async () => {
  const calls = [];
  const factory = (config) => ({
    getDevice: () => ({
      id: config.id, name: config.name, hostname: config.hostname, kind: config.kind,
      connection: { type: 'ssh', status: 'ready' },
    }),
    async connect() {
      return { connected: true, device: this.getDevice() };
    },
    async execute(command) {
      calls.push(command);
      return { command, output: ['safe output'] };
    },
    async disconnect() { return { disconnected: true }; },
  });
  const instance = createAgentServer({
    host: '127.0.0.1', port: 0, token: 'test-token',
    sshAdapterFactory: factory,
  });
  await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
  try {
    const base = `http://127.0.0.1:${instance.server.address().port}`;
    const registered = await jsonFetch(base, '/api/v1/devices', { method: 'POST', body: JSON.stringify({
      id: 'REAL-SW1', name: 'Lab Switch', hostname: 'LAB-SW1', kind: 'switch',
      host: '10.10.22.10', port: 22, username: 'netadmin', passwordEnv: 'LAB_SSH_PASSWORD', assumePrivileged: true,
    }) });
    assert.equal(registered.response.status, 201);
    const connected = await jsonFetch(base, '/api/v1/devices/REAL-SW1/connect', { method: 'POST' });
    assert.equal(connected.response.status, 200);

    const blocked = await jsonFetch(base, '/api/v1/devices/REAL-SW1/execute', {
      method: 'POST', body: JSON.stringify({ command: 'reload' }),
    });
    assert.equal(blocked.response.status, 403);
    assert.equal(blocked.payload.code, 'CHANGE_CONTROL_REQUIRED');
    assert.deepEqual(calls, []);

    const allowed = await jsonFetch(base, '/api/v1/devices/REAL-SW1/execute', {
      method: 'POST', body: JSON.stringify({ command: 'show version' }),
    });
    assert.equal(allowed.response.status, 200);
    assert.deepEqual(calls, ['show version']);

    const history = await jsonFetch(base, '/api/v1/devices/REAL-SW1/execute-history');
    assert.equal(history.response.status, 200);
    assert.equal(history.payload.count, 2);
    assert.equal(history.payload.history[0].outcome, 'blocked');
    assert.equal(history.payload.history[1].outcome, 'allowed');
    assert.match(history.payload.history[0].command, /reload/);
  } finally {
    await new Promise(resolve => instance.server.close(resolve));
  }
});

test('device agent rejects untrusted Host headers and request bodies above 1 MiB', async () => {
  const instance = createAgentServer({ host: '127.0.0.1', port: 0, token: 'test-token' });
  await new Promise((resolve, reject) => instance.server.listen(0, '127.0.0.1', resolve).once('error', reject));
  try {
    const base = `http://127.0.0.1:${instance.server.address().port}`;
    const spoofed = await new Promise((resolve, reject) => {
      const request = http.request({
        hostname: '127.0.0.1', port: instance.server.address().port,
        path: '/api/v1/devices', method: 'GET',
        headers: { Authorization: 'Bearer test-token', Host: 'attacker.example' },
      }, response => {
        response.resume();
        response.on('end', () => resolve(response));
      });
      request.on('error', reject);
      request.end();
    });
    assert.equal(spoofed.statusCode, 400);

    const body = JSON.stringify({ name: 'x'.repeat(1024 * 1024 + 32) });
    const oversized = await fetch(`${base}/api/v1/devices`, {
      method: 'POST',
      headers: { Authorization: 'Bearer test-token', 'Content-Type': 'application/json' },
      body,
    });
    assert.equal(oversized.status, 413);
  } finally {
    await new Promise(resolve => instance.server.close(resolve));
  }
});
