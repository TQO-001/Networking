import { chmod, mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync, chmodSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { homedir } from 'node:os';

export const AGENT_STATE_VERSION = '1.0.0';

export function defaultAgentStatePath() {
  return process.env.DRILLER_BILL_AGENT_STATE_FILE || join(homedir(), '.driller-bill', 'agent-state.json');
}

function emptyState() {
  return { version: AGENT_STATE_VERSION, updatedAt: null, devices: {}, configHistory: {}, inspections: {}, changeHistory: {}, discoveries: {} };
}

function normalizeState(value = {}) {
  return {
    version: AGENT_STATE_VERSION,
    updatedAt: value.updatedAt || null,
    devices: value.devices && typeof value.devices === 'object' ? value.devices : {},
    configHistory: value.configHistory && typeof value.configHistory === 'object' ? value.configHistory : {},
    inspections: value.inspections && typeof value.inspections === 'object' ? value.inspections : {},
    changeHistory: value.changeHistory && typeof value.changeHistory === 'object' ? value.changeHistory : {},
    discoveries: value.discoveries && typeof value.discoveries === 'object' ? value.discoveries : {},
  };
}

export function loadAgentStateSync(filePath = defaultAgentStatePath()) {
  if (!filePath || !existsSync(filePath)) return { state: emptyState(), path: filePath, recovered: false };
  try {
    const parsed = JSON.parse(readFileSync(filePath, 'utf8'));
    return { state: normalizeState(parsed), path: filePath, recovered: false };
  } catch (error) {
    return { state: emptyState(), path: filePath, recovered: true, error: error instanceof Error ? error.message : String(error) };
  }
}

export function saveAgentStateSync(filePath, state) {
  const normalized = normalizeState(state);
  normalized.updatedAt = new Date().toISOString();
  mkdirSync(dirname(filePath), { recursive: true, mode: 0o700 });
  const temp = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  writeFileSync(temp, JSON.stringify(normalized, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
  try { chmodSync(temp, 0o600); } catch {}
  renameSync(temp, filePath);
  return normalized;
}

export async function saveAgentState(filePath, state) {
  const normalized = normalizeState(state);
  normalized.updatedAt = new Date().toISOString();
  await mkdir(dirname(filePath), { recursive: true, mode: 0o700 });
  const temp = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  await writeFile(temp, JSON.stringify(normalized, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
  try { await chmod(temp, 0o600); } catch {}
  await rename(temp, filePath);
  return normalized;
}
