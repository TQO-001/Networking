import http from 'node:http';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { freshNetwork } from '../src/core/network-model.js';
import { isReadOnlyDeviceCommand } from './command-policy.mjs';
import { createSimulatedDeviceAdapter, deviceAgentContract, buildDeviceInventory, externalDeviceRecord, validateDeviceConnection, planIntent } from '../src/core/device-model.js';
import { createSshDeviceAdapter, validateSshConnection, sshConnectionSummary } from './ssh-device-adapter.mjs';
import { createSerialDeviceAdapter, validateSerialConnection, serialConnectionSummary } from './serial-device-adapter.mjs';
import { configDiff, snapshotRecord, summarizeConfigDiff, redactConfig } from '../src/core/config-history.js';
import { buildPreflight, normalizeChangeRecord, summarizeChangeRecord, PREFLIGHT_TTL_MS } from '../src/core/change-control.js';
import { inspectSimulatedDevice } from '../src/core/device-inspection.js';
import { buildDeviceDiagnostics } from '../src/core/device-diagnostics.js';
import { buildNetworkDiscoveryReport, DISCOVERY_COMMANDS } from '../src/core/network-discovery.js';
import { defaultAgentStatePath, loadAgentStateSync, saveAgentStateSync } from './state-store.mjs';

export const DEFAULT_AGENT_PORT = 8788;
export const DEFAULT_AGENT_HOST = '127.0.0.1';
export const AGENT_PROTOCOL = 'device-agent/3';

function json(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function cors(res, origin, allowedOrigins) {
  if (origin && allowedOrigins.has(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

const MAX_AGENT_BODY_BYTES = 1024 * 1024;

class AgentRequestError extends Error {
  constructor(statusCode, message) { super(message); this.statusCode = statusCode; }
}

async function readJson(req, maxBytes = MAX_AGENT_BODY_BYTES) {
  const advertisedLength = Number(req.headers['content-length'] || 0);
  if (advertisedLength > maxBytes) {
    req.resume();
    throw new AgentRequestError(413, `Request body exceeds the ${maxBytes}-byte limit.`);
  }
  const chunks = [];
  let totalBytes = 0;
  for await (const chunk of req) {
    totalBytes += chunk.length;
    if (totalBytes > maxBytes) {
      req.resume();
      throw new AgentRequestError(413, `Request body exceeds the ${maxBytes}-byte limit.`);
    }
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw new AgentRequestError(400, 'Request body must be valid JSON.'); }
}

function bearer(req) {
  const value = req.headers.authorization || '';
  return value.startsWith('Bearer ') ? value.slice(7) : '';
}

function authorized(req, token) {
  if (!token) return false;
  const expected = Buffer.from(String(token));
  const received = Buffer.from(bearer(req));
  if (!expected.length || received.length !== expected.length) return false;
  return timingSafeEqual(received, expected);
}

function hasSafeLocalHostHeader(value = '') {
  const match = String(value).toLowerCase().match(/^(localhost|127\.0\.0\.1|\[::1\])(?::(\d{1,5}))?$/);
  if (!match) return false;
  if (match[2] === undefined) return true;
  const port = Number(match[2]);
  return Number.isInteger(port) && port >= 1 && port <= 65535;
}

function advertised(device, connected) {
  return {
    ...device,
    connection: {
      ...device.connection,
      status: connected ? 'connected' : (device.connection?.status || 'ready'),
    },
  };
}

function publicConnection(connection = {}) {
  const { passwordEnv, enablePasswordEnv, privateKeyPath, ...safe } = connection;
  return { ...safe, authentication: connection.connectionType === 'serial' ? 'local serial console' : connection.passwordEnv ? 'environment password' : connection.privateKeyPath ? 'private key' : 'ssh agent/default key' };
}

export function createAgentServer({
  token = process.env.DRILLER_BILL_AGENT_TOKEN || randomBytes(24).toString('hex'),
  host = DEFAULT_AGENT_HOST,
  port = Number(process.env.DRILLER_BILL_AGENT_PORT || DEFAULT_AGENT_PORT),
  allowedOrigins = process.env.DRILLER_BILL_AGENT_ALLOWED_ORIGINS?.split(',').map(value => value.trim()).filter(Boolean)
    || [
      'http://localhost:5173', 'http://127.0.0.1:5173',
      'http://localhost:4173', 'http://127.0.0.1:4173',
      'http://localhost:8080', 'http://127.0.0.1:8080',
    ],
  initialState = freshNetwork(),
  stateFile = null,
  sshAdapterFactory = createSshDeviceAdapter,
  serialAdapterFactory = createSerialDeviceAdapter,
} = {}) {
  const state = initialState;
  const adapters = new Map();
  const connections = new Set();
  const external = new Map();
  const origins = new Set(allowedOrigins);
  const configHistory = new Map();
  const inspections = new Map();
  const changeHistory = new Map();
  const discoveries = new Map();
  const executeHistory = new Map();
  const pendingChanges = new Map();
  const persisted = stateFile ? loadAgentStateSync(stateFile) : { state: { devices: {}, configHistory: {}, inspections: {}, changeHistory: {}, executeHistory: {}, discoveries: {} }, recovered: false, error: null };
  for (const [id, config] of Object.entries(persisted.state.devices || {})) external.set(id, config);
  for (const [id, history] of Object.entries(persisted.state.configHistory || {})) configHistory.set(id, Array.isArray(history) ? history : []);
  for (const [id, report] of Object.entries(persisted.state.inspections || {})) inspections.set(id, report);
  for (const [id, history] of Object.entries(persisted.state.changeHistory || {})) changeHistory.set(id, Array.isArray(history) ? history : []);
  for (const [id, history] of Object.entries(persisted.state.executeHistory || {})) executeHistory.set(id, Array.isArray(history) ? history : []);
  for (const [id, report] of Object.entries(persisted.state.discoveries || {})) discoveries.set(id, report);

  const persist = () => {
    if (!stateFile) return;
    saveAgentStateSync(stateFile, {
      devices: Object.fromEntries(external.entries()),
      configHistory: Object.fromEntries(configHistory.entries()),
      inspections: Object.fromEntries(inspections.entries()),
      changeHistory: Object.fromEntries(changeHistory.entries()),
      executeHistory: Object.fromEntries(executeHistory.entries()),
      discoveries: Object.fromEntries(discoveries.entries()),
    });
  };

  const recordSnapshot = async (deviceId, source = 'manual', label = '') => {
    const adapter = getAdapter(deviceId);
    if (!adapter) throw new Error(`Device ${deviceId} not found.`);
    const snapshot = await adapter.snapshot();
    const records = configHistory.get(deviceId) || [];
    const previous = records.at(-1);
    const diff = configDiff(previous?.runningConfig || '', snapshot.runningConfig || '');
    const record = snapshotRecord(snapshot, {
      source,
      label: label || (source === 'intent' ? 'After configuration intent' : 'Configuration snapshot'),
      summary: previous ? summarizeConfigDiff(diff) : 'Baseline configuration captured.',
    });
    const safeSnapshot = {
      deviceId: record.deviceId,
      capturedAt: record.capturedAt,
      runningConfig: record.runningConfig,
      startupConfig: record.startupConfig,
    };
    if (previous && previous.runningConfig === record.runningConfig && previous.startupConfig === record.startupConfig) {
      return { snapshot: safeSnapshot, record: previous, diff, duplicate: true };
    }
    const stored = [...records, record].slice(-50);
    configHistory.set(deviceId, stored);
    persist();
    return { snapshot: safeSnapshot, record, diff, duplicate: false };
  };

  const historyFor = (deviceId) => configHistory.get(deviceId) || [];
  const changesFor = (deviceId) => changeHistory.get(deviceId) || [];

  const cleanExpiredPreflights = () => {
    const cutoff = Date.now() - PREFLIGHT_TTL_MS;
    for (const [id, pending] of pendingChanges.entries()) {
      const created = Date.parse(pending.createdAt || '');
      if (!Number.isFinite(created) || created < cutoff) pendingChanges.delete(id);
    }
  };

  const makePreflight = async (deviceId, intent) => {
    cleanExpiredPreflights();
    const adapter = getAdapter(deviceId);
    const device = inventory().find(item => item.id === deviceId);
    if (!adapter || !device) throw new Error(`Device ${deviceId} not found.`);
    if (!connections.has(deviceId)) throw new Error('Device session is not connected.');
    const plan = planIntent(intent, device);
    if (!plan.valid) return { valid: false, plan, preflight: buildPreflight({ device, intent, plan, connected: false, inspection: inspections.get(deviceId), diagnostics: null, history: historyFor(deviceId) }) };
    const inspection = await adapter.inspect();
    inspections.set(deviceId, inspection);
    const diagnostics = buildDeviceDiagnostics({ device, inspection, history: historyFor(deviceId), connected: true });
    const preSnapshot = await recordSnapshot(deviceId, 'preflight', `Before ${intent.type || 'configuration'} intent`);
    const preflight = buildPreflight({ device, intent, plan, connected: true, inspection, diagnostics, history: historyFor(deviceId) });
    const changeId = `chg-${Date.now().toString(36)}-${randomBytes(6).toString('hex')}`;
    const record = normalizeChangeRecord({
      id: changeId, deviceId, deviceType: device.kind, transport: device.connection?.type, intent,
      status: preflight.valid ? 'preflighted' : 'blocked', createdAt: preflight.generatedAt, preflightAt: preflight.generatedAt,
      preSnapshotId: preSnapshot.record?.id || null,
      plan: { commands: [], displayCommands: plan.displayCommands },
      errors: preflight.blocking,
    });
    pendingChanges.set(changeId, {
      createdAt: preflight.generatedAt, expiresAt: Date.now() + PREFLIGHT_TTL_MS, deviceId, intent: JSON.parse(JSON.stringify(intent)),
      record, preflight, plan, preSnapshot: preSnapshot.record,
    });
    const list = [...changesFor(deviceId), record].slice(-100);
    changeHistory.set(deviceId, list);
    persist();
    const safePlan = { valid: plan.valid, errors: plan.errors || [], displayCommands: plan.displayCommands || [], explanations: plan.explanations || [] };
    return { valid: preflight.valid, changeId, expiresAt: new Date(Date.now() + PREFLIGHT_TTL_MS).toISOString(), preflight, plan: safePlan, inspection, diagnostics, snapshot: preSnapshot.snapshot, history: preSnapshot.record, change: record };
  };

  const appendExecuteAudit = (deviceId, { command, outcome, transport }) => {
    const records = executeHistory.get(deviceId) || [];
    const record = {
      id: `exec-${Date.now().toString(36)}-${randomBytes(4).toString('hex')}`,
      timestamp: new Date().toISOString(),
      command: redactConfig(String(command || '')),
      outcome,
      transport,
    };
    executeHistory.set(deviceId, [...records, record].slice(-200));
    persist();
    return record;
  };

  const getAdapter = (deviceId) => {
    if (external.has(deviceId)) {
      const config = external.get(deviceId);
      if (!adapters.has(deviceId)) {
        adapters.set(deviceId, config.connectionType === 'serial'
          ? serialAdapterFactory(config)
          : sshAdapterFactory(config));
      }
      return adapters.get(deviceId);
    }
    if (!state.devices?.[deviceId]) return null;
    if (!adapters.has(deviceId)) adapters.set(deviceId, createSimulatedDeviceAdapter(state, deviceId));
    return adapters.get(deviceId);
  };

  const inventory = () => {
    const simulated = buildDeviceInventory(state).map(baseDevice => {
      const adapter = getAdapter(baseDevice.id);
      const currentState = adapter?.getState?.() || state;
      const inventoryDevice = buildDeviceInventory(currentState).find(device => device.id === baseDevice.id) || baseDevice;
      const latestInspection = inspections.get(baseDevice.id);
      return advertised({ ...inventoryDevice, connection: baseDevice.connection, inspection: latestInspection ? { inspectedAt: latestInspection.inspectedAt, source: latestInspection.source, signalCount: latestInspection.signals?.length || 0 } : null }, connections.has(baseDevice.id));
    });
    const physical = [...external.values()].map(config => {
      const adapter = adapters.get(config.id);
      const device = adapter?.getDevice?.() || externalDeviceRecord(config);
      const latestInspection = inspections.get(config.id);
      return advertised({ ...device, inspection: latestInspection ? { inspectedAt: latestInspection.inspectedAt, source: latestInspection.source, signalCount: latestInspection.signals?.length || 0 } : null }, connections.has(config.id));
    });
    return [...simulated, ...physical];
  };

  const route = async (req, res) => {
    if (!hasSafeLocalHostHeader(req.headers.host)) return json(res, 400, { ok: false, error: 'Invalid Host header. The Device Agent accepts loopback hosts only.' });
    cors(res, req.headers.origin, origins);
    if (req.method === 'OPTIONS') return json(res, 204, {});

    const url = new URL(req.url, `http://${host}:${port}`);
    const parts = url.pathname.split('/').filter(Boolean);

    if (req.method === 'GET' && url.pathname === '/api/v1/health') {
      return json(res, 200, { ok: true, protocol: AGENT_PROTOCOL, service: 'driller-bill-device-agent', host, port });
    }
    if (req.method === 'GET' && url.pathname === '/api/v1/contract') {
      return json(res, 200, {
        ok: true,
        ...deviceAgentContract(),
        protocol: AGENT_PROTOCOL,
        implementation: { transports: ['simulated', 'ssh', 'serial'], pending: [], persistentState: Boolean(stateFile) },
      });
    }
    if (!authorized(req, token)) return json(res, 401, { ok: false, error: 'Agent authorization required.' });

    if (req.method === 'GET' && url.pathname === '/api/v1/devices') {
      return json(res, 200, { ok: true, devices: inventory() });
    }

    if (req.method === 'POST' && url.pathname === '/api/v1/devices') {
      const payload = await readJson(req);
      const connectionType = payload.connectionType === 'serial' ? 'serial' : 'ssh';
      const config = {
        id: String(payload.id || payload.name || payload.hostname || '').trim(),
        name: String(payload.name || payload.hostname || '').trim(),
        hostname: String(payload.hostname || payload.name || '').trim(),
        kind: payload.kind === 'router' ? 'router' : 'switch',
        vendor: String(payload.vendor || 'Cisco').trim(),
        platform: String(payload.platform || 'IOS-style').trim(),
        connectionType,
        host: String(payload.host || '').trim(),
        port: Number(payload.port || 22),
        username: String(payload.username || '').trim(),
        privateKeyPath: payload.privateKeyPath ? String(payload.privateKeyPath).trim() : '',
        passwordEnv: payload.passwordEnv ? String(payload.passwordEnv).trim() : '',
        enablePasswordEnv: payload.enablePasswordEnv ? String(payload.enablePasswordEnv).trim() : '',
        assumePrivileged: payload.assumePrivileged !== false,
        strictHostKeyChecking: ['yes', 'accept-new', 'no'].includes(payload.strictHostKeyChecking) ? payload.strictHostKeyChecking : 'accept-new',
        connectTimeoutSec: Number(payload.connectTimeoutSec || 10),
        serialPort: String(payload.serialPort || payload.portPath || '').trim(),
        baudRate: Number(payload.baudRate || 9600),
        dataBits: Number(payload.dataBits || 8),
        stopBits: Number(payload.stopBits || 1),
        parity: String(payload.parity || 'none'),
        flowControl: String(payload.flowControl || 'none'),
        timeoutMs: Number(payload.timeoutMs || 5000),
      };
      if (state.devices?.[config.id]) return json(res, 409, { ok: false, error: `Device ID ${config.id} is already used by a simulated workspace device.` });
      const validation = validateDeviceConnection(config);
      if (!validation.valid) return json(res, 400, { ok: false, error: validation.errors.join(' ') });
      if (config.connectionType === 'serial') {
        const serialValidation = validateSerialConnection(config);
        if (!serialValidation.valid) return json(res, 400, { ok: false, error: serialValidation.errors.join(' ') });
      } else {
        const sshValidation = validateSshConnection(config);
        if (!sshValidation.valid) return json(res, 400, { ok: false, error: sshValidation.errors.join(' ') });
      }
      external.set(config.id, config);
      adapters.delete(config.id);
      persist();
      return json(res, 201, {
        ok: true,
        device: externalDeviceRecord(config),
        connection: publicConnection(config),
        ...(config.connectionType === 'serial' ? { serial: serialConnectionSummary(config) } : { ssh: sshConnectionSummary(config) }),
      });
    }

    if (parts.length >= 4 && parts[0] === 'api' && parts[1] === 'v1' && parts[2] === 'devices') {
      const deviceId = decodeURIComponent(parts[3]);
      const action = parts[4] || '';
      const adapter = getAdapter(deviceId);
      if (!adapter) return json(res, 404, { ok: false, error: `Device ${deviceId} not found.` });

      try {
        if (req.method === 'DELETE' && !action && external.has(deviceId)) {
          if (connections.has(deviceId)) {
            await adapter.disconnect();
            connections.delete(deviceId);
          }
          adapters.delete(deviceId);
          external.delete(deviceId);
          configHistory.delete(deviceId);
          inspections.delete(deviceId);
          changeHistory.delete(deviceId);
          for (const [changeId, pending] of pendingChanges.entries()) if (pending.deviceId === deviceId) pendingChanges.delete(changeId);
          persist();
          return json(res, 200, { ok: true, removed: deviceId });
        }
        if (req.method === 'POST' && action === 'connect') {
          const result = await adapter.connect();
          connections.add(deviceId);
          if (external.has(deviceId) && result.device?.version && result.device.version !== 'unknown') {
            external.set(deviceId, { ...external.get(deviceId), version: result.device.version });
            persist();
          }
          return json(res, 200, { ok: true, result: { ...result, device: advertised(result.device, true) } });
        }
        if (req.method === 'DELETE' && action === 'connect') {
          const result = await adapter.disconnect();
          connections.delete(deviceId);
          return json(res, 200, { ok: true, result });
        }
        if (req.method === 'GET' && action === 'diagnostics') {
          const report = inspections.get(deviceId) || null;
          const diagnostics = buildDeviceDiagnostics({ device: inventory().find(d => d.id === deviceId) || {}, inspection: report, history: historyFor(deviceId), connected: connections.has(deviceId) });
          return json(res, 200, { ok: true, diagnostics });
        }
        if (req.method === 'GET' && action === 'inspection') {
          const report = inspections.get(deviceId);
          if (!report) return json(res, 404, { ok: false, error: 'No saved inspection exists for this device.' });
          return json(res, 200, { ok: true, report });
        }
        if (req.method === 'GET' && action === 'discovery') {
          const report = discoveries.get(deviceId);
          if (!report) return json(res, 404, { ok: false, error: 'No saved discovery exists for this device.' });
          return json(res, 200, { ok: true, report });
        }
        if (req.method === 'GET' && action === 'config-history') {
          return json(res, 200, { ok: true, deviceId, history: historyFor(deviceId).map(({ runningConfig, startupConfig, ...item }) => item), count: historyFor(deviceId).length });
        }
        if (req.method === 'GET' && action === 'config-diff') {
          const from = String(url.searchParams.get('from') || '');
          const to = String(url.searchParams.get('to') || '');
          const records = historyFor(deviceId);
          const before = records.find(item => item.id === from);
          const after = records.find(item => item.id === to);
          if (!before || !after) return json(res, 404, { ok: false, error: 'Both configuration snapshot IDs must exist in device history.' });
          const diff = configDiff(before.runningConfig, after.runningConfig);
          return json(res, 200, { ok: true, deviceId, from: { id: before.id, capturedAt: before.capturedAt, label: before.label }, to: { id: after.id, capturedAt: after.capturedAt, label: after.label }, diff, summary: summarizeConfigDiff(diff) });
        }
        if (req.method === 'GET' && action === 'change-history') {
          return json(res, 200, { ok: true, deviceId, history: changesFor(deviceId).map(item => ({ ...item, plan: { commands: [], displayCommands: item.plan?.displayCommands || [] } })), count: changesFor(deviceId).length });
        }
        if (req.method === 'GET' && action === 'execute-history') {
          const history = executeHistory.get(deviceId) || [];
          return json(res, 200, { ok: true, deviceId, history, count: history.length });
        }

        if (req.method === 'POST' && action === 'preflight-intent') {
          const payload = await readJson(req);
          const intent = payload.intent || payload;
          if (!connections.has(deviceId)) return json(res, 409, { ok: false, error: 'Device session is not connected.', code: 'SESSION_REQUIRED' });
          const result = await makePreflight(deviceId, intent);
          if (!result.valid) return json(res, 400, { ok: false, error: result.preflight?.summary || 'Preflight blocked.', result });
          return json(res, 200, { ok: true, result });
        }
        if (!connections.has(deviceId)) return json(res, 409, { ok: false, error: 'Device session is not connected.' });

        if (req.method === 'POST' && action === 'discover') {
          const outputs = {};
          for (const command of DISCOVERY_COMMANDS) {
            try {
              const result = await adapter.execute(command);
              outputs[command] = Array.isArray(result?.output) ? result.output.join('\n') : String(result?.output || '');
            } catch (error) {
              outputs[command] = '';
            }
          }
          const device = inventory().find(item => item.id === deviceId) || adapter.getDevice?.() || { id: deviceId };
          const report = buildNetworkDiscoveryReport({ device, outputs, source: device.connection?.type === 'simulated' ? 'simulated' : 'device-agent' });
          discoveries.set(deviceId, report);
          persist();
          return json(res, 200, { ok: true, report });
        }

        if (req.method === 'POST' && action === 'inspect') {
          const report = await adapter.inspect();
          inspections.set(deviceId, report);
          if (external.has(deviceId)) {
            const current = external.get(deviceId);
            external.set(deviceId, { ...current, hostname: report.overview.hostname, version: report.overview.version, interfaceCount: report.overview.interfaceCount, upInterfaceCount: report.overview.upInterfaceCount, vlanCount: report.overview.vlanCount, routeCount: report.overview.routeCount });
          }
          persist();
          return json(res, 200, { ok: true, report });
        }

        if (req.method === 'POST' && action === 'execute') {
          const payload = await readJson(req);
          const command = String(payload.command || '').trim();
          if (!command) return json(res, 400, { ok: false, error: 'command is required.' });
          const listedDevice = inventory().find(item => item.id === deviceId) || adapter.getDevice?.() || {};
          const transport = listedDevice.connection?.type || (external.has(deviceId) ? 'physical' : 'simulated');
          const physical = external.has(deviceId) || ['ssh', 'serial'].includes(transport);
          if (physical && !isReadOnlyDeviceCommand(command)) {
            appendExecuteAudit(deviceId, { command, outcome: 'blocked', transport });
            return json(res, 403, {
              ok: false,
              code: 'CHANGE_CONTROL_REQUIRED',
              error: 'Raw execution on physical devices is read-only. Use Plan → Preflight → Approve → Apply for configuration changes.',
            });
          }
          try {
            const result = await adapter.execute(command);
            appendExecuteAudit(deviceId, { command, outcome: 'allowed', transport });
            return json(res, 200, { ok: true, result });
          } catch (error) {
            appendExecuteAudit(deviceId, { command, outcome: 'error', transport });
            throw error;
          }
        }
        if (req.method === 'POST' && action === 'snapshot') {
          const result = await recordSnapshot(deviceId, 'manual');
          return json(res, 200, { ok: true, result: { ...result.snapshot, history: result.record, diff: result.diff, duplicate: result.duplicate } });
        }
        if (req.method === 'POST' && action === 'apply-intent') {
          const payload = await readJson(req);
          const intent = payload.intent || payload;
          const device = inventory().find(d => d.id === deviceId);
          const physical = ['ssh', 'serial'].includes(device?.connection?.type) || external.has(deviceId);
          cleanExpiredPreflights();
          let pending = payload.changeId ? pendingChanges.get(String(payload.changeId)) : null;
          if (physical && (!pending || pending.deviceId !== deviceId || JSON.stringify(pending.intent) !== JSON.stringify(intent))) {
            return json(res, 409, { ok: false, error: 'A matching device preflight is required before changing a physical device.', code: 'PREFLIGHT_REQUIRED' });
          }
          if (!pending) {
            const preflightResult = await makePreflight(deviceId, intent);
            if (!preflightResult.valid) return json(res, 400, { ok: false, error: preflightResult.preflight?.summary || 'Preflight blocked.', result: preflightResult });
            pending = pendingChanges.get(preflightResult.changeId);
          }
          const plan = pending?.plan || planIntent(intent, device);
          if (!plan.valid) return json(res, 400, { ok: false, error: plan.errors.join(' '), plan });
          let applied;
          let post = null;
          let finalRecord;
          try {
            applied = await adapter.applyIntent(intent, plan);
            const recorded = await recordSnapshot(deviceId, 'intent', `After ${intent.type || 'configuration'} intent`);
            post = recorded;
            finalRecord = normalizeChangeRecord({
              ...pending.record, status: applied.applied ? 'applied' : 'failed', appliedAt: new Date().toISOString(), completedAt: new Date().toISOString(),
              postSnapshotId: recorded.record?.id || null, diffSummary: summarizeConfigDiff(recorded.diff), changed: Boolean(recorded.diff?.changed),
              verification: { snapshotCaptured: true }, errors: applied.applied ? [] : ['The device adapter reported that the intent was not fully applied.'],
            });
          } catch (error) {
            finalRecord = normalizeChangeRecord({ ...pending.record, status: 'failed', appliedAt: new Date().toISOString(), completedAt: new Date().toISOString(), errors: [error instanceof Error ? error.message : String(error)] });
            const list = [...changesFor(deviceId).filter(item => item.id !== finalRecord.id), finalRecord].slice(-100);
            changeHistory.set(deviceId, list);
            persist();
            pendingChanges.delete(finalRecord.id);
            return json(res, 500, { ok: false, error: error instanceof Error ? error.message : String(error), change: finalRecord, preflight: pending.preflight, snapshot: pending.preSnapshot });
          }
          const list = [...changesFor(deviceId).filter(item => item.id !== finalRecord.id), finalRecord].slice(-100);
          changeHistory.set(deviceId, list);
          persist();
          pendingChanges.delete(finalRecord.id);
          const { state: _unsafeState, ...appliedWithoutState } = applied || {};
          const safeApplied = {
            ...appliedWithoutState,
            plan: applied?.plan ? {
              valid: applied.plan.valid,
              errors: applied.plan.errors || [],
              displayCommands: applied.plan.displayCommands || [],
              explanations: applied.plan.explanations || [],
            } : undefined,
            transcript: Array.isArray(applied?.transcript) ? applied.transcript.map(entry => {
              const { state: _unsafeTranscriptState, ...safeEntry } = entry || {};
              return {
                ...safeEntry,
                command: redactConfig(entry?.command || ''),
                output: Array.isArray(entry?.output) ? entry.output.map(line => redactConfig(line)) : redactConfig(entry?.output || ''),
              };
            }) : [],
          };
          return json(res, 200, { ok: true, result: { ...safeApplied, snapshot: post?.snapshot || null, history: post?.record || null, diff: post?.diff || null, duplicate: post?.duplicate || false, preSnapshotId: pending.preSnapshot?.id || null, change: finalRecord, changeSummary: summarizeChangeRecord(finalRecord) } });
        }
      } catch (error) {
        if (!error.statusCode || error.statusCode >= 500) connections.delete(deviceId);
        return json(res, error.statusCode || 500, { ok: false, error: error instanceof Error ? error.message : String(error) });
      }
    }

    return json(res, 404, { ok: false, error: 'Not found.' });
  };

  const server = http.createServer((req, res) => {
    route(req, res).catch(error => json(res, error.statusCode || 500, { ok: false, error: error instanceof Error ? error.message : String(error) }));
  });

  return { server, token, host, port, allowedOrigins, protocol: AGENT_PROTOCOL, external, stateFile, stateRecovered: persisted.recovered, stateLoadError: persisted.error || null };
}

export async function startAgent(options = {}) {
  const instance = createAgentServer({ ...options, stateFile: options.stateFile ?? defaultAgentStatePath() });
  await new Promise((resolvePromise, reject) => {
    const onError = error => { instance.server.off('error', onError); reject(error); };
    instance.server.once('error', onError);
    instance.server.listen(instance.port, instance.host, () => { instance.server.off('error', onError); resolvePromise(); });
  });
  const address = instance.server.address();
  const actualPort = typeof address === 'object' && address ? address.port : instance.port;
  console.log(`[Driller Bill] Device Agent listening on http://${instance.host}:${actualPort}`);
  console.log(`[Driller Bill] Agent protocol: ${AGENT_PROTOCOL}`);
  console.log(`[Driller Bill] Agent token: ${instance.token}`);
  console.log('[Driller Bill] Transport status: simulated + SSH + serial/console enabled.');
  return { ...instance, port: actualPort };
}

const entry = process.argv[1] ? resolve(process.argv[1]) : '';
const current = resolve(fileURLToPath(import.meta.url));
if (entry === current) {
  startAgent().catch(error => {
    console.error(`[Driller Bill] Device Agent failed: ${error.message}`);
    process.exitCode = 1;
  });
}
