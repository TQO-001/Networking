import { INSPECTION_COMMANDS, buildInspectionReport } from '../src/core/device-inspection.js';

export const SERIAL_ADAPTER_VERSION = '1.0.0';
export const SERIALPORT_VERSION = '13.0.0';
export const DEFAULT_SERIAL_BAUD_RATE = 9600;
export const DEFAULT_SERIAL_DATA_BITS = 8;
export const DEFAULT_SERIAL_STOP_BITS = 1;
export const DEFAULT_SERIAL_PARITY = 'none';
export const DEFAULT_SERIAL_FLOW_CONTROL = 'none';
export const DEFAULT_SERIAL_TIMEOUT_MS = 5_000;

const SUPPORTED_BAUD_RATES = [1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600];
const SUPPORTED_DATA_BITS = [5, 6, 7, 8];
const SUPPORTED_STOP_BITS = [1, 2];
const SUPPORTED_PARITY = new Set(['none', 'even', 'odd']);
const SUPPORTED_FLOW = new Set(['none', 'hardware', 'software']);

function cleanOutput(value = '') {
  return String(value)
    .replace(/\x1b\][^\x07]*(?:\x07|\x1b\\)/g, '')
    .replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, '')
    .replace(/\r/g, '');
}

function lines(value = '') {
  return cleanOutput(value).split('\n').map(line => line.trimEnd()).filter(Boolean);
}

function safeErrorText(value) {
  return cleanOutput(value).trim().replace(/password\s*[:=]\s*[^\n]*/gi, 'password: [redacted]');
}

function validateEnum(value, allowed, fallback) {
  return value === undefined || value === '' ? fallback : value;
}

export function validateSerialConnection(connection = {}) {
  const errors = [];
  if (!String(connection.serialPort || connection.portPath || '').trim()) errors.push('Serial device path is required, for example /dev/ttyUSB0 or COM3.');

  const baudRate = Number(connection.baudRate || DEFAULT_SERIAL_BAUD_RATE);
  if (!SUPPORTED_BAUD_RATES.includes(baudRate)) errors.push(`Serial baud rate must be one of: ${SUPPORTED_BAUD_RATES.join(', ')}.`);

  const dataBits = Number(connection.dataBits || DEFAULT_SERIAL_DATA_BITS);
  if (!SUPPORTED_DATA_BITS.includes(dataBits)) errors.push('Serial data bits must be 5, 6, 7 or 8.');

  const stopBits = Number(connection.stopBits || DEFAULT_SERIAL_STOP_BITS);
  if (!SUPPORTED_STOP_BITS.includes(stopBits)) errors.push('Serial stop bits must be 1 or 2.');

  const parity = validateEnum(connection.parity, SUPPORTED_PARITY, DEFAULT_SERIAL_PARITY);
  if (!SUPPORTED_PARITY.has(parity)) errors.push('Serial parity must be none, even or odd.');

  const flowControl = validateEnum(connection.flowControl, SUPPORTED_FLOW, DEFAULT_SERIAL_FLOW_CONTROL);
  if (!SUPPORTED_FLOW.has(flowControl)) errors.push('Serial flow control must be none, hardware or software.');

  const timeoutMs = Number(connection.timeoutMs || DEFAULT_SERIAL_TIMEOUT_MS);
  if (!Number.isInteger(timeoutMs) || timeoutMs < 500 || timeoutMs > 120_000) errors.push('Serial command timeout must be an integer from 500 to 120000 ms.');
  if (connection.enablePasswordEnv && !/^[A-Za-z_][A-Za-z0-9_]*$/.test(String(connection.enablePasswordEnv))) errors.push('Enable-password environment variable name is invalid.');
  return { valid: errors.length === 0, errors };
}

function serialOptions(connection = {}) {
  const flow = validateEnum(connection.flowControl, SUPPORTED_FLOW, DEFAULT_SERIAL_FLOW_CONTROL);
  return {
    path: String(connection.serialPort || connection.portPath).trim(),
    baudRate: Number(connection.baudRate || DEFAULT_SERIAL_BAUD_RATE),
    dataBits: Number(connection.dataBits || DEFAULT_SERIAL_DATA_BITS),
    stopBits: Number(connection.stopBits || DEFAULT_SERIAL_STOP_BITS),
    parity: validateEnum(connection.parity, SUPPORTED_PARITY, DEFAULT_SERIAL_PARITY),
    rtscts: flow === 'hardware',
    xon: flow === 'software',
    xoff: flow === 'software',
    autoOpen: false,
  };
}

async function defaultSerialPortFactory(options) {
  try {
    const module = await import('serialport');
    const SerialPort = module.SerialPort || module.default;
    if (!SerialPort) throw new Error('The serialport package did not expose SerialPort.');
    return new SerialPort(options);
  } catch (error) {
    throw new Error(`Serial support requires the serialport package (${SERIALPORT_VERSION}). Run npm install before starting the Device Agent. ${error.message}`);
  }
}

function baseDevice(connection, overrides = {}) {
  const id = connection.id;
  const name = connection.name || connection.hostname || id;
  return {
    id,
    name,
    hostname: connection.hostname || name,
    kind: connection.kind || 'switch',
    vendor: connection.vendor || 'Cisco',
    platform: connection.platform || 'IOS-style',
    version: overrides.version || connection.version || 'unknown',
    mode: 'exec',
    interfaceCount: overrides.interfaceCount || 0,
    upInterfaceCount: overrides.upInterfaceCount || 0,
    vlanCount: overrides.vlanCount || 0,
    routeCount: overrides.routeCount || 0,
    connection: {
      type: 'serial',
      status: overrides.status || 'ready',
      endpoint: connection.serialPort || connection.portPath,
      serial: {
        baudRate: Number(connection.baudRate || DEFAULT_SERIAL_BAUD_RATE),
        dataBits: Number(connection.dataBits || DEFAULT_SERIAL_DATA_BITS),
        stopBits: Number(connection.stopBits || DEFAULT_SERIAL_STOP_BITS),
        parity: validateEnum(connection.parity, SUPPORTED_PARITY, DEFAULT_SERIAL_PARITY),
        flowControl: validateEnum(connection.flowControl, SUPPORTED_FLOW, DEFAULT_SERIAL_FLOW_CONTROL),
      },
    },
    capabilities: connection.kind === 'router'
      ? ['cli', 'configuration', 'config-snapshot', 'interfaces', 'routing', 'ospf', 'troubleshooting', 'serial-console']
      : ['cli', 'configuration', 'config-snapshot', 'interfaces', 'vlans', 'switching', 'troubleshooting', 'serial-console'],
  };
}

function stripEchoAndPrompt(output = '', command = '') {
  const rows = cleanOutput(output).trim().split('\n');
  const target = String(command).trim();
  if (rows[0]?.trim() === target) rows.shift();
  while (rows.length && /^[^\n\r]*[>#]\s*$/.test(rows.at(-1).trim())) rows.pop();
  return rows.join('\n').trim();
}

function configPrefix(connection, env) {
  if (connection.assumePrivileged !== false) return [];
  if (!connection.enablePasswordEnv) throw new Error('This device is configured as non-privileged, but no enable password environment variable is configured.');
  const secret = env[String(connection.enablePasswordEnv)];
  if (!secret) throw new Error(`The enable-password environment variable ${connection.enablePasswordEnv} is not set in the Device Agent environment.`);
  return ['enable', secret];
}

export function createSerialDeviceAdapter(connection = {}, {
  env = process.env,
  serialPortFactory = defaultSerialPortFactory,
} = {}) {
  const validation = validateSerialConnection(connection);
  if (!validation.valid) throw new Error(validation.errors.join(' '));

  let connected = false;
  let device = baseDevice(connection);
  let port = null;
  let inputBuffer = '';
  const waiters = new Set();

  const consumeIfReady = waiter => {
    if (!waiters.has(waiter) || !waiter.matches(inputBuffer)) return false;
    waiters.delete(waiter);
    clearTimeout(waiter.timer);
    const value = inputBuffer;
    inputBuffer = '';
    waiter.resolve(value);
    return true;
  };

  const onData = chunk => {
    inputBuffer += Buffer.from(chunk).toString('utf8');
    for (const waiter of [...waiters]) consumeIfReady(waiter);
  };

  const waitForPattern = (matches, timeoutMs, label) => new Promise((resolve, reject) => {
    const waiter = { matches, resolve, reject, timer: null };
    waiter.timer = setTimeout(() => {
      waiters.delete(waiter);
      reject(new Error(`Serial device did not return the expected ${label} within ${timeoutMs} ms.`));
    }, timeoutMs);
    waiters.add(waiter);
    consumeIfReady(waiter);
  });

  const promptPattern = value => /(?:^|\n)[^\n\r]{0,180}[>#]\s*$/.test(cleanOutput(value));
  const waitForPrompt = timeoutMs => waitForPattern(promptPattern, timeoutMs, 'CLI prompt');
  const waitForPromptOrPassword = timeoutMs => waitForPattern(value => /pass(word)?\s*:/i.test(cleanOutput(value)) || promptPattern(value), timeoutMs, 'CLI prompt or password prompt');

  const write = value => new Promise((resolve, reject) => {
    if (!port) return reject(new Error('Serial device session is not open.'));
    port.write(value, error => {
      if (error) reject(new Error(`Serial write failed: ${safeErrorText(error.message || error)}`));
      else if (typeof port.drain === 'function') port.drain(error2 => error2 ? reject(new Error(`Serial drain failed: ${safeErrorText(error2.message || error2)}`)) : resolve());
      else resolve();
    });
  });

  const transact = async (command = '', { timeoutMs = Number(connection.timeoutMs || DEFAULT_SERIAL_TIMEOUT_MS) } = {}) => {
    inputBuffer = '';
    const pending = waitForPrompt(timeoutMs);
    await write(command ? `${command}\r` : '\r');
    const response = await pending;
    return stripEchoAndPrompt(response, command);
  };

  const openPort = async () => {
    port = await serialPortFactory(serialOptions(connection));
    port.on?.('data', onData);
    port.on?.('error', error => {
      for (const waiter of [...waiters]) waiter.reject(new Error(`Serial device error: ${safeErrorText(error?.message || error)}`));
    });
    await new Promise((resolve, reject) => {
      if (port.isOpen) return resolve();
      port.open(error => error ? reject(new Error(`Unable to open serial port: ${safeErrorText(error.message || error)}`)) : resolve());
    });
  };

  const closePort = async () => {
    for (const waiter of [...waiters]) {
      clearTimeout(waiter.timer);
      waiter.reject(new Error('Serial session closed.'));
    }
    waiters.clear();
    inputBuffer = '';
    if (!port) return;
    const current = port;
    port = null;
    if (current.isOpen === false) return;
    await new Promise(resolve => {
      try { current.close(() => resolve()); } catch { resolve(); }
    });
  };

  const ensureReady = async () => {
    await transact('');
    for (const command of ['terminal length 0', 'terminal width 0']) {
      try { await transact(command); } catch { /* optional IOS terminal controls */ }
    }
    const prefix = configPrefix(connection, env);
    if (prefix.length) {
      inputBuffer = '';
      const pending = waitForPromptOrPassword(Number(connection.timeoutMs || DEFAULT_SERIAL_TIMEOUT_MS));
      await write('enable\r');
      const response = await pending;
      if (/pass(word)?\s*:/i.test(cleanOutput(response))) {
        const passwordPending = waitForPrompt(Number(connection.timeoutMs || DEFAULT_SERIAL_TIMEOUT_MS));
        await write(`${prefix[1]}\r`);
        await passwordPending;
      }
    }
  };

  return {
    protocol: 'device-adapter/1',
    kind: 'serial',
    deviceId: connection.id,
    async connect() {
      if (connected) return { connected: true, device };
      try {
        await openPort();
        await ensureReady();
        const versionOutput = await transact('show version');
        const versionMatch = cleanOutput(versionOutput).match(/Version\s+([0-9][^\s,;]+)/i);
        device = baseDevice(connection, { version: versionMatch?.[1] || 'unknown', status: 'connected' });
        connected = true;
        return { connected: true, device, handshake: { command: 'show version', output: lines(versionOutput) } };
      } catch (error) {
        await closePort();
        throw new Error(`Serial console handshake failed: ${error.message}`);
      }
    },
    async disconnect() {
      connected = false;
      await closePort();
      device = baseDevice(connection, { status: 'ready', version: device.version });
      return { connected: false };
    },
    isConnected() { return connected; },
    async execute(command) {
      if (!connected) throw new Error('Device session is not connected.');
      const value = String(command || '').trim();
      if (!value) throw new Error('Command is required.');
      if (/\r|\n/.test(value)) throw new Error('Serial execute accepts one command at a time.');
      const output = await transact(value);
      return { command: value, output: lines(output), device };
    },
    async applyIntent(intent, plan) {
      if (!connected) throw new Error('Device session is not connected.');
      if (!plan?.valid) throw new Error('Configuration intent is invalid.');
      const commands = plan.commands.filter(command => command !== 'end' && command !== 'enable');
      if (connection.assumePrivileged === false) {
        const secret = env[String(connection.enablePasswordEnv || '')];
        if (!secret) throw new Error(`The enable-password environment variable ${connection.enablePasswordEnv} is not set in the Device Agent environment.`);
        await transact('enable');
        await transact(secret);
      }
      const transcript = [];
      for (const command of commands) transcript.push({ command, output: lines(await transact(command)) });
      return { applied: true, plan, transcript, device };
    },
    async inspect() {
      if (!connected) throw new Error('Device session is not connected.');
      const commands = INSPECTION_COMMANDS[connection.kind === 'router' ? 'router' : 'switch'];
      const outputs = {};
      for (const command of commands) outputs[command] = await transact(command);
      const report = buildInspectionReport({ device, outputs, source: 'serial' });
      device = baseDevice(connection, {
        version: report.overview.version,
        interfaceCount: report.overview.interfaceCount,
        upInterfaceCount: report.overview.upInterfaceCount,
        vlanCount: report.overview.vlanCount,
        routeCount: report.overview.routeCount,
      });
      return { ...report, overview: { ...report.overview } };
    },
    async snapshot() {
      if (!connected) throw new Error('Device session is not connected.');
      return {
        deviceId: connection.id,
        capturedAt: new Date().toISOString(),
        runningConfig: cleanOutput(await transact('show running-config')).trim(),
        startupConfig: cleanOutput(await transact('show startup-config')).trim(),
        device,
      };
    },
    getState() { return null; },
    getDevice() { return device; },
    transportDetails() { return serialConnectionSummary(connection); },
  };
}

export function serialConnectionSummary(connection = {}) {
  return {
    port: connection.serialPort || connection.portPath,
    baudRate: Number(connection.baudRate || DEFAULT_SERIAL_BAUD_RATE),
    dataBits: Number(connection.dataBits || DEFAULT_SERIAL_DATA_BITS),
    stopBits: Number(connection.stopBits || DEFAULT_SERIAL_STOP_BITS),
    parity: validateEnum(connection.parity, SUPPORTED_PARITY, DEFAULT_SERIAL_PARITY),
    flowControl: validateEnum(connection.flowControl, SUPPORTED_FLOW, DEFAULT_SERIAL_FLOW_CONTROL),
  };
}
