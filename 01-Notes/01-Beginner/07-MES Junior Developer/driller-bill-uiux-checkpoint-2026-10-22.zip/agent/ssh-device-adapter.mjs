import { spawn } from 'node:child_process';
import { chmod, mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomBytes } from 'node:crypto';
import { INSPECTION_COMMANDS, buildInspectionReport } from '../src/core/device-inspection.js';

export const SSH_ADAPTER_VERSION = '1.0.0';
export const DEFAULT_SSH_PORT = 22;
export const DEFAULT_SSH_TIMEOUT_MS = 20_000;

function cleanOutput(value = '') {
  return String(value).replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, '').replace(/\r/g, '');
}

function lines(value = '') {
  return cleanOutput(value).split('\n').map(line => line.trimEnd());
}

function shellQuote(value) {
  return `'${String(value).replaceAll("'", "'\\''")}'`;
}

export function validateSshConnection(connection = {}) {
  const errors = [];
  if (!String(connection.host || '').trim()) errors.push('SSH host is required.');
  const port = Number(connection.port || DEFAULT_SSH_PORT);
  if (!Number.isInteger(port) || port < 1 || port > 65535) errors.push('SSH port must be an integer from 1 to 65535.');
  if (!String(connection.username || '').trim()) errors.push('SSH username is required.');
  if (connection.privateKeyPath && connection.passwordEnv) errors.push('Choose a private key or a password environment variable; do not configure both login methods.');
  if (connection.passwordEnv && !/^[A-Za-z_][A-Za-z0-9_]*$/.test(String(connection.passwordEnv))) errors.push('Password environment variable name is invalid.');
  if (connection.enablePasswordEnv && !/^[A-Za-z_][A-Za-z0-9_]*$/.test(String(connection.enablePasswordEnv))) errors.push('Enable-password environment variable name is invalid.');
  return { valid: errors.length === 0, errors };
}

function promptSafeId(value = 'driller-bill') {
  return String(value).replace(/[^A-Za-z0-9_.-]/g, '_').slice(0, 42) || 'driller-bill';
}

async function createAskpassHelper(secret) {
  const dir = await mkdtemp(join(tmpdir(), 'driller-bill-askpass-'));
  const isWindows = process.platform === 'win32';
  const filename = isWindows ? 'askpass.cmd' : 'askpass.sh';
  const file = join(dir, filename);
  const secretVar = `DRILLER_BILL_ASKPASS_${randomBytes(6).toString('hex').toUpperCase()}`;
  const content = isWindows
    ? `@echo off\necho %${secretVar}%\n`
    : `#!/bin/sh\nprintf '%s\\n' "$${secretVar}"\n`;
  await writeFile(file, content, { mode: 0o700 });
  if (!isWindows) await chmod(file, 0o700);
  return {
    path: file,
    directory: dir,
    envName: secretVar,
    env: { [secretVar]: secret },
  };
}

function safeErrorText(value) {
  return cleanOutput(value).trim().replace(/password\s*[:=]\s*[^\n]*/gi, 'password: [redacted]');
}

/**
 * Execute an SSH shell session using the host operating system's OpenSSH client.
 * Credentials never leave the agent process. Passwords are provided to OpenSSH through SSH_ASKPASS,
 * while the normal path is key-based authentication or an existing SSH agent.
 */
export async function runOpenSshSession(connection = {}, {
  stdin = '',
  timeoutMs = DEFAULT_SSH_TIMEOUT_MS,
  spawnImpl = spawn,
  env = process.env,
} = {}) {
  const validation = validateSshConnection(connection);
  if (!validation.valid) throw new Error(validation.errors.join(' '));

  const host = String(connection.host).trim();
  const username = String(connection.username).trim();
  const port = Number(connection.port || DEFAULT_SSH_PORT);
  const strictHostKeyChecking = ['yes', 'accept-new', 'no'].includes(connection.strictHostKeyChecking)
    ? connection.strictHostKeyChecking : 'accept-new';

  const args = [
    '-p', String(port),
    '-o', `ConnectTimeout=${Math.max(3, Math.round(Number(connection.connectTimeoutSec || 10)))}`,
    '-o', 'ServerAliveInterval=15',
    '-o', 'ServerAliveCountMax=2',
    '-o', `StrictHostKeyChecking=${strictHostKeyChecking}`,
  ];

  if (connection.privateKeyPath) {
    args.push('-i', String(connection.privateKeyPath), '-o', 'IdentitiesOnly=yes', '-o', 'BatchMode=yes');
  }

  let askpass = null;
  const childEnv = { ...env };
  if (connection.passwordEnv) {
    const secret = env[String(connection.passwordEnv)];
    if (!secret) throw new Error(`The SSH password environment variable ${connection.passwordEnv} is not set in the Device Agent environment.`);
    askpass = await createAskpassHelper(secret);
    childEnv.SSH_ASKPASS = askpass.path;
    childEnv.SSH_ASKPASS_REQUIRE = 'force';
    childEnv.DISPLAY = childEnv.DISPLAY || ':99';
    // No PTY when password authentication is used; this forces OpenSSH down the askpass path.
    args.push('-T', '-o', 'BatchMode=no', '-o', 'PreferredAuthentications=password,keyboard-interactive,publickey');
  } else {
    // PTY makes Cisco IOS-style shells behave like a normal console when key authentication is used.
    args.push('-tt', '-o', 'PreferredAuthentications=publickey');
  }

  args.push(`${username}@${host}`);

  return await new Promise((resolve, reject) => {
    let stdout = '';
    let stderr = '';
    let settled = false;
    let timer;
    let child;

    const finish = (result, error = null) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (askpass) rm(askpass.directory, { recursive: true, force: true }).catch(() => {});
      if (error) reject(error);
      else resolve(result);
    };

    try {
      child = spawnImpl('ssh', args, {
        env: childEnv,
        windowsHide: true,
        stdio: ['pipe', 'pipe', 'pipe'],
      });
    } catch (error) {
      finish(null, new Error(`Unable to start OpenSSH. Install the system ssh client or configure an SSH executable for the agent. ${error.message}`));
      return;
    }

    child.stdout?.on('data', chunk => { stdout += chunk.toString(); });
    child.stderr?.on('data', chunk => { stderr += chunk.toString(); });
    child.once('error', error => finish(null, new Error(`SSH transport failed: ${error.message}`)));
    child.once('close', code => {
      const result = {
        code: Number.isInteger(code) ? code : 1,
        stdout: cleanOutput(stdout),
        stderr: cleanOutput(stderr),
      };
      if (result.code !== 0) {
        const detail = safeErrorText(result.stderr || result.stdout) || `SSH exited with code ${result.code}.`;
        finish(null, new Error(detail));
      } else {
        finish(result);
      }
    });

    timer = setTimeout(() => {
      try { child.kill('SIGTERM'); } catch {}
      finish(null, new Error(`SSH session timed out after ${timeoutMs} ms.`));
    }, timeoutMs);

    try {
      child.stdin.write(String(stdin));
      child.stdin.end();
    } catch (error) {
      try { child.kill('SIGTERM'); } catch {}
      finish(null, new Error(`Unable to send commands to SSH session: ${error.message}`));
    }
  });
}

function configPrefix(connection, env) {
  if (connection.assumePrivileged !== false) return [];
  if (!connection.enablePasswordEnv) throw new Error('This device is configured as non-privileged, but no enable password environment variable is configured.');
  const secret = env[String(connection.enablePasswordEnv)];
  if (!secret) throw new Error(`The enable-password environment variable ${connection.enablePasswordEnv} is not set in the Device Agent environment.`);
  return ['enable', secret];
}

function shellInput(commands, connection, env) {
  const prefix = configPrefix(connection, env);
  return [
    'terminal length 0',
    'terminal width 0',
    ...prefix,
    ...commands,
    'end',
    'exit',
    '',
  ].join('\n');
}

function extractVersion(output) {
  const match = cleanOutput(output).match(/Version\s+([0-9][^\s,;]+)/i);
  return match?.[1] || 'unknown';
}

function baseDevice(connection, overrides = {}) {
  const id = connection.id;
  const name = connection.name || connection.hostname || id;
  return {
    id,
    name,
    hostname: connection.hostname || name,
    kind: connection.kind || 'switch',
    vendor: connection.vendor || 'Cisco',
    platform: connection.platform || 'IOS-style',
    version: overrides.version || connection.version || 'unknown',
    mode: 'exec',
    interfaceCount: overrides.interfaceCount || 0,
    upInterfaceCount: overrides.upInterfaceCount || 0,
    vlanCount: overrides.vlanCount || 0,
    routeCount: overrides.routeCount || 0,
    connection: {
      type: 'ssh',
      status: overrides.status || 'ready',
      endpoint: `${connection.host}:${Number(connection.port || DEFAULT_SSH_PORT)}`,
    },
    capabilities: connection.kind === 'router'
      ? ['cli', 'configuration', 'config-snapshot', 'interfaces', 'routing', 'ospf', 'troubleshooting']
      : ['cli', 'configuration', 'config-snapshot', 'interfaces', 'vlans', 'switching', 'troubleshooting'],
  };
}

export function createSshDeviceAdapter(connection = {}, {
  runSession = runOpenSshSession,
  env = process.env,
} = {}) {
  const validation = validateSshConnection(connection);
  if (!validation.valid) throw new Error(validation.errors.join(' '));
  let connected = false;
  let device = baseDevice(connection);

  const session = async commands => runSession(connection, {
    stdin: shellInput(commands, connection, env),
  });

  return {
    protocol: 'device-adapter/1',
    kind: 'ssh',
    deviceId: connection.id,
    async connect() {
      const result = await session(['show version']);
      connected = true;
      device = baseDevice(connection, { version: extractVersion(result.stdout), status: 'connected' });
      return { connected: true, device, handshake: { command: 'show version', output: lines(result.stdout) } };
    },
    async disconnect() {
      connected = false;
      device = baseDevice(connection, { status: 'ready', version: device.version });
      return { connected: false };
    },
    isConnected() { return connected; },
    async execute(command) {
      if (!connected) throw new Error('Device session is not connected.');
      const value = String(command || '').trim();
      if (!value) throw new Error('Command is required.');
      if (/\r|\n/.test(value)) throw new Error('SSH execute accepts one command at a time.');
      const result = await session([value]);
      return { command: value, output: lines(result.stdout), device };
    },
    async applyIntent(intent, plan) {
      if (!connected) throw new Error('Device session is not connected.');
      if (!plan?.valid) throw new Error('Configuration intent is invalid.');
      const commands = plan.commands.filter(command => command !== 'end' && command !== 'enable');
      const result = await session(commands);
      const output = lines(result.stdout).filter(Boolean);
      return {
        applied: true,
        plan,
        transcript: plan.commands.map(command => ({ command, output: command === 'enable' ? [] : output })),
        device,
      };
    },
    async inspect() {
      if (!connected) throw new Error('Device session is not connected.');
      const commands = INSPECTION_COMMANDS[connection.kind === 'router' ? 'router' : 'switch'];
      const outputs = {};
      for (const command of commands) {
        const result = await session([command]);
        outputs[command] = result.stdout;
      }
      const report = buildInspectionReport({ device, outputs, source: 'ssh' });
      device = baseDevice(connection, {
        version: report.overview.version,
        interfaceCount: report.overview.interfaceCount,
        upInterfaceCount: report.overview.upInterfaceCount,
        vlanCount: report.overview.vlanCount,
        routeCount: report.overview.routeCount,
      });
      return { ...report, overview: { ...report.overview } };
    },
    async snapshot() {
      if (!connected) throw new Error('Device session is not connected.');
      const running = await session(['show running-config']);
      const startup = await session(['show startup-config']);
      return {
        deviceId: connection.id,
        capturedAt: new Date().toISOString(),
        runningConfig: cleanOutput(running.stdout).trim(),
        startupConfig: cleanOutput(startup.stdout).trim(),
        device,
      };
    },
    getState() { return null; },
    getDevice() { return device; },
  };
}

export function sshConnectionSummary(connection = {}) {
  return {
    host: connection.host,
    port: Number(connection.port || DEFAULT_SSH_PORT),
    username: connection.username,
    authentication: connection.passwordEnv ? 'environment password' : connection.privateKeyPath ? 'private key' : 'ssh agent/default key',
    hostKeyPolicy: connection.strictHostKeyChecking || 'accept-new',
  };
}
