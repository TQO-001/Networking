# Driller Bill Local Device Agent

v61 extends the localhost bridge into real SSH and serial/console transport, durable device state, structured inspection, and transport-agnostic device workflows while preserving the browser-facing device protocol.

## Run

```bash
node agent/server.mjs
```

The process prints a bearer token. Enter that token in the Devices workspace.

Optional environment variables:

```bash
DRILLER_BILL_AGENT_PORT=8788
DRILLER_BILL_AGENT_TOKEN=replace-me
DRILLER_BILL_AGENT_ALLOWED_ORIGINS=http://localhost:5173,http://127.0.0.1:5173,http://localhost:4173,http://127.0.0.1:4173,http://localhost:8080,http://127.0.0.1:8080
DRILLER_BILL_AGENT_STATE_FILE=/path/to/agent-state.json
```

## SSH devices

The Devices workspace can register a Cisco IOS-style SSH device with:

- host/IP and port
- username
- private-key path, or an agent-side password environment variable reference
- optional agent-side enable-password environment variable reference
- host-key policy (`accept-new` by default, `yes`, or `no`)
- a privileged-login setting used by automated configuration

The actual password is never sent by the browser. The browser sends only the name of an environment variable that the local agent can read. The default authentication path is an SSH private key or an existing SSH agent.

The agent invokes the host operating system's `ssh` executable. The machine running the agent therefore needs an OpenSSH client available as `ssh` on PATH.

## Security boundary

The service binds to `127.0.0.1:8788` by default and accepts only loopback `Host` values. Request bodies are limited to 1 MiB, and bearer-token comparisons use a constant-time comparison when token lengths match. The browser never opens SSH sockets or serial ports. Device transport credentials remain inside the agent process and are never returned by the API. The default allowed origins include the Vite dev server (`5173`), Vite preview (`4173`) and local Docker web UI (`8080`); override the list explicitly when your deployment differs.

Host-key verification is enabled by default with `StrictHostKeyChecking=accept-new`, which accepts a new host key but rejects a changed key. Users can explicitly choose another policy when registering a device.

## Durable state

The executable agent persists registered external-device definitions, configuration history, the latest structured inspection report and the latest network discovery report. By default the state file is stored at `~/.driller-bill/agent-state.json`; override it with `DRILLER_BILL_AGENT_STATE_FILE`. Credentials themselves are not persisted: password authentication uses the name of an environment variable whose value remains in the agent process environment. State writes use an atomic temporary file + rename and restrictive local file permissions.

## Inspection

Connected devices can be inspected with: `POST /api/v1/devices/:id/inspect`. The agent gathers a small, standard IOS-style inspection set and returns structured interface, VLAN, trunk, route and version data. The last report can be retrieved after an agent restart with `GET /api/v1/devices/:id/inspection`.

## Raw command policy

The `/execute` endpoint is read-only for physical SSH and serial devices. It accepts bounded `show`, `ping`, `traceroute`, and `terminal length` commands. Mutations such as `reload`, `write erase`, `delete flash:`, and `configure terminal` are rejected and recorded in `GET /api/v1/devices/:id/execute-history`. Use the Plan → Preflight → Approve → Apply change-control flow for configuration changes. Simulated lab devices retain their training-console behaviour.

## API

- `GET /api/v1/health`
- `GET /api/v1/contract`
- `GET /api/v1/devices`
- `POST /api/v1/devices` — register an SSH device
- `DELETE /api/v1/devices/:id` — remove a registered SSH device
- `POST /api/v1/devices/:id/connect`
- `DELETE /api/v1/devices/:id/connect`
- `POST /api/v1/devices/:id/execute`
- `POST /api/v1/devices/:id/inspect`
- `GET /api/v1/devices/:id/inspection`
- `POST /api/v1/devices/:id/discover` — read-only CDP/LLDP neighbor discovery
- `GET /api/v1/devices/:id/discovery` — retrieve the latest discovery report
- `POST /api/v1/devices/:id/snapshot`
- `POST /api/v1/devices/:id/preflight-intent` — inspect, snapshot and create a short-lived change approval record
- `POST /api/v1/devices/:id/apply-intent` — apply an approved intent; physical SSH/serial changes require the matching preflight change ID
- `GET /api/v1/devices/:id/change-history` — retrieve redacted change-control records

## Change control

Configuration mutations now pass through a change-control boundary. The preflight step captures a pre-change configuration snapshot, evaluates the typed intent and current device health, classifies the risk, and creates a short-lived approval record. Physical SSH/serial mutations require that record before the agent accepts the change. The persisted change history contains display-safe command metadata; credential-bearing command text is not stored.

## Current transport support

- simulated: enabled
- SSH: enabled
- serial/console: enabled through the `serialport` package; supports local COM/tty paths, baud/data/stop/parity settings, and hardware/software/no flow control


## Serial dependency

The local Device Agent uses the official `serialport` package for cross-platform COM/tty access. Run `npm install` before starting the agent so its native serial bindings are installed.
