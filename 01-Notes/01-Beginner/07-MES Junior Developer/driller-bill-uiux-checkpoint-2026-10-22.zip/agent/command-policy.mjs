const SAFE_ARGUMENT = /^[a-z0-9][a-z0-9._:/-]*$/i;

/**
 * The raw execute route is deliberately read-only on physical devices.
 * Mutations must go through the validated preflight/change-control flow.
 */
export function isReadOnlyDeviceCommand(command) {
  const raw = String(command ?? '').trim();
  if (!raw || raw.length > 240 || /[\r\n\u0000;]/.test(raw)) return false;
  const value = raw.replace(/\s+/g, ' ');

  if (/^terminal length (?:0|[1-9]\d{0,2})$/i.test(value)) {
    const amount = Number(value.split(' ').at(-1));
    return amount <= 512;
  }

  const parts = value.split(' ');
  if (!/^(?:show|ping|traceroute)$/i.test(parts[0])) return false;
  return parts.slice(1).every(part => SAFE_ARGUMENT.test(part));
}
