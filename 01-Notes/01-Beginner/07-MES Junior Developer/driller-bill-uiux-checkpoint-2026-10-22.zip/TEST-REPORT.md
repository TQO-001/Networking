# Driller Bill — QA checkpoint (22 October 2026)

**Source baseline:** v64.0.6 archive. The working copy contains UI/UX and audit changes; `package.json` remains `64.0.6` until the release gate is complete.

## Automated checks — passed

- `node scripts/validate.mjs`: 73 source files scanned; 1,935 static questions across 387 families.
- `node scripts/validate-driller-bill.mjs`: 22 Driller Bill modules validated.
- `node scripts/validate-cloud.mjs`: 13 backend Python files validated.
- `node scripts/content-qa.mjs`: 53 objectives covered; 500 exhibit questions.
- `node scripts/release-check.mjs`: 8 release metadata pointers match package version 64.0.6.
- `node scripts/deploy-preflight.mjs`: PASS.
- `npm run check`: PASS after temporarily linking the environment's globally installed TypeScript package into this working copy so the syntax test and `tsc` could resolve it.
- Main Node test suite: **187/187 pass**, including source syntax, terminal helper and UI-contract regression tests.
- Device Agent suite: **23/23 pass**.
- Backend suite: **5/5 pass**.
- Browser preflight: PASS for installed Chromium and static sidebar CSS contract.

## UI/UX changes in this checkpoint

- Extended touch-friendly command keys to the physical-device console, not only the drill console.
- Added tested pure helpers for safe-catalogue command completion, caret-preserving symbol insertion, and up/down history with draft restoration.
- Added input attributes to prevent spellcheck, auto-capitalization and autocorrection from interfering with network commands.
- Mapped both modern `--ux-*` variables and original `--bg` / `--panel` / `--text` / accent aliases onto the persistent light/dark palette, with regression coverage.
- Enabled the touch-key row through 900 CSS pixels, covering phone and common tablet portrait widths.
- Updated `docs/IMPROVEMENT-AUDIT-ROADMAP.md`; L7 is checked as code-complete, with real-browser rendering still outstanding.

## Blocked / not verified

- `npm install --ignore-scripts --no-audit --no-fund` timed out; no project-local dependency tree or lockfile was generated.
- `npm run build`: **BLOCKED** — `vite: not found`. This is a missing dependency in this execution environment, not a successful build.
- Playwright E2E: configured but not run; the package is not installed. Chromium alone is not sufficient to run the suite.
- Docker Compose/image builds: not run because Docker is not installed.
- Physical SSH/serial hardware, browser rendering at phone/tablet sizes, service-worker behaviour in an actual browser, and cloud PostgreSQL integration remain untested.

## Reproduction on a networked development machine

Install the project dependencies first, then run:

```sh
npm install
npm run check
npm run build
npx playwright install chromium
npm run qa:e2e
```

The release is not considered complete until the production build and browser checks pass and any resulting issues are fixed.
