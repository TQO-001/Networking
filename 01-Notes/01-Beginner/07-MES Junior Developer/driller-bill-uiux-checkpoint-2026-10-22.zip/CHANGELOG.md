## v64.0.6 — Workspace layouts + terminal ergonomics

- Added shared terminal controls for text size, follow-output, sanitized copy, clear screen and expanded mode in simulated and physical device consoles.
- Made terminal font sizing a persistent 16–24px preference (18px default), with automatic scroll-follow that can be paused.
- Added Escape-to-exit and page-scroll locking for expanded terminal mode, accessible output regions and labelled CLI inputs.
- Redacted common password/secret lines in copied terminal transcripts.
- Reworked Devices page columns, device selector cards, device metrics, inspection panels and quick commands for desktop and narrow screens.
- Improved the stateful lab console and command reference layout for readable output and responsive sizing.
- Added targeted regression coverage for terminal preference, expansion, transcript sanitization and responsive workspace layout.

## v64.0.5 — Engineering-first UX polish

- Reworked the dashboard hero to position Driller Bill as a network-engineering workspace.
- Added six quick-launch cards for common engineering and learning tasks.
- Replaced Unicode sidebar glyphs with inline SVG icons; navigation groups can collapse and remember their state.
- Improved mobile drawer keyboard/focus behavior and kept search reachable on mobile.
- Strengthened body-copy sizing for important explanatory text.

## v64.0.4 — UX performance + Windows QA
- Fixed the Windows ESM loader URL used by Driller Bill module validation.
- Lazy-loaded heavy engineering/lab workspaces and added an accessible loading skeleton.
- Reduced initial font downloads with Latin/Latin Extended subsets.
- Added a working workspace command palette with `Ctrl/⌘+K` and arrow-key navigation.

## v64.0.3 — Windows-safe QA + final font precedence fix

- Replaced URL `.pathname` project-root resolution with `fileURLToPath()` in three tests; this is safe on Windows drive-letter paths.
- Put Google Sans ahead of Jost in the legacy global display-font token.
- Added regression assertions for the Windows path conversion and display-font precedence.
- Versioned the app, service-worker cache, and release pointers as 64.0.3.

# v64.0.2

## Critical JSX build fix

- Fixed a missing closing brace in the exam timer's JSX `className` expression. This was the parse error Vite reported at `src/App.jsx` around character offset 24,877.
- Added a parser regression test covering all JavaScript/JSX/MJS/CJS files so malformed JSX is caught by `npm test` before release.
- Bumped package and backup data metadata to `64.0.2`.
- Versioned the service-worker cache as `driller-bill-shell-v64.0.2` so this patch invalidates the previous v64 cache rather than reusing it.
- Updated README/release-history current-release pointers.

## Validation

- JavaScript/JSX parser scan: 101 files, zero syntax errors.
- Node test suite: 148/148 passed, including the new syntax regression test.
- Vite production build could not run in this environment because npm registry access failed with `EAI_AGAIN`. Run `npm run build` after dependencies are installed locally.

---

# v64.0.1

Deep-audit bugfixes: font stack correction, session-only agent token storage, PWA cache invalidation, current theme metadata, backup version metadata, and terminal button semantics.

## v64.0.0 — Unified UI System + Light/Dark Themes

- Replaced the v63 foundation-only pass with an application-wide soft neo-brutalist UI system.
- Added Google Sans + Google Sans Code via Fontsource.
- Added persistent light/dark theme selection.
- Added shared header/search/theme controls across normal workspaces and assessment screens.
- Reworked terminal, cards, buttons, panels, forms, tabs and navigation sizing for readability.
- Kept existing engineering, learning, device and safety logic unchanged.

## v63.0.0 — UX Rebuild Foundation
- Introduced the Soft Neo-Brutal design system.
- Removed unreadable micro-typography by raising the legacy CSS floor.
- Reworked application shell, sidebar, surfaces, controls, data cards, terminal typography, and exam surfaces.
- Added responsive readability rules, strong focus treatment, reduced-motion support, and high-contrast refinements.

## v62.0.0 — UI/UX Polish & Accessibility
- cyan-led visual system
- stronger contrast and readable type scale
- keyboard focus / skip link / reduced-motion / high-contrast support
- accessible tab and toggle states
- larger touch targets and mobile refinements

# Changelog

## 61.0.0 — Network Discovery & Topology Synchronization
- Added CDP/LLDP discovery parsing and normalized neighbor observations.
- Added a discovery graph that coalesces observations across devices and protocols.
- Added Device Agent discovery and persisted latest discovery reports.
- Added the Network Discovery workspace with device targeting, evidence reports, reconciliation and topology synchronization.
- Added non-destructive topology drift detection; discovery never removes existing topology links automatically.
- Added canonical discovery exports through `src/core/index.js`.

## 59.0.0 — Change Control & Operational Hardening
- Added mandatory preflight records for physical SSH/serial configuration mutations.
- Added risk classification, fresh inspection, diagnostics, baseline snapshot and short-lived approval checks.
- Added persistent, sanitized change history with pre/post configuration snapshot references.
- Added Plan → Preflight → Approve → Apply → Verify flow to Configuration and Runbooks.
- Hardened API responses and configuration history against credential-bearing command/state leakage.
- Preserved simulated-device compatibility while enforcing approval on live physical devices.

## 58.0.0 — Unified Workflows
- Connected knowledge, drills, troubleshooting, configuration, runbooks, devices and Twin through a persistent workflow thread.
- Added workflow orchestration core, workspace and context bar.
- Added local workflow history, notes and stage artifacts.

## v55.0.0 — Twin Intelligence

- Added first-class Twin Intelligence engineering workspace with investigate, explain, diagnose, plan, review, and document modes.
- Added local knowledge retrieval across the v53 Knowledge Graph and article corpus.
- Added observed-device reasoning using structured inspection and diagnostics from the shared network workspace.
- Added typed configuration proposal generation for supported intents, without direct device application.
- Added bounded local Twin history with redacted records.
- Added sanitized model-context export/copy for optional bring-your-own-LLM workflows.
- Added safety guardrails separating observation, inference, and configuration approval.

## v54.0.0 — Troubleshooting Workspace

- Added four built-in troubleshooting cases spanning interface, VLAN/trunk, static-route and OSPF faults.
- Added deterministic evidence collection, hypothesis ranking, test evaluation and remediation planning.
- Added simulation fault injection/reset paths and live Device Agent evidence support.
- Added reusable local custom troubleshooting case authoring.
- Added first-class Troubleshooting navigation/workspace and Knowledge Graph linkage.

# v53.0.0 — Knowledge Graph
- Connected Knowledge Base articles to drills, runbooks, scenarios, typed configuration intents, and network workspaces.
- Added contextual Knowledge Base actions and deep-link persistence for Driller Bill modules and runbooks.
- Added graph statistics and relationship validation.
- Fixed stale related-article references that could resolve to the default article.

## v49.0.0 — Engineering workbench expansion

- Richer interface/VLAN/trunk configuration intents with bulk access assignment.
- First reusable job-style device scenario with state-based verification.
- Structured switch inspection now includes interface documentation, switchport VLAN state and trunk allowed VLAN evidence.
- Configuration workbench adds Scenarios workflow and reviewed-step execution.

## v43.0.0 — Local Device Agent

- Added localhost Device Agent service and browser client.
- Wired simulated agent sessions into Devices.
- Added live CLI, intent application and config snapshots through the agent boundary.

## v41.0.0 — Knowledge foundation + engineering workspace direction

- Added a structured local-first Knowledge Base with searchable articles, categories, command references and related-concept links.
- Added knowledge objects designed to become shared references for drills, device configuration, verification and Twin intelligence.
- Added Engineering navigation surfaces for Devices, Configuration and Runbooks as architectural placeholders for the device-agent roadmap.
- Reframed Driller Bill workspace branding from CCNA-only training toward a broader network engineering workspace while preserving the existing simulator and learning tools.

# Changelog

## 61.0.0 — Network Discovery & Topology Synchronization
- Added CDP/LLDP discovery parsing and normalized neighbor observations.
- Added a discovery graph that coalesces observations across devices and protocols.
- Added Device Agent discovery and persisted latest discovery reports.
- Added the Network Discovery workspace with device targeting, evidence reports, reconciliation and topology synchronization.
- Added non-destructive topology drift detection; discovery never removes existing topology links automatically.
- Added canonical discovery exports through `src/core/index.js`.

## v57.0.0 — Serial / Console Device Support

- Added a real serial/console Device Agent adapter alongside simulated and SSH transports.
- Added cross-platform COM/tty configuration for baud, data bits, stop bits, parity and flow control.
- Added serial handshake, command execution, inspection, snapshots, typed intents and enable-password flow.
- Extended physical-device registration and inventory UI for Serial / Console targets.
- Added `serialport` 13.0.0 as the cross-platform serial transport dependency.


## v56.0.0 — Network & Device Operations

- Expanded the typed device-operation catalog to 32 Cisco IOS-style intents spanning OSPF, ACLs, access-port security, STP, EtherChannel, NAT, DHCP, management and IPv6.
- Added structured inspection fields for protocol/service state and stronger runbook verification of interface-scoped operations.
- Added redacted display commands for credential-bearing local-user plans so secrets are never shown in Configuration/Devices/Twin previews.
- Extended Twin natural-language intent detection and sanitized model context for the v56 operational surface.


## v52.0.0 — Runbooks

- Added first-class Runbooks workspace with executable, step-gated network procedures.
- Added built-in operational runbooks and local custom runbook authoring.
- Added runbook verification against live inspection and configuration diagnostics.


## v51.0.0 — First-class configuration workspace

- Replaced the Configuration navigation placeholder with the real Device Agent-backed configuration surface.
- Added a focused configuration mode that keeps device targeting, connection state, structured inspection, intent planning, apply/verify flow, diagnostics, and configuration history together.
- Reused the existing deterministic intent engine and local-agent boundary instead of creating a second configuration stack.
- Preserved the Devices workspace as the broader inventory, CLI and device-operations surface.


## 34.0.0 — Driller Bill Integration
- Renamed the product identity to Driller Bill.
- Integrated the original Driller Bill module engine catalog from v0.5.1.
- Added guided theory, simulation, hands-on drills, Speed Run, Sandbox, Twin, Notes, Progress and Drill Builder surfaces to the modern platform.
- Preserved the modern randomized CCNA exam, PBQ, topology, packet, mastery, authoring and cloud systems.
- Added real Twin ZIP export and local session artifacts.

## v38.0.0 — Result + remediation

- Redesigned drill completion as a session debrief.
- Added next-step remediation guidance based on incomplete objectives.
- Added explicit outcome state: target reached, mostly complete, or remediation needed.
- Added error-loop summary linking recorded friction back to Twin.
- Preserved existing drill, Twin, mastery, and network engines.

## v40.0.0 — Twin intelligence
- Added deterministic Twin inference for repeated errors, theory-linked friction, objective friction, typo signals, unfinished objectives, and repeated rejected commands.
- Added ranked recommendations and a dedicated Intelligence view.
- Added live inference to the practice telemetry panel.
- Added automated Twin intelligence coverage.

## v42.0.0 — Device architecture
- Added network-device model and inventory primitives.
- Added simulated device adapter and device-agent protocol boundary.
- Added intent-driven configuration planner for VLAN and switching operations.
- Replaced the Devices placeholder with a functional engineering workspace and non-destructive configuration preview.

## v44.0.0 — Real SSH transport
- Added the Node-only OpenSSH device adapter and agent-side authentication boundary.
- Added physical SSH device registration, inventory, connect/execute, intent apply and config snapshot plumbing.
- Added Devices UI for registering SSH-managed Cisco IOS-style equipment.
- Kept the browser-safe core free of Node transport dependencies.

## v45.0.0 — Configuration history + diff
- Added local device configuration history and comparison APIs.
- Added redacted snapshot records, timeline UI, and running-config diffs.
- Approved intents now produce an auditable post-change snapshot.

## v46.0.0 — Durable device state + structured inspection
- Persist registered physical device definitions, configuration history, and latest inspection reports to the local Device Agent state file.
- Add structured Cisco IOS inspection for interfaces, VLANs, trunks, routes, versions, and observations.
- Add inspection API endpoints and Devices workspace inspection surface.
- Keep persisted state free of live credential values; state files are written with restrictive local permissions.

## v47.0.0 — Device state & diagnostics
- Add deterministic device diagnostics derived from structured inspection and configuration history.
- Add interface, VLAN, trunk, and route engineering views in the Devices workspace.
- Add startup-vs-running alignment checks and recent configuration change summaries.
- Add local diagnostics API and refreshable engineering health surface.

## v48.0.0 — Configuration workbench
- Added VLAN Manager, Interface Manager, and routing views to the Devices workspace.
- Added `Save Running Config` intent and IOS-style `write memory` command plan.
- Added unified GUI configuration workflow with preview, apply, verify and snapshot stages.
- Post-change intents now re-inspect connected devices to refresh structured state.

## v50.0.0 — Device operations & routed recovery

- Added IPv4 static-route add/remove intents for routers.
- Added routing workbench action for static routes.
- Expanded operational CLI quick commands.
- Added routed-edge recovery scenario with structured-state verification.

## v50.0.0 — Device operations & routed recovery

- Added IPv4 static-route add/remove intents for routers.
- Added routing workbench action for static routes.
- Expanded operational CLI quick commands.
- Added routed-edge recovery scenario with structured-state verification.

## v60.0.0 — Multi-device Operations & Change Sets
- Added coordinated multi-device change-set orchestration.
- Added per-device typed plan compilation and capability validation.
- Added stop-on-failure / continue-on-failure execution strategies.
- Added change-set history with sanitized persistence.
- Added Change Sets engineering workspace.
