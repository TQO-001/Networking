import React,{useMemo,useState} from 'react';
import { FLOW_SCENARIOS, freshFlowState, buildFlow, repairFlow } from './core/flow-engine.js';
import { executeProtocolCommand } from './core/protocol-engine.js';

function Badge({children,ok=false}){return <span className={`flow-badge ${ok?'good':''}`}>{children}</span>}
function FlowLab(){
  const [scenarioId,setScenarioId]=useState(FLOW_SCENARIOS[0].id);
  const [state,setState]=useState(()=>freshFlowState());
  const [replay,setReplay]=useState(0);
  const trace=useMemo(()=>buildFlow(state,scenarioId),[state,scenarioId,replay]);
  const [visible,setVisible]=useState(trace.steps.length);
  React.useEffect(()=>setVisible(trace.steps.length),[scenarioId,state,replay,trace.steps.length]);
  const selected=trace.scenario;
  const runPrerequisite=()=>{ setState(prev=>repairFlow(prev,scenarioId)); setReplay(x=>x+1); };
  return <main className="page flow-page">
    <div className="page-title flow-title"><div><div className="eyebrow">NETWORK LAB / PROTOCOL OBSERVATORY</div><h1>Watch the <span>packet.</span></h1><p>Trace a controlled network event one state transition at a time. Evidence stays tied to the simulated topology.</p></div><div className="flow-title-meta"><span>STATEFUL</span><b>IOS / L2 / L3</b></div></div>
    <div className="flow-layout">
      <aside className="flow-catalog panel"><div className="panel-head"><div><div className="kicker">01 / FLOWS</div><h2>Select an event.</h2></div><span className="panel-micro">7 scenarios</span></div>{FLOW_SCENARIOS.map(s=><button key={s.id} className={`flow-scenario ${scenarioId===s.id?'active':''}`} onClick={()=>setScenarioId(s.id)}><div><span>{s.protocol}</span><strong>{s.title}</strong><small>{s.objective}</small></div><b>→</b></button>)}</aside>
      <section className="flow-main">
        <section className="panel flow-hero"><div className="flow-hero-head"><div><div className="kicker">02 / SELECTED TRACE</div><h2>{selected.title}</h2><p>{selected.description}</p></div><Badge ok={trace.complete}>{trace.status}</Badge></div><div className="flow-metrics"><div><small>PROTOCOL</small><b>{selected.protocol}</b></div><div><small>PATH</small><b>{selected.source} → {selected.destination}</b></div><div><small>CHECKS</small><b>{trace.passed}/{trace.total}</b></div><div><small>TARGET</small><b>{selected.objective}</b></div></div><div className="flow-actions"><button className="button primary" onClick={()=>{setVisible(0);setReplay(x=>x+1)}}>Replay trace</button><button className="button" onClick={runPrerequisite}>Repair prerequisites</button><span className="flow-hint">Replay is observational; repair changes the simulated device state.</span></div></section>
        <section className="panel flow-trace"><div className="panel-head"><div><div className="kicker">03 / STATE TRANSITIONS</div><h2>Evidence chain.</h2></div><span className="panel-micro">{selected.duration}</span></div><div className="flow-steps">{trace.steps.map((s,i)=><article key={s.id} className={`flow-step ${s.ok?'pass':'blocked'} ${i<visible?'revealed':''}`}><div className="flow-step-index">{String(i+1).padStart(2,'0')}</div><div className="flow-step-body"><div className="flow-step-top"><div><span>{s.label}</span><strong>{s.device}</strong></div><Badge ok={s.ok}>{s.status}</Badge></div><h3>{s.event}</h3><p>{s.detail}</p><code>{s.evidence}</code></div></article>)}</div><div className="flow-controls"><button className="button" disabled={visible>=trace.steps.length} onClick={()=>setVisible(v=>Math.min(trace.steps.length,v+1))}>Next transition</button><span>{Math.min(visible,trace.steps.length)} / {trace.steps.length} visible</span></div></section>
        <section className="panel flow-readout"><div><div className="kicker">04 / INTERPRETATION</div><h2>{trace.complete?'Flow complete.':'Flow blocked.'}</h2><p>{trace.complete?'Every prerequisite in this trace is satisfied. Use the same evidence chain when diagnosing an exam scenario.':'Start with the first BLOCKED transition. That is the earliest state preventing the packet or protocol event from progressing.'}</p></div><div className="flow-readout-box"><span>FIRST BLOCK</span><b>{trace.steps.find(s=>!s.ok)?.label||'NONE'}</b></div></section>
      </section>
    </div>
  </main>
}
export default FlowLab;
