import React, { useMemo, useState } from 'react';
import { conceptName } from './core/exam-engine.js';
import { gradeLabel, masteryStats } from './core/mastery-engine.js';

const dayLabel = days => days <= 0 ? 'now' : days === 1 ? '1 day' : `${days} days`;
const fmtDue = (ts, now=Date.now()) => {
  const delta = ts - now;
  if (delta <= 0) return 'Due now';
  const mins = Math.ceil(delta / 60000);
  if (mins < 60) return `in ${mins}m`;
  const hrs = Math.ceil(mins / 60);
  if (hrs < 24) return `in ${hrs}h`;
  return `in ${Math.ceil(hrs / 24)}d`;
};

export default function MasteryReview({ mastery, onGrade, onBack }) {
  const [position, setPosition] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const now = Date.now();
  const cards = useMemo(() => Object.values(mastery).filter(c => (c.dueAt || 0) <= now).sort((a,b)=>(a.dueAt||0)-(b.dueAt||0)), [mastery, now]);
  const stats = useMemo(() => masteryStats(mastery, now), [mastery, now]);
  const card = cards[position];

  const advance = (grade) => {
    if (!card) return;
    onGrade(card, grade);
    setRevealed(false);
    setPosition(p => p >= cards.length - 1 ? 0 : p + 1);
  };

  if (!cards.length) return <main className="page mastery-page"><section className="page-title compact"><div><div className="eyebrow">REVIEW QUEUE / SPACED REPETITION</div><h1>Nothing is due.<br/><span>Stay ahead.</span></h1><p>Your current learning queue is clear. New cards enter the schedule as you complete assessments and study sessions.</p></div><button className="button" onClick={onBack}>Back to console</button></section><section className="mastery-overview"><div className="panel mastery-stat"><span>DUE</span><strong>0</strong><small>cards right now</small></div><div className="panel mastery-stat"><span>LEARNING</span><strong>{stats.learning}</strong><small>active intervals</small></div><div className="panel mastery-stat"><span>MASTERED</span><strong>{stats.mastered}</strong><small>14+ day retention</small></div><div className="panel mastery-stat"><span>TRACKED</span><strong>{stats.total}</strong><small>concept cards</small></div></section><section className="panel mastery-next"><div className="panel-head"><div><div className="kicker">NEXT SIGNAL</div><h2>Come back after your next form.</h2></div></div><p>Good answers push cards farther into the future. Repeated misses pull them back into the queue.</p></section></main>;

  const q = card.question || {};
  const answerIndexes = new Set(card.question?.answer || []);
  return <main className="page mastery-page"><section className="page-title compact"><div><div className="eyebrow">REVIEW QUEUE / SPACED REPETITION</div><h1>Recall it.<br/><span>Then rate it.</span></h1><p>Cards are scheduled from your assessment history. Review the concept before revealing the rationale.</p></div><div className="mastery-header-stat"><strong>{stats.due}</strong><span>due now</span></div></section>
    <section className="mastery-layout">
      <section className="panel review-card">
        <div className="review-card-top"><div><div className="kicker">CARD {position+1} / {cards.length}</div><h2>{card.concept}</h2></div><div className="review-meta"><span>{card.topic}</span><span>{card.difficulty}</span><span>{fmtDue(card.dueAt, now)}</span></div></div>
        <div className="review-prompt">{q.q || `Review ${conceptName(card.topic)}.`}</div>
        {q.options?.length ? <div className="review-options">{q.options.map((option,i)=><div key={i} className={`review-option ${revealed && answerIndexes.has(i) ? 'correct':''}`}><b>{String.fromCharCode(65+i)}</b><span>{option}</span>{revealed && answerIndexes.has(i) && <em>correct</em>}</div>)}</div> : null}
        {!revealed ? <div className="review-actions"><button className="button primary large" onClick={()=>setRevealed(true)}>Reveal rationale</button><span>Try to recall the answer before revealing.</span></div> : <><div className="review-rationale"><div className="kicker">RATIONALE</div><p>{q.explanation || 'Review the concept and compare your reasoning with the documented answer.'}</p></div><div className="grade-grid"><button className="grade again" onClick={()=>advance('again')}><strong>Again</strong><span>10 minutes</span></button><button className="grade hard" onClick={()=>advance('hard')}><strong>Hard</strong><span>~{dayLabel(Math.max(1, Math.round((card.interval||1)*1.2)))}</span></button><button className="grade good" onClick={()=>advance('good')}><strong>Good</strong><span>next interval</span></button><button className="grade easy" onClick={()=>advance('easy')}><strong>Easy</strong><span>long interval</span></button></div></>}
      </section>
      <aside className="mastery-side"><section className="panel"><div className="panel-head"><div><div className="kicker">QUEUE HEALTH</div><h2>Retention loop</h2></div></div><div className="mastery-mini-grid"><div><span>Learning</span><strong>{stats.learning}</strong></div><div><span>Mastered</span><strong>{stats.mastered}</strong></div><div><span>Tracked</span><strong>{stats.total}</strong></div><div><span>Avg ease</span><strong>{stats.avgEase || '—'}</strong></div></div></section><section className="panel"><div className="panel-head"><div><div className="kicker">SCHEDULE</div><h2>Next review</h2></div></div><p>Intervals grow when you remember a concept and contract when you miss it.</p><div className="interval-line"><span>Current interval</span><strong>{card.interval ? `${card.interval}d` : 'learning'}</strong></div><div className="interval-line"><span>Review streak</span><strong>{card.streak || 0}</strong></div><div className="interval-line"><span>Lapses</span><strong>{card.lapses || 0}</strong></div></section></aside>
    </section>
  </main>;
}

export { gradeLabel };
