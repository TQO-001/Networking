import React, { useMemo, useState } from 'react';
import { safeStorage } from './storage.js';
import { useNetworkWorkspace } from './context/NetworkWorkspaceContext.jsx';
import { CONFIG_INTENTS, buildDeviceInventory, planIntent } from './core/device-model.js';
import { agentApplyIntent, agentConnect, agentDevices, agentInspect, agentPreflightIntent } from './core/device-agent-client.js';
import { buildChangeSet, compileChangeSet, loadChangeSets, saveChangeSets, normalizeChangeSet, addChangeSetTimeline, progressForChangeSet } from './core/change-sets.js';

function Icon({ name, size = 15 }) {
  const p = {
    plus: <><path d="M12 5v14"/><path d="M5 12h14"/></>,
    play: <path d="M8 5l11 7-11 7V5z" fill="currentColor"/>,
    check: <path d="m5 12 4 4L19 6"/>,
    refresh: <><path d="M20 11a8 8 0 0 0-14-4l-2 2"/><path d="M4 5v4h4"/><path d="M4 13a8 8 0 0 0 14 4l2-2"/><path d="M20 19v-4h-4"/></>,
    x: <><path d="m6 6 12 12"/><path d="m18 6-12 12"/></>,
    arrow: <><path d="M5 12h13"/><path d="m13 6 6 6-6 6"/></>,
    terminal: <><path d="M4 5h16v14H4z"/><path d="m7 9 3 3-3 3M12 15h5"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{p[name]}</svg>;
}

const DEFAULT_INTENT = CONFIG_INTENTS.find(item => item.id === 'create-vlan') || CONFIG_INTENTS[0];

function fieldDefaults(intent) {
  return Object.fromEntries((intent?.fields || []).map(field => [field.id, field.options?.[0]?.value ?? '']));
}

function riskLabel(level) { return String(level || 'high').toUpperCase(); }

function ChangeItem({ item, selected, onToggle }) {
  return <button type="button" className={`change-set-device-row ${selected ? 'selected' : ''}`} onClick={() => onToggle(item.id)}>
    <span className="change-set-check">{selected ? '✓' : ''}</span>
    <div><strong>{item.id}</strong><small>{item.kind} · {item.connection?.type || 'simulated'} · {item.source || 'lab'}</small></div>
    <b>{item.connection?.status || 'ready'}</b>
  </button>;
}

export default function ChangeSets() {
  const { labState } = useNetworkWorkspace();
  const localDevices = useMemo(() => buildDeviceInventory(labState), [labState]);
  const [devices, setDevices] = useState(localDevices);
  const [selectedIds, setSelectedIds] = useState(localDevices.slice(0, 2).map(item => item.id));
  const [intentType, setIntentType] = useState(DEFAULT_INTENT?.id || 'create-vlan');
  const [fields, setFields] = useState(() => fieldDefaults(DEFAULT_INTENT));
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [strategy, setStrategy] = useState('stop-on-failure');
  const [agentUrl, setAgentUrl] = useState('http://127.0.0.1:8788');
  const [agentToken, setAgentToken] = useState('');
  const [plan, setPlan] = useState(null);
  const [running, setRunning] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [history, setHistory] = useState(() => loadChangeSets(safeStorage));
  const [active, setActive] = useState(null);

  const intent = useMemo(() => CONFIG_INTENTS.find(item => item.id === intentType) || DEFAULT_INTENT, [intentType]);
  const progress = progressForChangeSet(active);

  const toggleDevice = id => setSelectedIds(current => current.includes(id) ? current.filter(value => value !== id) : [...current, id]);

  const changeIntent = type => {
    const next = CONFIG_INTENTS.find(item => item.id === type) || DEFAULT_INTENT;
    setIntentType(next.id);
    setFields(fieldDefaults(next));
    setPlan(null);
  };

  const refreshInventory = async () => {
    setBusy(true);
    setMessage('Refreshing device inventory…');
    try {
      const result = await agentDevices({ baseUrl: agentUrl, token: agentToken });
      if (Array.isArray(result.devices)) setDevices(result.devices);
      setMessage('Device inventory refreshed.');
    } catch (error) {
      setDevices(localDevices);
      setMessage(`Agent inventory unavailable; showing local lab devices. ${error.message}`);
    } finally { setBusy(false); }
  };

  const selectedDevices = useMemo(() => devices.filter(device => selectedIds.includes(device.id)), [devices, selectedIds]);

  const preview = () => {
    const items = selectedDevices.map(device => ({ deviceId: device.id, deviceType: device.kind, transport: device.connection?.type, label: intent.title, intent: { type: intent.id, fields } }));
    const built = buildChangeSet({ title: title.trim() || `${intent.title} across ${items.length} devices`, description: description.trim(), strategy, items });
    const compiled = compileChangeSet(built.changeSet, selectedDevices, planIntent);
    const next = normalizeChangeSet({ ...built.changeSet, items: compiled.items, maxRisk: compiled.maxRisk, status: compiled.valid ? 'draft' : 'blocked' });
    setPlan({ ...compiled, changeSet: next });
    setActive(next);
    setMessage(compiled.valid ? `Preview ready for ${compiled.total} device${compiled.total === 1 ? '' : 's'}.` : compiled.errors.join(' '));
  };

  const persist = next => {
    const nextHistory = [next, ...history.filter(item => item.id !== next.id)].slice(0, 60);
    setHistory(nextHistory);
    saveChangeSets(safeStorage, nextHistory.slice().reverse());
    setActive(next);
    return next;
  };

  const preflightAll = async () => {
    if (!plan?.changeSet || !plan.valid || !agentToken) return;
    setBusy(true);
    let next = normalizeChangeSet({ ...plan.changeSet, status: 'preflighted', approvedAt: null });
    const results = [];
    for (const item of next.items) {
      try {
        await agentConnect(item.deviceId, { baseUrl: agentUrl, token: agentToken });
        const result = await agentPreflightIntent(item.deviceId, item.intent, { baseUrl: agentUrl, token: agentToken });
        const r = result.result || result;
        results.push({ ...item, status: r.valid ? 'preflighted' : 'blocked', preflight: r.preflight ? { ...r.preflight, changeId: r.changeId || '' } : null, plan: r.plan || item.plan, changeId: r.changeId || '', error: r.valid ? '' : (r.preflight?.summary || 'Preflight blocked.') });
      } catch (error) {
        results.push({ ...item, status: 'blocked', error: error.message });
      }
    }
    const blocked = results.filter(item => item.status !== 'preflighted');
    next = addChangeSetTimeline({ ...next, items: results, status: blocked.length ? 'blocked' : 'preflighted' }, 'preflighted', blocked.length ? `${blocked.length} device preflight(s) blocked.` : `All ${results.length} device preflights passed.`);
    if (!blocked.length) next.approvedAt = null;
    persist(next);
    setPlan({ valid: !blocked.length, errors: results.flatMap(item => item.error ? [`${item.deviceId}: ${item.error}`] : []), total: results.length, ready: results.length, items: results, changeSet: next });
    setMessage(blocked.length ? `${blocked.length} device${blocked.length === 1 ? '' : 's'} blocked during preflight.` : 'All device preflights passed. Review the change set, then apply it.');
    setBusy(false);
  };

  const applyAll = async () => {
    if (!active || active.status !== 'preflighted' || !active.items.length) return;
    if (active.items.some(item => item.status === 'preflighted' && !item.changeId)) { setMessage('This change set no longer has reusable approval records. Run preflight again before applying it.'); return; }
    setRunning(true);
    const approvedAt = new Date().toISOString();
    const started = addChangeSetTimeline({ ...active, status: 'running', approvedAt, startedAt: approvedAt }, 'approved', 'Change set explicitly approved; execution started.');
    persist(started);
    let next = started;
    for (let index = 0; index < next.items.length; index += 1) {
      const item = next.items[index];
      if (item.status !== 'preflighted' || !item.changeId) continue;
      try {
        const result = await agentApplyIntent(item.deviceId, item.intent, { baseUrl: agentUrl, token: agentToken, changeId: item.changeId });
        const inspected = await agentInspect(item.deviceId, { baseUrl: agentUrl, token: agentToken });
        const updatedItem = { ...item, status: result.result?.change?.status === 'applied' ? 'completed' : 'failed', completedAt: new Date().toISOString(), verification: { passed: result.result?.change?.status === 'applied', detail: result.result?.changeSummary || 'Change applied and snapshot captured.', inspectedAt: inspected.report?.inspectedAt || null }, error: result.result?.change?.status === 'applied' ? '' : 'Device reported that the change was not fully applied.' };
        next = normalizeChangeSet({ ...next, items: next.items.map((entry, itemIndex) => itemIndex === index ? updatedItem : entry), updatedAt: new Date().toISOString() });
        next = addChangeSetTimeline(next, 'device-complete', `${item.deviceId}: ${updatedItem.status === 'completed' ? 'change applied and verified.' : 'change failed.'}`);
        persist(next);
        if (updatedItem.status === 'failed' && next.strategy === 'stop-on-failure') {
          next = addChangeSetTimeline({ ...next, status: 'partial' }, 'stopped', `Stopped after ${item.deviceId} failed.`);
          persist(next);
          break;
        }
      } catch (error) {
        const updatedItem = { ...item, status: 'failed', completedAt: new Date().toISOString(), error: error.message };
        next = normalizeChangeSet({ ...next, items: next.items.map((entry, itemIndex) => itemIndex === index ? updatedItem : entry) });
        next = addChangeSetTimeline(next, 'device-failed', `${item.deviceId}: ${error.message}`);
        persist(next);
        if (next.strategy === 'stop-on-failure') {
          next = addChangeSetTimeline({ ...next, status: 'partial' }, 'stopped', `Stopped after ${item.deviceId} failed.`);
          persist(next);
          break;
        }
      }
    }
    const finalProgress = progressForChangeSet(next);
    const unresolved = next.items.filter(item => !['completed', 'failed'].includes(item.status));
    const finalStatus = finalProgress.failed > 0 ? (finalProgress.completed > 0 ? 'partial' : 'failed') : unresolved.length ? 'partial' : 'completed';
    next = addChangeSetTimeline({ ...next, status: finalStatus, completedAt: new Date().toISOString() }, finalStatus, finalStatus === 'completed' ? 'All device changes completed and verified.' : 'Change set finished with partial or failed device changes.');
    persist(next);
    setRunning(false);
    setMessage(finalStatus === 'completed' ? 'Change set completed successfully.' : `Change set finished as ${finalStatus}. Review each device before attempting another change.`);
  };

  return <main className="page change-sets-page">
    <section className="change-set-hero">
      <div><div className="eyebrow">ENGINEERING / MULTI-DEVICE CHANGE CONTROL</div><h1>One change.<br/><span>Many devices.</span></h1><p>Coordinate the same typed configuration intent across a device group with per-device planning, preflight, approval, controlled execution and verification.</p></div>
      <div className="change-set-hero-stat"><strong>{active ? `${progress.percent}%` : selectedDevices.length}</strong><span>{active ? `${progress.completed}/${progress.total} verified` : 'selected targets'}</span></div>
    </section>

    <section className="change-set-grid">
      <section className="panel change-set-builder">
        <div className="change-set-section-head"><div><div className="kicker">01 / TARGETS</div><h2>Select devices</h2><p>Every selected device receives its own plan and change-control record.</p></div><button className="button" onClick={refreshInventory} disabled={busy}><Icon name="refresh" size={12}/> Refresh</button></div>
        <div className="change-set-device-list">{devices.map(device => <ChangeItem key={device.id} item={device} selected={selectedIds.includes(device.id)} onToggle={toggleDevice}/>)}</div>
        <div className="change-set-selected-count">{selectedDevices.length} selected · changes apply independently per device</div>
      </section>

      <section className="panel change-set-builder">
        <div className="change-set-section-head"><div><div className="kicker">02 / INTENT</div><h2>Describe the change once</h2><p>Driller Bill compiles the typed intent against each target's capabilities.</p></div></div>
        <div className="change-set-form"><label><span>INTENT</span><select value={intentType} onChange={event => changeIntent(event.target.value)}>{CONFIG_INTENTS.map(item => <option key={item.id} value={item.id}>{item.title}</option>)}</select></label>{intent?.fields?.map(field => <label key={field.id}><span>{field.label}</span>{field.input === 'select' ? <select value={fields[field.id] ?? ''} onChange={event => setFields(current => ({ ...current, [field.id]: event.target.value }))}>{field.options.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}</select> : <input type={field.input} value={fields[field.id] ?? ''} placeholder={field.placeholder} onChange={event => setFields(current => ({ ...current, [field.id]: event.target.value }))}/>}</label>)}<label><span>CHANGE SET TITLE</span><input value={title} onChange={event => setTitle(event.target.value)} placeholder={`${intent?.title || 'Network'} across branch switches`}/></label><label><span>EXECUTION STRATEGY</span><select value={strategy} onChange={event => setStrategy(event.target.value)}><option value="stop-on-failure">Stop on first failure</option><option value="continue-on-failure">Continue independent devices</option></select></label><label><span>DESCRIPTION</span><textarea value={description} rows={3} onChange={event => setDescription(event.target.value)} placeholder="Why is this change being made?"/></label></div>
        <button className="button primary" onClick={preview} disabled={!selectedDevices.length}><Icon name="terminal" size={12}/> Compile change set</button>
      </section>
    </section>

    <section className="panel change-set-control">
      <div className="change-set-section-head"><div><div className="kicker">03 / AGENT & EXECUTION</div><h2>Preflight every target before approval</h2><p>Physical device changes use the v59 change-control contract. A single failed preflight prevents the whole set from being approved.</p></div><span className={`change-set-risk ${active?.maxRisk?.level || 'low'}`}>{riskLabel(active?.maxRisk?.level || 'low')}</span></div>
      <div className="change-set-agent-grid"><label><span>AGENT URL</span><input value={agentUrl} onChange={event => setAgentUrl(event.target.value)}/></label><label><span>AGENT TOKEN</span><input type="password" value={agentToken} onChange={event => setAgentToken(event.target.value)} placeholder="Required for agent operations"/></label></div>
      {active && <div className="change-set-overview"><div><strong>{active.title}</strong><span>{active.description || 'No description supplied.'}</span></div><div className="change-set-overview-stats"><b>{active.items.length}</b><small>devices</small><b>{riskLabel(active.maxRisk.level)}</b><small>max risk</small></div></div>}
      {active && <div className="change-set-results">{active.items.map(item => <article key={item.id} className={`change-set-result ${item.status}`}><div><span>{item.id}</span><strong>{item.label}</strong><small>{item.transport} · {item.deviceType}</small></div><div><b>{item.status.toUpperCase()}</b>{item.error ? <small>{item.error}</small> : item.preflight?.summary ? <small>{item.preflight.summary}</small> : item.verification?.detail ? <small>{item.verification.detail}</small> : <small>{item.plan?.displayCommands?.length || 0} commands planned</small>}</div></article>)}</div>}
      {!active && <div className="change-set-empty">Compile a change set above to see per-device plans.</div>}
      <div className="change-set-control-actions"><button className="button" onClick={preflightAll} disabled={!active || active.status === 'blocked' || !plan?.valid || busy || !agentToken}>{busy ? 'Preflighting…' : 'Preflight all devices'}</button><button className="button primary" onClick={applyAll} disabled={!active || active.status !== 'preflighted' || running || !agentToken}>{running ? 'Executing…' : 'Approve & apply change set'}</button></div>
      <div className="change-set-notice"><strong>NO AUTOMATIC ROLLBACK</strong><span>Multi-device changes stop or continue according to the selected strategy. A partial set is never silently reverted; use each device's pre-change snapshot to design a reviewed rollback.</span></div>
    </section>

    {history.length > 0 && <section className="panel change-set-history"><div className="change-set-section-head"><div><div className="kicker">04 / HISTORY</div><h2>Recent change sets</h2></div><span>{history.length} preserved locally</span></div><div className="change-set-history-list">{history.slice(0, 10).map(item => <button key={item.id} type="button" onClick={() => { setActive(item); setPlan({ changeSet: item, valid: item.status === 'preflighted', items: item.items, total: item.items.length, ready: item.items.length }); }}><span>{item.status}</span><strong>{item.title}</strong><small>{item.items.length} devices · {progressForChangeSet(item).percent}% · {new Date(item.updatedAt).toLocaleString()}</small><b>{riskLabel(item.maxRisk.level)}</b></button>)}</div></section>}
    {message && <div className="change-set-toast" role="status">{message}</div>}
  </main>;
}
