import { freshPacketState, repairPacketCase, derivePacketState } from './packet-engine.js';

export const PACKET_PROFILES = [
  { id:'ipv4-icmp', label:'IPv4 / ICMP', source:'PC1', destination:'SRV1', destinationIp:'10.20.20.10', protocol:'ICMP', network:'internal' },
  { id:'ipv4-https', label:'IPv4 / HTTPS', source:'PC1', destination:'WAN', destinationIp:'198.51.100.10', protocol:'TCP/443', network:'internet' },
  { id:'ipv4-icmp-wan', label:'IPv4 / ICMP to WAN', source:'PC1', destination:'WAN', destinationIp:'198.51.100.10', protocol:'ICMP', network:'internet' },
  { id:'ipv6-icmp', label:'IPv6 / ICMPv6', source:'PC1', destination:'SRV1', destinationIp:'2001:db8:20::10', protocol:'ICMPv6', network:'internal-v6' },
  { id:'dhcp', label:'DHCP / DORA', source:'PC2', destination:'DHCP', destinationIp:'10.10.10.100', protocol:'UDP/67-68', network:'dhcp' },
  { id:'ospf', label:'OSPF / Hello', source:'R1', destination:'R2', destinationIp:'224.0.0.5', protocol:'OSPF', network:'control-plane' },
];

export const WORKSHOP_FAULTS = [
  { id:'none', label:'Healthy network', description:'All protocol gates are healthy.' },
  { id:'trunk-vlan20', label:'Remove VLAN 20 from trunk', description:'VLAN 20 is no longer permitted across SW1 ↔ SW2.' },
  { id:'acl-icmp', label:'Block ICMP with ACL', description:'An extended ACL denies ICMP to the server.' },
  { id:'nat-inside', label:'Remove NAT inside role', description:'R1 Gi0/0 is no longer marked as NAT inside.' },
  { id:'dhcp-helper', label:'Remove DHCP helper', description:'R1 has no helper address for the DHCP server.' },
  { id:'ipv6-forwarding', label:'Disable IPv6 forwarding', description:'R1 cannot route IPv6 packets.' },
  { id:'ipv6-route', label:'Remove remote IPv6 route', description:'R1 no longer has the 2001:db8:20::/64 route.' },
  { id:'ospf-adjacency', label:'Break OSPF adjacency', description:'The R1 ↔ R2 OSPF session is down.' },
];

const topology = {
  PC1:['SW1'], PC2:['SW1'], SW1:['PC1','PC2','R1','SW2'], R1:['SW1','R2','WAN','DHCP'], R2:['R1','SW2'], SW2:['SW1','R2','SRV1'], SRV1:['SW2'], WAN:['R1'], DHCP:['R1']
};

const clone = (value) => structuredClone(value);

export function freshWorkshopState() {
  const state = freshPacketState('none');
  const repaired = ['ipv6-nd','acl-echo','dhcp-relay','nat-flow','stp-convergence','lacp-bundle','dualstack']
    .reduce((acc,id)=>repairPacketCase(acc,id), state);
  repaired.workshop = {
    faults: [],
    ipv4RouteR1: true,
    ospf: { up:true },
    packetCounter: 0,
    trunkVlan20: true,
  };
  return repaired;
}

export function injectFault(input, faultId) {
  const state = clone(input);
  if (!state.workshop) state.workshop = { faults:[], ipv4RouteR1:true, ospf:{up:true}, packetCounter:0, trunkVlan20:true };
  state.workshop.faults = faultId === 'none' ? [] : [faultId];
  if (faultId === 'none') return deriveWorkshopState(state);
  switch (faultId) {
    case 'trunk-vlan20': state.workshop.trunkVlan20 = false; break;
    case 'acl-icmp': state.packet.acl.rules = [{action:'deny',protocol:'icmp',destination:'10.20.20.10'},{action:'permit',protocol:'ip',destination:'any'}]; break;
    case 'nat-inside': state.packet.nat.inside = []; break;
    case 'dhcp-helper': state.packet.dhcpRelay.helper = null; state.packet.dhcpRelay.clientState = 'DISCOVERING'; break;
    case 'ipv6-forwarding': state.packet.ipv6.forwarding.R1 = false; break;
    case 'ipv6-route': state.packet.ipv6.routes.R1 = state.packet.ipv6.routes.R1.filter(r=>r!=='2001:db8:20::/64'); break;
    case 'ospf-adjacency': state.workshop.ospf.up = false; break;
  }
  return deriveWorkshopState(state);
}

export function deriveWorkshopState(input) {
  const state = derivePacketState(clone(input));
  state.derived = {
    ...state.derived,
    ipv4RouteR1: state.workshop?.ipv4RouteR1 !== false,
    ospfUp: state.workshop?.ospf?.up !== false,
    trunkVlan20: state.workshop?.trunkVlan20 !== false,
  };
  return state;
}

function bfsPath(source, destination) {
  if (source === destination) return [source];
  const queue=[[source]]; const seen=new Set([source]);
  while(queue.length){
    const path=queue.shift(); const node=path.at(-1);
    for(const next of (topology[node]||[])){
      if(seen.has(next)) continue; const candidate=[...path,next];
      if(next===destination) return candidate; seen.add(next); queue.push(candidate);
    }
  }
  return [];
}

export function simulatePacket(input, profileId) {
  const state = deriveWorkshopState(input); const profile=PACKET_PROFILES.find(p=>p.id===profileId)||PACKET_PROFILES[0];
  const steps=[]; const add=(id,layer,device,status,ok,event,detail,evidence)=>steps.push({id,layer,device,status,ok,event,detail,evidence});
  const markStopped = () => steps.length>0 && !steps.at(-1).ok;
  state.workshop.packetCounter += 1;
  const frameId=`PF-${String(state.workshop.packetCounter).padStart(4,'0')}`;
  add('emit','L2',profile.source,'EMIT',true,'Frame created',`${profile.label} leaves ${profile.source}.`,`${frameId} · src=${profile.source} · dst=${profile.destinationIp}`);

  if(profile.network==='dhcp'){
    add('broadcast','L2','SW1','FLOOD',true,'Broadcast reaches gateway','DHCPDISCOVER is flooded within the client VLAN.','UDP 68 → 67 · 255.255.255.255');
    const ok=state.derived.dhcpRelayReady;
    add('relay','L3','R1',ok?'RELAY':'BLOCKED',ok,'DHCP relay decision',ok?'Helper address points to the DHCP server.':'No helper address is configured on the gateway.',`ip helper-address ${state.packet.dhcpRelay.helper||'none'}`);
    add('offer','L3','DHCP',ok?'OFFER':'WAIT',ok,'Server response',ok?'The server can answer the relayed request.':'The server never receives a relayed request.','10.10.10.100 · OFFER');
    add('bind','L2',profile.source,ok?'BOUND':'WAIT',ok,'Lease state',ok?'The client completes DORA.':'The client remains in DISCOVERING.',ok?'10.10.10.10/24':'no lease');
    return packetResult(profile, state, frameId, steps);
  }

  if(profile.network==='control-plane'){
    const ok=state.derived.ospfUp;
    add('hello','L3','R1',ok?'HELLO':'DOWN',ok,'OSPF hello',ok?'R1 sends hello packets on the transit link.':'The OSPF session is administratively or logically down.','224.0.0.5 · hello 10s');
    add('adj','L3','R2',ok?'2-WAY':'NO-ADJ',ok,'Neighbor adjacency',ok?'R2 reaches the expected 2-WAY state.':'R2 cannot form the expected adjacency.',ok?'Neighbor 1.1.1.1':'neighbor unavailable');
    add('spf','L3','R1',ok?'READY':'BLOCKED',ok,'Control-plane outcome',ok?'The adjacency can participate in route exchange.':'No usable OSPF relationship exists.',ok?'LSDB synchronized':'no LSDB peer');
    return packetResult(profile, state, frameId, steps);
  }

  const destNode = profile.destination==='WAN' ? 'WAN' : 'SRV1';
  const path = bfsPath(profile.source, destNode);
  add('switch','L2','SW1','FORWARD',true,'Switching decision','The access switch forwards the frame toward the first routing or relay point.','CAM lookup → Gi0/1');

  if(profile.network==='internal'){
    const trunkOk=state.derived.trunkVlan20 && state.derived.ipv4RouteR1;
    add('trunk','L2','SW1 ↔ SW2',trunkOk?'PASS':'BLOCKED',trunkOk,'VLAN 20 transit',trunkOk?'VLAN 20 is present on the inter-switch path.':'VLAN 20 is not available across the trunk.',`allowed vlan: ${trunkOk?'10,20,99':'10,99'}`);
    add('route','L3','R2',trunkOk?'CONNECTED':'UNREACHABLE',trunkOk,'IPv4 destination lookup',trunkOk?'R2 owns the destination server network.':'The packet cannot reach the remote VLAN.',trunkOk?'C 10.20.20.0/24':'route lookup failed');
    add('dest','L2','SRV1',trunkOk?'DELIVERED':'BLOCKED',trunkOk,'Server delivery',trunkOk?'The frame reaches SRV1.':'The forwarding path stops before delivery.','10.20.20.10');
  } else if(profile.network==='internet'){
    const aclOk=state.derived.aclAllowsPing; const natOk=state.derived.natReady;
    add('acl','L3','R1',aclOk?'PERMIT':'DENY',aclOk,'Policy decision',aclOk?'The ACL permits the modeled IP flow.':'The ACL denies ICMP; TCP flows may be policy-dependent in a real deployment.',aclOk?'permit ip any':'deny icmp 10.20.20.10');
    const finalOk=natOk;
    add('nat','L3','R1',natOk?'XLATE':'BLOCKED',natOk,'NAT/PAT decision',natOk?'The inside address is translated to the public interface.':'NAT cannot translate without the inside role.',natOk?'10.10.10.10 → 203.0.113.2':'no translation');
    add('wan','L3','WAN',finalOk?'FORWARD':'DROP',finalOk,'Internet egress',finalOk?'The translated packet exits R1.':'The packet is dropped before WAN egress.','203.0.113.2 → 198.51.100.10');
  } else if(profile.network==='internal-v6'){
    const fwd=state.derived.ipv6Reachable; const route=state.packet.ipv6.routes.R1.includes('2001:db8:20::/64'); const ok=fwd&&route;
    add('ndp','L3','R1',fwd?'READY':'BLOCKED',fwd,'IPv6 forwarding gate',fwd?'R1 is forwarding IPv6.':'R1 has IPv6 forwarding disabled.','ipv6 unicast-routing: '+(fwd?'enabled':'disabled'));
    add('route6','L3','R1',route?'FOUND':'MISSING',route,'IPv6 route lookup',route?'R1 knows the remote /64.':'The remote IPv6 prefix is absent from R1.',route?'2001:db8:20::/64':'route lookup failed');
    add('remote6','L3','R2',ok?'FORWARD':'BLOCKED',ok,'Remote IPv6 forwarding',ok?'R2 owns the destination LAN.':'R2 cannot receive a valid routed packet.',ok?'connected prefix':'no viable path');
    add('dest6','L2','SRV1',ok?'DELIVERED':'BLOCKED',ok,'IPv6 destination delivery',ok?'The packet reaches the IPv6 server.':'The IPv6 forwarding chain is incomplete.','2001:db8:20::10');
  }
  if(path.length===0) add('path','META','TOPOLOGY','NO PATH',false,'Topology path lookup','The configured topology does not expose a path for this flow.','no graph path');
  else add('path','META','TOPOLOGY','TRACE',true,'Physical path','The current topology graph provides a modeled route through the network.',path.join(' → '));
  return packetResult(profile, state, frameId, steps);
}

function packetResult(profile,state,frameId,steps){
  const completed=steps.filter(s=>s.ok).length; const total=steps.length; const complete=steps.every(s=>s.ok);
  return {frameId,profile,state,steps,completed,total,score:Math.round(completed/total*100),complete,firstFailure:steps.find(s=>!s.ok)?.id||null};
}

export function packetWorkshopSnapshot(state){
  const s=deriveWorkshopState(state);
  return {
    ipv4RouteR1:s.derived.ipv4RouteR1,
    acl:s.derived.aclAllowsPing,
    nat:s.derived.natReady,
    dhcpRelay:s.derived.dhcpRelayReady,
    ipv6Forwarding:s.derived.ipv6Reachable,
    ipv6RemoteRoute:s.packet.ipv6.routes.R1.includes('2001:db8:20::/64'),
    ospfUp:s.derived.ospfUp,
    trunkVlan20:s.derived.trunkVlan20,
  };
}
