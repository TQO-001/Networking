import { planIntent } from './device-model.js';

export const TROUBLESHOOTING_VERSION = '1.0.0';
export const TROUBLESHOOTING_STORAGE_KEY = 'drillerBill.troubleshooting.v54';

const BUILTIN_CASES = [
  {
    id: 'interface-down', title: 'Interface Down', category: 'access', difficulty: 'FOUNDATION', targetKind: 'any',
    summary: 'Determine whether a failed path starts at the interface, then prove the state before changing it.',
    symptom: 'A device interface is not forwarding traffic or reports an administrative/down state.',
    scope: 'L1/L2', tags: ['interface', 'link-state', 'shutdown'],
    knowledge: ['troubleshooting', 'vlan'],
    target: { interface: 'Gi0/1', preferredDevice: 'SW1' },
    hypotheses: [
      { id: 'admin-down', title: 'Interface is administratively disabled', confidence: 0, rationale: 'A shutdown state prevents the interface from forwarding even when the physical path is available.', remediation: { type: 'set-interface-state', fields: { interface: 'Gi0/1', state: 'up' } } },
      { id: 'link-down', title: 'Physical/link layer is unavailable', confidence: 0, rationale: 'An interface can remain configured correctly while its underlying link is down.', remediation: null },
      { id: 'wrong-vlan', title: 'Layer 2 assignment is incorrect', confidence: 0, rationale: 'The interface can be up while forwarding into the wrong access VLAN.', remediation: { type: 'assign-access-vlan', fields: { interface: 'Gi0/1', vlan: 10 } } },
    ],
    tests: [
      { id: 'interface-state', label: 'Inspect interface state', command: 'show ip interface brief', kind: 'inspection', evidence: 'interfaces' },
      { id: 'switchport', label: 'Inspect switchport VLAN', command: 'show interfaces switchport Gi0/1', kind: 'inspection', evidence: 'interfaces' },
    ],
  },
  {
    id: 'vlan-trunk', title: 'VLAN Missing Across Trunk', category: 'switching', difficulty: 'INTERMEDIATE', targetKind: 'switch',
    summary: 'Trace a missing VLAN from the edge port to the inter-switch trunk instead of assuming the trunk is at fault.',
    symptom: 'Hosts in a VLAN work locally but cannot reach the same VLAN across an inter-switch path.',
    scope: 'L2', tags: ['vlan', 'trunk', '802.1q'],
    knowledge: ['vlan', 'trunking', 'troubleshooting'],
    target: { interface: 'Gi0/24', vlan: 20, preferredDevice: 'SW2' },
    hypotheses: [
      { id: 'vlan-absent', title: 'The VLAN does not exist on the target switch', confidence: 0, rationale: 'A switch cannot forward an access or trunk VLAN that is not present in its local VLAN database.', remediation: { type: 'create-vlan', fields: { id: 20, name: 'SERVERS' } } },
      { id: 'vlan-not-allowed', title: 'The trunk does not permit the VLAN', confidence: 0, rationale: 'A trunk can be healthy while selectively filtering the affected VLAN.', remediation: { type: 'set-trunk-policy', fields: { interface: 'Gi0/24', nativeVlan: 99, vlans: '10,20,99' } } },
      { id: 'edge-misassigned', title: 'The destination access port is in the wrong VLAN', confidence: 0, rationale: 'An edge port can terminate the host in a different broadcast domain even when the trunk is correct.', remediation: { type: 'assign-access-vlan', fields: { interface: 'Gi0/5', vlan: 20 } } },
    ],
    tests: [
      { id: 'vlans', label: 'Inspect VLAN database', command: 'show vlan brief', kind: 'inspection', evidence: 'vlans' },
      { id: 'trunks', label: 'Inspect trunk policy', command: 'show interfaces trunk', kind: 'inspection', evidence: 'trunks' },
      { id: 'switchport', label: 'Inspect destination access port', command: 'show interfaces switchport Gi0/5', kind: 'inspection', evidence: 'interfaces' },
    ],
  },
  {
    id: 'static-route', title: 'Missing IPv4 Route', category: 'routing', difficulty: 'INTERMEDIATE', targetKind: 'router',
    summary: 'Separate interface reachability from route presence and next-hop correctness.',
    symptom: 'A remote IPv4 network is unreachable even though the local router interfaces appear operational.',
    scope: 'L3', tags: ['routing', 'static-route', 'forwarding'],
    knowledge: ['ipv4', 'troubleshooting'],
    target: { network: '10.20.20.0/24', nextHop: '10.0.12.2', preferredDevice: 'R1' },
    hypotheses: [
      { id: 'missing-route', title: 'No route covers the destination network', confidence: 0, rationale: 'A router must have a matching route before it can forward traffic toward the remote prefix.', remediation: { type: 'add-static-route', fields: { network: '10.20.20.0', mask: '255.255.255.0', nextHop: '10.0.12.2' } } },
      { id: 'transit-down', title: 'The routed transit interface is down', confidence: 0, rationale: 'A valid route is not enough if the next-hop path is not operational.', remediation: { type: 'set-interface-state', fields: { interface: 'Gi0/1', state: 'up' } } },
      { id: 'wrong-next-hop', title: 'The route points at the wrong next hop', confidence: 0, rationale: 'A destination can appear in the table while forwarding toward an unusable next hop.', remediation: null },
    ],
    tests: [
      { id: 'routes', label: 'Inspect routing table', command: 'show ip route', kind: 'inspection', evidence: 'routes' },
      { id: 'interfaces', label: 'Inspect routed interfaces', command: 'show ip interface brief', kind: 'inspection', evidence: 'interfaces' },
    ],
  },
  {
    id: 'ospf-neighbor', title: 'OSPF Neighbor Down', category: 'routing', difficulty: 'ADVANCED', targetKind: 'router',
    summary: 'Use interface state, neighbor evidence and OSPF timers to isolate an adjacency failure.',
    symptom: 'An expected OSPF neighbor is not reaching FULL state and remote routes are no longer being learned.',
    scope: 'L3', tags: ['ospf', 'adjacency', 'routing'],
    knowledge: ['ospf', 'troubleshooting'],
    target: { interface: 'Gi0/1', preferredDevice: 'R1' },
    hypotheses: [
      { id: 'interface-down', title: 'The OSPF transit interface is unavailable', confidence: 0, rationale: 'OSPF hellos cannot form an adjacency without operational Layer 3 connectivity.', remediation: { type: 'set-interface-state', fields: { interface: 'Gi0/1', state: 'up' } } },
      { id: 'timer-mismatch', title: 'Hello/dead timers do not agree', confidence: 0, rationale: 'OSPF neighbors must agree on key adjacency parameters before they can progress to FULL.', remediation: null },
      { id: 'neighbor-missing', title: 'The expected neighbor is absent', confidence: 0, rationale: 'A missing or non-FULL neighbor prevents the expected control-plane exchange.', remediation: null },
    ],
    tests: [
      { id: 'interfaces', label: 'Inspect transit interface', command: 'show ip interface brief', kind: 'inspection', evidence: 'interfaces' },
      { id: 'ospf', label: 'Inspect OSPF neighbor state', command: 'show ip ospf neighbor', kind: 'command', expected: { includes: 'FULL' } },
    ],
  },
];

export const TROUBLESHOOTING_CASES = Object.freeze(BUILTIN_CASES.map(item => Object.freeze(item)));

const clean = (value, fallback = '') => String(value ?? '').trim() || fallback;
const normalizePort = (value = '') => String(value).replace(/^GigabitEthernet/i, 'Gi');

export function normalizeTroubleshootingCase(input = {}) {
  return {
    version: TROUBLESHOOTING_VERSION,
    id: clean(input.id, `custom-${Date.now()}`),
    title: clean(input.title, 'Untitled troubleshooting case'),
    category: clean(input.category, 'custom'),
    difficulty: clean(input.difficulty, 'CUSTOM'),
    targetKind: ['switch', 'router', 'any'].includes(input.targetKind) ? input.targetKind : 'any',
    summary: clean(input.summary, 'Evidence-driven network troubleshooting procedure.'),
    symptom: clean(input.symptom, 'A network symptom needs investigation.'),
    scope: clean(input.scope, 'UNKNOWN'),
    tags: [...new Set((Array.isArray(input.tags) ? input.tags : []).map(v => clean(v)).filter(Boolean))],
    knowledge: [...new Set((Array.isArray(input.knowledge) ? input.knowledge : []).map(v => clean(v)).filter(Boolean))],
    target: { ...(input.target || {}) },
    source: input.source === 'builtin' ? 'builtin' : 'custom',
    hypotheses: (Array.isArray(input.hypotheses) ? input.hypotheses : []).map((item, index) => ({
      id: clean(item.id, `hypothesis-${index + 1}`), title: clean(item.title, `Hypothesis ${index + 1}`), confidence: Number(item.confidence) || 0,
      rationale: clean(item.rationale, 'Record evidence that supports or weakens this hypothesis.'), remediation: item.remediation || null,
    })),
    tests: (Array.isArray(input.tests) ? input.tests : []).map((item, index) => ({
      id: clean(item.id, `test-${index + 1}`), label: clean(item.label, `Test ${index + 1}`), command: clean(item.command, ''), kind: clean(item.kind, 'inspection'), evidence: clean(item.evidence, ''), expected: item.expected || null,
    })),
  };
}

export function validateTroubleshootingCase(caseData = {}) {
  const errors = [];
  if (!clean(caseData.id)) errors.push('Case ID is required.');
  if (!clean(caseData.title)) errors.push('Case title is required.');
  if (!clean(caseData.symptom)) errors.push('Case symptom is required.');
  if (!Array.isArray(caseData.hypotheses) || !caseData.hypotheses.length) errors.push('A case needs at least one hypothesis.');
  if (!Array.isArray(caseData.tests) || !caseData.tests.length) errors.push('A case needs at least one evidence test.');
  const seen = new Set();
  for (const test of caseData.tests || []) {
    if (seen.has(test.id)) errors.push(`Duplicate test ID: ${test.id}.`);
    seen.add(test.id);
    if (!test.label) errors.push(`Test ${test.id} needs a label.`);
  }
  return { valid: errors.length === 0, errors };
}

function interfaceRow(inspection, port) {
  const expected = normalizePort(port);
  return (inspection?.interfaces || []).find(item => normalizePort(item.name) === expected) || null;
}

function routeRow(inspection, network, nextHop) {
  return (inspection?.routes || []).find(item => String(item.network) === String(network) && (!nextHop || String(item.nextHop) === String(nextHop)));
}

function vlanRow(inspection, vlan) {
  return (inspection?.vlans || []).find(item => Number(item.id) === Number(vlan));
}

function trunkRow(inspection, port) {
  return (inspection?.trunks || []).find(item => normalizePort(item.interface) === normalizePort(port));
}

export function evaluateEvidenceTest(test, { inspection = null, diagnostics = null, commandResult = null, caseData = {} } = {}) {
  const typedCase = /** @type {Record<string, any>} */ (caseData);
  const target = typedCase.target || {};
  let status = 'unknown';
  let detail = 'No evidence has been collected for this test yet.';
  let evidence = [];

  if (test.kind === 'command') {
    const output = Array.isArray(commandResult?.output) ? commandResult.output.join('\n') : String(commandResult?.output || '');
    const expected = test.expected?.includes;
    const passed = expected ? output.toUpperCase().includes(String(expected).toUpperCase()) : Boolean(output.trim());
    status = passed ? 'pass' : 'fail';
    detail = passed ? `Command output contains the expected signal: ${expected}.` : 'The expected signal was not observed in the command output.';
    evidence = output.split(/\r?\n/).filter(Boolean).slice(0, 12);
  } else if (test.evidence === 'interfaces') {
    const row = interfaceRow(inspection, target.interface || 'Gi0/1');
    if (!row) { status = 'unknown'; detail = `No structured interface record was found for ${target.interface || 'the target interface'}.`; }
    else {
      const up = row.status === 'up' && row.protocol === 'up';
      status = up ? 'pass' : 'fail';
      detail = up ? `${row.name} is operational (${row.status}/${row.protocol}).` : `${row.name} reports ${row.status}/${row.protocol}.`;
      evidence = [row.name, `${row.status}/${row.protocol}`, row.ip || 'unassigned'];
    }
  } else if (test.evidence === 'vlans') {
    const row = vlanRow(inspection, target.vlan);
    status = row ? 'pass' : 'fail';
    detail = row ? `VLAN ${row.id} (${row.name}) is present.` : `VLAN ${target.vlan} is not present in the observed VLAN database.`;
    evidence = row ? [`VLAN ${row.id}`, row.name, row.status] : [];
  } else if (test.evidence === 'trunks') {
    const row = trunkRow(inspection, target.interface || 'Gi0/24');
    if (!row) { status = 'fail'; detail = `No active trunk record was found for ${target.interface || 'the target trunk'}.`; }
    else {
      const carries = !target.vlan || row.allowedVlans?.includes(Number(target.vlan));
      status = carries ? 'pass' : 'fail';
      detail = carries ? `${row.interface} is trunking and carries VLAN ${target.vlan}.` : `${row.interface} is trunking but VLAN ${target.vlan} is not in the observed allow-list.`;
      evidence = [`native VLAN ${row.nativeVlan}`, `allowed: ${(row.allowedVlans || []).join(', ') || 'none'}`, row.status];
    }
  } else if (test.evidence === 'routes') {
    const row = routeRow(inspection, target.network, target.nextHop);
    status = row ? 'pass' : 'fail';
    detail = row ? `${target.network} is present via ${row.nextHop}.` : `${target.network} was not observed with the expected next hop.`;
    evidence = row ? [row.code || 'route', row.network, `via ${row.nextHop || 'unknown'}`] : [];
  }

  if (diagnostics?.actionableSignals?.length) evidence = [...evidence, ...diagnostics.actionableSignals.map(signal => signal.message)];
  return { testId: test.id, status, detail, evidence };
}

export function analyzeTroubleshootingCase(caseData, { inspection = null, diagnostics = null, results = {} } = {}) {
  const observations = [];
  const evidence = [];
  const pushObservation = (item) => observations.push(item);
  const addEvidence = (label, value, severity = 'info') => evidence.push({ label, value: String(value ?? ''), severity });

  const typedCase = /** @type {Record<string, any>} */ (caseData);
  const resultMap = /** @type {Record<string, any>} */ (results || {});
  const target = typedCase.target || {};
  const iface = target.interface ? interfaceRow(inspection, target.interface) : null;
  const vlan = target.vlan ? vlanRow(inspection, target.vlan) : null;
  const trunk = target.interface ? trunkRow(inspection, target.interface) : null;
  const route = target.network ? routeRow(inspection, target.network, target.nextHop) : null;

  if (iface) {
    const operational = iface.status === 'up' && iface.protocol === 'up';
    addEvidence('Interface', `${iface.name} · ${iface.status}/${iface.protocol}`, operational ? 'good' : 'warning');
    pushObservation(operational ? 'The observed interface is operational.' : 'The observed interface is not fully operational.');
  }
  if (vlan) addEvidence('VLAN', `${vlan.id} · ${vlan.name} · ${vlan.status}`, 'good');
  else if (target.vlan) addEvidence('VLAN', `${target.vlan} not observed`, 'warning');
  if (trunk) {
    const carries = !target.vlan || trunk.allowedVlans?.includes(Number(target.vlan));
    addEvidence('Trunk', `${trunk.interface} · native ${trunk.nativeVlan} · allowed ${(trunk.allowedVlans || []).join(', ') || 'none'}`, carries ? 'good' : 'warning');
    if (!carries) pushObservation(`The target trunk does not currently carry VLAN ${target.vlan}.`);
  }
  if (route) addEvidence('Route', `${route.network} via ${route.nextHop || 'unknown'}`, 'good');
  else if (target.network) addEvidence('Route', `${target.network} not observed`, 'warning');

  if (diagnostics?.status) addEvidence('Device health', `${diagnostics.status} · score ${diagnostics.score}`, diagnostics.status === 'healthy' ? 'good' : 'warning');
  for (const [testId, result] of Object.entries(resultMap)) {
    if (!result) continue;
    addEvidence(`Test ${testId}`, result.detail, result.status === 'pass' ? 'good' : result.status === 'fail' ? 'warning' : 'info');
  }

  const scored = (caseData?.hypotheses || []).map(hypothesis => {
    let confidence = 0;
    if (caseData.id === 'interface-down') {
      if (iface?.status === 'administratively down') confidence += 90;
      else if (iface && iface.status !== 'up') confidence += 50;
      if (iface?.status === 'up' && iface?.protocol === 'up') confidence -= 35;
      if (hypothesis.id === 'wrong-vlan' && iface?.switchportVlan && Number(iface.switchportVlan) !== Number(target.vlan || 10)) confidence += 30;
    }
    if (caseData.id === 'vlan-trunk') {
      if (!vlan) confidence += hypothesis.id === 'vlan-absent' ? 90 : 10;
      if (trunk && target.vlan && !trunk.allowedVlans?.includes(Number(target.vlan))) confidence += hypothesis.id === 'vlan-not-allowed' ? 95 : -10;
      if (vlan && !trunk) confidence += hypothesis.id === 'vlan-not-allowed' ? 10 : hypothesis.id === 'edge-misassigned' ? 55 : 0;
      const edge = target.interface ? interfaceRow(inspection, 'Gi0/5') : null;
      if (edge && target.vlan && Number(edge.switchportVlan) !== Number(target.vlan)) confidence += hypothesis.id === 'edge-misassigned' ? 75 : -10;
    }
    if (caseData.id === 'static-route') {
      if (!route) confidence += 85;
      if (iface && iface.status !== 'up') confidence += 35;
      if (route && target.nextHop && String(route.nextHop) !== String(target.nextHop)) confidence += 75;
    }
    if (caseData.id === 'ospf-neighbor') {
      const ospfTest = resultMap.ospf;
      if (iface && iface.status !== 'up') confidence += hypothesis.id === 'interface-down' ? 90 : -10;
      if (ospfTest?.status === 'fail') confidence += hypothesis.id === 'neighbor-missing' ? 80 : 5;
      if (ospfTest?.status === 'pass') confidence -= 65;
      if (hypothesis.id === 'timer-mismatch' && ospfTest?.status === 'fail' && /timer|dead|hello/i.test(ospfTest.detail || '')) confidence += 35;
    }
    confidence = Math.max(0, Math.min(100, confidence));
    return { ...hypothesis, confidence };
  }).sort((a, b) => b.confidence - a.confidence || a.title.localeCompare(b.title));

  const nextTest = (typedCase.tests || []).find(test => !resultMap[test.id]);
  return {
    caseId: caseData?.id || '',
    observations,
    evidence,
    hypotheses: scored,
    topHypothesis: scored[0] || null,
    nextTest: nextTest || null,
    confidence: scored[0]?.confidence || 0,
    readyForRemediation: Boolean(scored[0]?.confidence >= 75),
  };
}

export function remediationPlan(caseData, hypothesis, device = {}) {
  if (!hypothesis?.remediation) return { valid: false, errors: ['No safe typed remediation is mapped to this hypothesis.'], commands: [], intent: null };
  return planIntent(hypothesis.remediation, device);
}

export function runbookLinkForCase(caseData, hypothesis) {
  if (caseData?.id === 'vlan-trunk') return 'trunk-standardization';
  if (caseData?.id === 'static-route') return 'routed-edge-recovery';
  if (caseData?.id === 'interface-down') return 'access-switch-baseline';
  return caseData?.id || '';
}

export function loadCustomTroubleshootingCases(storage) {
  try {
    const raw = storage?.getItem(TROUBLESHOOTING_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.map(normalizeTroubleshootingCase).filter(item => validateTroubleshootingCase(item).valid) : [];
  } catch { return []; }
}

export function saveCustomTroubleshootingCases(storage, cases = []) {
  const custom = cases.filter(item => item?.source !== 'builtin').map(normalizeTroubleshootingCase);
  storage?.setItem(TROUBLESHOOTING_STORAGE_KEY, JSON.stringify(custom));
  return custom;
}
