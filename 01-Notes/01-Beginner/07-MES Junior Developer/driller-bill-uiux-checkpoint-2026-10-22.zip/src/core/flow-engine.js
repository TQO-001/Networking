import { freshProtocolState, deriveProtocolState, protocolSnapshot, executeProtocolCommand } from './protocol-engine.js';
import { linkInfo, tracePath } from './network-model.js';

export const FLOW_SCENARIOS = [
  { id:'dhcp-dora', title:'DHCP DORA', protocol:'DHCP', source:'PC1', destination:'R1', objective:'Obtain a valid IPv4 lease', description:'Trace the client discovery, offer, request and acknowledgement sequence.', duration:'~5s' },
  { id:'vlan20-forward', title:'VLAN 20 delivery', protocol:'802.1Q', source:'PC2', destination:'SRV1', objective:'Carry VLAN 20 across the switched path', description:'Follow an Ethernet frame from an access port across the trunk to the server segment.', duration:'~4s' },
  { id:'ospf-adjacency', title:'OSPF adjacency', protocol:'OSPF', source:'R1', destination:'R2', objective:'Reach FULL adjacency', description:'Observe the routed-link and timer prerequisites for an OSPF neighbor relationship.', duration:'~4s' },
  { id:'lacp-bundle', title:'LACP bundle', protocol:'LACP', source:'SW1', destination:'SW2', objective:'Form Port-channel 1', description:'Follow LACP participation from member eligibility through bundle formation.', duration:'~4s' },
  { id:'stp-election', title:'RSTP root election', protocol:'RSTP', source:'SW1', destination:'SW2', objective:'Determine the VLAN root bridge', description:'Compare bridge priorities and observe which switch becomes the root.', duration:'~4s' },
  { id:'nat-session', title:'NAT overload flow', protocol:'NAT', source:'PC1', destination:'WAN', objective:'Create an inside-to-outside translation', description:'Trace the inside interface, overload rule, and generated translation entry.', duration:'~5s' },
  { id:'routed-path', title:'Inter-router packet path', protocol:'IP routing', source:'R1', destination:'SRV1', objective:'Reach the VLAN 20 server network', description:'Combine routing, transit-link state and VLAN delivery into one packet trace.', duration:'~5s' },
];

function clone(x){return structuredClone(x);}
function step(id,label,device,event,ok,evidence='',detail=''){return {id,label,device,event,status:ok?'PASS':'BLOCKED',ok,evidence,detail};}

export function freshFlowState(){return freshProtocolState('dhcp-recovery');}

function buildDhcp(state){
  const s=deriveProtocolState(state), r=s.devices.R1, pool=r.protocol.dhcp.pools.USERS, lease=r.protocol.dhcp.bindings.PC1;
  const access=!!s.devices.SW1.interfaces['GigabitEthernet0/1']?.admin&&s.devices.SW1.interfaces['GigabitEthernet0/1']?.accessVlan===10;
  return [
    step('discover','01 / DISCOVER','PC1','Broadcast DHCPDISCOVER',access,'SW1 Gi0/1','The client is attached to the USERS access segment.'),
    step('offer','02 / OFFER','R1','Select USERS pool',!!pool,'R1: show ip dhcp pool','A matching DHCP pool must exist.'),
    step('request','03 / REQUEST','R1','Validate default gateway',pool?.defaultRouter==='10.10.10.1','R1: show ip dhcp pool',pool?.defaultRouter==='10.10.10.1'?'Gateway option is valid.':`Pool currently advertises ${pool?.defaultRouter||'no gateway'}.`),
    step('ack','04 / ACK','R1','Bind client lease',lease?.status==='BOUND','R1: show ip dhcp binding',lease?.status==='BOUND'?`PC1 received ${lease.ip}.`:'The client remains unbound until the pool gateway is corrected.')
  ];
}

function buildVlan20(state){
  const s=deriveProtocolState(state);
  const pc=!!s.devices.SW1.interfaces['GigabitEthernet0/5']?.admin&&s.devices.SW1.interfaces['GigabitEthernet0/5']?.accessVlan===20;
  const trunk=s.devices.SW1.interfaces['GigabitEthernet0/24'], trunk2=s.devices.SW2.interfaces['GigabitEthernet0/24'];
  const t1=!!trunk?.admin&&trunk?.mode==='trunk';
  const t2=!!trunk2?.admin&&trunk2?.mode==='trunk';
  const vlan20=!!trunk?.allowedVlans?.includes(20)&&!!trunk2?.allowedVlans?.includes(20);
  const srv=!!s.devices.SW2.interfaces['GigabitEthernet0/5']?.admin&&s.devices.SW2.interfaces['GigabitEthernet0/5']?.accessVlan===20;
  return [
    step('access','01 / ACCESS','PC2','Emit frame on VLAN 20',pc,'SW1: show interfaces switchport Gi0/5',pc?'PC2 is correctly assigned to VLAN 20.':'PC2 access VLAN is incorrect.'),
    step('sw1','02 / INGRESS','SW1','Enter trunk on Gi0/24',t1,'SW1: show interfaces trunk',t1?'SW1 has an active trunk.':'The SW1 trunk is unavailable.'),
    step('trunk','03 / TAG','SW1 ↔ SW2','Forward VLAN 20 over 802.1Q',t1&&t2&&vlan20,'SW1/SW2: show interfaces trunk',vlan20?'Both ends allow VLAN 20.':'VLAN 20 is not permitted at both trunk ends.'),
    step('egress','04 / EGRESS','SW2','Deliver to SRV1 access port',srv,'SW2: show interfaces switchport Gi0/5',srv?'SRV1 is on VLAN 20.':'SRV1 access VLAN is incorrect.'),
    step('deliver','05 / DELIVERY','SRV1','Frame reaches destination',pc&&t1&&t2&&vlan20&&srv,'trace VLAN 20',pc&&t1&&t2&&vlan20&&srv?'End-to-end Layer 2 delivery is available.':'The path is blocked before the destination segment.')
  ];
}

function buildOspf(state){
  const s=deriveProtocolState(state), snap=protocolSnapshot(s), p1=s.devices.R1.protocol.ospfTimers, p2=s.devices.R2.protocol.ospfTimers;
  const link=linkInfo(s,{a:'R1',ai:'GigabitEthernet0/1',b:'R2',bi:'GigabitEthernet0/0',kind:'l3'}).healthy;
  const configured=!!s.devices.R1.ospf&&!!s.devices.R2.ospf;
  const timers=p1.hello===p2.hello&&p1.dead===p2.dead;
  return [
    step('link','01 / LINK','R1 ↔ R2','Routed transit is up',link,'show ip interface brief','Both interfaces must be administratively up and physically available.'),
    step('hello','02 / HELLO','R1 ↔ R2','Exchange OSPF hellos',configured,'show ip ospf interface',configured?'Both routers have OSPF configured.':'OSPF process configuration is missing.'),
    step('timer','03 / TIMER','R1 ↔ R2',`Match hello ${p1.hello} / dead ${p1.dead}`,timers,'show ip ospf interface',timers?'Timer values match.':`R1 is ${p1.hello}/${p1.dead}; R2 is ${p2.hello}/${p2.dead}.`),
    step('full','04 / FULL','R1 ↔ R2','Neighbor reaches FULL',snap.ospf.R1==='FULL','show ip ospf neighbor',snap.ospf.R1==='FULL'?'Adjacency is FULL.':'The adjacency remains down until prerequisites match.')
  ];
}

function buildLacp(state){
  const s=deriveProtocolState(state), a=s.devices.SW1.etherchannel, b=s.devices.SW2.etherchannel;
  const local=Object.values(a.members).every(Boolean), peer=Object.values(b.members).every(Boolean), formed=!!a.formed&&!!b.formed;
  return [
    step('local','01 / ELIGIBLE','SW1','All local members enabled',local,'show etherchannel summary',local?'SW1 members are participating.':'A SW1 member is unavailable.'),
    step('peer','02 / PEER','SW2','All peer members enabled',peer,'show etherchannel summary',peer?'SW2 members are participating.':'SW2 is missing an active member.'),
    step('protocol','03 / NEGOTIATE','SW1 ↔ SW2','LACP mode compatible',a.protocol==='LACP'&&b.protocol==='LACP','show etherchannel summary',a.protocol==='LACP'&&b.protocol==='LACP'?'Both sides use LACP.':'The bundle is not operating as LACP on both sides.'),
    step('bundle','04 / FORMED','Po1','Port-channel 1 is formed',formed,'show etherchannel summary',formed?'Po1 is operational.':'The bundle remains down.')
  ];
}

function buildStp(state){
  const s=deriveProtocolState(state), v10=protocolSnapshot(s).stp.VLAN10, v20=protocolSnapshot(s).stp.VLAN20;
  const sw1p=s.devices.SW1.protocol.stpVlans, sw2p=s.devices.SW2.protocol.stpVlans;
  const root10=v10==='SW1',root20=v20==='SW1';
  return [
    step('v10','01 / VLAN 10','SW1 ↔ SW2','Compare VLAN 10 bridge priorities',sw1p[10].priority<sw2p[10].priority,'show spanning-tree vlan 10',`SW1 ${sw1p[10].priority} / SW2 ${sw2p[10].priority}.`),
    step('root10','02 / ROOT','VLAN 10','Elect SW1 as root',root10,'show spanning-tree vlan 10',root10?'SW1 wins the election.':'SW2 currently has the lower priority.'),
    step('v20','03 / VLAN 20','SW1 ↔ SW2','Compare VLAN 20 bridge priorities',sw1p[20].priority<sw2p[20].priority,'show spanning-tree vlan 20',`SW1 ${sw1p[20].priority} / SW2 ${sw2p[20].priority}.`),
    step('root20','04 / ROOT','VLAN 20','Elect SW1 as root',root20,'show spanning-tree vlan 20',root20?'SW1 wins the election.':'SW2 currently has the lower priority.')
  ];
}

function buildNat(state){
  const s=deriveProtocolState(state), r=s.devices.R1, nat=r.protocol.nat;
  const inside=nat.inside.includes('GigabitEthernet0/0'), outside=nat.outside.includes('GigabitEthernet0/1');
  const rule=nat.rules.some(x=>x.type==='overload'&&x.interface==='GigabitEthernet0/1'&&x.enabled), translation=nat.translations.length>0;
  return [
    step('inside','01 / INSIDE','R1 Gi0/0','Mark inside interface',inside,'show ip nat statistics',inside?'Gi0/0 is NAT inside.':'Gi0/0 is not marked inside.'),
    step('outside','02 / OUTSIDE','R1 Gi0/1','Mark outside interface',outside,'show ip nat statistics',outside?'Gi0/1 is NAT outside.':'Gi0/1 is not marked outside.'),
    step('rule','03 / RULE','R1','Enable overload rule',rule,'show running-config',rule?'The overload rule is active.':'No active overload rule matches the WAN interface.'),
    step('translation','04 / TRANSLATION','R1','Create translation entry',inside&&outside&&rule&&translation,'show ip nat translations',translation?'A dynamic entry exists.':'Generate a NAT flow after the roles and overload rule are correct.')
  ];
}

function buildRoutedPath(state){
  const s=deriveProtocolState(state), routed=tracePath(s,'R1','10.20.20.10');
  const transit=linkInfo(s,{a:'R1',ai:'GigabitEthernet0/1',b:'R2',bi:'GigabitEthernet0/0',kind:'l3'}).healthy;
  const vlan20=!!s.devices.SW1.interfaces['GigabitEthernet0/24']?.allowedVlans?.includes(20)&&!!s.devices.SW2.interfaces['GigabitEthernet0/24']?.allowedVlans?.includes(20);
  return [
    step('route','01 / LOOKUP','R1','Find a route to 10.20.20.0/24',!!routed.hops?.length&&routed.hops[0]==='R1','show ip route','A matching route must exist before forwarding can begin.'),
    step('transit','02 / TRANSIT','R1 ↔ R2','Forward across routed link',transit,'show ip interface brief',transit?'The R1↔R2 link is available.':'The routed transit link is down.'),
    step('vlan','03 / L2','SW1 ↔ SW2','Carry VLAN 20 toward SRV1',vlan20,'show interfaces trunk',vlan20?'VLAN 20 is available end-to-end on the trunk.':'VLAN 20 is blocked on the switched path.'),
    step('destination','04 / DELIVERY','SRV1','Reach 10.20.20.10',routed.ok,'ping 10.20.20.10',routed.ok?'The simulated route reaches the destination.':routed.reason)
  ];
}

export function buildFlow(state,flowId){
  const builders={'dhcp-dora':buildDhcp,'vlan20-forward':buildVlan20,'ospf-adjacency':buildOspf,'lacp-bundle':buildLacp,'stp-election':buildStp,'nat-session':buildNat,'routed-path':buildRoutedPath};
  const s=state ? clone(state) : freshFlowState();
  const scenario=FLOW_SCENARIOS.find(x=>x.id===flowId)||FLOW_SCENARIOS[0];
  const steps=(builders[scenario.id]||buildDhcp)(s);
  const passed=steps.filter(x=>x.ok).length;
  return {scenario,state:s,steps,passed,total:steps.length,complete:passed===steps.length,status:passed===steps.length?'COMPLETE':passed===0?'BLOCKED':'PARTIAL'};
}


const REPAIR_SEQUENCES = {
  'dhcp-dora':[['R1','enable'],['R1','configure terminal'],['R1','ip dhcp pool USERS'],['R1','default-router 10.10.10.1'],['R1','exit'],['R1','end']],
  'vlan20-forward':[['SW2','enable'],['SW2','configure terminal'],['SW2','interface gi0/24'],['SW2','switchport trunk allowed vlan 10,20,99'],['SW2','end']],
  'ospf-adjacency':[['R2','enable'],['R2','configure terminal'],['R2','router ospf 1'],['R2','timers hello 10'],['R2','timers dead 40'],['R2','end']],
  'lacp-bundle':[['SW2','enable'],['SW2','configure terminal'],['SW2','interface gi0/22'],['SW2','channel-group 1 mode active'],['SW2','end']],
  'stp-election':[['SW1','enable'],['SW1','configure terminal'],['SW1','spanning-tree vlan 10 priority 20480'],['SW1','spanning-tree vlan 20 priority 20480'],['SW1','end']],
  'nat-session':[['R1','enable'],['R1','configure terminal'],['R1','interface gi0/0'],['R1','ip nat inside'],['R1','exit'],['R1','interface gi0/1'],['R1','ip nat outside'],['R1','exit'],['R1','ip nat inside source list 1 interface gi0/1 overload'],['R1','end'],['R1','simulate nat flow']],
  'routed-path':[['R1','enable'],['R1','configure terminal'],['R1','ip route 10.20.20.0 255.255.255.0 10.0.12.2'],['R1','end'],['SW2','enable'],['SW2','configure terminal'],['SW2','interface gi0/24'],['SW2','switchport trunk allowed vlan 10,20,99'],['SW2','end']]
};

export function repairFlow(state, flowId){
  let next=clone(state||freshFlowState());
  for(const [device,command] of REPAIR_SEQUENCES[flowId]||[]) next=executeProtocolCommand(next,device,command).state;
  return deriveProtocolState(next);
}

export function getFlowCatalog(){return FLOW_SCENARIOS.map(x=>({...x}));}
