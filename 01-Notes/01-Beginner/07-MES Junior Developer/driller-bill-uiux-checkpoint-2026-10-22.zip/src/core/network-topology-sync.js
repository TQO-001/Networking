import { interfaceKey, normalizeLabState } from './cli-engine.js';

const clone = value => structuredClone(value);
const SUPPORTED_DEVICE_TYPES = new Set(['router', 'switch']);
const CLIENT_TYPES = new Set(['host', 'server']);
const CORE_DEVICE_NAMES = new Set(['R1', 'R2', 'SW1', 'SW2']);

function clientRecord(device, existing = {}) {
  return {
    ip: device.ip || existing.ip || '',
    mask: existing.mask || '255.255.255.0',
    gateway: existing.gateway || '',
    vlan: existing.vlan || 1,
    switch: existing.switch || '',
    port: existing.port || '',
    ipv6: existing.ipv6 || '',
    dhcp: !!existing.dhcp,
    topologyId: device.id,
    online: device.enabled !== false,
  };
}

function makeDeviceFromTopologyDevice(device, template) {
  const kind = device.type === 'router' ? 'router' : 'switch';
  const next = clone(template);
  next.name = device.name;
  next.hostname = device.name;
  next.kind = kind;
  next.role = kind;
  next.mode = 'exec';
  next.interfaces = {};
  next.routes = [];
  next.ospf = null;
  next.nat = { inside: [], outside: [], overload: [] };
  next.acls = {};
  next.dhcpPools = {};
  next.dhcpExcluded = [];
  next.users = [];
  next.ipv6 = { forwarding: kind === 'router', routes: [], addresses: {} };
  next.vlans = kind === 'switch' ? { 1: 'default' } : {};
  next.etherchannel = { group: 1, protocol: 'LACP', ports: [], state: 'SU' };
  next.stp = kind === 'switch' ? { root: false, rootPort: null, priority: 32768, mac: `00${device.id.slice(-8).replace(/[^a-f0-9]/gi, '0').padStart(8, '0')}`.slice(0, 12) } : null;
  next.managementIp = device.ip || '';
  next.topologyId = device.id;
  next.topologyManaged = true;
  return next;
}

function ensureInterface(dev, rawPort) {
  const key = interfaceKey(rawPort);
  if (!key) return null;
  dev.interfaces[key] ||= {
    mode: dev.kind === 'switch' ? 'access' : undefined,
    accessVlan: 1,
    admin: true,
    link: false,
    description: '',
    helperAddresses: [],
    natRole: null,
    portSecurity: { enabled: false, maximum: 1 },
    portfast: false,
    bpduguard: false,
    channelGroup: null,
  };
  return key;
}

function endpointState(topology, deviceId) {
  return topology.devices.find(d => d.id === deviceId) || null;
}

function endpointPort(topology, link, side) {
  const id = side === 'a' ? link.a : link.b;
  const port = side === 'a' ? link.ai : link.bi;
  const device = endpointState(topology, id);
  return { device, port };
}

export function syncTopologyToLabState(inputState, topology) {
  const state = normalizeLabState(inputState);
  const managed = new Set(state.meta.topologyManagedDevices || []);
  const previousBindings = state.meta.topologyBindings || {};
  const templateByKind = {
    router: Object.values(state.devices).find(d => d.kind === 'router') || state.devices.R1,
    switch: Object.values(state.devices).find(d => d.kind === 'switch') || state.devices.SW1,
  };
  const topologyNames = new Set(topology.devices.map(d => d.name));
  const bindings = {};

  for (const topoDevice of topology.devices) {
    bindings[topoDevice.id] = topoDevice.name;
    if (SUPPORTED_DEVICE_TYPES.has(topoDevice.type)) {
      if (!state.devices[topoDevice.name]) {
        const template = templateByKind[topoDevice.type];
        if (template) state.devices[topoDevice.name] = makeDeviceFromTopologyDevice(topoDevice, template);
      }
      const dev = state.devices[topoDevice.name];
      if (!dev) continue;
      dev.hostname = topoDevice.name;
      dev.topologyId = topoDevice.id;
      dev.topologyManaged = true;
      dev.managementIp = topoDevice.ip || dev.managementIp || '';
      if (topoDevice.enabled === false) {
        for (const iface of Object.values(dev.interfaces)) iface.link = false;
      }
      for (const port of topoDevice.ports || []) {
        const key = ensureInterface(dev, port.id);
        if (!key) continue;
        dev.interfaces[key].topologyPortId = port.id;
        dev.interfaces[key].topologyDesiredState = port.state || 'up';
        if (topoDevice.enabled === false || port.state === 'down') dev.interfaces[key].link = false;
      }
      managed.add(topoDevice.name);
    } else if (CLIENT_TYPES.has(topoDevice.type)) {
      state.clients[topoDevice.name] = clientRecord(topoDevice, state.clients[topoDevice.name]);
      managed.add(topoDevice.name);
    }
  }

  // Structural removal: custom topology-managed devices disappear from the live model when deleted.
  for (const name of [...managed]) {
    if (topologyNames.has(name)) continue;
    if (CORE_DEVICE_NAMES.has(name)) {
      const core = state.devices[name];
      if (core) {
        core.topologyPresent = false;
        for (const iface of Object.values(core.interfaces || {})) iface.link = false;
      }
      if (state.clients[name]) state.clients[name].online = false;
      continue;
    }
    if (state.devices[name]?.topologyManaged) delete state.devices[name];
    if (state.clients[name]?.topologyManaged || previousBindings[name]) delete state.clients[name];
  }

  const resetLinks = new Set();
  for (const device of topology.devices) {
    if (SUPPORTED_DEVICE_TYPES.has(device.type)) {
      const dev = state.devices[device.name];
      if (dev) {
        for (const iface of Object.values(dev.interfaces || {})) {
          if (iface.topologyPortId) resetLinks.add(`${device.name}:${iface.topologyPortId}`);
        }
      }
    }
  }
  // Clear runtime link status for topology-managed ports before deriving it from the current links.
  for (const key of resetLinks) {
    const [name, ...portParts] = key.split(':');
    const port = portParts.join(':');
    const dev = state.devices[name];
    const iface = dev?.interfaces?.[interfaceKey(port)];
    if (iface) iface.link = false;
  }

  for (const link of topology.links) {
    const a = endpointPort(topology, link, 'a');
    const b = endpointPort(topology, link, 'b');
    const aOnline = a.device?.enabled !== false && (a.device?.ports || []).find(p => p.id === a.port)?.state !== 'down';
    const bOnline = b.device?.enabled !== false && (b.device?.ports || []).find(p => p.id === b.port)?.state !== 'down';
    const linkUp = link.state !== 'down' && aOnline && bOnline;

    for (const side of [a, b]) {
      if (!side.device) continue;
      if (SUPPORTED_DEVICE_TYPES.has(side.device.type)) {
        const dev = state.devices[side.device.name];
        const key = ensureInterface(dev, side.port);
        if (key) {
          dev.interfaces[key].topologyPortId = side.port;
          dev.interfaces[key].topologyLinkId = link.id;
          dev.interfaces[key].link = linkUp;
          if (link.kind === 'trunk' && dev.kind === 'switch') {
            dev.interfaces[key].mode = 'trunk';
            dev.interfaces[key].nativeVlan ||= 99;
            dev.interfaces[key].allowedVlans ||= [10, 20, 99];
            for (const vlan of [10, 20, 99]) {
              dev.vlans[vlan] ||= vlan === 10 ? 'USERS' : vlan === 20 ? 'SERVERS' : 'MANAGEMENT';
            }
          }
        }
      } else if (CLIENT_TYPES.has(side.device.type)) {
        const client = state.clients[side.device.name];
        if (client) {
          const other = side.device.id === a.device?.id ? b.device : a.device;
          client.switch = other?.type === 'switch' ? other.name : client.switch;
          client.port = side.port;
          const otherLivePort = other?.type === 'switch' ? state.devices[other.name]?.interfaces?.[interfaceKey(side === a ? link.bi : link.ai)] : null;
          const portRecord = (side.device.ports || []).find(p => p.id === side.port);
          if (otherLivePort?.mode === 'access') client.vlan = otherLivePort.accessVlan || client.vlan;
          else if (portRecord?.vlan) client.vlan = portRecord.vlan;
          client.online = linkUp;
          client.topologyManaged = true;
        }
      }
    }
  }

  state.meta.topologyManagedDevices = [...managed];
  state.meta.topologyBindings = bindings;
  state.meta.topologyId = topology.id;
  state.meta.topologyName = topology.name;
  state.meta.topologyRevision = topology.updatedAt;
  state.meta.liveNetworkVersion = (state.meta.liveNetworkVersion || 1) + 1;
  return normalizeLabState(state);
}

export function projectLabStateOntoTopology(topology, labState) {
  let changed = false;
  const next = clone(topology);
  for (const device of next.devices) {
    const dev = labState.devices?.[device.name];
    const client = labState.clients?.[device.name];
    if (dev) {
      const runtimeEnabled = !Object.keys(dev.interfaces || {}).length || Object.values(dev.interfaces).some(i => i.admin !== false);
      if (device.runtimeEnabled !== runtimeEnabled) { device.runtimeEnabled = runtimeEnabled; changed = true; }
      for (const port of device.ports || []) {
        const iface = dev.interfaces?.[interfaceKey(port.id)];
        if (!iface) continue;
        const runtimeState = iface.admin && iface.link ? 'up' : 'down';
        if (port.runtimeState !== runtimeState) { port.runtimeState = runtimeState; changed = true; }
      }
    } else if (client) {
      if (device.runtimeEnabled !== client.online) { device.runtimeEnabled = client.online; changed = true; }
    }
  }
  return changed ? next : topology;
}
