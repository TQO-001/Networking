import { executeCommand, normalizeLabState } from './cli-engine.js';
import { INSPECTION_COMMANDS, inspectSimulatedDevice } from './device-inspection.js';

export const DEVICE_MODEL_VERSION = '1.6.0';
export const DEVICE_CONNECTION_TYPES = ['simulated', 'ssh', 'serial'];
export const DEVICE_TRANSPORT_STATUS = ['ready', 'connecting', 'connected', 'error'];

export const DEVICE_PROVIDERS = {
  ciscoIos: {
    id: 'cisco-ios',
    vendor: 'Cisco',
    platform: 'IOS-style',
    supportedConnections: ['simulated', 'ssh', 'serial'],
    capabilities: ['cli', 'configuration', 'config-snapshot', 'interfaces', 'vlans', 'routing', 'troubleshooting'],
  },
};

const SWITCH_CAPABILITIES = ['cli', 'configuration', 'config-snapshot', 'interfaces', 'vlans', 'switching', 'stp', 'etherchannel', 'security', 'management', 'services', 'scenarios', 'troubleshooting'];
const ROUTER_CAPABILITIES = ['cli', 'configuration', 'config-snapshot', 'interfaces', 'routing', 'ospf', 'acl', 'nat', 'dhcp', 'ipv6', 'security', 'management', 'services', 'troubleshooting'];

export function providerForDevice(device = {}) {
  return DEVICE_PROVIDERS.ciscoIos;
}

function countInterfaces(device = {}) {
  return Object.keys(device.interfaces || {}).length;
}

function countUpInterfaces(device = {}) {
  return Object.values(device.interfaces || {}).filter(i => i?.admin !== false && i?.link !== false).length;
}

function capabilitiesForDevice(device = {}) {
  return device.kind === 'switch' ? [...SWITCH_CAPABILITIES] : [...ROUTER_CAPABILITIES];
}

export function deviceRecord(deviceId, device = {}) {
  const provider = providerForDevice(device);
  const interfaces = countInterfaces(device);
  const upInterfaces = countUpInterfaces(device);
  return {
    id: deviceId,
    name: device.name || deviceId,
    hostname: device.hostname || deviceId,
    kind: device.kind || 'unknown',
    vendor: provider.vendor,
    platform: provider.platform,
    version: device.version || 'unknown',
    mode: device.mode || 'exec',
    interfaceCount: interfaces,
    upInterfaceCount: upInterfaces,
    vlanCount: Object.keys(device.vlans || {}).length,
    routeCount: Array.isArray(device.routes) ? device.routes.length : 0,
    connection: {
      type: 'simulated',
      status: 'ready',
      endpoint: 'Shared Driller Bill lab',
    },
    capabilities: capabilitiesForDevice(device),
    inspection: null,
  };
}

export function buildDeviceInventory(input) {
  const state = normalizeLabState(input);
  return Object.entries(state.devices || {}).map(([id, device]) => deviceRecord(id, device));
}

export function deviceCapabilitySummary(device) {
  return (device?.capabilities || []).map(id => ({
    id,
    label: id.replaceAll('-', ' '),
    enabled: true,
  }));
}

export const CONFIG_INTENTS = [
  {
    id: 'create-vlan',
    title: 'Create VLAN',
    category: 'switching',
    description: 'Create a Layer 2 VLAN and optionally give it a human-readable name.',
    fields: [
      { id: 'id', label: 'VLAN ID', placeholder: '10', input: 'number', required: true },
      { id: 'name', label: 'Name', placeholder: 'SALES', input: 'text', required: true },
    ],
    capabilities: ['vlans', 'configuration'],
  },
  {
    id: 'assign-access-vlan',
    title: 'Assign Access VLAN',
    category: 'switching',
    description: 'Place a switch interface into an access VLAN.',
    fields: [
      { id: 'interface', label: 'Interface', placeholder: 'Gi0/1', input: 'text', required: true },
      { id: 'vlan', label: 'VLAN ID', placeholder: '10', input: 'number', required: true },
    ],
    capabilities: ['vlans', 'interfaces', 'configuration'],
  },
  {
    id: 'set-trunk-vlans',
    title: 'Set Trunk VLANs',
    category: 'switching',
    description: 'Set the explicit VLAN allow-list on a trunk interface.',
    fields: [
      { id: 'interface', label: 'Interface', placeholder: 'Gi0/24', input: 'text', required: true },
      { id: 'vlans', label: 'Allowed VLANs', placeholder: '10,20,99', input: 'text', required: true },
    ],
    capabilities: ['vlans', 'interfaces', 'configuration'],
  },
  {
    id: 'set-trunk-policy',
    title: 'Configure Trunk Policy',
    category: 'switching',
    description: 'Configure trunk mode, native VLAN and the explicit allowed-VLAN list.',
    fields: [
      { id: 'interface', label: 'Interface', placeholder: 'Gi0/24', input: 'text', required: true },
      { id: 'nativeVlan', label: 'Native VLAN', placeholder: '99', input: 'number', required: true },
      { id: 'vlans', label: 'Allowed VLANs', placeholder: '10,20,99', input: 'text', required: true },
    ],
    capabilities: ['vlans', 'interfaces', 'configuration'],
  },
  {
    id: 'assign-access-vlan-bulk',
    title: 'Bulk Assign Access VLAN',
    category: 'switching',
    description: 'Assign one access VLAN to multiple switch interfaces in a single reviewed plan.',
    fields: [
      { id: 'interfaces', label: 'Interfaces', placeholder: 'Gi0/1, Gi0/2, Gi0/3', input: 'text', required: true },
      { id: 'vlan', label: 'VLAN ID', placeholder: '10', input: 'number', required: true },
    ],
    capabilities: ['vlans', 'interfaces', 'configuration'],
  },
  {
    id: 'set-interface-description',
    title: 'Set Interface Description',
    category: 'interfaces',
    description: 'Document an interface purpose using its IOS description field.',
    fields: [
      { id: 'interface', label: 'Interface', placeholder: 'Gi0/1', input: 'text', required: true },
      { id: 'description', label: 'Description', placeholder: 'USER DESK 01', input: 'text', required: true },
    ],
    capabilities: ['interfaces', 'configuration'],
  },
  {
    id: 'set-interface-state',
    title: 'Set Interface State',
    category: 'interfaces',
    description: 'Administratively enable or disable an interface.',
    fields: [
      { id: 'interface', label: 'Interface', placeholder: 'Gi0/1', input: 'text', required: true },
      { id: 'state', label: 'Administrative State', input: 'select', required: true, options: [{ value: 'up', label: 'No shutdown (up)' }, { value: 'down', label: 'Shutdown (down)' }] },
    ],
    capabilities: ['interfaces', 'configuration'],
  },
  {
    id: 'add-static-route',
    title: 'Add Static Route',
    category: 'routing',
    description: 'Install an IPv4 static route using a network, mask and next-hop.',
    fields: [
      { id: 'network', label: 'Network', placeholder: '10.20.20.0', input: 'text', required: true },
      { id: 'mask', label: 'Mask', placeholder: '255.255.255.0', input: 'text', required: true },
      { id: 'nextHop', label: 'Next Hop', placeholder: '10.0.12.2', input: 'text', required: true },
    ],
    capabilities: ['routing', 'configuration'],
  },
  {
    id: 'remove-static-route',
    title: 'Remove Static Route',
    category: 'routing',
    description: 'Remove an IPv4 static route by network, mask and next-hop.',
    fields: [
      { id: 'network', label: 'Network', placeholder: '10.20.20.0', input: 'text', required: true },
      { id: 'mask', label: 'Mask', placeholder: '255.255.255.0', input: 'text', required: true },
      { id: 'nextHop', label: 'Next Hop', placeholder: '10.0.12.2', input: 'text', required: true },
    ],
    capabilities: ['routing', 'configuration'],
  },
  {
    id: 'save-running-config',
    title: 'Save Running Config',
    category: 'configuration',
    description: 'Persist the current running configuration into startup-config so the device can restore it after a reboot.',
    fields: [],
    capabilities: ['configuration', 'config-snapshot'],
  },
  {
    id: 'configure-ospf-process',
    title: 'Configure OSPF Process',
    category: 'routing',
    description: 'Create or update an OSPF process and its router ID.',
    fields: [
      { id: 'process', label: 'Process ID', placeholder: '1', input: 'number', required: true },
      { id: 'routerId', label: 'Router ID', placeholder: '1.1.1.1', input: 'text', required: true },
    ],
    capabilities: ['ospf', 'routing', 'configuration'],
  },
  {
    id: 'add-ospf-network',
    title: 'Add OSPF Network',
    category: 'routing',
    description: 'Advertise an IPv4 network into an OSPF area.',
    fields: [
      { id: 'process', label: 'Process ID', placeholder: '1', input: 'number', required: true },
      { id: 'network', label: 'Network', placeholder: '10.0.12.0', input: 'text', required: true },
      { id: 'wildcard', label: 'Wildcard', placeholder: '0.0.0.3', input: 'text', required: true },
      { id: 'area', label: 'Area', placeholder: '0', input: 'number', required: true },
    ],
    capabilities: ['ospf', 'routing', 'configuration'],
  },
  {
    id: 'configure-ospf-interface',
    title: 'Tune OSPF Interface',
    category: 'routing',
    description: 'Enable OSPF on an interface and optionally align hello/dead timers.',
    fields: [
      { id: 'interface', label: 'Interface', placeholder: 'Gi0/1', input: 'text', required: true },
      { id: 'process', label: 'Process ID', placeholder: '1', input: 'number', required: true },
      { id: 'area', label: 'Area', placeholder: '0', input: 'number', required: true },
      { id: 'hello', label: 'Hello (sec)', placeholder: '10', input: 'number', required: true },
      { id: 'dead', label: 'Dead (sec)', placeholder: '40', input: 'number', required: true },
    ],
    capabilities: ['ospf', 'interfaces', 'routing', 'configuration'],
  },
  {
    id: 'set-ospf-passive-interface',
    title: 'Set OSPF Passive Interface',
    category: 'routing',
    description: 'Stop OSPF hellos on an interface while keeping its network in the OSPF process.',
    fields: [
      { id: 'process', label: 'Process ID', placeholder: '1', input: 'number', required: true },
      { id: 'interface', label: 'Interface', placeholder: 'Gi0/0', input: 'text', required: true },
    ],
    capabilities: ['ospf', 'routing', 'configuration'],
  },
  {
    id: 'add-standard-acl-rule',
    title: 'Add Standard ACL Rule',
    category: 'security',
    description: 'Append a standard IPv4 ACL permit or deny rule.',
    fields: [
      { id: 'id', label: 'ACL ID', placeholder: '1', input: 'number', required: true },
      { id: 'action', label: 'Action', input: 'select', required: true, options: [{ value: 'permit', label: 'Permit' }, { value: 'deny', label: 'Deny' }] },
      { id: 'source', label: 'Source', placeholder: '10.10.10.10', input: 'text', required: true },
      { id: 'wildcard', label: 'Wildcard', placeholder: '0.0.0.0', input: 'text', required: false },
    ],
    capabilities: ['acl', 'security', 'configuration'],
  },
  {
    id: 'remove-standard-acl',
    title: 'Remove Standard ACL',
    category: 'security',
    description: 'Delete an entire numbered standard ACL.',
    fields: [
      { id: 'id', label: 'ACL ID', placeholder: '1', input: 'number', required: true },
    ],
    capabilities: ['acl', 'security', 'configuration'],
  },
  {
    id: 'apply-standard-acl',
    title: 'Apply ACL to Interface',
    category: 'security',
    description: 'Attach a numbered standard ACL to an interface in the inbound or outbound direction.',
    fields: [
      { id: 'interface', label: 'Interface', placeholder: 'Gi0/0', input: 'text', required: true },
      { id: 'id', label: 'ACL ID', placeholder: '1', input: 'number', required: true },
      { id: 'direction', label: 'Direction', input: 'select', required: true, options: [{ value: 'in', label: 'Inbound' }, { value: 'out', label: 'Outbound' }] },
    ],
    capabilities: ['acl', 'interfaces', 'security', 'configuration'],
  },
  {
    id: 'harden-access-port',
    title: 'Harden Access Port',
    category: 'security',
    description: 'Enable port security, PortFast and BPDU Guard on a switch access interface.',
    fields: [
      { id: 'interface', label: 'Interface', placeholder: 'Gi0/1', input: 'text', required: true },
      { id: 'maximum', label: 'Max MACs', placeholder: '2', input: 'number', required: true },
    ],
    capabilities: ['security', 'interfaces', 'stp', 'configuration'],
  },
  {
    id: 'set-stp-mode',
    title: 'Set STP Mode',
    category: 'switching',
    description: 'Select the spanning-tree mode used by the switch.',
    fields: [
      { id: 'mode', label: 'STP Mode', input: 'select', required: true, options: [{ value: 'rapid-pvst', label: 'Rapid-PVST+' }, { value: 'pvst', label: 'PVST+' }, { value: 'mst', label: 'MST' }] },
    ],
    capabilities: ['stp', 'switching', 'configuration'],
  },
  {
    id: 'set-stp-vlan-priority',
    title: 'Set STP VLAN Priority',
    category: 'switching',
    description: 'Set the bridge priority for a VLAN to influence root election.',
    fields: [
      { id: 'vlan', label: 'VLAN ID', placeholder: '10', input: 'number', required: true },
      { id: 'priority', label: 'Priority', placeholder: '24576', input: 'number', required: true },
    ],
    capabilities: ['stp', 'switching', 'configuration'],
  },
  {
    id: 'configure-etherchannel',
    title: 'Configure EtherChannel',
    category: 'switching',
    description: 'Bundle multiple switch interfaces into an EtherChannel group.',
    fields: [
      { id: 'interfaces', label: 'Interfaces', placeholder: 'Gi0/1, Gi0/2', input: 'text', required: true },
      { id: 'group', label: 'Channel Group', placeholder: '1', input: 'number', required: true },
      { id: 'mode', label: 'Protocol Mode', input: 'select', required: true, options: [{ value: 'active', label: 'LACP active' }, { value: 'passive', label: 'LACP passive' }, { value: 'on', label: 'Static on' }] },
    ],
    capabilities: ['etherchannel', 'interfaces', 'switching', 'configuration'],
  },
  {
    id: 'set-interface-nat-role',
    title: 'Set NAT Interface Role',
    category: 'services',
    description: 'Mark a router interface as NAT inside or outside.',
    fields: [
      { id: 'interface', label: 'Interface', placeholder: 'Gi0/0', input: 'text', required: true },
      { id: 'role', label: 'Role', input: 'select', required: true, options: [{ value: 'inside', label: 'Inside' }, { value: 'outside', label: 'Outside' }] },
    ],
    capabilities: ['nat', 'interfaces', 'services', 'configuration'],
  },
  {
    id: 'configure-nat-overload',
    title: 'Configure NAT Overload',
    category: 'services',
    description: 'Create a PAT overload rule using a numbered standard ACL and an outside interface.',
    fields: [
      { id: 'acl', label: 'ACL ID', placeholder: '1', input: 'number', required: true },
      { id: 'interface', label: 'Outside Interface', placeholder: 'Gi0/1', input: 'text', required: true },
    ],
    capabilities: ['nat', 'acl', 'services', 'configuration'],
  },
  {
    id: 'create-dhcp-pool',
    title: 'Create DHCP Pool',
    category: 'services',
    description: 'Create a DHCP pool with network, gateway and optional DNS parameters.',
    fields: [
      { id: 'name', label: 'Pool Name', placeholder: 'USERS', input: 'text', required: true },
      { id: 'network', label: 'Network', placeholder: '10.10.10.0', input: 'text', required: true },
      { id: 'mask', label: 'Mask', placeholder: '255.255.255.0', input: 'text', required: true },
      { id: 'gateway', label: 'Default Gateway', placeholder: '10.10.10.1', input: 'text', required: true },
      { id: 'dns', label: 'DNS Server', placeholder: '10.10.10.53', input: 'text', required: false },
    ],
    capabilities: ['dhcp', 'services', 'configuration'],
  },
  {
    id: 'exclude-dhcp-address',
    title: 'Exclude DHCP Address',
    category: 'services',
    description: 'Reserve an IPv4 address or range so the DHCP service does not lease it.',
    fields: [
      { id: 'start', label: 'Start Address', placeholder: '10.10.10.1', input: 'text', required: true },
      { id: 'end', label: 'End Address', placeholder: '10.10.10.20', input: 'text', required: false },
    ],
    capabilities: ['dhcp', 'services', 'configuration'],
  },
  {
    id: 'set-hostname',
    title: 'Set Hostname',
    category: 'management',
    description: 'Set the operational hostname shown in the CLI prompt.',
    fields: [{ id: 'hostname', label: 'Hostname', placeholder: 'EDGE-R1', input: 'text', required: true }],
    capabilities: ['management', 'configuration'],
  },
  {
    id: 'configure-ssh',
    title: 'Enable SSH',
    category: 'management',
    description: 'Set a domain name and enable SSH version 2 on the device.',
    fields: [{ id: 'domain', label: 'Domain Name', placeholder: 'example.local', input: 'text', required: true }],
    capabilities: ['management', 'configuration'],
  },
  {
    id: 'create-local-user',
    title: 'Create Local User',
    category: 'management',
    description: 'Create a local CLI user with an explicit privilege level and secret. Secrets are never included in saved runbook metadata.',
    fields: [
      { id: 'username', label: 'Username', placeholder: 'netadmin', input: 'text', required: true },
      { id: 'privilege', label: 'Privilege', placeholder: '15', input: 'number', required: true },
      { id: 'secret', label: 'Secret', placeholder: 'Enter secret', input: 'password', required: true },
    ],
    capabilities: ['management', 'security', 'configuration'],
    sensitiveFields: ['secret'],
  },
  {
    id: 'configure-vty-ssh',
    title: 'Configure VTY for SSH',
    category: 'management',
    description: 'Enable login on VTY 0–4 and restrict inbound transport to SSH.',
    fields: [],
    capabilities: ['management', 'security', 'configuration'],
  },
  {
    id: 'set-default-gateway',
    title: 'Set Default Gateway',
    category: 'management',
    description: 'Set the default gateway used by a switch for management traffic.',
    fields: [{ id: 'gateway', label: 'Gateway', placeholder: '10.10.10.1', input: 'text', required: true }],
    capabilities: ['management', 'configuration'],
  },
  {
    id: 'enable-ipv6-routing',
    title: 'Enable IPv6 Routing',
    category: 'routing',
    description: 'Enable IPv6 unicast forwarding on a router.',
    fields: [],
    capabilities: ['ipv6', 'routing', 'configuration'],
  },
  {
    id: 'add-static-ipv6-route',
    title: 'Add IPv6 Static Route',
    category: 'routing',
    description: 'Install an IPv6 static route with an explicit next hop.',
    fields: [
      { id: 'prefix', label: 'Prefix', placeholder: '2001:db8:20::/64', input: 'text', required: true },
      { id: 'nextHop', label: 'Next Hop', placeholder: '2001:db8:12::2', input: 'text', required: true },
    ],
    capabilities: ['ipv6', 'routing', 'configuration'],
  },
];

function parseVlanList(value) {
  return [...new Set(String(value ?? '').split(',').map(x => Number(x.trim())).filter(Number.isInteger))].sort((a, b) => a - b);
}

function isIPv4(value = '') {
  const parts = String(value).trim().split('.');
  return parts.length === 4 && parts.every(part => /^\d+$/.test(part) && Number(part) >= 0 && Number(part) <= 255);
}

function normalizeInterface(value = '') {
  const raw = String(value).trim();
  if (/^gi/i.test(raw)) return `GigabitEthernet${raw.slice(2)}`;
  return raw;
}

export function validateIntent(intent = {}, device = {}) {
  const errors = [];
  const fields = intent.fields || {};
  if (!intent.type) errors.push('Intent type is required.');
  if (!device.id) errors.push('A target device is required.');
  if (intent.type === 'create-vlan') {
    if (device.kind !== 'switch') errors.push('Create VLAN is supported on switch devices only.');
    const id = Number(fields.id);
    if (!Number.isInteger(id) || id < 1 || id > 4094) errors.push('VLAN ID must be an integer from 1 to 4094.');
    const name = String(fields.name ?? '').trim();
    if (!name) errors.push('VLAN name is required.');
    if (name.length > 32) errors.push('VLAN name must be 32 characters or fewer.');
  }
  if (intent.type === 'assign-access-vlan') {
    if (device.kind !== 'switch') errors.push('Access VLAN assignment is supported on switch devices only.');
    const vlan = Number(fields.vlan);
    if (!Number.isInteger(vlan) || vlan < 1 || vlan > 4094) errors.push('VLAN ID must be an integer from 1 to 4094.');
    if (!String(fields.interface ?? '').trim()) errors.push('An interface is required.');
  }
  if (intent.type === 'set-trunk-vlans') {
    if (device.kind !== 'switch') errors.push('Trunk VLAN policy is supported on switch devices only.');
    if (!String(fields.interface ?? '').trim()) errors.push('An interface is required.');
    const vlans = parseVlanList(fields.vlans);
    if (!vlans.length || vlans.some(v => v < 1 || v > 4094)) errors.push('Allowed VLANs must be comma-separated integers from 1 to 4094.');
  }
  if (intent.type === 'set-trunk-policy') {
    if (device.kind !== 'switch') errors.push('Trunk policy is supported on switch devices only.');
    if (!String(fields.interface ?? '').trim()) errors.push('An interface is required.');
    const nativeVlan = Number(fields.nativeVlan);
    if (!Number.isInteger(nativeVlan) || nativeVlan < 1 || nativeVlan > 4094) errors.push('Native VLAN must be an integer from 1 to 4094.');
    const vlans = parseVlanList(fields.vlans);
    if (!vlans.length || vlans.some(v => v < 1 || v > 4094)) errors.push('Allowed VLANs must be comma-separated integers from 1 to 4094.');
  }
  if (intent.type === 'assign-access-vlan-bulk') {
    if (device.kind !== 'switch') errors.push('Access VLAN assignment is supported on switch devices only.');
    const interfaces = String(fields.interfaces ?? '').split(',').map(item => item.trim()).filter(Boolean);
    const vlan = Number(fields.vlan);
    if (!interfaces.length) errors.push('At least one interface is required.');
    if (!Number.isInteger(vlan) || vlan < 1 || vlan > 4094) errors.push('VLAN ID must be an integer from 1 to 4094.');
  }
  if (intent.type === 'set-interface-description') {
    if (!String(fields.interface ?? '').trim()) errors.push('An interface is required.');
    const description = String(fields.description ?? '').trim();
    if (!description) errors.push('Interface description is required.');
    if (description.length > 80) errors.push('Interface description must be 80 characters or fewer.');
  }
  if (intent.type === 'set-interface-state') {
    if (!String(fields.interface ?? '').trim()) errors.push('An interface is required.');
    if (!['up', 'down'].includes(String(fields.state || ''))) errors.push('Interface state must be up or down.');
  }
  if (intent.type === 'add-static-route' || intent.type === 'remove-static-route') {
    if (device.kind !== 'router') errors.push('Static route configuration is supported on router devices only.');
    if (!isIPv4(fields.network)) errors.push('Route network must be a valid IPv4 address.');
    if (!isIPv4(fields.mask)) errors.push('Route mask must be a valid IPv4 mask.');
    if (!isIPv4(fields.nextHop)) errors.push('Next hop must be a valid IPv4 address.');
  }
  if (['configure-ospf-process','add-ospf-network','configure-ospf-interface','set-ospf-passive-interface'].includes(intent.type) && device.kind !== 'router') errors.push('OSPF configuration is supported on router devices only.');
  if (['configure-ospf-process','add-ospf-network','set-ospf-passive-interface'].includes(intent.type)) {
    const process = Number(fields.process); if (!Number.isInteger(process) || process < 1 || process > 65535) errors.push('OSPF process ID must be an integer from 1 to 65535.');
  }
  if (intent.type === 'configure-ospf-process') {
    if (!isIPv4(String(fields.routerId || ''))) errors.push('OSPF router ID must be a valid IPv4 address.');
  }
  if (intent.type === 'add-ospf-network') {
    if (!isIPv4(String(fields.network || ''))) errors.push('OSPF network must be a valid IPv4 address.');
    if (!isIPv4(String(fields.wildcard || ''))) errors.push('OSPF wildcard must be a valid IPv4 address.');
    const area = Number(fields.area); if (!Number.isInteger(area) || area < 0 || area > 4294967295) errors.push('OSPF area must be an integer from 0 to 4294967295.');
  }
  if (intent.type === 'configure-ospf-interface') {
    if (!String(fields.interface || '').trim()) errors.push('An interface is required.');
    const area = Number(fields.area); if (!Number.isInteger(area) || area < 0 || area > 4294967295) errors.push('OSPF area must be an integer from 0 to 4294967295.');
    const hello = Number(fields.hello), dead = Number(fields.dead); if (!Number.isInteger(hello) || hello < 1 || hello > 65535) errors.push('OSPF hello interval must be an integer from 1 to 65535.'); if (!Number.isInteger(dead) || dead < 1 || dead > 65535) errors.push('OSPF dead interval must be an integer from 1 to 65535.'); if (Number.isInteger(hello) && Number.isInteger(dead) && dead <= hello) errors.push('OSPF dead interval must be greater than the hello interval.');
  }
  if (intent.type === 'set-ospf-passive-interface' && !String(fields.interface || '').trim()) errors.push('An interface is required.');
  if (['add-standard-acl-rule','remove-standard-acl'].includes(intent.type)) {
    const id = Number(fields.id); if (!Number.isInteger(id) || id < 1 || id > 99) errors.push('Standard ACL ID must be an integer from 1 to 99.');
  }
  if (intent.type === 'add-standard-acl-rule') {
    if (!['permit','deny'].includes(String(fields.action || ''))) errors.push('ACL action must be permit or deny.');
    if (!String(fields.source || '').trim()) errors.push('ACL source is required.');
    if (fields.wildcard && !isIPv4(String(fields.wildcard))) errors.push('ACL wildcard must be a valid IPv4 address.');
  }
  if (intent.type === 'apply-standard-acl') {
    const id = Number(fields.id); if (!Number.isInteger(id) || id < 1 || id > 99) errors.push('Standard ACL ID must be an integer from 1 to 99.');
    if (!String(fields.interface || '').trim()) errors.push('An interface is required.');
    if (!['in','out'].includes(String(fields.direction || ''))) errors.push('ACL direction must be in or out.');
  }
  if (intent.type === 'harden-access-port') {
    if (device.kind !== 'switch') errors.push('Access-port hardening is supported on switch devices only.');
    if (!String(fields.interface || '').trim()) errors.push('An interface is required.');
    const maximum = Number(fields.maximum); if (!Number.isInteger(maximum) || maximum < 1 || maximum > 4096) errors.push('Maximum MAC addresses must be an integer from 1 to 4096.');
  }
  if (intent.type === 'set-stp-mode') {
    if (device.kind !== 'switch') errors.push('STP mode is supported on switch devices only.');
    if (!['rapid-pvst','pvst','mst'].includes(String(fields.mode || ''))) errors.push('STP mode must be rapid-pvst, pvst or mst.');
  }
  if (intent.type === 'set-stp-vlan-priority') {
    if (device.kind !== 'switch') errors.push('STP VLAN priority is supported on switch devices only.');
    const vlan=Number(fields.vlan), priority=Number(fields.priority); if(!Number.isInteger(vlan)||vlan<1||vlan>4094)errors.push('STP VLAN must be an integer from 1 to 4094.'); if(!Number.isInteger(priority)||priority<0||priority>61440||priority%4096!==0)errors.push('STP priority must be a multiple of 4096 from 0 to 61440.');
  }
  if (intent.type === 'configure-etherchannel') {
    if (device.kind !== 'switch') errors.push('EtherChannel is supported on switch devices only.');
    const interfaces = String(fields.interfaces || '').split(',').map(x=>x.trim()).filter(Boolean); if(!interfaces.length)errors.push('At least one interface is required.');
    const group=Number(fields.group); if(!Number.isInteger(group)||group<1||group>32)errors.push('Channel group must be an integer from 1 to 32.');
    if(!['active','passive','on'].includes(String(fields.mode||'')))errors.push('EtherChannel mode must be active, passive or on.');
  }
  if (intent.type === 'set-interface-nat-role') {
    if (device.kind !== 'router') errors.push('NAT interface roles are supported on router devices only.');
    if (!String(fields.interface || '').trim()) errors.push('An interface is required.');
    if (!['inside','outside'].includes(String(fields.role || ''))) errors.push('NAT role must be inside or outside.');
  }
  if (intent.type === 'configure-nat-overload') {
    if (device.kind !== 'router') errors.push('NAT overload is supported on router devices only.');
    const acl=Number(fields.acl); if(!Number.isInteger(acl)||acl<1||acl>99)errors.push('NAT ACL ID must be an integer from 1 to 99.');
    if(!String(fields.interface||'').trim())errors.push('An outside interface is required.');
  }
  if (intent.type === 'create-dhcp-pool') {
    if (device.kind !== 'router') errors.push('DHCP server pools are supported on router devices only.');
    if(!/^[A-Za-z][A-Za-z0-9_-]{0,31}$/.test(String(fields.name||'')))errors.push('DHCP pool name must start with a letter and contain only letters, numbers, underscores or hyphens.');
    if(!isIPv4(String(fields.network||'')))errors.push('DHCP network must be a valid IPv4 address.'); if(!isIPv4(String(fields.mask||'')))errors.push('DHCP mask must be a valid IPv4 address.'); if(!isIPv4(String(fields.gateway||'')))errors.push('DHCP default gateway must be a valid IPv4 address.'); if(fields.dns && !isIPv4(String(fields.dns)))errors.push('DHCP DNS server must be a valid IPv4 address.');
  }
  if (intent.type === 'exclude-dhcp-address') {
    if (device.kind !== 'router') errors.push('DHCP exclusions are supported on router devices only.');
    if(!isIPv4(String(fields.start||'')))errors.push('DHCP exclusion start address must be valid.'); if(fields.end && !isIPv4(String(fields.end)))errors.push('DHCP exclusion end address must be valid.');
  }
  if (intent.type === 'set-hostname') {
    if (!/^[A-Za-z][A-Za-z0-9_-]{0,31}$/.test(String(fields.hostname||''))) errors.push('Hostname must start with a letter and contain only letters, numbers, underscores or hyphens.');
  }
  if (intent.type === 'configure-ssh' && !/^(?=.{1,63}$)[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?$/.test(String(fields.domain||''))) errors.push('Domain name must be a valid DNS-style name.');
  if (intent.type === 'create-local-user') {
    if (!/^[A-Za-z][A-Za-z0-9_-]{0,31}$/.test(String(fields.username||''))) errors.push('Username must start with a letter and contain only letters, numbers, underscores or hyphens.');
    const privilege=Number(fields.privilege); if(!Number.isInteger(privilege)||privilege<0||privilege>15)errors.push('Privilege must be an integer from 0 to 15.'); if(!String(fields.secret||''))errors.push('A user secret is required.');
  }
  if (intent.type === 'set-default-gateway') {
    if (device.kind !== 'switch') errors.push('Default gateway is intended for switch management.');
    if(!isIPv4(String(fields.gateway||'')))errors.push('Default gateway must be a valid IPv4 address.');
  }
  if (intent.type === 'add-static-ipv6-route') {
    if (device.kind !== 'router') errors.push('IPv6 static routes are supported on router devices only.');
    if(!/^([0-9A-Fa-f:]+)\/(\d|[1-9]\d|1[0-1]\d|12[0-8])$/.test(String(fields.prefix||'')))errors.push('IPv6 prefix must use address/prefix-length notation.');
    if(!/^[0-9A-Fa-f:]+$/.test(String(fields.nextHop||'')))errors.push('IPv6 next hop must be a valid hexadecimal address.');
  }
  const supportedIntents = ['create-vlan','assign-access-vlan','set-trunk-vlans','set-trunk-policy','assign-access-vlan-bulk','set-interface-description','set-interface-state','add-static-route','remove-static-route','save-running-config','configure-ospf-process','add-ospf-network','configure-ospf-interface','set-ospf-passive-interface','add-standard-acl-rule','remove-standard-acl','apply-standard-acl','harden-access-port','set-stp-mode','set-stp-vlan-priority','configure-etherchannel','set-interface-nat-role','configure-nat-overload','create-dhcp-pool','exclude-dhcp-address','set-hostname','configure-ssh','create-local-user','configure-vty-ssh','set-default-gateway','enable-ipv6-routing','add-static-ipv6-route'];
  if (!supportedIntents.includes(intent.type)) errors.push(`Unsupported configuration intent: ${intent.type || 'unknown'}.`);
  return { valid: errors.length === 0, errors };
}

export function renderCiscoIntent(intent = {}) {
  const fields = intent.fields || {};
  if (intent.type === 'create-vlan') {
    return [`enable`, `configure terminal`, `vlan ${Number(fields.id)}`, `name ${String(fields.name).trim()}`, `end`];
  }
  if (intent.type === 'assign-access-vlan') {
    const iface = normalizeInterface(fields.interface);
    return [`enable`, `configure terminal`, `interface ${iface}`, `switchport mode access`, `switchport access vlan ${Number(fields.vlan)}`, `end`];
  }
  if (intent.type === 'set-trunk-vlans') {
    const iface = normalizeInterface(fields.interface);
    const vlans = parseVlanList(fields.vlans).join(',');
    return [`enable`, `configure terminal`, `interface ${iface}`, `switchport mode trunk`, `switchport trunk allowed vlan ${vlans}`, `end`];
  }
  if (intent.type === 'set-trunk-policy') {
    const iface = normalizeInterface(fields.interface);
    const nativeVlan = Number(fields.nativeVlan);
    const vlans = parseVlanList(fields.vlans).join(',');
    return [`enable`, `configure terminal`, `interface ${iface}`, `switchport mode trunk`, `switchport trunk native vlan ${nativeVlan}`, `switchport trunk allowed vlan ${vlans}`, `end`];
  }
  if (intent.type === 'assign-access-vlan-bulk') {
    const vlan = Number(fields.vlan);
    const interfaces = String(fields.interfaces).split(',').map(item => normalizeInterface(item)).filter(Boolean);
    return ['enable', 'configure terminal', ...interfaces.flatMap(iface => [`interface ${iface}`, 'switchport mode access', `switchport access vlan ${vlan}`]), 'end'];
  }
  if (intent.type === 'set-interface-description') {
    const iface = normalizeInterface(fields.interface);
    return [`enable`, `configure terminal`, `interface ${iface}`, `description ${String(fields.description).trim()}`, `end`];
  }
  if (intent.type === 'set-interface-state') {
    const iface = normalizeInterface(fields.interface);
    return [`enable`, `configure terminal`, `interface ${iface}`, String(fields.state) === 'down' ? 'shutdown' : 'no shutdown', `end`];
  }
  if (intent.type === 'add-static-route') return ['enable', 'configure terminal', `ip route ${String(fields.network).trim()} ${String(fields.mask).trim()} ${String(fields.nextHop).trim()}`, 'end'];
  if (intent.type === 'remove-static-route') return ['enable', 'configure terminal', `no ip route ${String(fields.network).trim()} ${String(fields.mask).trim()} ${String(fields.nextHop).trim()}`, 'end'];
  if (intent.type === 'configure-ospf-process') return ['enable', 'configure terminal', `router ospf ${Number(fields.process)}`, `router-id ${String(fields.routerId).trim()}`, 'end'];
  if (intent.type === 'add-ospf-network') return ['enable', 'configure terminal', `router ospf ${Number(fields.process)}`, `network ${String(fields.network).trim()} ${String(fields.wildcard).trim()} area ${Number(fields.area)}`, 'end'];
  if (intent.type === 'configure-ospf-interface') { const iface=normalizeInterface(fields.interface); return ['enable','configure terminal',`interface ${iface}`,`ip ospf ${Number(fields.process)} area ${Number(fields.area)}`,`ip ospf hello-interval ${Number(fields.hello)}`,`ip ospf dead-interval ${Number(fields.dead)}`,'end']; }
  if (intent.type === 'set-ospf-passive-interface') return ['enable','configure terminal',`router ospf ${Number(fields.process)}`,`passive-interface ${normalizeInterface(fields.interface)}`,'end'];
  if (intent.type === 'add-standard-acl-rule') { const wildcard=String(fields.wildcard||'').trim(); return ['enable','configure terminal',`access-list ${Number(fields.id)} ${fields.action} ${String(fields.source).trim()}${wildcard ? ` ${wildcard}` : ''}`,'end']; }
  if (intent.type === 'remove-standard-acl') return ['enable','configure terminal',`no access-list ${Number(fields.id)}`,'end'];
  if (intent.type === 'apply-standard-acl') return ['enable','configure terminal',`interface ${normalizeInterface(fields.interface)}`,`ip access-group ${Number(fields.id)} ${fields.direction}`,'end'];
  if (intent.type === 'harden-access-port') { const iface=normalizeInterface(fields.interface); return ['enable','configure terminal',`interface ${iface}`,'switchport mode access','switchport port-security',`switchport port-security maximum ${Number(fields.maximum)}`,'spanning-tree portfast','spanning-tree bpduguard enable','end']; }
  if (intent.type === 'set-stp-mode') return ['enable','configure terminal',`spanning-tree mode ${fields.mode}`,'end'];
  if (intent.type === 'set-stp-vlan-priority') return ['enable','configure terminal',`spanning-tree vlan ${Number(fields.vlan)} priority ${Number(fields.priority)}`,'end'];
  if (intent.type === 'configure-etherchannel') { const interfaces=String(fields.interfaces).split(',').map(x=>normalizeInterface(x)).filter(Boolean); return ['enable','configure terminal',...interfaces.flatMap(iface=>[`interface ${iface}`,`channel-group ${Number(fields.group)} mode ${fields.mode}`,'exit']),'end']; }
  if (intent.type === 'set-interface-nat-role') return ['enable','configure terminal',`interface ${normalizeInterface(fields.interface)}`,`ip nat ${fields.role}`,'end'];
  if (intent.type === 'configure-nat-overload') return ['enable','configure terminal',`ip nat inside source list ${Number(fields.acl)} interface ${normalizeInterface(fields.interface)} overload`,'end'];
  if (intent.type === 'create-dhcp-pool') { const dns=String(fields.dns||'').trim(); return ['enable','configure terminal',`ip dhcp pool ${String(fields.name).trim()}`,`network ${String(fields.network).trim()} ${String(fields.mask).trim()}`,`default-router ${String(fields.gateway).trim()}`,...(dns ? [`dns-server ${dns}`] : []),'end']; }
  if (intent.type === 'exclude-dhcp-address') return ['enable','configure terminal',`ip dhcp excluded-address ${String(fields.start).trim()}${fields.end ? ` ${String(fields.end).trim()}` : ''}`,'end'];
  if (intent.type === 'set-hostname') return ['enable','configure terminal',`hostname ${String(fields.hostname).trim()}`,'end'];
  if (intent.type === 'configure-ssh') return ['enable','configure terminal',`ip domain name ${String(fields.domain).trim()}`,'ip ssh version 2','end'];
  if (intent.type === 'create-local-user') return ['enable','configure terminal',`username ${String(fields.username).trim()} privilege ${Number(fields.privilege)} secret ${String(fields.secret)}`,'end'];
  if (intent.type === 'configure-vty-ssh') return ['enable','configure terminal','line vty 0 4','login','transport input ssh','end'];
  if (intent.type === 'set-default-gateway') return ['enable','configure terminal',`ip default-gateway ${String(fields.gateway).trim()}`,'end'];
  if (intent.type === 'enable-ipv6-routing') return ['enable','configure terminal','ipv6 unicast-routing','end'];
  if (intent.type === 'add-static-ipv6-route') return ['enable','configure terminal',`ipv6 route ${String(fields.prefix).trim()} ${String(fields.nextHop).trim()}`,'end'];
  if (intent.type === 'save-running-config') return ['enable', 'write memory'];
  return [];
}

export function planIntent(intent = {}, target = {}) {
  const validation = validateIntent(intent, target);
  const commands = validation.valid ? renderCiscoIntent(intent) : [];
  const sensitiveFields = intent.type === 'create-local-user' ? ['secret'] : [];
  const displayCommands = commands.map(command => intent.type === 'create-local-user' ? command.replace(/\ssecret\s+\S+$/, ' secret ********') : command);
  const explanations = displayCommands.map(command => ({
    command,
    reason: command === 'enable' ? 'Enter privileged EXEC mode.'
      : command === 'configure terminal' ? 'Enter global configuration mode.'
      : command.startsWith('vlan ') ? 'Select the VLAN configuration object identified by the requested VLAN ID.'
      : command.startsWith('name ') ? 'Attach a readable name to the selected VLAN.'
      : command.startsWith('interface ') ? 'Select the interface that the requested intent targets.'
      : command === 'switchport mode access' ? 'Make the target interface an access port.'
      : command.startsWith('switchport access vlan ') ? 'Associate the access interface with the requested VLAN.'
      : command === 'switchport mode trunk' ? 'Make the target interface a trunk.'
      : command.startsWith('switchport trunk native vlan ') ? 'Set the VLAN that receives untagged frames on the trunk.'
      : command.startsWith('switchport trunk allowed vlan ') ? 'Define the explicit VLAN allow-list carried by the trunk.'
      : command.startsWith('description ') ? 'Document the operational purpose of the target interface.'
      : command === 'shutdown' ? 'Administratively disable the target interface.'
      : command === 'no shutdown' ? 'Administratively enable the target interface.'
      : command.startsWith('ip route ') ? 'Install an IPv4 static route pointing the requested destination network at the specified next hop.'
      : command.startsWith('no ip route ') ? 'Remove the matching IPv4 static route from the device routing configuration.'
      : command.startsWith('router ospf ') ? 'Select the OSPF process to configure.'
      : command.startsWith('router-id ') ? 'Set the stable OSPF router identifier used by the control plane.'
      : command.startsWith('network ') ? 'Advertise the requested IPv4 network into the selected OSPF area.'
      : command.startsWith('passive-interface ') ? 'Suppress OSPF hellos on the requested interface while retaining the network advertisement.'
      : command.startsWith('ip ospf ') ? 'Apply OSPF process, area or timer parameters to the selected interface.'
      : command.startsWith('access-list ') ? 'Add a standard IPv4 ACL rule that controls matching source traffic.'
      : command.startsWith('no access-list ') ? 'Remove the specified numbered standard ACL from the device.'
      : command.startsWith('ip access-group ') ? 'Attach the selected ACL to the interface in the requested direction.'
      : command === 'switchport port-security' ? 'Enable Layer 2 port-security protection on the access interface.'
      : command.startsWith('switchport port-security maximum ') ? 'Limit the number of secure MAC addresses learned on the interface.'
      : command === 'spanning-tree portfast' ? 'Move an access interface quickly toward forwarding state.'
      : command === 'spanning-tree bpduguard enable' ? 'Protect the edge interface by disabling it if unexpected BPDUs are received.'
      : command.startsWith('spanning-tree mode ') ? 'Select the switch spanning-tree implementation.'
      : command.startsWith('spanning-tree vlan ') ? 'Set the bridge priority used during STP root election for the selected VLAN.'
      : command.startsWith('channel-group ') ? 'Add the interface to the requested EtherChannel group using the selected negotiation mode.'
      : command.startsWith('ip nat ') ? 'Configure the requested NAT/PAT service policy.'
      : command.startsWith('ip dhcp pool ') ? 'Create or select the DHCP service pool.'
      : command.startsWith('ip dhcp excluded-address ') ? 'Reserve the specified address or range outside the DHCP lease pool.'
      : command.startsWith('hostname ') ? 'Set the operational device identity shown in the CLI prompt.'
      : command.startsWith('ip domain name ') ? 'Set the DNS domain used by management services such as SSH.'
      : command === 'ip ssh version 2' ? 'Enable SSH version 2 for remote management.'
      : command.startsWith('username ') ? 'Create a local authenticated management identity at the requested privilege level.'
      : command === 'transport input ssh' ? 'Restrict VTY inbound remote access to SSH.'
      : command === 'login' ? 'Require VTY line login credentials.'
      : command.startsWith('ip default-gateway ') ? 'Define the switch management default gateway.'
      : command === 'ipv6 unicast-routing' ? 'Enable Layer 3 IPv6 forwarding on the router.'
      : command.startsWith('ipv6 route ') ? 'Install the requested IPv6 static route.'
      : command.startsWith('interface range ') ? 'Select multiple interfaces so the following access configuration is applied consistently.'
      : command === 'end' ? 'Return to privileged EXEC mode so the result can be verified.'
      : command === 'write memory' ? 'Persist the current running configuration into startup-config.'
      : 'Execute the vendor-specific implementation step.',
  }));
  return {
    valid: validation.valid,
    errors: validation.errors,
    intent,
    vendor: 'Cisco',
    platform: 'IOS-style',
    commands,
    displayCommands,
    explanations,
    safety: {
      requiresPreview: true,
      mutatesDevice: commands.length > 0,
      credentialHandling: intent.type === 'create-local-user' ? 'A secret is transiently represented in the current plan; never persist or place it in reusable runbook metadata.' : 'No credentials are represented in the intent.',
      sensitiveFields,
    },
  };
}

function outputLines(value) {
  if (Array.isArray(value)) return value.filter(Boolean);
  if (value == null || value === '') return [];
  return String(value).split('\n');
}

export function createSimulatedDeviceAdapter(initialState, deviceId) {
  let state = normalizeLabState(initialState);
  let connected = false;
  const getDevice = () => state.devices?.[deviceId];
  return {
    protocol: 'device-adapter/1',
    kind: 'simulated',
    deviceId,
    async connect() {
      if (!getDevice()) throw new Error(`Device ${deviceId} not found.`);
      connected = true;
      return { connected: true, device: deviceRecord(deviceId, getDevice()) };
    },
    async disconnect() {
      connected = false;
      return { connected: false };
    },
    isConnected() { return connected; },
    async execute(command) {
      if (!connected) throw new Error('Device session is not connected.');
      const result = executeCommand(state, deviceId, command);
      state = result.state;
      return { command, output: outputLines(result.output), device: deviceRecord(deviceId, getDevice()), state: normalizeLabState(state) };
    },
    async applyIntent(intent) {
      if (!connected) throw new Error('Device session is not connected.');
      const plan = planIntent(intent, deviceRecord(deviceId, getDevice()));
      if (!plan.valid) return { applied: false, plan };
      const transcript = [];
      for (const command of plan.commands) {
        // Simulated sessions begin in privileged EXEC. A real SSH/serial session may begin in user EXEC,
        // so `enable` remains part of the vendor plan but is skipped when the current session already has privilege.
        if (command === 'enable' && getDevice()?.mode === 'exec') continue;
        transcript.push(await this.execute(command));
      }
      return { applied: true, plan, transcript, state: normalizeLabState(state) };
    },
    async inspect() {
      if (!connected) throw new Error('Device session is not connected.');
      const report = inspectSimulatedDevice(state, deviceId);
      const running = await this.snapshot();
      return { ...report, runningConfig: running.runningConfig };
    },
    async snapshot() {
      if (!connected) throw new Error('Device session is not connected.');
      const running = await this.execute('show running-config');
      const startup = await this.execute('show startup-config');
      return {
        deviceId,
        capturedAt: new Date().toISOString(),
        runningConfig: running.output.join('\n'),
        startupConfig: startup.output.join('\n'),
        state: normalizeLabState(state),
      };
    },
    getState() { return normalizeLabState(state); },
  };
}

export function deviceAgentContract() {
  return {
    protocol: 'device-agent/3',
    operations: ['discover', 'connect', 'disconnect', 'execute', 'snapshot', 'inspect', 'diagnostics', 'apply-intent', 'config-history', 'config-diff'],
    transports: ['simulated', 'ssh', 'serial'],
    boundary: 'Credentials and transport sockets stay outside the browser UI.',
  };
}

export function externalDeviceRecord(config = {}, status = 'ready') {
  const id = config.id || config.name || config.hostname || config.host;
  const provider = DEVICE_PROVIDERS.ciscoIos;
  const kind = config.kind || 'switch';
  return {
    id,
    name: config.name || config.hostname || id,
    hostname: config.hostname || config.name || id,
    kind,
    vendor: config.vendor || provider.vendor,
    platform: config.platform || provider.platform,
    version: config.version || 'unknown',
    mode: 'exec',
    interfaceCount: Number(config.interfaceCount || 0),
    upInterfaceCount: Number(config.upInterfaceCount || 0),
    vlanCount: Number(config.vlanCount || 0),
    routeCount: Number(config.routeCount || 0),
    connection: {
      type: config.connectionType || 'ssh',
      status,
      endpoint: config.connectionType === 'serial'
        ? (config.serialPort || config.portPath || 'unknown')
        : `${config.host || 'unknown'}:${Number(config.port || 22)}`,
      ...(config.connectionType === 'serial' ? {
        serial: {
          baudRate: Number(config.baudRate || 9600),
          dataBits: Number(config.dataBits || 8),
          stopBits: Number(config.stopBits || 1),
          parity: config.parity || 'none',
          flowControl: config.flowControl || 'none',
        },
      } : {}),
    },
    capabilities: [
      ...(kind === 'router' ? [...ROUTER_CAPABILITIES] : [...SWITCH_CAPABILITIES]),
      ...(config.connectionType === 'serial' ? ['serial-console'] : []),
    ],
    inspection: null,
  };
}

export function validateDeviceConnection(config = {}) {
  const errors = [];
  if (!String(config.name || config.hostname || '').trim()) errors.push('Device name or hostname is required.');
  const connectionType = String(config.connectionType || 'ssh');
  if (!['ssh', 'serial'].includes(connectionType)) errors.push('Physical device connection type must be ssh or serial.');

  if (connectionType === 'serial') {
    if (!String(config.serialPort || config.portPath || '').trim()) errors.push('Serial device path is required.');
    const baud = Number(config.baudRate || 9600);
    if (!Number.isInteger(baud) || baud < 1200 || baud > 921600) errors.push('Serial baud rate must be an integer from 1200 to 921600.');
    const dataBits = Number(config.dataBits || 8);
    if (![5, 6, 7, 8].includes(dataBits)) errors.push('Serial data bits must be 5, 6, 7 or 8.');
    const stopBits = Number(config.stopBits || 1);
    if (![1, 2].includes(stopBits)) errors.push('Serial stop bits must be 1 or 2.');
    if (!['none', 'even', 'odd'].includes(String(config.parity || 'none'))) errors.push('Serial parity must be none, even or odd.');
    if (!['none', 'hardware', 'software'].includes(String(config.flowControl || 'none'))) errors.push('Serial flow control must be none, hardware or software.');
    return { valid: errors.length === 0, errors };
  }

  if (!String(config.host || '').trim()) errors.push('Device host is required.');
  const port = Number(config.port || 22);
  if (!Number.isInteger(port) || port < 1 || port > 65535) errors.push('Device port must be an integer from 1 to 65535.');
  if (!String(config.username || '').trim()) errors.push('SSH username is required.');
  if (config.passwordEnv && !/^[A-Za-z_][A-Za-z0-9_]*$/.test(String(config.passwordEnv))) errors.push('Password environment variable name is invalid.');
  if (config.enablePasswordEnv && !/^[A-Za-z_][A-Za-z0-9_]*$/.test(String(config.enablePasswordEnv))) errors.push('Enable-password environment variable name is invalid.');
  if (config.privateKeyPath && config.passwordEnv) errors.push('Choose a private key or a password environment variable for SSH login.');
  return { valid: errors.length === 0, errors };
}
