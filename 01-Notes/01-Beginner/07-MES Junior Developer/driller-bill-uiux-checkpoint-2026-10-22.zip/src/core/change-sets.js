import { classifyIntentRisk } from './change-control.js';

export const CHANGE_SET_VERSION = '1.0.0';
export const CHANGE_SET_STORAGE_KEY = 'drillerBill.changeSets.v60';
export const CHANGE_SET_MAX_HISTORY = 60;
export const CHANGE_SET_STRATEGIES = Object.freeze(['stop-on-failure', 'continue-on-failure']);

const RISK_ORDER = Object.freeze({ low: 1, medium: 2, high: 3, critical: 4 });

function clean(value, fallback = '') {
  const text = String(value ?? '').trim();
  return text || fallback;
}

function nowIso() { return new Date().toISOString(); }

function safeIntent(intent = {}) {
  const fields = {};
  for (const [key, value] of Object.entries(intent.fields || {})) {
    fields[key] = /secret|password|passphrase|token|privatekey|credential/i.test(key) ? '[redacted]' : value;
  }
  return { type: clean(intent.type, 'unknown'), fields };
}

function riskRank(level = 'high') { return RISK_ORDER[level] || 3; }


export function normalizeChangeSet(input = {}) {
  const items = Array.isArray(input.items) ? input.items : [];
  const normalizedItems = items.map((item, index) => ({
    id: clean(item.id, `csi-${index + 1}`),
    deviceId: clean(item.deviceId),
    deviceType: clean(item.deviceType, 'unknown'),
    transport: clean(item.transport, 'simulated'),
    label: clean(item.label, clean(item.intent?.type, 'configuration').replaceAll('-', ' ')),
    intent: safeIntent(item.intent),
    risk: item.risk ? { level: clean(item.risk.level, 'high'), rank: Number(item.risk.rank) || riskRank(item.risk.level) } : { level: 'high', rank: 3 },
    status: clean(item.status, 'planned'),
    preflight: item.preflight ? {
      valid: Boolean(item.preflight.valid),
      changeId: clean(item.preflight.changeId),
      expiresAt: item.preflight.expiresAt || null,
      summary: clean(item.preflight.summary),
      risk: item.preflight.risk ? { level: clean(item.preflight.risk.level, 'high'), rank: Number(item.preflight.risk.rank) || riskRank(item.preflight.risk.level) } : null,
      checks: Array.isArray(item.preflight.checks) ? item.preflight.checks.map(check => ({ id: clean(check.id), status: clean(check.status), label: clean(check.label), detail: clean(check.detail) })) : [],
    } : null,
    plan: item.plan ? { valid: Boolean(item.plan.valid), errors: Array.isArray(item.plan.errors) ? item.plan.errors.map(String) : [], displayCommands: Array.isArray(item.plan.displayCommands) ? item.plan.displayCommands.map(String) : [] } : null,
    changeId: clean(item.changeId),
    startedAt: item.startedAt || null,
    completedAt: item.completedAt || null,
    verification: item.verification ? { passed: Boolean(item.verification.passed), detail: clean(item.verification.detail), inspectedAt: item.verification.inspectedAt || null } : null,
    error: clean(item.error),
  }));

  const maxRisk = normalizedItems.reduce((best, item) => item.risk.rank > best.rank ? item.risk : best, { level: 'low', rank: 1 });
  return {
    version: CHANGE_SET_VERSION,
    id: clean(input.id, `set-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`),
    title: clean(input.title, 'Network change set'),
    description: clean(input.description),
    strategy: CHANGE_SET_STRATEGIES.includes(input.strategy) ? input.strategy : 'stop-on-failure',
    status: clean(input.status, 'draft'),
    createdAt: input.createdAt || nowIso(),
    updatedAt: input.updatedAt || nowIso(),
    approvedAt: input.approvedAt || null,
    startedAt: input.startedAt || null,
    completedAt: input.completedAt || null,
    maxRisk,
    items: normalizedItems,
    timeline: Array.isArray(input.timeline) ? input.timeline.slice(-100).map(entry => ({ at: entry.at || nowIso(), type: clean(entry.type, 'event'), text: clean(entry.text) })) : [],
    notes: Array.isArray(input.notes) ? input.notes.slice(-50).map(String) : [],
  };
}

export function validateChangeSet(changeSet = {}) {
  const normalized = normalizeChangeSet(changeSet);
  const errors = [];
  if (!normalized.title) errors.push('A change set title is required.');
  if (!normalized.items.length) errors.push('At least one device change is required.');
  const duplicateDevices = normalized.items.map(item => item.deviceId).filter(Boolean);
  const duplicateCount = duplicateDevices.length - new Set(duplicateDevices).size;
  if (duplicateCount > 0) errors.push('Each device may appear only once in a change set.');
  normalized.items.forEach((item, index) => {
    if (!item.deviceId) errors.push(`Change ${index + 1} has no target device.`);
    if (!item.intent?.type || item.intent.type === 'unknown') errors.push(`Change ${index + 1} has no intent type.`);
  });
  return { valid: errors.length === 0, errors, changeSet: normalized };
}

export function buildChangeSet({ title = '', description = '', strategy = 'stop-on-failure', items = [] } = {}) {
  const next = normalizeChangeSet({ title, description, strategy, items, status: 'draft', timeline: [{ type: 'created', text: 'Change set created.' }] });
  const result = validateChangeSet(next);
  return { ...result, changeSet: next };
}

export function compileChangeSet(changeSet, devices, planIntentFn) {
  const normalized = normalizeChangeSet(changeSet);
  const byId = new Map((devices || []).map(device => [device.id, device]));
  const items = normalized.items.map(item => {
    const device = byId.get(item.deviceId);
    if (!device) return { ...item, plan: { valid: false, errors: ['Target device is not in the current inventory.'], displayCommands: [] }, status: 'blocked', error: 'Target device is not in the current inventory.' };
    const plan = planIntentFn(item.intent, device);
    const risk = classifyIntentRisk(item.intent);
    return { ...item, deviceType: device.kind || item.deviceType, transport: device.connection?.type || item.transport, risk: { level: risk.level, rank: risk.rank }, plan: { valid: Boolean(plan.valid), errors: plan.errors || [], displayCommands: plan.displayCommands || [] }, status: plan.valid ? 'planned' : 'blocked', error: plan.valid ? '' : (plan.errors || []).join(' ') };
  });
  const errors = items.flatMap(item => item.plan?.valid ? [] : [`${item.deviceId}: ${item.error || item.plan?.errors?.join(' ') || 'invalid plan'}`]);
  const maxRisk = items.reduce((best, item) => item.risk.rank > best.rank ? item.risk : best, { level: 'low', rank: 1 });
  return { valid: errors.length === 0 && items.length > 0, errors, items, maxRisk, total: items.length, ready: items.filter(item => item.plan?.valid).length };
}

export function summarizeChangeSet(changeSet = {}) {
  const normalized = normalizeChangeSet(changeSet);
  const counts = normalized.items.reduce((acc, item) => { acc[item.status] = (acc[item.status] || 0) + 1; return acc; }, {});
  const completed = counts.completed || counts.verified || 0;
  if (normalized.status === 'completed') return `Completed · ${completed}/${normalized.items.length} verified`;
  if (normalized.status === 'partial') return `Partial · ${completed}/${normalized.items.length} completed`;
  if (normalized.status === 'failed') return `Failed · ${counts.failed || 0} failed`;
  if (normalized.status === 'preflighted') return `Preflighted · ${normalized.items.length} device${normalized.items.length === 1 ? '' : 's'}`;
  return `${normalized.items.length} device${normalized.items.length === 1 ? '' : 's'} · ${normalized.maxRisk.label || normalized.maxRisk.level}`;
}

export function progressForChangeSet(changeSet = {}) {
  const normalized = normalizeChangeSet(changeSet);
  const total = normalized.items.length;
  const completed = normalized.items.filter(item => ['completed', 'verified'].includes(item.status) || item.verification?.passed === true).length;
  const failed = normalized.items.filter(item => item.status === 'failed').length;
  return { total, completed, failed, percent: total ? Math.round((completed / total) * 100) : 0 };
}

export function addChangeSetTimeline(changeSet, type, text) {
  const normalized = normalizeChangeSet(changeSet);
  normalized.timeline.push({ at: nowIso(), type: clean(type, 'event'), text: clean(text) });
  normalized.timeline = normalized.timeline.slice(-100);
  normalized.updatedAt = nowIso();
  return normalized;
}

export function loadChangeSets(storage) {
  try {
    const raw = storage?.getItem(CHANGE_SET_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.map(normalizeChangeSet).slice(-CHANGE_SET_MAX_HISTORY).reverse() : [];
  } catch {
    return [];
  }
}

export function saveChangeSets(storage, changeSets = []) {
  const normalized = changeSets.map(normalizeChangeSet).slice(-CHANGE_SET_MAX_HISTORY);
  const persisted = normalized.map(changeSet => ({
    ...changeSet,
    status: changeSet.status === 'preflighted' || changeSet.status === 'running' ? 'draft' : changeSet.status,
    approvedAt: null,
    items: changeSet.items.map(item => ({
      ...item,
      changeId: '',
      preflight: item.preflight ? { ...item.preflight, changeId: '' } : null,
    })),
  }));
  storage?.setItem(CHANGE_SET_STORAGE_KEY, JSON.stringify(persisted));
  return normalized;
}
