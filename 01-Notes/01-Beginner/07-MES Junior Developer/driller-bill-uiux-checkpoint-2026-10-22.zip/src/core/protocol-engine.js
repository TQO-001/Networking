import { freshNetwork, executeCommand, promptForModel, LINKS, DEVICES, ENDPOINTS, effectiveRoutes } from './network-model.js';

export const PROTOCOL_CASES = [
  {id:'dhcp-recovery', code:'PRO-01', title:'Restore DHCP service', protocol:'DHCP', difficulty:'APPLICATION', timeMinutes:15,
   brief:'PC1 should receive an address from the USERS pool. The router has a pool, but its default gateway option is wrong and the client is still unbound.',
   steps:['Inspect the DHCP pool','Correct the default-router option','Renew the client lease','Verify the binding'],
   objective:'DHCP pool supplies 10.10.10.1 as the default gateway', hint:'Use `show ip dhcp pool`, then enter `ip dhcp pool USERS` and set `default-router 10.10.10.1`.'},
  {id:'nat-edge', code:'PRO-02', title:'Restore the NAT edge', protocol:'NAT', difficulty:'ANALYSIS', timeMinutes:18,
   brief:'Inside users need translated access toward the simulated WAN. The router has the NAT rule, but the inside interface is not marked as an inside interface.',
   steps:['Inspect NAT statistics','Inspect Gi0/0','Mark Gi0/0 as NAT inside','Verify the translation path'],
   objective:'R1 Gi0/0 is NAT inside and the overload rule is active', hint:'Inspect `show ip nat statistics`; then configure `ip nat inside` under R1 Gi0/0.'},
  {id:'stp-root', code:'PRO-03', title:'Re-establish the STP root', protocol:'RSTP', difficulty:'ANALYSIS', timeMinutes:15,
   brief:'SW2 became the root bridge after a priority change. Restore SW1 as the root for VLANs 10 and 20 without disabling spanning tree.',
   steps:['Inspect STP on both switches','Lower SW1 VLAN priorities','Verify the root bridge','Verify forwarding state'],
   objective:'SW1 is root for VLANs 10 and 20', hint:'Use `show spanning-tree vlan 10` and set SW1 priority lower than SW2.'},
  {id:'etherchannel-repair', code:'PRO-04', title:'Repair the LACP bundle', protocol:'ETHERCHANNEL', difficulty:'APPLICATION', timeMinutes:18,
   brief:'SW1 and SW2 have two parallel trunk links, but the Gi0/22 member on SW2 is not participating in Port-channel 1.',
   steps:['Inspect EtherChannel summary','Enter Gi0/22 on SW2','Join it to channel-group 1 in active mode','Verify the bundle'],
   objective:'Port-channel 1 forms with Gi0/21 and Gi0/22 on both switches', hint:'Use `show etherchannel summary`; then add SW2 Gi0/22 to `channel-group 1 mode active`.'},
  {id:'ospf-timers', code:'PRO-05', title:'Normalize OSPF timers', protocol:'OSPF', difficulty:'ANALYSIS', timeMinutes:20,
   brief:'R1 and R2 can see each other, but the adjacency remains down because the hello/dead timers do not match.',
   steps:['Inspect OSPF status','Compare timer configuration','Correct R2 timers','Verify the FULL adjacency'],
   objective:'R1 and R2 use matching OSPF hello 10 / dead 40 timers and form FULL', hint:'Use `show ip ospf neighbor` and `show ip ospf interface`; match R2 to 10/40.'}
];

export const PROTOCOL_STORAGE='pennyFarthingProtocol:v8';

function clone(x){return structuredClone(x);}
function ifaceUp(i){return !!i?.admin && !!i?.link;}
function addInterface(dev,name,kind='switch'){
  if(dev.interfaces[name])return;
  if(kind==='switch')dev.interfaces[name]={mode:'trunk',nativeVlan:99,allowedVlans:[10,20,99],admin:true,link:true};
  else dev.interfaces[name]={ip:'',mask:'',admin:true,link:true};
}

export function freshProtocolState(caseId='dhcp-recovery'){
  const state=freshNetwork();
  Object.values(state.devices).forEach(d=>{
    d.protocol={dhcp:{pools:{},bindings:{}},nat:{inside:[],outside:[],rules:[],translations:[]},ospfTimers:{hello:10,dead:40},etherchannel:{groups:{}},stpMode:'rapid-pvst'};
  });
  addInterface(state.devices.SW1,'GigabitEthernet0/21');
  addInterface(state.devices.SW1,'GigabitEthernet0/22');
  addInterface(state.devices.SW2,'GigabitEthernet0/21');
  addInterface(state.devices.SW2,'GigabitEthernet0/22');
  state.devices.SW1.etherchannel={group:1,protocol:'LACP',ports:['Gi0/21','Gi0/22'],members:{'Gi0/21':true,'Gi0/22':true}};
  state.devices.SW2.etherchannel={group:1,protocol:'LACP',ports:['Gi0/21','Gi0/22'],members:{'Gi0/21':true,'Gi0/22':false}};
  state.devices.R1.protocol.dhcp.pools.USERS={network:'10.10.10.0/24',defaultRouter:'10.10.10.254',dnsServer:'8.8.8.8',excluded:['10.10.10.1']};
  state.devices.R1.protocol.dhcp.bindings.PC1={pool:'USERS',ip:null,status:'INIT'};
  state.devices.R1.protocol.nat.inside=[];
  state.devices.R1.protocol.nat.outside=['GigabitEthernet0/1'];
  state.devices.R1.protocol.nat.rules=[{type:'overload',interface:'GigabitEthernet0/1',acl:'1',enabled:true}];
  state.devices.R1.ospfTimers={hello:10,dead:40};
  state.devices.R2.ospfTimers={hello:5,dead:20};
  state.devices.SW1.protocol.stpVlans={10:{priority:28672},20:{priority:28672}};
  state.devices.SW2.protocol.stpVlans={10:{priority:24576},20:{priority:24576}};

  if(caseId==='dhcp-recovery'){}
  if(caseId==='nat-edge'){}
  if(caseId==='stp-root'){}
  if(caseId==='etherchannel-repair'){}
  if(caseId==='ospf-timers'){}
  return deriveProtocolState(state);
}

function rootSwitch(state,vlan){
  return ['SW1','SW2'].map(n=>state.devices[n]).sort((a,b)=>((a.protocol?.stpVlans?.[vlan]?.priority??32768)-(b.protocol?.stpVlans?.[vlan]?.priority??32768))||a.stp.mac.localeCompare(b.stp.mac))[0];
}

function etherchannelFormed(state,device='SW1',group=1){
  const d=state.devices[device]; const members=d?.etherchannel?.members; if(!members)return false;
  const local=Object.values(members).every(Boolean);
  const peer=device==='SW1'?'SW2':'SW1'; const pm=state.devices[peer]?.etherchannel?.members;
  return local && !!pm && Object.values(pm).every(Boolean);
}

function ospfFullProtocol(state){
  const r1=state.devices.R1,r2=state.devices.R2;
  const up=ifaceUp(r1.interfaces['GigabitEthernet0/1']) && ifaceUp(r2.interfaces['GigabitEthernet0/0']);
  const timers=r1.protocol.ospfTimers?.hello===r2.protocol.ospfTimers?.hello && r1.protocol.ospfTimers?.dead===r2.protocol.ospfTimers?.dead;
  return !!(r1.ospf&&r2.ospf&&up&&timers);
}

function leaseForPool(state,poolName){
  const r1=state.devices.R1, pool=r1.protocol.dhcp.pools[poolName]; if(!pool)return null;
  const b=r1.protocol.dhcp.bindings.PC1;
  if(pool.defaultRouter==='10.10.10.1'){
    b.ip='10.10.10.100'; b.status='BOUND';
  } else { b.ip=null; b.status='INIT'; }
  return b;
}

function natHealthy(state){
  const r1=state.devices.R1; const inside=r1.protocol.nat.inside.includes('GigabitEthernet0/0'); const rule=r1.protocol.nat.rules.some(r=>r.type==='overload'&&r.interface==='GigabitEthernet0/1'&&r.enabled); return inside&&rule&&r1.protocol.nat.outside.includes('GigabitEthernet0/1');
}

export function deriveProtocolState(state){
  const s=clone(state);
  const r1=s.devices.R1;
  if(r1.protocol?.dhcp?.pools?.USERS)leaseForPool(s,'USERS');
  const natOK=natHealthy(s);
  r1.protocol.nat.translations=natOK ? [{insideLocal:'10.10.10.10',insideGlobal:'10.0.12.1',outsideLocal:'203.0.113.10',outsideGlobal:'203.0.113.10',type:'dynamic'}] : [];
  for(const v of [10,20]){
    const root=rootSwitch(s,v);
    for(const sw of ['SW1','SW2']){
      const d=s.devices[sw]; d.protocol.stpVlans[v].root=root.name;
      d.protocol.stpVlans[v].role=root.name===sw?'ROOT':'NONROOT';
      d.protocol.stpVlans[v].state=etherchannelFormed(s,'SW1',1)?'FWD':'FWD';
    }
  }
  for(const sw of ['SW1','SW2']){
    const d=s.devices[sw];
    d.etherchannel.formed=etherchannelFormed(s,sw,1);
  }
  r1.protocol.ospfAdjacency=ospfFullProtocol(s);
  s.devices.R2.protocol.ospfAdjacency=ospfFullProtocol(s);
  return s;
}

function compact(name){return String(name||'').replace(/^GigabitEthernet/,'Gi').replace(/^FastEthernet/,'Fa');}
function parseList(v){return v.split(',').flatMap(x=>{const [a,b]=x.split('-').map(Number);return Number.isInteger(b)?Array.from({length:b-a+1},(_,i)=>a+i):[Number(a)]}).filter(Number.isInteger);}
function parseInterface(name){const x=String(name||'').trim();if(/^gi/i.test(x)){const p=x.replace(/^gi/i,'');return `GigabitEthernet${p.startsWith('g')?'0/':p.includes('/')?'':''}${p}`.replace('GigabitEthernet0/0/','GigabitEthernet0/');}return x;}
function normalizeInterface(name){const n=String(name||'').trim().toLowerCase();if(/^gi\d+\/\d+$/.test(n))return `GigabitEthernet${n.slice(2)}`;if(/^g\d+\/\d+$/.test(n))return `GigabitEthernet${n.slice(1)}`;return name;}

function protocolShow(state,device,cmd){
  const d=state.devices[device], p=d.protocol||{};
  if(cmd==='show ip dhcp pool'){
    if(d.kind!=='router')return '% DHCP pool information is available on routers only.';
    const rows=Object.entries(p.dhcp.pools).map(([name,x])=>`Pool ${name}\n  Network ${x.network}\n  Default-router ${x.defaultRouter}\n  DNS-server ${x.dnsServer}\n  Excluded ${x.excluded.join(', ')}`).join('\n\n');
    return rows||'No DHCP pools configured.';
  }
  if(cmd==='show ip dhcp binding'){
    const rows=Object.entries(p.dhcp.bindings).map(([client,b])=>`${client.padEnd(10)} ${b.ip||'unknown'.padEnd(15)} ${b.status.padEnd(8)} ${b.pool}`).join('\n');
    return `IP address       Client-ID/Lease       State\n${rows||'(none)'}`;
  }
  if(cmd==='show ip nat translations'){
    const rows=p.nat.translations.map(t=>`${t.insideLocal.padEnd(16)} ${t.insideGlobal.padEnd(16)} ${t.outsideLocal.padEnd(16)} ${t.outsideGlobal.padEnd(16)} ${t.type}`); return `Pro  Inside local     Inside global    Outside local    Outside global\n${rows.length?rows.join('\n'):'(none)'}`;
  }
  if(cmd==='show ip nat statistics'){
    return `Active translations: ${p.nat.translations.length}\nInside interfaces: ${p.nat.inside.map(compact).join(', ')||'none'}\nOutside interfaces: ${p.nat.outside.map(compact).join(', ')||'none'}\nOverload rules: ${p.nat.rules.filter(r=>r.enabled).length}`;
  }
  const sm=cmd.match(/^show spanning-tree(?: vlan (\d+))?$/); if(sm&&d.kind==='switch'){
    const vlan=Number(sm[1]||10), v=p.stpVlans?.[vlan]||{priority:32768,root:device,role:'ROOT',state:'FWD'};
    return `VLAN${String(vlan).padStart(4,'0')}\n  Spanning tree enabled protocol rapid-pvst\n  Root ID    Priority    ${state.devices[v.root]?.protocol?.stpVlans?.[vlan]?.priority??v.priority}\n             Address     ${state.devices[v.root]?.stp?.mac||d.stp.mac}\n             This bridge is the ${v.role==='ROOT'?'root':'a non-root bridge'}\n\nInterface        Role Sts Cost\nGi0/24           ${v.role==='ROOT'?'Desg':'Root'} FWD 4`;
  }
  if(cmd==='show etherchannel summary'&&d.kind==='switch'){
    const f=d.etherchannel?.formed; const members=Object.entries(d.etherchannel?.members||{}).map(([x,on])=>`${x}(${on?'P':'s'})`).join(' ');
    return `Group  Port-channel  Protocol    Ports\n${d.etherchannel.group}      Po${d.etherchannel.group}(${f?'SU':'SD'})         ${d.etherchannel.protocol}        ${members}`;
  }
  if(cmd==='show ip ospf interface'){
    return `OSPF Process 1\n  Hello interval ${p.ospfTimers?.hello??10}, Dead interval ${p.ospfTimers?.dead??40}\n  Timer match with peer: ${state.devices[device==='R1'?'R2':'R1']?.protocol?.ospfTimers?.hello===p.ospfTimers?.hello?'yes':'no'}`;
  }
  if(cmd==='show ip ospf neighbor'){
    const full=ospfFullProtocol(state); return `Neighbor ID     State        Dead Time   Address\n${device==='R1'?'2.2.2.2':'1.1.1.1'}         ${full?'FULL':'DOWN'}        ${p.ospfTimers?.dead||40}         ${device==='R1'?'10.0.12.2':'10.0.12.1'}`;
  }
  return null;
}

export function executeProtocolCommand(prevState,device,raw){
  const original=String(raw||'').trim(); if(!original)return {state:prevState,output:''};
  const state=deriveProtocolState(prevState); const d=state.devices[device]; if(!d)return {state,output:'% Unknown device.'};
  const cmd=original.toLowerCase().replace(/\s+/g,' ');
  const shown=protocolShow(state,device,cmd); if(shown!==null)return {state,output:shown};

  if(cmd==='renew dhcp client pc1'){const b=leaseForPool(state,'USERS');return {state:deriveProtocolState(state),output:b?.status==='BOUND'?`DHCP client PC1 bound to ${b.ip} / gateway ${state.devices.R1.protocol.dhcp.pools.USERS.defaultRouter}`:'DHCP request failed: pool default-router is invalid.'};}
  if(cmd==='simulate nat flow'){return {state:deriveProtocolState(state),output:natHealthy(state)?'Created dynamic translation 10.10.10.10 → 10.0.12.1. Translation table updated.':'% NAT flow failed: inside/outside interface roles are incomplete.'};}

  if(d.mode==='exec'||d.mode==='user'){
    if(cmd==='configure terminal'||cmd==='conf t') { if(d.mode==='user')return {state,output:'% Privileged EXEC mode required.'}; d.mode='config'; return {state,output:'Enter configuration commands, one per line. End with CNTL/Z.'}; }
    return executeCommand(state,device,original);
  }
  if(d.mode==='config'){
    if(cmd.startsWith('ip dhcp excluded-address ')) {d.protocol.dhcp.globalExcluded=d.protocol.dhcp.globalExcluded||[];d.protocol.dhcp.globalExcluded.push(original.slice(23).trim());return {state,output:''};}
    const pool=original.match(/^ip dhcp pool (.+)$/i); if(pool&&d.kind==='router'){d.configPool=pool[1].trim();d.protocol.dhcp.pools[d.configPool]=d.protocol.dhcp.pools[d.configPool]||{network:'10.10.10.0/24',defaultRouter:'10.10.10.254',dnsServer:'8.8.8.8',excluded:[]};d.mode='config-dhcp';return {state,output:''};}
    const nat=cmd.match(/^ip nat inside source list (\d+) interface (.+) overload$/); if(nat&&d.kind==='router'){d.protocol.nat.rules=[...d.protocol.nat.rules.filter(r=>r.acl!==nat[1]),{type:'overload',interface:normalizeInterface(nat[2]),acl:nat[1],enabled:true}];return {state,output:''};}
    const stp=cmd.match(/^spanning-tree vlan (\d+) priority (\d+)$/); if(stp&&d.kind==='switch'){const vlan=Number(stp[1]),priority=Number(stp[2]);d.protocol.stpVlans=d.protocol.stpVlans||{};d.protocol.stpVlans[vlan]=d.protocol.stpVlans[vlan]||{};d.protocol.stpVlans[vlan].priority=priority;return {state,output:''};}
    return executeCommand(state,device,original);
  }
  if(d.mode==='config-dhcp'){
    const p=d.protocol.dhcp.pools[d.configPool];
    if(cmd.startsWith('network ')){p.network=original.slice(8).trim();return {state,output:''};}
    if(cmd.startsWith('default-router ')){p.defaultRouter=original.slice(15).trim();return {state,output:''};}
    if(cmd.startsWith('dns-server ')){p.dnsServer=original.slice(11).trim();return {state,output:''};}
    if(cmd==='exit'){d.mode='config';delete d.configPool;return {state,output:''};}
    return {state,output:'% DHCP pool command not supported.'};
  }
  if(d.mode==='config-if'){
    const i=d.interfaces[d.configInterface];
    if(cmd==='ip nat inside'){d.protocol.nat.inside=[...new Set([...d.protocol.nat.inside,d.configInterface])];return {state,output:''};}
    if(cmd==='ip nat outside'){d.protocol.nat.outside=[...new Set([...d.protocol.nat.outside,d.configInterface])];return {state,output:''};}
    if(cmd==='no ip nat inside'){d.protocol.nat.inside=d.protocol.nat.inside.filter(x=>x!==d.configInterface);return {state,output:''};}
    if(cmd==='no ip nat outside'){d.protocol.nat.outside=d.protocol.nat.outside.filter(x=>x!==d.configInterface);return {state,output:''};}
    const ch=cmd.match(/^channel-group (\d+) mode (active|passive|on)$/); if(ch&&d.kind==='switch'){const g=Number(ch[1]);d.etherchannel.group=g;d.etherchannel.protocol=ch[2]==='on'?'STATIC':'LACP';d.etherchannel.members[compact(d.configInterface)]=true;return {state,output:''};}
    return executeCommand(state,device,original);
  }
  if(d.mode==='config-router'){
    if(cmd.startsWith('timers hello ')){d.protocol.ospfTimers.hello=Number(cmd.split(' ').at(-1));return {state,output:''};}
    if(cmd.startsWith('timers dead ')){d.protocol.ospfTimers.dead=Number(cmd.split(' ').at(-1));return {state,output:''};}
    return executeCommand(state,device,original);
  }
  return executeCommand(state,device,original);
}

export function evaluateProtocolCase(state,caseId){
  const c=PROTOCOL_CASES.find(x=>x.id===caseId); if(!c)return {ok:false,score:0,checks:[]};
  const s=deriveProtocolState(state), checks=[];
  if(caseId==='dhcp-recovery'){
    const p=s.devices.R1.protocol.dhcp.pools.USERS, b=s.devices.R1.protocol.dhcp.bindings.PC1;
    checks.push({label:'USERS pool exists',ok:!!p}); checks.push({label:'Default gateway is 10.10.10.1',ok:p?.defaultRouter==='10.10.10.1'}); checks.push({label:'PC1 lease is BOUND',ok:b?.status==='BOUND'&&b.ip});
  } else if(caseId==='nat-edge'){
    checks.push({label:'R1 Gi0/0 is NAT inside',ok:s.devices.R1.protocol.nat.inside.includes('GigabitEthernet0/0')}); checks.push({label:'R1 Gi0/1 is NAT outside',ok:s.devices.R1.protocol.nat.outside.includes('GigabitEthernet0/1')}); checks.push({label:'Overload rule is active',ok:natHealthy(s)}); checks.push({label:'Translation can be created',ok:s.devices.R1.protocol.nat.translations.length>0});
  } else if(caseId==='stp-root'){
    for(const v of [10,20])checks.push({label:`SW1 is root for VLAN ${v}`,ok:rootSwitch(s,v)?.name==='SW1'});
    checks.push({label:'Rapid-PVST remains enabled',ok:s.devices.SW1.protocol.stpMode==='rapid-pvst'});
  } else if(caseId==='etherchannel-repair'){
    checks.push({label:'SW1 Port-channel 1 is formed',ok:s.devices.SW1.etherchannel.formed===true}); checks.push({label:'SW2 Port-channel 1 is formed',ok:s.devices.SW2.etherchannel.formed===true}); checks.push({label:'Gi0/22 participates on SW2',ok:s.devices.SW2.etherchannel.members['Gi0/22']===true});
  } else if(caseId==='ospf-timers'){
    checks.push({label:'R1 uses hello 10 / dead 40',ok:s.devices.R1.protocol.ospfTimers.hello===10&&s.devices.R1.protocol.ospfTimers.dead===40}); checks.push({label:'R2 uses hello 10 / dead 40',ok:s.devices.R2.protocol.ospfTimers.hello===10&&s.devices.R2.protocol.ospfTimers.dead===40}); checks.push({label:'OSPF adjacency is FULL',ok:ospfFullProtocol(s)});
  }
  const completed=checks.filter(x=>x.ok).length, score=Math.round(completed/checks.length*100);
  return {caseId,code:c.code,ok:completed===checks.length,score,completed,total:checks.length,checks,message:completed===checks.length?'All protocol objectives are satisfied.':'The protocol state is still incomplete.',hint:c.hint};
}

export function protocolSnapshot(state){const s=deriveProtocolState(state);return {dhcp:s.devices.R1.protocol.dhcp.bindings.PC1,nat:s.devices.R1.protocol.nat,stp:{VLAN10:rootSwitch(s,10)?.name,VLAN20:rootSwitch(s,20)?.name},etherchannel:{SW1:s.devices.SW1.etherchannel.formed,SW2:s.devices.SW2.etherchannel.formed},ospf:{R1:s.devices.R1.protocol.ospfAdjacency?'FULL':'DOWN',R2:s.devices.R2.protocol.ospfAdjacency?'FULL':'DOWN'}};}
