export const DEVICE_DIAGNOSTICS_VERSION = '1.0.0';

/**
 * @typedef {{
 *   id?: string, kind?: string, hostname?: string, name?: string, vendor?: string,
 *   platform?: string, version?: string
 * }} DiagnosticDevice
 * @typedef {{
 *   id?: string, capturedAt?: string, label?: string, source?: string,
 *   runningConfig?: string, startupConfig?: string, summary?: string
 * }} DiagnosticSnapshot
 * @typedef {{
 *   device?: DiagnosticDevice, inspection?: Record<string, any>|null,
 *   history?: DiagnosticSnapshot[], connected?: boolean
 * }} DeviceDiagnosticsInput
 */

const SEVERITY_WEIGHT = { critical: 30, warning: 15, info: 0 };

function configLines(value = '') {
  return String(value || '').split(/\r?\n/).map(line => line.trimEnd()).filter(Boolean);
}

export function configDiff(before = '', after = '') {
  const beforeLines = configLines(before);
  const afterLines = configLines(after);
  const beforeSet = new Set(beforeLines);
  const afterSet = new Set(afterLines);
  const removed = beforeLines.filter(line => !afterSet.has(line));
  const added = afterLines.filter(line => !beforeSet.has(line));
  return { added, removed, addedCount: added.length, removedCount: removed.length, changed: added.length > 0 || removed.length > 0 };
}

function check(id, label, status, detail, value = '') {
  return { id, label, status, detail, value };
}

/** @param {DeviceDiagnosticsInput} options */
export function buildDeviceDiagnostics({ device = {}, inspection = null, history = [], connected = false } = {}) {
  const report = inspection || {};
  const overview = report.overview || {};
  const interfaces = Array.isArray(report.interfaces) ? report.interfaces : [];
  const vlans = Array.isArray(report.vlans) ? report.vlans : [];
  const trunks = Array.isArray(report.trunks) ? report.trunks : [];
  const routes = Array.isArray(report.routes) ? report.routes : [];
  const signals = Array.isArray(report.signals) ? report.signals : [];
  const latest = history.at(-1);
  const previous = history.at(-2);
  const runningVsStartup = latest ? configDiff(latest.startupConfig || '', latest.runningConfig || '') : null;
  const recentChange = previous && latest ? configDiff(previous.runningConfig || '', latest.runningConfig || '') : null;

  const checks = [];
  checks.push(check(
    'connection',
    'Connection',
    connected ? 'good' : 'attention',
    connected ? 'The Device Agent currently has an active session.' : 'The device is not connected through the Device Agent.',
    connected ? 'connected' : 'offline',
  ));

  if (inspection) {
    const up = Number(overview.upInterfaceCount || 0);
    const total = Number(overview.interfaceCount || 0);
    const down = Math.max(0, total - up);
    checks.push(check(
      'interfaces',
      'Interface state',
      down === 0 ? 'good' : down === total && total > 0 ? 'warning' : 'attention',
      total ? `${up} of ${total} interfaces report up/up; ${down} are not fully operational.` : 'No interface rows were parsed.',
      `${up}/${total}`,
    ));

    if (device.kind === 'switch' || report.kind === 'switch') {
      checks.push(check(
        'vlans',
        'VLAN inventory',
        vlans.length ? 'good' : 'warning',
        vlans.length ? `${vlans.length} VLAN records were parsed from the device.` : 'No VLAN records were parsed; inspect the switch before assuming VLAN state is complete.',
        String(vlans.length),
      ));
      checks.push(check(
        'trunks',
        'Trunk visibility',
        trunks.length ? 'good' : 'attention',
        trunks.length ? `${trunks.length} active trunk record${trunks.length === 1 ? '' : 's'} were parsed.` : 'No active trunk records were parsed. This can be normal on an access switch.',
        String(trunks.length),
      ));
    }

    if (device.kind === 'router' || report.kind === 'router') {
      checks.push(check(
        'routing',
        'Routing table',
        routes.length ? 'good' : 'warning',
        routes.length ? `${routes.length} route records were parsed.` : 'No route records were parsed from the inspection output.',
        String(routes.length),
      ));
    }
  } else {
    checks.push(check('inspection', 'Inspection freshness', 'attention', 'Run an inspection to populate structured device state and diagnostics.'));
  }

  if (latest) {
    checks.push(check(
      'config-save',
      'Startup alignment',
      runningVsStartup?.changed ? 'warning' : 'good',
      runningVsStartup?.changed ? `${runningVsStartup.addedCount + runningVsStartup.removedCount} line-level differences exist between startup and running configuration.` : 'The latest captured running and startup configurations match.',
      runningVsStartup?.changed ? `${runningVsStartup.addedCount + runningVsStartup.removedCount} changes` : 'aligned',
    ));
  } else {
    checks.push(check('config-history', 'Configuration baseline', 'attention', 'No configuration snapshot exists yet. Capture a baseline before making operational changes.'));
  }

  const warningCount = checks.filter(item => item.status === 'warning').length;
  const attentionCount = checks.filter(item => item.status === 'attention').length;
  const penalty = checks.reduce((sum, item) => sum + (item.status === 'warning' ? SEVERITY_WEIGHT.warning : item.status === 'critical' ? SEVERITY_WEIGHT.critical : 0), 0);
  const score = Math.max(0, 100 - penalty);
  const status = warningCount ? (warningCount >= 2 ? 'attention' : 'degraded') : attentionCount ? 'observed' : 'healthy';

  const recentChanges = recentChange?.changed ? {
    from: previous?.id || '',
    to: latest?.id || '',
    added: recentChange.added,
    removed: recentChange.removed,
    addedCount: recentChange.addedCount,
    removedCount: recentChange.removedCount,
    summary: `${recentChange.addedCount} added · ${recentChange.removedCount} removed`,
  } : null;

  const actionableSignals = signals.filter(signal => signal.severity === 'warning' || signal.severity === 'critical');

  return {
    version: DEVICE_DIAGNOSTICS_VERSION,
    deviceId: device.id || report.deviceId || '',
    generatedAt: new Date().toISOString(),
    status,
    score,
    checks,
    warnings: warningCount,
    attention: attentionCount,
    actionableSignals,
    recentChanges,
    latestSnapshot: latest ? {
      id: latest.id,
      capturedAt: latest.capturedAt,
      label: latest.label,
      source: latest.source,
      runningStartupAligned: !runningVsStartup?.changed,
    } : null,
    historyCount: history.length,
  };
}
