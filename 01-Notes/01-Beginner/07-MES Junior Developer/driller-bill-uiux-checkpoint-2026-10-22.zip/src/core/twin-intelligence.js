import { getKnowledgeConnections } from '../knowledge/knowledge-graph.js';
import { KNOWLEDGE_ARTICLES } from '../knowledge/knowledge-base.js';
import { planIntent, CONFIG_INTENTS } from './device-model.js';
import { redactConfig } from './config-history.js';

export const TWIN_INTELLIGENCE_VERSION = '1.0.0';
export const TWIN_INTELLIGENCE_STORAGE_KEY = 'drillerBill.twin.intelligence.v55';
export const TWIN_MODES = ['investigate', 'explain', 'diagnose', 'plan', 'review', 'document'];

const STOP_WORDS = new Set(['the', 'a', 'an', 'and', 'or', 'to', 'of', 'for', 'on', 'in', 'is', 'are', 'with', 'why', 'what', 'how', 'can', 'i', 'we', 'me', 'my', 'this', 'that', 'it']);
const ACTION_HINTS = {
  'create vlan': 'create-vlan',
  'add vlan': 'create-vlan',
  'assign access vlan': 'assign-access-vlan',
  'access vlan': 'assign-access-vlan',
  'trunk vlan': 'set-trunk-vlans',
  'trunk policy': 'set-trunk-policy',
  'native vlan': 'set-trunk-policy',
  'enable interface': 'set-interface-state',
  'no shutdown': 'set-interface-state',
  'disable interface': 'set-interface-state',
  'shutdown interface': 'set-interface-state',
  'static route': 'add-static-route',
  'remove static route': 'remove-static-route',
  'interface description': 'set-interface-description',
  'save running config': 'save-running-config',
  'configure ospf process': 'configure-ospf-process',
  'ospf process': 'configure-ospf-process',
  'add ospf network': 'add-ospf-network',
  'ospf network': 'add-ospf-network',
  'ospf interface': 'configure-ospf-interface',
  'ospf passive': 'set-ospf-passive-interface',
  'access control list': 'add-standard-acl-rule',
  'standard acl': 'add-standard-acl-rule',
  'apply acl': 'apply-standard-acl',
  'port security': 'harden-access-port',
  'harden access port': 'harden-access-port',
  'stp mode': 'set-stp-mode',
  'stp priority': 'set-stp-vlan-priority',
  'etherchannel': 'configure-etherchannel',
  'nat overload': 'configure-nat-overload',
  'nat inside': 'set-interface-nat-role',
  'nat outside': 'set-interface-nat-role',
  'dhcp pool': 'create-dhcp-pool',
  'exclude dhcp': 'exclude-dhcp-address',
  'set hostname': 'set-hostname',
  'hostname': 'set-hostname',
  'configure ssh': 'configure-ssh',
  'vty ssh': 'configure-vty-ssh',
  'default gateway': 'set-default-gateway',
  'enable ipv6 routing': 'enable-ipv6-routing',
  'ipv6 static route': 'add-static-ipv6-route',
};

function normalize(text = '') {
  return String(text ?? '').toLowerCase().replace(/[^a-z0-9./:_-]+/g, ' ').replace(/\s+/g, ' ').trim();
}

function tokens(text = '') {
  return [...new Set(normalize(text).split(' ').filter(token => token.length > 1 && !STOP_WORDS.has(token)))];
}

function clamp(value, min = 0, max = 100) {
  return Math.min(max, Math.max(min, Math.round(value)));
}

function safe(value = '') {
  return redactConfig(String(value ?? '')).replace(/(enable\s+secret|password|passwd|secret|community|key-string)\s+\S+/gi, '$1 [redacted]');
}

function extractInterface(prompt = '') {
  const match = String(prompt).match(/\b(?:gi|gigabitethernet|fa|fastethernet|eth|ethernet)\s*\d+(?:\/\d+){1,2}\b/i);
  return match ? match[0] : '';
}

function extractVlan(prompt = '') {
  const match = String(prompt).match(/\bvlan\s*#?\s*(\d{1,4})\b/i);
  return match ? Number(match[1]) : null;
}

function extractNetwork(prompt = '') {
  const match = String(prompt).match(/\b(\d{1,3}(?:\.\d{1,3}){3}\/\d{1,2})\b/);
  return match ? match[1] : '';
}

function articleScore(article, queryTokens, rawQuery) {
  const title = normalize(article.title);
  const haystack = normalize([
    article.title, article.summary, article.category, article.level,
    ...(article.tags || []), ...(article.commands || []), ...(article.related || []),
    ...(article.sections || []).flat(),
  ].join(' '));
  let score = 0;
  for (const token of queryTokens) {
    if (title.includes(token)) score += 7;
    else if ((article.tags || []).some(tag => normalize(tag).includes(token))) score += 5;
    else if ((article.commands || []).some(command => normalize(command).includes(token))) score += 4;
    else if (haystack.includes(token)) score += 2;
  }
  if (normalize(rawQuery) === title) score += 12;
  return score;
}

export function retrieveTwinKnowledge(query = '', limit = 5) {
  const queryTokens = tokens(query);
  return KNOWLEDGE_ARTICLES
    .map(article => ({ article, score: articleScore(article, queryTokens, query) }))
    .filter(item => item.score > 0 || !queryTokens.length)
    .sort((a, b) => b.score - a.score || a.article.title.localeCompare(b.article.title))
    .slice(0, limit)
    .map(({ article, score }) => ({
      article,
      score,
      connections: getKnowledgeConnections(article.id),
    }));
}

export function inferTwinMode(prompt = '') {
  const text = normalize(prompt);
  if (/\b(explain|teach|meaning|difference|how does|what is|why does)\b/.test(text)) return 'explain';
  if (/\b(troubleshoot|diagnos|not working|broken|fail|failed|down|unreachable|cannot reach|can't reach|issue|problem)\b/.test(text)) return 'diagnose';
  if (/\b(review|audit|check|verify|inspect|safe|risk|correct)\b/.test(text)) return 'review';
  if (/\b(document|write|note|summarize|runbook|postmortem)\b/.test(text)) return 'document';
  if (/\b(configure|create|add|remove|delete|enable|disable|set|change|apply)\b/.test(text)) return 'plan';
  return 'investigate';
}

export function findTwinIntent(prompt = '') {
  const text = normalize(prompt);
  const ranked = Object.entries(ACTION_HINTS)
    .filter(([hint]) => text.includes(hint))
    .map(([hint, id]) => ({ hint, id, score: hint.length }));
  ranked.sort((a, b) => b.score - a.score);
  if (!ranked.length) return null;
  return CONFIG_INTENTS.find(intent => intent.id === ranked[0].id) || null;
}

function inspectContext(context = {}) {
  const inspection = context.inspection || {};
  const target = context.device || {};
  const requestedInterface = extractInterface(context.prompt);
  const requestedVlan = extractVlan(context.prompt);
  const requestedNetwork = extractNetwork(context.prompt);
  const interfaces = Array.isArray(inspection.interfaces) ? inspection.interfaces : [];
  const vlans = Array.isArray(inspection.vlans) ? inspection.vlans : [];
  const trunks = Array.isArray(inspection.trunks) ? inspection.trunks : [];
  const routes = Array.isArray(inspection.routes) ? inspection.routes : [];
  const iface = requestedInterface
    ? interfaces.find(item => normalize(item.name).replace('gigabitethernet', 'gi') === normalize(requestedInterface).replace('gigabitethernet', 'gi'))
    : null;
  const vlan = requestedVlan ? vlans.find(item => Number(item.id) === requestedVlan) : null;
  const route = requestedNetwork ? routes.find(item => normalize(item.network) === normalize(requestedNetwork)) : null;
  const trunk = requestedInterface ? trunks.find(item => normalize(item.interface).replace('gigabitethernet', 'gi') === normalize(requestedInterface).replace('gigabitethernet', 'gi')) : null;
  const findings = [];
  if (iface) findings.push({ label: 'Interface', value: `${iface.name} · ${iface.status}/${iface.protocol}`, severity: iface.status === 'up' && iface.protocol === 'up' ? 'good' : 'warning' });
  if (vlan) findings.push({ label: 'VLAN', value: `${vlan.id} · ${vlan.name} · ${vlan.status}`, severity: 'good' });
  else if (requestedVlan) findings.push({ label: 'VLAN', value: `VLAN ${requestedVlan} is not present in the observed inventory`, severity: 'warning' });
  if (trunk) {
    const carrying = requestedVlan ? (trunk.allowedVlans || []).includes(requestedVlan) : true;
    findings.push({ label: 'Trunk', value: `${trunk.interface} · allowed ${(trunk.allowedVlans || []).join(', ') || 'none'}`, severity: carrying ? 'good' : 'warning' });
  }
  if (requestedNetwork) findings.push({ label: 'Route', value: route ? `${route.network} via ${route.nextHop || 'unknown'}` : `${requestedNetwork} is not observed`, severity: route ? 'good' : 'warning' });
  const signals = Array.isArray(inspection.signals) ? inspection.signals : [];
  signals.slice(0, 5).forEach(signal => findings.push({ label: signal.label || 'Device signal', value: signal.message || signal.detail || '', severity: signal.severity || 'info' }));
  return { target, requestedInterface, requestedVlan, requestedNetwork, iface, vlan, route, trunk, findings };
}

export function buildTwinContext({ prompt = '', mode = inferTwinMode(prompt), device = null, inspection = null, diagnostics = null, history = [], twinHistory = [], topology = null, runbook = null, troubleshooting = null, session = null } = {}) {
  const knowledge = retrieveTwinKnowledge(prompt, 5);
  const deviceEvidence = inspectContext({ prompt, device, inspection });
  const latestHistory = Array.isArray(history) ? history.slice(-5).map(item => ({
    id: item.id,
    capturedAt: item.capturedAt,
    label: item.label,
    summary: item.summary,
    source: item.source,
    runningConfig: safe(item.runningConfig).slice(0, 12000),
    startupConfig: safe(item.startupConfig).slice(0, 12000),
  })) : [];
  return {
    version: TWIN_INTELLIGENCE_VERSION,
    mode,
    prompt: safe(prompt),
    device: device ? {
      id: device.id, name: device.name, hostname: device.hostname, kind: device.kind,
      vendor: device.vendor, platform: device.platform, version: device.version,
      capabilities: device.capabilities,
    } : null,
    inspection: inspection ? {
      inspectedAt: inspection.inspectedAt,
      source: inspection.source,
      overview: inspection.overview,
      findings: deviceEvidence.findings,
      interfaces: (inspection.interfaces || []).slice(0, 40),
      vlans: (inspection.vlans || []).slice(0, 40),
      trunks: (inspection.trunks || []).slice(0, 20),
      routes: (inspection.routes || []).slice(0, 40),
      ospf: inspection.ospf || null,
      acls: inspection.acls || {},
      nat: inspection.nat || null,
      dhcpPools: inspection.dhcpPools || {},
      dhcpExcluded: inspection.dhcpExcluded || [],
      etherchannels: inspection.etherchannels || {},
      stp: inspection.stp || {},
      ipv6: inspection.ipv6 || null,
      runningConfig: safe(inspection.runningConfig || '').slice(0, 16000),
    } : null,
    diagnostics: diagnostics ? {
      status: diagnostics.status,
      score: diagnostics.score,
      warnings: diagnostics.warnings,
      attention: diagnostics.attention,
      actionableSignals: (diagnostics.actionableSignals || []).slice(0, 8),
      recentChanges: diagnostics.recentChanges,
    } : null,
    history: latestHistory,
    twinHistory: Array.isArray(twinHistory) ? twinHistory.slice(-5).map(item => ({ id: item.id, createdAt: item.createdAt, mode: item.mode, prompt: safe(item.prompt), answer: safe(item.answer), confidence: item.confidence })) : [],
    topology: topology ? {
      id: topology.id,
      name: topology.name,
      nodeCount: topology.nodes?.length || 0,
      linkCount: topology.links?.length || 0,
    } : null,
    activeRunbook: runbook ? { id: runbook.id, title: runbook.title, currentStep: runbook.currentStep, stepCount: runbook.steps?.length || 0 } : null,
    troubleshooting: troubleshooting ? {
      caseId: troubleshooting.caseId,
      symptom: troubleshooting.symptom,
      topHypothesis: troubleshooting.topHypothesis,
      confidence: troubleshooting.confidence,
      nextTest: troubleshooting.nextTest,
    } : null,
    knowledge,
  };
}

function generalAnswer(mode, context, knowledge) {
  const deviceLabel = context.device?.id || 'the target device';
  const findings = context.inspection?.findings || [];
  const warning = findings.find(item => item.severity === 'warning');
  if (mode === 'explain') {
    const lead = knowledge[0]?.article;
    return lead
      ? `${lead.title} is the closest knowledge match. ${lead.summary} Start with the engineering workflow in that article, then use its verification commands to test the observed state.`
      : 'No strong knowledge match was found. Start from the device evidence and verify one layer at a time.';
  }
  if (mode === 'diagnose') {
    if (warning) return `${deviceLabel} has a relevant warning signal: ${warning.label} — ${warning.value}. Treat this as evidence, not a root cause; run the smallest targeted verification next.`;
    if (context.diagnostics?.status && context.diagnostics.status !== 'healthy') return `${deviceLabel} is currently ${context.diagnostics.status} with a diagnostic score of ${context.diagnostics.score}/100. Collect a fresh inspection before making configuration changes.`;
    return `I do not have enough device-specific evidence to name a root cause on ${deviceLabel}. Collect an inspection, then test the most specific failing signal.`;
  }
  if (mode === 'plan') return 'I can translate a known configuration request into a typed change plan, but the plan still needs the target device and complete fields before it is safe to apply.';
  if (mode === 'review') {
    const change = context.diagnostics?.recentChanges;
    return change ? `The latest configuration history contains ${change.addedCount} added and ${change.removedCount} removed lines. Review that diff against the intended change before applying anything else.` : 'No recent configuration diff is available. Capture a baseline so future changes can be reviewed rather than guessed.';
  }
  if (mode === 'document') return `Use the evidence and linked knowledge below to document what was observed on ${deviceLabel}, what was tested, and what remains unverified.`;
  return `The Twin has assembled ${knowledge.length} relevant knowledge matches and ${findings.length} observed device signals. Use the evidence first, then move to the most specific next action.`;
}

export function buildTwinProposal(prompt, device, mode = inferTwinMode(prompt)) {
  const intent = findTwinIntent(prompt);
  if (!intent) return { valid: false, mode, intent: null, errors: ['No supported typed intent was detected from this request.'], commands: [] };
  const fields = {};
  const lower = normalize(prompt);
  const vlan = extractVlan(prompt);
  const iface = extractInterface(prompt);
  const network = extractNetwork(prompt);
  if (intent.id === 'create-vlan') { fields.id = vlan; fields.name = (prompt.match(/(?:named|name(?:d)?|called)\s+([A-Za-z0-9_-]{1,32})/i)?.[1] || '').toUpperCase(); }
  if (intent.id === 'assign-access-vlan') { fields.interface = iface; fields.vlan = vlan; }
  if (intent.id === 'set-trunk-vlans') { fields.interface = iface; fields.vlans = (prompt.match(/(?:allow|allowed|vlan(?:s)?)(?:\s+vlan[s]?)?\s*([0-9, -]+)/i)?.[1] || '').replace(/ /g, ''); }
  if (intent.id === 'set-trunk-policy') { fields.interface = iface; fields.nativeVlan = vlan; fields.vlans = (prompt.match(/(?:allow|allowed)\s+(?:vlan[s]?\s*)?([0-9, -]+)/i)?.[1] || '').replace(/ /g, ''); }
  if (intent.id === 'set-interface-state') { fields.interface = iface; fields.state = /\b(?:disable|shutdown|down)\b/.test(lower) ? 'down' : 'up'; }
  if (intent.id === 'add-static-route' || intent.id === 'remove-static-route') {
    fields.network = network.split('/')[0] || '';
    fields.mask = network.includes('/') ? prefixToMask(Number(network.split('/')[1])) : '';
    fields.nextHop = (prompt.match(/(?:next[- ]?hop|via)\s+(\d{1,3}(?:\.\d{1,3}){3})/i)?.[1] || '');
  }
  if (intent.id === 'set-interface-description') { fields.interface = iface; fields.description = (prompt.match(/(?:description|describe)\s+["']?([^"']+?)["']?$/i)?.[1] || '').trim(); }
  if (intent.id === 'configure-ospf-process') { fields.process = Number(prompt.match(/(?:process|ospf)\s+(?:id\s+)?(\d{1,5})/i)?.[1] || ''); fields.routerId = prompt.match(/(?:router[ -]?id|router id)\s+(\d{1,3}(?:\.\d{1,3}){3})/i)?.[1] || ''; }
  if (intent.id === 'add-ospf-network') { fields.process = Number(prompt.match(/process\s+(\d{1,5})/i)?.[1] || ''); fields.network = network.split('/')[0] || ''; fields.wildcard = prompt.match(/wildcard\s+(\d{1,3}(?:\.\d{1,3}){3})/i)?.[1] || ''; fields.area = Number(prompt.match(/area\s+(\d+)/i)?.[1] || ''); }
  if (intent.id === 'configure-ospf-interface') { fields.interface = iface; fields.process = Number(prompt.match(/process\s+(\d{1,5})/i)?.[1] || ''); fields.area = Number(prompt.match(/area\s+(\d+)/i)?.[1] || ''); fields.hello = Number(prompt.match(/hello(?:-interval)?\s+(\d+)/i)?.[1] || 10); fields.dead = Number(prompt.match(/dead(?:-interval)?\s+(\d+)/i)?.[1] || 40); }
  if (intent.id === 'set-ospf-passive-interface') { fields.process = Number(prompt.match(/process\s+(\d{1,5})/i)?.[1] || ''); fields.interface = iface; }
  if (intent.id === 'add-standard-acl-rule') { fields.id = Number(prompt.match(/(?:acl|access-list)\s*(?:id\s*)?(\d{1,2})/i)?.[1] || ''); fields.action = /\bdeny\b/i.test(prompt) ? 'deny' : 'permit'; fields.source = prompt.match(/(?:source|from)\s+(\S+)/i)?.[1] || ''; fields.wildcard = prompt.match(/wildcard\s+(\S+)/i)?.[1] || ''; }
  if (intent.id === 'apply-standard-acl') { fields.id = Number(prompt.match(/(?:acl|access-list)\s*(?:id\s*)?(\d{1,2})/i)?.[1] || ''); fields.interface = iface; fields.direction = /\bout\b/i.test(lower) ? 'out' : 'in'; }
  if (intent.id === 'harden-access-port') { fields.interface = iface; fields.maximum = Number(prompt.match(/(?:maximum|max)\s+(\d+)/i)?.[1] || 1); }
  if (intent.id === 'set-stp-mode') { fields.mode = prompt.match(/\b(rapid-pvst|pvst|mst)\b/i)?.[1]?.toLowerCase() || ''; }
  if (intent.id === 'set-stp-vlan-priority') { fields.vlan = vlan; fields.priority = Number(prompt.match(/priority\s+(\d+)/i)?.[1] || ''); }
  if (intent.id === 'configure-etherchannel') { fields.interfaces = (prompt.match(/(?:interfaces?|ports?)\s+([A-Za-z0-9\/,-]+)/i)?.[1] || iface).replace(/\s+/g, ''); fields.group = Number(prompt.match(/(?:group|channel-group)\s+(\d+)/i)?.[1] || ''); fields.mode = prompt.match(/\b(active|passive|on)\b/i)?.[1]?.toLowerCase() || ''; }
  if (intent.id === 'set-interface-nat-role') { fields.interface = iface; fields.role = /\boutside\b/i.test(lower) ? 'outside' : 'inside'; }
  if (intent.id === 'configure-nat-overload') { fields.acl = Number(prompt.match(/(?:acl|access-list)\s*(?:id\s*)?(\d{1,2})/i)?.[1] || ''); fields.interface = iface; }
  if (intent.id === 'exclude-dhcp-address') { fields.start = prompt.match(/(?:exclude|excluded)[^0-9]*(\d{1,3}(?:\.\d{1,3}){3})/i)?.[1] || ''; fields.end = prompt.match(/(?:through|to|-)[^0-9]*(\d{1,3}(?:\.\d{1,3}){3})/i)?.[1] || ''; }
  if (intent.id === 'set-hostname') { fields.hostname = prompt.match(/(?:set )?hostname\s+([A-Za-z][A-Za-z0-9_-]*)/i)?.[1] || ''; }
  if (intent.id === 'configure-ssh') { fields.domain = prompt.match(/(?:domain|dns domain)\s+([A-Za-z0-9.-]+)/i)?.[1] || ''; }
  if (intent.id === 'set-default-gateway') { fields.gateway = prompt.match(/(?:gateway|via)\s+(\d{1,3}(?:\.\d{1,3}){3})/i)?.[1] || ''; }
  const plan = device ? planIntent({ type: intent.id, fields }, device) : null;
  return { valid: Boolean(plan?.valid), mode, intent, fields, plan, commands: plan?.commands || [], displayCommands: plan?.displayCommands || plan?.commands || [], errors: plan?.errors || (device ? [] : ['A target device is required before this proposal can be validated.']) };
}

function prefixToMask(prefix) {
  const length = Number(prefix);
  if (!Number.isInteger(length) || length < 0 || length > 32) return '';
  let value = length === 0 ? 0 : (0xffffffff << (32 - length)) >>> 0;
  return [24,16,8,0].map(shift => (value >>> shift) & 255).join('.');
}

function recommendationFor(mode, context, knowledge) {
  const recommendations = [];
  const warning = context.inspection?.findings?.find(item => item.severity === 'warning');
  if (warning) recommendations.push(`Verify ${warning.label.toLowerCase()} before changing configuration.`);
  if (knowledge[0]) recommendations.push(`Open ${knowledge[0].article.title} and use its verification workflow.`);
  if (mode === 'diagnose') recommendations.push('Record the observed evidence before applying a change, then verify the expected state transition.');
  if (mode === 'plan') recommendations.push('Review the typed intent and generated commands before applying them to a device.');
  if (mode === 'review') recommendations.push('Compare the latest snapshot with the previous baseline and confirm the change matches the intended task.');
  if (!recommendations.length) recommendations.push('Collect more specific evidence before escalating to configuration changes.');
  return [...new Set(recommendations)].slice(0, 4);
}

export function generateTwinResponse(context = {}) {
  const mode = context.mode || inferTwinMode(context.prompt);
  const knowledge = context.knowledge || retrieveTwinKnowledge(context.prompt, 5);
  const deviceContext = inspectContext(context);
  const proposal = mode === 'plan' ? buildTwinProposal(context.prompt, context.device, mode) : null;
  const answer = generalAnswer(mode, { ...context, inspection: context.inspection ? { ...context.inspection, findings: deviceContext.findings } : null }, knowledge);
  const evidence = deviceContext.findings.slice(0, 8);
  const recommendations = recommendationFor(mode, { ...context, inspection: context.inspection ? { ...context.inspection, findings: deviceContext.findings } : null }, knowledge);
  const confidence = clamp(30 + (knowledge.length ? 20 : 0) + (evidence.length ? 25 : 0) + (context.device ? 10 : 0) + (context.diagnostics ? 10 : 0));
  return {
    version: TWIN_INTELLIGENCE_VERSION,
    mode,
    answer,
    evidence,
    recommendations,
    confidence,
    proposal,
    knowledge,
    guardrails: [
      'Observations are evidence, not proof of root cause.',
      'Configuration proposals remain subject to the existing Preview → Apply → Verify workflow.',
      'Sensitive-looking configuration values are redacted before model-context export.',
    ],
  };
}

export function buildModelContext(responseOrContext = {}) {
  const context = responseOrContext.prompt ? responseOrContext : responseOrContext.context || {};
  return JSON.stringify({
    purpose: 'Driller Bill Twin engineering context. Use only as a reasoning aid; do not treat missing values as facts.',
    rules: ['Do not invent device state.', 'Do not expose credentials.', 'Return proposed configuration as structured intent when possible.', 'Human approval remains required for device changes.'],
    context: buildTwinContext(context),
  }, null, 2);
}

export function loadTwinHistory(storage) {
  try {
    const raw = storage?.getItem(TWIN_INTELLIGENCE_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.slice(-25) : [];
  } catch { return []; }
}

export function saveTwinHistory(storage, history = [], record = {}) {
  const normalized = {
    id: record.id || `twin-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    createdAt: record.createdAt || new Date().toISOString(),
    mode: record.mode || 'investigate',
    prompt: safe(record.prompt || ''),
    answer: safe(record.answer || ''),
    confidence: Number(record.confidence || 0),
    knowledge: (record.knowledge || []).slice(0, 5).map(item => item.article?.id || item.id).filter(Boolean),
  };
  const next = [...history, normalized].slice(-25);
  storage?.setItem(TWIN_INTELLIGENCE_STORAGE_KEY, JSON.stringify(next));
  return next;
}
