import { safeStorage } from '../storage.js';
const STORAGE_KEY = 'pf_topology_v10';

let sequence = 0;
const nextId = (prefix='n') => `${prefix}-${Date.now().toString(36)}-${(++sequence).toString(36)}`;

export const DEVICE_TYPES = {
  router: { label: 'Router', code: 'R', ports: 8, accent: 'router' },
  switch: { label: 'Switch', code: 'SW', ports: 48, accent: 'switch' },
  host: { label: 'Host', code: 'PC', ports: 1, accent: 'host' },
  server: { label: 'Server', code: 'SRV', ports: 2, accent: 'server' },
  wireless: { label: 'Wireless AP', code: 'AP', ports: 2, accent: 'wireless' },
};

const portName = (type, idx) => {
  if (type === 'router') return `Gi0/${idx}`;
  if (type === 'switch') return `Gi0/${idx}`;
  if (type === 'wireless') return idx === 0 ? 'Gi0/0' : 'Gi0/1';
  if (type === 'server') return idx === 0 ? 'eth0' : 'eth1';
  return 'eth0';
};

export const makePorts = (type) => Array.from({ length: DEVICE_TYPES[type].ports }, (_, i) => ({
  id: `${portName(type, i)}`,
  label: portName(type, i),
  state: 'up',
  vlan: type === 'switch' ? 1 : undefined,
}));

const device = (type, name, x, y, options={}) => ({
  id: nextId('d'), type, name,
  x, y,
  enabled: true,
  notes: '',
  ip: options.ip || '',
  ports: makePorts(type),
});

// Rebuild demo with stable endpoint IDs; kept separate so this file is easy to extend.
export const demoTopology = () => {
  const devices = [
    device('router', 'R1', 230, 135, { ip: '10.10.10.1' }),
    device('switch', 'SW1', 470, 135),
    device('switch', 'SW2', 730, 135),
    device('router', 'R2', 730, 355, { ip: '10.0.12.2' }),
    device('host', 'PC1', 250, 370, { ip: '10.10.10.10' }),
    device('host', 'PC2', 500, 370, { ip: '10.20.20.20' }),
    device('server', 'SRV1', 760, 535, { ip: '10.20.20.10' }),
  ];
  const byName = Object.fromEntries(devices.map(d => [d.name, d]));
  const links = [
    { a: byName.R1, b: byName.SW1, ai: 'Gi0/0', bi: 'Gi0/10', kind: 'copper' },
    { a: byName.SW1, b: byName.SW2, ai: 'Gi0/24', bi: 'Gi0/24', kind: 'trunk' },
    { a: byName.R1, b: byName.R2, ai: 'Gi0/1', bi: 'Gi0/0', kind: 'copper' },
    { a: byName.R2, b: byName.SW2, ai: 'Gi0/1', bi: 'Gi0/23', kind: 'copper' },
    { a: byName.SW1, b: byName.PC1, ai: 'Gi0/1', bi: 'eth0', kind: 'access' },
    { a: byName.SW1, b: byName.PC2, ai: 'Gi0/5', bi: 'eth0', kind: 'access' },
    { a: byName.SW2, b: byName.SRV1, ai: 'Gi0/5', bi: 'eth0', kind: 'access' },
  ].map(l => ({ ...l, id: nextId('l'), a: l.a.id, b: l.b.id, state: 'up' }));
  return { id: nextId('topo'), name: 'Branch Core / Access Lab', updatedAt: Date.now(), devices, links };
};

export const DEMO_TOPOLOGY = demoTopology;

export const cloneTopology = topo => JSON.parse(JSON.stringify(topo));

export function addDevice(topology, type='switch') {
  const count = topology.devices.filter(d => d.type === type).length + 1;
  const code = DEVICE_TYPES[type].code;
  const angle = (topology.devices.length * 0.85) % (Math.PI * 2);
  const x = Math.round(500 + Math.cos(angle) * 190);
  const y = Math.round(300 + Math.sin(angle) * 170);
  const next = device(type, `${code}${count}`, Math.max(85, Math.min(915, x)), Math.max(75, Math.min(565, y)));
  return { ...topology, updatedAt: Date.now(), devices: [...topology.devices, next] };
}

export function updateDevice(topology, deviceId, patch) {
  return { ...topology, updatedAt: Date.now(), devices: topology.devices.map(d => d.id === deviceId ? { ...d, ...patch } : d) };
}

export function removeDevice(topology, deviceId) {
  return {
    ...topology,
    updatedAt: Date.now(),
    devices: topology.devices.filter(d => d.id !== deviceId),
    links: topology.links.filter(l => l.a !== deviceId && l.b !== deviceId),
  };
}

export function addLink(topology, a, b, kind='copper') {
  if (!a || !b || a === b) return topology;
  if (topology.links.some(l => (l.a === a && l.b === b) || (l.a === b && l.b === a))) return topology;
  const da = topology.devices.find(d => d.id === a);
  const db = topology.devices.find(d => d.id === b);
  if (!da || !db) return topology;
  const usedFor = (deviceId) => {
    const used = new Set();
    topology.links.forEach(l => {
      if (l.a === deviceId) used.add(l.ai);
      if (l.b === deviceId) used.add(l.bi);
    });
    return used;
  };
  const usedA = usedFor(a);
  const usedB = usedFor(b);
  const firstFree = (d, used) => d.ports.find(p => !used.has(p.id))?.id || d.ports[0]?.id || '';
  const ai = firstFree(da, usedA);
  const bi = firstFree(db, usedB);
  return { ...topology, updatedAt: Date.now(), links: [...topology.links, { id: nextId('l'), a, b, ai, bi, kind, state: 'up' }] };
}

export function updateLink(topology, linkId, patch) {
  return { ...topology, updatedAt: Date.now(), links: topology.links.map(l => l.id === linkId ? { ...l, ...patch } : l) };
}

export function removeLink(topology, linkId) {
  return { ...topology, updatedAt: Date.now(), links: topology.links.filter(l => l.id !== linkId) };
}

export function isLinkHealthy(topology, link) {
  const a = topology.devices.find(d => d.id === link.a);
  const b = topology.devices.find(d => d.id === link.b);
  if (!a || !b || !a.enabled || !b.enabled || link.state === 'down') return false;
  const ai = a.ports.find(p => p.id === link.ai);
  const bi = b.ports.find(p => p.id === link.bi);
  return (ai?.runtimeState ?? ai?.state) !== 'down' && (bi?.runtimeState ?? bi?.state) !== 'down' && a.runtimeEnabled !== false && b.runtimeEnabled !== false;
}

export function topologyStats(topology) {
  const healthy = topology.links.filter(l => isLinkHealthy(topology, l)).length;
  const hosts = topology.devices.filter(d => ['host', 'server'].includes(d.type)).length;
  return {
    devices: topology.devices.length,
    links: topology.links.length,
    healthy,
    degraded: topology.links.length - healthy,
    hosts,
  };
}

export function findPath(topology, sourceId, targetId) {
  if (!sourceId || !targetId || sourceId === targetId) return sourceId ? [sourceId] : [];
  const q = [sourceId];
  const prev = new Map([[sourceId, null]]);
  while (q.length) {
    const current = q.shift();
    const edges = topology.links.filter(l => isLinkHealthy(topology, l) && (l.a === current || l.b === current));
    for (const edge of edges) {
      const next = edge.a === current ? edge.b : edge.a;
      if (prev.has(next)) continue;
      prev.set(next, current);
      q.push(next);
      if (next === targetId) {
        const path = [];
        let n = targetId;
        while (n !== null) { path.unshift(n); n = prev.get(n); }
        return path;
      }
    }
  }
  return [];
}

export function validateTopology(topology) {
  const issues = [];
  const names = new Set();
  topology.devices.forEach(d => {
    if (!d.name.trim()) issues.push({ severity: 'error', message: `Device ${d.id} has no name.` });
    if (names.has(d.name.trim().toLowerCase())) issues.push({ severity: 'error', message: `Duplicate device name: ${d.name}` });
    names.add(d.name.trim().toLowerCase());
  });
  topology.links.forEach(l => {
    const a = topology.devices.find(d => d.id === l.a);
    const b = topology.devices.find(d => d.id === l.b);
    if (!a || !b) issues.push({ severity: 'error', message: `Link ${l.id} references a missing device.` });
    if (a && b && l.a === l.b) issues.push({ severity: 'error', message: `${a.name} has a self-link.` });
  });
  const usedPorts = new Map();
  topology.links.forEach(l => {
    [[l.a,l.ai],[l.b,l.bi]].forEach(([d,p]) => {
      const key = `${d}:${p}`;
      if (usedPorts.has(key)) issues.push({ severity: 'warning', message: `${deviceName(topology,d)} ${p} is used by multiple links.` });
      usedPorts.set(key, true);
    });
  });
  if (!topology.devices.length) issues.push({ severity: 'warning', message: 'Topology has no devices.' });
  if (topology.devices.length && topology.links.length === 0) issues.push({ severity: 'warning', message: 'Topology has no links.' });
  return { valid: !issues.some(x => x.severity === 'error'), issues };
}

const deviceName = (topology,id) => topology.devices.find(d => d.id === id)?.name || id;

export function exportTopology(topology) {
  return JSON.stringify({ schema: 'penny-farthing-topology', version: 1, exportedAt: new Date().toISOString(), topology }, null, 2);
}

export function importTopology(text) {
  const parsed = JSON.parse(text);
  if (!parsed || parsed.schema !== 'penny-farthing-topology' || !parsed.topology) throw new Error('Not a Driller Bill topology export.');
  return parsed.topology;
}

export function saveTopology(topology) {
  safeStorage.setItem(STORAGE_KEY, JSON.stringify(topology));
}

export function loadTopology() {
  try {
    const raw = safeStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : demoTopology();
  } catch {
    return demoTopology();
  }
}
