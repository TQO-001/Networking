import { DEVICE_TYPES, makePorts } from './topology-engine.js';

export const NETWORK_DISCOVERY_VERSION = '1.0.0';
export const DISCOVERY_COMMANDS = ['show cdp neighbors', 'show lldp neighbors'];

const clone = value => structuredClone(value);

function cleanLine(value = '') {
  return String(value).replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, '').replace(/\r/g, '').trimEnd();
}

function lines(value = '') {
  return String(value).split('\n').map(cleanLine).filter(line => line.trim());
}

function normalizePort(value = '') {
  return String(value).replace(/^Gig(?:abitEthernet)?\s*/i, 'Gi').replace(/^FastEthernet\s*/i, 'Fa').replace(/^TenGigabitEthernet\s*/i, 'Te').replace(/\s+/g, '').trim();
}

function looksLikeHold(value = '') { return /^\d{1,3}$/.test(String(value)); }

function parseSummaryTokens(line = '') {
  const tokens = line.trim().split(/\s+/).filter(Boolean);
  if (tokens.length < 5) return null;
  const holdIndex = tokens.findIndex((token, index) => index > 0 && looksLikeHold(token));
  if (holdIndex < 2 || holdIndex >= tokens.length - 2) return null;
  const deviceId = tokens[0];
  const localRaw = tokens.slice(1, holdIndex);
  if (!localRaw.length) return null;
  const localInterface = normalizePort(localRaw.join(' '));
  const holdTime = Number(tokens[holdIndex]);
  const capability = tokens.slice(holdIndex + 1, -2).join(' ');
  const platform = tokens.at(-2) || '';
  const remotePort = normalizePort(tokens.at(-1) || '');
  if (!deviceId || !localInterface || !remotePort) return null;
  return { deviceId, localInterface, holdTime, capability, platform, remotePort };
}

export function parseCdpNeighbors(text = '') {
  const rows = [];
  for (const line of lines(text)) {
    if (/^Device ID\s+Local Intrfce/i.test(line) || /^\s*-{3,}/.test(line)) continue;
    const row = parseSummaryTokens(line);
    if (!row) continue;
    rows.push({
      protocol: 'cdp',
      remoteName: row.deviceId,
      localInterface: row.localInterface,
      remoteInterface: row.remotePort,
      holdTime: row.holdTime,
      capability: row.capability,
      platform: row.platform,
    });
  }
  return rows;
}

export function parseLldpNeighbors(text = '') {
  const rows = [];
  for (const line of lines(text)) {
    if (/^Device ID\s+Local Intf/i.test(line) || /^\s*-{3,}/.test(line)) continue;
    const tokens = line.trim().split(/\s+/).filter(Boolean);
    if (tokens.length < 5) continue;
    const holdIndex = tokens.findIndex((token, index) => index > 0 && looksLikeHold(token));
    if (holdIndex < 2 || holdIndex >= tokens.length - 1) continue;
    const remoteName = tokens[0];
    const localInterface = normalizePort(tokens.slice(1, holdIndex).join(' '));
    const holdTime = Number(tokens[holdIndex]);
    const remoteInterface = normalizePort(tokens.at(-1));
    const capability = tokens.slice(holdIndex + 1, -1).join(' ');
    if (!remoteName || !localInterface || !remoteInterface) continue;
    rows.push({ protocol:'lldp', remoteName, localInterface, remoteInterface, holdTime, capability, platform:'' });
  }
  return rows;
}

function observationKey(item) {
  return [String(item.localDeviceId || '').toLowerCase(), String(item.localInterface || '').toLowerCase(), String(item.remoteName || '').toLowerCase(), String(item.remoteInterface || '').toLowerCase()].join('|');
}

export function mergeNeighborObservations(cdp = [], lldp = []) {
  const merged = new Map();
  for (const item of [...lldp, ...cdp]) {
    const key = observationKey(item);
    const previous = merged.get(key);
    // Prefer CDP when both mechanisms observe exactly the same edge.
    if (!previous || item.protocol === 'cdp') merged.set(key, clone(item));
  }
  return [...merged.values()].sort((a, b) => `${a.localDeviceId}:${a.localInterface}:${a.remoteName}`.localeCompare(`${b.localDeviceId}:${b.localInterface}:${b.remoteName}`));
}

/** @param {{device?: Record<string, any>, outputs?: Record<string, string>, source?: string}} options */
export function buildNetworkDiscoveryReport({ device = {}, outputs = {}, source = 'device-agent' } = {}) {
  const cdp = parseCdpNeighbors(outputs['show cdp neighbors'] || '').map(item => ({ ...item, localDeviceId: device.id || '' }));
  const lldp = parseLldpNeighbors(outputs['show lldp neighbors'] || '').map(item => ({ ...item, localDeviceId: device.id || '' }));
  const observations = mergeNeighborObservations(cdp, lldp);
  return {
    version: NETWORK_DISCOVERY_VERSION,
    deviceId: device.id || '',
    deviceName: device.name || device.hostname || device.id || 'unknown',
    inspectedAt: new Date().toISOString(),
    source,
    commands: [...DISCOVERY_COMMANDS],
    counts: { cdp: cdp.length, lldp: lldp.length, unique: observations.length },
    observations,
    signals: [
      ...(cdp.length && lldp.length ? [] : [{ severity: 'info', type: 'protocol-coverage', message: 'Only one neighbor discovery protocol returned usable rows.', evidence: [cdp.length ? 'CDP' : '', lldp.length ? 'LLDP' : ''].filter(Boolean) }]),
      ...(!observations.length ? [{ severity: 'warning', type: 'no-neighbors', message: 'No CDP or LLDP neighbors were discovered from this device.', evidence: [] }] : []),
    ],
    raw: { commands: Object.keys(outputs), outputs },
  };
}

function typeFromObservation(item, inventory = []) {
  const known = inventory.find(device => device.id === item.remoteName || device.name === item.remoteName || device.hostname === item.remoteName);
  if (known) return known.kind === 'router' ? 'router' : known.kind === 'switch' ? 'switch' : 'switch';
  const capability = String(item.capability || '').toUpperCase();
  if (/(R|ROUTER)/.test(capability) && !/(S|SWITCH)/.test(capability)) return 'router';
  if (/ROUTER/.test(item.platform || '') || /ROUTER/i.test(item.capability || '')) return 'router';
  return 'switch';
}

function topologyDeviceFor(topology, candidate = {}) {
  const key = String(candidate.name || '').toLowerCase();
  return topology.devices.find(device => [device.name, device.hostname, device.ip].filter(Boolean).some(value => String(value).toLowerCase() === key)) || null;
}

function endpointPair(edge, a, b) {
  return (edge.a === a && edge.b === b) || (edge.a === b && edge.b === a);
}

function linksMatch(edge, aId, aPort, bId, bPort) {
  return (edge.a === aId && normalizePort(edge.ai) === normalizePort(aPort) && edge.b === bId && normalizePort(edge.bi) === normalizePort(bPort))
    || (edge.a === bId && normalizePort(edge.ai) === normalizePort(bPort) && edge.b === aId && normalizePort(edge.bi) === normalizePort(aPort));
}

function nextNodePosition(index) {
  const col = index % 4;
  const row = Math.floor(index / 4);
  return { x: 130 + col * 230, y: 120 + row * 170 };
}

function ensureTopologyNode(topology, identity, { type = 'switch', ip = '', discovered = false } = {}) {
  let existing = topologyDeviceFor(topology, { name: identity });
  if (existing) return { device: existing, created: false };
  const pos = nextNodePosition(topology.devices.length);
  const node = {
    id: `disc-${String(identity).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'device'}`,
    type: DEVICE_TYPES[type] ? type : 'switch',
    name: identity,
    x: pos.x,
    y: pos.y,
    enabled: true,
    notes: discovered ? 'Discovered by Driller Bill network discovery.' : '',
    ip,
    ports: makePorts(DEVICE_TYPES[type] ? type : 'switch'),
    discovered: Boolean(discovered),
    discoveredAt: new Date().toISOString(),
  };
  topology.devices.push(node);
  return { device: node, created: true };
}

function normalizeInventoryMap(inventory = []) {
  const map = new Map();
  for (const device of inventory) {
    for (const key of [device.id, device.name, device.hostname].filter(Boolean)) map.set(String(key).toLowerCase(), device);
  }
  return map;
}

/** @param {Array<Record<string, any>>} reports @param {Array<Record<string, any>>} inventory */
export function buildDiscoveryGraph(reports = [], inventory = []) {
  const deviceMap = normalizeInventoryMap(inventory);
  const nodes = new Map();
  const edges = new Map();
  for (const report of reports) {
    const localInventory = deviceMap.get(String(report.deviceId || report.deviceName).toLowerCase());
    const local = { id: report.deviceId || report.deviceName, name: report.deviceName || report.deviceId, kind: localInventory?.kind || 'switch', known: Boolean(localInventory) };
    nodes.set(local.id, { ...nodes.get(local.id), ...local });
    for (const obs of report.observations || []) {
      const remoteInventory = deviceMap.get(String(obs.remoteName).toLowerCase());
      const remoteId = remoteInventory?.id || obs.remoteName;
      nodes.set(remoteId, { id: remoteId, name: remoteInventory?.name || obs.remoteName, kind: remoteInventory?.kind || typeFromObservation(obs, inventory), known: Boolean(remoteInventory) });
      const endpointA = String(local.id);
      const endpointB = String(remoteId);
      const edgeParts = [
        `${endpointA.toLowerCase()}::${normalizePort(obs.localInterface).toLowerCase()}`,
        `${endpointB.toLowerCase()}::${normalizePort(obs.remoteInterface).toLowerCase()}`,
      ].sort();
      const edgeKey = edgeParts.join('|');
      const existing = edges.get(edgeKey);
      if (!existing) edges.set(edgeKey, {
        id: `disc-link-${edgeKey.replace(/[^a-z0-9|]/gi, '-')}`,
        a: local.id,
        b: remoteId,
        ai: obs.localInterface,
        bi: obs.remoteInterface,
        protocol: obs.protocol,
        evidence: [report.deviceId],
        observations: [obs],
      });
      else {
        existing.protocols = [...new Set([...(existing.protocols || [existing.protocol]), obs.protocol])];
        existing.evidence = [...new Set([...(existing.evidence || []), report.deviceId])];
        existing.observations.push(obs);
      }
    }
  }
  return { nodes: [...nodes.values()], edges: [...edges.values()] };
}

/** @param {Record<string, any>} topologyInput @param {Record<string, any>} discoveryRun @param {{inventory?: Array<Record<string, any>>}} options */
export function reconcileDiscoveryTopology(topologyInput, discoveryRun = {}, { inventory = [] } = {}) {
  const topology = clone(topologyInput);
  const graph = discoveryRun.graph || buildDiscoveryGraph(discoveryRun.reports || [], inventory);
  const changes = { addedDevices: [], addedLinks: [], confirmedLinks: [], drift: [] };
  const idByName = new Map(topology.devices.flatMap(device => [device.name, device.hostname, device.ip].filter(Boolean).map(key => [String(key).toLowerCase(), device])).map(([k,v]) => [k,v]));
  const ensure = node => {
    const known = idByName.get(String(node.name).toLowerCase()) || idByName.get(String(node.id).toLowerCase());
    if (known) return known;
    const created = ensureTopologyNode(topology, node.name || node.id, { type: node.kind === 'router' ? 'router' : 'switch', discovered: true }).device;
    created.discoveryId = node.id;
    idByName.set(String(node.name).toLowerCase(), created);
    idByName.set(String(node.id).toLowerCase(), created);
    changes.addedDevices.push(created.name);
    return created;
  };
  const discoveredEdgeKeys = new Set();
  for (const edge of graph.edges) {
    const aNode = ensure(graph.nodes.find(node => node.id === edge.a) || { id: edge.a, name: edge.a, kind: 'switch' });
    const bNode = ensure(graph.nodes.find(node => node.id === edge.b) || { id: edge.b, name: edge.b, kind: 'switch' });
    const existing = topology.links.find(link => linksMatch(link, aNode.id, edge.ai, bNode.id, edge.bi) || endpointPair(link, aNode.id, bNode.id) && ((normalizePort(link.ai) === normalizePort(edge.ai) && normalizePort(link.bi) === normalizePort(edge.bi)) || (normalizePort(link.ai) === normalizePort(edge.bi) && normalizePort(link.bi) === normalizePort(edge.ai))));
    if (existing) {
      existing.discovery = { ...(existing.discovery || {}), confirmedAt: new Date().toISOString(), protocol: edge.protocol, evidence: edge.evidence };
      changes.confirmedLinks.push(existing.id);
    } else {
      const linkId = edge.id || `disc-link-${topology.links.length + 1}`;
      const link = { id: linkId, a: aNode.id, b: bNode.id, ai: edge.ai, bi: edge.bi, kind: 'copper', state: 'up', discovered: true, discovery: { discoveredAt: new Date().toISOString(), protocol: edge.protocol, evidence: edge.evidence } };
      topology.links.push(link);
      changes.addedLinks.push(link.id);
    }
    discoveredEdgeKeys.add(`${aNode.id}|${bNode.id}`.split('|').sort().join('|'));
  }

  const discoveredDeviceIds = new Set(graph.nodes.map(node => idByName.get(String(node.name).toLowerCase())?.id || node.id));
  for (const link of topology.links) {
    if (!discoveredDeviceIds.has(link.a) || !discoveredDeviceIds.has(link.b)) continue;
    const key = [link.a, link.b].sort().join('|');
    if (link.discovered && !discoveredEdgeKeys.has(key)) changes.drift.push({ type: 'discovered-link-missing', linkId: link.id, message: `Previously discovered link ${link.id} was not observed this run.` });
  }

  topology.discovery = {
    ...(topology.discovery || {}),
    version: NETWORK_DISCOVERY_VERSION,
    lastRunAt: new Date().toISOString(),
    discoveredNodes: graph.nodes.length,
    discoveredEdges: graph.edges.length,
    lastStatus: 'merged',
    driftCount: changes.drift.length,
  };
  topology.updatedAt = Date.now();
  return { topology, graph, changes };
}

export function summarizeDiscoveryRun(run = {}) {
  const reports = run.reports || [];
  const graph = run.graph || buildDiscoveryGraph(reports, run.inventory || []);
  const newLinks = run.changes?.addedLinks?.length || 0;
  const newDevices = run.changes?.addedDevices?.length || 0;
  return `${graph.nodes.length} discovered devices, ${graph.edges.length} observed links, ${newDevices} new devices, ${newLinks} new links${run.changes?.drift?.length ? `, ${run.changes.drift.length} drift item${run.changes.drift.length === 1 ? '' : 's'}` : ''}.`;
}
