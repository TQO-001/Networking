import { safeStorage } from '../storage.js';
import { conceptName, getCorrect } from './exam-engine.js';

export const MASTERY_STORAGE = 'pennyFarthingMasteryV14';
const DAY = 86400000;

const clamp = (n, min, max) => Math.max(min, Math.min(max, n));

export function readMastery() {
  try {
    return JSON.parse(safeStorage.getItem(MASTERY_STORAGE) || '{}');
  } catch {
    return {};
  }
}

export function writeMastery(value) {
  try { safeStorage.setItem(MASTERY_STORAGE, JSON.stringify(value)); return true; } catch { return false; }
}

export function emptyCard(question) {
  return {
    key: question.id,
    topic: question.topic,
    concept: question.concept || conceptName(question.topic),
    interval: 0,
    ease: 2.5,
    repetitions: 0,
    lapses: 0,
    streak: 0,
    dueAt: Date.now(),
    lastReviewedAt: null,
    lastGrade: null,
    totalReviews: 0,
    question: {
      questionId: question.questionId || question.id,
      q: question.q || question.prompt || '',
      options: question.options || [],
      answer: question.answer || [],
      explanation: question.explanation || '',
      type: question.type || 'single',
      difficulty: question.difficulty || 'foundation',
      presentation: question.presentation || 'standard',
      domain: question.domain,
      topic: question.topic,
    },
  };
}

export function gradeLabel(grade) {
  return ({ again: 'Again', hard: 'Hard', good: 'Good', easy: 'Easy' })[grade] || grade;
}

export function scheduleCard(card, grade, now = Date.now()) {
  const next = { ...card, totalReviews: (card.totalReviews || 0) + 1, lastReviewedAt: now, lastGrade: grade };
  const ease = clamp(next.ease || 2.5, 1.3, 3.2);
  if (grade === 'again') {
    next.lapses = (next.lapses || 0) + 1;
    next.repetitions = 0;
    next.streak = 0;
    next.interval = 0;
    next.ease = clamp(ease - 0.2, 1.3, 3.2);
    next.dueAt = now + 10 * 60 * 1000;
    return next;
  }
  if (grade === 'hard') {
    next.ease = clamp(ease - 0.15, 1.3, 3.2);
    next.repetitions = (next.repetitions || 0) + 1;
    next.streak = Math.max(0, next.streak || 0) + 1;
    next.interval = next.interval ? Math.max(1, Math.round(next.interval * 1.2)) : 1;
    next.dueAt = now + next.interval * DAY;
    return next;
  }
  if (grade === 'good') {
    next.ease = clamp(ease, 1.3, 3.2);
    next.repetitions = (next.repetitions || 0) + 1;
    next.streak = Math.max(0, next.streak || 0) + 1;
    const base = next.interval || (next.repetitions === 1 ? 1 : next.repetitions === 2 ? 3 : 7);
    next.interval = Math.max(1, Math.round(base * next.ease));
    next.dueAt = now + next.interval * DAY;
    return next;
  }
  next.ease = clamp(ease + 0.1, 1.3, 3.2);
  next.repetitions = (next.repetitions || 0) + 1;
  next.streak = Math.max(0, next.streak || 0) + 1;
  const base = next.interval || (next.repetitions === 1 ? 2 : next.repetitions === 2 ? 5 : 10);
  next.interval = Math.max(2, Math.round(base * next.ease * 1.15));
  next.dueAt = now + next.interval * DAY;
  return next;
}

export function syncMasteryWithHistory(history, questionsById = {}) {
  const current = readMastery();
  let changed = false;
  for (const attempt of history) {
    const stamp = attempt.date ? new Date(attempt.date).getTime() : Date.now();
    for (const q of attempt.questions || []) {
      const key = q.id;
      if (!key || current[key]?.lastSeenAttemptId === attempt.id) continue;
      if (!current[key]) current[key] = emptyCard({ ...q, concept: q.concept || conceptName(q.topic) });
      const correct = getCorrect(q, attempt.answers?.[q.questionId] || []);
      const grade = correct ? 'good' : 'again';
      const seed = scheduleCard(current[key], grade, stamp);
      current[key] = { ...seed, lastSeenAttemptId: attempt.id };
      changed = true;
    }
  }
  if (changed) writeMastery(current);
  return current;
}

export function dueCards(mastery, now = Date.now()) {
  return Object.values(mastery).filter(card => (card.dueAt || 0) <= now).sort((a,b) => (a.dueAt || 0) - (b.dueAt || 0));
}

export function masteryStats(mastery, now = Date.now()) {
  const cards = Object.values(mastery);
  const due = cards.filter(c => (c.dueAt || 0) <= now).length;
  const mastered = cards.filter(c => (c.streak || 0) >= 4 && (c.interval || 0) >= 14).length;
  const learning = cards.filter(c => (c.streak || 0) > 0 && !((c.streak || 0) >= 4 && (c.interval || 0) >= 14)).length;
  const dormant = cards.filter(c => (c.totalReviews || 0) === 0).length;
  const avgEase = cards.length ? Math.round(cards.reduce((s,c)=>s+(c.ease||2.5),0) / cards.length * 100) / 100 : 0;
  return { total: cards.length, due, mastered, learning, dormant, avgEase };
}

export function upsertFromQuestions(mastery, questions) {
  const next = { ...mastery };
  for (const q of questions || []) {
    if (!q?.id || next[q.id]) continue;
    next[q.id] = emptyCard(q);
  }
  return next;
}
