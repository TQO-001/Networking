import { safeStorage } from '../storage.js';
import { STORAGE, AUTHORING_STORAGE } from './exam-engine.js';
import { MASTERY_STORAGE } from './mastery-engine.js';
import { LIVE_LAB_STORAGE } from './live-network-engine.js';

export const DATA_BACKUP_SCHEMA = 'penny-farthing-study-backup';
export const DATA_BACKUP_VERSION = 1;
export const APP_DATA_VERSION = '64.0.6';

const TOPOLOGY_STORAGE = 'pf_topology_v10';

export const MANAGED_KEYS = Object.freeze({
  history: STORAGE.history,
  seen: STORAGE.seen,
  session: STORAGE.session,
  settings: STORAGE.settings,
  mastery: MASTERY_STORAGE,
  authoring: AUTHORING_STORAGE,
  liveLab: LIVE_LAB_STORAGE,
  topology: TOPOLOGY_STORAGE,
});

const isObject = (value) => value !== null && typeof value === 'object';

export function collectStudyData() {
  const data = {};
  for (const [name, key] of Object.entries(MANAGED_KEYS)) {
    const raw = safeStorage.getItem(key);
    if (raw !== null) {
      try { data[name] = JSON.parse(raw); }
      catch { data[name] = null; }
    }
  }
  return data;
}

export function createStudySnapshot({ now = new Date().toISOString() } = {}) {
  return {
    schema: DATA_BACKUP_SCHEMA,
    version: DATA_BACKUP_VERSION,
    appVersion: APP_DATA_VERSION,
    exportedAt: now,
    data: collectStudyData(),
  };
}

export function serializeStudySnapshot(options) {
  return JSON.stringify(createStudySnapshot(options), null, 2);
}

export function validateStudySnapshot(snapshot) {
  const errors = [];
  if (!isObject(snapshot)) errors.push('Backup is not an object.');
  if (snapshot?.schema !== DATA_BACKUP_SCHEMA) errors.push('Unrecognized Driller Bill backup schema.');
  if (snapshot?.version !== DATA_BACKUP_VERSION) errors.push(`Unsupported backup version: ${snapshot?.version ?? 'missing'}.`);
  if (!isObject(snapshot?.data)) errors.push('Backup data is missing.');
  if (isObject(snapshot?.data)) {
    for (const key of Object.keys(snapshot.data)) {
      if (!Object.hasOwn(MANAGED_KEYS, key)) errors.push(`Unknown backup field: ${key}.`);
    }
    if (snapshot.data.history !== undefined && !Array.isArray(snapshot.data.history)) errors.push('History must be an array.');
    if (snapshot.data.seen !== undefined && !isObject(snapshot.data.seen)) errors.push('Seen-question data must be an object.');
    if (snapshot.data.mastery !== undefined && !isObject(snapshot.data.mastery)) errors.push('Mastery data must be an object.');
    if (snapshot.data.authoring !== undefined && !Array.isArray(snapshot.data.authoring)) errors.push('Authoring data must be an array.');
    if (snapshot.data.settings !== undefined && !isObject(snapshot.data.settings)) errors.push('Settings must be an object.');
  }
  return { valid: errors.length === 0, errors };
}

export function restoreStudySnapshot(snapshot, { clearMissing = false } = {}) {
  const validation = validateStudySnapshot(snapshot);
  if (!validation.valid) throw new Error(validation.errors.join(' '));
  const data = snapshot.data;

  for (const [name, key] of Object.entries(MANAGED_KEYS)) {
    if (Object.hasOwn(data, name)) {
      const value = data[name];
      safeStorage.setItem(key, JSON.stringify(value));
    } else if (clearMissing) {
      safeStorage.removeItem(key);
    }
  }
  return { restored: Object.keys(data).length, clearMissing };
}

export function downloadStudySnapshot() {
  if (typeof document === 'undefined' || typeof URL === 'undefined' || typeof Blob === 'undefined') {
    throw new Error('Downloads are not available in this environment.');
  }
  const blob = new Blob([serializeStudySnapshot()], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  try {
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `penny-farthing-study-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
  } finally {
    URL.revokeObjectURL(url);
  }
}
