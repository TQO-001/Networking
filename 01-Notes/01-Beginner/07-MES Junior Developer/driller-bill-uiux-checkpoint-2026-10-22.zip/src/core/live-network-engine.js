import { freshLab, normalizeLabState } from './cli-engine.js';

export const LIVE_LAB_STORAGE = 'pennyFarthingLiveNetwork:v1';

export const LIVE_PACKET_PROFILES = [
  { id:'vlan20-icmp', label:'VLAN 20 / ICMP', source:'PC2', destination:'SRV1', destinationIp:'10.20.20.10', protocol:'ICMP', network:'switched-vlan20' },
  { id:'ipv4-icmp', label:'IPv4 / ICMP', source:'PC1', destination:'SRV1', destinationIp:'10.20.20.10', protocol:'ICMP', network:'routed-ipv4' },
  { id:'ipv4-https', label:'IPv4 / HTTPS', source:'PC1', destination:'WAN', destinationIp:'198.51.100.10', protocol:'TCP/443', network:'internet' },
  { id:'dhcp', label:'DHCP / DORA', source:'PC2', destination:'DHCP', destinationIp:'10.10.10.100', protocol:'UDP/67-68', network:'dhcp' },
  { id:'ospf', label:'OSPF / Hello', source:'R1', destination:'R2', destinationIp:'224.0.0.5', protocol:'OSPF', network:'ospf' },
  { id:'ipv6-icmp', label:'IPv6 / ICMPv6', source:'PC1', destination:'SRV1', destinationIp:'2001:db8:20::10', protocol:'ICMPv6', network:'routed-ipv6' },
];

export const LIVE_WORKSHOP_FAULTS = [
  { id:'none', label:'Live configuration', description:'Read the current configuration from the shared CLI Lab state.' },
  { id:'trunk-vlan20', label:'Remove VLAN 20 from trunk', description:'Mutates the shared SW1 ↔ SW2 trunk state.' },
  { id:'acl-icmp', label:'Deny PC1 ICMP', description:'Adds a standard ACL deny matching PC1 as a modeled policy gate.' },
  { id:'nat-inside', label:'Remove NAT inside role', description:'Removes the NAT inside role from R1 Gi0/0.' },
  { id:'dhcp-helper', label:'Remove DHCP helper', description:'Removes the helper address from the client gateway.' },
  { id:'ipv6-forwarding', label:'Disable IPv6 forwarding', description:'Disables IPv6 routing on R1.' },
  { id:'ipv6-route', label:'Remove remote IPv6 route', description:'Removes R1’s route to the remote IPv6 /64.' },
  { id:'ospf-adjacency', label:'Break OSPF adjacency', description:'Creates a hello/dead mismatch between R1 and R2.' },
  { id:'interface-down', label:'Disable SW1 Gi0/1', description:'Administratively disables the simulated access interface.' },
  { id:'static-route', label:'Remove R1 remote route', description:'Removes the modeled route to 10.20.20.0/24 from R1.' },
];

const clone = value => structuredClone(value);

function ensureExtendedState(state) {
  const s = normalizeLabState(state);
  for (const name of ['R1','R2']) {
    const d = s.devices[name];
    d.ipv6 ||= { forwarding: true, routes: [], addresses: {} };
    d.ipv6.routes ||= [];
    d.ipv6.addresses ||= {};
  }
  return s;
}

export function createHealthyLiveLab() {
  const state = ensureExtendedState(freshLab());
  // Start the shared lab from a coherent, usable baseline.
  state.devices.SW1.interfaces['GigabitEthernet0/24'].allowedVlans = [10,20,99];
  state.devices.SW2.interfaces['GigabitEthernet0/24'].allowedVlans = [10,20,99];
  state.devices.SW2.interfaces['GigabitEthernet0/23'] ||= { mode:'access', accessVlan:20, admin:true, link:true, description:'VLAN 20 gateway edge', helperAddresses:[], natRole:null, portSecurity:{enabled:false,maximum:1}, portfast:false, bpduguard:false, channelGroup:null };
  state.devices.SW2.interfaces['GigabitEthernet0/23'].mode = 'access';
  state.devices.SW2.interfaces['GigabitEthernet0/23'].accessVlan = 20;
  state.devices.SW2.interfaces['GigabitEthernet0/23'].admin = true;
  state.devices.SW2.interfaces['GigabitEthernet0/23'].link = true;

  state.devices.R1.nat.inside = ['GigabitEthernet0/0'];
  state.devices.R1.nat.outside = ['GigabitEthernet0/1'];
  state.devices.R1.nat.overload = [{ acl:'1', interface:'GigabitEthernet0/1' }];
  state.devices.R1.acls['1'] = { rules:[{ sequence:10, action:'permit', source:'any', wildcard:'0.0.0.0', hits:0 }] };
  state.devices.R1.interfaces['GigabitEthernet0/0'].helperAddresses = ['10.10.10.100'];

  state.devices.R1.ipv6.forwarding = true;
  state.devices.R2.ipv6.forwarding = true;
  state.devices.R1.ipv6.routes = ['2001:db8:20::/64'];
  state.devices.R2.ipv6.routes = ['2001:db8:20::/64'];
  state.clients.PC1.ipv6 = '2001:db8:10::10';
  state.clients.SRV1.ipv6 = '2001:db8:20::10';
  state.clients.PC2.dhcp = true;
  state.meta.liveNetworkVersion = 1;
  return state;
}

export function prepareLiveLabState(input) {
  return ensureExtendedState(input || createHealthyLiveLab());
}

function ifaceUp(iface) { return !!iface?.admin && !!iface?.link; }
function trunkPairHealthy(state) {
  const a = state.devices.SW1.interfaces['GigabitEthernet0/24'];
  const b = state.devices.SW2.interfaces['GigabitEthernet0/24'];
  return ifaceUp(a) && ifaceUp(b) && a.mode === 'trunk' && b.mode === 'trunk';
}
function trunkCarries(state, vlan) {
  const a = state.devices.SW1.interfaces['GigabitEthernet0/24'];
  const b = state.devices.SW2.interfaces['GigabitEthernet0/24'];
  return trunkPairHealthy(state) && a.allowedVlans?.includes(vlan) && b.allowedVlans?.includes(vlan);
}
function routePresent(state, router, prefix) {
  return !!state.devices[router]?.routes?.some(r => r.prefix === prefix && ['C','O','S','S*'].includes(r.type));
}
function ospfHealthy(state) {
  const r1 = state.devices.R1, r2 = state.devices.R2;
  if (!r1?.ospf || !r2?.ospf) return false;
  const a = r1.interfaces['GigabitEthernet0/1'], b = r2.interfaces['GigabitEthernet0/0'];
  if (!ifaceUp(a) || !ifaceUp(b)) return false;
  return Number(r1.ospf.hello ?? 10) === Number(r2.ospf.hello ?? 10)
    && Number(r1.ospf.dead ?? 40) === Number(r2.ospf.dead ?? 40);
}
function aclAllowsPc1(state) {
  const rules = Object.values(state.devices.R1.acls || {}).flatMap(x => x.rules || []);
  const blocking = rules.some(r => r.action === 'deny' && ['10.10.10.10','host 10.10.10.10'].includes(r.source));
  return !blocking;
}
function natReady(state) {
  const r1 = state.devices.R1;
  return r1.nat?.inside?.includes('GigabitEthernet0/0')
    && r1.nat?.outside?.includes('GigabitEthernet0/1')
    && (r1.nat?.overload || []).length > 0;
}
function dhcpRelayReady(state) {
  return (state.devices.R1.interfaces['GigabitEthernet0/0'].helperAddresses || []).length > 0;
}
function ipv6Ready(state) {
  return state.devices.R1.ipv6?.forwarding === true;
}
function ipv6RouteReady(state) {
  return state.devices.R1.ipv6?.routes?.includes('2001:db8:20::/64');
}
function accessVlanReady(state, device, iface, vlan) {
  const i = state.devices[device]?.interfaces?.[iface];
  return ifaceUp(i) && i.mode === 'access' && i.accessVlan === vlan;
}

export function liveSnapshot(input) {
  const state = prepareLiveLabState(input);
  const r1 = state.devices.R1, r2 = state.devices.R2;
  return {
    sw1Trunk: trunkPairHealthy(state),
    vlan20Trunk: trunkCarries(state, 20),
    vlan10Trunk: trunkCarries(state, 10),
    pc1Edge: accessVlanReady(state,'SW1','GigabitEthernet0/1',10),
    pc2Edge: accessVlanReady(state,'SW1','GigabitEthernet0/5',20),
    serverEdge: accessVlanReady(state,'SW2','GigabitEthernet0/5',20),
    r1Transit: ifaceUp(r1.interfaces['GigabitEthernet0/1']),
    r2Transit: ifaceUp(r2.interfaces['GigabitEthernet0/0']),
    r2GatewayEdge: ifaceUp(r2.interfaces['GigabitEthernet0/1']) && accessVlanReady(state,'SW2','GigabitEthernet0/23',20),
    routeToServer: routePresent(state,'R1','10.20.20.0/24'),
    ospf: ospfHealthy(state),
    aclAllowsPc1: aclAllowsPc1(state),
    nat: natReady(state),
    dhcpRelay: dhcpRelayReady(state),
    ipv6Forwarding: ipv6Ready(state),
    ipv6Route: ipv6RouteReady(state),
  };
}

export function simulateLivePacket(input, profileId) {
  const state = prepareLiveLabState(input);
  const profile = LIVE_PACKET_PROFILES.find(p => p.id === profileId) || LIVE_PACKET_PROFILES[0];
  const snap = liveSnapshot(state);
  const steps = [];
  const add = (id, layer, device, status, ok, event, detail, evidence) => steps.push({ id, layer, device, status, ok, event, detail, evidence });
  add('emit','L2',profile.source,'EMIT',true,'Frame created',`${profile.label} enters the shared network model.`,`${profile.protocol} · ${profile.source} → ${profile.destinationIp}`);

  if (profile.network === 'switched-vlan20') {
    add('edge20','L2','SW1',snap.pc2Edge?'ACCESS':'BLOCKED',snap.pc2Edge,'Source VLAN 20 edge',snap.pc2Edge?'PC2 is attached to VLAN 20.':'PC2 is not presenting VLAN 20 at its access edge.',`Gi0/5 · access VLAN ${state.devices.SW1.interfaces['GigabitEthernet0/5'].accessVlan}`);
    add('trunk','L2','SW1 ↔ SW2',snap.vlan20Trunk?'ALLOWED':'BLOCKED',snap.vlan20Trunk,'VLAN 20 trunk forwarding',snap.vlan20Trunk?'Both trunk ends carry VLAN 20.':'VLAN 20 is missing from one or both trunk allowed lists.',`VLAN 20 · SW1 ${state.devices.SW1.interfaces['GigabitEthernet0/24'].allowedVlans?.join(',') || 'none'} · SW2 ${state.devices.SW2.interfaces['GigabitEthernet0/24'].allowedVlans?.join(',') || 'none'}`);
    const delivered = snap.pc2Edge && snap.vlan20Trunk && snap.serverEdge;
    add('dest20','L2','SRV1',delivered?'DELIVERED':'BLOCKED',delivered,'Server VLAN delivery',delivered?'The VLAN 20 frame reaches SRV1.':'The VLAN 20 forwarding path is incomplete.',`SRV1 · ${profile.destinationIp}`);
  } else if (profile.network === 'routed-ipv4') {
    add('edge','L2','SW1',snap.pc1Edge?'ACCESS':'BLOCKED',snap.pc1Edge,'PC1 access VLAN',snap.pc1Edge?'PC1 is attached to VLAN 10.':'The source edge is not presenting VLAN 10.',`Gi0/1 · access VLAN ${state.devices.SW1.interfaces['GigabitEthernet0/1'].accessVlan}`);
    add('route','L3','R1',snap.routeToServer?'ROUTE':'NO ROUTE',snap.routeToServer,'IPv4 route lookup',snap.routeToServer?'R1 has a path to the remote server network.':'R1 has no route to 10.20.20.0/24.',snap.routeToServer?'10.20.20.0/24':'lookup failed');
    add('transit','L3','R1 ↔ R2',snap.r1Transit&&snap.r2Transit?'UP':'DOWN',snap.r1Transit&&snap.r2Transit,'Routed transit',snap.r1Transit&&snap.r2Transit?'The transit interfaces are operational.':'One side of the routed transit is down.','Gi0/1 ↔ Gi0/0');
    add('gateway','L3','R2',snap.r2GatewayEdge?'EDGE OK':'BLOCKED',snap.r2GatewayEdge,'VLAN 20 gateway edge',snap.r2GatewayEdge?'R2 can forward toward the VLAN 20 LAN.':'The R2 gateway edge is not correctly attached to VLAN 20.','Gi0/1 → SW2 Gi0/23');
    const delivered = snap.pc1Edge && snap.routeToServer && snap.r1Transit && snap.r2Transit && snap.r2GatewayEdge && snap.serverEdge;
    add('dest','L2','SRV1',delivered?'DELIVERED':'BLOCKED',delivered,'Server delivery',delivered?'The packet reaches SRV1 through the routed path.':'The routed path cannot complete delivery.',`SRV1 · ${profile.destinationIp}`);
  } else if (profile.network === 'internet') {
    add('acl','L3','R1',snap.aclAllowsPc1?'PERMIT':'DENY',snap.aclAllowsPc1,'ACL decision',snap.aclAllowsPc1?'No modeled deny blocks PC1.':'A modeled ACL deny matches the source.',snap.aclAllowsPc1?'ACL permits':'ACL deny matched PC1');
    add('nat','L3','R1',snap.nat?'TRANSLATE':'BLOCKED',snap.nat,'NAT/PAT decision',snap.nat?'Gi0/0 is inside and Gi0/1 is outside with overload.':'NAT cannot translate because the inside/outside roles or overload rule are missing.',snap.nat?'PAT ready':'NAT roles incomplete');
    add('wan','L3','WAN',(snap.aclAllowsPc1&&snap.nat)?'FORWARD':'DROP',snap.aclAllowsPc1&&snap.nat,'WAN egress',(snap.aclAllowsPc1&&snap.nat)?'The packet leaves with a translated source address.':'A policy or NAT gate blocks WAN egress.', '203.0.113.2 → 198.51.100.10');
  } else if (profile.network === 'dhcp') {
    add('broadcast','L2','SW1','FLOOD',true,'DHCPDISCOVER', 'The client broadcast reaches its local gateway boundary.','0.0.0.0:68 → 255.255.255.255:67');
    add('relay','L3','R1',snap.dhcpRelay?'RELAY':'BLOCKED',snap.dhcpRelay,'DHCP relay',snap.dhcpRelay?'The helper address is configured.':'No helper address is present on the client gateway.',`helper-address: ${state.devices.R1.interfaces['GigabitEthernet0/0'].helperAddresses?.[0] || 'none'}`);
    add('server','L3','DHCP',snap.dhcpRelay?'OFFER':'WAIT',snap.dhcpRelay,'DHCPOFFER',snap.dhcpRelay?'The modeled relay can reach the DHCP server.':'The server never receives the relayed request.','10.10.10.100 · OFFER');
    add('bind','L2','PC2',snap.dhcpRelay?'BOUND':'WAIT',snap.dhcpRelay,'Lease state',snap.dhcpRelay?'The client receives a lease in the simulation.':'The client remains in DISCOVERING.','10.10.10.20');
  } else if (profile.network === 'ospf') {
    add('hello','L3','R1',snap.ospf?'HELLO':'DOWN',snap.ospf,'OSPF hello',snap.ospf?'Timers agree and the transit is operational.':'The OSPF adjacency is unavailable.','224.0.0.5 · 10s/40s');
    add('adj','L3','R2',snap.ospf?'FULL':'NO-ADJ',snap.ospf,'Neighbor adjacency',snap.ospf?'R2 can form the expected relationship.':'R2 cannot reach FULL state.',snap.ospf?'FULL':'DOWN');
    add('routes','L3','R1',snap.ospf?'LEARN':'BLOCKED',snap.ospf,'Route exchange',snap.ospf?'The control plane can exchange routes.':'No usable OSPF relationship exists.',snap.ospf?'LSDB sync':'no peer');
  } else if (profile.network === 'routed-ipv6') {
    add('forward','L3','R1',snap.ipv6Forwarding?'ENABLED':'DISABLED',snap.ipv6Forwarding,'IPv6 forwarding gate',snap.ipv6Forwarding?'R1 is forwarding IPv6.':'R1 has IPv6 forwarding disabled.','ipv6 unicast-routing');
    add('route6','L3','R1',snap.ipv6Route?'FOUND':'MISSING',snap.ipv6Route,'IPv6 route lookup',snap.ipv6Route?'The remote IPv6 prefix is known.':'The remote IPv6 route is absent.','2001:db8:20::/64');
    add('remote','L3','R2',snap.r2GatewayEdge?'READY':'BLOCKED',snap.r2GatewayEdge,'Remote IPv6 LAN',snap.r2GatewayEdge?'The remote gateway edge is operational.':'The remote gateway edge is unavailable.','R2 → SW2');
    const delivered = snap.ipv6Forwarding && snap.ipv6Route && snap.r2GatewayEdge && snap.serverEdge;
    add('dest6','L2','SRV1',delivered?'DELIVERED':'BLOCKED',delivered,'IPv6 destination',delivered?'The packet reaches the IPv6 server.':'The IPv6 path is incomplete.','2001:db8:20::10');
  }

  const firstFailure = steps.find(s => !s.ok)?.id || null;
  const passed = steps.filter(s => s.ok).length;
  return { profile, steps, firstFailure, passed, total:steps.length, score:Math.round(passed/steps.length*100), complete:!firstFailure };
}

export function injectLiveFault(input, faultId) {
  const state = prepareLiveLabState(input);
  switch (faultId) {
    case 'trunk-vlan20':
      state.devices.SW1.interfaces['GigabitEthernet0/24'].allowedVlans = [10,99];
      state.devices.SW2.interfaces['GigabitEthernet0/24'].allowedVlans = [10,99];
      break;
    case 'acl-icmp':
      state.devices.R1.acls['1'] = { rules:[{sequence:10,action:'deny',source:'10.10.10.10',wildcard:'0.0.0.0',hits:0},{sequence:20,action:'permit',source:'any',wildcard:'0.0.0.0',hits:0}] };
      break;
    case 'nat-inside': state.devices.R1.nat.inside = []; break;
    case 'dhcp-helper': state.devices.R1.interfaces['GigabitEthernet0/0'].helperAddresses = []; break;
    case 'ipv6-forwarding': state.devices.R1.ipv6.forwarding = false; break;
    case 'ipv6-route': state.devices.R1.ipv6.routes = []; break;
    case 'ospf-adjacency': state.devices.R2.ospf = {...state.devices.R2.ospf, hello: 5}; break;
    case 'interface-down': state.devices.SW1.interfaces['GigabitEthernet0/1'].admin = false; break;
    case 'static-route': state.devices.R1.routes = state.devices.R1.routes.filter(route => route.prefix !== '10.20.20.0/24'); break;
    default: break;
  }
  return state;
}

export function resetLiveNetwork() { return createHealthyLiveLab(); }
