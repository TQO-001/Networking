import {
  INITIAL_LAB,
  LAB_TASKS,
  LINKS as BASE_LINKS,
  TOPOLOGY as BASE_TOPOLOGY,
  freshLab as baseFreshLab,
  networkHealth as baseNetworkHealth,
  pingResult as basePingResult,
  evaluateTask as baseEvaluateTask,
  taskFixture as baseTaskFixture,
  compactInterface,
} from './network-base.js';
import { freshNetwork } from './network-model.js';

const clone = value => structuredClone(value);

export const TOPOLOGY = BASE_TOPOLOGY;
export const LINKS = BASE_LINKS;
export { LAB_TASKS, compactInterface };

const EXEC_SHOWS = [
  'show ip interface brief',
  'show interfaces',
  'show interfaces <interface>',
  'show interfaces status',
  'show interfaces trunk',
  'show interfaces switchport',
  'show ip route',
  'show ip protocols',
  'show ip ospf neighbor',
  'show vlan brief',
  'show etherchannel summary',
  'show spanning-tree',
  'show mac address-table',
  'show cdp neighbors',
  'show lldp neighbors',
  'show ip dhcp binding',
  'show ip nat translations',
  'show access-lists',
  'show running-config',
  'show startup-config',
  'show version',
];

export const HELP = `DRILLER BILL IOS ENGINE — SUPPORTED COMMAND SURFACE\n\nEXEC\n  show ip interface brief\n  show interfaces [<interface>]\n  show interfaces status\n  show interfaces trunk\n  show interfaces switchport [<interface>]\n  show ip route\n  show ip protocols\n  show ip ospf neighbor\n  show vlan brief\n  show etherchannel summary\n  show spanning-tree [vlan <id>]\n  show mac address-table\n  show cdp neighbors\n  show lldp neighbors\n  show ip dhcp binding\n  show ip nat translations\n  show access-lists\n  show running-config\n  show startup-config\n  show version\n  ping <IPv4>\n  terminal length <0-512>\n  do <show-command> (configuration modes)\n\nPRIVILEGED\n  configure terminal | conf t\n  enable / disable\n  copy running-config startup-config\n  write memory\n  erase startup-config\n\nGLOBAL CONFIG\n  hostname <name>\n  no hostname\n  username <name> privilege <0-15> secret <password>\n  ip default-gateway <IPv4>\n  ip route <network> <mask> <next-hop> [<AD>]\n  no ip route <network> <mask> <next-hop>\n  vlan <1-4094>\n  interface <name>\n  interface vlan <id>\n  router ospf <process>\n  ip dhcp pool <name>\n  ip nat inside source list <acl> interface <interface> overload\n  access-list <num> permit|deny <source> [<wildcard>]\n\nINTERFACE CONFIG\n  description <text>\n  ip address <IPv4> <mask>\n  ip helper-address <IPv4>\n  ip nat inside | ip nat outside\n  switchport mode access|trunk\n  switchport access vlan <id>\n  switchport trunk native vlan <id>\n  switchport trunk allowed vlan <list>\n  switchport trunk allowed vlan add|remove <list>\n  switchport port-security\n  switchport port-security maximum <1-4096>\n  spanning-tree portfast\n  spanning-tree bpduguard enable\n  channel-group <1-32> mode active|passive|on\n  no shutdown / shutdown\n\nVLAN CONFIG\n  name <name>\n\nOSPF CONFIG\n  router-id <IPv4>\n  network <IPv4> <wildcard> area <0-4294967295>\n  passive-interface <interface>\n\nDHCP POOL CONFIG\n  network <network> <mask>\n  default-router <IPv4>\n  dns-server <IPv4> [<IPv4>]\n  lease <days> [<hours>] [<minutes>]\n\nLINE EDITING\n  Enter             execute\n  ↑ / ↓             command history\n  Tab               autocomplete\n  ?                 context help\n  Ctrl+C            clear current input\n\nThis is a controlled CCNA training simulation, not a Cisco IOS implementation.`;

function ensureObject(target, key, fallback) {
  if (target[key] == null) target[key] = fallback;
  return target[key];
}

export function normalizeLabState(input) {
  const state = clone(input || baseFreshLab());
  if (!state.devices?.R2) {
    const seedR2 = freshNetwork().devices.R2;
    state.devices.R2 = { ...seedR2 };
  }
  for (const [name, dev] of Object.entries(state.devices || {})) {
    dev.hostname ||= name;
    dev.mode ||= 'exec';
    dev.role ||= dev.kind;
    dev.interfaces ||= {};
    dev.vlans ||= dev.kind === 'switch' ? {1: 'default'} : {};
    dev.routes ||= [];
    dev.users ||= [];
    dev.enableSecret ||= '';
    dev.domainName ||= '';
    dev.sshVersion ||= null;
    dev.spanningTreeMode ||= 'rapid-pvst';
    dev.lines ||= {};
    dev.dhcpExcluded ||= [];
    dev.acls ||= {};
    dev.dhcpPools ||= {};
    dev.nat ||= {inside: [], outside: [], overload: []};
    dev.etherchannels ||= {group: 1, protocol: 'LACP', ports: [], state: 'SU'};
    dev.stp ||= {root: dev.kind === 'switch', rootPort: null, priority: 32768, mac: '0011.2233.0000'};
    dev.ospf ||= null;
    dev.configInterface ||= null;
    dev.configVlan ||= null;
    dev.configRouter ||= null;
    dev.configDhcpPool ||= null;
    dev.configLine ||= null;
    dev.configSvi ||= null;
    dev.ipv6 ||= { forwarding: false, routes: [], addresses: {} };
    dev.ipv6.routes ||= [];
    dev.ipv6.addresses ||= {};
    for (const iface of Object.values(dev.interfaces)) {
      iface.admin = iface.admin !== false;
      iface.link = iface.link !== false;
      if (dev.kind === 'switch') {
        iface.mode ||= 'access';
        iface.accessVlan ||= 1;
        if (iface.mode === 'trunk') {
          iface.nativeVlan ||= 1;
          iface.allowedVlans ||= [1];
        }
      }
      iface.description ||= '';
      iface.helperAddresses ||= [];
      iface.aclBindings ||= {};
      iface.natRole ||= null;
      iface.portSecurity ||= {enabled: false, maximum: 1};
      iface.portfast = !!iface.portfast;
      iface.bpduguard = !!iface.bpduguard;
      iface.channelGroup ||= null;
    }
  }
  ensureObject(state.meta = state.meta || {}, 'savedAt', null);
  return state;
}

export function freshLab() {
  return normalizeLabState(baseFreshLab());
}

function devOf(state, name) {
  return state.devices[name];
}

function normalizeSpaces(value = '') {
  return value.trim().replace(/\s+/g, ' ');
}

function lower(value = '') {
  return normalizeSpaces(value).toLowerCase();
}

function isIPv4(value = '') {
  const parts = value.split('.').map(Number);
  return parts.length === 4 && parts.every(n => Number.isInteger(n) && n >= 0 && n <= 255);
}

function maskToPrefix(mask) {
  if (!isIPv4(mask)) return null;
  return mask.split('.').map(Number).reduce((sum, octet) => sum + octet.toString(2).split('').filter(c => c === '1').length, 0);
}

function prefixMask(prefix) {
  const p = Number(prefix);
  if (!Number.isInteger(p) || p < 0 || p > 32) return null;
  const out = [];
  let remaining = p;
  for (let i = 0; i < 4; i += 1) {
    const bits = Math.min(8, Math.max(0, remaining));
    out.push(bits === 0 ? 0 : 256 - (2 ** (8 - bits)));
    remaining -= bits;
  }
  return out.join('.');
}

function wildcardMask(value) {
  if (!isIPv4(value)) return null;
  return value.split('.').map(o => 255 - Number(o)).join('.');
}

function networkPrefix(ip, mask) {
  if (!isIPv4(ip) || !isIPv4(mask)) return null;
  const a = ip.split('.').map(Number);
  const m = mask.split('.').map(Number);
  const network = a.map((x, i) => x & m[i]).join('.');
  const prefix = maskToPrefix(mask);
  return `${network}/${prefix}`;
}

function maskFromPrefixToken(token) {
  if (!token) return null;
  if (/^\d+$/.test(token)) return prefixMask(token);
  return isIPv4(token) ? token : null;
}

function parseVlanList(value, current = []) {
  const out = [];
  const tokens = String(value || '').split(',');
  for (const raw of tokens) {
    const token = raw.trim();
    if (!token) continue;
    if (/^\d+-\d+$/.test(token)) {
      const [a, b] = token.split('-').map(Number);
      for (let vlan = Math.min(a, b); vlan <= Math.max(a, b); vlan += 1) out.push(vlan);
    } else if (/^\d+$/.test(token)) out.push(Number(token));
  }
  return [...new Set(out.length ? out : current)].filter(v => v >= 1 && v <= 4094).sort((a, b) => a - b);
}

export function interfaceKey(raw = '') {
  const input = raw.trim();
  const x = input.toLowerCase().replace(/^int(?:erface)?\s+/, '');
  const aliases = {
    gi: 'GigabitEthernet',
    gig: 'GigabitEthernet',
    gigabitethernet: 'GigabitEthernet',
    fa: 'FastEthernet',
    fastethernet: 'FastEthernet',
    te: 'TenGigabitEthernet',
    tengigabitethernet: 'TenGigabitEthernet',
  };
  for (const [prefix, long] of Object.entries(aliases)) {
    const match = x.match(new RegExp(`^${prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\d+\\/\\d+(?:\\/\\d+)?)$`));
    if (match) return `${long}${match[1]}`;
  }
  if (/^(?:lo|loopback)\d+$/.test(x)) return x.startsWith('lo') ? `Loopback${x.replace(/\D/g, '')}` : `Loopback${x.match(/\d+/)?.[0]}`;
  const svi = x.match(/^vlan(\d+)$/);
  if (svi) return `Vlan${svi[1]}`;
  return input;
}

function shortInterface(name = '') {
  return name
    .replace(/^GigabitEthernet/i, 'Gi')
    .replace(/^FastEthernet/i, 'Fa')
    .replace(/^TenGigabitEthernet/i, 'Te')
    .replace(/^Loopback/i, 'Lo')
    .replace(/^Vlan/i, 'Vl');
}

function ensureInterface(dev, rawName) {
  const name = interfaceKey(rawName);
  if (!name) return null;
  if (!dev.interfaces[name]) {
    dev.interfaces[name] = {
      mode: dev.kind === 'switch' ? 'access' : undefined,
      accessVlan: 1,
      admin: true,
      link: false,
      description: '',
      helperAddresses: [],
      portSecurity: {enabled: false, maximum: 1},
      portfast: false,
      bpduguard: false,
      natRole: null,
      aclBindings: {},
      channelGroup: null,
    };
  }
  return name;
}

function modePrompt(dev) {
  if (dev.mode === 'user') return '>';
  if (dev.mode === 'config') return '(config)#';
  if (dev.mode === 'config-if') return '(config-if)#';
  if (dev.mode === 'config-vlan') return '(config-vlan)#';
  if (dev.mode === 'config-router') return '(config-router)#';
  if (dev.mode === 'config-dhcp') return '(dhcp-config)#';
  if (dev.mode === 'config-line') return '(config-line)#';
  return '#';
}

export function promptFor(state, name) {
  const dev = devOf(state, name);
  return `${dev?.hostname || name}${modePrompt(dev || {mode:'exec'})}`;
}

function cliError(text = 'Invalid input') {
  return `% ${text}`;
}

function invalidInput() {
  return `% Invalid input detected at '^' marker.`;
}

function incomplete() {
  return '% Incomplete command.';
}

function contextHelp(dev) {
  if (dev.mode === 'user') return ['enable', 'exit', 'help', 'ping', 'show', '?'].join('\n');
  if (dev.mode === 'exec') return ['configure terminal', 'disable', 'show', 'ping', 'copy', 'write', 'terminal', 'help', '?'].join('\n');
  if (dev.mode === 'config') return ['hostname', 'username', 'interface', 'vlan', 'router', 'ip route', 'ip dhcp pool', 'access-list', 'end', 'exit', 'do', 'no'].join('\n');
  if (dev.mode === 'config-if') return ['description', 'ip address', 'ip helper-address', 'ip nat', 'switchport', 'spanning-tree', 'channel-group', 'shutdown', 'no shutdown', 'do', 'exit', 'end', 'no'].join('\n');
  if (dev.mode === 'config-vlan') return ['name', 'exit', 'end', 'no'].join('\n');
  if (dev.mode === 'config-router') return ['router-id', 'network', 'passive-interface', 'exit', 'end', 'no'].join('\n');
  if (dev.mode === 'config-dhcp') return ['network', 'default-router', 'dns-server', 'lease', 'exit', 'end', 'no'].join('\n');
  if (dev.mode === 'config-line') return ['login', 'transport input', 'password', 'exec-timeout', 'exit', 'end', 'no'].join('\n');
  return HELP;
}

function findCommandMatches(dev, raw) {
  const value = raw.trim().toLowerCase();
  if (!value) return contextHelp(dev).split('\n');
  const commands = dev.mode === 'exec' || dev.mode === 'user' ? EXEC_SHOWS.concat(['configure terminal', 'enable', 'disable', 'ping', 'copy running-config startup-config', 'write memory', 'terminal length', 'help']) : contextHelp(dev).split('\n');
  return commands.filter(command => command.startsWith(value) || command.split(' ').some(part => part.startsWith(value)));
}

export function commandSuggestions(state, deviceName, raw) {
  const dev = devOf(state, deviceName);
  return findCommandMatches(dev, raw);
}

function dhcpBindings(dev) {
  const bindings = [];
  // Excluded addresses belong in running-config; they do not create DHCP bindings.
  // Keep this helper side-effect free so `show ip dhcp binding` can never reference an undefined renderer buffer.

  for (const [name, pool] of Object.entries(dev.dhcpPools || {})) {
    if (!pool.network) continue;
    const network = pool.network.split('/')[0];
    const mask = pool.network.includes('/') ? prefixMask(pool.network.split('/')[1]) : pool.mask;
    const leased = pool.leases || [];
    leased.forEach(lease => bindings.push({pool:name, mac:lease.mac || '0000.0000.0000', ip:lease.ip, state:'Active', poolNetwork:`${network}/${maskToPrefix(mask)}` }));
  }
  return bindings;
}

function ospfNeighborState(state, deviceName) {
  const dev = devOf(state, deviceName);
  if (!dev?.ospf) return [];
  const candidates = [];
  for (const [otherName, other] of Object.entries(state.devices)) {
    if (otherName === deviceName || !other?.ospf) continue;
    const shared = Object.entries(dev.interfaces).some(([name, iface]) => {
      if (!iface.admin || !iface.link || !iface.ip) return false;
      return Object.values(other.interfaces || {}).some(otherIface => otherIface.admin && otherIface.link && otherIface.ip && !String(otherIface.ip).startsWith('127.'));
    });
    if (!shared) continue;
    const hello = Number(dev.ospf.hello || 10) === Number(other.ospf.hello || 10);
    const dead = Number(dev.ospf.dead || 40) === Number(other.ospf.dead || 40);
    candidates.push({id: other.ospf.routerId || '0.0.0.0', state: hello && dead ? 'FULL/-' : 'EXSTART/ -', dead: dead ? '00:00:33' : '00:00:00', address: Object.values(other.interfaces).find(i => i.ip)?.ip || '0.0.0.0', iface: shortInterface(Object.keys(dev.interfaces).find(k => dev.interfaces[k].ip) || 'GigabitEthernet0/1')});
  }
  return candidates;
}

function showIpInterfaceBrief(dev) {
  const lines = [
    'Interface              IP-Address      OK? Method Status                Protocol',
    'GigabitEthernet0/0     '.replace('GigabitEthernet', 'Gi').padEnd(24),
  ];
  const rows = Object.entries(dev.interfaces).map(([name, iface]) => {
    const status = iface.admin && iface.link ? 'up' : iface.admin ? 'down' : 'administratively down';
    const protocol = iface.admin && iface.link ? 'up' : 'down';
    return `${shortInterface(name).padEnd(22)} ${(iface.ip || 'unassigned').padEnd(15)} YES manual ${status.padEnd(22)} ${protocol}`;
  });
  return [lines[0], ...rows].join('\n');
}

function showInterfaces(dev, requested) {
  const targets = requested ? [interfaceKey(requested)] : Object.keys(dev.interfaces);
  return targets.map(name => {
    const i = dev.interfaces[name];
    if (!i) return `% Interface ${name} not found.`;
    const status = i.admin && i.link ? 'up' : 'down';
    const proto = i.admin && i.link ? 'up' : 'down';
    const lines = [
      `${name} is ${status}, line protocol is ${proto}`,
      `  Description: ${i.description || '—'}`,
      '  Hardware is Driller Bill simulated interface',
      `  Internet address is ${i.ip || 'not set'}`,
      `  MTU 1500 bytes, BW simulated`,
      `  Encapsulation ARPA`,
    ];
    if (dev.kind === 'switch') {
      lines.push(`  Switchport: enabled, mode ${i.mode || 'access'}`);
      lines.push(`  Access VLAN: ${i.mode === 'access' ? i.accessVlan : '1'}`);
      lines.push(`  Native VLAN: ${i.mode === 'trunk' ? i.nativeVlan : '—'}`);
      lines.push(`  Allowed VLANs: ${i.mode === 'trunk' ? (i.allowedVlans || []).join(',') : '—'}`);
      lines.push(`  PortFast: ${i.portfast ? 'enabled' : 'disabled'}`);
      lines.push(`  BPDU Guard: ${i.bpduguard ? 'enabled' : 'disabled'}`);
      lines.push(`  Channel-group: ${i.channelGroup ? `${i.channelGroup} (${i.channelMode || 'active'})` : 'none'}`);
    }
    if (i.helperAddresses?.length) lines.push(`  Helper addresses: ${i.helperAddresses.join(', ')}`);
    if (i.natRole) lines.push(`  NAT role: ${i.natRole}`);
    return lines.join('\n');
  }).join('\n\n');
}

function showInterfaceStatus(dev) {
  const lines = ['Port      Name                Status       VLAN       Duplex  Speed   Type'];
  for (const [name, iface] of Object.entries(dev.interfaces)) {
    const status = iface.admin && iface.link ? 'connected' : iface.admin ? 'notconnect' : 'disabled';
    const vlan = iface.mode === 'trunk' ? 'trunk' : (iface.accessVlan || '—');
    lines.push(`${shortInterface(name).padEnd(9)} ${(iface.description || '').slice(0,19).padEnd(20)} ${status.padEnd(12)} ${String(vlan).padEnd(10)} a-full   a-1000  simulated`);
  }
  return lines.join('\n');
}

function showTrunk(dev) {
  const trunks = Object.entries(dev.interfaces).filter(([,i]) => i.mode === 'trunk');
  if (!trunks.length) return '% No trunking interfaces.';
  return trunks.map(([name, i]) => [
    `Port        Mode         Encapsulation  Status        Native vlan`,
    `${shortInterface(name).padEnd(12)}on           802.1q          ${(i.admin && i.link ? 'trunking' : 'not-trunking').padEnd(14)}${i.nativeVlan || 1}`,
    '',
    'Port        Vlans allowed on trunk',
    `${shortInterface(name).padEnd(12)}${(i.allowedVlans || []).join(',')}`,
    '',
    'Port        Vlans allowed and active in management domain',
    `${shortInterface(name).padEnd(12)}${(i.allowedVlans || []).filter(v => dev.vlans?.[v]).join(',')}`,
  ].join('\n')).join('\n\n');
}

function showSwitchport(dev, requested) {
  const name = interfaceKey(requested || 'GigabitEthernet0/24');
  const i = dev.interfaces[name];
  if (!i) return `% Interface ${name} not found.`;
  if (dev.kind !== 'switch') return invalidInput();
  return [
    `Name: ${shortInterface(name)}`,
    'Switchport: Enabled',
    `Administrative Mode: ${i.mode === 'trunk' ? 'trunk' : 'static access'}`,
    `Operational Mode: ${i.mode === 'trunk' ? 'trunk' : 'static access'}`,
    `Access Mode VLAN: ${i.mode === 'access' ? i.accessVlan : '1'}`,
    `Trunking Native Mode VLAN: ${i.nativeVlan || 1}`,
    `Trunking VLANs Enabled: ${i.allowedVlans?.join(',') || 'none'}`,
    `PortFast: ${i.portfast ? 'enabled' : 'disabled'}`,
    `BPDU Guard: ${i.bpduguard ? 'enabled' : 'disabled'}`,
  ].join('\n');
}

function showVlans(dev) {
  const lines = ['VLAN Name                             Status    Ports', '---- -------------------------------- --------- -------------------------------'];
  for (const [id, name] of Object.entries(dev.vlans || {})) {
    const ports = Object.entries(dev.interfaces).filter(([, iface]) => iface.mode === 'access' && String(iface.accessVlan) === String(id)).map(([port]) => shortInterface(port)).join(', ');
    lines.push(`${String(id).padEnd(5)}${String(name).slice(0,32).padEnd(32)}active    ${ports}`);
  }
  return lines.join('\n');
}

function showRoute(dev) {
  if (dev.kind !== 'router') return '% IP routing not active on this simulated switch.';
  const gw = dev.routes.find(r => r.type?.startsWith('S*'))?.next;
  const header = `Gateway of last resort is ${gw || 'not set'} to network 0.0.0.0`;
  const routes = (dev.routes || []).map(r => `${String(r.type || 'C').padEnd(4)}${r.prefix} ${r.next === 'direct' ? `is directly connected, ${r.iface}` : `[${r.ad || 1}/${r.metric ?? 0}] via ${r.next}, ${r.iface || 'unknown'}`}`);
  return `${header}\n\n${routes.join('\n')}`;
}

function showOspf(dev, state) {
  if (!dev.ospf) return '% OSPF not configured.';
  const neighbors = ospfNeighborState(state, dev.name || Object.keys(state.devices).find(k => state.devices[k] === dev));
  return [
    `Routing Process "ospf ${dev.ospf.process}" with ID ${dev.ospf.routerId || '0.0.0.0'}`,
    `Hello interval is ${dev.ospf.hello || 10}, Dead interval is ${dev.ospf.dead || 40}`,
    '',
    'Routing for Networks:',
    ...(dev.ospf.networks || []).map(n => `  ${n}`),
    '',
    `Passive interfaces: ${(dev.ospf.passiveInterfaces || []).join(', ') || 'none'}`,
    '',
    `Neighbor count is ${neighbors.length}`,
  ].join('\n');
}

function showOspfNeighbors(dev, state, deviceName) {
  if (!dev.ospf) return '% OSPF not configured.';
  const rows = ospfNeighborState(state, deviceName);
  if (!rows.length) return 'Neighbor ID     Pri   State           Dead Time   Address         Interface\n% No OSPF neighbors.';
  return ['Neighbor ID     Pri   State           Dead Time   Address         Interface', ...rows.map(r => `${r.id.padEnd(16)}1     ${r.state.padEnd(15)}${r.dead.padEnd(12)}${r.address.padEnd(16)}${r.iface}`)].join('\n');
}

function showEtherchannel(dev) {
  if (dev.kind !== 'switch') return '% EtherChannel is not configured.';
  const groups = dev.etherchannels?.groups || {};
  const names = Object.keys(groups);
  if (!names.length && dev.etherchannel?.ports?.length) {
    return `Group  Port-channel  Protocol    Ports\n${dev.etherchannel.group}      Po${dev.etherchannel.group}(SU)         ${dev.etherchannel.protocol}        ${dev.etherchannel.ports.map(p => `${shortInterface(p)}(${dev.etherchannel.state === 'SU' ? 'P' : 'I'})`).join(' ')}`;
  }
  if (!names.length) return 'No EtherChannel configured.';
  return ['Group  Port-channel  Protocol    Ports', ...names.map(group => {
    const g = groups[group];
    const bundled = (g.ports || []).map(p => `${shortInterface(p)}(${g.state === 'SU' ? 'P' : 'I'})`).join(' ');
    return `${String(group).padEnd(7)}Po${group}(SU)       ${(g.protocol || 'LACP').padEnd(11)}${bundled}`;
  })].join('\n');
}

function showSpanningTree(dev, vlan) {
  if (dev.kind !== 'switch') return '% STP is not applicable.';
  const selectedVlan = vlan ? Number(vlan) : 1;
  const priority = dev.stp?.vlanPriorities?.[selectedVlan] ?? dev.stp?.priority ?? 32768;
  const root = dev.stp?.vlanRoot?.[selectedVlan] ?? dev.stp?.root;
  const rootPort = dev.stp?.vlanRootPort?.[selectedVlan] ?? dev.stp?.rootPort;
  return [
    `VLAN${String(selectedVlan).padStart(4,'0')}`,
    `  Root ID    Priority    ${priority}`,
    `             Address     ${dev.stp?.mac || '0011.2233.0000'}`,
    `             ${root ? 'This bridge is the root' : `Root port   ${rootPort || 'none'}`}`,
    '',
    'Interface        Role Sts Cost      Prio.Nbr',
    ...Object.entries(dev.interfaces).map(([name, iface], idx) => `${shortInterface(name).padEnd(17)}${root ? 'Desg' : (name === rootPort ? 'Root' : 'Desg')} FWD 4         128.${idx + 1}`),
  ].join('\n');
}

function showMacTable(dev) {
  if (dev.kind !== 'switch') return '% MAC address table unavailable.';
  const lines = ['Vlan    Mac Address       Type       Ports', '----    -----------       --------   -----'];
  for (const [name, iface] of Object.entries(dev.interfaces)) {
    if (iface.mode === 'access' && iface.admin) {
      const vlan = iface.accessVlan || 1;
      const suffix = String(Math.abs(name.split('').reduce((n,c) => n + c.charCodeAt(0), 0))).padStart(2,'0').slice(-2);
      lines.push(`${String(vlan).padEnd(8)}aaaa.bbbb.cc${suffix.padStart(2,'0')}   DYNAMIC    ${shortInterface(name)}`);
    }
  }
  return lines.join('\n');
}

function showDhcp(dev) {
  const rows = dhcpBindings(dev);
  if (!rows.length) return 'Bindings from all pools not found.';
  return ['Bindings from all pools:', 'IP address      Client-ID/              Lease expiration     Type       State', ...rows.map(r => `${r.ip.padEnd(16)}${r.mac.padEnd(24)}Infinite              Dynamic    ${r.state}`)].join('\n');
}

function showDhcpPool(dev) {
  const entries = Object.entries(dev.dhcpPools || {});
  if (!entries.length) return '% No DHCP pools configured.';
  return entries.map(([name, pool]) => [
    `Pool ${name} :`,
    `  Network: ${pool.network || 'not configured'}` ,
    `  Default-router: ${pool.defaultRouter || 'not configured'}`,
    `  DNS server: ${pool.dns?.join(', ') || 'not configured'}`,
    `  Active leases: ${pool.leases?.length || 0}`,
  ].join('\n')).join('\n\n');
}

function showNat(dev) {
  const translations = dev.nat?.translations || [];
  if (!translations.length) return 'Pro Inside global      Inside local       Outside local      Outside global\n---  ---                   ---                ---                ---\n% No active translations.';
  return ['Pro  Inside global      Inside local       Outside local      Outside global', ...translations.map(t => `${(t.protocol || '---').padEnd(5)}${t.insideGlobal.padEnd(20)}${t.insideLocal.padEnd(19)}${(t.outsideLocal || '---').padEnd(19)}${t.outsideGlobal || '---'}`)].join('\n');
}

function showNatStatistics(dev) {
  const nat = dev.nat || {inside:[], outside:[], overload:[], translations:[]};
  return [
    `Inside interfaces: ${(nat.inside || []).join(', ') || 'none'}`,
    `Outside interfaces: ${(nat.outside || []).join(', ') || 'none'}`,
    `Overload rules: ${(nat.overload || []).length}`,
    `Active translations: ${(nat.translations || []).length}`,
  ].join('\n');
}

function showAcls(dev) {
  const entries = Object.entries(dev.acls || {});
  if (!entries.length) return '% No access lists configured.';
  const lines = [];
  for (const [id, acl] of entries) {
    lines.push(`Standard IP access list ${id}`);
    for (const rule of acl.rules || []) lines.push(`    ${rule.sequence || 10} ${rule.action} ${rule.source || 'any'} (hits=${rule.hits || 0})`);
  }
  return lines.join('\n');
}

function showRunningConfig(dev) {
  const lines = [`hostname ${dev.hostname}`];
  if (dev.enableSecret) lines.push(`enable secret ********`);
  if (dev.domainName) lines.push(`ip domain name ${dev.domainName}`);
  if (dev.sshVersion) lines.push(`ip ssh version ${dev.sshVersion}`);
  if (dev.spanningTreeMode) lines.push(`spanning-tree mode ${dev.spanningTreeMode}`);
  if (dev.kind === 'switch' && Object.keys(dev.vlans || {}).length) {
    for (const [id, name] of Object.entries(dev.vlans).sort((a, b) => Number(a[0]) - Number(b[0]))) {
      lines.push(`vlan ${id}`);
      if (name && name !== 'default' && name !== `VLAN${id}`) lines.push(` name ${name}`);
      lines.push('!');
    }
  }
  if (dev.ipv6?.forwarding) lines.push('ipv6 unicast-routing');
  for (const line of dev.lines ? Object.values(dev.lines) : []) {
    lines.push(`line ${line.type}${line.type === 'vty' ? ` ${line.start || 0} ${line.end ?? 4}` : ''}`);
    if (line.password) lines.push(' password ********');
    if (line.login) lines.push(' login');
    if (line.transportInput) lines.push(` transport input ${line.transportInput}`);
    lines.push('!');
  }
  lines.push('!');
  if (dev.users?.length) {
    for (const user of dev.users) lines.push(`username ${user.name} privilege ${user.privilege ?? 1} secret ${user.secret ? '********' : '—'}`);
    lines.push('!');
  }
  if (dev.defaultGateway) lines.push(`ip default-gateway ${dev.defaultGateway}`, '!');
  for (const [name, i] of Object.entries(dev.interfaces)) {
    lines.push(`interface ${name}`);
    if (i.description) lines.push(` description ${i.description}`);
    if (i.ip) lines.push(` ip address ${i.ip} ${i.mask}`);
    if (i.ospfProcess) lines.push(` ip ospf ${i.ospfProcess} area ${i.ospfArea ?? 0}`);
    if (i.ospfHello) lines.push(` ip ospf hello-interval ${i.ospfHello}`);
    if (i.ospfDead) lines.push(` ip ospf dead-interval ${i.ospfDead}`);
    if (dev.kind === 'switch') {
      if (i.mode === 'access') {
        lines.push(' switchport mode access', ` switchport access vlan ${i.accessVlan}`);
      } else if (i.mode === 'trunk') {
        lines.push(' switchport mode trunk', ` switchport trunk native vlan ${i.nativeVlan || 1}`, ` switchport trunk allowed vlan ${(i.allowedVlans || []).join(',')}`);
      }
      if (i.portSecurity?.enabled) {
        lines.push(' switchport port-security', ` switchport port-security maximum ${i.portSecurity.maximum || 1}`);
      }
      if (i.portfast) lines.push(' spanning-tree portfast');
      if (i.bpduguard) lines.push(' spanning-tree bpduguard enable');
    }
    for (const helper of i.helperAddresses || []) lines.push(` ip helper-address ${helper}`);
    for (const [direction, aclId] of Object.entries(i.aclBindings || {})) lines.push(` ip access-group ${aclId} ${direction}`);
    if (i.natRole) lines.push(` ip nat ${i.natRole}`);
    const ipv6Address = dev.ipv6?.addresses?.[name];
    if (ipv6Address) lines.push(` ipv6 address ${ipv6Address}`);
    if (i.channelGroup) lines.push(` channel-group ${i.channelGroup} mode ${i.channelMode || 'active'}`);
    lines.push(i.admin ? ' no shutdown' : ' shutdown', '!');
  }
  for (const svi of Object.entries(dev.svis || {})) {
    const [id, i] = svi;
    lines.push(`interface Vlan${id}`);
    if (i.ip) lines.push(` ip address ${i.ip} ${i.mask}`);
    if (i.ospfProcess) lines.push(` ip ospf ${i.ospfProcess} area ${i.ospfArea ?? 0}`);
    if (i.ospfHello) lines.push(` ip ospf hello-interval ${i.ospfHello}`);
    if (i.ospfDead) lines.push(` ip ospf dead-interval ${i.ospfDead}`);
    lines.push(i.admin ? ' no shutdown' : ' shutdown', '!');
  }
  if (dev.kind === 'router') {
    for (const route of (dev.routes || []).filter(r => r.type === 'S' || r.type === 'S*')) {
      lines.push(`ip route ${route.prefix.split('/')[0]} ${prefixMask(route.prefix.split('/')[1])} ${route.next}${route.ad && route.ad !== 1 ? ` ${route.ad}` : ''}`, '!');
    }
    for (const route of (dev.ipv6?.routes || []).filter(r => r.type === 'S')) lines.push(`ipv6 route ${route.prefix} ${route.next}`, '!');
  }
  for (const [id, acl] of Object.entries(dev.acls || {})) {
    for (const rule of acl.rules || []) lines.push(`access-list ${id} ${rule.action} ${rule.source}${rule.wildcard ? ` ${rule.wildcard}` : ''}`);
  }
  if (Object.keys(dev.acls || {}).length) lines.push('!');
  for (const rule of dev.nat?.overload || []) lines.push(`ip nat inside source list ${rule.acl} interface ${rule.interface} overload`);
  if ((dev.nat?.overload || []).length) lines.push('!');
  if (dev.ospf) {
    lines.push(`router ospf ${dev.ospf.process}`);
    if (dev.ospf.routerId) lines.push(` router-id ${dev.ospf.routerId}`);
    for (const network of dev.ospf.networks || []) lines.push(` network ${network}`);
    for (const passive of dev.ospf.passiveInterfaces || []) lines.push(` passive-interface ${passive}`);
    if (dev.ospf.hello) lines.push(` ip ospf hello-interval ${dev.ospf.hello}`);
    if (dev.ospf.dead) lines.push(` ip ospf dead-interval ${dev.ospf.dead}`);
    lines.push('!');
  }
  for (const excluded of dev.dhcpExcluded || []) lines.push(`ip dhcp excluded-address ${excluded}`);
  if ((dev.dhcpExcluded || []).length) lines.push('!');
  for (const [name, pool] of Object.entries(dev.dhcpPools || {})) {
    lines.push(`ip dhcp pool ${name}`);
    if (pool.network) {
      const [network, prefix] = pool.network.split('/');
      lines.push(` network ${network} ${prefixMask(prefix)}`);
    }
    if (pool.defaultRouter) lines.push(` default-router ${pool.defaultRouter}`);
    if (pool.dns?.length) lines.push(` dns-server ${pool.dns.join(' ')}`);
    if (pool.lease) lines.push(` lease ${pool.lease}`);
    lines.push('!');
  }
  return lines.join('\n');
}

function showIpv6InterfaceBrief(dev) {
  const rows = Object.entries(dev.interfaces || {}).map(([name, iface]) => {
    const addr = dev.ipv6?.addresses?.[name] || 'unassigned';
    const status = iface.admin && iface.link ? 'up' : (iface.admin ? 'down' : 'administratively down');
    return `${shortInterface(name).padEnd(12)} ${addr.padEnd(24)} ${status}`;
  });
  return ['Interface    IPv6-Address            Status', ...rows].join('\n');
}

function showIpv6Route(dev) {
  if (dev.kind !== 'router') return '% IPv6 routing is not active on this simulated switch.';
  const rows = dev.ipv6?.routes || [];
  if (!rows.length) return 'IPv6 Routing Table - no IPv6 routes.';
  return ['IPv6 Routing Table', ...rows.map(r => `${r.type === 'C' ? 'C' : 'S'} ${r.prefix}${r.next ? ` [${r.next}]` : ''}`)].join('\n');
}

function showStartupConfig(dev) {
  return dev.startupConfig || showRunningConfig(dev);
}

export function deriveShow(state, deviceName, rawCommand) {
  const dev = devOf(state, deviceName);
  if (!dev) return cliError('Device not found.');
  const c = lower(rawCommand).replace(/^do\s+/, '');
  if (c === 'show ip interface brief') return showIpInterfaceBrief(dev);
  if (c === 'show interfaces status') return dev.kind === 'switch' ? showInterfaceStatus(dev) : invalidInput();
  if (c === 'show interfaces trunk') return dev.kind === 'switch' ? showTrunk(dev) : invalidInput();
  const interfacesMatch = c.match(/^show interfaces(?: (.+))?$/);
  if (interfacesMatch) return showInterfaces(dev, interfacesMatch[1]);
  const switchportMatch = c.match(/^show interfaces switchport(?: (.+))?$/);
  if (switchportMatch) return showSwitchport(dev, switchportMatch[1]);
  if (c === 'show ip route') return showRoute(dev);
  if (c === 'show ip protocols') return showOspf(dev, state);
  if (c === 'show ip ospf neighbor') return showOspfNeighbors(dev, state, deviceName);
  if (c === 'show vlan brief') return dev.kind === 'switch' ? showVlans(dev) : invalidInput();
  if (c === 'show etherchannel summary') return showEtherchannel(dev);
  const stpMatch = c.match(/^show spanning-tree(?: vlan (\d+))?$/);
  if (stpMatch) return showSpanningTree(dev, stpMatch[1]);
  if (c === 'show mac address-table') return showMacTable(dev);
  if (c === 'show cdp neighbors') return showCdpNeighbors(state, deviceName);
  if (c === 'show lldp neighbors') return showLldpNeighbors(state, deviceName);
  if (c === 'show ip dhcp binding') return showDhcp(dev);
  if (c === 'show ip dhcp pool') return showDhcpPool(dev);
  if (c === 'show ip nat translations') return showNat(dev);
  if (c === 'show ip nat statistics') return showNatStatistics(dev);
  if (c === 'show ipv6 interface brief') return showIpv6InterfaceBrief(dev);
  if (c === 'show ipv6 route') return showIpv6Route(dev);
  if (c === 'show access-lists') return showAcls(dev);
  if (c === 'show running-config') return showRunningConfig(dev);
  if (c === 'show startup-config') return showStartupConfig(dev);
  if (c === 'show version') return `Cisco IOS XE Software, Version ${dev.version || '17.12.04'}\nDriller Bill simulated ${dev.kind} device\nProcessor board ID PF-${deviceName}\nConfiguration register is 0x2102`;
  return null;
}

const SIMULATED_DISCOVERY_LINKS = [
  { a:'R1', ai:'GigabitEthernet0/0', b:'SW1', bi:'GigabitEthernet0/10' },
  { a:'SW1', ai:'GigabitEthernet0/24', b:'SW2', bi:'GigabitEthernet0/24' },
  { a:'R1', ai:'GigabitEthernet0/1', b:'R2', bi:'GigabitEthernet0/0' },
  { a:'R2', ai:'GigabitEthernet0/1', b:'SW2', bi:'GigabitEthernet0/23' },
];

function showDiscoveryLinks(state, deviceName) {
  const rows = [];
  for (const link of SIMULATED_DISCOVERY_LINKS) {
    const localIsA = link.a === deviceName;
    const localIsB = link.b === deviceName;
    if (!localIsA && !localIsB) continue;
    const remote = localIsA ? link.b : link.a;
    const remoteDev = state.devices?.[remote];
    if (!remoteDev || !['router','switch'].includes(remoteDev.kind)) continue;
    rows.push({ remote, localPort: localIsA ? link.ai : link.bi, remotePort: localIsA ? link.bi : link.ai, kind: remoteDev.kind });
  }
  return rows;
}

function showCdpNeighbors(state, deviceName) {
  const lines = ['Device ID        Local Intrfce     Holdtme    Capability   Platform    Port ID'];
  for (const row of showDiscoveryLinks(state, deviceName)) {
    const capability = row.kind === 'router' ? 'R S I' : 'S I';
    const platform = row.kind === 'router' ? 'C9300' : 'C9200';
    const local = row.localPort.replace(/^GigabitEthernet/, 'Gig ');
    lines.push(`${row.remote.padEnd(16)} ${local.padEnd(17)} 120        ${capability.padEnd(12)} ${platform.padEnd(11)} ${row.remotePort}`);
  }
  return lines.join('\n');
}

function showLldpNeighbors(state, deviceName) {
  const lines = ['Device ID        Local Intf      Hold-time   Capability  Port ID'];
  for (const row of showDiscoveryLinks(state, deviceName)) {
    const capability = row.kind === 'router' ? 'Router' : 'Bridge';
    const local = row.localPort.replace(/^GigabitEthernet/, 'Gi');
    lines.push(`${row.remote.padEnd(16)} ${local.padEnd(15)} 120         ${capability.padEnd(11)} ${row.remotePort}`);
  }
  return lines.join('\n');
}

function setMode(dev, mode) {
  dev.mode = mode;
}

function exitConfig(dev) {
  dev.mode = 'exec';
  dev.configInterface = null;
  dev.configVlan = null;
  dev.configRouter = null;
  dev.configDhcpPool = null;
  dev.configLine = null;
  dev.configSvi = null;
}

function parseRouteFromArgs(args) {
  if (args.length < 3) return null;
  const network = args[0];
  const mask = maskFromPrefixToken(args[1]);
  const next = args[2];
  const ad = args[3] ? Number(args[3]) : 1;
  if (!isIPv4(network) || !mask || !isIPv4(next) || !Number.isInteger(ad)) return null;
  return {prefix: networkPrefix(network, mask), network, mask, next, ad};
}

function executeShowOrDo(state, deviceName, raw, allowDo = false) {
  const dev = devOf(state, deviceName);
  const c = lower(raw);
  if (allowDo && c.startsWith('do ')) return deriveShow(state, deviceName, raw.slice(3));
  const shown = deriveShow(state, deviceName, raw);
  if (shown !== null) return shown;
  return null;
}

function addUser(dev, name, privilege, secret) {
  const existing = dev.users.find(user => user.name === name);
  const entry = existing || {name};
  entry.privilege = Number(privilege ?? entry.privilege ?? 1);
  entry.secret = secret || entry.secret || '';
  if (!existing) dev.users.push(entry);
}

function configureInterface(dev, raw) {
  const name = ensureInterface(dev, raw);
  if (!name) return {ok:false, output:incomplete()};
  if (name.startsWith('Vlan')) {
    dev.svis ||= {};
    const id = Number(name.replace('Vlan',''));
    dev.svis[id] ||= {ip:'',mask:'255.255.255.0',admin:true};
    dev.configSvi = id;
    dev.mode = 'config-if';
    dev.configInterface = name;
    return {ok:true, output:''};
  }
  dev.mode = 'config-if';
  dev.configInterface = name;
  return {ok:true, output:''};
}

function currentInterface(dev) {
  return dev.configInterface ? dev.interfaces[dev.configInterface] : null;
}

function applyInterfaceCommand(dev, original, c) {
  const i = currentInterface(dev);
  if (!i) return {output:cliError('No interface context.')};
  if (c === 'exit') { dev.mode='config'; dev.configInterface=null; return {output:''}; }
  if (c === 'end') { exitConfig(dev); return {output:''}; }
  if (c === 'do ?' || c === '?') return {output:contextHelp(dev)};
  if (c.startsWith('description ')) { i.description = original.slice(original.indexOf(' ')+1).trim(); return {output:''}; }
  if (c === 'no description') { i.description=''; return {output:''}; }
  if (c === 'shutdown') { i.admin=false; i.link=false; return {output:''}; }
  if (c === 'no shutdown') { i.admin=true; i.link=true; return {output:''}; }
  const ip = c.match(/^ip address (\S+) (\S+)$/);
  if (ip) {
    if (!isIPv4(ip[1]) || !isIPv4(ip[2])) return {output:cliError('Invalid IP address or mask.')};
    i.ip = ip[1]; i.mask = ip[2];
    const prefix = networkPrefix(i.ip, i.mask);
    if (dev.kind === 'router' && !dev.routes.some(r => r.prefix === prefix && r.type === 'C')) dev.routes.push({type:'C',prefix,next:'direct',iface:shortInterface(dev.configInterface)});
    return {output:''};
  }
  if (c === 'no ip address') { i.ip=''; i.mask=''; return {output:''}; }
  const ospfIf = c.match(/^ip ospf (\d+) area (\d+)$/); if(ospfIf){i.ospfProcess=Number(ospfIf[1]);i.ospfArea=Number(ospfIf[2]);return {output:''};}
  const hello=c.match(/^ip ospf hello-interval (\d+)$/); if(hello){i.ospfHello=Number(hello[1]);dev.ospf ||= {process:1,routerId:'0.0.0.0',networks:[],passiveInterfaces:[],hello:10,dead:40};dev.ospf.hello=Number(hello[1]);return {output:''};}
  const dead=c.match(/^ip ospf dead-interval (\d+)$/); if(dead){i.ospfDead=Number(dead[1]);dev.ospf ||= {process:1,routerId:'0.0.0.0',networks:[],passiveInterfaces:[],hello:10,dead:40};dev.ospf.dead=Number(dead[1]);return {output:''};}
  if(c==='no ip ospf'){i.ospfProcess=null;i.ospfArea=null;return {output:''};}
  const helper = c.match(/^ip helper-address (\S+)$/);
  if (helper) { if (!isIPv4(helper[1])) return {output:cliError('Invalid helper address.')}; i.helperAddresses ||= []; if (!i.helperAddresses.includes(helper[1])) i.helperAddresses.push(helper[1]); return {output:''}; }
  const noHelper = c.match(/^no ip helper-address (\S+)$/);
  if (noHelper) { i.helperAddresses=(i.helperAddresses||[]).filter(x=>x!==noHelper[1]); return {output:''}; }
  if (c === 'ip nat inside' || c === 'ip nat outside') {
    const role=c.split(' ').at(-1); i.natRole=role; dev.nat ||= {inside:[],outside:[],overload:[],translations:[]};
    const key=role === 'inside' ? 'inside' : 'outside';
    dev.nat[key] ||= [];
    if (!dev.nat[key].includes(dev.configInterface)) dev.nat[key].push(dev.configInterface);
    return {output:''};
  }
  if (c === 'no ip nat inside' || c === 'no ip nat outside') {
    const role=c.split(' ').at(-1);
    i.natRole=null; dev.nat ||= {inside:[],outside:[],overload:[],translations:[]};
    const key=role === 'inside' ? 'inside' : 'outside';
    dev.nat[key]=(dev.nat[key] || []).filter(name => name !== dev.configInterface);
    return {output:''};
  }
  const aclBind = c.match(/^ip access-group (\d+) (in|out)$/);
  if (aclBind) {
    const id = aclBind[1];
    if (!dev.acls?.[id]) return {output:cliError(`Access list ${id} does not exist.`)};
    i.aclBindings ||= {};
    i.aclBindings[aclBind[2]] = id;
    return {output:''};
  }
  const noAclBind = c.match(/^no ip access-group (\d+) (in|out)$/);
  if (noAclBind) {
    if (i.aclBindings) delete i.aclBindings[noAclBind[2]];
    return {output:''};
  }
  if (dev.kind === 'switch') {
    if (c === 'switchport mode trunk') {
      i.mode='trunk'; i.allowedVlans ||= [1]; i.nativeVlan ||= 1; return {output:''};
    }
    if (c === 'switchport mode access') { i.mode='access'; i.accessVlan ||= 1; delete i.allowedVlans; delete i.nativeVlan; return {output:''}; }
    const access = c.match(/^switchport access vlan (\d+)$/);
    if (access) { const vlan=Number(access[1]); if(vlan<1||vlan>4094)return {output:cliError('Invalid VLAN.')}; i.accessVlan=vlan; dev.vlans[vlan] ||= `VLAN${vlan}`; return {output:''}; }
    const native = c.match(/^switchport trunk native vlan (\d+)$/);
    if (native) { i.nativeVlan=Number(native[1]); dev.vlans[i.nativeVlan] ||= `VLAN${i.nativeVlan}`; return {output:''}; }
    const allowed = c.match(/^switchport trunk allowed vlan (add |remove )?(.+)$/);
    if (allowed) {
      const op=(allowed[1]||'').trim(); const vlans=parseVlanList(allowed[2], i.allowedVlans || [1]);
      if (!op) i.allowedVlans=vlans;
      else if (op === 'add') i.allowedVlans=[...new Set([...(i.allowedVlans||[]),...vlans])].sort((a,b)=>a-b);
      else i.allowedVlans=(i.allowedVlans||[]).filter(v=>!vlans.includes(v));
      vlans.forEach(v=>{dev.vlans[v] ||= `VLAN${v}`});
      return {output:''};
    }
    if (c === 'no switchport trunk allowed vlan') { i.allowedVlans=[1]; return {output:''}; }
    if (c === 'switchport port-security') { i.portSecurity ||= {maximum:1}; i.portSecurity.enabled=true; return {output:''}; }
    const psm = c.match(/^switchport port-security maximum (\d+)$/);
    if (psm) { i.portSecurity ||= {enabled:true}; i.portSecurity.enabled=true; i.portSecurity.maximum=Number(psm[1]); return {output:''}; }
    if (c === 'no switchport port-security') { i.portSecurity={enabled:false,maximum:1}; return {output:''}; }
    if (c === 'spanning-tree portfast') { i.portfast=true; return {output:''}; }
    if (c === 'no spanning-tree portfast') { i.portfast=false; return {output:''}; }
    if (c === 'spanning-tree bpduguard enable') { i.bpduguard=true; return {output:''}; }
    if (c === 'no spanning-tree bpduguard enable') { i.bpduguard=false; return {output:''}; }
    const channel = c.match(/^channel-group (\d+) mode (active|passive|on)$/);
    if (channel) {
      i.channelGroup=Number(channel[1]); i.channelMode=channel[2];
      dev.etherchannels ||= {groups:{}};
      dev.etherchannels.groups ||= {};
      dev.etherchannels.groups[channel[1]] ||= {protocol:channel[2]==='on'?'—':'LACP',ports:[],state:'SU'};
      if (!dev.etherchannels.groups[channel[1]].ports.includes(dev.configInterface)) dev.etherchannels.groups[channel[1]].ports.push(dev.configInterface);
      return {output:''};
    }
    if (c.startsWith('no channel-group')) { i.channelGroup=null; i.channelMode=null; return {output:''}; }
    const stpPriority = c.match(/^spanning-tree vlan (\d+) root primary$/);
    if (stpPriority) { dev.stp.vlanPriorities ||= {}; dev.stp.vlanPriorities[Number(stpPriority[1])]=24576; return {output:''}; }
  }
  return {output:invalidInput()};
}

function applyGlobalCommand(dev, original, c) {
  if (c === 'exit') { exitConfig(dev); return {output:''}; }
  if (c === 'end') { exitConfig(dev); return {output:''}; }
  if (c === '?') return {output:contextHelp(dev)};
  if (c.startsWith('hostname ')) { const name=original.slice(9).trim(); if(!/^[A-Za-z][A-Za-z0-9_-]*$/.test(name))return {output:cliError('Invalid hostname.')}; dev.hostname=name; return {output:''}; }
  if (c.startsWith('enable secret ')) { dev.enableSecret = original.slice(14).trim(); return {output:''}; }
  if (c === 'no enable secret') { dev.enableSecret=''; return {output:''}; }
  const domain=c.match(/^ip domain name (\S+)$/); if(domain){dev.domainName=domain[1];return {output:''};}
  if(c==='no ip domain name'){dev.domainName='';return {output:''};}
  if(c==='ip ssh version 2'){dev.sshVersion=2;return {output:''};}
  if(c==='no ip ssh version'){dev.sshVersion=null;return {output:''};}
  const stpMode=c.match(/^spanning-tree mode (rapid-pvst|pvst|mst)$/); if(stpMode){dev.spanningTreeMode=stpMode[1];return {output:''};}
  const stpPri=c.match(/^spanning-tree vlan (\d+) priority (\d+)$/); if(stpPri){dev.stp.vlanPriorities ||= {};dev.stp.vlanPriorities[Number(stpPri[1])]=Number(stpPri[2]);return {output:''};}
  const excluded=c.match(/^ip dhcp excluded-address (\S+)(?: (\S+))?$/); if(excluded){const start=excluded[1],end=excluded[2];if(!isIPv4(start)||end&&!isIPv4(end))return {output:cliError('Invalid excluded address.')};dev.dhcpExcluded ||= [];const item=end?`${start} ${end}`:start;if(!dev.dhcpExcluded.includes(item))dev.dhcpExcluded.push(item);return {output:''};}
  const line=c.match(/^line (console 0|vty (\d+) (\d+))$/); if(line){dev.lines ||= {};const isVty=line[1].startsWith('vty');const key=isVty?`vty-${line[2]}-${line[3]}`:'console-0';dev.lines[key] ||= {type:isVty?'vty':'console',start:isVty?Number(line[2]):0,end:isVty?Number(line[3]):0,login:false,transportInput:''};dev.configLine=key;dev.mode='config-line';return {output:''};}
  if (c === 'no hostname') { dev.hostname=dev.name; return {output:''}; }
  const username=c.match(/^username (\S+) privilege (\d+) secret (.+)$/);
  if(username){addUser(dev,username[1],username[2],original.slice(original.toLowerCase().indexOf('secret ')+7).trim());return {output:''};}
  const dg=c.match(/^ip default-gateway (\S+)$/); if(dg){if(!isIPv4(dg[1]))return {output:cliError('Invalid address.')};dev.defaultGateway=dg[1];return {output:''};}
  if(c==='no ip default-gateway'){dev.defaultGateway='';return {output:''};}
  const routeCmd=c.match(/^ip route (.+)$/); if(routeCmd){const args=routeCmd[1].split(/\s+/);const route=parseRouteFromArgs(args);if(!route)return {output:invalidInput()};dev.routes=dev.routes.filter(r=>r.prefix!==route.prefix);dev.routes.push({type:'S',prefix:route.prefix,next:route.next,iface:shortInterface(dev.configInterface || 'GigabitEthernet0/1'),ad:route.ad,metric:0});return {output:''};}
  const noRouteCmd=c.match(/^no ip route (.+)$/); if(noRouteCmd){const args=noRouteCmd[1].split(/\s+/);const route=parseRouteFromArgs(args);if(!route)return {output:invalidInput()};dev.routes=dev.routes.filter(r=>!(r.prefix===route.prefix && r.next===route.next));return {output:''};}
  const vlan=c.match(/^vlan (\d+)$/); if(vlan){const id=Number(vlan[1]);if(id<1||id>4094)return {output:cliError('VLAN out of range.')};dev.vlans[id] ||= `VLAN${id}`;dev.configVlan=id;dev.mode='config-vlan';return {output:''};}
  const iface=c.match(/^interface (.+)$/); if(iface)return configureInterface(dev,original.slice(original.indexOf(' ')+1));
  const ospf=c.match(/^router ospf (\d+)$/); if(ospf){dev.ospf ||= {process:Number(ospf[1]),routerId:'0.0.0.0',networks:[],passiveInterfaces:[],hello:10,dead:40};dev.ospf.process=Number(ospf[1]);dev.mode='config-router';dev.configRouter=dev.ospf.process;return {output:''};}
  const poolOriginal=original.match(/^ip dhcp pool (\S+)$/i); if(poolOriginal){const poolName=poolOriginal[1];dev.dhcpPools ||= {};dev.dhcpPools[poolName] ||= {leases:[],dns:[]};dev.configDhcpPool=poolName;dev.mode='config-dhcp';return {output:''};}
  const noPool=c.match(/^no ip dhcp pool (\S+)$/); if(noPool){delete dev.dhcpPools?.[noPool[1]];return {output:''};}
  if(c==='ipv6 unicast-routing'){dev.ipv6.forwarding=true;return {output:''};}
  if(c==='no ipv6 unicast-routing'){dev.ipv6.forwarding=false;return {output:''};}
  const ipv6Route=c.match(/^ipv6 route (\S+) (\S+)$/); if(ipv6Route){dev.ipv6.routes ||= [];dev.ipv6.routes=dev.ipv6.routes.filter(r=>!(r.prefix===ipv6Route[1]&&r.next===ipv6Route[2]));dev.ipv6.routes.push({type:'S',prefix:ipv6Route[1],next:ipv6Route[2]});return {output:''};}
  const noIpv6Route=c.match(/^no ipv6 route (\S+) (\S+)$/); if(noIpv6Route){dev.ipv6.routes=(dev.ipv6.routes||[]).filter(r=>!(r.prefix===noIpv6Route[1]&&r.next===noIpv6Route[2]));return {output:''};}
  const acl=c.match(/^access-list (\d+) (permit|deny) (\S+)(?: (\S+))?$/); if(acl){const id=acl[1];dev.acls ||= {};dev.acls[id] ||= {rules:[]};dev.acls[id].rules.push({sequence:(dev.acls[id].rules.length+1)*10,action:acl[2],source:acl[3],wildcard:acl[4],hits:0});return {output:''};}
  const noAcl=c.match(/^no access-list (\d+)$/); if(noAcl){delete dev.acls?.[noAcl[1]];return {output:''};}
  const nat=c.match(/^ip nat inside source list (\d+) interface (\S+) overload$/); if(nat){dev.nat ||= {inside:[],outside:[],overload:[],translations:[]};dev.nat.overload.push({acl:nat[1],interface:interfaceKey(nat[2])});return {output:''};}
  const noNat=c.match(/^no ip nat inside source list (\d+) interface (\S+) overload$/); if(noNat){const intf=interfaceKey(noNat[2]);dev.nat ||= {inside:[],outside:[],overload:[],translations:[]};dev.nat.overload=(dev.nat.overload||[]).filter(x=>!(String(x.acl)===noNat[1] && x.interface===intf));return {output:''};}
  if(c==='copy running-config startup-config'||c==='write memory'){dev.startupConfig=showRunningConfig(dev);return {output:'Building configuration...\n[OK]'};}
  if(c==='erase startup-config'){dev.startupConfig='';return {output:'Erasing the nvram filesystem...\n[OK]'};}
  return {output:invalidInput()};
}

function applyVlanCommand(dev, original, c) {
  if (c === 'exit') {dev.mode='config';dev.configVlan=null;return {output:''};}
  if (c === 'end') {exitConfig(dev);return {output:''};}
  if (c === '?') return {output:contextHelp(dev)};
  if (c.startsWith('name ')){dev.vlans[dev.configVlan]=original.slice(5).trim() || `VLAN${dev.configVlan}`;return {output:''};}
  if (c === 'no name'){dev.vlans[dev.configVlan]=`VLAN${dev.configVlan}`;return {output:''};}
  return {output:invalidInput()};
}

function applyRouterCommand(dev, original, c) {
  if (c === 'exit'){dev.mode='config';dev.configRouter=null;return {output:''};}
  if (c === 'end'){exitConfig(dev);return {output:''};}
  if(c==='?')return {output:contextHelp(dev)};
  if(c.startsWith('router-id ')){const id=original.slice(10).trim();if(!isIPv4(id))return {output:cliError('Invalid router ID.')};dev.ospf.routerId=id;return {output:''};}
  const network=c.match(/^network (\S+) (\S+) area (\d+)$/); if(network){const net=network[1],wild=network[2];if(!isIPv4(net)||!wildcardMask(wild))return {output:invalidInput()};dev.ospf.networks ||= [];const line=`${net} ${wild} area ${network[3]}`;if(!dev.ospf.networks.includes(line))dev.ospf.networks.push(line);return {output:''};}
  const passive=c.match(/^passive-interface (\S+)$/); if(passive){dev.ospf.passiveInterfaces ||= [];const intf=interfaceKey(passive[1]);if(!dev.ospf.passiveInterfaces.includes(intf))dev.ospf.passiveInterfaces.push(intf);return {output:''};}
  if(c.startsWith('no passive-interface ')){const intf=interfaceKey(original.slice(21).trim());dev.ospf.passiveInterfaces=(dev.ospf.passiveInterfaces||[]).filter(x=>x!==intf);return {output:''};}
  return {output:invalidInput()};
}

function applyDhcpCommand(dev, original, c) {
  if (c === 'exit'){dev.mode='config';dev.configDhcpPool=null;return {output:''};}
  if(c==='end'){exitConfig(dev);return {output:''};}
  if(c==='?')return {output:contextHelp(dev)};
  const pool=dev.dhcpPools[dev.configDhcpPool];
  if(!pool)return {output:cliError('DHCP pool context unavailable.')};
  const network=c.match(/^network (\S+) (\S+)$/);if(network){const mask=maskFromPrefixToken(network[2]);if(!mask||!isIPv4(network[1]))return {output:invalidInput()};pool.network=`${network[1]}/${maskToPrefix(mask)}`;pool.mask=mask;return {output:''};}
  const gateway=c.match(/^default-router (\S+)$/);if(gateway){if(!isIPv4(gateway[1]))return {output:cliError('Invalid router address.')};pool.defaultRouter=gateway[1];return {output:''};}
  const dns=c.match(/^dns-server (\S+)(?: (\S+))?$/);if(dns){pool.dns=[dns[1],dns[2]].filter(Boolean);return {output:''};}
  const lease=c.match(/^lease (\d+)(?: (\d+))?(?: (\d+))?$/);if(lease){pool.lease=lease.slice(1).filter(Boolean).join(' ');return {output:''};}
  return {output:invalidInput()};
}

function applyLineCommand(dev, original, c) {
  const line=dev.lines?.[dev.configLine];
  if(!line) return {output:cliError('Line context unavailable.')};
  if(c==='exit'){dev.mode='config';dev.configLine=null;return {output:''};}
  if(c==='end'){exitConfig(dev);return {output:''};}
  if(c==='?')return {output:contextHelp(dev)};
  if(c==='login'){line.login=true;return {output:''};}
  if(c==='no login'){line.login=false;return {output:''};}
  const transport=c.match(/^transport input (ssh|telnet|all)$/);if(transport){line.transportInput=transport[1];return {output:''};}
  if(c.startsWith('password ')){line.password=original.slice(9).trim();return {output:''};}
  if(c==='no password'){line.password='';return {output:''};}
  const timeout=c.match(/^exec-timeout (\d+) (\d+)$/);if(timeout){line.execTimeout=`${timeout[1]} ${timeout[2]}`;return {output:''};}
  return {output:invalidInput()};
}

export function executeCommand(previousState, deviceName, rawCommand) {
  const state = normalizeLabState(previousState);
  const dev = devOf(state, deviceName);
  const original = String(rawCommand || '').trim();
  if (!dev) return {state, output:cliError('Device not found.')};
  if (!original) return {state, output:''};
  const c = lower(original);

  if (c === 'clear') return {state, output:'__CLEAR__'};
  if (c === 'help') return {state, output:HELP};
  if (c === '?') return {state, output:contextHelp(dev)};
  if (c === 'ctrl+c') {dev.mode='exec';dev.configInterface=null;dev.configVlan=null;dev.configRouter=null;dev.configDhcpPool=null;return {state, output:''};}

  if (dev.mode === 'config-if' && c.startsWith('do ')) return {state, output:deriveShow(state,deviceName,original.slice(3)) || invalidInput()};
  if (dev.mode === 'config' && c.startsWith('do ')) return {state, output:deriveShow(state,deviceName,original.slice(3)) || invalidInput()};
  if (dev.mode === 'config-vlan' && c.startsWith('do ')) return {state, output:deriveShow(state,deviceName,original.slice(3)) || invalidInput()};
  if (dev.mode === 'config-router' && c.startsWith('do ')) return {state, output:deriveShow(state,deviceName,original.slice(3)) || invalidInput()};
  if (dev.mode === 'config-dhcp' && c.startsWith('do ')) return {state, output:deriveShow(state,deviceName,original.slice(3)) || invalidInput()};

  if (dev.mode === 'user') {
    if (c === 'enable' || c === 'en') {dev.mode='exec';return {state,output:''};}
    if (c === 'exit') return {state,output:'logout'};
    if (c.startsWith('show ')) return {state,output:'% Privileged EXEC mode required.'};
    if (c === 'configure terminal' || c === 'conf t') return {state,output:'% Privileged EXEC mode required.'};
    if (c.startsWith('ping ')) return {state,output:basePingResult(state,deviceName,original.slice(original.indexOf(' ')+1))};
    return {state,output:invalidInput()};
  }

  if (dev.mode === 'exec') {
    if (c === 'disable' || c === 'dis') {dev.mode='user';return {state,output:''};}
    if (c === 'configure terminal' || c === 'conf t' || c === 'conf terminal') {dev.mode='config';return {state,output:'Enter configuration commands, one per line. End with CNTL/Z.'};}
    if (c === 'terminal length 0' || /^terminal length \d+$/.test(c)) {dev.terminalLength=Number(c.split(' ').at(-1));return {state,output:''};}
    if (c === 'copy running-config startup-config' || c === 'write memory') {dev.startupConfig=showRunningConfig(dev);return {state,output:'Building configuration...\n[OK]'};}
    if (c === 'erase startup-config') {dev.startupConfig='';return {state,output:'Erasing the nvram filesystem...\n[OK]'};}
    if (c.startsWith('show ')) return {state,output:deriveShow(state,deviceName,original) || invalidInput()};
    if (c.startsWith('ping ')) return {state,output:basePingResult(state,deviceName,original.slice(original.indexOf(' ')+1))};
    return {state,output:invalidInput()};
  }

  if (dev.mode === 'config') return {state,output:applyGlobalCommand(dev,original,c).output};
  if (dev.mode === 'config-if') return {state,output:applyInterfaceCommand(dev,original,c).output};
  if (dev.mode === 'config-vlan') return {state,output:applyVlanCommand(dev,original,c).output};
  if (dev.mode === 'config-router') return {state,output:applyRouterCommand(dev,original,c).output};
  if (dev.mode === 'config-dhcp') return {state,output:applyDhcpCommand(dev,original,c).output};
  if (dev.mode === 'config-line') return {state,output:applyLineCommand(dev,original,c).output};
  return {state,output:invalidInput()};
}

export function networkHealth(state) {
  return baseNetworkHealth(normalizeLabState(state));
}

export function pingResult(state, deviceName, target) {
  return basePingResult(normalizeLabState(state), deviceName, target);
}

export function evaluateTask(state, taskId) {
  return baseEvaluateTask(normalizeLabState(state), taskId);
}

export function taskFixture(taskId) {
  return normalizeLabState(baseTaskFixture(taskId));
}

// Sanity exports for lightweight automated checks.
export const CLI_ENGINE_VERSION = '11.2.0';
export const COMMAND_FAMILIES = {
  exec: EXEC_SHOWS.length,
  config: 13,
  interface: 18,
  ospf: 7,
  dhcp: 6,
};
