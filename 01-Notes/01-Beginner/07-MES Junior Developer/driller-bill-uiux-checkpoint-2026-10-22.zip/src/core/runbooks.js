import { planIntent, CONFIG_INTENTS } from './device-model.js';

export const RUNBOOK_VERSION = '1.1.0';
export const RUNBOOK_STORAGE_KEY = 'drillerBill.runbooks.v52';

const BUILTIN_RUNBOOKS = [
  {
    id: 'access-switch-baseline',
    title: 'Access Switch Baseline',
    category: 'switching',
    difficulty: 'INTERMEDIATE',
    targetKind: 'switch',
    summary: 'Build a small access-switch baseline with user VLANs, access ports, an explicit trunk policy, and a persistent startup configuration.',
    description: 'A guided operational procedure for turning a clean switch into a documented access layer edge.',
    tags: ['vlan', 'access-port', 'trunk', 'baseline'],
    source: 'builtin',
    steps: [
      { id: 'vlan-users', label: 'Create USERS VLAN', summary: 'Create VLAN 10 and name it USERS.', intent: { type: 'create-vlan', fields: { id: 10, name: 'USERS' } }, verify: { type: 'vlan', id: 10, name: 'USERS' } },
      { id: 'vlan-engineering', label: 'Create ENGINEERING VLAN', summary: 'Create VLAN 20 and name it ENGINEERING.', intent: { type: 'create-vlan', fields: { id: 20, name: 'ENGINEERING' } }, verify: { type: 'vlan', id: 20, name: 'ENGINEERING' } },
      { id: 'access-users', label: 'Assign Gi0/1 to USERS', summary: 'Place the first user-facing port into VLAN 10.', intent: { type: 'assign-access-vlan', fields: { interface: 'Gi0/1', vlan: 10 } }, verify: { type: 'access-vlan', interface: 'Gi0/1', vlan: 10 } },
      { id: 'access-engineering', label: 'Assign Gi0/2 to ENGINEERING', summary: 'Place the engineering port into VLAN 20.', intent: { type: 'assign-access-vlan', fields: { interface: 'Gi0/2', vlan: 20 } }, verify: { type: 'access-vlan', interface: 'Gi0/2', vlan: 20 } },
      { id: 'trunk-uplink', label: 'Configure Gi0/24 trunk', summary: 'Use VLAN 99 as native and explicitly allow VLANs 10, 20 and 99.', intent: { type: 'set-trunk-policy', fields: { interface: 'Gi0/24', nativeVlan: 99, vlans: '10,20,99' } }, verify: { type: 'trunk-policy', interface: 'Gi0/24', nativeVlan: 99, vlans: [10, 20, 99] } },
      { id: 'save', label: 'Save startup configuration', summary: 'Persist the completed running configuration into startup-config.', intent: { type: 'save-running-config', fields: {} }, verify: { type: 'saved' } },
    ],
  },
  {
    id: 'routed-edge-recovery',
    title: 'Routed Edge Recovery',
    category: 'routing',
    difficulty: 'INTERMEDIATE',
    targetKind: 'router',
    summary: 'Restore a routed edge by enabling the uplink, adding the missing static path, and persisting the recovery.',
    description: 'A job-style recovery procedure for a router whose remote path is missing or whose uplink was administratively disabled.',
    tags: ['routing', 'static-route', 'recovery'],
    source: 'builtin',
    steps: [
      { id: 'uplink-state', label: 'Ensure R1 Gi0/1 is enabled', summary: 'Administratively enable the routed uplink.', intent: { type: 'set-interface-state', fields: { interface: 'Gi0/1', state: 'up' } }, verify: { type: 'interface-state', interface: 'Gi0/1', state: 'up' } },
      { id: 'remote-route', label: 'Add route to 10.20.20.0/24', summary: 'Restore the remote network through next-hop 10.0.12.2.', intent: { type: 'add-static-route', fields: { network: '10.20.20.0', mask: '255.255.255.0', nextHop: '10.0.12.2' } }, verify: { type: 'static-route', network: '10.20.20.0/24', nextHop: '10.0.12.2' } },
      { id: 'save', label: 'Save startup configuration', summary: 'Persist the recovered routing state.', intent: { type: 'save-running-config', fields: {} }, verify: { type: 'saved' } },
    ],
  },
  {
    id: 'switch-port-standardization',
    title: 'Switch Port Standardization',
    category: 'switching',
    difficulty: 'BASIC',
    targetKind: 'switch',
    summary: 'Apply one access VLAN consistently across a small port group, then preserve the resulting state.',
    description: 'A repeatable change procedure for standardizing a group of edge ports without typing the same configuration repeatedly.',
    tags: ['bulk-change', 'access-port', 'standardization'],
    source: 'builtin',
    steps: [
      { id: 'bulk-access', label: 'Assign Gi0/1 and Gi0/23 to USERS', summary: 'Standardize two existing edge ports into VLAN 10 using one reviewed bulk intent.', intent: { type: 'assign-access-vlan-bulk', fields: { interfaces: 'Gi0/1, Gi0/23', vlan: 10 } }, verify: { type: 'access-vlan-set', interfaces: ['Gi0/1', 'Gi0/23'], vlan: 10 } },
      { id: 'save', label: 'Save startup configuration', summary: 'Persist the standardized access-port state.', intent: { type: 'save-running-config', fields: {} }, verify: { type: 'saved' } },
    ],
  },
  {
    id: 'trunk-standardization',
    title: 'Trunk Standardization',
    category: 'switching',
    difficulty: 'INTERMEDIATE',
    targetKind: 'switch',
    summary: 'Standardize an uplink trunk with a known native VLAN and explicit allowed VLAN list, then save it.',
    description: 'A compact change-control procedure for replacing implicit trunk behavior with an explicit policy.',
    tags: ['802.1q', 'trunk', 'change-control'],
    source: 'builtin',
    steps: [
      { id: 'trunk-policy', label: 'Standardize Gi0/24', summary: 'Set trunk mode, native VLAN 99, and the explicit allow-list.', intent: { type: 'set-trunk-policy', fields: { interface: 'Gi0/24', nativeVlan: 99, vlans: '10,20,99' } }, verify: { type: 'trunk-policy', interface: 'Gi0/24', nativeVlan: 99, vlans: [10, 20, 99] } },
      { id: 'save', label: 'Save startup configuration', summary: 'Persist the trunk policy.', intent: { type: 'save-running-config', fields: {} }, verify: { type: 'saved' } },
    ],
  },
];

export const RUNBOOKS = Object.freeze(BUILTIN_RUNBOOKS.map(item => Object.freeze(item)));

function cleanText(value, fallback = '') {
  const text = String(value ?? '').trim();
  return text || fallback;
}

export function normalizeRunbook(input = {}) {
  const steps = Array.isArray(input.steps) ? input.steps : [];
  return {
    version: RUNBOOK_VERSION,
    id: cleanText(input.id, `custom-${Date.now()}`),
    title: cleanText(input.title, 'Untitled runbook'),
    category: cleanText(input.category, 'custom'),
    difficulty: cleanText(input.difficulty, 'CUSTOM'),
    targetKind: ['switch', 'router', 'any'].includes(input.targetKind) ? input.targetKind : 'any',
    summary: cleanText(input.summary, 'Custom network-engineering procedure.'),
    description: cleanText(input.description, ''),
    tags: [...new Set((Array.isArray(input.tags) ? input.tags : []).map(tag => cleanText(tag)).filter(Boolean))],
    source: input.source === 'builtin' ? 'builtin' : 'custom',
    steps: steps.map((step, index) => ({
      id: cleanText(step.id, `step-${index + 1}`),
      label: cleanText(step.label, `Step ${index + 1}`),
      summary: cleanText(step.summary, 'Review and apply this configuration change.'),
      intent: { type: cleanText(step.intent?.type), fields: { ...(step.intent?.fields || {}) } },
      verify: { type: cleanText(step.verify?.type, 'manual') },
    })),
  };
}

export function validateRunbook(runbook = {}) {
  const errors = [];
  if (!String(runbook.id || '').trim()) errors.push('Runbook ID is required.');
  if (!String(runbook.title || '').trim()) errors.push('Runbook title is required.');
  if (!Array.isArray(runbook.steps) || runbook.steps.length === 0) errors.push('A runbook must contain at least one step.');
  const seen = new Set();
  const intentById = new Map(CONFIG_INTENTS.map(intent => [intent.id, intent]));
  for (const [index, step] of (runbook.steps || []).entries()) {
    if (!step?.id) errors.push(`Step ${index + 1} is missing an ID.`);
    else if (seen.has(step.id)) errors.push(`Duplicate step ID: ${step.id}.`);
    seen.add(step.id);
    if (!step?.label) errors.push(`Step ${index + 1} needs a label.`);
    if (!step?.intent?.type) errors.push(`Step ${index + 1} needs a configuration intent.`);
    if (!step?.verify?.type) errors.push(`Step ${index + 1} needs a verification type.`);
    const definition = intentById.get(step?.intent?.type);
    if (definition?.sensitiveFields?.length) errors.push(`Step ${index + 1} uses credential-bearing intent ${step.intent.type}; run this directly from Configuration instead of storing a secret in a reusable runbook.`);
    const storedFields = step?.intent?.fields || {};
    if (definition?.sensitiveFields?.some(field => Object.prototype.hasOwnProperty.call(storedFields, field))) errors.push(`Step ${index + 1} contains a sensitive field and cannot be persisted in a runbook.`);
  }
  return { valid: errors.length === 0, errors };
}

export function verificationForIntent(intent = {}) {
  const fields = intent.fields || {};
  switch (intent.type) {
    case 'create-vlan': return { type: 'vlan', id: Number(fields.id), name: String(fields.name || '').trim() };
    case 'assign-access-vlan': return { type: 'access-vlan', interface: String(fields.interface || '').trim(), vlan: Number(fields.vlan) };
    case 'assign-access-vlan-bulk': return { type: 'access-vlan-set', interfaces: String(fields.interfaces || '').split(',').map(item => item.trim()).filter(Boolean), vlan: Number(fields.vlan) };
    case 'set-trunk-policy': return { type: 'trunk-policy', interface: String(fields.interface || '').trim(), nativeVlan: Number(fields.nativeVlan), vlans: String(fields.vlans || '').split(',').map(item => Number(item.trim())).filter(Number.isInteger) };
    case 'set-interface-state': return { type: 'interface-state', interface: String(fields.interface || '').trim(), state: String(fields.state || '') };
    case 'add-static-route': return { type: 'static-route', network: `${String(fields.network || '').trim()}/${maskToPrefix(fields.mask)}`, nextHop: String(fields.nextHop || '').trim() };
    case 'configure-ospf-process': return { type: 'ospf-process', process: Number(fields.process), routerId: String(fields.routerId || '').trim() };
    case 'add-ospf-network': return { type: 'ospf-network', process: Number(fields.process), network: String(fields.network || '').trim(), wildcard: String(fields.wildcard || '').trim(), area: Number(fields.area) };
    case 'configure-ospf-interface': return { type: 'ospf-interface', interface: String(fields.interface || '').trim(), process: Number(fields.process), area: Number(fields.area), hello: Number(fields.hello), dead: Number(fields.dead) };
    case 'set-ospf-passive-interface': return { type: 'ospf-passive', interface: String(fields.interface || '').trim(), process: Number(fields.process) };
    case 'add-standard-acl-rule': return { type: 'acl-rule', id: Number(fields.id), action: String(fields.action || ''), source: String(fields.source || '').trim(), wildcard: String(fields.wildcard || '').trim() };
    case 'apply-standard-acl': return { type: 'acl-binding', interface: String(fields.interface || '').trim(), id: Number(fields.id), direction: String(fields.direction || '') };
    case 'harden-access-port': return { type: 'access-hardening', interface: String(fields.interface || '').trim(), maximum: Number(fields.maximum) };
    case 'set-stp-mode': return { type: 'stp-mode', mode: String(fields.mode || '') };
    case 'set-stp-vlan-priority': return { type: 'stp-priority', vlan: Number(fields.vlan), priority: Number(fields.priority) };
    case 'configure-etherchannel': return { type: 'etherchannel', interfaces: String(fields.interfaces || '').split(',').map(item => item.trim()).filter(Boolean), group: Number(fields.group), mode: String(fields.mode || '') };
    case 'set-interface-nat-role': return { type: 'nat-role', interface: String(fields.interface || '').trim(), role: String(fields.role || '') };
    case 'configure-nat-overload': return { type: 'nat-overload', acl: Number(fields.acl), interface: String(fields.interface || '').trim() };
    case 'create-dhcp-pool': return { type: 'dhcp-pool', name: String(fields.name || '').trim(), network: String(fields.network || '').trim(), mask: String(fields.mask || '').trim(), gateway: String(fields.gateway || '').trim() };
    case 'exclude-dhcp-address': return { type: 'dhcp-exclusion', start: String(fields.start || '').trim(), end: String(fields.end || '').trim() };
    case 'set-hostname': return { type: 'hostname', hostname: String(fields.hostname || '').trim() };
    case 'configure-ssh': return { type: 'ssh', domain: String(fields.domain || '').trim() };
    case 'configure-vty-ssh': return { type: 'vty-ssh' };
    case 'set-default-gateway': return { type: 'default-gateway', gateway: String(fields.gateway || '').trim() };
    case 'enable-ipv6-routing': return { type: 'ipv6-forwarding' };
    case 'add-static-ipv6-route': return { type: 'ipv6-route', prefix: String(fields.prefix || '').trim(), nextHop: String(fields.nextHop || '').trim() };
    case 'save-running-config': return { type: 'saved' };
    default: return { type: 'manual' };
  }
}

function maskToPrefix(mask = '') {
  const parts = String(mask).split('.').map(Number);
  if (parts.length !== 4 || parts.some(Number.isNaN)) return '';
  let bits = 0;
  for (const part of parts) { let value = part; while (value > 0) { bits += value & 1; value >>>= 1; } }
  return bits;
}

export function planRunbookStep(runbook, stepIndex, device) {
  const step = runbook?.steps?.[stepIndex];
  if (!step) return { valid: false, errors: ['Runbook step does not exist.'], commands: [], explanations: [] };
  return planIntent(step.intent, device);
}

function normalizePort(value = '') {
  return String(value).replace(/^GigabitEthernet/i, 'Gi');
}

function vlanExists(inspection, id, name) {
  return Boolean((inspection?.vlans || []).some(row => Number(row.id) === Number(id) && String(row.name || '').toLowerCase() === String(name || '').toLowerCase()));
}

function accessVlan(inspection, port, vlan) {
  const expected = normalizePort(port);
  return Boolean((inspection?.vlans || []).some(row => Number(row.id) === Number(vlan) && (row.ports || []).some(item => normalizePort(item) === expected)));
}

function trunkPolicy(inspection, port, nativeVlan, vlans) {
  const expected = [...new Set((vlans || []).map(Number))].sort((a, b) => a - b);
  const row = (inspection?.trunks || []).find(item => normalizePort(item.interface) === normalizePort(port));
  if (!row) return false;
  const actual = [...new Set((row.allowedVlans || []).map(Number))].sort((a, b) => a - b);
  return Number(row.nativeVlan) === Number(nativeVlan) && JSON.stringify(actual) === JSON.stringify(expected);
}

function interfaceState(inspection, port, state) {
  const row = (inspection?.interfaces || []).find(item => normalizePort(item.name) === normalizePort(port));
  return Boolean(row && row.status === state && row.protocol === state);
}

function staticRoute(inspection, network, nextHop) {
  return Boolean((inspection?.routes || []).some(item => String(item.network) === String(network) && String(item.nextHop) === String(nextHop) && String(item.code || '').toUpperCase().includes('S')));
}

function interfaceRow(inspection, port) {
  return (inspection?.interfaces || []).find(item => normalizePort(item.name) === normalizePort(port));
}

function routeMatches(inspection, verify) {
  return staticRoute(inspection, verify.network, verify.nextHop);
}

function interfaceBlock(config = '', port = '') {
  const normalized = normalizePort(port);
  const long = normalized.startsWith('Gi') ? `GigabitEthernet${normalized.slice(2)}` : port;
  const lines = String(config).split(/\r?\n/);
  const start = lines.findIndex(line => {
    const value = line.trim();
    return value === `interface ${port}` || value === `interface ${normalized}` || value === `interface ${long}`;
  });
  if (start < 0) return '';
  const block = [];
  for (let i = start + 1; i < lines.length; i += 1) {
    if (/^interface\s+/i.test(lines[i].trim())) break;
    if (/^(?:line |router |ip dhcp pool |!)/i.test(lines[i].trim())) {
      if (lines[i].trim() === '!') break;
    }
    block.push(lines[i].trim());
  }
  return block.join('\n');
}

function runbookConfigText(inspection) {
  return String(inspection?.runningConfig || inspection?.config || '');
}

export function verifyRunbookStep(step, { inspection = null, diagnostics = null } = {}) {
  const verify = step?.verify || { type: 'manual' };
  let completed = false;
  let detail = 'Manual verification required.';
  switch (verify.type) {
    case 'vlan':
      completed = vlanExists(inspection, verify.id, verify.name);
      detail = completed ? `VLAN ${verify.id} is present with the expected name.` : `VLAN ${verify.id} was not observed with the expected name.`;
      break;
    case 'access-vlan':
      completed = accessVlan(inspection, verify.interface, verify.vlan);
      detail = completed ? `${verify.interface} is observed in VLAN ${verify.vlan}.` : `${verify.interface} is not observed in VLAN ${verify.vlan}.`;
      break;
    case 'access-vlan-set':
      completed = (verify.interfaces || []).every(port => accessVlan(inspection, port, verify.vlan));
      detail = completed ? `All ${verify.interfaces.length} interfaces are observed in VLAN ${verify.vlan}.` : `One or more interfaces are not observed in VLAN ${verify.vlan}.`;
      break;
    case 'trunk-policy':
      completed = trunkPolicy(inspection, verify.interface, verify.nativeVlan, verify.vlans);
      detail = completed ? `${verify.interface} matches the expected native VLAN and allow-list.` : `${verify.interface} does not yet match the expected trunk policy.`;
      break;
    case 'interface-state':
      completed = interfaceState(inspection, verify.interface, verify.state);
      detail = completed ? `${verify.interface} is operational (${verify.state}/${verify.state}).` : `${verify.interface} is not observed in the expected operational state.`;
      break;
    case 'static-route':
      completed = staticRoute(inspection, verify.network, verify.nextHop);
      detail = completed ? `${verify.network} is observed via ${verify.nextHop}.` : `${verify.network} was not observed via ${verify.nextHop}.`;
      break;
    case 'ospf-process': {
      const cfg = runbookConfigText(inspection);
      completed = cfg.includes(`router ospf ${verify.process}`) && cfg.includes(` router-id ${verify.routerId}`);
      detail = completed ? `OSPF process ${verify.process} is configured with router ID ${verify.routerId}.` : `OSPF process ${verify.process} is not observed with the expected router ID.`;
      break;
    }
    case 'ospf-network': {
      const cfg = runbookConfigText(inspection);
      completed = cfg.includes(`router ospf ${verify.process}`) && cfg.includes(` network ${verify.network} ${verify.wildcard} area ${verify.area}`);
      detail = completed ? `OSPF advertises ${verify.network} ${verify.wildcard} in area ${verify.area}.` : 'The expected OSPF network statement is not observed.';
      break;
    }
    case 'ospf-interface': {
      const row = interfaceRow(inspection, verify.interface);
      const cfg = interfaceBlock(runbookConfigText(inspection), verify.interface);
      completed = Boolean((row && Number(row.ospfProcess) === Number(verify.process) && Number(row.ospfArea) === Number(verify.area)) || (cfg && cfg.includes(`ip ospf ${Number(verify.process)} area ${Number(verify.area)}`) && cfg.includes(`ip ospf hello-interval ${Number(verify.hello)}`) && cfg.includes(`ip ospf dead-interval ${Number(verify.dead)}`)));
      detail = completed ? `${verify.interface} is associated with OSPF ${verify.process}, area ${verify.area}.` : `${verify.interface} is not observed with the expected OSPF process/area and timers.`;
      break;
    }
    case 'ospf-passive': {
      const cfg = runbookConfigText(inspection);
      completed = new RegExp(`passive-interface ${verify.interface}\\b`).test(cfg);
      detail = completed ? `${verify.interface} is configured as OSPF passive.` : `${verify.interface} is not observed as an OSPF passive interface.`;
      break;
    }
    case 'acl-rule': {
      const cfg = runbookConfigText(inspection);
      const wildcard = verify.wildcard ? ` ${verify.wildcard}` : '';
      completed = cfg.includes(`access-list ${verify.id} ${verify.action} ${verify.source}${wildcard}`);
      detail = completed ? `ACL ${verify.id} contains the expected ${verify.action} rule.` : `ACL ${verify.id} does not yet contain the expected rule.`;
      break;
    }
    case 'acl-binding': {
      const row = interfaceRow(inspection, verify.interface);
      const block = interfaceBlock(runbookConfigText(inspection), verify.interface);
      completed = Boolean((row?.aclBindings?.[verify.direction] && Number(row.aclBindings[verify.direction]) === Number(verify.id)) || block.includes(`ip access-group ${verify.id} ${verify.direction}`));
      detail = completed ? `${verify.interface} is bound to ACL ${verify.id} ${verify.direction}.` : `${verify.interface} is not observed with the expected ACL binding.`;
      break;
    }
    case 'access-hardening': {
      const row = interfaceRow(inspection, verify.interface);
      const block = interfaceBlock(runbookConfigText(inspection), verify.interface);
      completed = Boolean((row?.portSecurity?.enabled && Number(row.portSecurity.maximum) === Number(verify.maximum) && row.portfast && row.bpduguard) || (block.includes('switchport port-security') && block.includes(`switchport port-security maximum ${verify.maximum}`) && block.includes('spanning-tree portfast') && block.includes('spanning-tree bpduguard enable')));
      detail = completed ? `${verify.interface} has port security, PortFast and BPDU Guard in the device configuration.` : `${verify.interface} is not yet observed with the requested access-port hardening.`;
      break;
    }
    case 'stp-mode': {
      const cfg = runbookConfigText(inspection);
      completed = cfg.includes(`spanning-tree mode ${verify.mode}`);
      detail = completed ? `STP mode is configured as ${verify.mode}.` : `STP mode ${verify.mode} is not yet observed.`;
      break;
    }
    case 'stp-priority': {
      const cfg = runbookConfigText(inspection);
      completed = cfg.includes(`spanning-tree vlan ${verify.vlan} priority ${verify.priority}`);
      detail = completed ? `VLAN ${verify.vlan} has STP priority ${verify.priority}.` : `VLAN ${verify.vlan} is not yet observed with priority ${verify.priority}.`;
      break;
    }
    case 'etherchannel': {
      const cfg = runbookConfigText(inspection);
      completed = (verify.interfaces || []).every(port => {
        const block = interfaceBlock(cfg, port);
        return block.includes(`channel-group ${verify.group} mode ${verify.mode}`);
      });
      detail = completed ? `All requested interfaces are configured in EtherChannel ${verify.group} (${verify.mode}).` : `The requested EtherChannel membership is not fully observed.`;
      break;
    }
    case 'nat-role': {
      const row = interfaceRow(inspection, verify.interface);
      const block = interfaceBlock(runbookConfigText(inspection), verify.interface);
      completed = Boolean((row?.natRole === verify.role) || block.includes(`ip nat ${verify.role}`));
      detail = completed ? `${verify.interface} is configured as NAT ${verify.role}.` : `${verify.interface} is not observed as NAT ${verify.role}.`;
      break;
    }
    case 'nat-overload': {
      const cfg = runbookConfigText(inspection);
      const short = normalizePort(verify.interface);
      const long = short.startsWith('Gi') ? `GigabitEthernet${short.slice(2)}` : verify.interface;
      completed = cfg.includes(`ip nat inside source list ${verify.acl} interface ${short} overload`) || cfg.includes(`ip nat inside source list ${verify.acl} interface ${long} overload`);
      detail = completed ? `NAT overload is configured using ACL ${verify.acl} on ${verify.interface}.` : 'The expected NAT overload rule is not observed.';
      break;
    }
    case 'hostname':
      completed = String(inspection?.hostname || inspection?.overview?.hostname || '') === verify.hostname;
      detail = completed ? `Hostname is ${verify.hostname}.` : `Hostname is not yet observed as ${verify.hostname}.`;
      break;
    case 'ssh': {
      const cfg=runbookConfigText(inspection); completed = cfg.includes(`ip domain name ${verify.domain}`) && cfg.includes('ip ssh version 2'); detail = completed ? 'SSH version 2 and its domain are configured.' : 'SSH management configuration is incomplete.'; break;
    }
    case 'vty-ssh': { const cfg=runbookConfigText(inspection); completed = cfg.includes('line vty 0 4') && cfg.includes(' transport input ssh') && cfg.includes(' login'); detail = completed ? 'VTY 0–4 requires login and accepts SSH transport.' : 'VTY SSH restrictions are not yet observed.'; break; }
    case 'default-gateway': { const cfg=runbookConfigText(inspection); completed = cfg.includes(`ip default-gateway ${verify.gateway}`); detail = completed ? `Default gateway is ${verify.gateway}.` : 'The expected default gateway is not observed.'; break; }
    case 'ipv6-forwarding': { const cfg=runbookConfigText(inspection); completed = cfg.includes('ipv6 unicast-routing'); detail = completed ? 'IPv6 unicast routing is enabled.' : 'IPv6 unicast routing is not observed as enabled.'; break; }
    case 'ipv6-route': { const cfg=runbookConfigText(inspection); completed = cfg.includes(`ipv6 route ${verify.prefix} ${verify.nextHop}`); detail = completed ? `${verify.prefix} is routed via ${verify.nextHop}.` : 'The expected IPv6 static route is not observed.'; break; }
    case 'dhcp-pool': { const cfg=runbookConfigText(inspection); completed = cfg.includes(`ip dhcp pool ${verify.name}`) && cfg.includes(` default-router ${verify.gateway}`) && cfg.includes(` network ${verify.network} ${verify.mask}`); detail = completed ? `DHCP pool ${verify.name} is configured for ${verify.network}.` : `DHCP pool ${verify.name} is not yet observed with the expected network/gateway.`; break; }
    case 'dhcp-exclusion': { const cfg=runbookConfigText(inspection); const line=`ip dhcp excluded-address ${verify.start}${verify.end ? ` ${verify.end}` : ''}`; completed = cfg.includes(line); detail = completed ? `DHCP exclusion ${verify.start}${verify.end ? `–${verify.end}` : ''} is present.` : 'The expected DHCP exclusion is not observed.'; break; }
    case 'save-running-config':
    case 'saved':
      completed = diagnostics?.latestSnapshot?.runningStartupAligned === true;
      detail = completed ? 'Running and startup configuration are aligned.' : 'Running and startup configuration are not yet confirmed aligned.';
      break;
    case 'manual':
    default:
      completed = false;
  }
  return { type: verify.type, completed, detail };
}

export function runbookProgress(runbook, verification = {}) {
  const steps = (runbook?.steps || []).map((step, index) => ({
    id: step.id,
    index,
    label: step.label,
    completed: verification[step.id]?.completed === true,
    detail: verification[step.id]?.detail || 'Not verified yet.',
  }));
  const completed = steps.filter(step => step.completed).length;
  return {
    completed,
    total: steps.length,
    percent: steps.length ? Math.round((completed / steps.length) * 100) : 0,
    valid: steps.length > 0 && completed === steps.length,
    steps,
  };
}

export function loadCustomRunbooks(storage) {
  try {
    const raw = storage?.getItem(RUNBOOK_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.map(normalizeRunbook).filter(runbook => validateRunbook(runbook).valid) : [];
  } catch {
    return [];
  }
}

export function saveCustomRunbooks(storage, runbooks = []) {
  const custom = runbooks.filter(runbook => runbook?.source !== 'builtin').map(normalizeRunbook);
  storage?.setItem(RUNBOOK_STORAGE_KEY, JSON.stringify(custom));
  return custom;
}
