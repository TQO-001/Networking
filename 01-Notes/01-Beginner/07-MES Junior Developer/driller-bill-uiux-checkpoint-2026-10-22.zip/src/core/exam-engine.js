import { safeStorage } from '../storage.js';
import { PF_DOMAINS, PF_QUESTIONS, PF_QUESTION_FAMILIES } from '../data/question-bank.js';
import { PF_EXHIBITS, PF_EXHIBIT_QUESTIONS } from '../data/exhibit-bank.js';
import { PF_EXPANDED_FAMILIES, expandQuestionFamilies } from '../data/question-expansion-v13.js';
import { PF_EXPANDED_FAMILIES_V18, expandQuestionFamiliesV18 } from '../data/question-expansion-v18.js';
import { PF_EXHIBITS_V18, PF_EXHIBIT_QUESTIONS_V18 } from '../data/exhibit-expansion-v18.js';
import { PF_SCENARIO_FAMILIES_V19, PF_SCENARIO_QUESTIONS_V19, PF_SCENARIO_PACKS_V19 } from '../data/scenario-bank-v19.js';

const EXPANDED_VARIANTS_RAW = expandQuestionFamilies();

export const AUTHORING_STORAGE = 'pennyFarthingAuthoringV15';

export const STORAGE = {
  history: 'pennyFarthingHistoryV4',
  seen: 'pennyFarthingSeenV4',
  session: 'pennyFarthingSessionV4',
  settings: 'pennyFarthingSettingsV4',
};

export const MODE_META = {
  full: { label: 'Full Blueprint', questions: 100, minutes: 120, description: 'Balanced across the six CCNA blueprint domains.' },
  domain: { label: 'Domain Drill', questions: 20, minutes: 30, description: 'Deep practice inside one blueprint domain.' },
  sprint: { label: 'CCNA Sprint', questions: 20, minutes: 24, description: 'Fast mixed assessment. One minute and change per question.' },
  remediation: { label: 'Remediation', questions: 24, minutes: 36, description: 'Adaptive paper built from your weakest objectives.' },
  exhibits: { label: 'Exhibit Lab', questions: 20, minutes: 30, description: 'Topology, CLI, routing-table and configuration interpretation.' },
  scenario: { label: 'Scenario Form', questions: 30, minutes: 45, description: 'Case-style questions built around network evidence.' },
};

export const DIFFICULTIES = ['mixed', 'foundation', 'application', 'analysis', 'exam'];

const CONCEPTS = {
  '1.1': 'Network devices & roles','1.2':'Network topologies & architecture','1.3':'Cabling & interfaces','1.4':'Interface problems',
  '1.5':'TCP / UDP','1.6':'IPv4 addressing & subnetting','1.7':'IPv4 address types','1.8':'IPv6 addressing','1.9':'IPv6 address types',
  '1.10':'Host IP tools','1.11':'Wireless fundamentals','1.12':'VRF & routing separation','1.13':'MAC learning',
  '2.1':'VLANs & access ports','2.2':'802.1Q trunks','2.3':'Native VLAN','2.4':'EtherChannel','2.5':'STP / RSTP','2.6':'Root bridge selection',
  '2.7':'Wireless architectures','2.8':'Secure device access','2.9':'WLAN security','3.1':'Routing table','3.2':'Route selection',
  '3.3':'Static routing','3.4':'OSPF','3.5':'FHRP','4.1':'NAT','4.2':'NTP','4.3':'DNS','4.4':'SNMP','4.5':'Syslog',
  '4.6':'DHCP relay','4.7':'QoS','4.8':'SSH / VTY','4.9':'TFTP / FTP','5.1':'Threats & vulnerabilities','5.2':'Security controls',
  '5.3':'AAA','5.4':'ACLs','5.5':'Layer 2 security','5.6':'Wireless security','5.7':'DHCP snooping','6.1':'Automation benefits',
  '6.2':'Controller-based networking','6.3':'Underlay & overlay','6.4':'AI / ML concepts','6.5':'REST APIs','6.6':'Ansible / Terraform','6.7':'JSON'
};

export function conceptName(topic){ return CONCEPTS[topic] || `Objective ${topic}`; }
export function secureRandomInt(max){
  if (max <= 1) return 0;
  if (typeof window !== 'undefined' && window.crypto?.getRandomValues) {
    const a = new Uint32Array(1); const limit = Math.floor(0x100000000 / max) * max;
    do window.crypto.getRandomValues(a); while (a[0] >= limit);
    return a[0] % max;
  }
  return Math.floor(Math.random()*max);
}
export function shuffle(items){
  const a=[...items]; for(let i=a.length-1;i>0;i--){const j=secureRandomInt(i+1);[a[i],a[j]]=[a[j],a[i]];} return a;
}
export function formatDuration(ms){const s=Math.max(0,Math.floor(ms/1000)); const h=Math.floor(s/3600),m=Math.floor((s%3600)/60),x=s%60; return [h,m,x].map(v=>String(v).padStart(2,'0')).join(':');}
export function formatShortDuration(seconds){const m=Math.floor(seconds/60);const s=seconds%60;return `${m}m ${String(s).padStart(2,'0')}s`;}
export function formatDate(iso){return new Date(iso).toLocaleString([], {dateStyle:'medium',timeStyle:'short'});}
export function readStorage(key,fallback){try{if(false)return fallback;return JSON.parse(safeStorage.getItem(key)||JSON.stringify(fallback));}catch{return fallback;}}
export function writeStorage(key,value){try{if(false)return false;safeStorage.setItem(key,JSON.stringify(value));return true;}catch{return false;}}
export function getAuthoringQuestions(){
  try {
    const raw = JSON.parse(safeStorage.getItem(AUTHORING_STORAGE) || '[]');
    if (!Array.isArray(raw)) return [];
    const out=[];
    for (const family of raw) {
      if (!family?.published || !Array.isArray(family.variants)) continue;
      family.variants.forEach((v, index) => {
        const id = String(v.questionId || v.id || `${family.id}-V${index+1}`);
        const q = String(v.q || v.prompt || '').trim();
        const options = Array.isArray(v.options) ? v.options.map(x=>String(x ?? '')) : [];
        const answer = Array.isArray(v.answer) ? v.answer.map(Number).filter(Number.isInteger) : [];
        if (!q || options.length !== 4 || !answer.length || answer.some(i=>i<0||i>=4)) return;
        out.push(enrich({
          ...v, id, questionId:id, familyId:String(family.id), variant:index+1,
          domain:String(family.domain || v.domain || '1'), topic:String(family.topic || v.topic || '1.1'),
          concept:family.concept || v.concept || conceptName(String(family.topic || '1.1')),
          q, prompt:q, options, answer,
          type:v.type || (answer.length>1 ? 'multi' : 'single'),
          published:true, authoring:true
        }));
      });
    }
    return out;
  } catch { return []; }
}

export function getAuthoringFamilies(){
  try {
    const raw = JSON.parse(safeStorage.getItem(AUTHORING_STORAGE) || '[]');
    return Array.isArray(raw) ? raw : [];
  } catch { return []; }
}

export function getCorrect(q,selected){const a=[...(selected||[])].sort((x,y)=>x-y),b=[...q.answer].sort((x,y)=>x-y);return a.length===b.length&&a.every((v,i)=>v===b[i]);}

export function difficultyOf(q){
  if (q.difficulty) return q.difficulty;
  const text=`${q.q||''} ${q.explanation||''}`.toLowerCase();
  if (q.topic==='1.6' || /subnet|cidr|longest-prefix|administrative distance|route lookup/.test(text)) return 'analysis';
  if (q.type==='multi' || q.exhibit || /troubleshoot|scenario|configuration|table|output/.test(text)) return 'analysis';
  if (q.topic?.startsWith('3.') || q.topic?.startsWith('6.') || /ospf|routing|static route|json|rest|ansible|terraform/.test(text)) return 'application';
  return 'foundation';
}

function enrich(q){const familyId=q.familyId||String(q.id||'').replace(/-V\d+$/,''); return {...q, familyId, concept:q.concept||conceptName(q.topic), difficulty:q.difficulty||difficultyOf(q), presentation:q.presentation||(q.exhibit?'exhibit':'standard'), tags:q.tags||[], cognitiveLevel:q.cognitiveLevel||'knowledge', misconception:q.misconception||null, generated:!!q.generated};}

function subnetMask(prefix){const mask=(0xffffffff << (32-prefix))>>>0;return [(mask>>>24)&255,(mask>>>16)&255,(mask>>>8)&255,mask&255].join('.');}
function ipToInt(ip){return ip.split('.').reduce((v,o)=>(v<<8)+Number(o),0)>>>0;}
function intToIp(x){return [24,16,8,0].map(s=>(x>>>s)&255).join('.');}
function randPrivateBase(){const a=10+secureRandomInt(10),b=secureRandomInt(256),c=secureRandomInt(256);return ipToInt(`${a}.${b}.${c}.0`);}
function generateSubnetQuestions(count=20){
  const variants = [
    (ip,p)=>`A host is configured as ${ip}/${p}. Which subnet contains the host?`,
    (ip,p)=>`Determine the network boundary for host ${ip}/${p}. Which prefix is correct?`,
    (ip,p)=>`An engineer is validating ${ip}/${p}. Identify the containing IPv4 subnet.`,
    (ip,p)=>`Which network should be associated with the host address ${ip}/${p}?`,
    (ip,p)=>`Use the prefix length to calculate the subnet for ${ip}/${p}.`
  ];
  const qs=[]; const prefixes=[25,26,27,28,29];
  for(let i=0;i<count;i++){
    const p=prefixes[secureRandomInt(prefixes.length)]; const block=2**(32-p); const base=randPrivateBase();
    const network=(base + secureRandomInt(Math.floor(256/block))*block)>>>0; const host=network+1+secureRandomInt(block-2);
    const candidates=shuffle([network, network+block, network-block, network+2*block].filter(x=>x>=0&&x<=0xffffffff).slice(0,4));
    const unique=[]; for(const x of candidates){if(!unique.includes(x))unique.push(x);} while(unique.length<4) unique.push((network+unique.length*block)>>>0);
    const answer=unique.findIndex(x=>x===network);
    const id=`SUBNET-${Date.now()}-${i}-${secureRandomInt(9999)}`;
    const prompt=variants[secureRandomInt(variants.length)](intToIp(host),p);
    qs.push(enrich({domain:'1',topic:'1.6',id,questionId:id,variant:1,prompt, q:prompt, options:unique.map(x=>`${intToIp(x)}/${p}`),answer:[answer],explanation:`A /${p} has a block size of ${block} addresses. The subnet containing ${intToIp(host)} begins at ${intToIp(network)} and ends at ${intToIp(network+block-1)}.`,generated:true}));
  }
  return qs;
}

export const BASE_QUESTIONS = PF_QUESTIONS.map(enrich);
export const EXHIBIT_QUESTIONS = PF_EXHIBIT_QUESTIONS.map(enrich);
export const EXPANDED_FAMILIES = PF_EXPANDED_FAMILIES.map(enrich);
export const EXPANDED_QUESTIONS = EXPANDED_VARIANTS_RAW.map(enrich);
export const V18_EXPANDED_FAMILIES = PF_EXPANDED_FAMILIES_V18.map(enrich);
export const V18_EXPANDED_QUESTIONS = expandQuestionFamiliesV18().map(enrich);
export const V18_EXHIBITS = PF_EXHIBITS_V18.map(enrich);
export const V18_EXHIBIT_QUESTIONS = PF_EXHIBIT_QUESTIONS_V18.map(enrich);
export const V19_SCENARIO_FAMILIES = PF_SCENARIO_FAMILIES_V19.map(enrich);
export const V19_SCENARIO_QUESTIONS = PF_SCENARIO_QUESTIONS_V19.map(enrich);
export const ALL_EXHIBIT_QUESTIONS = [...EXHIBIT_QUESTIONS,...V18_EXHIBIT_QUESTIONS];
export const ALL_STATIC_QUESTIONS = [...BASE_QUESTIONS,...ALL_EXHIBIT_QUESTIONS,...EXPANDED_QUESTIONS,...V18_EXPANDED_QUESTIONS,...V19_SCENARIO_QUESTIONS];
export const FAMILIES = [...PF_QUESTION_FAMILIES.map(enrich),...PF_EXHIBITS.map(enrich),...EXPANDED_FAMILIES,...V18_EXPANDED_FAMILIES,...V18_EXHIBITS,...V19_SCENARIO_FAMILIES];

const SCENARIO_PACKS = [
  {id:'SC-01',title:'Branch VLAN outage',brief:'Users on VLAN 20 can reach local devices but lose access to a remote application after a switch change.',families:['EX-NA-01','EX-NA-04','EX-IP-05']},
  {id:'SC-02',title:'Campus redundancy event',brief:'A campus access block reports intermittent connectivity after a maintenance window changed Layer 2 behavior.',families:['EX-NA-02','EX-NA-03','EX-NA-01']},
  {id:'SC-03',title:'Routing table anomaly',brief:'A router has multiple candidate paths to an application subnet and the operations team needs to verify forwarding.',families:['EX-IP-01','EX-IP-02','EX-IP-06']},
  {id:'SC-04',title:'OSPF neighbor incident',brief:'A routed link is up, but the expected OSPF relationship and learned route are not behaving as planned.',families:['EX-IP-03','EX-IP-04','EX-IP-01']},
  {id:'SC-05',title:'Remote branch DHCP failure',brief:'New clients at a routed branch are not receiving addresses from the centralized DHCP service.',families:['EX-IS-02','EX-NF-01','EX-IP-05']},
  {id:'SC-06',title:'Internet edge translation',brief:'Internal hosts reach the edge router, but the outside network sees unexpected source addressing.',families:['EX-IS-01','EX-IP-05','EX-SEC-01']},
  {id:'SC-07',title:'Access-layer security review',brief:'A switch port is under review after an endpoint policy change and the security team wants to validate Layer 2 controls.',families:['EX-SEC-01','EX-SEC-02','EX-SEC-05']},
  {id:'SC-08',title:'Wireless rollout',brief:'A new office is being deployed with controller-managed WLANs and a constrained radio environment.',families:['EX-SEC-03','EX-NF-04','EX-AUTO-01']},
  {id:'SC-09',title:'Automation operations',brief:'The network team is integrating an API-driven workflow with machine-readable state and declarative tooling.',families:['EX-AUTO-02','EX-AUTO-03','EX-AUTO-04']},
  {id:'SC-10',title:'Identity and edge control',brief:'An administrator is reviewing who can use privileged device functions while keeping endpoint access restricted.',families:['EX-SEC-04','EX-SEC-05','EX-NA-03']},
];

const variantsByFamily = new Map();
for (const q of [...ALL_EXHIBIT_QUESTIONS, ...V19_SCENARIO_QUESTIONS]) {
  const familyKey = q.familyId || String(q.id).replace(/-V\d+$/, '');
  if (!variantsByFamily.has(familyKey)) variantsByFamily.set(familyKey, []);
  variantsByFamily.get(familyKey).push(enrich(q));
}

function buildScenarioQuestions({count=30,history=[],seen={},adaptive=true,coldStart=false,difficulty='mixed'}={}) {
  const objective = objectiveStats(history);
  const packScore = (pack) => 1 + pack.families.reduce((sum, familyId) => {
    const family = variantsByFamily.get(familyId)?.[0];
    const stat = family ? objective[family.topic] : null;
    if (!adaptive || !stat) return sum;
    return sum + (stat.pct < 60 ? 2.2 : stat.pct < 75 ? 1.3 : 0.2);
  }, 0);
  const preferredPacks = PF_SCENARIO_PACKS_V19;
  const packs = shuffle(preferredPacks).sort((a,b) => packScore(b)-packScore(a)).slice(0, Math.ceil(count/5));
  const output = [];
  const usedQuestionIds = new Set();
  for (const pack of packs) {
    let step = 0;
    for (const familyId of pack.families) {
      const variants = variantsByFamily.get(familyId) || [];
      if (!variants.length) continue;
      const unseen = variants.filter(q => coldStart || !seen[q.questionId]);
      const difficultyPool = (unseen.length ? unseen : variants).filter(q => difficulty === 'mixed' || q.difficulty === difficulty);
      const basePool = difficultyPool.length ? difficultyPool : (unseen.length ? unseen : variants);
      const freshPool = basePool.filter(q => !usedQuestionIds.has(q.questionId));
      const pool = freshPool.length ? freshPool : variants.filter(q => !usedQuestionIds.has(q.questionId));
      if (!pool.length) continue;
      const q = {...pool[secureRandomInt(pool.length)]};
      output.push(randomizeChoices({
        ...q,
        scenarioId:pack.id,
        scenarioTitle:pack.title,
        scenarioBrief:pack.brief,
        scenarioStep:++step,
        scenarioTotal:pack.families.length,
        presentation:'scenario'
      }));
      usedQuestionIds.add(q.questionId);
      if (output.length >= count) break;
    }
    if (output.length >= count) break;
  }
  if (output.length < count) {
    const custom = getAuthoringQuestions().filter(q => !usedQuestionIds.has(q.questionId));
    const fallback = shuffle([...custom, ...V19_SCENARIO_QUESTIONS, ...ALL_EXHIBIT_QUESTIONS]).filter(q => !usedQuestionIds.has(q.questionId));
    for (const source of fallback) {
      if (output.length >= count) break;
      const q = {...enrich(source), scenarioId:source.authoring?'SC-AUTHORED':'SC-FILL', scenarioTitle:source.authoring?(source.concept||'Authored case'):'Network evidence review', scenarioBrief:source.authoring?'Additional authored evidence drawn from the local question studio.':'Additional mixed evidence drawn from the CCNA exhibit bank.', scenarioStep:1, scenarioTotal:1, presentation:'scenario'};
      usedQuestionIds.add(q.questionId);
      output.push(randomizeChoices(q));
    }
  }
  return output.slice(0,count);
}

export function buildQuestionPool({includeExhibits=true, generatedSubnets=0}={}){
  const authored = getAuthoringQuestions();
  return [...BASE_QUESTIONS,...EXPANDED_QUESTIONS,...V18_EXPANDED_QUESTIONS,...V19_SCENARIO_QUESTIONS,(includeExhibits?ALL_EXHIBIT_QUESTIONS:[]),authored,generateSubnetQuestions(generatedSubnets)].flat();
}

export function weightedCounts(total){
  const exact=PF_DOMAINS.map(d=>({...d,raw:total*d.weight/100}));
  const base=exact.map(d=>({...d,count:Math.floor(d.raw),frac:d.raw-Math.floor(d.raw)})); let remaining=total-base.reduce((s,d)=>s+d.count,0);
  base.sort((a,b)=>b.frac-a.frac); for(let i=0;i<remaining;i++) base[i%base.length].count+=1;
  return Object.fromEntries(base.map(d=>[d.id,d.count]));
}

export function objectiveStats(history){
  const stats={};
  for(const attempt of history){for(const q of (attempt.questions||[])){
    const selected=attempt.answers?.[q.questionId]||[]; const ok=getCorrect(q,selected); const key=q.topic;
    if(!stats[key])stats[key]={objective:key,concept:conceptName(key),correct:0,total:0,recentWrong:0,lastSeen:attempt.date};
    stats[key].total++; if(ok)stats[key].correct++;else stats[key].recentWrong++; stats[key].lastSeen=attempt.date;
  }}
  return Object.fromEntries(Object.values(stats).map(x=>[x.objective,{...x,pct:Math.round(x.correct/x.total*100)}]));
}
export function familyStats(history){
  const stats={}; for(const attempt of history){for(const q of (attempt.questions||[])){
    const key=q.id; const ok=getCorrect(q,attempt.answers?.[q.questionId]||[]);
    if(!stats[key])stats[key]={id:key,topic:q.topic,concept:q.concept||conceptName(q.topic),attempts:0,correct:0,wrong:0,lastSeen:attempt.date};
    stats[key].attempts++; ok?stats[key].correct++:stats[key].wrong++; stats[key].lastSeen=attempt.date;
  }} return stats;
}

function weightedPick(candidates, count, history, seen, opts={}){
  const oStats=objectiveStats(history), fStats=familyStats(history), picked=[], usedFamilies=new Set();
  const pool=candidates.map(q=>{
    const seenWeight=opts.coldStart?1:(seen[q.questionId]?0.22:1.45);
    const op=oStats[q.topic]; const weak=opts.adaptive&&op?(op.pct<60?3.1:op.pct<75?2.0:op.pct<90?0.95:0.45):1;
    const fs=fStats[q.id]; const familyBoost=opts.adaptive&&fs?.wrong>fs?.correct?1.5:1;
    const diff=opts.difficulty==='mixed'?1:(q.difficulty===opts.difficulty?3:0.35);
    const exhibit=opts.exhibitOnly?(q.exhibit?3:0.1):1;
    const novelty=(q.id?.includes('-V13-')||q.id?.includes('V18-'))?1.12:1;
    return {q,weight:seenWeight*weak*familyBoost*diff*exhibit*novelty};
  });
  while(picked.length<Math.min(count,pool.length)){
    let eligible=pool.filter(x=>!picked.includes(x.q));
    if(usedFamilies.size<Math.floor(count*.55)) eligible=eligible.filter(x=>!usedFamilies.has(x.q.familyId||x.q.id)) || eligible;
    if(!eligible.length)break;
    const total=eligible.reduce((s,x)=>s+x.weight,0); let cursor=(secureRandomInt(1_000_000)/1_000_000)*total; let choice=eligible[eligible.length-1];
    for(const item of eligible){cursor-=item.weight;if(cursor<=0){choice=item;break;}}
    picked.push(choice.q); usedFamilies.add(choice.q.familyId||choice.q.id);
  }
  return picked.map(q=>randomizeChoices(q));
}
export function randomizeChoices(q){const opts=shuffle(q.options.map((text,index)=>({text,index})));const answer=opts.map((o,i)=>q.answer.includes(o.index)?i:-1).filter(i=>i>=0);return {...q,options:opts.map(o=>o.text),answer};}


export function normalizeExhibit(exhibit){
  if(!exhibit) return null;
  const raw=exhibit.data;
  const data=raw && typeof raw==='object' && !Array.isArray(raw) ? raw : {};
  const code=exhibit.code ?? (typeof raw==='string'?raw:data.code);
  const rows=exhibit.rows ?? data.rows ?? (Array.isArray(raw) && ['address-table','stp-table','wlan-table','channel-plan','packet-sequence','mac-table','interface-table'].includes(exhibit.type) ? raw : undefined);
  const nodes=exhibit.nodes ?? data.nodes ?? (Array.isArray(raw) && ['topology','frame-flow','aaa-flow'].includes(exhibit.type) ? raw : undefined);
  const layers=exhibit.layers ?? data.layers;
  return {...exhibit, code, rows, nodes, layers, tabs:exhibit.tabs ?? data.tabs};
}

export function makeExam({mode,domain='all',history=[],seen={},adaptive=true,coldStart=false,difficulty='mixed',objectiveFilter=null}){
  const meta=MODE_META[mode]||MODE_META.full;
  let pool=buildQuestionPool({includeExhibits:true,generatedSubnets:mode==='exhibits'||mode==='scenario'?0:Math.max(0,Math.ceil(meta.questions*.35))});
  if(mode==='exhibits'){pool=ALL_EXHIBIT_QUESTIONS;}
  if(mode==='scenario'){
    return buildScenarioQuestions({count:meta.questions,history,seen,adaptive,coldStart,difficulty});
  }
  if(mode==='domain') pool=pool.filter(q=>q.domain===domain);
  if(objectiveFilter?.length) pool=pool.filter(q=>objectiveFilter.includes(q.topic));
  if(mode==='remediation') adaptive=true;
  if(mode==='full'||mode==='sprint'){
    const counts=weightedCounts(meta.questions), result=[];
    for(const d of PF_DOMAINS){result.push(...weightedPick(pool.filter(q=>q.domain===d.id),counts[d.id],history,seen,{adaptive,coldStart,difficulty}));}
    return shuffle(result).slice(0,meta.questions);
  }
  return weightedPick(pool,meta.questions,history,seen,{adaptive,coldStart,difficulty,exhibitOnly:mode==='exhibits'||mode==='scenario'});
}

export function modeLabel(mode,domain){if(mode==='domain')return `${PF_DOMAINS.find(d=>d.id===domain)?.name||'Domain'} Drill`;return MODE_META[mode]?.label||'Assessment';}
export function computeResult({mode,domain,questions,answers,review,startedAt,autoSubmitted=false,scenarioCount=0}){
  const domains={}; for(const d of PF_DOMAINS){const qs=questions.filter(q=>q.domain===d.id);if(!qs.length)continue;const correct=qs.filter(q=>getCorrect(q,answers[q.questionId])).length;domains[d.id]={id:d.id,name:d.name,total:qs.length,correct,pct:Math.round(correct/qs.length*100),weight:d.weight};}
  const correct=questions.filter(q=>getCorrect(q,answers[q.questionId])).length;
  const result={id:`PF-${Date.now()}`,date:new Date().toISOString(),mode,domain,total:questions.length,correct,pct:Math.round(correct/questions.length*100),domains,timeUsed:Math.round(Math.max(0,Date.now()-(startedAt||Date.now()))/1000),autoSubmitted,questions,answers,review:[...review],scenarioCount};
  return result;
}
