export const UNIFIED_WORKFLOW_VERSION = '1.0.0';
export const UNIFIED_WORKFLOW_STORAGE_KEY = 'drillerBill.unifiedWorkflow.v1';
export const UNIFIED_WORKFLOW_EVENT = 'driller-bill:unified-workflow';

export const WORKFLOW_STAGES = [
  { id: 'context', label: 'Context', view: 'knowledge', description: 'Establish the concept, symptom or operational goal.' },
  { id: 'learn', label: 'Learn', view: 'drills', description: 'Study or practice the relevant network behavior.' },
  { id: 'investigate', label: 'Investigate', view: 'troubleshooting', description: 'Collect evidence and test hypotheses.' },
  { id: 'plan', label: 'Plan change', view: 'config', description: 'Translate the intended change into a typed, reviewable plan.' },
  { id: 'operate', label: 'Operate', view: 'runbooks', description: 'Execute an approved procedure or operational sequence.' },
  { id: 'verify', label: 'Verify', view: 'devices', description: 'Confirm the expected state and preserve evidence.' },
  { id: 'document', label: 'Document', view: 'twin', description: 'Capture what changed, why, and what was verified.' },
];

export const WORKFLOW_TEMPLATES = {
  'learn-to-operate': {
    id: 'learn-to-operate',
    title: 'Learn → Operate',
    description: 'Start from a network concept, practice it, then carry the same context into configuration and operations.',
    stages: ['context', 'learn', 'plan', 'operate', 'verify', 'document'],
  },
  'troubleshoot-to-recovery': {
    id: 'troubleshoot-to-recovery',
    title: 'Troubleshoot → Recover',
    description: 'Move from an observed symptom through evidence, diagnosis, remediation and verification.',
    stages: ['context', 'investigate', 'plan', 'operate', 'verify', 'document'],
  },
  'device-change': {
    id: 'device-change',
    title: 'Device Change',
    description: 'Inspect a device, plan a typed change, execute the approved procedure and capture the result.',
    stages: ['context', 'plan', 'operate', 'verify', 'document'],
  },
  'engineering-case': {
    id: 'engineering-case',
    title: 'Engineering Case',
    description: 'A flexible engineering thread that can move between learning, diagnosis, configuration and documentation.',
    stages: ['context', 'learn', 'investigate', 'plan', 'operate', 'verify', 'document'],
  },
};

const STAGE_MAP = new Map(WORKFLOW_STAGES.map(stage => [stage.id, stage]));
const TEMPLATE_MAP = new Map(Object.values(WORKFLOW_TEMPLATES).map(template => [template.id, template]));
const uid = (prefix = 'wf') => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
const now = () => new Date().toISOString();

function emitWorkflowEvent() {
  try { window.dispatchEvent(new Event(UNIFIED_WORKFLOW_EVENT)); } catch {}
}

function safeParse(raw, fallback) {
  try {
    const parsed = raw ? JSON.parse(raw) : fallback;
    return parsed;
  } catch {
    return fallback;
  }
}

export function stageDefinition(id) {
  return STAGE_MAP.get(id) || null;
}

export function templateDefinition(id) {
  return TEMPLATE_MAP.get(id) || WORKFLOW_TEMPLATES['engineering-case'];
}

export function normalizeWorkflow(input = {}) {
  const template = templateDefinition(input.templateId);
  const rawStages = input.stages?.length ? input.stages : template.stages;
  const stages = rawStages.map((rawStage, index) => {
    const stageId = typeof rawStage === 'string' ? rawStage : rawStage?.id;
    const stage = stageDefinition(stageId) || stageDefinition('context');
    const incoming = typeof rawStage === 'object' ? rawStage : (typeof input.stageState?.[stage.id] === 'object' ? input.stageState[stage.id] : {});
    return {
      id: stage.id,
      status: incoming.status || (index === 0 ? 'active' : 'pending'),
      startedAt: incoming.startedAt || null,
      completedAt: incoming.completedAt || null,
      note: String(incoming.note || ''),
      artifact: incoming.artifact || null,
    };
  });
  const normalized = {
    version: UNIFIED_WORKFLOW_VERSION,
    id: input.id || uid(),
    templateId: template.id,
    title: String(input.title || template.title),
    description: String(input.description || template.description),
    source: input.source || null,
    target: input.target || null,
    createdAt: input.createdAt || now(),
    updatedAt: input.updatedAt || now(),
    completedAt: input.completedAt || null,
    status: input.status || 'active',
    currentStage: input.currentStage && stages.some(stage => stage.id === input.currentStage) ? input.currentStage : stages[0]?.id || 'context',
    stages,
    notes: Array.isArray(input.notes) ? input.notes.slice(-50) : [],
    timeline: Array.isArray(input.timeline) ? input.timeline.slice(-80) : [],
  };
  return ensureStageProgress(normalized);
}

export function ensureStageProgress(workflow) {
  const stages = workflow.stages || [];
  const completed = stages.filter(stage => stage.status === 'complete').length;
  const percent = stages.length ? Math.round((completed / stages.length) * 100) : 0;
  const firstOpen = stages.find(stage => stage.status !== 'complete');
  const status = stages.length && completed === stages.length ? 'complete' : 'active';
  return {
    ...workflow,
    percent,
    status,
    currentStage: firstOpen?.id || stages.at(-1)?.id || workflow.currentStage || 'context',
    completedAt: status === 'complete' ? (workflow.completedAt || now()) : null,
  };
}

export function createWorkflow(options = {}) {
  const template = templateDefinition(options.templateId);
  const base = normalizeWorkflow({
    templateId: template.id,
    title: options.title || template.title,
    description: options.description || template.description,
    source: options.source || null,
    target: options.target || null,
    stages: template.stages,
  });
  const sourceLabel = options.source?.title || options.source?.label || options.source?.id;
  base.timeline.push({ at: now(), type: 'created', stage: base.currentStage, text: sourceLabel ? `Workflow created from ${sourceLabel}.` : 'Workflow created.' });
  return base;
}

export function loadWorkflowStore(storage) {
  const fallback = { version: UNIFIED_WORKFLOW_VERSION, active: null, history: [] };
  const store = safeParse(storage?.getItem(UNIFIED_WORKFLOW_STORAGE_KEY), fallback);
  return {
    version: UNIFIED_WORKFLOW_VERSION,
    active: store?.active ? normalizeWorkflow(store.active) : null,
    history: Array.isArray(store?.history) ? store.history.map(normalizeWorkflow).slice(-20) : [],
  };
}

export function saveWorkflowStore(storage, store) {
  const normalized = {
    version: UNIFIED_WORKFLOW_VERSION,
    active: store?.active ? normalizeWorkflow(store.active) : null,
    history: Array.isArray(store?.history) ? store.history.map(normalizeWorkflow).slice(-20) : [],
  };
  storage?.setItem(UNIFIED_WORKFLOW_STORAGE_KEY, JSON.stringify(normalized));
  emitWorkflowEvent();
  return normalized;
}

export function getActiveWorkflow(storage) {
  return loadWorkflowStore(storage).active;
}

export function startWorkflow(storage, options = {}) {
  const workflow = createWorkflow(options);
  const store = loadWorkflowStore(storage);
  const next = { ...store, active: workflow };
  saveWorkflowStore(storage, next);
  return workflow;
}

export function updateWorkflow(storage, updater) {
  const store = loadWorkflowStore(storage);
  if (!store.active) return store;
  const updated = typeof updater === 'function' ? updater(store.active) : updater;
  const normalized = ensureStageProgress({ ...store.active, ...updated, updatedAt: now() });
  const next = { ...store, active: normalized };
  if (normalized.status === 'complete') {
    next.history = [...store.history, normalized].slice(-20);
    next.active = null;
  }
  saveWorkflowStore(storage, next);
  return normalized;
}

export function completeWorkflowStage(storage, stageId, options = {}) {
  const result = updateWorkflow(storage, current => {
    const stages = current.stages.map(stage => {
      if (stage.id !== stageId) return stage;
      return {
        ...stage,
        status: 'complete',
        completedAt: now(),
        startedAt: stage.startedAt || now(),
        note: String(options.note || stage.note || ''),
        artifact: options.artifact ?? stage.artifact ?? null,
      };
    });
    const nextStage = stages.find(stage => stage.status !== 'complete');
    return {
      ...current,
      currentStage: nextStage?.id || current.currentStage,
      stages,
      timeline: [...current.timeline, { at: now(), type: 'stage-complete', stage: stageId, text: options.timelineText || `Completed ${stageDefinition(stageId)?.label || stageId}.` }].slice(-80),
    };
  });
  return result;
}

export function activateWorkflowStage(storage, stageId, options = {}) {
  return updateWorkflow(storage, current => {
    const valid = current.stages.some(stage => stage.id === stageId);
    if (!valid) return current;
    const stages = current.stages.map(stage => stage.id === stageId && stage.status === 'pending'
      ? { ...stage, status: 'active', startedAt: now() }
      : stage);
    return {
      ...current,
      currentStage: stageId,
      stages,
      timeline: [...current.timeline, { at: now(), type: 'stage-opened', stage: stageId, text: options.text || `Opened ${stageDefinition(stageId)?.label || stageId}.` }].slice(-80),
    };
  });
}

export function attachWorkflowArtifact(storage, artifact, options = {}) {
  return updateWorkflow(storage, current => {
    const stageId = options.stageId || current.currentStage;
    const stages = current.stages.map(stage => stage.id === stageId
      ? { ...stage, artifact: { ...(stage.artifact || {}), ...artifact }, status: stage.status === 'pending' ? 'active' : stage.status, startedAt: stage.startedAt || now() }
      : stage);
    return {
      ...current,
      target: options.target || current.target,
      stages,
      timeline: [...current.timeline, { at: now(), type: 'artifact', stage: stageId, text: options.text || `Attached context to ${stageDefinition(stageId)?.label || stageId}.` }].slice(-80),
    };
  });
}

export function addWorkflowNote(storage, note, stageId = null) {
  const clean = String(note || '').trim();
  if (!clean) return getActiveWorkflow(storage);
  return updateWorkflow(storage, current => ({
    ...current,
    notes: [...current.notes, { at: now(), stage: stageId || current.currentStage, text: clean }].slice(-50),
  }));
}

export function advanceWorkflow(storage) {
  const active = getActiveWorkflow(storage);
  if (!active) return null;
  return completeWorkflowStage(storage, active.currentStage, { timelineText: `Completed ${stageDefinition(active.currentStage)?.label || active.currentStage}.` });
}

export function abandonWorkflow(storage) {
  const store = loadWorkflowStore(storage);
  if (!store.active) return store;
  const abandoned = {
    ...store.active,
    status: 'abandoned',
    updatedAt: now(),
    completedAt: null,
    timeline: [...store.active.timeline, { at: now(), type: 'abandoned', text: 'Workflow abandoned.' }].slice(-80),
  };
  const next = { ...store, active: null, history: [...store.history, abandoned].slice(-20) };
  saveWorkflowStore(storage, next);
  return next;
}

export function progressForWorkflow(workflow) {
  const normalized = workflow ? ensureStageProgress(normalizeWorkflow(workflow)) : null;
  if (!normalized) return { completed: 0, total: 0, percent: 0, current: null };
  return {
    completed: normalized.stages.filter(stage => stage.status === 'complete').length,
    total: normalized.stages.length,
    percent: normalized.percent,
    current: normalized.stages.find(stage => stage.id === normalized.currentStage) || normalized.stages.find(stage => stage.status !== 'complete') || null,
  };
}

export function stageForView(view) {
  const map = { knowledge: 'context', drills: 'learn', troubleshooting: 'investigate', config: 'plan', runbooks: 'operate', devices: 'verify', twin: 'document' };
  return map[view] || null;
}

export function buildWorkflowContext(workflow) {
  if (!workflow) return null;
  const progress = progressForWorkflow(workflow);
  return {
    workflow: {
      id: workflow.id,
      templateId: workflow.templateId,
      title: workflow.title,
      description: workflow.description,
      status: workflow.status,
      currentStage: progress.current?.id || null,
      percent: progress.percent,
      source: workflow.source,
      target: workflow.target,
    },
    stages: workflow.stages.map(stage => ({
      id: stage.id,
      label: stageDefinition(stage.id)?.label || stage.id,
      status: stage.status,
      note: stage.note,
      artifact: stage.artifact,
    })),
    notes: workflow.notes,
    timeline: workflow.timeline.slice(-20),
  };
}

export function workflowFromKnowledge(article, options = {}) {
  return {
    templateId: options.templateId || 'learn-to-operate',
    title: options.title || `${article.title} engineering thread`,
    description: `Carry ${article.title} from knowledge into practice, change and verification.`,
    source: { type: 'knowledge', id: article.id, title: article.title },
    target: options.target || null,
  };
}

export function workflowFromTroubleshooting(caseData, options = {}) {
  return {
    templateId: options.templateId || 'troubleshoot-to-recovery',
    title: options.title || `${caseData.title || caseData.id} recovery`,
    description: `Investigate ${caseData.title || caseData.id}, prepare a controlled recovery and verify the outcome.`,
    source: { type: 'troubleshooting', id: caseData.id, title: caseData.title || caseData.id },
    target: options.target || null,
  };
}

export function workflowFromTwin(prompt, options = {}) {
  return {
    templateId: options.templateId || 'engineering-case',
    title: options.title || 'Twin-assisted engineering case',
    description: String(prompt || 'Carry the Twin investigation into an operational workflow.'),
    source: { type: 'twin', id: uid('twin'), title: String(prompt || 'Twin request').slice(0, 90) },
    target: options.target || null,
  };
}

export function workflowHistory(storage) {
  return loadWorkflowStore(storage).history.slice().reverse();
}
