export const CHANGE_CONTROL_VERSION = '1.0.0';
export const CHANGE_CONTROL_STORAGE_KEY = 'drillerBill.changeControl.v1';
export const PREFLIGHT_TTL_MS = 15 * 60 * 1000;

const RISK_BY_INTENT = Object.freeze({
  'save-running-config': 'low',
  'set-interface-description': 'low',
  'create-vlan': 'medium',
  'assign-access-vlan': 'medium',
  'assign-access-vlan-bulk': 'high',
  'set-trunk-vlans': 'high',
  'set-trunk-policy': 'high',
  'set-interface-state': 'critical',
  'remove-static-route': 'high',
  'add-static-route': 'high',
  'configure-ospf-process': 'high',
  'add-ospf-network': 'high',
  'configure-ospf-interface': 'high',
  'set-ospf-passive-interface': 'high',
  'add-standard-acl-rule': 'critical',
  'apply-standard-acl': 'critical',
  'harden-access-port': 'high',
  'set-stp-mode': 'high',
  'set-stp-vlan-priority': 'high',
  'configure-etherchannel': 'high',
  'set-interface-nat-role': 'critical',
  'configure-nat-overload': 'critical',
  'exclude-dhcp-address': 'high',
  'create-dhcp-pool': 'high',
  'set-hostname': 'medium',
  'configure-ssh': 'critical',
  'configure-vty-ssh': 'critical',
  'create-local-user': 'critical',
  'set-default-gateway': 'critical',
  'enable-ipv6-routing': 'high',
  'add-static-ipv6-route': 'high',
});

const RISK_ORDER = Object.freeze({ low: 1, medium: 2, high: 3, critical: 4 });
const RISK_META = Object.freeze({
  low: { label: 'Low', description: 'Low blast radius. Still review the generated change before application.', requiresApproval: true },
  medium: { label: 'Medium', description: 'A bounded configuration change that can affect local device behavior.', requiresApproval: true },
  high: { label: 'High', description: 'A change that can affect connectivity, routing, switching or service behavior.', requiresApproval: true },
  critical: { label: 'Critical', description: 'A change that can affect device access, traffic enforcement or broad connectivity.', requiresApproval: true },
});

function clean(value, fallback = '') {
  const text = String(value ?? '').trim();
  return text || fallback;
}

function nowIso() { return new Date().toISOString(); }

function sanitizeIntent(intent = {}) {
  const fields = {};
  for (const [key, value] of Object.entries(intent.fields || {})) {
    fields[key] = /secret|password|passphrase|token|privatekey|credential/i.test(key) ? '[redacted]' : value;
  }
  return { type: clean(intent.type), fields };
}

export function classifyIntentRisk(intent = {}) {
  const type = clean(intent.type, 'unknown');
  const level = RISK_BY_INTENT[type] || 'high';
  return { level, rank: RISK_ORDER[level], ...RISK_META[level], intentType: type };
}

function hasFreshInspection(inspection, maxAgeMs = 5 * 60 * 1000) {
  if (!inspection?.inspectedAt) return false;
  const age = Date.now() - Date.parse(inspection.inspectedAt);
  return Number.isFinite(age) && age >= 0 && age <= maxAgeMs;
}

export function buildPreflight({ device = null, intent = {}, plan = null, connected = false, inspection = null, diagnostics = null, history = [] } = {}) {
  const typedIntent = /** @type {Record<string, any>} */ (intent);
  const typedPlan = /** @type {Record<string, any> | null} */ (plan);
  const risk = classifyIntentRisk(typedIntent);
  const physical = ['ssh', 'serial'].includes(device?.connection?.type);
  const checks = [];
  const add = (id, status, label, detail, required = true) => checks.push({ id, status, label, detail, required });

  add('plan-valid', typedPlan?.valid ? 'pass' : 'fail', 'Typed intent is valid', typedPlan?.valid ? `${typedIntent.type} produced a valid device plan.` : (typedPlan?.errors?.join(' ') || 'The intent could not be validated.'));
  add('connected', connected ? 'pass' : 'fail', 'Device session is connected', connected ? `Active ${device?.connection?.type || 'device'} session detected.` : 'Connect to the target device before a live change can be applied.');
  add('fresh-inspection', hasFreshInspection(inspection) ? 'pass' : 'attention', 'Current device evidence exists', hasFreshInspection(inspection) ? 'Structured inspection is recent enough for this change review.' : 'Collect a fresh inspection before changing a device so the baseline is explicit.');
  add('baseline', history?.length ? 'pass' : 'attention', 'Configuration history baseline', history?.length ? `${history.length} stored configuration snapshot${history.length === 1 ? '' : 's'} available.` : 'No configuration snapshot exists yet. Capture a baseline before a physical change.');
  const diagnosticsStatus = diagnostics?.status || 'unknown';
  add('health', diagnosticsStatus === 'healthy' ? 'pass' : diagnosticsStatus === 'warning' ? 'attention' : 'unknown', 'Device health', diagnosticsStatus === 'healthy' ? 'Latest diagnostics report the device as healthy.' : diagnostics?.warnings ? `${diagnostics.warnings} warning(s) were observed. Review them before proceeding.` : 'No recent health classification is available.');

  if (risk.level === 'critical') add('critical-review', 'attention', 'Critical change review', 'This operation can materially affect device access or traffic behavior. Confirm the target and command plan manually before application.');
  if (physical) add('physical-confirmation', 'attention', 'Physical-device confirmation', 'This live SSH/serial change must reference a successful preflight record before the Device Agent will apply it.');

  const blocking = checks.filter(check => check.required && check.status === 'fail');
  const attention = checks.filter(check => check.status === 'attention');
  return {
    version: CHANGE_CONTROL_VERSION,
    valid: blocking.length === 0,
    risk,
    physical,
    checks,
    blocking: blocking.map(check => check.id),
    attention: attention.map(check => check.id),
    summary: blocking.length ? `Preflight blocked by ${blocking.length} required check${blocking.length === 1 ? '' : 's'}.` : attention.length ? `${attention.length} review item${attention.length === 1 ? '' : 's'} require attention before application.` : 'Preflight is clean and ready for approval.',
    generatedAt: nowIso(),
  };
}

export function normalizeChangeRecord(input = {}) {
  const risk = classifyIntentRisk(input.intent || {});
  return {
    version: CHANGE_CONTROL_VERSION,
    id: clean(input.id, `chg-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`),
    deviceId: clean(input.deviceId),
    deviceType: clean(input.deviceType, 'unknown'),
    transport: clean(input.transport, 'simulated'),
    intent: sanitizeIntent(input.intent || {}),
    risk: { level: risk.level, label: risk.label, rank: risk.rank },
    status: clean(input.status, 'preflighted'),
    createdAt: input.createdAt || nowIso(),
    preflightAt: input.preflightAt || input.createdAt || nowIso(),
    appliedAt: input.appliedAt || null,
    completedAt: input.completedAt || null,
    preSnapshotId: input.preSnapshotId || null,
    postSnapshotId: input.postSnapshotId || null,
    diffSummary: clean(input.diffSummary),
    changed: Boolean(input.changed),
    verification: input.verification ? { ...input.verification } : null,
    plan: {
      commands: Array.isArray(input.plan?.displayCommands) ? input.plan.displayCommands.map(String) : [],
      displayCommands: Array.isArray(input.plan?.displayCommands) ? input.plan.displayCommands.map(String) : [],
    },
    errors: Array.isArray(input.errors) ? input.errors.map(String).slice(-10) : [],
  };
}

export function reverseIntentHint(intent = {}) {
  const type = clean(intent.type);
  const hints = {
    'create-vlan': 'Remove the created VLAN using the device CLI or a dedicated inverse intent once the impact is confirmed.',
    'assign-access-vlan': 'Restore the interface to its previous access VLAN from the pre-change inspection/snapshot.',
    'assign-access-vlan-bulk': 'Restore each affected interface to its pre-change access VLAN from the saved baseline.',
    'set-trunk-vlans': 'Restore the previous trunk allow-list from the pre-change snapshot.',
    'set-trunk-policy': 'Restore the previous trunk policy from the pre-change snapshot.',
    'set-interface-state': 'Restore the interface administrative state captured in the pre-change baseline.',
    'add-static-route': 'Remove the newly added route after confirming the previous routing state.',
    'remove-static-route': 'Recreate the removed route from the pre-change baseline if it was required.',
  };
  return hints[type] || 'Use the pre-change snapshot and configuration diff to design a reviewed manual rollback.';
}

export function summarizeChangeRecord(record = {}) {
  const normalized = normalizeChangeRecord(record);
  const parts = [normalized.risk.label, normalized.status];
  if (normalized.changed) parts.push(normalized.diffSummary || 'configuration changed');
  return parts.join(' · ');
}
