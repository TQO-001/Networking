export const INITIAL_LAB = {
  devices: {
    R1: {
      name:'R1', kind:'router', mode:'exec', hostname:'R1',
      interfaces:{
        'GigabitEthernet0/0':{ip:'10.10.10.1',mask:'255.255.255.0',admin:true,link:true},
        'GigabitEthernet0/1':{ip:'10.0.12.1',mask:'255.255.255.252',admin:true,link:true},
        'Loopback0':{ip:'1.1.1.1',mask:'255.255.255.255',admin:true,link:true}
      },
      routes:[
        {type:'C',prefix:'10.10.10.0/24',next:'direct',iface:'Gi0/0'},
        {type:'C',prefix:'10.0.12.0/30',next:'direct',iface:'Gi0/1'},
        {type:'O',prefix:'10.20.20.0/24',next:'10.0.12.2',iface:'Gi0/1',ad:110,metric:20},
        {type:'S*',prefix:'0.0.0.0/0',next:'10.0.12.2',iface:'Gi0/1',ad:1,metric:0}
      ],
      ospf:{process:1,routerId:'1.1.1.1',networks:['10.0.12.0 0.0.0.3 area 0']},
      version:'17.12.04'
    },
    SW1: {
      name:'SW1', kind:'switch', mode:'exec', hostname:'SW1',
      vlans:{1:'default',10:'USERS',20:'SERVERS',99:'MANAGEMENT'},
      interfaces:{
        'GigabitEthernet0/1':{mode:'access',accessVlan:10,admin:true,link:true},
        'GigabitEthernet0/5':{mode:'access',accessVlan:20,admin:true,link:true},
        'GigabitEthernet0/24':{mode:'trunk',nativeVlan:99,allowedVlans:[10,20,99],admin:true,link:true}
      },
      etherchannel:{group:1,protocol:'LACP',ports:['Gi0/1','Gi0/2'],state:'SU'},
      stp:{root:true,rootPort:null,priority:24576,mac:'0011.2233.4455'}, version:'17.12.04'
    },
    SW2: {
      name:'SW2', kind:'switch', mode:'exec', hostname:'SW2',
      vlans:{1:'default',10:'USERS',20:'SERVERS',99:'MANAGEMENT'},
      interfaces:{
        'GigabitEthernet0/1':{mode:'access',accessVlan:10,admin:true,link:true},
        'GigabitEthernet0/5':{mode:'access',accessVlan:20,admin:true,link:true},
        'GigabitEthernet0/24':{mode:'trunk',nativeVlan:99,allowedVlans:[10,99],admin:true,link:true}
      },
      etherchannel:{group:1,protocol:'LACP',ports:['Gi0/1','Gi0/2'],state:'SU'},
      stp:{root:false,rootPort:'Gi0/24',priority:32768,mac:'0011.2233.5566'}, version:'17.12.04'
    }
  },
  clients:{
    PC1:{ip:'10.10.10.10',mask:'255.255.255.0',gateway:'10.10.10.1',vlan:10,switch:'SW1',port:'GigabitEthernet0/1'},
    PC2:{ip:'10.20.20.20',mask:'255.255.255.0',gateway:'10.20.20.1',vlan:20,switch:'SW1',port:'GigabitEthernet0/5'},
    SRV1:{ip:'10.20.20.10',mask:'255.255.255.0',gateway:'10.20.20.1',vlan:20,switch:'SW2',port:'GigabitEthernet0/5'}
  }
};

export const TOPOLOGY = [
  {id:'R1',x:50,y:15,kind:'router',label:'R1'},
  {id:'SW1',x:28,y:50,kind:'switch',label:'SW1'},
  {id:'SW2',x:72,y:50,kind:'switch',label:'SW2'},
  {id:'PC1',x:12,y:84,kind:'host',label:'PC1'},
  {id:'PC2',x:39,y:84,kind:'host',label:'PC2'},
  {id:'SRV1',x:88,y:84,kind:'server',label:'SRV1'}
];
export const LINKS = [
  {id:'r1-sw1',from:'R1',to:'SW1',left:'Gi0/0 ↔ Gi0/24',a:'R1',ai:'GigabitEthernet0/0',b:'SW1',bi:'GigabitEthernet0/24'},
  {id:'sw1-sw2',from:'SW1',to:'SW2',left:'Gi0/24 ↔ Gi0/24',a:'SW1',ai:'GigabitEthernet0/24',b:'SW2',bi:'GigabitEthernet0/24'},
  {id:'sw1-pc1',from:'SW1',to:'PC1',left:'Gi0/1',a:'SW1',ai:'GigabitEthernet0/1',b:'PC1'},
  {id:'sw1-pc2',from:'SW1',to:'PC2',left:'Gi0/5',a:'SW1',ai:'GigabitEthernet0/5',b:'PC2'},
  {id:'sw2-srv1',from:'SW2',to:'SRV1',left:'Gi0/5 · VLAN 20',a:'SW2',ai:'GigabitEthernet0/5',b:'SRV1'}
];

export const LAB_TASKS = [
  {id:'vlan20-trunk',title:'Restore VLAN 20 across the inter-switch trunk',objective:'2.2 / 2.3',device:'SW2',brief:'Users on SW2 VLAN 20 cannot reach the server behind the inter-switch path. Diagnose the trunk and make VLAN 20 traverse Gi0/24.',target:{mode:'trunk',nativeVlan:99,allowed:[10,20,99]},checks:['Gi0/24 is trunking','Native VLAN is 99','VLAN 20 is permitted'],hint:'Compare `show interfaces trunk` on SW1 and SW2.'},
  {id:'mgmt-native',title:'Keep the management VLAN explicitly carried',objective:'2.2 / 2.3',device:'SW2',brief:'The management VLAN must remain VLAN 99, and the inter-switch trunk must explicitly carry it.',target:{mode:'trunk',nativeVlan:99,allowedIncludes:99},checks:['Gi0/24 is trunking','Native VLAN is 99','VLAN 99 is permitted'],hint:'Verify native VLAN and allowed VLANs on SW2 Gi0/24.'},
  {id:'server-access',title:'Place the server edge in VLAN 20',objective:'2.1 / 2.3',device:'SW2',brief:'SRV1 is attached to SW2 Gi0/5. Configure that access port for the SERVERS VLAN.',target:{iface:'GigabitEthernet0/5',mode:'access',accessVlan:20,admin:true},checks:['Gi0/5 is access mode','Access VLAN is 20','Interface is not shutdown'],hint:'Use `interface gi0/5`, then set access mode and VLAN 20.'},
  {id:'recover-trunk',title:'Recover the inter-switch link',objective:'2.2',device:'SW2',brief:'The inter-switch connection has been administratively disabled. Restore the interface without changing its existing trunk policy.',target:{iface:'GigabitEthernet0/24',admin:true,mode:'trunk',nativeVlan:99,allowedIncludes:10},checks:['Gi0/24 is up','Gi0/24 remains trunking','Users VLAN 10 remains allowed'],hint:'Enter interface Gi0/24 and use `no shutdown`.'},
  {id:'static-route',title:'Install a static route to the remote LAN',objective:'3.2',device:'R1',brief:'R1 needs a static path to 10.20.20.0/24 via the R2 next hop at 10.0.12.2.',target:{route:'10.20.20.0/24',next:'10.0.12.2'},checks:['Route for 10.20.20.0/24 exists','Next hop is 10.0.12.2'],hint:'From global configuration, use `ip route 10.20.20.0 255.255.255.0 10.0.12.2`.'}
];

export const HELP=`Supported EXEC commands:
  show ip interface brief
  show interfaces <interface>
  show interfaces status
  show ip route
  show ip protocols
  show ip ospf neighbor
  show cdp neighbors
  show lldp neighbors
  show vlan brief
  show interfaces trunk
  show interfaces switchport
  show etherchannel summary
  show spanning-tree
  show mac address-table
  show running-config
  show version
  ping <IPv4 address>

Configuration:
  enable
  configure terminal
  interface <interface>
  vlan <id>
  name <name>
  switchport mode trunk
  switchport mode access
  switchport access vlan <id>
  switchport trunk native vlan <id>
  switchport trunk allowed vlan <list>
  switchport trunk allowed vlan add <list>
  ip address <ip> <mask>
  ip route <network> <mask> <next-hop>
  router ospf <process>
  router-id <id>
  network <network> <wildcard> area <area>
  no shutdown
  shutdown
  end / exit
  clear

Controlled CCNA training simulator — not a Cisco IOS implementation.`;

export function freshLab(){return structuredClone(INITIAL_LAB);}
function device(state,name){return state.devices[name];}
export function interfaceKey(raw=''){
  const x=raw.trim().toLowerCase().replace(/^int(?:erface)?\s+/,'');
  const m=x.match(/^(?:gi|gig|giga|gigabitethernet)(\d+\/\d+(?:\/\d+)?)$/); if(m)return `GigabitEthernet${m[1]}`;
  const n=x.match(/^gigabitethernet(\d+\/\d+(?:\/\d+)?)$/); if(n)return `GigabitEthernet${n[1]}`;
  if(/^lo(?:opback)?0$/.test(x))return 'Loopback0';
  return raw.trim();
}
export function compactInterface(name=''){return name.replace('GigabitEthernet','Gi').replace('Loopback','Lo');}
function parseVlanList(value,current=[]){
  if(!value)return [...current]; const out=[];
  for(const token of value.split(',')){const t=token.trim();if(!t)continue;if(t.includes('-')){const [a,b]=t.split('-').map(Number);for(let i=Math.min(a,b);i<=Math.max(a,b);i++)out.push(i);}else if(/^\d+$/.test(t))out.push(Number(t));}
  return [...new Set(out)].sort((a,b)=>a-b);
}
function wildcardToMask(w){return w.split('.').map(o=>255-Number(o)).join('.');}
function prefixToMask(prefix){let p=Number(prefix);const a=[];for(let i=0;i<4;i++){const bits=Math.max(0,Math.min(8,p));a.push(256-Math.pow(2,8-bits));p-=bits;}return a.join('.');}
function networkFor(ip,mask){const a=ip.split('.').map(Number),m=mask.split('.').map(Number);return a.map((o,i)=>o&m[i]).join('.')+'/'+m.map(x=>x.toString(2).replace(/0/g,'').length).reduce((s,x)=>s+x,0);}
function ifaceState(i){return i.admin&&i.link?'up/up':i.admin?'down/down':'administratively down/down';}
function showIpInterfaceBrief(dev){return ['Interface'.padEnd(24)+'IP-Address'.padEnd(16)+'OK? Method Status'.padEnd(25)+'Protocol',...Object.entries(dev.interfaces).map(([n,i])=>`${compactInterface(n).padEnd(24)}${(i.ip||'unassigned').padEnd(16)}YES manual  ${ifaceState(i).split('/')[0].padEnd(12)} ${i.link&&i.admin?'up':'down'}`)].join('\n');}
function showInterface(dev,name){const i=dev.interfaces[name];if(!i)return `% Interface ${name} not found.`;const sw=dev.kind==='switch';const switchLine=sw?(i.mode==='access'?`Switchport: access, access VLAN ${i.accessVlan}`:`Switchport: trunk, native VLAN ${i.nativeVlan||'none'}, allowed VLANs ${i.allowedVlans?.join(',')||'none'}`):'';return `${name} is ${i.admin&&i.link?'up':'down'}, line protocol is ${i.link&&i.admin?'up':'down'}\n  Hardware is simulated\n  Internet address is ${i.ip||'not set'}\n  MTU 1500 bytes\n  Encapsulation ARPA\n  ${switchLine}`;}
function showInterfaceStatus(dev){return ['Port        Name               Status       VLAN','Gi0/1                          '+(dev.interfaces['GigabitEthernet0/1']?.admin?'connected':'disabled')+'    '+(dev.kind==='switch'?dev.interfaces['GigabitEthernet0/1']?.accessVlan:'routed'), 'Gi0/5                          '+(dev.interfaces['GigabitEthernet0/5']?.admin?'connected':'disabled')+'    '+(dev.kind==='switch'?dev.interfaces['GigabitEthernet0/5']?.accessVlan:'routed'),'Gi0/24                         '+(dev.interfaces['GigabitEthernet0/24']?.admin?'connected':'disabled')+'    trunk'].join('\n');}
function showVlan(dev){const lines=['VLAN Name                             Status    Ports','---- -------------------------------- --------- -------------------------------'];for(const [id,name] of Object.entries(dev.vlans)){const ports=Object.entries(dev.interfaces).filter(([,i])=>i.mode==='access'&&String(i.accessVlan)===String(id)).map(([n])=>compactInterface(n)).join(', ');lines.push(`${String(id).padEnd(5)}${String(name).padEnd(32)}active    ${ports}`);}return lines.join('\n');}
function showTrunk(dev){const trunks=Object.entries(dev.interfaces).filter(([,i])=>i.mode==='trunk');if(!trunks.length)return '% No trunking interfaces.';return trunks.map(([name,i])=>`Port        Mode         Encapsulation  Status        Native vlan\n${compactInterface(name).padEnd(12)}on           802.1q          ${i.admin&&i.link?'trunking':'not-trunking'}      ${i.nativeVlan}\n\nPort        Vlans allowed on trunk\n${compactInterface(name).padEnd(12)}${i.allowedVlans.join(',')}\n\nPort        Vlans allowed and active in management domain\n${compactInterface(name).padEnd(12)}${i.allowedVlans.filter(v=>dev.vlans[v]).join(',')}`).join('\n\n');}
function showSwitchport(dev,name){const i=dev.interfaces[name];if(!i)return `% Interface ${name} not found.`;if(dev.kind!=='switch')return '% Invalid input detected at \'^\' marker.';return `Name: ${compactInterface(name)}\nSwitchport: Enabled\nAdministrative Mode: ${i.mode==='trunk'?'trunk':'static access'}\nOperational Mode: ${i.mode==='trunk'?'trunk':'static access'}\nAccess Mode VLAN: ${i.mode==='access'?i.accessVlan:'1'}\nTrunking Native Mode VLAN: ${i.nativeVlan||'1'}\nTrunking VLANs Enabled: ${i.allowedVlans?.join(',')||'none'}`;}
function showRun(dev){const lines=[`hostname ${dev.hostname}`,'!'];for(const [name,i] of Object.entries(dev.interfaces)){lines.push(`interface ${name}`);if(i.ip)lines.push(` ip address ${i.ip} ${i.mask}`);if(dev.kind==='switch'&&i.mode==='access'){lines.push(' switchport mode access',` switchport access vlan ${i.accessVlan}`);}if(dev.kind==='switch'&&i.mode==='trunk'){lines.push(' switchport mode trunk',` switchport trunk native vlan ${i.nativeVlan}`,` switchport trunk allowed vlan ${i.allowedVlans.join(',')}`);}lines.push(i.admin?' no shutdown':' shutdown','!');}if(dev.kind==='router'){for(const r of dev.routes.filter(r=>r.type==='S'||r.type==='S*'))lines.push(`ip route ${r.prefix.split('/')[0]} ${prefixToMask(r.prefix.split('/')[1])} ${r.next}`,'!');}if(dev.ospf){lines.push(`router ospf ${dev.ospf.process}`,` router-id ${dev.ospf.routerId}`,...dev.ospf.networks.map(n=>` network ${n}`),'!');}return lines.join('\n');}
function showRoute(dev){if(dev.kind!=='router')return '% IP routing not active on this simulated switch.';const gateway=dev.routes.find(r=>r.type==='S*')?.next;return `Gateway of last resort is ${gateway||'not set'} to network 0.0.0.0\n\n${dev.routes.map(r=>`${r.type.padEnd(4)}${r.prefix} ${r.next==='direct'?'is directly connected, '+r.iface:`[${r.ad}/${r.metric}] via ${r.next}, ${r.iface}`}`).join('\n')}`;}
function showOspf(dev){if(!dev.ospf)return '% OSPF not configured.';return `Routing Process "ospf ${dev.ospf.process}" with ID ${dev.ospf.routerId||'0.0.0.0'}\n\n${dev.ospf.networks.map(n=>`  ${n}`).join('\n')}\n\nRouting for Networks:\n${dev.ospf.networks.join('\n')}`;}
export function deriveShow(state,deviceName,cmd){const dev=device(state,deviceName);const c=cmd.trim().toLowerCase().replace(/\s+/g,' ');if(c==='show ip interface brief')return showIpInterfaceBrief(dev);if(c==='show ip route')return showRoute(dev);if(c==='show ip protocols')return showOspf(dev);if(c==='show ip ospf neighbor')return dev.ospf?'Neighbor ID     Pri   State           Dead Time   Address         Interface\n2.2.2.2           1   FULL/ -        00:00:33    10.0.12.2       Gi0/1':'% OSPF not configured.';if(c==='show cdp neighbors')return `Device ID        Local Intrfce     Holdtme    Capability   Platform    Port ID\n${deviceName==='R1'?'SW1              Gig 0/0          152        S I          C9200       Gi0/24':'R1               Gig 0/24         152        R S I        C9300       Gi0/0'}`;if(c==='show lldp neighbors')return `Device ID        Local Intf      Hold-time   Capability  Port ID\n${deviceName==='R1'?'SW1              Gi0/0          120         Bridge      Gi0/24':'R1               Gi0/24         120         Router      Gi0/0'}`;if(c==='show vlan brief')return dev.kind==='switch'?showVlan(dev):`% Invalid input detected at '^' marker.`;if(c==='show interfaces trunk')return dev.kind==='switch'?showTrunk(dev):`% Invalid input detected at '^' marker.`;const sm=c.match(/^show interfaces switchport(?: (.+))?$/);if(sm)return showSwitchport(dev,interfaceKey(sm[1]||'GigabitEthernet0/24'));const si=c.match(/^show interfaces(?: (.+))?$/);if(si)return showInterface(dev,interfaceKey(si[1]||'GigabitEthernet0/24'));if(c==='show interfaces status')return dev.kind==='switch'?showInterfaceStatus(dev):'% Invalid input detected at \'^\' marker.';if(c==='show etherchannel summary')return dev.kind==='switch'?`Group  Port-channel  Protocol    Ports\n${dev.etherchannel.group}      Po${dev.etherchannel.group}(SU)         ${dev.etherchannel.protocol}        ${dev.etherchannel.ports.map(p=>p+'(P)').join(' ')}`:`% EtherChannel is not configured.`;if(c==='show spanning-tree')return dev.kind==='switch'?`VLAN0099\n  Root ID    Priority    ${dev.stp.priority}\n             Address     ${dev.stp.mac}\n             ${dev.stp.root?'This bridge is the root':`Root port   ${dev.stp.rootPort}`}\n\nInterface        Role Sts Cost      Prio.Nbr\nGi0/24           ${dev.stp.root?'Desg':'Root'} FWD 4         128.24`:`% STP is not applicable.`;if(c==='show mac address-table')return dev.kind==='switch'?`Vlan    Mac Address       Type       Ports\n----    -----------       --------   -----\n10      aaaa.bbbb.cc${deviceName==='SW1'?'01':'10'}   DYNAMIC    Gi0/1\n${dev.interfaces['GigabitEthernet0/5']?.accessVlan===20?'20      aaaa.bbbb.cc20   DYNAMIC    Gi0/5\n':''}99      aaaa.bbbb.cc99   DYNAMIC    Gi0/24`:'% MAC address table unavailable.';if(c==='show running-config')return showRun(dev);if(c==='show version')return `Cisco IOS XE Software, Version ${dev.version}\nDriller Bill simulated ${dev.kind} lab device\nProcessor board ID PF-${deviceName}\nConfiguration register is 0x2102`;return null;}

export function executeCommand(prevState,deviceName,raw){
  const state=structuredClone(prevState),dev=device(state,deviceName),original=raw.trim(),cmd=original.toLowerCase().replace(/\s+/g,' ');if(!original)return {state,output:''};
  if(cmd==='clear')return {state,output:'__CLEAR__'};if(cmd==='help'||cmd==='?')return {state,output:HELP};
  if(cmd==='enable'){dev.mode='exec';return {state,output:''};}
  if(cmd==='disable'){dev.mode='user';return {state,output:''};}
  if(cmd==='end'){dev.mode='exec';dev.configInterface=null;dev.configVlan=null;dev.configRouter=null;return {state,output:''};}
  if(cmd==='exit'){if(dev.mode==='config-if'){dev.mode='config';dev.configInterface=null;}else if(dev.mode==='config-vlan'){dev.mode='config';dev.configVlan=null;}else if(dev.mode==='config-router'){dev.mode='config';dev.configRouter=null;}else if(dev.mode==='config'){dev.mode='exec';}return {state,output:''};}
  if(dev.mode==='exec'||dev.mode==='user'){
    const shown=deriveShow(state,deviceName,original);if(shown!==null)return {state,output:shown};
    if(cmd.startsWith('ping '))return {state,output:pingResult(state,deviceName,original.slice(5).trim())};
    if(cmd==='configure terminal'||cmd==='conf t'){if(dev.mode==='user')return {state,output:'% Privileged EXEC mode required.'};dev.mode='config';return {state,output:'Enter configuration commands, one per line. End with CNTL/Z.'};}
    return {state,output:`% Invalid input: ${original}\n% Type 'help' for the lab command set.`};
  }
  if(dev.mode==='config'){
    if(cmd.startsWith('hostname ')){dev.hostname=original.slice(9).trim();return {state,output:''};}
    if(/^vlan \d+$/.test(cmd)){const id=cmd.split(' ')[1];dev.vlans[id]=dev.vlans[id]||`VLAN${id}`;dev.mode='config-vlan';dev.configVlan=id;return {state,output:''};}
    if(/^interface /.test(cmd)){const key=interfaceKey(original.slice(original.indexOf(' ')+1));if(!dev.interfaces[key])dev.interfaces[key]={mode:dev.kind==='switch'?'access':undefined,accessVlan:1,admin:false,link:false};dev.mode='config-if';dev.configInterface=key;return {state,output:''};}
    if(/^ip route /.test(cmd)&&dev.kind==='router'){const parts=original.split(/\s+/);if(parts.length<5)return {state,output:'% Incomplete command.'};const [network,mask,next]=[parts[2],parts[3],parts[4]];const prefix=`${network}/${maskToPrefix(mask)}`;dev.routes=dev.routes.filter(r=>r.prefix!==prefix);dev.routes.push({type:'S',prefix,next,iface:'Gi0/1',ad:1,metric:0});return {state,output:''};}
    if(/^router ospf \d+$/.test(cmd)){dev.ospf=dev.ospf||{process:Number(cmd.split(' ')[2]),routerId:'0.0.0.0',networks:[]};dev.mode='config-router';dev.configRouter=dev.ospf.process;return {state,output:''};}
    return {state,output:`% Invalid input detected at '^' marker.`};
  }
  if(dev.mode==='config-vlan'){if(cmd.startsWith('name ')){dev.vlans[dev.configVlan]=original.slice(5).trim();return {state,output:''};}return {state,output:'% VLAN configuration command not supported in this lab.'};}
  if(dev.mode==='config-router'){if(cmd.startsWith('router-id ')){dev.ospf.routerId=original.slice(10).trim();return {state,output:''};}if(cmd.startsWith('network ')){dev.ospf.networks.push(original.slice(8).trim());return {state,output:''};}return {state,output:'% Routing process command not supported in this lab.'};}
  if(dev.mode==='config-if'){
    const i=dev.interfaces[dev.configInterface];
    if(cmd==='no shutdown'){i.admin=true;i.link=true;return {state,output:''};}
    if(cmd==='shutdown'){i.admin=false;i.link=false;return {state,output:''};}
    if(cmd.startsWith('ip address ')){const parts=original.split(/\s+/);if(parts.length!==4)return {state,output:'% Incomplete command.'};i.ip=parts[2];i.mask=parts[3];return {state,output:''};}
    if(dev.kind==='switch'){
      if(cmd==='switchport mode trunk'){i.mode='trunk';i.admin=true;i.link=true;i.allowedVlans=i.allowedVlans||[1];i.nativeVlan=i.nativeVlan||1;return {state,output:''};}
      if(cmd==='switchport mode access'){i.mode='access';i.allowedVlans=undefined;i.nativeVlan=undefined;i.admin=true;i.link=true;return {state,output:''};}
      if(cmd.startsWith('switchport access vlan ')){const v=Number(cmd.split(' ').at(-1));if(!Number.isInteger(v)||v<1||v>4094)return {state,output:'% Invalid VLAN.'};i.accessVlan=v;dev.vlans[v]=dev.vlans[v]||`VLAN${v}`;return {state,output:''};}
      if(cmd.startsWith('switchport trunk native vlan ')){i.nativeVlan=Number(cmd.split(' ').at(-1));return {state,output:''};}
      if(cmd.startsWith('switchport trunk allowed vlan ')){let value=original.slice(original.toLowerCase().indexOf('vlan ')+5);const add=/^add /i.test(value);value=value.replace(/^add\s+/i,'');const list=parseVlanList(value,i.allowedVlans||[]);i.allowedVlans=add?[...new Set([...(i.allowedVlans||[]),...list])].sort((a,b)=>a-b):list;return {state,output:''};}
    }
    return {state,output:`% Invalid input detected at '^' marker.`};
  }
  return {state,output:`% Invalid input: ${original}`};
}

function maskToPrefix(mask){return mask.split('.').map(Number).reduce((s,o)=>s+o.toString(2).replace(/0/g,'').length,0)}
export function promptFor(state,name){const dev=device(state,name);const suffix=dev.mode==='user'?'>':dev.mode==='config'?'(config)#':dev.mode==='config-if'?'(config-if)#':dev.mode==='config-vlan'?'(config-vlan)#':dev.mode==='config-router'?'(config-router)#':'#';return `${dev.hostname}${suffix}`;}

export function linkHealthy(state,link){
  const a=link.a==='PC1'||link.a==='PC2'||link.a==='SRV1'?state.clients[link.a]:state.devices[link.a];const b=link.b==='PC1'||link.b==='PC2'||link.b==='SRV1'?state.clients[link.b]:state.devices[link.b];
  if(link.a==='PC1'||link.a==='PC2'||link.a==='SRV1'){const x=a;const di=state.devices[link.b]?.interfaces[link.bi];return !!di?.admin&&di.link&&di.mode==='access'&&di.accessVlan===x.vlan;}
  if(link.b==='PC1'||link.b==='PC2'||link.b==='SRV1'){const x=b;const di=state.devices[link.a]?.interfaces[link.ai];return !!di?.admin&&di.link&&di.mode==='access'&&di.accessVlan===x.vlan;}
  const ai=a.interfaces[link.ai],bi=b.interfaces[link.bi];if(!ai?.admin||!ai.link||!bi?.admin||!bi.link)return false;if(ai.mode==='trunk'&&bi.mode==='trunk')return ai.allowedVlans.some(v=>bi.allowedVlans.includes(v));return true;
}
export function networkHealth(state){const linkRows=LINKS.map(l=>({id:l.id,label:l.left,healthy:linkHealthy(state,l)}));const vlan20Path=linkHealthy(state,LINKS.find(l=>l.id==='sw1-sw2'))&&state.devices.SW2.interfaces['GigabitEthernet0/5']?.admin&&state.devices.SW2.interfaces['GigabitEthernet0/5']?.accessVlan===20&&state.devices.SW1.interfaces['GigabitEthernet0/5']?.accessVlan===20;return {links:linkRows,healthyLinks:linkRows.filter(x=>x.healthy).length,totalLinks:linkRows.length,vlan20Path};}
export function pingResult(state,fromName,target){
  const targetClient=Object.values(state.clients).find(c=>c.ip===target);if(!targetClient)return `% Destination ${target} unknown in lab.`;
  if(fromName==='R1'){
    const route=state.devices.R1.routes.some(r=>r.prefix==='10.20.20.0/24');return route&&networkHealth(state).vlan20Path?'Type escape sequence to abort.\n!!!!!\nSuccess rate is 100 percent (5/5), round-trip min/avg/max = 1/2/4 ms':'Type escape sequence to abort.\n.....\nSuccess rate is 0 percent (0/5)';
  }
  const reachable=networkHealth(state).vlan20Path;if(target==='10.20.20.10'&&reachable)return 'Type escape sequence to abort.\n!!!!!\nSuccess rate is 100 percent (5/5), round-trip min/avg/max = 1/2/4 ms';return 'Type escape sequence to abort.\n.....\nSuccess rate is 0 percent (0/5)';
}

export function evaluateTask(state,taskId){
  const task=LAB_TASKS.find(t=>t.id===taskId);if(!task)return {ok:false,score:0,message:'Unknown task.',checks:[]};
  if(task.target.route){const hit=state.devices.R1.routes.find(r=>(r.type==='S'||r.type==='S*')&&r.prefix===task.target.route&&r.next===task.target.next);const checks=[{label:task.checks[0],ok:!!hit},{label:task.checks[1],ok:!!hit&&hit.next===task.target.next}];return {ok:checks.every(c=>c.ok),score:checks.filter(c=>c.ok).length*50,message:checks.every(c=>c.ok)?'The static route is present with the requested next hop.':'The route has not been installed with the requested destination and next hop.',checks};}
  const dev=state.devices[task.device],i=dev.interfaces[task.target.iface||'GigabitEthernet0/24'];const checks=[];
  if(task.target.mode)checks.push({label:task.checks[0],ok:i?.mode===task.target.mode});
  if(Object.hasOwn(task.target,'nativeVlan'))checks.push({label:task.checks[1]||'Native VLAN is correct',ok:i?.nativeVlan===task.target.nativeVlan});
  if(Object.hasOwn(task.target,'accessVlan'))checks.push({label:task.checks[1]||'Access VLAN is correct',ok:i?.accessVlan===task.target.accessVlan});
  if(Object.hasOwn(task.target,'admin'))checks.push({label:task.checks.at(-1)||'Interface is enabled',ok:i?.admin===task.target.admin});
  if(task.target.allowed){checks.push({label:task.checks[2],ok:task.target.allowed.every(v=>i?.allowedVlans?.includes(v))});}
  if(Object.hasOwn(task.target,'allowedIncludes'))checks.push({label:task.checks[2],ok:i?.allowedVlans?.includes(task.target.allowedIncludes)});
  return {ok:checks.length>0&&checks.every(c=>c.ok),score:checks.length?Math.round(checks.filter(c=>c.ok).length/checks.length*100):0,message:checks.every(c=>c.ok)?'Objective complete. The simulated device state matches the task requirements.':'Objective not complete. Use the checklist and verify the resulting state.',checks};
}

export function taskFixture(taskId){
  const state=freshLab();
  if(taskId==='vlan20-trunk') state.devices.SW2.interfaces['GigabitEthernet0/24'].allowedVlans=[10,99];
  if(taskId==='mgmt-native') state.devices.SW2.interfaces['GigabitEthernet0/24'].nativeVlan=1;
  if(taskId==='server-access') state.devices.SW2.interfaces['GigabitEthernet0/5'].accessVlan=10;
  if(taskId==='recover-trunk') {state.devices.SW2.interfaces['GigabitEthernet0/24'].admin=false;state.devices.SW2.interfaces['GigabitEthernet0/24'].link=false;}
  if(taskId==='static-route') state.devices.R1.routes=state.devices.R1.routes.filter(r=>r.prefix!=='10.20.20.0/24');
  return state;
}
