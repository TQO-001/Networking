export const CONFIG_HISTORY_VERSION = '1.0.0';

function normalizeConfig(value = '') {
  return String(value ?? '').replace(/\r/g, '').split('\n').map(line => line.trimEnd()).join('\n').trim();
}

export function redactConfig(value = '') {
  return normalizeConfig(value)
    .replace(/(^|\n)(\s*(?:enable\s+)?secret\s+)(.+)$/gim, '$1$2[redacted]')
    .replace(/(^|\n)(\s*(?:password|passwd)\s+)(.+)$/gim, '$1$2[redacted]')
    .replace(/(^|\n)(\s*username\s+\S+(?:\s+\S+)*?\s+(?:secret|password)\s+)(.+)$/gim, '$1$2[redacted]')
    .replace(/(^|\n)(\s*(?:snmp-server\s+community\s+)\S+)(.*)$/gim, '$1$2 [redacted]')
    .replace(/(^|\n)(\s*(?:key\s+\d+\s+)(?:[^\s]+))\s*$/gim, '$1$2 [redacted]');
}

export function normalizeSnapshot(snapshot = {}) {
  return {
    deviceId: String(snapshot.deviceId || ''),
    capturedAt: snapshot.capturedAt || new Date().toISOString(),
    runningConfig: redactConfig(snapshot.runningConfig || ''),
    startupConfig: redactConfig(snapshot.startupConfig || ''),
  };
}

function lines(value) {
  return normalizeConfig(value).split('\n').filter(Boolean);
}

export function configDiff(before = '', after = '') {
  const beforeLines = lines(before);
  const afterLines = lines(after);
  const beforeCount = new Map();
  const afterCount = new Map();
  for (const line of beforeLines) beforeCount.set(line, (beforeCount.get(line) || 0) + 1);
  for (const line of afterLines) afterCount.set(line, (afterCount.get(line) || 0) + 1);

  const remainingBefore = new Map(beforeCount);
  const remainingAfter = new Map(afterCount);
  const removed = [];
  const added = [];

  for (const line of beforeLines) {
    const count = remainingAfter.get(line) || 0;
    if (count > 0) remainingAfter.set(line, count - 1);
    else removed.push(line);
  }
  for (const line of afterLines) {
    const count = remainingBefore.get(line) || 0;
    if (count > 0) remainingBefore.set(line, count - 1);
    else added.push(line);
  }

  return {
    added,
    removed,
    changed: [...added, ...removed].length > 0,
    addedCount: added.length,
    removedCount: removed.length,
    beforeLines: beforeLines.length,
    afterLines: afterLines.length,
  };
}

export function summarizeConfigDiff(diff = {}) {
  if (!diff.changed) return 'No configuration changes detected.';
  const parts = [];
  if (diff.addedCount) parts.push(`${diff.addedCount} added`);
  if (diff.removedCount) parts.push(`${diff.removedCount} removed`);
  return parts.join(' · ');
}

export function snapshotRecord(snapshot = {}, meta = {}) {
  const normalized = normalizeSnapshot(snapshot);
  return {
    id: meta.id || `cfg-${Date.parse(normalized.capturedAt) || Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    deviceId: normalized.deviceId,
    capturedAt: normalized.capturedAt,
    source: meta.source || 'manual',
    label: meta.label || (meta.source === 'intent' ? 'After configuration intent' : 'Configuration snapshot'),
    runningConfig: normalized.runningConfig,
    startupConfig: normalized.startupConfig,
    summary: meta.summary || '',
  };
}
