export const DEVICE_INSPECTION_VERSION = '1.0.0';

export const INSPECTION_COMMANDS = {
  switch: ['show version', 'show ip interface brief', 'show interfaces status', 'show vlan brief', 'show interfaces trunk', 'show ip route', 'show running-config'],
  router: ['show version', 'show ip interface brief', 'show ip route', 'show running-config'],
};

function cleanLine(value = '') {
  return String(value).replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, '').replace(/\r/g, '').trimEnd();
}

function outputLines(value = '') {
  return String(value).split('\n').map(cleanLine).filter(line => line.trim());
}

function extractVersion(text = '') {
  return String(text).match(/Version\s+([0-9][^\s,;]+)/i)?.[1] || 'unknown';
}

function extractHostname(text = '') {
  const uptime = String(text).match(/^(\S+)\s+uptime is/im)?.[1];
  if (uptime) return uptime;
  return String(text).match(/^hostname\s+(\S+)/im)?.[1] || 'unknown';
}

export function parseIpInterfaceBrief(text = '') {
  const rows = [];
  for (const line of outputLines(text)) {
    if (/^(Interface|Protocol|---|\S+\s+IP-Address)/i.test(line)) continue;
    const match = line.trim().match(/^(\S+)\s+(\S+)\s+(YES|NO)\s+\S+\s+(up|down|administratively down)\s+(up|down)$/i);
    if (!match) continue;
    rows.push({ name: match[1], ip: match[2], status: match[4].toLowerCase(), protocol: match[5].toLowerCase() });
  }
  return rows;
}

export function parseVlanBrief(text = '') {
  const rows = [];
  for (const line of outputLines(text)) {
    const match = line.match(/^\s*(\d+)\s+(.+?)\s{2,}(active|act\/unsup|suspended|legacy|unknown)\s*(.*)$/i);
    if (!match || Number(match[1]) > 4094) continue;
    rows.push({ id: Number(match[1]), name: match[2].trim(), status: match[3].trim(), ports: match[4].trim() ? match[4].split(/\s*,\s*/).filter(Boolean) : [] });
  }
  return rows;
}

export function parseInterfacesTrunk(text = '') {
  const rows = [];
  let allowedMode = false;
  for (const line of outputLines(text)) {
    if (/^Port\s+Vlans allowed on trunk/i.test(line)) { allowedMode = true; continue; }
    const match = line.match(/^\s*(\S+)\s+(on|off|desirable|auto|nonegotiate)\s+\S+\s+(trunking|trunk|not-trunking)\s+(\S+)$/i);
    if (match) {
      rows.push({ interface: match[1], mode: match[2].toLowerCase(), status: match[3].toLowerCase(), nativeVlan: Number.isFinite(Number(match[4])) ? Number(match[4]) : match[4], allowedVlans: [] });
      continue;
    }
    if (allowedMode) {
      const allowed = line.match(/^\s*(\S+)\s+(.+)$/);
      if (allowed) {
        const target = rows.find(item => item.interface === allowed[1]);
        if (target) target.allowedVlans = String(allowed[2]).split(',').map(value => Number(value.trim())).filter(Number.isInteger);
      }
    }
  }
  return rows;
}


export function parseInterfaceStatus(text = '') {
  const rows = [];
  for (const line of outputLines(text)) {
    const match = line.trim().match(/^(\S+)\s+(.*?)\s{2,}(connected|notconnect|disabled)\s+(\S+)\s+(a-full|a-half|full|half|auto)\s+(\S+)\s+\S+$/i);
    if (!match || /^Port$/i.test(match[1])) continue;
    rows.push({ name: match[1], description: match[2].trim(), status: match[3].toLowerCase(), vlan: match[4].toLowerCase() === 'trunk' ? 'trunk' : Number.isInteger(Number(match[4])) ? Number(match[4]) : match[4] });
  }
  return rows;
}

export function parseIpRoute(text = '') {
  const rows = [];
  for (const line of outputLines(text)) {
    const match = line.match(/^\s*([A-Z*]+)\s+(\S+)(?:\s+\[(\d+)\/([^\]]+)\])?\s+via\s+(\S+)(?:,\s+\S+\s+\S+\s+([A-Za-z0-9/.-]+))?/);
    if (!match) continue;
    rows.push({ code: match[1], network: match[2], administrativeDistance: match[3] ? Number(match[3]) : null, metric: match[4] ? Number(match[4]) : null, nextHop: match[5], interface: match[6] || '' });
  }
  return rows;
}

function signalsFor(report) {
  const signals = [];
  const downInterfaces = report.interfaces.filter(item => item.status !== 'up' || item.protocol !== 'up');
  if (downInterfaces.length) signals.push({ severity: 'info', type: 'interface-state', message: `${downInterfaces.length} interface${downInterfaces.length === 1 ? '' : 's'} are not operational.`, evidence: downInterfaces.map(item => `${item.name}: ${item.status}/${item.protocol}`) });
  const missingNames = report.interfaces.filter(item => item.ip === 'unassigned').length;
  if (missingNames && report.kind === 'router') signals.push({ severity: 'info', type: 'addressing', message: `${missingNames} routed interface${missingNames === 1 ? '' : 's'} currently report an unassigned IPv4 address.`, evidence: report.interfaces.filter(item => item.ip === 'unassigned').map(item => item.name) });
  if (report.kind === 'switch' && report.vlans.length === 0) signals.push({ severity: 'warning', type: 'vlan-state', message: 'No VLAN records were parsed from the inspection output.', evidence: [] });
  if (report.kind === 'switch' && report.trunks.length === 0) signals.push({ severity: 'info', type: 'trunk-state', message: 'No active trunk records were parsed from the inspection output.', evidence: [] });
  return signals;
}

/**
 * @param {{device?: Record<string, any>, outputs?: Record<string, string>, source?: string}} options
 */
export function buildInspectionReport({ device = {}, outputs = {}, source = 'device' } = {}) {
  const versionText = outputs['show version'] || '';
  const interfaces = parseIpInterfaceBrief(outputs['show ip interface brief'] || '');
  const interfaceStatus = parseInterfaceStatus(outputs['show interfaces status'] || '');
  const vlans = parseVlanBrief(outputs['show vlan brief'] || '');
  const mergedInterfaces = interfaces.map(item => {
    const detail = interfaceStatus.find(row => row.name === item.name);
    return detail ? { ...item, description: detail.description, switchportVlan: detail.vlan } : item;
  });
  const trunks = parseInterfacesTrunk(outputs['show interfaces trunk'] || '');
  const routes = parseIpRoute(outputs['show ip route'] || '');
  const report = {
    version: DEVICE_INSPECTION_VERSION,
    deviceId: device.id || '',
    inspectedAt: new Date().toISOString(),
    source,
    kind: device.kind || 'unknown',
    overview: {
      hostname: extractHostname(versionText) !== 'unknown' ? extractHostname(versionText) : (device.hostname || device.name || 'unknown'),
      vendor: device.vendor || 'unknown',
      platform: device.platform || 'unknown',
      version: extractVersion(versionText) !== 'unknown' ? extractVersion(versionText) : (device.version || 'unknown'),
      interfaceCount: mergedInterfaces.length,
      upInterfaceCount: mergedInterfaces.filter(item => item.status === 'up' && item.protocol === 'up').length,
      vlanCount: vlans.length,
      routeCount: routes.length,
      trunkCount: trunks.length,
    },
    interfaces: mergedInterfaces,
    vlans,
    trunks,
    routes,
    signals: [],
    raw: { commands: Object.keys(outputs), outputs },
    runningConfig: String(outputs['show running-config'] || ''),
    ospf: null,
    acls: {},
    nat: null,
    dhcpPools: {},
    dhcpExcluded: [],
    etherchannels: {},
    stp: {},
    ipv6: null,
  };
  report.signals = signalsFor(report);
  return report;
}

export function inspectSimulatedDevice(state = {}, deviceId = '') {
  const device = state.devices?.[deviceId];
  if (!device) throw new Error(`Device ${deviceId} not found.`);
  const interfaces = Object.entries(device.interfaces || {}).map(([name, value]) => ({
    name,
    ip: value.ip || 'unassigned',
    status: value.admin === false ? 'administratively down' : value.link === false ? 'down' : 'up',
    protocol: value.admin === false || value.link === false ? 'down' : 'up',
    description: value.description || '',
    switchportVlan: device.kind === 'switch' ? (value.mode === 'trunk' ? 'trunk' : Number(value.accessVlan || 1)) : '',
    mode: value.mode || '',
    nativeVlan: value.nativeVlan ?? null,
    allowedVlans: Array.isArray(value.allowedVlans) ? [...value.allowedVlans] : [],
    ospfProcess: value.ospfProcess ?? null,
    ospfArea: value.ospfArea ?? null,
    ospfHello: value.ospfHello ?? null,
    ospfDead: value.ospfDead ?? null,
    ospfPassive: Boolean(device.ospf?.passiveInterfaces?.includes(name)),
    natRole: value.natRole || null,
    aclBindings: { ...(value.aclBindings || {}) },
    portSecurity: { enabled: Boolean(value.portSecurity?.enabled), maximum: Number(value.portSecurity?.maximum || 1) },
    portfast: Boolean(value.portfast),
    bpduguard: Boolean(value.bpduguard),
    channelGroup: value.channelGroup ?? null,
    channelMode: value.channelMode ?? null,
  }));
  const vlans = Object.entries(device.vlans || {}).map(([id, value]) => {
    const numericId = Number(id);
    const name = typeof value === 'string' ? value : value?.name || `VLAN${id}`;
    const ports = Object.entries(device.interfaces || {})
      .filter(([, iface]) => iface.mode === 'access' && Number(iface.accessVlan || 1) === numericId)
      .map(([port]) => port.startsWith('GigabitEthernet') ? port.replace('GigabitEthernet', 'Gi') : port);
    return { id: numericId, name, status: value?.active === false ? 'suspended' : 'active', ports };
  });
  const trunks = interfaces
    .filter(item => device.interfaces?.[item.name]?.mode === 'trunk')
    .map(item => ({ interface: item.name, mode: 'on', status: 'trunking', nativeVlan: device.interfaces[item.name].nativeVlan || 1, allowedVlans: device.interfaces[item.name].allowedVlans || [] }));
  const routes = (device.routes || []).map(route => ({ code: route.code || route.type || 'S', network: route.network || route.prefix || 'unknown', administrativeDistance: route.distance ?? route.ad ?? null, metric: route.metric ?? null, nextHop: route.nextHop || route.next || route.via || '', interface: route.interface || route.iface || '' }));
  const report = {
    version: DEVICE_INSPECTION_VERSION,
    deviceId,
    inspectedAt: new Date().toISOString(),
    source: 'simulated',
    kind: device.kind || 'unknown',
    overview: {
      hostname: device.hostname || deviceId,
      vendor: device.vendor || 'Cisco',
      platform: device.platform || 'IOS-style',
      version: device.version || 'simulated',
      interfaceCount: interfaces.length,
      upInterfaceCount: interfaces.filter(item => item.status === 'up' && item.protocol === 'up').length,
      vlanCount: vlans.length,
      routeCount: routes.length,
      trunkCount: trunks.length,
      stpMode: device.spanningTreeMode || null,
      defaultGateway: device.defaultGateway || '',
      domainName: device.domainName || '',
      sshVersion: device.sshVersion || null,
      ipv6Forwarding: Boolean(device.ipv6?.forwarding),
    },
    interfaces,
    vlans,
    trunks,
    routes,
    ospf: device.ospf ? {
      process: device.ospf.process,
      routerId: device.ospf.routerId || '',
      networks: [...(device.ospf.networks || [])],
      passiveInterfaces: [...(device.ospf.passiveInterfaces || [])],
      hello: device.ospf.hello ?? 10,
      dead: device.ospf.dead ?? 40,
    } : null,
    acls: JSON.parse(JSON.stringify(device.acls || {})),
    nat: JSON.parse(JSON.stringify(device.nat || { inside: [], outside: [], overload: [] })),
    dhcpPools: JSON.parse(JSON.stringify(device.dhcpPools || {})),
    dhcpExcluded: [...(device.dhcpExcluded || [])],
    etherchannels: JSON.parse(JSON.stringify(device.etherchannels || {})),
    stp: JSON.parse(JSON.stringify(device.stp || {})),
    ipv6: JSON.parse(JSON.stringify(device.ipv6 || { forwarding: false, routes: [], addresses: {} })),
    signals: [],
    raw: { commands: INSPECTION_COMMANDS[device.kind === 'router' ? 'router' : 'switch'], outputs: {} },
    runningConfig: '',
  };
  report.signals = signalsFor(report);
  return report;
}
