export const DEVICE_AGENT_URL = 'http://127.0.0.1:8788';

/** @typedef {{baseUrl?: string, token?: string, method?: string, body?: unknown}} AgentRequestOptions */

export class DeviceAgentError extends Error {
  constructor(message, status = 0) {
    super(message);
    this.name = 'DeviceAgentError';
    this.status = status;
  }
}

/** @param {string} path @param {AgentRequestOptions} options */
async function request(path, { baseUrl = DEVICE_AGENT_URL, token = '', method = 'GET', body } = {}) {
  const headers = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = `Bearer ${token}`;
  let response;
  try {
    response = await fetch(`${baseUrl.replace(/\/$/, '')}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch (error) {
    throw new DeviceAgentError(`Cannot reach the local Device Agent at ${baseUrl}. Start agent/server.mjs first.`);
  }
  let payload = null;
  try { payload = await response.json(); } catch { /* preserve status below */ }
  if (!response.ok || payload?.ok === false) throw new DeviceAgentError(payload?.error || `Agent request failed (${response.status}).`, response.status);
  return payload;
}

export const agentHealth = (options = {}) => request('/api/v1/health', options);
export const agentContract = (options = {}) => request('/api/v1/contract', options);
export const agentDevices = (options = {}) => request('/api/v1/devices', options);
export const agentRegisterDevice = (device, options = {}) => request('/api/v1/devices', { ...options, method: 'POST', body: device });
export const agentRemoveDevice = (deviceId, options = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}`, { ...options, method: 'DELETE' });
export const agentConnect = (deviceId, options = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}/connect`, { ...options, method: 'POST' });
export const agentDisconnect = (deviceId, options = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}/connect`, { ...options, method: 'DELETE' });
export const agentExecute = (deviceId, command, options = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}/execute`, { ...options, method: 'POST', body: { command } });
export const agentDiscover = (deviceId, options = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}/discover`, { ...options, method: 'POST', body: {} });
export const agentDiscovery = (deviceId, options = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}/discovery`, options);
export const agentSnapshot = (deviceId, options = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}/snapshot`, { ...options, method: 'POST' });
export const agentInspect = (deviceId, options = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}/inspect`, { ...options, method: 'POST' });
export const agentInspection = (deviceId, options = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}/inspection`, options);
export const agentDiagnostics = (deviceId, options = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}/diagnostics`, options);
export const agentConfigHistory = (deviceId, options = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}/config-history`, options);
export const agentConfigDiff = (deviceId, fromId, toId, options = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}/config-diff?from=${encodeURIComponent(fromId)}&to=${encodeURIComponent(toId)}`, options);
export const agentApplyIntent = (deviceId, intent, { changeId = '', ...options } = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}/apply-intent`, { ...options, method: 'POST', body: { intent, ...(changeId ? { changeId } : {}) } });
export const agentPreflightIntent = (deviceId, intent, options = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}/preflight-intent`, { ...options, method: 'POST', body: { intent } });
export const agentChangeHistory = (deviceId, options = {}) => request(`/api/v1/devices/${encodeURIComponent(deviceId)}/change-history`, options);
