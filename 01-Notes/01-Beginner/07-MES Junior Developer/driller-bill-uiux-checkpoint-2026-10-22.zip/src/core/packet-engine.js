export const PACKET_SCENARIOS = [
  {id:'ipv6-nd',code:'PKT-01',title:'Resolve an IPv6 neighbor',protocol:'IPv6 / NDP',difficulty:'APPLICATION',source:'PC1',destination:'2001:db8:20::10',objective:'IPv6 neighbor discovery and gateway reachability',summary:'R1 is not forwarding IPv6, so the first-hop path never becomes usable.'},
  {id:'acl-echo',code:'PKT-02',title:'Permit diagnostic ICMP',protocol:'ACL',difficulty:'ANALYSIS',source:'PC1',destination:'10.20.20.10',objective:'ACL evaluation order and permit/deny behavior',summary:'An extended ACL blocks ICMP to the server before routing can deliver it.'},
  {id:'dhcp-relay',code:'PKT-03',title:'Relay a DHCP broadcast',protocol:'DHCP relay',difficulty:'APPLICATION',source:'PC2',destination:'10.10.10.100',objective:'DHCP relay forwarding and helper addresses',summary:'The client broadcast reaches R1, but the missing helper address prevents relay.'},
  {id:'nat-flow',code:'PKT-04',title:'Translate an inside flow',protocol:'NAT overload',difficulty:'ANALYSIS',source:'PC1',destination:'198.51.100.10',objective:'NAT inside/outside roles and overload translation',summary:'The overload rule exists, but R1 is not treating Gi0/0 as the NAT inside interface.'},
  {id:'stp-convergence',code:'PKT-05',title:'Restore the forwarding path',protocol:'RSTP',difficulty:'ANALYSIS',source:'PC2',destination:'SRV1',objective:'RSTP root and forwarding-state convergence',summary:'SW2 became the root for VLAN 20; restore SW1 as the intended root.'},
  {id:'lacp-bundle',code:'PKT-06',title:'Form the redundant uplink',protocol:'LACP',difficulty:'APPLICATION',source:'SW1',destination:'SW2',objective:'LACP negotiation and port-channel formation',summary:'SW2 has a non-participating member and passive state, so the intended bundle is down.'},
  {id:'dualstack',code:'PKT-07',title:'Forward a dual-stack packet',protocol:'IPv4 / IPv6',difficulty:'EXAM',source:'PC1',destination:'2001:db8:20::10',objective:'Dual-stack forwarding and IPv6 routing',summary:'The IPv6 destination exists on R2, but R1 lacks forwarding and a remote IPv6 route.'},
];

const clone = value => structuredClone(value);

export function freshPacketState(caseId='ipv6-nd') {
  return derivePacketState({caseId, packet:{
    ipv6:{forwarding:{R1:false,R2:true},routes:{R1:['2001:db8:10::/64'],R2:['2001:db8:12::/64','2001:db8:20::/64']},neighbors:{PC1:'INCOMPLETE'}},
    acl:{rules:[{action:'deny',protocol:'icmp',destination:'10.20.20.10'},{action:'permit',protocol:'ip',destination:'any'}]},
    dhcpRelay:{helper:null,server:'10.10.10.100',clientState:'DISCOVERING'},
    nat:{inside:[],outside:['GigabitEthernet0/1'],overload:true,translations:[],publicAddress:'203.0.113.2'},
    stp:{mode:'rapid-pvst',vlans:{10:{sw1Priority:32768,sw2Priority:24576,root:'SW2'},20:{sw1Priority:32768,sw2Priority:24576,root:'SW2'}},forwarding:false},
    etherchannel:{sw1:{Gi0_21:'active',Gi0_22:'active'},sw2:{Gi0_21:'passive',Gi0_22:'down'},formed:false}
  }});
}

export function derivePacketState(input){
  const state=clone(input); const p=state.packet;
  p.ipv6.neighbors.PC1=p.ipv6.forwarding.R1?'REACHABLE':'INCOMPLETE';
  p.aclAllowsPing=!p.acl.rules.some(r=>r.action==='deny'&&r.protocol==='icmp'&&r.destination==='10.20.20.10');
  p.dhcpRelay.ok=p.dhcpRelay.helper===p.dhcpRelay.server;
  p.nat.ok=p.nat.inside.includes('GigabitEthernet0/0')&&p.nat.outside.includes('GigabitEthernet0/1')&&p.nat.overload;
  p.nat.translations=p.nat.ok?[{insideLocal:'10.10.10.10',insideGlobal:p.nat.publicAddress,outsideGlobal:'198.51.100.10'}]:[];
  for(const vlan of [10,20]) p.stp.vlans[vlan].root=p.stp.vlans[vlan].sw1Priority<p.stp.vlans[vlan].sw2Priority?'SW1':'SW2';
  p.stp.forwarding=p.stp.mode==='rapid-pvst'&&p.stp.vlans[20].root==='SW1';
  p.etherchannel.formed=Object.values(p.etherchannel.sw1).every(v=>v==='active')&&Object.values(p.etherchannel.sw2).every(v=>v==='active');
  state.derived={ipv6Reachable:p.ipv6.forwarding.R1,aclAllowsPing:p.aclAllowsPing,dhcpRelayReady:p.dhcpRelay.ok,natReady:p.nat.ok,stpReady:p.stp.forwarding,lacpReady:p.etherchannel.formed,dualStackReady:p.ipv6.forwarding.R1&&p.ipv6.routes.R1.includes('2001:db8:20::/64')};
  return state;
}

export function evaluatePacketCase(state,caseId){
  const s=derivePacketState(state); const checks=[];
  switch(caseId){
    case 'ipv6-nd': checks.push({label:'R1 IPv6 forwarding enabled',ok:s.derived.ipv6Reachable},{label:'PC1 NDP state is REACHABLE',ok:s.packet.ipv6.neighbors.PC1==='REACHABLE'}); break;
    case 'acl-echo': checks.push({label:'ICMP deny removed from ACL',ok:s.derived.aclAllowsPing},{label:'Permit IP rule remains',ok:s.packet.acl.rules.some(r=>r.action==='permit'&&r.destination==='any')}); break;
    case 'dhcp-relay': checks.push({label:'Helper address configured',ok:s.derived.dhcpRelayReady},{label:'Client reaches BOUND state',ok:s.packet.dhcpRelay.clientState==='BOUND'}); break;
    case 'nat-flow': checks.push({label:'Gi0/0 marked NAT inside',ok:s.packet.nat.inside.includes('GigabitEthernet0/0')},{label:'Gi0/1 remains NAT outside',ok:s.packet.nat.outside.includes('GigabitEthernet0/1')},{label:'PAT translation created',ok:s.packet.nat.translations.length===1}); break;
    case 'stp-convergence': checks.push({label:'SW1 is root for VLAN 10',ok:s.packet.stp.vlans[10].root==='SW1'},{label:'SW1 is root for VLAN 20',ok:s.packet.stp.vlans[20].root==='SW1'},{label:'VLAN 20 forwarding path active',ok:s.derived.stpReady}); break;
    case 'lacp-bundle': checks.push({label:'SW1 members active',ok:Object.values(s.packet.etherchannel.sw1).every(v=>v==='active')},{label:'SW2 members active',ok:Object.values(s.packet.etherchannel.sw2).every(v=>v==='active')},{label:'Port-channel formed',ok:s.derived.lacpReady}); break;
    case 'dualstack': checks.push({label:'R1 IPv6 forwarding enabled',ok:s.derived.ipv6Reachable},{label:'R2 owns destination prefix',ok:s.packet.ipv6.routes.R2.includes('2001:db8:20::/64')},{label:'R1 has remote IPv6 route',ok:s.packet.ipv6.routes.R1.includes('2001:db8:20::/64')}); break;
    default: return {ok:false,score:0,checks:[],message:'Unknown scenario'};
  }
  const completed=checks.filter(c=>c.ok).length;
  return {caseId,checks,completed,total:checks.length,score:Math.round(completed/checks.length*100),ok:completed===checks.length};
}

export function tracePacket(state,caseId){
  const s=derivePacketState(state); const result=evaluatePacketCase(s,caseId); const scenario=PACKET_SCENARIOS.find(x=>x.id===caseId); const steps=[];
  const add=(id,label,device,status,ok,event,detail,evidence)=>steps.push({id,label,device,status,ok,event,detail,evidence});
  if(caseId==='ipv6-nd'){
    add('src','SOURCE','PC1','EMIT',true,'PC1 emits IPv6 traffic','The host sends toward the remote IPv6 prefix.','2001:db8:10::10 → 2001:db8:20::10');
    add('nd','NDP','R1',s.derived.ipv6Reachable?'REACHABLE':'BLOCKED',s.derived.ipv6Reachable,'First-hop IPv6 forwarding gate',s.derived.ipv6Reachable?'R1 is permitted to forward IPv6.':'R1 has IPv6 forwarding disabled.','ipv6 unicast-routing: '+(s.derived.ipv6Reachable?'enabled':'disabled'));
    add('route','ROUTE','R2','FOUND',true,'Destination prefix lookup','R2 owns the remote LAN.','2001:db8:20::/64 · connected');
    add('dst','DESTINATION','SRV1',result.ok?'DELIVERED':'BLOCKED',result.ok,'Remote delivery','The packet can only reach the destination after the first-hop gate succeeds.', '2001:db8:20::10');
  } else if(caseId==='acl-echo'){
    add('ingress','INGRESS','R1','ARRIVE',true,'ICMP echo arrives','The packet reaches the ACL evaluation point.','10.10.10.10 → 10.20.20.10 · ICMP');
    add('acl','ACL','R1',s.derived.aclAllowsPing?'PERMIT':'DENY',s.derived.aclAllowsPing,'ACL 101 decision',s.derived.aclAllowsPing?'No matching ICMP deny remains.':'The explicit ICMP deny matches the server.',s.derived.aclAllowsPing?'permit ip any':'deny icmp 10.20.20.10');
    add('route','ROUTE','R2','FORWARD',true,'Destination route lookup','R2 has a connected route to the server LAN.','C 10.20.20.0/24 · Gi0/1');
    add('dst','DESTINATION','SRV1',s.derived.aclAllowsPing?'DELIVERED':'BLOCKED',s.derived.aclAllowsPing,'Server receives echo','ACL outcome controls delivery.','ICMP echo request');
  } else if(caseId==='dhcp-relay'){
    add('discover','DISCOVER','PC2','BROADCAST',true,'DHCPDISCOVER emitted','The client broadcasts because no lease is installed.','0.0.0.0:68 → 255.255.255.255:67');
    add('relay','RELAY','R1',s.derived.dhcpRelayReady?'FORWARD':'BLOCKED',s.derived.dhcpRelayReady,'DHCP relay checks helper',s.derived.dhcpRelayReady?'R1 forwards to the DHCP server.':'No helper address is configured.','Gi0/0 helper: '+(s.packet.dhcpRelay.helper||'none'));
    add('server','SERVER','DHCP','OFFER',s.derived.dhcpRelayReady,'DHCPOFFER prepared','The modeled pool can answer once relay is operational.','Pool 10.10.10.0/24');
    add('bind','BIND','PC2',s.packet.dhcpRelay.clientState==='BOUND'?'BOUND':'WAIT',s.packet.dhcpRelay.clientState==='BOUND','Lease state','A successful DORA flow ends with BOUND.','10.10.10.100');
  } else if(caseId==='nat-flow'){
    add('inside','INSIDE','R1',s.packet.nat.inside.includes('GigabitEthernet0/0')?'MARKED':'MISSING',s.packet.nat.inside.includes('GigabitEthernet0/0'),'NAT inside role',s.packet.nat.inside.includes('GigabitEthernet0/0')?'Inside interface identified.':'Inside interface role is missing.','Gi0/0');
    add('rule','RULE','R1','OVERLOAD',true,'PAT rule evaluated','The overload rule uses Gi0/1 as the public interface.','ip nat inside source list 1 interface Gi0/1 overload');
    add('xlate','XLATE','R1',s.derived.natReady?'CREATED':'BLOCKED',s.derived.natReady,'Translation allocation',s.derived.natReady?'Translation slot created.':'NAT cannot allocate without the inside role.',s.derived.natReady?'10.10.10.10 → 203.0.113.2':'No translation');
    add('wan','WAN','WAN',s.derived.natReady?'FORWARD':'DROP',s.derived.natReady,'Translated packet leaves R1','The WAN sees the translated source address.','203.0.113.2 → 198.51.100.10');
  } else if(caseId==='stp-convergence'){
    add('bpdu','BPDUS','SW1 / SW2','RECEIVE',true,'BPDUs exchanged','Bridge IDs are compared per VLAN.','SW1 VLAN20 priority '+s.packet.stp.vlans[20].sw1Priority+' · SW2 '+s.packet.stp.vlans[20].sw2Priority);
    add('root','ROOT','SW1',s.packet.stp.vlans[20].root==='SW1'?'ROOT':'NONROOT',s.packet.stp.vlans[20].root==='SW1','VLAN 20 root selection','Lower bridge priority wins.','Root: '+s.packet.stp.vlans[20].root);
    add('forward','PORT','SW1 / SW2',s.derived.stpReady?'FWD':'BLOCKED',s.derived.stpReady,'Forwarding state','The intended inter-switch path becomes usable after convergence.','SW1-SW2: '+(s.derived.stpReady?'forwarding':'blocked'));
  } else if(caseId==='lacp-bundle'){
    add('actor','ACTOR','SW1','ACTIVE',true,'SW1 initiates LACP','Active mode sends negotiation PDUs.','Gi0/21 + Gi0/22 · active');
    add('partner','PARTNER','SW2',s.packet.etherchannel.sw2.Gi0_21==='active'?'ACTIVE':'PASSIVE',s.packet.etherchannel.sw2.Gi0_21==='active','SW2 negotiation','The member must agree to active negotiation in this lab.', 'Gi0/21: '+s.packet.etherchannel.sw2.Gi0_21);
    add('member','MEMBER','SW2',s.packet.etherchannel.sw2.Gi0_22==='active'?'IN':'OUT',s.packet.etherchannel.sw2.Gi0_22==='active','Second member participation','Gi0/22 must join the bundle.','Gi0/22: '+s.packet.etherchannel.sw2.Gi0_22);
    add('bundle','BUNDLE','SW1 / SW2',s.derived.lacpReady?'FORMED':'DOWN',s.derived.lacpReady,'Port-channel state','The bundle forms only when all required members agree.','Po1: '+(s.derived.lacpReady?'SU':'SD'));
  } else if(caseId==='dualstack'){
    add('gate','IPv6','R1',s.derived.ipv6Reachable?'ENABLED':'DISABLED',s.derived.ipv6Reachable,'IPv6 forwarding gate','IPv6 routing requires forwarding to be enabled.','ipv6 unicast-routing: '+(s.derived.ipv6Reachable?'enabled':'disabled'));
    const route=s.packet.ipv6.routes.R1.includes('2001:db8:20::/64');
    add('route','ROUTE','R1',route?'FOUND':'MISSING',route,'Remote IPv6 route lookup','R1 needs the destination prefix in its routing table.','2001:db8:20::/64');
    add('remote','REMOTE','R2','CONNECTED',true,'R2 owns the destination LAN','The remote prefix is connected to R2.','2001:db8:20::/64 · connected');
    add('delivery','DELIVERY','SRV1',result.ok?'DELIVERED':'BLOCKED',result.ok,'End-to-end IPv6 delivery','Forwarding and routing must both succeed.','2001:db8:20::10');
  }
  return {caseId,scenario,steps,passed:steps.filter(x=>x.ok).length,total:steps.length,complete:result.ok,score:result.score};
}

export function repairPacketCase(input,caseId){
  const s=clone(input); const p=s.packet;
  if(caseId==='ipv6-nd')p.ipv6.forwarding.R1=true;
  if(caseId==='acl-echo')p.acl.rules=[{action:'permit',protocol:'ip',destination:'any'}];
  if(caseId==='dhcp-relay'){p.dhcpRelay.helper='10.10.10.100';p.dhcpRelay.clientState='BOUND';}
  if(caseId==='nat-flow'){p.nat.inside=['GigabitEthernet0/0'];p.nat.outside=['GigabitEthernet0/1'];p.nat.overload=true;}
  if(caseId==='stp-convergence'){p.stp.vlans[10].sw1Priority=12288;p.stp.vlans[20].sw1Priority=12288;}
  if(caseId==='lacp-bundle'){p.etherchannel.sw1.Gi0_21='active';p.etherchannel.sw1.Gi0_22='active';p.etherchannel.sw2.Gi0_21='active';p.etherchannel.sw2.Gi0_22='active';}
  if(caseId==='dualstack'){p.ipv6.forwarding.R1=true;if(!p.ipv6.routes.R1.includes('2001:db8:20::/64'))p.ipv6.routes.R1.push('2001:db8:20::/64');}
  return derivePacketState(s);
}

export function packetSnapshot(state){
  const s=derivePacketState(state);
  return {
    ipv6:s.derived.ipv6Reachable,
    acl:s.derived.aclAllowsPing,
    dhcpRelay:s.derived.dhcpRelayReady && s.packet.dhcpRelay.clientState==='BOUND',
    nat:s.derived.natReady,
    stp:s.derived.stpReady,
    etherchannel:s.derived.lacpReady,
  };
}
