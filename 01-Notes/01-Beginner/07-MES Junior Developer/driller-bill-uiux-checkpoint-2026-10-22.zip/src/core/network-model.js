export const DEVICES = ['R1','R2','SW1','SW2'];
export const ENDPOINTS = ['PC1','PC2','SRV1'];

export const TOPOLOGY = [
  {id:'R1',x:28,y:16,kind:'router',label:'R1'},
  {id:'R2',x:72,y:16,kind:'router',label:'R2'},
  {id:'SW1',x:28,y:50,kind:'switch',label:'SW1'},
  {id:'SW2',x:72,y:50,kind:'switch',label:'SW2'},
  {id:'PC1',x:12,y:82,kind:'host',label:'PC1'},
  {id:'PC2',x:39,y:82,kind:'host',label:'PC2'},
  {id:'SRV1',x:88,y:82,kind:'server',label:'SRV1'}
];

export const LINKS = [
  {id:'r1-r2',from:'R1',to:'R2',label:'Gi0/1 ↔ Gi0/0',a:'R1',ai:'GigabitEthernet0/1',b:'R2',bi:'GigabitEthernet0/0',kind:'l3'},
  {id:'r1-sw1',from:'R1',to:'SW1',label:'Gi0/0 ↔ Gi0/23 · VLAN 10',a:'R1',ai:'GigabitEthernet0/0',b:'SW1',bi:'GigabitEthernet0/23',kind:'access',vlan:10},
  {id:'r2-sw2',from:'R2',to:'SW2',label:'Gi0/1 ↔ Gi0/23 · VLAN 20',a:'R2',ai:'GigabitEthernet0/1',b:'SW2',bi:'GigabitEthernet0/23',kind:'access',vlan:20},
  {id:'sw1-sw2',from:'SW1',to:'SW2',label:'Gi0/24 ↔ Gi0/24 · TRUNK',a:'SW1',ai:'GigabitEthernet0/24',b:'SW2',bi:'GigabitEthernet0/24',kind:'trunk'},
  {id:'sw1-pc1',from:'SW1',to:'PC1',label:'Gi0/1 · VLAN 10',a:'SW1',ai:'GigabitEthernet0/1',b:'PC1',kind:'access',vlan:10},
  {id:'sw1-pc2',from:'SW1',to:'PC2',label:'Gi0/5 · VLAN 20',a:'SW1',ai:'GigabitEthernet0/5',b:'PC2',kind:'access',vlan:20},
  {id:'sw2-srv1',from:'SW2',to:'SRV1',label:'Gi0/5 · VLAN 20',a:'SW2',ai:'GigabitEthernet0/5',b:'SRV1',kind:'access',vlan:20}
];

const router = (name, interfaces, routes, ospf, mac) => ({
  name, kind:'router', mode:'exec', hostname:name, interfaces, routes, ospf, mac, version:'17.12.04', configInterface:null, configVlan:null, configRouter:null
});
const iface = (ip='',mask='',extra={}) => ({ip,mask,admin:true,link:true,...extra});
const switchIface = (mode='access', accessVlan=1, extra={}) => ({mode,accessVlan,admin:true,link:true,...extra});

export function freshNetwork(){
  return {
    devices:{
      R1:router('R1',{
        'GigabitEthernet0/0':iface('10.10.10.1','255.255.255.0'),
        'GigabitEthernet0/1':iface('10.0.12.1','255.255.255.252'),
        'Loopback0':iface('1.1.1.1','255.255.255.255')
      },[
        {type:'C',prefix:'10.10.10.0/24',next:'direct',iface:'Gi0/0'},
        {type:'C',prefix:'10.0.12.0/30',next:'direct',iface:'Gi0/1'}
      ],{process:1,routerId:'1.1.1.1',networks:['10.0.12.0 0.0.0.3 area 0']},'0011.2233.4455'),
      R2:router('R2',{
        'GigabitEthernet0/0':iface('10.0.12.2','255.255.255.252'),
        'GigabitEthernet0/1':iface('10.20.20.1','255.255.255.0'),
        'Loopback0':iface('2.2.2.2','255.255.255.255')
      },[
        {type:'C',prefix:'10.0.12.0/30',next:'direct',iface:'Gi0/0'},
        {type:'C',prefix:'10.20.20.0/24',next:'direct',iface:'Gi0/1'}
      ],{process:1,routerId:'2.2.2.2',networks:['10.0.12.0 0.0.0.3 area 0','10.20.20.0 0.0.0.255 area 0']},'0011.2233.5566'),
      SW1:{name:'SW1',kind:'switch',mode:'exec',hostname:'SW1',interfaces:{
        'GigabitEthernet0/1':switchIface('access',10),
        'GigabitEthernet0/5':switchIface('access',20),
        'GigabitEthernet0/23':switchIface('access',10),
        'GigabitEthernet0/24':switchIface('trunk',1,{nativeVlan:99,allowedVlans:[10,20,99]})
      },vlans:{1:'default',10:'USERS',20:'SERVERS',99:'MANAGEMENT'},etherchannel:{group:1,protocol:'LACP',ports:['Gi0/21','Gi0/22'],members:{'Gi0/21':true,'Gi0/22':true}},stp:{priority:24576,mac:'0011.2233.4455'},version:'17.12.04',configInterface:null,configVlan:null,configRouter:null},
      SW2:{name:'SW2',kind:'switch',mode:'exec',hostname:'SW2',interfaces:{
        'GigabitEthernet0/5':switchIface('access',20),
        'GigabitEthernet0/23':switchIface('access',20),
        'GigabitEthernet0/24':switchIface('trunk',1,{nativeVlan:99,allowedVlans:[10,99]})
      },vlans:{1:'default',10:'USERS',20:'SERVERS',99:'MANAGEMENT'},etherchannel:{group:1,protocol:'LACP',ports:['Gi0/21','Gi0/22'],members:{'Gi0/21':true,'Gi0/22':true}},stp:{priority:32768,mac:'0011.2233.5566'},version:'17.12.04',configInterface:null,configVlan:null,configRouter:null}
    },
    clients:{
      PC1:{ip:'10.10.10.10',mask:'255.255.255.0',gateway:'10.10.10.1',vlan:10,switch:'SW1',port:'GigabitEthernet0/1'},
      PC2:{ip:'10.20.20.20',mask:'255.255.255.0',gateway:'10.20.20.1',vlan:20,switch:'SW1',port:'GigabitEthernet0/5'},
      SRV1:{ip:'10.20.20.10',mask:'255.255.255.0',gateway:'10.20.20.1',vlan:20,switch:'SW2',port:'GigabitEthernet0/5'}
    }
  };
}

export const LAB_TASKS = [
  {id:'vlan20-trunk',title:'Restore VLAN 20 across the inter-switch trunk',objective:'2.2 / 2.3',device:'SW2',brief:'PC2 and SRV1 share VLAN 20, but SW2 is not permitting VLAN 20 across Gi0/24.',target:{iface:'GigabitEthernet0/24',mode:'trunk',nativeVlan:99,requiredVlans:[10,20,99]},checks:['Gi0/24 is trunking','Native VLAN is 99','VLANs 10, 20 and 99 are allowed'],hint:'Inspect both trunk ends, then use `switchport trunk allowed vlan 10,20,99` on SW2.'},
  {id:'native-vlan',title:'Correct the native VLAN on the trunk',objective:'2.2',device:'SW2',brief:'The trunk policy is present, but SW2 is using VLAN 1 as its native VLAN. Align it to VLAN 99.',target:{iface:'GigabitEthernet0/24',mode:'trunk',nativeVlan:99,requiredVlans:[10,20,99]},checks:['Gi0/24 is trunking','Native VLAN is 99','Required VLANs remain permitted'],hint:'Use `switchport trunk native vlan 99`, then verify with `show interfaces trunk`.'},
  {id:'server-access',title:'Place the server edge in VLAN 20',objective:'2.1 / 2.3',device:'SW2',brief:'SRV1 is connected to SW2 Gi0/5 but has been placed in VLAN 10. Restore the server access VLAN.',target:{iface:'GigabitEthernet0/5',mode:'access',accessVlan:20,admin:true},checks:['Gi0/5 is access mode','Access VLAN is 20','Interface is not shutdown'],hint:'Enter Gi0/5, use access mode, then `switchport access vlan 20`.'},
  {id:'recover-trunk',title:'Recover the inter-switch link without changing policy',objective:'2.2',device:'SW2',brief:'The inter-switch trunk is administratively down. Bring it up while preserving its existing VLAN policy.',target:{iface:'GigabitEthernet0/24',mode:'trunk',nativeVlan:99,admin:true,requiredVlans:[10,20,99]},checks:['Gi0/24 is up','Native VLAN is 99','VLAN 20 is still permitted'],hint:'Use `no shutdown` on Gi0/24 and avoid replacing its trunk policy.'},
  {id:'static-route',title:'Install a static route from R1 to VLAN 20',objective:'3.2',device:'R1',brief:'R1 must reach 10.20.20.0/24 through R2 at 10.0.12.2.',target:{route:'10.20.20.0/24',next:'10.0.12.2'},checks:['10.20.20.0/24 exists in R1 routing table','Next hop is 10.0.12.2'],hint:'Use `ip route 10.20.20.0 255.255.255.0 10.0.12.2`.'},
  {id:'r2-gateway',title:'Restore the VLAN 20 gateway edge',objective:'3.3 / 2.1',device:'SW2',brief:'R2 provides the VLAN 20 gateway through SW2 Gi0/23. The access port is in VLAN 10.',target:{iface:'GigabitEthernet0/23',mode:'access',accessVlan:20,admin:true},checks:['Gi0/23 is access mode','Access VLAN is 20','Interface is not shutdown'],hint:'Inspect `show interfaces gi0/23` and place the gateway edge in VLAN 20.'}
];

export const HELP = `IOS LAB — STATEFUL MULTI-DEVICE SURFACE\n\nEXEC / SHOW\n  show ip interface brief\n  show interfaces <interface>\n  show interfaces status\n  show interfaces trunk\n  show interfaces switchport <interface>\n  show ip route\n  show ip protocols\n  show ip ospf neighbor\n  show cdp neighbors\n  show lldp neighbors\n  show vlan brief\n  show etherchannel summary\n  show spanning-tree [vlan <id>]\n  show mac address-table\n  show running-config\n  show version\n  ping <IPv4>\n\nCONFIGURATION\n  enable\n  configure terminal\n  interface <interface>\n  vlan <id>\n  name <name>\n  switchport mode trunk\n  switchport mode access\n  switchport access vlan <id>\n  switchport trunk native vlan <id>\n  switchport trunk allowed vlan <list>\n  switchport trunk allowed vlan add <list>\n  switchport trunk allowed vlan remove <list>\n  ip address <ip> <mask>\n  ip route <network> <mask> <next-hop>\n  router ospf <process>\n  router-id <id>\n  network <network> <wildcard> area <area>\n  spanning-tree vlan <id> priority <value>\n  no shutdown / shutdown\n  end / exit\n  clear\n\nThis is a controlled educational simulator, not a Cisco IOS implementation.`;

function isClient(id){return ENDPOINTS.includes(id);}
function getNode(state,id){return isClient(id)?state.clients[id]:state.devices[id];}
function bitsToPrefix(mask){let count=0;for(const oct of mask.split('.'))count += Number(oct).toString(2).replace(/0/g,'').length;return count;}
function networkAddress(ip,mask){const a=ip.split('.').map(Number),m=mask.split('.').map(Number);return a.map((x,i)=>x&m[i]).join('.');}
function prefixMask(prefix){let p=Number(prefix),oct=[];for(let i=0;i<4;i++){const bits=Math.max(0,Math.min(8,p));oct.push(bits===0?0:256-(2**(8-bits)));p-=bits;}return oct.join('.');}
function normalizeInterface(raw=''){const x=raw.trim().toLowerCase().replace(/^int(?:erface)?\s+/,'');const g=x.match(/^(?:gi|gig|gigabitethernet)(\d+\/\d+(?:\/\d+)?)$/);if(g)return `GigabitEthernet${g[1]}`;if(/^lo(?:opback)?0$/.test(x))return 'Loopback0';return raw.trim();}
export function compactInterface(name=''){return name.replaceAll('GigabitEthernet','Gi').replaceAll('Loopback','Lo');}
function parseList(value,current=[]){const out=[];for(const token of value.split(',')){const t=token.trim();if(!t)continue;if(t.includes('-')){const [a,b]=t.split('-').map(Number);for(let i=Math.min(a,b);i<=Math.max(a,b);i++)out.push(i);}else if(/^\d+$/.test(t))out.push(Number(t));}return [...new Set(out.length?out:current)].sort((a,b)=>a-b);}
function ifaceUp(i){return !!i?.admin&&!!i?.link;}
export function linkInfo(state,link){
  const a=getNode(state,link.a), b=getNode(state,link.b);
  if(link.kind==='l3')return {healthy:ifaceUp(a.interfaces[link.ai])&&ifaceUp(b.interfaces[link.bi]),reason:'routed link'};
  if(link.kind==='access'){
    const ai=a.interfaces?.[link.ai], bi=b.interfaces?.[link.bi];
    const switchSide = a.kind==='switch'?ai:bi;
    const endpointSide = a.kind==='switch'?bi:ai;
    const endpointOk = !endpointSide || ifaceUp(endpointSide);
    return {healthy:!!switchSide&&ifaceUp(switchSide)&&endpointOk&&switchSide.mode==='access'&&switchSide.accessVlan===link.vlan,reason:`VLAN ${link.vlan} access segment`};
  }
  const ai=a.interfaces[link.ai], bi=b.interfaces[link.bi];
  const healthy=!!ai&&!!bi&&ifaceUp(ai)&&ifaceUp(bi)&&ai.mode==='trunk'&&bi.mode==='trunk'&&ai.allowedVlans.some(v=>bi.allowedVlans.includes(v));
  let reason='trunk has a common allowed VLAN';
  if(healthy&&ai.nativeVlan!==bi.nativeVlan)reason='native VLAN mismatch (link can still carry tagged VLANs)';
  return {healthy,reason};
}

function switchVlanPath(state,sourceSwitch,targetSwitch,vlan){
  if(sourceSwitch===targetSwitch)return true;
  const trunk=LINKS.find(l=>l.kind==='trunk' && ((l.a===sourceSwitch&&l.b===targetSwitch)||(l.a===targetSwitch&&l.b===sourceSwitch)));
  if(!trunk)return false;
  const a=state.devices[trunk.a].interfaces[trunk.ai], b=state.devices[trunk.b].interfaces[trunk.bi];
  return ifaceUp(a)&&ifaceUp(b)&&a.mode==='trunk'&&b.mode==='trunk'&&a.allowedVlans.includes(vlan)&&b.allowedVlans.includes(vlan);
}

function endpointSegment(state,clientId){const c=state.clients[clientId];const port=state.devices[c.switch].interfaces[c.port];return {healthy:ifaceUp(port)&&port.mode==='access'&&port.accessVlan===c.vlan,switch:c.switch,vlan:c.vlan};}

export function tracePath(state,sourceId,targetIp){
  const targetId=Object.entries(state.clients).find(([,c])=>c.ip===targetIp)?.[0];
  if(!targetId)return {ok:false,reason:'Unknown endpoint address',hops:[]};
  if(sourceId===targetId)return {ok:true,reason:'Source and destination are the same endpoint',hops:[sourceId]};
  const target=state.clients[targetId];
  const source=state.clients[sourceId];
  if(source){
    const s=endpointSegment(state,sourceId);const t=endpointSegment(state,targetId);
    const hops=[sourceId,s.switch];
    if(!s.healthy)return {ok:false,reason:`${source.port} does not present VLAN ${source.vlan}.`,hops};
    if(source.vlan===target.vlan){
      const l2=switchVlanPath(state,s.switch,t.switch,source.vlan);
      if(l2){hops.push(...(s.switch===t.switch?[]:[t.switch]),targetId);return {ok:t.healthy,reason:t.healthy?'Layer 2 path is available.':`${targetId} access segment is down.`,hops};}
      return {ok:false,reason:`VLAN ${source.vlan} is not traversing the switched path between ${s.switch} and ${t.switch}.`,hops};
    }
    if(target.vlan===20 && target.gateway==='10.20.20.1'){
      const r2edge=LINKS.find(l=>l.id==='r2-sw2'); const r2up=linkInfo(state,r2edge).healthy;
      const trunk=LINKS.find(l=>l.id==='sw1-sw2'); const vlan20=switchVlanPath(state,'SW1','SW2',20);
      if(!t.healthy)return {ok:false,reason:`${targetId} access segment is down.`,hops};
      if(source.gateway==='10.20.20.1' && r2up && (source.vlan===20?true:vlan20)){hops.push(...(s.switch==='SW2'?[]:['SW2']),'R2',targetId);return {ok:true,reason:'VLAN 20 reaches R2 and the destination segment is available.',hops};}
      if(r2up&&vlan20){hops.push('R2',targetId);return {ok:true,reason:'Inter-VLAN path is available through R2.',hops};}
      return {ok:false,reason:'The VLAN 20 path is blocked before the gateway.',hops};
    }
    return {ok:false,reason:'No simulated Layer 3 path is available for this source.',hops};
  }
  if(sourceId==='R1'||sourceId==='R2'){
    const r=state.devices[sourceId];
    const route=effectiveRoutes(state,sourceId).find(x=>x.prefix===`${target.ip}/24` || x.prefix===`${target.ip}/32` || (target.ip.startsWith('10.20.20.')&&x.prefix==='10.20.20.0/24'));
    if(!route)return {ok:false,reason:`${sourceId} has no matching route for ${target.ip}.`,hops:[sourceId]};
    if(route.type==='S' || route.type==='O'){
      const next=route.next;
      const nextRouter=Object.entries(state.devices).find(([id,d])=>d.kind==='router'&&Object.values(d.interfaces).some(i=>i.ip===next))?.[0];
      if(!nextRouter)return {ok:false,reason:`Next hop ${next} is not reachable in the simulated topology.`,hops:[sourceId]};
      const p2p=LINKS.find(l=>l.kind==='l3'&&((l.a===sourceId&&l.b===nextRouter)||(l.a===nextRouter&&l.b===sourceId)));
      if(!p2p||!linkInfo(state,p2p).healthy)return {ok:false,reason:'The routed transit link is down.',hops:[sourceId,nextRouter]};
      const tail=tracePath(state,nextRouter,targetIp);
      return {ok:tail.ok,reason:tail.reason,hops:[sourceId,nextRouter,...tail.hops.slice(1)]};
    }
    const edge=sourceId==='R1'?LINKS.find(l=>l.id==='r1-sw1'):LINKS.find(l=>l.id==='r2-sw2');
    const tail=linkInfo(state,edge);
    const sourceSwitch=edge.to;
    const l2Reach=target.switch===sourceSwitch?switchVlanPath(state,sourceSwitch,target.switch,target.vlan):switchVlanPath(state,sourceSwitch,target.switch,target.vlan);
    return {ok:tail.healthy&&l2Reach&&endpointSegment(state,targetId).healthy,reason:tail.healthy?(l2Reach?'Connected route reaches the destination VLAN.':'Destination VLAN is not reachable across the switched path.'):'Connected edge is down.',hops:[sourceId,sourceSwitch,...(target.switch===sourceSwitch?[]:[target.switch]),targetId]};
  }
  return {ok:false,reason:'Unsupported source node.',hops:[]};
}

export function effectiveRoutes(state,deviceName){
  const dev=state.devices[deviceName];if(dev.kind!=='router')return [];
  const connected=[];
  for(const [name,i] of Object.entries(dev.interfaces))if(i.ip&&i.mask&&ifaceUp(i))connected.push({type:'C',prefix:`${networkAddress(i.ip,i.mask)}/${bitsToPrefix(i.mask)}`,next:'direct',iface:compactInterface(name),metric:0,ad:0});
  const staticRoutes=dev.routes.filter(r=>r.type==='S'||r.type==='S*');
  const ospf=[];
  if(dev.ospf){
    for(const [otherName,other] of Object.entries(state.devices)){
      if(otherName===deviceName||other.kind!=='router'||!other.ospf)continue;
      const transitLink=LINKS.find(l=>l.kind==='l3'&&((l.a===deviceName&&l.b===otherName)||(l.b===deviceName&&l.a===otherName)));
      if(!transitLink||!linkInfo(state,transitLink).healthy)continue;
      const remoteConnected=Object.entries(other.interfaces)
        .filter(([,i])=>i.ip&&i.mask&&ifaceUp(i))
        .map(([n,i])=>({type:'C',prefix:`${networkAddress(i.ip,i.mask)}/${bitsToPrefix(i.mask)}`,next:'direct',iface:compactInterface(n)}))
        .filter(r=>r.prefix!=='10.0.12.0/30');
      for(const r of remoteConnected)ospf.push({...r,type:'O',next:Object.values(other.interfaces).find(i=>i.ip?.startsWith('10.0.12.')&&ifaceUp(i))?.ip||'10.0.12.2',iface:deviceName==='R1'?'Gi0/1':'Gi0/0',ad:110,metric:20});
    }
  }
  const dedup=new Map();for(const r of [...connected,...staticRoutes,...ospf]){const rank=r.type==='C'?1:r.type==='O'?2:3;if(!dedup.has(r.prefix)||rank<dedup.get(r.prefix)._rank)dedup.set(r.prefix,{...r,_rank:rank});}return [...dedup.values()].map(({_rank,...r})=>r);
}

function showIpBrief(dev){return ['Interface'.padEnd(24)+'IP-Address'.padEnd(17)+'Status'.padEnd(13)+'Protocol',...Object.entries(dev.interfaces).map(([n,i])=>`${compactInterface(n).padEnd(24)}${(i.ip||'unassigned').padEnd(17)}${(i.admin&&i.link?'up':'administratively down').padEnd(13)}${i.admin&&i.link?'up':'down'}`)].join('\n');}
function showInt(dev,name){const i=dev.interfaces[name];if(!i)return `% Interface ${name} not found.`;const body=[`${name} is ${ifaceUp(i)?'up':'down'}, line protocol is ${ifaceUp(i)?'up':'down'}`,`  Hardware is simulated`,`  Internet address is ${i.ip||'not set'}`,`  MTU 1500 bytes`];if(dev.kind==='switch'){const sw=/** @type {any} */ (i);body.push(i.mode==='trunk'?`  Switchport trunk native VLAN ${sw.nativeVlan}, allowed ${(sw.allowedVlans||[]).join(',')}`:`  Switchport access VLAN ${sw.accessVlan}`);}return body.join('\n');}
function showTrunks(state,dev){const out=[];for(const [n,i] of Object.entries(dev.interfaces).filter(([,x])=>x.mode==='trunk')){const sw=/** @type {any} */ (i);const peer=LINKS.find(l=>l.kind==='trunk'&&l.a===dev.name&&l.ai===n||l.kind==='trunk'&&l.b===dev.name&&l.bi===n);const other=peer?state.devices[peer.a===dev.name?peer.b:peer.a]:null;const otherI=peer?other.interfaces[peer.a===dev.name?peer.bi:peer.ai]:null;const allowed=sw.allowedVlans||[];out.push(`Port        Mode   Encapsulation  Status         Native vlan\n${compactInterface(n).padEnd(12)}on     802.1q          ${(ifaceUp(i)&&(!otherI||ifaceUp(otherI))?'trunking':'not-trunking').padEnd(14)}${sw.nativeVlan||1}\n\nPort        Vlans allowed on trunk\n${compactInterface(n).padEnd(12)}${allowed.join(',')}\n\nPort        Vlans allowed and active in management domain\n${compactInterface(n).padEnd(12)}${allowed.filter(v=>dev.vlans[v]).join(',')}`);}
return out.length?out.join('\n\n'):'% No trunking interfaces.';}
function showSwitchport(dev,name){const i=dev.interfaces[name];if(!i)return `% Interface ${name} not found.`;if(dev.kind!=='switch')return `% Invalid input detected at '^' marker.`;return `Name: ${compactInterface(name)}\nSwitchport: Enabled\nAdministrative Mode: ${i.mode==='trunk'?'trunk':'static access'}\nOperational Mode: ${i.mode==='trunk'?'trunk':'static access'}\nAccess Mode VLAN: ${i.mode==='access'?i.accessVlan:'1'}\nTrunking Native Mode VLAN: ${i.nativeVlan||'1'}\nTrunking VLANs Enabled: ${i.allowedVlans?.join(',')||'none'}`;}
function showVlan(dev){return ['VLAN Name                             Status    Ports','---- -------------------------------- --------- -------------------------------',...Object.entries(dev.vlans).map(([id,name])=>{const ports=Object.entries(dev.interfaces).filter(([,i])=>i.mode==='access'&&i.accessVlan===Number(id)).map(([n])=>compactInterface(n)).join(', ');return `${id.padEnd(5)}${name.padEnd(32)}active    ${ports}`})].join('\n');}
function showRun(dev){const lines=[`hostname ${dev.hostname}`,'!'];for(const [n,i] of Object.entries(dev.interfaces)){lines.push(`interface ${n}`);if(i.ip)lines.push(` ip address ${i.ip} ${i.mask}`);if(dev.kind==='switch'&&i.mode==='access')lines.push(' switchport mode access',` switchport access vlan ${i.accessVlan}`);if(dev.kind==='switch'&&i.mode==='trunk')lines.push(' switchport mode trunk',` switchport trunk native vlan ${i.nativeVlan}`,` switchport trunk allowed vlan ${i.allowedVlans.join(',')}`);lines.push(i.admin?' no shutdown':' shutdown','!');}for(const r of dev.routes.filter(x=>x.type==='S'||x.type==='S*'))lines.push(`ip route ${r.prefix.split('/')[0]} ${prefixMask(r.prefix.split('/')[1])} ${r.next}`,'!');if(dev.ospf){lines.push(`router ospf ${dev.ospf.process}`,` router-id ${dev.ospf.routerId}`,...dev.ospf.networks.map(n=>` network ${n}`),'!');}if(dev.kind==='switch')lines.push(`spanning-tree vlan 1 priority ${dev.stp.priority}`,'!');return lines.join('\n');}
function showStp(state,dev){if(dev.kind!=='switch')return '% STP is not applicable.';const switches=Object.values(state.devices).filter(d=>d.kind==='switch');const root=[...switches].sort((a,b)=>a.stp.priority-b.stp.priority||a.stp.mac.localeCompare(b.stp.mac))[0];const isRoot=root.name===dev.name;return `VLAN0001\n  Root ID    Priority    ${root.stp.priority}\n             Address     ${root.stp.mac}\n             ${isRoot?'This bridge is the root':`Root port   Gi0/24` }\n\nInterface        Role Sts Cost      Prio.Nbr\nGi0/24           ${isRoot?'Desg':'Root'} FWD 4         128.24`;}
function showEther(dev){const m=Object.entries(dev.etherchannel.members).map(([p,up])=>`${p}(${up?'P':'s'})`).join(' ');const flag=Object.values(dev.etherchannel.members).every(Boolean)?'SU':'SD';return `Group  Port-channel  Protocol    Ports\n${dev.etherchannel.group}      Po${dev.etherchannel.group}(${flag})         ${dev.etherchannel.protocol}        ${m}`;}
function showNeighbors(state,dev){const rows=LINKS.filter(l=>l.a===dev.name||l.b===dev.name).map(l=>{const peer=l.a===dev.name?l.b:l.a;return {l,peer};}).filter(x=>!isClient(x.peer)&&linkInfo(state,x.l).healthy).map(({l,peer})=>`${peer.padEnd(16)}${compactInterface(dev.name===l.a?l.ai:l.bi).padEnd(16)}up           ${compactInterface(dev.name===l.a?l.bi:l.ai)}`);return rows.length?['Device ID        Local Intrfce     Status       Port ID',...rows].join('\n'):'% No neighbors detected.';}
function showMac(dev){if(dev.kind!=='switch')return '% MAC address table unavailable.';return `Vlan    Mac Address       Type       Ports\n----    -----------       --------   -----\n10      aaaa.bbbb.cc01   DYNAMIC    Gi0/1\n20      aaaa.bbbb.cc20   DYNAMIC    Gi0/5\n99      aaaa.bbbb.cc99   DYNAMIC    Gi0/24`;}

export function deriveShow(state,deviceName,command){
  const dev=state.devices[deviceName];if(!dev)return null;const c=command.trim().toLowerCase().replace(/\s+/g,' ');
  if(c==='show ip interface brief')return showIpBrief(dev);
  if(c==='show ip route')return dev.kind==='router'?`Gateway of last resort is ${effectiveRoutes(state,deviceName).find(r=>r.type==='S*')?.next||'not set'}\n\n${effectiveRoutes(state,deviceName).map(r=>`${r.type.padEnd(4)}${r.prefix} ${r.next==='direct'?'is directly connected, '+r.iface:`[${r.ad}/${r.metric}] via ${r.next}, ${r.iface}`}`).join('\n')}`:'% IP routing not active on this simulated switch.';
  if(c==='show ip protocols')return dev.ospf?`Routing Process "ospf ${dev.ospf.process}" with ID ${dev.ospf.routerId}\n\nRouting for Networks:\n${dev.ospf.networks.join('\n')}`:'% OSPF not configured.';
  if(c==='show ip ospf neighbor'){const transit=LINKS.find(l=>l.id==='r1-r2');const up=!!transit&&linkInfo(state,transit).healthy;return dev.ospf&&up?`Neighbor ID     Pri   State           Dead Time   Address         Interface\n${deviceName==='R1'?'2.2.2.2':'1.1.1.1'}           1   FULL/ -        00:00:33    ${deviceName==='R1'?'10.0.12.2':'10.0.12.1'}       ${deviceName==='R1'?'Gi0/1':'Gi0/0'}`:dev.ospf?'% No OSPF neighbors are currently in FULL state.':'% OSPF not configured.';}
  if(c==='show cdp neighbors'||c==='show lldp neighbors')return showNeighbors(state,dev);
  if(c==='show vlan brief')return dev.kind==='switch'?showVlan(dev):'% Invalid input detected at \'^\' marker.';
  if(c==='show interfaces trunk')return dev.kind==='switch'?showTrunks(state,dev):'% Invalid input detected at \'^\' marker.';
  const sp=c.match(/^show interfaces switchport(?: (.+))?$/);if(sp)return showSwitchport(dev,normalizeInterface(sp[1]||'GigabitEthernet0/24'));
  const si=c.match(/^show interfaces(?: (.+))?$/);if(si)return showInt(dev,normalizeInterface(si[1]||'GigabitEthernet0/24'));
  if(c==='show interfaces status')return dev.kind==='switch'?['Port     Status       VLAN','Gi0/1    '+(ifaceUp(dev.interfaces['GigabitEthernet0/1'])?'connected':'disabled')+'    '+dev.interfaces['GigabitEthernet0/1'].accessVlan,'Gi0/5    '+(ifaceUp(dev.interfaces['GigabitEthernet0/5'])?'connected':'disabled')+'    '+dev.interfaces['GigabitEthernet0/5'].accessVlan,'Gi0/23   '+(ifaceUp(dev.interfaces['GigabitEthernet0/23'])?'connected':'disabled')+'    '+dev.interfaces['GigabitEthernet0/23'].accessVlan,'Gi0/24   '+(ifaceUp(dev.interfaces['GigabitEthernet0/24'])?'connected':'disabled')+'    trunk'].join('\n'):'% Invalid input detected at \'^\' marker.';
  if(c==='show etherchannel summary')return dev.kind==='switch'?showEther(dev):'% EtherChannel is not configured.';
  if(c.startsWith('show spanning-tree'))return showStp(state,dev);
  if(c==='show mac address-table')return showMac(dev);
  if(c==='show running-config')return showRun(dev);
  if(c==='show version')return `Cisco IOS XE Software, Version ${dev.version}\nDriller Bill simulated ${dev.kind} device\nProcessor board ID PF-${deviceName}\nConfiguration register is 0x2102`;
  return null;
}

export function executeCommand(prevState,deviceName,raw){
  const state=structuredClone(prevState),dev=state.devices[deviceName],original=raw.trim(),cmd=original.toLowerCase().replace(/\s+/g,' ');if(!dev)return {state,output:'% Unknown device.'};if(!original)return {state,output:''};
  if(cmd==='clear')return {state,output:'__CLEAR__'};if(cmd==='help'||cmd==='?')return {state,output:HELP};
  if(cmd==='enable'){dev.mode='exec';return {state,output:''}}if(cmd==='disable'){dev.mode='user';return {state,output:''}}
  if(cmd==='end'){dev.mode='exec';dev.configInterface=null;dev.configVlan=null;dev.configRouter=null;return {state,output:''}}
  if(cmd==='exit'){if(dev.mode==='config-if'){dev.mode='config';dev.configInterface=null}else if(dev.mode==='config-vlan'){dev.mode='config';dev.configVlan=null}else if(dev.mode==='config-router'){dev.mode='config';dev.configRouter=null}else if(dev.mode==='config'){dev.mode='exec'}return {state,output:''}}
  if(dev.mode==='exec'||dev.mode==='user'){
    const shown=deriveShow(state,deviceName,original);if(shown!==null)return {state,output:shown};
    if(cmd.startsWith('ping ')){return {state,output:pingOutput(state,deviceName,original.slice(5).trim())}};
    if(cmd==='configure terminal'||cmd==='conf t'){if(dev.mode==='user')return {state,output:'% Privileged EXEC mode required.'};dev.mode='config';return {state,output:'Enter configuration commands, one per line. End with CNTL/Z.'}}
    return {state,output:`% Invalid input: ${original}\n% Type 'help' for the lab command set.`};
  }
  if(dev.mode==='config'){
    if(cmd.startsWith('hostname ')){dev.hostname=original.slice(9).trim();return {state,output:''}}
    if(/^vlan \d+$/.test(cmd)&&dev.kind==='switch'){const id=Number(cmd.split(' ')[1]);dev.vlans[id]=dev.vlans[id]||`VLAN${id}`;dev.mode='config-vlan';dev.configVlan=id;return {state,output:''}}
    if(/^interface /.test(cmd)){const key=normalizeInterface(original.slice(original.indexOf(' ')+1));if(!dev.interfaces[key])dev.interfaces[key]={mode:dev.kind==='switch'?'access':undefined,accessVlan:1,admin:false,link:false};dev.mode='config-if';dev.configInterface=key;return {state,output:''}}
    if(/^ip route /.test(cmd)&&dev.kind==='router'){const p=original.split(/\s+/);if(p.length<5)return {state,output:'% Incomplete command.'};const [network,mask,next]=[p[2],p[3],p[4]];const prefix=`${network}/${bitsToPrefix(mask)}`;dev.routes=dev.routes.filter(r=>r.prefix!==prefix);dev.routes.push({type:'S',prefix,next,iface:deviceName==='R1'?'Gi0/1':'Gi0/0',ad:1,metric:0});return {state,output:''}}
    if(/^router ospf \d+$/.test(cmd)&&dev.kind==='router'){dev.ospf=dev.ospf||{process:Number(cmd.split(' ')[2]),routerId:'0.0.0.0',networks:[]};dev.mode='config-router';dev.configRouter=dev.ospf.process;return {state,output:''}}
    if(/^spanning-tree vlan \d+ priority \d+$/.test(cmd)&&dev.kind==='switch'){dev.stp.priority=Number(cmd.split(' ').at(-1));return {state,output:''}}
    return {state,output:'% Invalid input detected at \'^\' marker.'};
  }
  if(dev.mode==='config-vlan'){if(cmd.startsWith('name ')){dev.vlans[dev.configVlan]=original.slice(5).trim();return {state,output:''}}return {state,output:'% VLAN configuration command not supported.'}}
  if(dev.mode==='config-router'){if(cmd.startsWith('router-id ')){dev.ospf.routerId=original.slice(10).trim();return {state,output:''}}if(cmd.startsWith('network ')){dev.ospf.networks.push(original.slice(8).trim());return {state,output:''}}return {state,output:'% Routing process command not supported.'}}
  if(dev.mode==='config-if'){
    const i=dev.interfaces[dev.configInterface];
    if(cmd==='no shutdown'){i.admin=true;i.link=true;return {state,output:''}}if(cmd==='shutdown'){i.admin=false;i.link=false;return {state,output:''}}
    if(cmd.startsWith('ip address ')){const p=original.split(/\s+/);if(p.length!==4)return {state,output:'% Incomplete command.'};i.ip=p[2];i.mask=p[3];return {state,output:''}}
    if(dev.kind==='switch'){
      if(cmd==='switchport mode trunk'){i.mode='trunk';i.admin=true;i.link=true;i.allowedVlans=i.allowedVlans||[1];i.nativeVlan=i.nativeVlan||1;return {state,output:''}}
      if(cmd==='switchport mode access'){i.mode='access';i.allowedVlans=undefined;i.nativeVlan=undefined;i.admin=true;i.link=true;i.accessVlan=i.accessVlan||1;return {state,output:''}}
      if(cmd.startsWith('switchport access vlan ')){const v=Number(cmd.split(' ').at(-1));if(!Number.isInteger(v)||v<1||v>4094)return {state,output:'% Invalid VLAN.'};i.accessVlan=v;dev.vlans[v]=dev.vlans[v]||`VLAN${v}`;return {state,output:''}}
      if(cmd.startsWith('switchport trunk native vlan ')){i.nativeVlan=Number(cmd.split(' ').at(-1));return {state,output:''}}
      const allowed=cmd.match(/^switchport trunk allowed vlan (add |remove )?(.+)$/);if(allowed){const action=allowed[1]?.trim()||'set',list=parseList(allowed[2],i.allowedVlans||[]);if(action==='add')i.allowedVlans=[...new Set([...(i.allowedVlans||[]),...list])].sort((a,b)=>a-b);else if(action==='remove')i.allowedVlans=(i.allowedVlans||[]).filter(v=>!list.includes(v));else i.allowedVlans=list;return {state,output:''}}
    }
    return {state,output:'% Invalid input detected at \'^\' marker.'};
  }
  return {state,output:`% Invalid input: ${original}`};
}

function pingOutput(state,from,target){const t=Object.entries(state.clients).find(([,c])=>c.ip===target)?.[0];if(!t)return `% Destination ${target} unknown in lab.`;const r=tracePath(state,from,target);return `Type escape sequence to abort.\n${r.ok?'!!!!!':'.....'}\nSuccess rate is ${r.ok?'100':'0'} percent (5/5)`;}
export function promptForModel(state,name){const d=state.devices[name];const suffix=d.mode==='user'?'>':d.mode==='config'?'(config)#':d.mode==='config-if'?'(config-if)#':d.mode==='config-vlan'?'(config-vlan)#':d.mode==='config-router'?'(config-router)#':'#';return `${d.hostname}${suffix}`;}
export function networkSnapshot(state){const linkRows=LINKS.map(l=>({...l,...linkInfo(state,l)}));const roots=Object.values(state.devices).filter(d=>d.kind==='switch').sort((a,b)=>a.stp.priority-b.stp.priority||a.stp.mac.localeCompare(b.stp.mac));return {links:linkRows,healthyLinks:linkRows.filter(l=>l.healthy).length,totalLinks:linkRows.length,rootSwitch:roots[0]?.name||'—',vlan20Reachable:switchVlanPath(state,'SW1','SW2',20)};}

export function taskFixture(taskId){const s=freshNetwork();const trunk=/** @type {any} */ (s.devices.SW2.interfaces['GigabitEthernet0/24']);if(taskId==='vlan20-trunk')trunk.allowedVlans=[10,99];if(taskId==='native-vlan')trunk.nativeVlan=1;if(taskId==='server-access')s.devices.SW2.interfaces['GigabitEthernet0/5'].accessVlan=10;if(taskId==='recover-trunk'){trunk.admin=false;trunk.link=false;}if(taskId==='static-route'){s.devices.R1.routes=[];s.devices.R1.ospf=null;}if(taskId==='r2-gateway')s.devices.SW2.interfaces['GigabitEthernet0/23'].accessVlan=10;return s;}

export function evaluateTask(state,taskId){const task=LAB_TASKS.find(t=>t.id===taskId);if(!task)return {ok:false,score:0,checks:[]};if(task.target.route){const routes=effectiveRoutes(state,'R1');const hit=routes.find(r=>r.prefix===task.target.route&&r.next===task.target.next&&r.type==='S');const checks=[{label:task.checks[0],ok:!!hit},{label:task.checks[1],ok:!!hit}];return {ok:!!hit,score:hit?100:0,message:hit?'R1 now has a static route to the remote VLAN 20 subnet via R2.':'No matching static route is installed on R1.',checks};}
  const i=state.devices[task.device].interfaces[task.target.iface];const checks=[];
  if(task.target.mode)checks.push({label:task.checks[0],ok:i?.mode===task.target.mode});
  if('nativeVlan' in task.target)checks.push({label:task.checks[1],ok:i?.nativeVlan===task.target.nativeVlan});
  if('accessVlan' in task.target)checks.push({label:task.checks[1],ok:i?.accessVlan===task.target.accessVlan});
  if('admin' in task.target)checks.push({label:task.checks.at(-1),ok:i?.admin===task.target.admin});
  if(task.target.requiredVlans)checks.push({label:task.checks.at(-1),ok:task.target.requiredVlans.every(v=>i?.allowedVlans?.includes(v))});
  return {ok:checks.every(x=>x.ok),score:Math.round(checks.filter(x=>x.ok).length/checks.length*100),message:checks.every(x=>x.ok)?'Objective complete. The simulated topology now satisfies the case requirements.':'Objective incomplete. Use the evidence and verify the resulting network state.',checks};
}
