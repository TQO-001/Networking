export const DEVICE_SCENARIO_VERSION = '1.0.0';

export const DEVICE_SCENARIOS = [
  {
    id: 'access-switch-baseline',
    title: 'Access Switch Baseline',
    category: 'switching',
    kind: 'switch',
    summary: 'Create two user VLANs, place access ports, establish an explicit trunk policy, then save the configuration.',
    difficulty: 'INTERMEDIATE',
    steps: [
      { id: 'vlan-users', label: 'Create USERS VLAN', intent: { type: 'create-vlan', fields: { id: 10, name: 'USERS' } } },
      { id: 'vlan-engineering', label: 'Create ENGINEERING VLAN', intent: { type: 'create-vlan', fields: { id: 20, name: 'ENGINEERING' } } },
      { id: 'access-users', label: 'Assign Gi0/1 to USERS', intent: { type: 'assign-access-vlan', fields: { interface: 'Gi0/1', vlan: 10 } } },
      { id: 'access-engineering', label: 'Assign Gi0/2 to ENGINEERING', intent: { type: 'assign-access-vlan', fields: { interface: 'Gi0/2', vlan: 20 } } },
      { id: 'trunk-uplink', label: 'Configure Gi0/24 trunk', intent: { type: 'set-trunk-policy', fields: { interface: 'Gi0/24', nativeVlan: 99, vlans: '10,20,99' } } },
      { id: 'save', label: 'Save startup configuration', intent: { type: 'save-running-config', fields: {} } },
    ],
  },
  {
    id: 'routed-edge-recovery',
    title: 'Routed Edge Recovery',
    category: 'routing',
    kind: 'router',
    summary: 'Verify the routed uplink, restore the path to VLAN 20 with a static route, then persist the recovery.',
    difficulty: 'INTERMEDIATE',
    steps: [
      { id: 'uplink-state', label: 'Ensure R1 Gi0/1 is enabled', intent: { type: 'set-interface-state', fields: { interface: 'Gi0/1', state: 'up' } } },
      { id: 'remote-route', label: 'Add route to 10.20.20.0/24 via R2', intent: { type: 'add-static-route', fields: { network: '10.20.20.0', mask: '255.255.255.0', nextHop: '10.0.12.2' } } },
      { id: 'save', label: 'Save startup configuration', intent: { type: 'save-running-config', fields: {} } },
    ],
  },
];

function vlan(report, id, name) {
  return (report?.vlans || []).some(item => Number(item.id) === Number(id) && String(item.name).toLowerCase() === String(name).toLowerCase());
}

function accessPort(report, port, vlanId) {
  const row = (report?.vlans || []).find(item => (item.ports || []).some(value => normalizePort(value) === port));
  return Boolean(row && Number(row.id) === Number(vlanId));
}

function normalizePort(value = '') { return String(value).replace(/^GigabitEthernet/i, 'Gi'); }

function trunkPolicy(report, port, nativeVlan, allowedVlans) {
  const trunk = (report?.trunks || []).find(item => normalizePort(item.interface) === port);
  if (!trunk) return false;
  const actualAllowed = (trunk.allowedVlans || []).map(Number).sort((a, b) => a - b);
  const expectedAllowed = String(allowedVlans).split(',').map(Number).sort((a, b) => a - b);
  return Number(trunk.nativeVlan) === Number(nativeVlan) && JSON.stringify(actualAllowed) === JSON.stringify(expectedAllowed);
}

function interfaceState(report, port, expected = 'up') {
  const row = (report?.interfaces || []).find(item => normalizePort(item.name) === port);
  return Boolean(row && row.status === expected && row.protocol === expected);
}

function staticRoute(report, network, nextHop) {
  return (report?.routes || []).some(item => String(item.code).toUpperCase().includes('S') && String(item.network) === network && String(item.nextHop) === nextHop);
}

export function verifyScenario(scenario, { inspection = null, diagnostics = null } = {}) {
  if (!scenario) return { valid: false, completed: 0, total: 0, steps: [], status: 'unknown' };
  if (scenario.id === 'access-switch-baseline') {
    const checks = [
      { id: 'vlan-users', label: 'USERS VLAN 10 exists', completed: vlan(inspection, 10, 'USERS') },
      { id: 'vlan-engineering', label: 'ENGINEERING VLAN 20 exists', completed: vlan(inspection, 20, 'ENGINEERING') },
      { id: 'access-users', label: 'Gi0/1 is in VLAN 10', completed: accessPort(inspection, 'Gi0/1', 10) },
      { id: 'access-engineering', label: 'Gi0/2 is in VLAN 20', completed: accessPort(inspection, 'Gi0/2', 20) },
      { id: 'trunk-uplink', label: 'Gi0/24 has native 99 and allows 10,20,99', completed: trunkPolicy(inspection, 'Gi0/24', 99, '10,20,99') },
      { id: 'save', label: 'Running and startup configuration are aligned', completed: diagnostics?.latestSnapshot?.runningStartupAligned === true },
    ];
    const completed = checks.filter(item => item.completed).length;
    return { version: DEVICE_SCENARIO_VERSION, valid: completed === checks.length, completed, total: checks.length, status: completed === checks.length ? 'complete' : completed ? 'in-progress' : 'not-started', steps: checks };
  }
  if (scenario.id === 'routed-edge-recovery') {
    const checks = [
      { id: 'uplink-state', label: 'R1 Gi0/1 is operational', completed: interfaceState(inspection, 'Gi0/1', 'up') },
      { id: 'remote-route', label: '10.20.20.0/24 routes through 10.0.12.2', completed: staticRoute(inspection, '10.20.20.0/24', '10.0.12.2') },
      { id: 'save', label: 'Running and startup configuration are aligned', completed: diagnostics?.latestSnapshot?.runningStartupAligned === true },
    ];
    const completed = checks.filter(item => item.completed).length;
    return { version: DEVICE_SCENARIO_VERSION, valid: completed === checks.length, completed, total: checks.length, status: completed === checks.length ? 'complete' : completed ? 'in-progress' : 'not-started', steps: checks };
  }
  return { valid: false, completed: 0, total: scenario.steps?.length || 0, steps: [], status: 'unknown' };
}
