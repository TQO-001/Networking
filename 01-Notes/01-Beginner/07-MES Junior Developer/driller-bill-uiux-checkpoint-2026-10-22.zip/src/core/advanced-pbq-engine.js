import { freshProtocolState, executeProtocolCommand, protocolSnapshot } from './protocol-engine.js';

export const ADVANCED_STORAGE = 'pennyFarthingAdvanced:v9';

const ifaceUp = (i) => !!i?.admin && !!i?.link;
const hasRoute = (state, prefix, next) => state.devices.R1.routes.some(r => (r.type === 'S' || r.type === 'S*') && r.prefix === prefix && (!next || r.next === next));

/** @type {Array<{id:string, code:string, difficulty:string, title:string, protocol:string, timeMinutes:number, brief:string, incident?:string, objectives?:string[], goals:Array<[string,(state:any)=>boolean]>, recommended?:string[], hint:string}>} */
export const ADVANCED_CASES = [
  {
    id: 'branch-multiple-faults', code: 'PBQ-01', difficulty: 'EXAM', title: 'Branch office blackout', protocol: 'MULTI-PROTOCOL', timeMinutes: 25,
    brief: 'A branch has lost client addressing, switched reachability, WAN translation, and dynamic routing. Work across R1, R2, SW1 and SW2. Diagnose before changing configuration.',
    incident: 'PC1 cannot obtain a lease, the server VLAN is unreachable, and the branch WAN is intermittently isolated.',
    objectives: ['Restore the client DHCP gateway', 'Restore VLAN 20 across the trunk', 'Make SW1 the RSTP root', 'Restore the LACP bundle', 'Normalize OSPF timers', 'Restore NAT inside processing'],
    goals: [
      ['DHCP pool uses gateway 10.10.10.1', s => s.devices.R1.protocol.dhcp.pools.USERS?.defaultRouter === '10.10.10.1'],
      ['PC1 receives a BOUND lease', s => s.devices.R1.protocol.dhcp.bindings.PC1?.status === 'BOUND'],
      ['SW2 Gi0/24 permits VLAN 20', s => s.devices.SW2.interfaces['GigabitEthernet0/24']?.allowedVlans.includes(20)],
      ['SW1 is root for VLAN 10', s => s.devices.SW1.protocol.stpVlans?.[10]?.root === 'SW1'],
      ['SW1 is root for VLAN 20', s => s.devices.SW1.protocol.stpVlans?.[20]?.root === 'SW1'],
      ['LACP Port-channel 1 is formed', s => s.devices.SW1.etherchannel?.formed && s.devices.SW2.etherchannel?.formed],
      ['OSPF adjacency is FULL', s => s.devices.R1.protocol.ospfAdjacency && s.devices.R2.protocol.ospfAdjacency],
      ['R1 Gi0/0 is NAT inside', s => s.devices.R1.protocol.nat.inside.includes('GigabitEthernet0/0')],
      ['NAT translation is present', s => s.devices.R1.protocol.nat.translations.length > 0],
    ],
    recommended: ['R1', 'R2', 'SW1', 'SW2'],
    hint: 'Start with `show ip dhcp pool`, `show interfaces trunk`, `show spanning-tree vlan 10`, `show etherchannel summary`, `show ip ospf neighbor`, and `show ip nat statistics`.'
  },
  {
    id: 'wan-incident', code: 'PBQ-02', difficulty: 'EXAM', title: 'WAN edge isolation', protocol: 'OSPF · NAT · STATIC ROUTING', timeMinutes: 22,
    brief: 'The branch LAN is healthy, but R1 cannot translate or route traffic toward the remote server network. Multiple Layer 3 control-plane conditions are broken.',
    incident: 'Users can reach the local gateway but remote resources on 10.20.20.0/24 are unavailable.',
    objectives: ['Restore NAT processing', 'Restore OSPF adjacency', 'Install a static backup route', 'Verify the routed path'],
    goals: [
      ['R1 Gi0/0 is NAT inside', s => s.devices.R1.protocol.nat.inside.includes('GigabitEthernet0/0')],
      ['NAT overload rule is active', s => s.devices.R1.protocol.nat.rules.some(r => r.type === 'overload' && r.enabled && r.interface === 'GigabitEthernet0/1')],
      ['NAT translation is present', s => s.devices.R1.protocol.nat.translations.length > 0],
      ['OSPF adjacency is FULL', s => s.devices.R1.protocol.ospfAdjacency && s.devices.R2.protocol.ospfAdjacency],
      ['R1 has static route to 10.20.20.0/24', s => hasRoute(s, '10.20.20.0/24', '10.0.12.2')],
      ['R1 Gi0/1 and R2 Gi0/0 are up', s => ifaceUp(s.devices.R1.interfaces['GigabitEthernet0/1']) && ifaceUp(s.devices.R2.interfaces['GigabitEthernet0/0'])],
    ],
    recommended: ['R1', 'R2'],
    hint: 'Use `show ip nat statistics`, `show ip ospf neighbor`, and `show ip route`. A backup static route can be added from R1.'
  },
  {
    id: 'campus-segmentation', code: 'PBQ-03', difficulty: 'ANALYSIS', title: 'Campus segmentation failure', protocol: 'VLAN · TRUNK · RSTP', timeMinutes: 20,
    brief: 'The server is online but the switched path is wrong. VLAN 20 is blocked at the trunk and the spanning-tree root is not where operations expects it to be.',
    incident: 'SRV1 is reachable only from some local segments. The switching team suspects a trunk and STP problem.',
    goals: [
      ['SW2 Gi0/24 is trunking', s => s.devices.SW2.interfaces['GigabitEthernet0/24']?.mode === 'trunk'],
      ['SW2 Gi0/24 allows VLAN 20', s => s.devices.SW2.interfaces['GigabitEthernet0/24']?.allowedVlans.includes(20)],
      ['Native VLAN is 99 on SW2', s => s.devices.SW2.interfaces['GigabitEthernet0/24']?.nativeVlan === 99],
      ['SRV1 edge is access VLAN 20', s => s.devices.SW2.interfaces['GigabitEthernet0/5']?.mode === 'access' && s.devices.SW2.interfaces['GigabitEthernet0/5']?.accessVlan === 20],
      ['SW1 is root for VLAN 10', s => s.devices.SW1.protocol.stpVlans?.[10]?.root === 'SW1'],
      ['SW1 is root for VLAN 20', s => s.devices.SW1.protocol.stpVlans?.[20]?.root === 'SW1'],
    ],
    recommended: ['SW1', 'SW2'],
    hint: 'Compare both ends with `show interfaces trunk` and inspect `show spanning-tree vlan 10` / `vlan 20` before changing STP priority.'
  },
  {
    id: 'redundant-uplink', code: 'PBQ-04', difficulty: 'ANALYSIS', title: 'Redundant uplink failure', protocol: 'LACP · STP · TRUNK', timeMinutes: 20,
    brief: 'Two physical uplinks exist between SW1 and SW2, but one member is suspended. Restore the bundle without turning the network into an unmanaged parallel path.',
    incident: 'Traffic still passes, but redundancy is lost and the operations dashboard shows a degraded Port-channel.',
    goals: [
      ['SW1 Port-channel 1 is formed', s => s.devices.SW1.etherchannel?.formed === true],
      ['SW2 Port-channel 1 is formed', s => s.devices.SW2.etherchannel?.formed === true],
      ['SW2 Gi0/22 participates in LACP', s => s.devices.SW2.etherchannel?.members?.['Gi0/22'] === true],
      ['SW2 Gi0/24 remains a trunk', s => s.devices.SW2.interfaces['GigabitEthernet0/24']?.mode === 'trunk'],
      ['SW2 trunk still permits VLAN 20', s => s.devices.SW2.interfaces['GigabitEthernet0/24']?.allowedVlans.includes(20)],
    ],
    recommended: ['SW2', 'SW1'],
    hint: 'Use `show etherchannel summary`, then inspect Gi0/22 and place it in `channel-group 1 mode active`.'
  },
  {
    id: 'services-recovery', code: 'PBQ-05', difficulty: 'APPLICATION', title: 'Branch services recovery', protocol: 'DHCP · NAT · GATEWAY', timeMinutes: 18,
    brief: 'The branch router is servicing users incorrectly. DHCP hands out the wrong gateway and NAT is not translating inside traffic.',
    incident: 'PC1 shows no usable lease and users cannot establish a translated session to the WAN.',
    goals: [
      ['USERS DHCP gateway is 10.10.10.1', s => s.devices.R1.protocol.dhcp.pools.USERS?.defaultRouter === '10.10.10.1'],
      ['PC1 lease is BOUND', s => s.devices.R1.protocol.dhcp.bindings.PC1?.status === 'BOUND'],
      ['R1 Gi0/0 is NAT inside', s => s.devices.R1.protocol.nat.inside.includes('GigabitEthernet0/0')],
      ['R1 Gi0/1 is NAT outside', s => s.devices.R1.protocol.nat.outside.includes('GigabitEthernet0/1')],
      ['NAT overload is active', s => s.devices.R1.protocol.nat.rules.some(r => r.type === 'overload' && r.enabled && r.interface === 'GigabitEthernet0/1')],
      ['Translation appears after simulated flow', s => s.devices.R1.protocol.nat.translations.length > 0],
    ],
    recommended: ['R1'],
    hint: 'Repair DHCP first, then mark the LAN interface as `ip nat inside`, and use `simulate nat flow` to verify translation.'
  }
];

export function advancedFixture(caseId) {
  const state = freshProtocolState('advanced');
  switch (caseId) {
    case 'wan-incident':
      state.devices.R1.protocol.nat.inside.push('GigabitEthernet0/0');
      state.devices.R2.protocol.ospfTimers.hello = 5;
      state.devices.R2.protocol.ospfTimers.dead = 20;
      state.devices.R1.routes = state.devices.R1.routes.filter(r => r.prefix !== '10.20.20.0/24');
      break;
    case 'campus-segmentation':
      state.devices.SW2.interfaces['GigabitEthernet0/24'].allowedVlans = [10,99];
      state.devices.SW2.interfaces['GigabitEthernet0/24'].nativeVlan = 1;
      state.devices.SW2.interfaces['GigabitEthernet0/5'].mode = 'access';
      state.devices.SW2.interfaces['GigabitEthernet0/5'].accessVlan = 10;
      state.devices.SW1.protocol.stpVlans[10].priority = 28672;
      state.devices.SW1.protocol.stpVlans[20].priority = 28672;
      state.devices.SW2.protocol.stpVlans[10].priority = 24576;
      state.devices.SW2.protocol.stpVlans[20].priority = 24576;
      break;
    case 'redundant-uplink':
      state.devices.SW2.etherchannel.members['Gi0/22'] = false;
      state.devices.SW2.interfaces['GigabitEthernet0/24'].allowedVlans = [10,20,99];
      state.devices.SW2.interfaces['GigabitEthernet0/24'].nativeVlan = 99;
      break;
    case 'services-recovery':
      break;
    default:
      break;
  }
  return state;
}

export function evaluateAdvancedCase(state, caseId) {
  const c = ADVANCED_CASES.find(x => x.id === caseId);
  if (!c) return {ok:false, score:0, checks:[]};
  const normalized = executeProtocolCommand(state, 'R1', 'show ip route').state;
  const checks = c.goals.map(([label, check]) => ({label, ok: !!check(normalized)}));
  const completed = checks.filter(x => x.ok).length;
  return {
    caseId,
    code: c.code,
    title: c.title,
    score: Math.round((completed / checks.length) * 100),
    completed,
    total: checks.length,
    checks,
    ok: completed === checks.length,
    hint: c.hint,
    objectives: c.objectives || c.goals.map(x => x[0]),
  };
}

export function advancedSnapshot(state) {
  return protocolSnapshot(state);
}

export function advancedRun(state, device, command) {
  const result = executeProtocolCommand(state, device, command);
  return {state: result.state, output: result.output};
}
