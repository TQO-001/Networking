# 09. Network Services

> [!summary] Chapter goal
> Understand the services that make a network usable and manageable: DHCP, DNS, NTP, SNMP and Syslog.

## 9.1 DHCP

DHCP automatically supplies client configuration. The classic sequence is DORA:

```text
Discover → Offer → Request → Acknowledge
```

A lease can include an IP address, subnet mask, default gateway, DNS servers and other options.

## 9.2 DHCP Relay

A DHCP broadcast normally stays within a local Layer 2 domain. A router or Layer 3 switch can relay DHCP requests to a server on another network.

This is a key reason why “the DHCP server works” does not automatically mean a remote VLAN will receive leases.

## 9.3 DNS

DNS translates names into resource records. Clients can then use a service by name instead of memorizing an address.

Common record types:

```text
A      IPv4
AAAA   IPv6
CNAME  alias
MX     mail
PTR    reverse lookup
NS     authoritative name server
```

## 9.4 NTP

NTP synchronizes clocks. Consistent time is critical for security logs, incident timelines, authentication and troubleshooting.

## 9.5 SNMP

SNMP is commonly used to monitor devices. Managers can retrieve counters and status information and receive notifications depending on the version and implementation.

## 9.6 Syslog

Syslog transports event messages from network devices to logging infrastructure. Centralized logging turns isolated device messages into a timeline that can be searched and correlated.

## 9.7 TFTP and File Transfer

TFTP is a simple file-transfer protocol often encountered in network-device image/configuration workflows. It lacks the security features of modern secure transfer mechanisms and should be used appropriately.

## 9.8 Review Checklist

- Explain DORA.
- Explain why DHCP relay exists.
- Know common DNS record types.
- Explain why NTP matters operationally.
- Distinguish SNMP monitoring from Syslog logging.
