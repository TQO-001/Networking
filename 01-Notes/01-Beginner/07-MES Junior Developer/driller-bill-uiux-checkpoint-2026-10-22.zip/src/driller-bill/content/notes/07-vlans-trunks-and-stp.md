# 07. VLANs, Trunks & STP

> [!summary] Chapter goal
> Understand segmentation, trunking and loop prevention as one connected Layer 2 story.

## 7.1 VLANs

A VLAN creates a logical broadcast domain. Ports assigned to different VLANs are separated at Layer 2 even when they belong to the same physical switch.

Typical roles:

```text
VLAN 10 → Users
VLAN 20 → Voice
VLAN 30 → Servers
VLAN 99 → Management
```

## 7.2 Access Ports

An access port normally carries one VLAN:

```text
interface Gi0/10
 switchport mode access
 switchport access vlan 10
```

The endpoint usually sends normal untagged Ethernet frames; the switch associates them with the configured access VLAN.

## 7.3 Trunks

A trunk transports multiple VLANs across one link. IEEE 802.1Q adds VLAN information to tagged Ethernet frames.

Useful verification:

```text
show interfaces trunk
show interfaces switchport
```

## 7.4 Native VLAN

The native VLAN is the VLAN associated with untagged traffic on an 802.1Q trunk. Native VLAN mismatches can cause traffic leaks and confusing connectivity problems.

> [!warning] Security note
> Treat the native VLAN as an explicit configuration decision. Do not assume that a default is automatically appropriate for production.

## 7.5 Why Layer 2 Loops Are Dangerous

Ethernet does not naturally stop a frame that loops between switches. Broadcasts can multiply rapidly and MAC tables can flap between ports.

## 7.6 Spanning Tree Protocol

STP creates a loop-free logical topology while keeping redundant links available for failover. A root bridge is selected, paths are evaluated, and ports take forwarding or non-forwarding roles depending on the STP implementation.

## 7.7 Edge Ports and BPDU Guard

Access ports connected to end hosts can use PortFast-style edge behavior to enter forwarding quickly. BPDU Guard protects edge ports by reacting when unexpected BPDUs arrive.

## 7.8 EtherChannel Relationship

EtherChannel groups physical links into one logical link. STP sees the bundle as a logical path, reducing the need to block individual member links.

## 7.9 Verification Workflow

After changes, verify:

1. VLAN exists.
2. Access port belongs to the expected VLAN.
3. Trunk is actually trunking.
4. Allowed VLANs are correct.
5. STP topology is healthy.
6. EtherChannel members agree.

## 7.10 Review Checklist

- Define a VLAN.
- Configure and verify an access port.
- Explain a trunk.
- Explain the native VLAN.
- Explain why STP exists.
- Distinguish PortFast from BPDU Guard.
