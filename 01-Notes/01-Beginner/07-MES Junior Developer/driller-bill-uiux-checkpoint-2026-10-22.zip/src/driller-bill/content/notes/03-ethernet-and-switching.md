# 03. Ethernet & Switching

> [!summary] Chapter goal
> Understand how Ethernet frames move through a switch, how MAC learning works, and how access ports, trunks and VLANs shape Layer 2 forwarding.

## 3.1 Ethernet Frames

Ethernet provides local Layer 2 delivery. A frame contains destination and source MAC addresses plus a payload and error-detection information.

A switch primarily cares about the source and destination MAC addresses while forwarding a frame.

## 3.2 MAC Address Learning

When a switch receives a frame, it examines the **source MAC** and records an association between that address and the incoming interface.

Example:

```text
Source MAC: AA:AA:AA:AA:AA:AA
Ingress:    Gi0/3

MAC table entry:
AA:AA:AA:AA:AA:AA → Gi0/3
```

The table ages out entries after an inactivity period so stale information does not persist forever.

## 3.3 Forwarding Decisions

If the destination MAC is known, the switch can forward the frame only toward the associated port. If the destination is unknown, the frame is flooded within the relevant VLAN, excluding the ingress port.

Broadcast frames are also flooded inside the broadcast domain.

## 3.4 VLANs

A VLAN partitions a switch into logical Layer 2 broadcast domains. VLAN 10 and VLAN 20 are separate broadcast domains even if they use the same physical switch.

```text
VLAN 10  → users
VLAN 20  → voice/lab/servers
VLAN 30  → management
```

Devices in different VLANs need Layer 3 routing to communicate.

## 3.5 Access Ports

An access port normally carries traffic for one VLAN. The endpoint does not normally add an 802.1Q tag itself; the switch associates received traffic with the access VLAN.

Typical configuration:

```text
interface GigabitEthernet0/1
 switchport mode access
 switchport access vlan 10
```

## 3.6 Trunk Ports

A trunk can transport multiple VLANs over one link. IEEE 802.1Q identifies the VLAN for tagged frames.

Typical concepts to remember:

- allowed VLAN list
- native VLAN
- tagging
- trunk negotiation

> [!warning] Native VLAN
> The native VLAN carries untagged traffic on an 802.1Q trunk. Mismatches can produce confusing connectivity and security problems.

## 3.7 STP and Loops

Redundant Layer 2 links are useful for resilience but can create loops. Ethernet has no TTL-like mechanism that automatically kills a frame after repeated switching. STP prevents loops by placing redundant paths into a blocking/discarding state when necessary.

## 3.8 EtherChannel

EtherChannel combines multiple physical links into one logical bundle. LACP is the standards-based negotiation protocol commonly encountered in CCNA studies.

Benefits include:

- increased aggregate capacity
- link redundancy
- one logical topology from STP's perspective

## 3.9 Useful Verification Commands

```text
show mac address-table
show vlan brief
show interfaces status
show interfaces trunk
show spanning-tree
show etherchannel summary
```

The key skill is not memorizing syntax alone. Know what each output is supposed to prove.

## 3.10 Review Checklist

- Explain source MAC learning.
- Explain unknown-unicast flooding.
- Distinguish access and trunk ports.
- Explain why VLANs form broadcast domains.
- Explain what STP prevents.
- Explain why EtherChannel is useful.
