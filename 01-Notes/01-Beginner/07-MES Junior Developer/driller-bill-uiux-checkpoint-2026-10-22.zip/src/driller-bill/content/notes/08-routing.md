# 08. Routing

> [!summary] Chapter goal
> Learn how routers choose paths, how route sources appear in the routing table, and how to interpret common Cisco routing output.

## 8.1 What Routing Solves

Routing moves packets between different IP networks. A router receives a packet, examines the destination IP, consults its routing information and forwards the packet toward the selected next hop or outgoing interface.

## 8.2 Routing Table

A routing table contains reachable prefixes and information about how to reach them.

Common sources include:

- connected
- local
- static
- dynamic routing protocols
- default routes

## 8.3 Longest-Prefix Match

When multiple routes match a destination, the most specific prefix wins.

Example:

```text
10.0.0.0/8
10.10.0.0/16
10.10.10.0/24
```

Traffic for `10.10.10.5` matches all three, but `/24` is the longest and therefore the most specific match.

## 8.4 Default Route

A default route is the fallback path used when no more-specific route exists.

```text
0.0.0.0/0
```

On a small network, a router may send unknown destinations toward an upstream provider using a default route.

## 8.5 Administrative Distance and Metrics

When a router learns the same prefix from different sources, administrative distance helps determine which source is preferred. Within a routing protocol, a protocol-specific metric may then choose the best path.

Do not confuse administrative distance with routing metrics: they solve different selection problems.

## 8.6 Inter-VLAN Routing

VLANs isolate Layer 2 broadcast domains. Inter-VLAN routing provides Layer 3 connectivity between those networks using a router or multilayer switch.

Common designs include router-on-a-stick and switched virtual interfaces (SVIs).

## 8.7 Verification Commands

```text
show ip route
show ip interface brief
show arp
ping
traceroute
```

Read the routing table before making routing changes. Evidence beats guessing.

> [!tip] Troubleshooting habit
> For a remote destination, trace the path in layers: host IP configuration → default gateway → gateway routing table → next hop → return path.

## 8.8 Review Checklist

- Explain longest-prefix match.
- Explain connected/static/default routes.
- Distinguish administrative distance from metric.
- Explain inter-VLAN routing.
- Read a simple Cisco routing table.
