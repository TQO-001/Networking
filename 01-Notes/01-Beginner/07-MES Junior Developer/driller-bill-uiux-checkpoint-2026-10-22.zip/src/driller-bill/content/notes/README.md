# Driller-Bill Markdown Notes

These chapters are deliberately plain `.md` files so they can be opened directly in Obsidian, VS Code, GitHub or another Markdown editor.

## Obsidian support

The notes use standard Markdown plus Obsidian-compatible callouts such as:

```markdown
> [!summary] Chapter goal
> Use this section to orient yourself before studying the details.

> [!tip] Exam tip
> Read the command output before changing configuration.

> [!warning] Common trap
> A correct command can still be rejected when used in the wrong IOS mode.
```

The in-app Notes reader renders these callouts while preserving the original Markdown for download.
