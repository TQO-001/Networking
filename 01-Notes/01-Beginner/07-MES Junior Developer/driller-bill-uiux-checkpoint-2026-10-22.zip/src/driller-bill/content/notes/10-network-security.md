# 10. Network Security

> [!summary] Chapter goal
> Build a layered security mindset: secure management, restrict unnecessary access, segment traffic, and protect Layer 2 control planes.

## 10.1 Least Privilege

Least privilege means a user, process or device should have only the access required to perform its job. It reduces the consequences of stolen credentials and configuration mistakes.

## 10.2 Secure Management

Prefer encrypted management protocols such as SSH rather than plaintext Telnet. Strong authentication, centralized identity and role-based authorization provide better accountability than shared local passwords alone.

## 10.3 Password and Secret Handling

Secrets should never be copied casually into shared notes or documentation. In Driller-Bill Twin exports, sensitive values are replaced with placeholders such as:

```text
[enable_secret_password]
[user_password]
```

> [!warning] Documentation rule
> Treat generated lab notes as potentially sensitive. Verify that credentials, keys, community strings and tokens are redacted before sharing them.

## 10.4 VLAN Segmentation

Segmentation reduces unnecessary reachability. Separate users, servers, management and untrusted devices into appropriate network zones, then enforce policy between those zones.

## 10.5 Port Security

Port security can restrict which MAC addresses are accepted or learned on an access interface. It is a Layer 2 control and should be configured according to the environment rather than blindly applied everywhere.

## 10.6 DHCP Snooping

DHCP Snooping distinguishes trusted and untrusted interfaces and can block rogue DHCP server responses. It can also create binding information used by other protection features.

## 10.7 Dynamic ARP Inspection

DAI helps defend against ARP spoofing by validating ARP packets against trusted information such as DHCP Snooping bindings or static entries.

## 10.8 Unused Ports

Unused access ports should generally be disabled or placed into a controlled state. This reduces opportunities for unauthorized attachment.

## 10.9 Defense in Depth

No single feature provides complete security. Combine:

```text
identity + secure management + segmentation + filtering + monitoring + backups
```

Security becomes much stronger when failures in one layer do not automatically become total compromise.

## 10.10 Review Checklist

- Explain least privilege.
- Know why SSH is preferred to Telnet.
- Understand port security.
- Understand DHCP Snooping and DAI.
- Redact secrets in documentation.
- Think in layers, not isolated security commands.
