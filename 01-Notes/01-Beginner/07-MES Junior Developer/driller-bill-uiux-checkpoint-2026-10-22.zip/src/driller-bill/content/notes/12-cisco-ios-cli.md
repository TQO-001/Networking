# 12. Cisco IOS CLI

> [!summary] Chapter goal
> Become comfortable enough with IOS navigation that the prompt, help system and command history feel automatic during a CCNA lab.

## 12.1 User EXEC and Privileged EXEC

A typical user EXEC prompt ends with `>`:

```text
Switch>
```

Privileged EXEC ends with `#`:

```text
Switch#
```

The prompt is not decoration. It tells you what commands are likely to be valid.

## 12.2 Configuration Modes

Global configuration:

```text
Switch(config)#
```

Interface configuration:

```text
Switch(config-if)#
```

VLAN configuration:

```text
Switch(config-vlan)#
```

Other features can introduce additional submodes.

## 12.3 Entering and Leaving Modes

```text
enable
configure terminal
interface gigabitEthernet0/1
exit
end
```

`exit` normally moves up one level. `end` or `Ctrl+Z` returns to privileged EXEC.

## 12.4 Context-Sensitive Help

The question mark is one of the most useful IOS features:

```text
Switch# show ?
```

It displays valid commands for the current context.

## 12.5 Tab Completion

Tab completes an unambiguous command or keyword. Abbreviations are convenient, but explicit commands are often easier to document and review.

## 12.6 Command History

Use the Up and Down keys to recall commands. During troubleshooting, this is useful for repeating a verification command after a change.

## 12.7 Configuration Storage

The running configuration is active in memory. The startup configuration is stored for use after a reload.

```text
show running-config
show startup-config
copy running-config startup-config
```

> [!warning] Classic mistake
> A successful configuration change is not automatically the same thing as a saved configuration.

## 12.8 Common Verification Pattern

A good command sequence often looks like:

```text
configure terminal
...change...
end
show ...
copy running-config startup-config
```

The verification step should prove that the intended state exists.

## 12.9 Correct Syntax Can Still Fail

A command can be perfectly valid in IOS and still be rejected because:

- you are in the wrong mode;
- a required prerequisite is missing;
- the command is incomplete;
- the abbreviation is ambiguous;
- the target interface or feature is unavailable.

This distinction is central to Driller-Bill: the learner should diagnose why a command failed rather than simply being told that it was wrong.

## 12.10 Review Checklist

- Identify the current CLI mode from the prompt.
- Use `?` and Tab rather than guessing.
- Know `enable`, `configure terminal`, `exit` and `end`.
- Understand running vs startup configuration.
- Verify changes after configuring them.
