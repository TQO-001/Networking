# 05. TCP/IP Protocols

> [!summary] Chapter goal
> Learn the jobs, relationships and common ports of the protocols you encounter every day in CCNA study and real network operations.

## 5.1 IP Addressing

Internet Protocol provides logical addressing and packet forwarding. IPv4 uses 32-bit addresses; IPv6 uses 128-bit addresses.

IP is intentionally best effort. It does not guarantee delivery, order or retransmission. Those responsibilities can be added by protocols above it, especially TCP.

## 5.2 Protocols and Ports

A protocol defines communication rules. A TCP or UDP port identifies a transport endpoint used by an application.

Some common examples:

| Service | Common protocol | Port |
|---|---|---:|
| HTTP | TCP | 80 |
| HTTPS | TCP | 443 |
| SSH | TCP | 22 |
| DNS | UDP/TCP | 53 |
| DHCP server/client | UDP | 67/68 |
| TFTP | UDP | 69 |
| NTP | UDP | 123 |
| SNMP | UDP | 161/162 |
| Syslog | UDP, often 514 | 514 |

Ports are not the same thing as switch interfaces. `GigabitEthernet0/1` is a network interface; TCP port 443 is a transport endpoint.

## 5.3 TCP

TCP is connection-oriented and provides reliable, ordered delivery. It uses sequence numbers, acknowledgements, retransmissions and flow/congestion-control mechanisms.

The classic three-way handshake is:

```text
Client → SYN
Server → SYN-ACK
Client → ACK
```

A connection can then carry application data.

> [!tip] Exam framing
> TCP is about reliable transport between application endpoints. It does not choose the next router hop; IP routing does that.

## 5.4 UDP

UDP is connectionless and lightweight. It does not provide TCP's built-in reliability or ordering. Applications choose UDP when simplicity, low overhead or application-specific recovery is desirable.

DNS, DHCP and many streaming/real-time systems use UDP in common configurations.

## 5.5 ICMP

ICMP supports control, diagnostics and error-reporting functions. The `ping` utility typically uses ICMP Echo Request and Echo Reply for IPv4/IPv6, although successful ping does not prove that every application will work.

`traceroute`/`tracert` relies on TTL/Hop Limit behavior and ICMP responses to reveal path information.

## 5.6 ARP

ARP resolves an IPv4 next-hop IP address to a MAC address on the local Ethernet segment.

A simplified flow is:

```text
Who has 192.0.2.1?
192.0.2.1 is at AA:BB:CC:DD:EE:FF
```

If the destination is remote, the host normally resolves the **default gateway's** MAC, not the remote host's MAC.

## 5.7 DNS

DNS maps names to resource records. The most familiar are:

- `A` → IPv4 address
- `AAAA` → IPv6 address
- `CNAME` → alias
- `MX` → mail routing
- `NS` → authoritative name servers
- `PTR` → reverse lookup

A DNS failure can look like “the Internet is down” even when IP connectivity is completely healthy.

## 5.8 DHCP

DHCP automates address configuration. The traditional four-step memory aid is DORA:

```text
Discover
Offer
Request
Acknowledge
```

Common client configuration includes IP address, subnet mask/prefix, default gateway and DNS servers.

## 5.9 NTP

NTP synchronizes system clocks. Time consistency is crucial for log correlation, authentication, certificates and troubleshooting.

## 5.10 SNMP and Syslog

SNMP supports monitoring and management. Syslog transports event messages and is especially useful for centralized troubleshooting.

A professional network should make it possible to answer not only “what is broken?” but also “when did it change?”

## 5.11 Putting It Together

When a user opens a web site:

```text
DNS → find the server address
ARP/ND → find the local next-hop address
IP → route packets
TCP → establish reliable transport
HTTP(S) → exchange application data
```

That sequence is a powerful mental model for CCNA questions.

## 5.12 Review Checklist

- Know TCP vs UDP.
- Know the purpose of ICMP, ARP, DNS and DHCP.
- Know the common ports above.
- Understand the difference between IP forwarding and TCP reliability.
- Explain how DNS and ARP solve different problems.
