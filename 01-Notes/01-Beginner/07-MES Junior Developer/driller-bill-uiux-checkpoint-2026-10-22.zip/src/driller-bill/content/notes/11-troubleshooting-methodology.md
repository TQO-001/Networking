# 11. Troubleshooting Methodology

> [!summary] Chapter goal
> Replace random command changes with evidence-driven troubleshooting that can be documented, repeated and verified.

## 11.1 Define the Symptom

Start with a precise problem statement.

Bad:

> “The network is broken.”

Better:

> “Host A can reach its default gateway but cannot reach the application server at 10.20.30.40.”

Specific symptoms dramatically reduce the search space.

## 11.2 Gather Evidence

Before changing configuration, inspect the current state.

Useful Cisco commands include:

```text
show running-config
show ip interface brief
show interfaces
show vlan brief
show interfaces trunk
show ip route
show arp
show mac address-table
```

Choose commands that test a hypothesis.

## 11.3 Start at the Lowest Sensible Layer

If a link is physically down, start at Layer 1. If interfaces are up but a VLAN path is wrong, investigate Layer 2. If packets leave the host but do not reach another network, investigate Layer 3.

This is not a rigid rule. Evidence determines where you focus.

## 11.4 Change One Thing at a Time

Randomly changing five settings makes it difficult to know which one fixed or caused the problem.

Use a controlled loop:

```text
Hypothesis → one change → verification → next hypothesis
```

## 11.5 Verify the Original Symptom

A command succeeding does not prove the user problem is solved.

After a fix, reproduce the original failure condition and verify that it no longer occurs.

## 11.6 Preserve a Rollback Path

Know what you changed. Save known-good configuration copies where appropriate. Avoid destructive changes when a read-only verification step can provide the evidence you need.

## 11.7 Twin as a Troubleshooting Journal

Twin records commands, output, mode transitions, errors and suspected typos. This turns the troubleshooting session into a timeline that can be reviewed later.

Useful questions after a session:

- Where did I first deviate from the correct path?
- Which error occurred most often?
- Did I misunderstand a mode or command prerequisite?
- What should I practice next?

## 11.8 Common Failure Patterns

### Correct command, wrong mode
The syntax is valid but the prompt shows the wrong configuration level.

### Wrong prerequisite
The command depends on a feature, VLAN, interface state or protocol being configured first.

### Correct local state, wrong remote state
Your interface can be correct while a trunk, gateway or return path elsewhere is wrong.

> [!tip] Professional habit
> Treat every troubleshooting session as evidence collection. Record what you observed before and after each change.

## 11.9 Review Checklist

- Define the symptom precisely.
- Gather evidence first.
- Use the prompt to identify CLI mode.
- Change one thing at a time.
- Verify the original problem after the fix.
- Document the path so another engineer can reproduce it.
