# 04. IPv4 & Subnetting

> [!summary] Chapter goal
> Become comfortable reading prefixes, finding subnet boundaries, calculating host capacity, and identifying when traffic is local versus remote.

## 4.1 IPv4 Address Structure

IPv4 addresses contain 32 bits, normally written as four decimal octets.

```text
192.0.2.10
```

A subnet prefix divides the address into network bits and host bits.

## 4.2 CIDR Prefix Length

CIDR notation uses a slash followed by the number of network bits.

```text
192.0.2.10/24
```

`/24` means the first 24 bits are the network portion, leaving 8 host bits.

> [!tip] Core formula
> Total addresses = `2^(host bits)`.
>
> Normal host count on traditional IPv4 subnets = `2^(host bits) - 2`.

## 4.3 Common Prefixes

| Prefix | Mask | Total addresses | Traditional usable hosts |
|---|---|---:|---:|
| /24 | 255.255.255.0 | 256 | 254 |
| /25 | 255.255.255.128 | 128 | 126 |
| /26 | 255.255.255.192 | 64 | 62 |
| /27 | 255.255.255.224 | 32 | 30 |
| /28 | 255.255.255.240 | 16 | 14 |
| /29 | 255.255.255.248 | 8 | 6 |
| /30 | 255.255.255.252 | 4 | 2 |

## 4.4 Network, Broadcast and Host Addresses

For a normal IPv4 subnet, the first address represents the network and the last represents broadcast.

Example `192.0.2.64/26`:

```text
Network:   192.0.2.64
Hosts:     192.0.2.65 – 192.0.2.126
Broadcast: 192.0.2.127
```

## 4.5 Finding Boundaries

The mask tells you the block size. A `/26` mask is `255.255.255.192`. The interesting octet has a block size of 64:

```text
0, 64, 128, 192
```

A host address such as `192.0.2.117` therefore belongs to the `192.0.2.64/26` subnet.

## 4.6 Private IPv4 Space

RFC 1918 private ranges are:

```text
10.0.0.0/8
172.16.0.0/12
192.168.0.0/16
```

Private addresses are widely used internally and commonly require NAT or another mechanism for Internet connectivity.

## 4.7 Default Gateway

A host compares the destination IP with its own subnet. If the destination is local, it can resolve the destination's Layer 2 address. If the destination is remote, the host sends the packet to its default gateway.

This is why an incorrect default gateway can break communication to remote networks while local communication may continue working.

## 4.8 Special Addresses

`127.0.0.0/8` is loopback space. `169.254.0.0/16` is link-local IPv4 space commonly associated with automatic self-assignment when DHCP configuration fails on hosts.

## 4.9 Subnetting Strategy

For exam questions, work systematically:

1. Write the prefix length.
2. Calculate host bits.
3. Determine block size.
4. Identify the nearest subnet boundary.
5. Write network and broadcast.
6. Derive the usable host range.

> [!warning] Do not guess from the last octet alone
> `/20`, `/21`, `/22` and similar prefixes cross octet boundaries. Convert the mask or use binary/block-size reasoning.

## 4.10 Review Checklist

- Convert common prefixes to masks.
- Calculate host counts quickly.
- Find network and broadcast addresses.
- Recognize private ranges.
- Explain why the default gateway matters.
