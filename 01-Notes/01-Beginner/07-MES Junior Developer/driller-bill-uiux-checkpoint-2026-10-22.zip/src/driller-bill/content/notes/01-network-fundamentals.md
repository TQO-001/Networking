# 01. Network Fundamentals

> [!summary] Chapter goal
> Build the vocabulary and mental models you need before moving into addressing, switching and routing. This chapter explains what a network is, the roles of hosts and forwarding devices, common network types, encapsulation, bandwidth and latency.

## 1.1 What Is a Computer Network?

A computer network is a collection of devices that exchange information over communication links using agreed protocols. Devices may be end hosts such as laptops and servers, or network infrastructure such as switches, routers, firewalls and wireless access points.

A useful way to think about networking is to separate **endpoints**, **forwarding**, and **services**. An endpoint creates or consumes data. A forwarding device decides where traffic should go next. A service provides a function such as name resolution, address assignment, logging or time synchronization.

## 1.2 Hosts, Clients and Servers

A **host** is any networked endpoint with a network identity. A client requests a service; a server provides a service. The same physical machine can perform both roles.

Examples:

- A laptop can be a DHCP client, DNS client and web client.
- A file server can provide SMB/NFS while also using DNS and NTP.
- A network printer is an endpoint even though users normally do not think of it as a computer.

> [!tip] CCNA mental model
> Ask: “Who is sending? Who is receiving? What device forwards the traffic? What service does the application need?” This turns a vague networking problem into a sequence of smaller questions.

## 1.3 Switches, Routers and Firewalls

### Switch

A Layer 2 switch forwards Ethernet frames using destination MAC addresses. It learns source MAC addresses and stores them in a MAC address table associated with switch ports.

### Router

A router forwards Layer 3 packets between different IP networks. It uses a routing table and chooses the best available route for a destination.

### Firewall

A firewall enforces traffic policy. Depending on the platform it may filter by source/destination address, protocol, port, application or identity.

## 1.4 LAN, WAN and the Internet

A **LAN** is a local area network, typically covering a home, office or campus. A **WAN** connects geographically separated locations. The Internet is a global collection of interconnected networks using IP and a huge ecosystem of routing and application protocols.

Do not treat LAN and WAN as protocols. They describe scope and topology, not a single command or packet format.

## 1.5 Network Topology

Common topologies include star, mesh, partial mesh, point-to-point and hub-and-spoke. Modern switched Ethernet commonly looks like a logical star: many endpoints connect to access switches, and switches connect upward toward distribution or core infrastructure.

Physical topology answers “what is physically connected?” Logical topology answers “how does traffic behave?” The two can be different.

## 1.6 Encapsulation and Decapsulation

When an application sends data, each layer adds information relevant to its responsibility. The process of adding headers and trailers is **encapsulation**. At the receiver, the information is processed and removed as data moves back toward the application; this is **decapsulation**.

A simplified path is:

```text
Application data
    ↓
TCP segment
    ↓
IP packet
    ↓
Ethernet frame
    ↓
Bits on the wire
```

## 1.7 Bandwidth, Throughput, Latency and Jitter

**Bandwidth** is the theoretical capacity of a link. **Throughput** is the rate actually achieved. **Latency** is the delay between endpoints. **Jitter** is variation in delay over time.

A 1 Gbps link can have high bandwidth but poor application performance if latency, packet loss, congestion or server limitations dominate.

## 1.8 Broadcast and Collision Domains

A broadcast domain is the group of devices that receives a Layer 2 broadcast. VLANs create separate broadcast domains. In modern switched full-duplex Ethernet, each switch port is normally its own collision domain.

> [!warning] Common exam trap
> A VLAN is a broadcast-domain boundary, not a magic security boundary. Inter-VLAN traffic needs Layer 3 forwarding, and security policy may still need to be enforced with ACLs or firewalls.

## 1.9 Ports, Interfaces and Links

A network **interface** is the device endpoint used for connectivity. An **interface port** is a physical or virtual attachment point. A TCP/UDP **port number** is different: it identifies an application endpoint at Layer 4.

Never confuse:

```text
Gi0/1        → network interface
TCP 443      → transport/application endpoint
VLAN 10      → logical Layer 2 segment
```

## 1.10 Core Review Checklist

- Know the difference between a frame, packet, segment and application data.
- Know what a switch does versus a router.
- Know LAN, WAN, broadcast domain and collision domain.
- Explain encapsulation without memorizing a picture.
- Distinguish bandwidth from throughput and latency.
- Understand why VLANs separate broadcast domains.
