# 02. OSI & TCP/IP

> [!summary] Chapter goal
> Use the OSI and TCP/IP models as troubleshooting maps, not as lists you recite from memory.

## 2.1 Why Layered Models Exist

Networking is complex because many different tasks have to happen at once: physical signaling, local delivery, logical addressing, transport reliability and application protocols. Layered models divide those responsibilities so technologies can evolve independently.

## 2.2 The Seven OSI Layers

| Layer | Name | Examples | Main idea |
|---|---|---|---|
| 7 | Application | HTTP, DNS, DHCP, SSH | User-facing network services |
| 6 | Presentation | Encoding, encryption concepts | Data representation |
| 5 | Session | Session management concepts | Dialog/session control |
| 4 | Transport | TCP, UDP | End-to-end transport |
| 3 | Network | IPv4, IPv6, routing | Logical addressing and forwarding |
| 2 | Data Link | Ethernet, VLAN, MAC | Local delivery |
| 1 | Physical | Copper, fiber, radio | Signals and bits |

The OSI model is conceptual. Real protocols do not always fit neatly into one box.

## 2.3 TCP/IP Model

A common practical model groups the stack into four layers:

1. Application
2. Transport
3. Internet
4. Network Access

TCP/IP is the protocol suite used by modern IP networks. The model is useful because it maps directly onto protocols you will configure and troubleshoot.

## 2.4 Mapping Common Protocols

Think in categories:

```text
Application  → HTTP, DNS, DHCP, SSH, SNMP
Transport    → TCP, UDP
Internet     → IPv4, IPv6, ICMP
Link         → Ethernet, 802.1Q
Physical     → copper, fiber, wireless
```

ARP is commonly discussed around the boundary between the Internet and Link layers because it resolves IPv4 next-hop addresses to MAC addresses on the local link.

## 2.5 Data Units

Different layers use different terminology:

```text
Application      data
Transport        segment (TCP) / datagram (UDP)
Internet         packet
Data Link        frame
Physical         bits
```

The exact words are less important than understanding that headers are added for different delivery responsibilities.

## 2.6 Addressing at Different Layers

MAC addresses identify Layer 2 interfaces on a local Ethernet segment. IP addresses identify Layer 3 endpoints and networks. TCP/UDP port numbers identify transport endpoints.

For example:

```text
MAC      → 00:11:22:33:44:55
IPv4     → 192.0.2.10
TCP port → 443
```

> [!tip] Troubleshooting shortcut
> Ask which address is failing. If the device cannot learn a MAC, think Layer 2. If it has a MAC but cannot reach another network, think Layer 3. If IP connectivity works but a service fails, investigate ports and applications.

## 2.7 Encapsulation Example

A web request can be represented conceptually as:

```text
HTTP data
  ↓ TCP header + data
TCP segment
  ↓ IP header + segment
IP packet
  ↓ Ethernet header/trailer + packet
Ethernet frame
```

The receiving endpoint performs the reverse process.

## 2.8 Common Exam Mistakes

The OSI model is often used to classify symptoms, but “Layer 3 issue” does not automatically mean “router issue.” A misconfigured switch SVI, wrong gateway, ACL, ARP entry or host IP can all affect Layer 3 communication.

> [!warning] Avoid cargo-cult troubleshooting
> Do not jump straight to a layer because a keyword reminds you of it. Gather evidence first, then map the evidence to the most likely layer.

## 2.9 Review Checklist

- Memorize the seven OSI layer names.
- Know the TCP/IP four-layer model.
- Map MAC, IP and port numbers to their jobs.
- Distinguish frame, packet and segment.
- Explain encapsulation and decapsulation.
