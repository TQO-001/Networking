# Community Drills

Put contributor-authored drill definitions in this directory.

The current canonical format is JSON. YAML is also accepted as an authoring format; convert it to JSON before committing unless the repository later enables native YAML loading.

## Minimum workflow

1. Copy `vlan-access-port.json`.
2. Change the ID/title/metadata.
3. Write focused theory sections.
4. Add a realistic command sequence.
5. Add objectives tied to theory anchors.
6. Run `npm run validate:drills`.
7. Open a pull request.

The `engineModule` field identifies which existing simulator capability executes the scenario. Content files never execute code.
