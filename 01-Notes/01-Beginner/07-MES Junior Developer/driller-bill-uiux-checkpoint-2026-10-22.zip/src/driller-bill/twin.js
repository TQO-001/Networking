const SECRET_PATTERNS = [
  [/\b(enable\s+secret)(?:\s+\S+)?/gi, '$1 [enable_secret_password]'],
  [/\b(enable\s+password)(?:\s+\S+)?/gi, '$1 [enable_password]'],
  [/\b(username\s+\S+(?:\s+privilege\s+\d+)?\s+(?:secret|password))(?:\s+\S+)?/gi, '$1 [user_password]'],
  [/\b(key-string)(?:\s+\S+)?/gi, '$1 [key_string]'],
  [/\b(community)(?:\s+\S+)?/gi, '$1 [snmp_community]'],
];

export function redactSensitive(text = '') {
  let result = String(text);
  SECRET_PATTERNS.forEach(([pattern, replacement]) => {
    result = result.replace(pattern, replacement);
  });
  return result;
}

function normalize(value) { return String(value ?? '').toLowerCase().trim().replace(/\s+/g, ' '); }

function levenshtein(a, b) {
  const previous = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i += 1) {
    const current = [i];
    for (let j = 1; j <= b.length; j += 1) {
      current[j] = Math.min(current[j - 1] + 1, previous[j] + 1, previous[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    for (let j = 0; j <= b.length; j += 1) previous[j] = current[j];
  }
  return previous[b.length];
}

export function looksLikeTypo(command, module) {
  const input = normalize(command);
  if (!input || !module) return false;
  return module.drill.some((step) => {
    const target = normalize(step.command);
    if (!target || target === input || target.length < 5) return false;
    const threshold = target.length <= 10 ? 2 : Math.max(2, Math.floor(target.length * 0.22));
    return levenshtein(input, target) <= threshold;
  });
}

function modeLabel(mode) {
  if (mode === 'privileged') return 'privileged EXEC';
  if (mode === 'global') return 'global configuration';
  if (mode === 'interfaceRange') return 'interface-range';
  if (mode === 'lineConsole') return 'console line';
  if (mode === 'lineVty') return 'VTY line';
  if (mode === 'vlanConfig') return 'VLAN configuration';
  return `${mode ?? 'unknown'} mode`;
}

function duration(ms) {
  const sec = Math.max(0, Math.round(ms / 1000));
  return `${Math.floor(sec / 60)}m ${String(sec % 60).padStart(2, '0')}s`;
}

export function buildTwinFiles(module, session, finalState, errors = []) {
  const entries = session?.entries ?? [];
  const elapsed = entries.length ? entries[entries.length - 1].elapsedMs : 0;
  const typoCount = entries.filter((entry) => entry.typo).length;
  const modeChanges = entries.filter((entry) => entry.modeBefore !== entry.modeAfter);
  const successful = entries.filter((entry) => !entry.error);
  const objectives = (module?.objectives ?? []).map((objective) => `- [${objective.check(finalState) ? 'x' : ' '}] ${objective.label}`);

  const documentation = [
    `# Driller Bill Twin — ${module?.title ?? 'Practice Session'}`,
    '',
    '> First-person session record generated locally by Twin. Sensitive-looking values are redacted.',
    '',
    '## Session Summary',
    '',
    `- Started: ${new Date(session?.startedAt ?? Date.now()).toLocaleString()}`,
    `- Duration: ${duration(elapsed)}`,
    `- Commands: ${entries.length}`,
    `- Successful commands: ${successful.length}`,
    `- Errors: ${errors.length}`,
    `- Suspected typos: ${typoCount}`,
    `- Mode transitions: ${modeChanges.length}`,
    `- Final mode: ${modeLabel(finalState?.mode)}`,
    '',
    '## Objectives',
    '',
    ...objectives,
    '',
    '## Commands Executed',
    '',
    ...entries.flatMap((entry) => [
      `### ${duration(entry.elapsedMs)} — ${redactSensitive(entry.prompt)}`,
      '```text',
      redactSensitive(entry.command),
      '```',
      entry.outputs.length ? entry.outputs.map((output) => `> ${redactSensitive(output)}`).join('\n') : '> *(no output)*',
      '',
    ]),
  ].join('\n');

  const errorText = errors.length
    ? errors.map((error, index) => `${index + 1}. **${error.category}** — \`${redactSensitive(error.raw)}\` — ${error.message}`).join('\n')
    : '- No errors recorded during this session.';

  const errorAnchors = new Map();
  errors.forEach((error) => {
    if (error.theoryAnchor) errorAnchors.set(error.theoryAnchor, (errorAnchors.get(error.theoryAnchor) ?? 0) + 1);
  });
  const improvements = errorAnchors.size
    ? [...errorAnchors.entries()].sort((a, b) => b[1] - a[1]).map(([anchor, count]) => {
      const section = (module?.theory ?? []).find((item) => item.id === anchor);
      return `- **${section?.title ?? anchor}** — ${count} linked error${count === 1 ? '' : 's'}. Revisit the concept and repeat the drill.`;
    }).join('\n')
    : '- No theory-linked weaknesses were detected.';

  const cards = (module?.theory ?? []).slice(0, 8).map((section) => `## ${section.title}\n\n**Recall:** ${section.commandRef ?? 'Explain the concept in your own words.'}\n\n${section.body?.[0] ?? ''}`).join('\n\n');

  return {
    documentation,
    errors: `# Errors — ${module?.title ?? 'Practice'}\n\n${errorText}\n`,
    improvements: `# Areas of Improvement — ${module?.title ?? 'Practice'}\n\n${improvements}\n`,
    cueCards: `# Cue Cards — ${module?.title ?? 'Practice'}\n\n${cards}\n`,
  };
}



export function analyzeTwin(module, session = {}, finalState = {}, errors = []) {
  const entries = Array.isArray(session?.entries) ? session.entries : [];
  const theory = Array.isArray(module?.theory) ? module.theory : [];
  const objectives = Array.isArray(module?.objectives) ? module.objectives : [];
  const categoryCounts = new Map();
  const anchorCounts = new Map();
  const commandCounts = new Map();
  const objectiveCounts = new Map();

  errors.forEach((error) => {
    const category = error?.category || 'unknown';
    categoryCounts.set(category, (categoryCounts.get(category) ?? 0) + 1);
    if (error?.theoryAnchor) anchorCounts.set(error.theoryAnchor, (anchorCounts.get(error.theoryAnchor) ?? 0) + 1);
    if (error?.relatedObjectiveId) objectiveCounts.set(error.relatedObjectiveId, (objectiveCounts.get(error.relatedObjectiveId) ?? 0) + 1);
    const command = normalize(error?.raw);
    if (command) commandCounts.set(command, (commandCounts.get(command) ?? 0) + 1);
  });

  const typoCount = entries.filter((entry) => entry.typo).length;
  const completedObjectives = objectives.filter((objective) => objective.check(finalState)).length;
  const completionPct = objectives.length ? Math.round((completedObjectives / objectives.length) * 100) : 100;
  const errorRate = entries.length ? Math.round((errors.length / entries.length) * 100) : 0;
  const topCategory = [...categoryCounts.entries()].sort((a, b) => b[1] - a[1])[0];
  const topAnchor = [...anchorCounts.entries()].sort((a, b) => b[1] - a[1])[0];
  const topCommand = [...commandCounts.entries()].sort((a, b) => b[1] - a[1])[0];
  const topObjective = [...objectiveCounts.entries()].sort((a, b) => b[1] - a[1])[0];

  const signals = [];
  if (topCategory) {
    const labels = {
      'wrong-mode': 'mode selection',
      'wrong-order': 'command sequencing',
      syntax: 'command syntax',
      incomplete: 'command completeness',
      ambiguous: 'command specificity',
    };
    signals.push({
      id: `category-${topCategory[0]}`,
      type: 'error-pattern',
      strength: Math.min(100, 35 + topCategory[1] * 15),
      title: `Pattern: ${labels[topCategory[0]] || topCategory[0]}`,
      detail: `${topCategory[1]} ${topCategory[1] === 1 ? 'error' : 'errors'} in this session were classified as ${topCategory[0]}.`,
    });
  }
  if (topAnchor) {
    const section = theory.find((item) => item.id === topAnchor[0]);
    signals.push({
      id: `anchor-${topAnchor[0]}`,
      type: 'theory-gap',
      strength: Math.min(100, 40 + topAnchor[1] * 20),
      title: `Revisit: ${section?.title || topAnchor[0]}`,
      detail: `${topAnchor[1]} error${topAnchor[1] === 1 ? '' : 's'} linked back to this theory section.`,
      anchor: topAnchor[0],
    });
  }
  if (topObjective) {
    const objective = objectives.find((item) => item.id === topObjective[0]);
    signals.push({
      id: `objective-${topObjective[0]}`,
      type: 'objective-friction',
      strength: Math.min(100, 45 + topObjective[1] * 15),
      title: `Objective friction: ${objective?.label || topObjective[0]}`,
      detail: `${topObjective[1]} rejected attempt${topObjective[1] === 1 ? '' : 's'} were associated with this objective.`,
    });
  }
  if (typoCount) {
    signals.push({
      id: 'typo-signal',
      type: 'typing',
      strength: Math.min(90, 25 + typoCount * 10),
      title: 'Typing accuracy is adding friction',
      detail: `${typoCount} command${typoCount === 1 ? '' : 's'} looked close to a known drill command but were not exact.`,
    });
  }
  if (completionPct < 100 && objectives.length) {
    signals.push({
      id: 'completion-gap',
      type: 'state',
      strength: Math.min(100, 50 + (100 - completionPct) / 2),
      title: `${100 - completionPct}% of objectives remain`,
      detail: 'The final device state still has unfinished requirements; repeat the missing state transition rather than only reviewing the transcript.',
    });
  }

  const ranked = [...signals].sort((a, b) => b.strength - a.strength);
  const primary = ranked[0] || {
    id: 'no-signal', type: 'retention', strength: 20,
    title: 'No major friction detected',
    detail: 'The session produced no repeated error pattern. Use a delayed retry to test retention.',
  };

  const recommendations = [];
  if (topAnchor) {
    const section = theory.find((item) => item.id === topAnchor[0]);
    recommendations.push({ type: 'theory', label: `Review ${section?.title || topAnchor[0]}`, anchor: topAnchor[0] });
  }
  if (topCategory?.[0] === 'wrong-mode') recommendations.push({ type: 'practice', label: 'Do a mode-navigation drill before repeating the full module.' });
  if (topCategory?.[0] === 'wrong-order') recommendations.push({ type: 'practice', label: 'Repeat the command sequence slowly, checking state after each transition.' });
  if (topCategory?.[0] === 'syntax' || typoCount) recommendations.push({ type: 'practice', label: 'Repeat the commands from memory, prioritising exact syntax over speed.' });
  if (completionPct < 100) recommendations.push({ type: 'practice', label: 'Retry the unfinished objective before attempting speed mode.' });
  if (!recommendations.length) recommendations.push({ type: 'retention', label: 'Schedule a delayed retry to verify the commands stick without the transcript.' });

  return {
    primary,
    signals: ranked.slice(0, 4),
    recommendations: recommendations.slice(0, 3),
    stats: { commands: entries.length, errors: errors.length, errorRate, typos: typoCount, completionPct, completedObjectives, totalObjectives: objectives.length },
    repeatedCommand: topCommand ? { command: topCommand[0], count: topCommand[1] } : null,
  };
}

export function filesToZipPayload(files) {
  return {
    'Documentation.md': files.documentation,
    'Errors.md': files.errors,
    'Areas-of-improvement.md': files.improvements,
    'Cue-Cards.md': files.cueCards,
  };
}
