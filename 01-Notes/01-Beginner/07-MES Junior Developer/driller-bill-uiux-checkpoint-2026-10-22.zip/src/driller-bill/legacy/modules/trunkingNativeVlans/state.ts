export interface TrunkCustomState {
  vlans: Record<number, { name?: string }>
  currentInterface: string | null
  trunkMode: boolean
  nativeVlan: number | null
  allowedVlans: number[] | null
  nonegotiate: boolean
  noShutdown: boolean
  savedToStartup: boolean
}

export function initialTrunkCustom(): TrunkCustomState {
  return {
    vlans: {},
    currentInterface: null,
    trunkMode: false,
    nativeVlan: null,
    allowedVlans: null,
    nonegotiate: false,
    noShutdown: false,
    savedToStartup: false,
  }
}
