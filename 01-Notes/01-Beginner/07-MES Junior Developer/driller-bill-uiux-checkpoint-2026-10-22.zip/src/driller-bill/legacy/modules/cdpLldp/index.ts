import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand } from './engine'
import { renderPrompt, withDoSupport } from '../../engine/shell'

export const cdpLldpModule: ModuleDefinition = {
  id: 'cdp-lldp',
  title: 'CDP & LLDP Neighbor Discovery',
  summary: 'Use CDP to identify directly connected neighbors, enable LLDP for non-Cisco gear, and disable CDP on an untrusted-facing port.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
