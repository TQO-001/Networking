import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand } from './engine'
import { renderPrompt, withDoSupport } from '../../engine/shell'

export const vlansAccessPortsModule: ModuleDefinition = {
  id: 'vlans-access-ports',
  title: 'VLANs & Access Ports',
  summary: 'Create VLANs (individually and with range syntax) and assign access ports \u2014 single and range \u2014 to them.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
