// Full Device Simulator: routes a command against EVERY module's engine in
// turn, sharing ONE state object across all of them. This isn't a rewrite
// of 15 command grammars into one giant file \u2014 it reuses the already
// tested per-module engines as-is. Each module's engine only reads/writes
// the custom-state fields it knows about (via its own local `c(state)`
// cast), so sharing one big `custom` bag across all of them is safe: field
// names were kept consistent across modules on purpose (e.g. every module
// that tracks VLANs uses the same `vlans: Record<number,{name?:string}>`
// shape), so the same command has the same effect no matter which module's
// engine happens to be the one that recognizes it.
//
// Routing: try each engine against the CURRENT shared state. The first one
// that doesn't return a generic "not part of this drill" syntax error wins
// and its resulting state becomes the new shared state. If none recognize
// the command, a single synthesized error is shown instead of a random
// module's oddly-specific rejection message.

import type { CommandResult, EngineState, Objective } from '../../types'
import { renderPrompt as sharedRenderPrompt, withDoSupport, genericIosCommand } from '../../engine/shell'

import * as bootRecovery from '../bootPasswordRecovery/engine'
import * as factoryReset from '../factoryReset/engine'
import * as iosImage from '../iosImageManagement/engine'
import * as backupRestore from '../backupRestore/engine'
import * as basicMgmt from '../basicManagementSetup/engine'
import * as ifaceTs from '../interfaceTroubleshooting/engine'
import * as vlans from '../vlansAccessPorts/engine'
import * as trunking from '../trunkingNativeVlans/engine'
import * as etherchannel from '../etherchannelLacp/engine'
import * as portSecurity from '../portSecurity/engine'
import * as spanningTree from '../spanningTree/engine'
import * as vtp from '../vtp/engine'
import * as interVlan from '../interVlanRouting/engine'
import * as cdpLldp from '../cdpLldp/engine'
import * as dhcpSnooping from '../dhcpSnoopingDai/engine'

type Engine = { handleCommand: (raw: string, state: EngineState, objectives: Objective[]) => CommandResult }

// Boot/Password Recovery is deliberately excluded: it starts in ROMMON
// (mode: 'special') with its own prompt semantics, which doesn't make
// sense mixed into a normal already-booted device session. It stays its
// own dedicated Sandbox command set instead.
const ENGINES: Engine[] = [
  basicMgmt,
  vlans,
  trunking,
  etherchannel,
  portSecurity,
  spanningTree,
  vtp,
  interVlan,
  ifaceTs,
  cdpLldp,
  dhcpSnooping,
  factoryReset,
  iosImage,
  backupRestore,
]

function initialFullDeviceCustom(): Record<string, unknown> {
  return {
    ...factoryReset.createInitialState().custom,
    ...iosImage.createInitialState().custom,
    ...backupRestore.createInitialState().custom,
    ...basicMgmt.createInitialState().custom,
    ...ifaceTs.createInitialState().custom,
    ...vlans.createInitialState().custom,
    ...trunking.createInitialState().custom,
    ...etherchannel.createInitialState().custom,
    ...portSecurity.createInitialState().custom,
    ...spanningTree.createInitialState().custom,
    ...vtp.createInitialState().custom,
    ...interVlan.createInitialState().custom,
    ...cdpLldp.createInitialState().custom,
    ...dhcpSnooping.createInitialState().custom,
  }
}

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialFullDeviceCustom(),
  }
}

export const renderPrompt = sharedRenderPrompt

// A rejection is only worth surfacing directly if it's a rich semantic
// error \u2014 wrong-order, incomplete, or ambiguous \u2014 meaning some engine
// clearly recognized the command's structure and flagged a real issue
// (e.g. "copy the image in before setting boot system"). A plain 'syntax'
// rejection just means "this particular engine doesn't model this command,"
// which is common and expected when trying 14 narrow engines against one
// command \u2014 it should never win over another engine actually succeeding
// further down the list.
function isRichSemanticError(result: CommandResult): boolean {
  return !!result.error && result.error.category !== 'syntax'
}

function rawHandleCommand(raw: string, state: EngineState, objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()
  if (trimmed === '') return { output: [], state }

  const tokens = trimmed.split(/\s+/)
  if (tokens[0]?.toLowerCase() === '?') {
    return { output: ['Full Device sandbox: try any command from any of the 15 modules \u2014 hostname, vlan, interface, switchport, spanning-tree, ip dhcp snooping, crypto, copy, show, etc.'], state }
  }

  // Try every engine against the SAME original state (each engine call is
  // pure \u2014 it never mutates `state`, only returns a new one \u2014 so trying
  // all of them is safe). Prefer the first outright success; failing that,
  // prefer the first rich semantic error; otherwise fall back to a single
  // synthesized "not recognized" message instead of whichever engine's
  // oddly-specific rejection happened to run first.
  let firstSemanticError: CommandResult | null = null
  for (const engine of ENGINES) {
    const result = engine.handleCommand(raw, state, objectives)
    if (!result.error) return result
    if (!firstSemanticError && isRichSemanticError(result)) firstSemanticError = result
  }

  if (firstSemanticError) return firstSemanticError

  const generic = genericIosCommand(raw, state)
  if (generic) return generic

  return {
    output: ["% Invalid input detected at '^' marker."],
    state,
    error: {
      category: 'syntax',
      message:
        'None of the 15 modules\u2019 engines recognize this command. Full Device covers the union of everything built so far, but not the entire real IOS command set.',
    },
  }
}

export const handleCommand = withDoSupport(rawHandleCommand)
