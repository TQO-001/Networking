import type { ModuleDefinition } from '../types'
import { loadDeclarativeModules } from '../lib/declarative'
import { bootPasswordRecoveryModule } from './bootPasswordRecovery'
import { basicManagementSetupModule } from './basicManagementSetup'
import { factoryResetModule } from './factoryReset'
import { iosImageManagementModule } from './iosImageManagement'
import { backupRestoreModule } from './backupRestore'
import { interfaceTroubleshootingModule } from './interfaceTroubleshooting'
import { vlansAccessPortsModule } from './vlansAccessPorts'
import { trunkingNativeVlansModule } from './trunkingNativeVlans'
import { etherchannelLacpModule } from './etherchannelLacp'
import { portSecurityModule } from './portSecurity'
import { spanningTreeModule } from './spanningTree'
import { vtpModule } from './vtp'
import { interVlanRoutingModule } from './interVlanRouting'
import { cdpLldpModule } from './cdpLldp'
import { dhcpSnoopingDaiModule } from './dhcpSnoopingDai'
import { deviceLabModules } from './deviceLabs'

// Core simulator engines. Community JSON drills are layered on top below,
// so content contributors do not need to edit this file.
const engineModules: ModuleDefinition[] = [
  bootPasswordRecoveryModule,
  factoryResetModule,
  iosImageManagementModule,
  backupRestoreModule,
  basicManagementSetupModule,
  interfaceTroubleshootingModule,
  vlansAccessPortsModule,
  trunkingNativeVlansModule,
  etherchannelLacpModule,
  portSecurityModule,
  spanningTreeModule,
  vtpModule,
  interVlanRoutingModule,
  cdpLldpModule,
  dhcpSnoopingDaiModule,
]

const communityDrillFiles = import.meta.glob('../../content/drills/*.json', { eager: true, import: 'default' })
const communityModules = loadDeclarativeModules(communityDrillFiles, engineModules)

const legacyModules: ModuleDefinition[] = engineModules.map((module) => ({
  ...module,
  category: module.category ?? 'switch',
  difficulty: module.difficulty ?? (module.id.includes('troubleshooting') || module.id.includes('security') ? 'intermediate' : 'beginner'),
}))

export const modules: ModuleDefinition[] = [...legacyModules, ...deviceLabModules, ...communityModules.map((module) => ({ ...module, category: module.category ?? 'switch' }))]

export function getModule(id: string): ModuleDefinition | undefined {
  return modules.find((m) => m.id === id)
}
