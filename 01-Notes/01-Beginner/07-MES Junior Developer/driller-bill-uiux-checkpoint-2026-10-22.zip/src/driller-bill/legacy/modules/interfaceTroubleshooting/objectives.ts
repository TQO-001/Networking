import type { EngineState, Objective } from '../../types'
import type { InterfaceTsCustomState } from './state'

function c(state: EngineState): InterfaceTsCustomState {
  return state.custom as InterfaceTsCustomState
}

export const objectives: Objective[] = [
  {
    id: 'checked-status',
    label: 'Check overall interface status',
    description: 'Run "show interfaces status" to get the fast overview.',
    theoryAnchor: 'interface-states',
    check: (s) => c(s).checkedStatus,
  },
  {
    id: 'checked-interface-detail',
    label: 'Look closer at a specific interface',
    description: 'Run a detailed show command on Fa0/3 or Fa0/5.',
    theoryAnchor: 'duplex-mismatch',
    check: (s) => c(s).checkedInterfaceDetail,
  },
  {
    id: 'fixed-duplex-mismatch',
    label: 'Fix the duplex mismatch on Fa0/3',
    description: 'Set matching speed and duplex.',
    theoryAnchor: 'duplex-mismatch',
    check: (s) => c(s).fixedDuplexMismatch,
  },
  {
    id: 'identified-errdisable-cause',
    label: 'Identify the err-disable cause on Fa0/5',
    description: 'Find out why the port tripped before recovering it.',
    theoryAnchor: 'errdisable-diagnosis',
    check: (s) => c(s).identifiedErrDisableCause,
  },
  {
    id: 'recovered-port',
    label: 'Recover the err-disabled port',
    description: 'shutdown then no shutdown on Fa0/5.',
    theoryAnchor: 'errdisable-recovery',
    check: (s) => c(s).recoveredPort,
  },
  {
    id: 'configured-auto-recovery',
    label: 'Configure err-disable auto-recovery',
    description: 'Set a recovery cause and an interval globally.',
    theoryAnchor: 'errdisable-recovery',
    check: (s) => c(s).configuredAutoRecovery,
  },
  {
    id: 'saved-config',
    label: 'Save the configuration',
    description: 'Copy running-config to startup-config.',
    theoryAnchor: 'errdisable-recovery',
    check: (s) => c(s).savedToStartup,
  },
]
