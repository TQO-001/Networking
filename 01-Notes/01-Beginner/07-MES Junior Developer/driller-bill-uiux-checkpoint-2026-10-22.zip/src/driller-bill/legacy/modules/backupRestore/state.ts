export interface BackupRestoreCustomState {
  backedUp: boolean
  backupFilename: string | null
  copiedToFlash: boolean
  flashFilename: string | null
  configReplaced: boolean
  pendingConfirmRequired: boolean
  ranConfigureConfirm: boolean
  savedToStartup: boolean
}

export function initialBackupRestoreCustom(): BackupRestoreCustomState {
  return {
    backedUp: false,
    backupFilename: null,
    copiedToFlash: false,
    flashFilename: null,
    configReplaced: false,
    pendingConfirmRequired: false,
    ranConfigureConfirm: false,
    savedToStartup: false,
  }
}
