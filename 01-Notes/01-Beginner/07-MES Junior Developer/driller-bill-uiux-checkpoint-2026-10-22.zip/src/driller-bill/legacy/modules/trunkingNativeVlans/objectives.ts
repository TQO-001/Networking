import type { EngineState, Objective } from '../../types'
import type { TrunkCustomState } from './state'

function c(state: EngineState): TrunkCustomState {
  return state.custom as TrunkCustomState
}

export const objectives: Objective[] = [
  {
    id: 'created-native-vlan',
    label: 'Create the dedicated native VLAN',
    description: 'vlan 999, named.',
    theoryAnchor: 'native-vlan',
    check: (s) => !!c(s).vlans[999]?.name,
  },
  {
    id: 'set-trunk-mode',
    label: 'Force trunk mode',
    description: 'switchport mode trunk.',
    theoryAnchor: 'dot1q-tagging',
    check: (s) => c(s).trunkMode,
  },
  {
    id: 'set-native-vlan',
    label: 'Set the native VLAN to 999',
    description: 'Not VLAN 1, not a VLAN carrying data.',
    theoryAnchor: 'native-vlan',
    check: (s) => c(s).nativeVlan === 999,
  },
  {
    id: 'set-allowed-vlans',
    label: 'Restrict the allowed VLAN list',
    description: 'Prune the trunk down from the default "all VLANs".',
    theoryAnchor: 'allowed-vlans',
    check: (s) => !!c(s).allowedVlans && c(s).allowedVlans!.length > 0,
  },
  {
    id: 'set-nonegotiate',
    label: 'Disable DTP negotiation',
    description: 'switchport nonegotiate.',
    theoryAnchor: 'dot1q-tagging',
    check: (s) => c(s).nonegotiate,
  },
  {
    id: 'saved-config',
    label: 'Save the configuration',
    description: 'copy running-config startup-config.',
    theoryAnchor: 'dot1q-tagging',
    check: (s) => c(s).savedToStartup,
  },
]
