import type { EngineState, Objective } from '../../types'
import type { BmsCustomState } from './state'

function c(state: EngineState): BmsCustomState {
  return state.custom as BmsCustomState
}

export const objectives: Objective[] = [
  {
    id: 'hostname',
    label: 'Set a non-default hostname',
    description: 'The switch should no longer be using the default "Switch" hostname.',
    theoryAnchor: 'hostname-domain',
    check: (s) => s.hostname !== 'Switch',
  },
  {
    id: 'domain',
    label: 'Configure the IP domain name',
    description: 'Required before RSA key generation will work correctly.',
    theoryAnchor: 'hostname-domain',
    check: (s) => !!c(s).domainName,
  },
  {
    id: 'enable-secret',
    label: 'Set the enable secret',
    description: 'Privileged EXEC access should be protected with a hashed secret.',
    theoryAnchor: 'enable-secret',
    check: (s) => c(s).enableSecretSet,
  },
  {
    id: 'local-user',
    label: 'Create a local user account',
    description: 'SSH login should authenticate against a named local account, not a bare line password.',
    theoryAnchor: 'local-auth',
    check: (s) => Object.keys(c(s).users).length > 0,
  },
  {
    id: 'rsa-key',
    label: 'Generate the RSA key pair',
    description: 'This is what actually enables the SSH server.',
    theoryAnchor: 'rsa-keys',
    check: (s) => c(s).rsaKeyGenerated,
  },
  {
    id: 'ssh-version',
    label: 'Force SSH version 2',
    description: 'SSHv1 has known vulnerabilities and should be explicitly disabled.',
    theoryAnchor: 'ssh-hardening',
    check: (s) => c(s).sshVersion === 2,
  },
  {
    id: 'console-secured',
    label: 'Secure the console line',
    description: 'login local, logging synchronous, and an exec-timeout should all be set.',
    theoryAnchor: 'line-security',
    check: (s) => c(s).consoleLine.loginLocal && c(s).consoleLine.loggingSync && c(s).consoleLine.execTimeoutSet,
  },
  {
    id: 'vty-secured',
    label: 'Secure the VTY lines for SSH only',
    description: 'login local, transport input ssh, and an exec-timeout should all be set.',
    theoryAnchor: 'line-security',
    check: (s) => c(s).vtyLine.loginLocal && c(s).vtyLine.transportSsh && c(s).vtyLine.execTimeoutSet,
  },
  {
    id: 'banner',
    label: 'Configure a legal warning banner',
    description: 'A banner motd should be set.',
    theoryAnchor: 'banner',
    check: (s) => c(s).bannerSet,
  },
  {
    id: 'mgmt-vlan',
    label: 'Create and name the management VLAN',
    description: 'VLAN 99 should exist and be named.',
    theoryAnchor: 'mgmt-vlan-svi',
    check: (s) => !!c(s).vlans[99]?.name,
  },
  {
    id: 'svi-configured',
    label: 'Configure and enable the management SVI',
    description: 'Interface VLAN 99 needs an IP address and no shutdown.',
    theoryAnchor: 'mgmt-vlan-svi',
    check: (s) => !!c(s).svi99.ipAddress && !!c(s).svi99.noShutdown,
  },
  {
    id: 'default-gateway',
    label: 'Set the default gateway',
    description: 'Required for the switch\u2019s own management traffic to reach off-subnet destinations.',
    theoryAnchor: 'default-gateway',
    check: (s) => !!c(s).defaultGateway,
  },
  {
    id: 'password-encryption',
    label: 'Enable password encryption',
    description: 'Cleans up any remaining plaintext secrets in the config.',
    theoryAnchor: 'password-encryption',
    check: (s) => c(s).passwordEncryption,
  },
  {
    id: 'saved-config',
    label: 'Save the configuration',
    description: 'Copy running-config to startup-config so changes survive a reload.',
    theoryAnchor: 'save-config',
    check: (s) => c(s).savedToStartup,
  },
]
