import type { CommandResult, EngineState, Objective } from '../../types'
import {
  INCOMPLETE_COMMAND,
  INVALID_INPUT,
  expandInterfaceRange,
  normalizeInterfaceName,
  popMode,
  resolveWord,
} from '../../engine/shell'
import { initialInterVlanCustom, type InterVlanCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialInterVlanCustom(),
  }
}

function c(state: EngineState): InterVlanCustomState {
  return state.custom as InterVlanCustomState
}
function withCustom(state: EngineState, patch: Partial<InterVlanCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}
function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}
function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}
function ipLike(token: string): boolean {
  return /^\d{1,3}(\.\d{1,3}){3}$/.test(token)
}
function activeInterfaces(cs: InterVlanCustomState): string[] {
  if (cs.currentInterfaceRange) return cs.currentInterfaceRange
  if (cs.currentInterface) return [cs.currentInterface]
  return []
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()
  if (trimmed === '') return ok(state, [])
  const tokens = trimmed.split(/\s+/)
  const first = tokens[0].toLowerCase()
  const cs = c(state)

  if (first === 'end') return ok({ ...state, mode: 'privileged', awaitingInput: null }, [])
  if (resolveWord(first, ['exit']) === 'exit') {
    if (state.mode === 'user') return ok(state, [])
    if (state.mode === 'privileged') return ok({ ...state, mode: 'user' }, [])
    return ok(withCustom({ ...state, mode: popMode(state.mode) }, { currentInterface: null, currentInterfaceRange: null }), [])
  }
  if (first === '?') return ok(state, [helpFor(state)])

  if (state.mode === 'user') {
    if (resolveWord(first, ['enable']) === 'enable') return ok({ ...state, mode: 'privileged' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in user EXEC mode. Try "enable".`)
  }

  if (state.mode === 'privileged') {
    const word = resolveWord(first, ['configure', 'show', 'copy', 'disable'])
    if (word === 'configure') {
      if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure needs an argument.')
      if (resolveWord(tokens[1], ['terminal']) === 'terminal') return ok({ ...state, mode: 'global' }, ['Enter configuration commands, one per line.  End with CNTL/Z.'])
      return errFail(state, [INVALID_INPUT], 'syntax', 'Only "configure terminal" is supported.')
    }
    if (word === 'show') {
      const target = tokens.slice(1).join(' ').toLowerCase()
      if (target === 'ip route') {
        const lines = ['Codes: C - connected, S - static']
        Object.entries(cs.svis).forEach(([id, svi]) => {
          if (svi.ipAddress) lines.push(`C    192.168.${id}.0/24 is directly connected, Vlan${id}`)
        })
        if (lines.length === 1) lines.push('(no routes \u2014 configure the SVIs first)')
        return ok(withCustom(state, { checkedRoutes: true }), lines, 'verified-routes')
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "show ip route".')
    }
    if (word === 'copy') {
      const rest = tokens.slice(1).join(' ').toLowerCase()
      if (rest === 'running-config startup-config') return ok(withCustom(state, { savedToStartup: true }), ['Building configuration...', '[OK]'], 'saved-config')
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "copy running-config startup-config".')
    }
    if (word === 'disable') return ok({ ...state, mode: 'user' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set.`)
  }

  if (state.mode === 'global') {
    const word = resolveWord(first, ['ip', 'vlan', 'interface'])
    if (word === 'ip') {
      if (resolveWord(tokens[1] ?? '', ['routing']) === 'routing') return ok(withCustom(state, { ipRoutingEnabled: true }), [], 'enabled-ip-routing')
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer only simulates "ip routing" here.')
    }
    if (word === 'vlan') {
      const id = Number(tokens[1])
      if (!Number.isInteger(id)) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'vlan needs a numeric ID.')
      const vlans = { ...cs.vlans, [id]: cs.vlans[id] ?? {} }
      return ok(withCustom({ ...state, mode: 'vlanConfig' }, { vlans }), [])
    }
    if (word === 'interface') {
      const rest = tokens.slice(1)
      if (resolveWord(rest[0] ?? '', ['range']) === 'range') {
        const list = expandInterfaceRange(rest.slice(1))
        if (!list) return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "interface range fastethernet0/1 - 5".')
        return ok(withCustom({ ...state, mode: 'interfaceRange' }, { currentInterfaceRange: list, currentInterface: null }), [])
      }
      const iface = normalizeInterfaceName(rest.join(''))
      if (!iface) return errFail(state, [INVALID_INPUT], 'syntax', 'Expected an interface name, e.g. "interface vlan 10".')
      return ok(withCustom({ ...state, mode: 'interface' }, { currentInterface: iface, currentInterfaceRange: null }), [])
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in global configuration mode.`)
  }

  if (state.mode === 'vlanConfig') {
    if (resolveWord(first, ['name']) === 'name') {
      const name = tokens.slice(1).join(' ')
      if (!name) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'name needs a VLAN name.')
      const vlanId = Object.keys(cs.vlans).map(Number).find((id) => !cs.vlans[id].name)
      if (vlanId === undefined) return errFail(state, [INVALID_INPUT], 'wrong-mode', 'No pending VLAN to name.')
      const vlans = { ...cs.vlans, [vlanId]: { name } }
      return ok(withCustom(state, { vlans }), [])
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'Try "name <text>".')
  }

  if (state.mode === 'interface') {
    const iface = cs.currentInterface
    if (iface?.startsWith('vlan')) {
      const vlanId = Number(iface.replace('vlan', ''))
      const word = resolveWord(first, ['ip', 'no'])
      if (word === 'ip') {
        if (resolveWord(tokens[1] ?? '', ['address']) !== 'address' || !tokens[2] || !tokens[3] || !ipLike(tokens[2]) || !ipLike(tokens[3])) {
          return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "ip address <ip> <mask>".')
        }
        const svis = { ...cs.svis, [vlanId]: { ...cs.svis[vlanId], ipAddress: `${tokens[2]} ${tokens[3]}` } }
        return ok(withCustom(state, { svis }), [], checkSviObjective(vlanId, svis))
      }
      if (word === 'no') {
        if (resolveWord(tokens[1] ?? '', ['shutdown']) !== 'shutdown') return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "no shutdown".')
        const svis = { ...cs.svis, [vlanId]: { ...cs.svis[vlanId], noShutdown: true } }
        return ok(withCustom(state, { svis }), [], checkSviObjective(vlanId, svis))
      }
      return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s SVI command set.`)
    }
    return errFail(state, [INVALID_INPUT], 'wrong-mode', 'Not an SVI interface in this trainer.')
  }

  if (state.mode === 'interfaceRange') {
    const ifaces = activeInterfaces(cs)
    const word = resolveWord(first, ['switchport'])
    if (word === 'switchport') {
      const sub = resolveWord(tokens[1] ?? '', ['mode', 'access'])
      if (sub === 'mode') {
        if (resolveWord(tokens[2] ?? '', ['access']) !== 'access') return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer only simulates "switchport mode access".')
        const ports = { ...cs.ports }
        ifaces.forEach((i) => { ports[i] = { ...ports[i], mode: 'access' } })
        return ok(withCustom(state, { ports }), [])
      }
      if (sub === 'access') {
        if (resolveWord(tokens[2] ?? '', ['vlan']) !== 'vlan' || !tokens[3]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Expected "switchport access vlan <id>".')
        const id = Number(tokens[3])
        const ports = { ...cs.ports }
        ifaces.forEach((i) => { ports[i] = { ...ports[i], vlan: id } })
        const next = withCustom(state, { ports })
        const done = Array.from({ length: 5 }, (_, i) => i + 1).every((n) => {
          const p = c(next).ports[`fastethernet0/${n}`]
          return p?.mode === 'access' && p?.vlan === 10
        })
        return ok(next, [], done ? 'assigned-ports' : undefined)
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "switchport mode access" or "switchport access vlan <id>".')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s interface command set.`)
  }

  return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized shell state.')
}

function checkSviObjective(vlanId: number, svis: InterVlanCustomState['svis']): string | undefined {
  const svi = svis[vlanId]
  if (!svi?.ipAddress || !svi?.noShutdown) return undefined
  if (vlanId === 10) return 'configured-svi10'
  if (vlanId === 20) return 'configured-svi20'
  return undefined
}

function helpFor(state: EngineState): string {
  if (state.mode === 'user') return 'enable'
  if (state.mode === 'global') return 'ip routing, vlan <id>, interface vlan <id>, interface range <a> - <b>, end, exit'
  if (state.mode === 'interface') return 'ip address <ip> <mask>, no shutdown, exit'
  if (state.mode === 'interfaceRange') return 'switchport mode access, switchport access vlan <id>, exit'
  return 'configure terminal, show ip route, copy running-config startup-config'
}
