export interface DhcpSnoopingCustomState {
  dhcpSnoopingEnabled: boolean
  dhcpSnoopingVlans: number[]
  currentInterface: string | null
  currentInterfaceRange: string[] | null
  uplinkDhcpTrusted: boolean
  dhcpRateLimited: boolean
  arpInspectionVlans: number[]
  uplinkArpTrusted: boolean
  arpRateLimited: boolean
  savedToStartup: boolean
}

export function initialDhcpSnoopingCustom(): DhcpSnoopingCustomState {
  return {
    dhcpSnoopingEnabled: false,
    dhcpSnoopingVlans: [],
    currentInterface: null,
    currentInterfaceRange: null,
    uplinkDhcpTrusted: false,
    dhcpRateLimited: false,
    arpInspectionVlans: [],
    uplinkArpTrusted: false,
    arpRateLimited: false,
    savedToStartup: false,
  }
}
