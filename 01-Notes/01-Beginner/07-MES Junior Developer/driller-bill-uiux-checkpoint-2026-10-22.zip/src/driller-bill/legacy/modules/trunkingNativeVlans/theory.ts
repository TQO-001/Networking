import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'dot1q-tagging',
    title: '802.1Q Tagging',
    commandRef: 'switchport mode trunk',
    body: [
      'A trunk carries multiple VLANs across one physical link by inserting a 4-byte 802.1Q tag (VLAN ID + CoS priority) into the frame header. This is essential between switches, or to a router/firewall.',
    ],
  },
  {
    id: 'native-vlan',
    title: 'Native VLAN',
    commandRef: 'switchport trunk native vlan <id>',
    body: [
      'One exception to tagging: frames in the native VLAN cross the trunk untagged. Default is VLAN 1 on both ends \u2014 a native VLAN mismatch between the two ends silently misroutes untagged traffic and is a known VLAN-hopping risk.',
      'Best practice: set the native VLAN to a dedicated, unused VLAN ID \u2014 never VLAN 1, never a VLAN carrying real data.',
    ],
  },
  {
    id: 'allowed-vlans',
    title: 'Allowed VLAN List',
    commandRef: 'switchport trunk allowed vlan <list>',
    body: [
      'By default a trunk carries ALL VLANs (1\u20134094). Pruning this down to only what\u2019s actually needed reduces unnecessary flooding and limits blast radius.',
    ],
  },
]
