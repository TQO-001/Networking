import type { CommandResult, EngineState, Objective } from '../../types'
import {
  AMBIGUOUS_COMMAND,
  INCOMPLETE_COMMAND,
  INVALID_INPUT,
  expandInterfaceRange,
  normalizeInterfaceName,
  popMode,
  resolveWord,
} from '../../engine/shell'
import { initialVlansCustom, type VlansCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialVlansCustom(),
  }
}

function c(state: EngineState): VlansCustomState {
  return state.custom as VlansCustomState
}
function withCustom(state: EngineState, patch: Partial<VlansCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}
function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}
function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}

function activeInterfaces(cs: VlansCustomState): string[] {
  if (cs.currentInterfaceRange) return cs.currentInterfaceRange
  if (cs.currentInterface) return [cs.currentInterface]
  return []
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()
  if (trimmed === '') return ok(state, [])
  const tokens = trimmed.split(/\s+/)
  const first = tokens[0].toLowerCase()
  const cs = c(state)

  if (first === 'end') return ok({ ...state, mode: 'privileged', awaitingInput: null }, [])
  if (resolveWord(first, ['exit']) === 'exit') {
    if (state.mode === 'user') return ok(state, [])
    if (state.mode === 'privileged') return ok({ ...state, mode: 'user' }, [])
    return ok(withCustom({ ...state, mode: popMode(state.mode) }, { currentInterface: null, currentInterfaceRange: null }), [])
  }
  if (first === '?') return ok(state, [helpFor(state)])

  if (state.mode === 'user') {
    const word = resolveWord(first, ['enable'])
    if (word === 'enable') return ok({ ...state, mode: 'privileged' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in user EXEC mode. Try "enable".`)
  }

  if (state.mode === 'privileged') {
    const word = resolveWord(first, ['configure', 'copy', 'disable'])
    if (word === 'configure') {
      if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure needs an argument, e.g. "configure terminal".')
      const sub = resolveWord(tokens[1], ['terminal'])
      if (sub === 'terminal') return ok({ ...state, mode: 'global' }, ['Enter configuration commands, one per line.  End with CNTL/Z.'])
      return errFail(state, [INVALID_INPUT], 'syntax', 'Only "configure terminal" is supported in this trainer.')
    }
    if (word === 'copy') {
      const rest = tokens.slice(1).join(' ').toLowerCase()
      if (rest === 'running-config startup-config') {
        return ok(withCustom(state, { savedToStartup: true }), ['Building configuration...', '[OK]'], 'saved-config')
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "copy running-config startup-config".')
    }
    if (word === 'disable') return ok({ ...state, mode: 'user' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in privileged EXEC mode.`)
  }

  if (state.mode === 'global') {
    const word = resolveWord(first, ['vlan', 'interface'])
    if (word === 'vlan') {
      const arg = tokens[1]
      if (!arg) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'vlan needs an ID or comma-separated list, e.g. "vlan 10" or "vlan 30,40,50".')
      const ids = arg.split(',').map(Number)
      if (ids.some((n) => !Number.isInteger(n))) return errFail(state, [INVALID_INPUT], 'syntax', 'VLAN IDs must be numeric.')
      const vlans = { ...cs.vlans }
      ids.forEach((id) => { vlans[id] = vlans[id] ?? {} })
      const next = withCustom({ ...state, mode: ids.length === 1 ? 'vlanConfig' : state.mode }, { vlans })
      return ok(next, [])
    }
    if (word === 'interface') {
      const rest = tokens.slice(1)
      if (resolveWord(rest[0] ?? '', ['range']) === 'range') {
        const list = expandInterfaceRange(rest.slice(1))
        if (!list) return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "interface range fastethernet0/2 - 10".')
        const next = withCustom({ ...state, mode: 'interfaceRange' }, { currentInterfaceRange: list, currentInterface: null })
        return ok(next, [])
      }
      const iface = normalizeInterfaceName(rest.join(''))
      if (!iface) return errFail(state, [INVALID_INPUT], 'syntax', 'Expected an interface name, e.g. "interface fastethernet0/1".')
      const next = withCustom({ ...state, mode: 'interface' }, { currentInterface: iface, currentInterfaceRange: null })
      return ok(next, [])
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in global configuration mode.`)
  }

  if (state.mode === 'vlanConfig') {
    const word = resolveWord(first, ['name'])
    if (word === 'name') {
      const name = tokens.slice(1).join(' ')
      if (!name) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'name needs a VLAN name argument.')
      const vlanId = Object.keys(cs.vlans).map(Number).find((id) => !cs.vlans[id].name)
      if (vlanId === undefined) return errFail(state, [INVALID_INPUT], 'wrong-mode', 'No pending VLAN to name.')
      const vlans = { ...cs.vlans, [vlanId]: { name } }
      const next = withCustom(state, { vlans })
      const objectiveCompleted = vlanId === 10 ? 'created-named-vlan10' : vlanId === 20 ? 'created-named-vlan20' : undefined
      return ok(next, [], objectiveCompleted)
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s vlan-config command set. Try "name <text>".`)
  }

  if (state.mode === 'interface' || state.mode === 'interfaceRange') {
    const word = resolveWord(first, ['switchport', 'no'])
    const ifaces = activeInterfaces(cs)
    if (word === 'switchport') {
      const sub = resolveWord(tokens[1] ?? '', ['mode', 'access', 'nonegotiate'])
      if (sub === 'mode') {
        const m = resolveWord(tokens[2] ?? '', ['access'])
        if (m !== 'access') return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer only simulates "switchport mode access".')
        const ports = { ...cs.ports }
        ifaces.forEach((i) => { ports[i] = { ...ports[i], mode: 'access' } })
        return ok(withCustom(state, { ports }), [])
      }
      if (sub === 'access') {
        const vlanWord = resolveWord(tokens[2] ?? '', ['vlan'])
        if (vlanWord !== 'vlan' || !tokens[3]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Expected "switchport access vlan <id>".')
        const vlanId = Number(tokens[3])
        if (!Number.isInteger(vlanId)) return errFail(state, [INVALID_INPUT], 'syntax', 'VLAN ID must be numeric.')
        const ports = { ...cs.ports }
        ifaces.forEach((i) => { ports[i] = { ...ports[i], vlan: vlanId } })
        const next = withCustom(state, { ports })
        return ok(next, [], checkPortObjectives(next))
      }
      if (sub === 'nonegotiate') {
        const ports = { ...cs.ports }
        ifaces.forEach((i) => { ports[i] = { ...ports[i], nonegotiate: true } })
        return ok(withCustom(state, { ports }), [])
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "switchport mode access", "switchport access vlan <id>", or "switchport nonegotiate".')
    }
    if (word === 'no') {
      const sub = resolveWord(tokens[1] ?? '', ['shutdown'])
      if (sub === 'shutdown') {
        const ports = { ...cs.ports }
        ifaces.forEach((i) => { ports[i] = { ...ports[i], noShutdown: true } })
        const next = withCustom(state, { ports })
        return ok(next, [], checkPortObjectives(next))
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "no shutdown".')
    }
    if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s interface command set.`)
  }

  return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized shell state.')
}

function checkPortObjectives(state: EngineState): string | undefined {
  const cs = c(state)
  const p1 = cs.ports['fastethernet0/1']
  if (p1?.mode === 'access' && p1?.vlan === 10 && p1?.noShutdown) return 'assigned-single-port'
  for (let n = 2; n <= 10; n++) {
    const p = cs.ports[`fastethernet0/${n}`]
    if (!p || p.mode !== 'access' || p.vlan !== 20) return undefined
  }
  return 'assigned-port-range'
}

function helpFor(state: EngineState): string {
  if (state.mode === 'user') return 'enable'
  if (state.mode === 'global') return 'vlan <id>, interface <name>, interface range <a> - <b>, end, exit'
  if (state.mode === 'vlanConfig') return 'name <text>, exit'
  if (state.mode === 'interface' || state.mode === 'interfaceRange') return 'switchport mode access, switchport access vlan <id>, switchport nonegotiate, no shutdown, exit'
  return 'configure terminal, copy running-config startup-config'
}
