import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'root-election',
    title: 'Root Bridge Election',
    commandRef: 'spanning-tree vlan <ids> root primary',
    body: [
      'Left to default priority, the root bridge election tiebreaker falls to MAC address \u2014 meaning whichever switch happens to have the lowest MAC could become root, possibly an edge switch far from the core. Deliberately set root priority on your intended core switch instead of leaving it to chance.',
    ],
  },
  {
    id: 'portfast',
    title: 'PortFast',
    commandRef: 'spanning-tree portfast',
    body: [
      'Skips STP\u2019s Listening/Learning delay on a port, going straight to Forwarding \u2014 intended ONLY for ports connecting to end devices that will never introduce a loop. Never configure PortFast on a port connecting to another switch: doing so lets a loop become active immediately instead of being caught during STP\u2019s normal convergence.',
    ],
  },
  {
    id: 'bpduguard',
    title: 'BPDU Guard',
    commandRef: 'spanning-tree bpduguard enable',
    body: [
      'The safety net for PortFast: if a PortFast port ever receives a BPDU (meaning something that behaves like a switch got plugged in), the port is immediately put into err-disabled state. Always pair PortFast with BPDU Guard \u2014 never deploy one without the other.',
    ],
  },
]
