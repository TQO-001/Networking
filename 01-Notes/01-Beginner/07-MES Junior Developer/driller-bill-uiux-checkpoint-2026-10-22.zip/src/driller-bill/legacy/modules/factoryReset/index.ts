import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand } from './engine'
import { renderPrompt, withDoSupport } from '../../engine/shell'

export const factoryResetModule: ModuleDefinition = {
  id: 'factory-reset',
  title: 'Factory Reset & Flash Cleanup',
  summary:
    'Wipe a switch back to true factory defaults \u2014 erase NVRAM, delete the separate vlan.dat database, and reload cleanly without falling into the VTP revision trap.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
