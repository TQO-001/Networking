import type { DrillStep } from '../../types'

export const drill: DrillStep[] = [
  { command: 'enable', explanation: 'Enter privileged EXEC mode.' },
  { command: 'configure terminal', explanation: 'Enter global configuration mode.' },
  { command: 'interface range gigabitethernet0/1 - 2', explanation: 'Configure BOTH member ports identically before bundling.', theoryAnchor: 'matching-config' },
  { command: 'switchport mode trunk', explanation: 'Matching trunk config on both members.', theoryAnchor: 'matching-config' },
  { command: 'channel-group 1 mode active', explanation: 'Bundle both interfaces using LACP active mode.', theoryAnchor: 'lacp-modes' },
  { command: 'exit', explanation: 'Back to global configuration mode.' },
  { command: 'interface port-channel 1', explanation: 'Configure the resulting logical interface.' },
  { command: 'switchport mode trunk', explanation: 'Configure the Port-channel interface itself, not just the members.', theoryAnchor: 'why-etherchannel' },
  { command: 'no shutdown', explanation: 'Bring the bundle up.' },
  { command: 'exit', explanation: 'Back to global configuration mode.' },
  { command: 'port-channel load-balance src-dst-ip', explanation: 'Set the load-balancing hash algorithm.' },
  { command: 'end', explanation: 'Return to privileged EXEC mode.' },
  { command: 'copy running-config startup-config', explanation: 'Save.' },
]
