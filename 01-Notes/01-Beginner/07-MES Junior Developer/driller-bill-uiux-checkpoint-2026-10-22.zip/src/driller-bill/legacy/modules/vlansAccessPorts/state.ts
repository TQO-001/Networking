export interface VlansCustomState {
  vlans: Record<number, { name?: string }>
  ports: Record<string, { mode?: 'access'; vlan?: number; nonegotiate?: boolean; noShutdown?: boolean }>
  currentInterface: string | null
  currentInterfaceRange: string[] | null
  savedToStartup: boolean
}

export function initialVlansCustom(): VlansCustomState {
  return {
    vlans: {},
    ports: {},
    currentInterface: null,
    currentInterfaceRange: null,
    savedToStartup: false,
  }
}
