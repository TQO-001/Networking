import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'offbox-backup',
    title: 'Why Off-Device Backup Matters',
    commandRef: 'copy running-config tftp:',
    body: [
      'copy running-config startup-config only protects against a power loss \u2014 it does nothing if you make a bad change and need yesterday\u2019s config back, or if the switch itself dies and gets replaced.',
      'A config sitting only in the switch\u2019s own NVRAM isn\u2019t backed up, it\u2019s just saved. Copying it off-box (TFTP/SCP/FTP) to another machine is the actual backup.',
    ],
  },
  {
    id: 'restore-workflow',
    title: 'Restore Workflow',
    commandRef: 'copy tftp: flash:',
    body: [
      'To do a real rollback, the saved config needs to land in flash first, where configure replace can point at it \u2014 copying a backup file straight into running-config takes a different, weaker path (see Merge vs Replace).',
    ],
  },
  {
    id: 'merge-vs-replace',
    title: 'Merge vs Replace',
    commandRef: 'copy <file> running-config vs. configure replace',
    body: [
      'copy tftp: running-config only MERGES the file into running-config \u2014 it adds what\u2019s in the file but does not remove anything currently configured that isn\u2019t in it. If your backup doesn\u2019t include an interface that\u2019s currently live, that live config just stays.',
      'configure replace calculates the actual DIFF and applies both additions and removals, making running-config match the file exactly. That\u2019s the real rollback tool.',
    ],
  },
  {
    id: 'configure-replace-safety',
    title: 'Safer Rollback with a Timer',
    commandRef: 'configure replace flash:<file> time <minutes> / configure confirm',
    body: [
      'Adding "time N" to configure replace auto-reverts the change if configure confirm isn\u2019t run within N minutes \u2014 critical when you\u2019re making the change over the same SSH session you could accidentally lock yourself out of.',
      'Without the timer, a bad replace that breaks your own connectivity has no safety net.',
    ],
  },
]
