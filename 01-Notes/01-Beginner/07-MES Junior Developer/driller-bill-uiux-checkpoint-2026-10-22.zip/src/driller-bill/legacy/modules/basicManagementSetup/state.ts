// Module-specific state shape for Basic Management Setup. This is what
// lives inside EngineState.custom for this module — nothing outside this
// module folder needs to know its shape.

export interface BmsCustomState {
  domainName: string | null
  enableSecretSet: boolean
  users: Record<string, { privilege: number; secretSet: boolean }>
  rsaKeyGenerated: boolean
  sshVersion: 1 | 2 | null
  sshTimeoutSet: boolean
  sshRetriesSet: boolean
  consoleLine: { loginLocal: boolean; loggingSync: boolean; execTimeoutSet: boolean }
  vtyLine: { loginLocal: boolean; transportSsh: boolean; execTimeoutSet: boolean }
  bannerSet: boolean
  bannerDelimiter: string | null
  bannerBuffer: string[]
  vlans: Record<number, { name?: string }>
  currentInterface: string | null
  svi99: { description?: string; ipAddress?: string; noShutdown?: boolean }
  svis: Record<number, { description?: string; ipAddress?: string; noShutdown?: boolean }>
  ports: Record<string, { description?: string; vlan?: number; mode?: 'access' | 'trunk'; noShutdown?: boolean }>
  currentVlan: number | null
  defaultGateway: string | null
  passwordEncryption: boolean
  savedToStartup: boolean
}

export function initialBmsCustom(): BmsCustomState {
  return {
    domainName: null,
    enableSecretSet: false,
    users: {},
    rsaKeyGenerated: false,
    sshVersion: null,
    sshTimeoutSet: false,
    sshRetriesSet: false,
    consoleLine: { loginLocal: false, loggingSync: false, execTimeoutSet: false },
    vtyLine: { loginLocal: false, transportSsh: false, execTimeoutSet: false },
    bannerSet: false,
    bannerDelimiter: null,
    bannerBuffer: [],
    vlans: {},
    currentInterface: null,
    svi99: {},
    svis: {},
    ports: {},
    currentVlan: null,
    defaultGateway: null,
    passwordEncryption: false,
    savedToStartup: false,
  }
}
