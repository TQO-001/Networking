import type { DrillStep } from '../../types'

export const drill: DrillStep[] = [
  { command: 'confreg 0x2142', explanation: 'Set the register to skip startup-config on next boot.', theoryAnchor: 'config-register' },
  { command: 'reset', explanation: 'Reboot with the new register value \u2014 lands in privileged EXEC with no password.', theoryAnchor: 'config-register' },
  { command: 'enable', explanation: 'No password required \u2014 running-config is blank.' },
  { command: 'copy startup-config running-config', explanation: 'Restore the OLD config into memory (without restoring old passwords\u2019 protection yet).', theoryAnchor: 'recovery-flow' },
  { command: 'configure terminal', explanation: 'Enter global configuration mode to set new credentials.' },
  { command: 'enable secret NewSecurePass123!', explanation: 'Set a new privileged-mode password.' },
  { command: 'config-register 0x2102', explanation: 'Restore normal boot behavior \u2014 the step people forget.', theoryAnchor: 'restore-register' },
  { command: 'end', explanation: 'Return to privileged EXEC mode.' },
  { command: 'copy running-config startup-config', explanation: 'Save the recovered and updated config.' },
  { command: 'reload', explanation: 'Confirm everything comes up clean.' },
  { command: '', explanation: 'Confirm the reload.' },
]
