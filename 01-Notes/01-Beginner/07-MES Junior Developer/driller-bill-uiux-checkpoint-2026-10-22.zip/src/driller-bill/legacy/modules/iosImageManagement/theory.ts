import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'flash-and-boot-var',
    title: 'Flash & the Boot Variable',
    commandRef: 'dir flash: / boot system flash:<file>',
    body: [
      'Flash holds the IOS image file(s), vlan.dat, and anything else you choose to store there. Checking free space (dir flash: / show flash:) before copying a new image in avoids an interrupted transfer leaving a corrupted partial file.',
      'The boot system command tells the bootloader which image to load if flash has more than one. Without it, the switch just loads whichever valid image it finds first \u2014 not necessarily the one you just spent time copying in.',
    ],
  },
  {
    id: 'tftp-transfer',
    title: 'TFTP Transfer',
    commandRef: 'copy tftp: flash:',
    body: [
      'TFTP has no authentication and is unencrypted \u2014 fine for a controlled internal transfer on a management network, which is exactly why it should never be exposed anywhere else.',
      'The transfer needs the switch to already be able to reach the TFTP server\u2019s IP \u2014 that\u2019s why pinging it first is worth doing before you\u2019re halfway through a copy that then times out.',
    ],
  },
  {
    id: 'space-cleanup',
    title: 'Freeing Up Space',
    commandRef: 'delete flash:<old-image>',
    body: [
      'Before copying a new image in, check free space and delete an old/unused one if it\u2019s tight. An interrupted copy due to insufficient space can leave a partially-written, unbootable image file \u2014 which is why this happens BEFORE the copy, not as cleanup after a failure.',
    ],
  },
  {
    id: 'verify-image',
    title: 'Verifying the Copy',
    commandRef: 'verify flash:<filename>',
    body: [
      'A checksum check on the file that just landed in flash, confirming the transfer completed correctly before you reload into it. Skipping this and reloading straight into an unverified image is how you end up needing the password/config recovery procedure again \u2014 except this time possibly with no working IOS image at all.',
    ],
  },
  {
    id: 'save-prompt-context',
    title: 'The Save Prompt \u2014 Context Matters',
    commandRef: 'copy running-config startup-config / reload',
    body: [
      'Unlike the factory-reset drill (where answering "yes" to a reload save prompt is a trap that undoes an erase), here a boot system change sitting only in running-config is exactly the kind of thing you DO want saved \u2014 losing it means the switch reloads without ever finding out you wanted it to boot the new image.',
      'The lesson isn\u2019t "always answer yes" or "always answer no" \u2014 it\u2019s understanding what\u2019s actually in running-config that hasn\u2019t been saved yet before you answer either way.',
    ],
  },
]
