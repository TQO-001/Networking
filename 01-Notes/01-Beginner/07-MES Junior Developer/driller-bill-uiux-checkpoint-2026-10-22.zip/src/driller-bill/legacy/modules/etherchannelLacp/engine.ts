import type { CommandResult, EngineState, Objective } from '../../types'
import { INCOMPLETE_COMMAND, INVALID_INPUT, expandInterfaceRange, normalizeInterfaceName, popMode, resolveWord } from '../../engine/shell'
import { initialEtherchannelCustom, type EtherchannelCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialEtherchannelCustom(),
  }
}

function c(state: EngineState): EtherchannelCustomState {
  return state.custom as EtherchannelCustomState
}
function withCustom(state: EngineState, patch: Partial<EtherchannelCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}
function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}
function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}

function activeInterfaces(cs: EtherchannelCustomState): string[] {
  if (cs.currentInterfaceRange) return cs.currentInterfaceRange
  if (cs.currentInterface) return [cs.currentInterface]
  return []
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()
  if (trimmed === '') return ok(state, [])
  const tokens = trimmed.split(/\s+/)
  const first = tokens[0].toLowerCase()
  const cs = c(state)

  if (first === 'end') return ok({ ...state, mode: 'privileged', awaitingInput: null }, [])
  if (resolveWord(first, ['exit']) === 'exit') {
    if (state.mode === 'user') return ok(state, [])
    if (state.mode === 'privileged') return ok({ ...state, mode: 'user' }, [])
    return ok(withCustom({ ...state, mode: popMode(state.mode) }, { currentInterface: null, currentInterfaceRange: null }), [])
  }
  if (first === '?') return ok(state, [helpFor(state)])

  if (state.mode === 'user') {
    if (resolveWord(first, ['enable']) === 'enable') return ok({ ...state, mode: 'privileged' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in user EXEC mode. Try "enable".`)
  }

  if (state.mode === 'privileged') {
    const word = resolveWord(first, ['configure', 'copy', 'disable'])
    if (word === 'configure') {
      if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure needs an argument.')
      if (resolveWord(tokens[1], ['terminal']) === 'terminal') return ok({ ...state, mode: 'global' }, ['Enter configuration commands, one per line.  End with CNTL/Z.'])
      return errFail(state, [INVALID_INPUT], 'syntax', 'Only "configure terminal" is supported.')
    }
    if (word === 'copy') {
      const rest = tokens.slice(1).join(' ').toLowerCase()
      if (rest === 'running-config startup-config') return ok(withCustom(state, { savedToStartup: true }), ['Building configuration...', '[OK]'], 'saved-config')
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "copy running-config startup-config".')
    }
    if (word === 'disable') return ok({ ...state, mode: 'user' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set.`)
  }

  if (state.mode === 'global') {
    const word = resolveWord(first, ['interface', 'port-channel'])
    if (word === 'interface') {
      const rest = tokens.slice(1)
      if (resolveWord(rest[0] ?? '', ['range']) === 'range') {
        const list = expandInterfaceRange(rest.slice(1))
        if (!list || !list.every((i) => i === 'gigabitethernet0/1' || i === 'gigabitethernet0/2')) {
          return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "interface range gigabitethernet0/1 - 2".')
        }
        return ok(withCustom({ ...state, mode: 'interfaceRange' }, { currentInterfaceRange: list, currentInterface: null }), [])
      }
      const iface = normalizeInterfaceName(rest.join(''))
      if (iface === 'port-channel1') return ok(withCustom({ ...state, mode: 'interface' }, { currentInterface: iface, currentInterfaceRange: null }), [])
      if (iface !== 'gigabitethernet0/1' && iface !== 'gigabitethernet0/2') {
        return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates gigabitethernet0/1, gigabitethernet0/2, and port-channel1.')
      }
      return ok(withCustom({ ...state, mode: 'interface' }, { currentInterface: iface, currentInterfaceRange: null }), [])
    }
    if (word === 'port-channel') {
      const sub = resolveWord(tokens[1] ?? '', ['load-balance'])
      if (sub === 'load-balance') {
        if (!tokens[2]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'port-channel load-balance needs an algorithm, e.g. "src-dst-ip".')
        return ok(withCustom(state, { loadBalanceSet: true }), [], 'set-load-balance')
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "port-channel load-balance <algorithm>".')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in global configuration mode.`)
  }

  if (state.mode === 'interface' || state.mode === 'interfaceRange') {
    const ifaces = activeInterfaces(cs)
    const onPortChannel = ifaces.length === 1 && ifaces[0] === 'port-channel1'
    const word = resolveWord(first, ['switchport', 'channel-group', 'no'])

    if (word === 'switchport') {
      const sub = resolveWord(tokens[1] ?? '', ['mode'])
      if (sub === 'mode' && resolveWord(tokens[2] ?? '', ['trunk']) === 'trunk') {
        if (onPortChannel) return ok(withCustom(state, { portChannelTrunkConfigured: true }), [], 'configured-portchannel')
        const memberTrunkConfigured = { ...cs.memberTrunkConfigured }
        ifaces.forEach((i) => { memberTrunkConfigured[i] = true })
        const next = withCustom(state, { memberTrunkConfigured })
        const completed = memberTrunkConfigured['gigabitethernet0/1'] && memberTrunkConfigured['gigabitethernet0/2'] ? 'configured-members' : undefined
        return ok(next, [], completed)
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer only simulates "switchport mode trunk".')
    }

    if (word === 'channel-group') {
      if (onPortChannel) return errFail(state, [INVALID_INPUT], 'wrong-mode', 'channel-group is configured on the physical member interfaces, not the Port-channel interface itself.')
      const id = Number(tokens[1])
      if (!Number.isInteger(id)) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'channel-group needs a group number, e.g. "channel-group 1 mode active".')
      const modeWord = resolveWord(tokens[2] ?? '', ['mode'])
      const activePassive = resolveWord(tokens[3] ?? '', ['active', 'passive'])
      if (modeWord !== 'mode' || (activePassive !== 'active' && activePassive !== 'passive')) {
        return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "channel-group <id> mode active" (or passive).')
      }
      if (activePassive === 'passive' && cs.channelGroupMode !== 'active') {
        // both sides passive would never form in reality; nudge without hard-blocking
        return errFail(
          withCustom(state, { channelGroupId: id, channelGroupMode: 'passive', bundledMembers: [...new Set([...cs.bundledMembers, ...ifaces])] }),
          ['(bundled locally, but two "passive" ends never actually negotiate LACP in reality)'],
          'wrong-order',
          'At least one side of an LACP bundle must be "active" \u2014 two passive ends never negotiate.',
          'bundled-active',
          'lacp-modes',
        )
      }
      const bundledMembers = [...new Set([...cs.bundledMembers, ...ifaces])]
      const next = withCustom(state, { channelGroupId: id, channelGroupMode: 'active', bundledMembers })
      const completed = bundledMembers.includes('gigabitethernet0/1') && bundledMembers.includes('gigabitethernet0/2') ? 'bundled-active' : undefined
      return ok(next, [], completed)
    }

    if (word === 'no') {
      if (resolveWord(tokens[1] ?? '', ['shutdown']) === 'shutdown') return ok(state, [])
      return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "no shutdown".')
    }

    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s interface command set.`)
  }

  return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized shell state.')
}

function helpFor(state: EngineState): string {
  if (state.mode === 'user') return 'enable'
  if (state.mode === 'global') return 'interface range gigabitethernet0/1 - 2, interface port-channel 1, port-channel load-balance <algorithm>, end, exit'
  if (state.mode === 'interface' || state.mode === 'interfaceRange') return 'switchport mode trunk, channel-group <id> mode active, no shutdown, exit'
  return 'configure terminal, copy running-config startup-config'
}
