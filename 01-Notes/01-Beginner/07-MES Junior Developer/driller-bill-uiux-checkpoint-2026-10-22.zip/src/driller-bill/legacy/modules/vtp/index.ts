import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand } from './engine'
import { renderPrompt, withDoSupport } from '../../engine/shell'

export const vtpModule: ModuleDefinition = {
  id: 'vtp',
  title: 'VTP & the Revision Number Trap',
  summary: 'Understand VTP modes and the revision-number hazard, then apply the safer default: transparent mode with locally-configured VLANs.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
