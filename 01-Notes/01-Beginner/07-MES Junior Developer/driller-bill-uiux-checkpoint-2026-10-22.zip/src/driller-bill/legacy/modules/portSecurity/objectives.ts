import type { EngineState, Objective } from '../../types'
import type { PortSecurityCustomState } from './state'

function c(state: EngineState): PortSecurityCustomState {
  return state.custom as PortSecurityCustomState
}

export const objectives: Objective[] = [
  {
    id: 'set-access-mode',
    label: 'Set the port to access mode and assign VLAN 10',
    description: 'Port security requires an access port.',
    theoryAnchor: 'port-security-basics',
    check: (s) => c(s).accessMode && c(s).accessVlan === 10,
  },
  {
    id: 'enabled-port-security',
    label: 'Enable port security',
    description: 'switchport port-security \u2014 nothing else works without this.',
    theoryAnchor: 'port-security-basics',
    check: (s) => c(s).portSecurityEnabled,
  },
  {
    id: 'set-maximum',
    label: 'Set the maximum secure MAC count',
    description: 'switchport port-security maximum 2.',
    theoryAnchor: 'port-security-basics',
    check: (s) => c(s).maximum === 2,
  },
  {
    id: 'enabled-sticky',
    label: 'Enable sticky learning',
    description: 'switchport port-security mac-address sticky.',
    theoryAnchor: 'sticky-learning',
    check: (s) => c(s).stickyEnabled,
  },
  {
    id: 'set-violation-restrict',
    label: 'Set violation mode to restrict',
    description: 'Log without taking the port down.',
    theoryAnchor: 'violation-modes',
    check: (s) => c(s).violationMode === 'restrict',
  },
  {
    id: 'configured-auto-recovery',
    label: 'Configure err-disable auto-recovery',
    description: 'Cause + interval, globally.',
    theoryAnchor: 'violation-modes',
    check: (s) => c(s).configuredAutoRecovery,
  },
  {
    id: 'saved-config',
    label: 'Save the configuration',
    description: 'copy running-config startup-config.',
    theoryAnchor: 'port-security-basics',
    check: (s) => c(s).savedToStartup,
  },
]
