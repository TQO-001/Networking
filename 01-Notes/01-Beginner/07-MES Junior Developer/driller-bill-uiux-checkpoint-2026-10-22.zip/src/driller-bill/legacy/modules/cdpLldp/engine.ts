import type { CommandResult, EngineState, Objective } from '../../types'
import { INCOMPLETE_COMMAND, INVALID_INPUT, normalizeInterfaceName, popMode, resolveWord } from '../../engine/shell'
import { initialCdpLldpCustom, type CdpLldpCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialCdpLldpCustom(),
  }
}

function c(state: EngineState): CdpLldpCustomState {
  return state.custom as CdpLldpCustomState
}
function withCustom(state: EngineState, patch: Partial<CdpLldpCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}
function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}
function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()
  if (trimmed === '') return ok(state, [])
  const tokens = trimmed.split(/\s+/)
  const first = tokens[0].toLowerCase()
  const cs = c(state)

  if (first === 'end') return ok({ ...state, mode: 'privileged', awaitingInput: null }, [])
  if (resolveWord(first, ['exit']) === 'exit') {
    if (state.mode === 'user') return ok(state, [])
    if (state.mode === 'privileged') return ok({ ...state, mode: 'user' }, [])
    return ok({ ...state, mode: popMode(state.mode) }, [])
  }
  if (first === '?') return ok(state, [helpFor(state)])

  if (state.mode === 'user') {
    if (resolveWord(first, ['enable']) === 'enable') return ok({ ...state, mode: 'privileged' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in user EXEC mode. Try "enable".`)
  }

  if (state.mode === 'privileged') {
    const word = resolveWord(first, ['show', 'configure', 'copy', 'disable'])
    if (word === 'show') {
      const target = tokens.slice(1).join(' ').toLowerCase()
      if (target === 'cdp neighbors') {
        return ok(withCustom(state, { checkedCdpNeighbors: true }), [
          'Capability Codes: R - Router, T - Trans Bridge, S - Switch',
          'Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID',
          'DIST-SW1         Gig 0/1           178             S      WS-C3560  Gig 0/24',
          'RTR-CORE         Fas 0/24          161            R S      CISCO2911 Gig 0/0',
        ], 'checked-cdp-neighbors')
      }
      if (target === 'cdp neighbors detail') {
        return ok(withCustom(state, { checkedCdpDetail: true }), [
          'Device ID: DIST-SW1',
          'Entry address(es): IP address: 192.168.99.5',
          'Platform: cisco WS-C3560,  Capabilities: Switch',
          'Interface: GigabitEthernet0/1,  Port ID (outgoing port): GigabitEthernet0/24',
          'Version: Cisco IOS Software, C3560 Software',
        ], 'checked-cdp-detail')
      }
      if (target === 'lldp neighbors') {
        if (!cs.lldpEnabled) return errFail(state, ['% LLDP is not enabled.'], 'wrong-order', 'Run "lldp run" globally first.', 'checked-lldp-neighbors', 'lldp-basics')
        return ok(withCustom(state, { checkedLldpNeighbors: true }), [
          'Local Intf     Chassis ID          Port ID           System Name',
          'Fa0/23         00:1a:2b:cc:dd:ee   eth0              phone-reception',
        ], 'checked-lldp-neighbors')
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "show cdp neighbors", "show cdp neighbors detail", and "show lldp neighbors".')
    }
    if (word === 'configure') {
      if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure needs an argument.')
      if (resolveWord(tokens[1], ['terminal']) === 'terminal') return ok({ ...state, mode: 'global' }, ['Enter configuration commands, one per line.  End with CNTL/Z.'])
      return errFail(state, [INVALID_INPUT], 'syntax', 'Only "configure terminal" is supported.')
    }
    if (word === 'copy') {
      const rest = tokens.slice(1).join(' ').toLowerCase()
      if (rest === 'running-config startup-config') return ok(withCustom(state, { savedToStartup: true }), ['Building configuration...', '[OK]'], 'saved-config')
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "copy running-config startup-config".')
    }
    if (word === 'disable') return ok({ ...state, mode: 'user' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set.`)
  }

  if (state.mode === 'global') {
    const word = resolveWord(first, ['lldp', 'interface'])
    if (word === 'lldp') {
      if (resolveWord(tokens[1] ?? '', ['run']) === 'run') return ok(withCustom(state, { lldpEnabled: true }), [], 'enabled-lldp')
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer only simulates "lldp run".')
    }
    if (word === 'interface') {
      const iface = normalizeInterfaceName(tokens.slice(1).join(''))
      if (iface !== 'fastethernet0/24') return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "interface fastethernet0/24".')
      return ok(withCustom({ ...state, mode: 'interface' }, { currentInterface: iface }), [])
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in global configuration mode.`)
  }

  if (state.mode === 'interface') {
    if (resolveWord(first, ['no']) === 'no') {
      const sub = resolveWord(tokens[1] ?? '', ['cdp'])
      if (sub === 'cdp' && resolveWord(tokens[2] ?? '', ['enable']) === 'enable') {
        return ok(withCustom(state, { cdpDisabledOnUntrustedPort: true }), [], 'disabled-cdp-untrusted')
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "no cdp enable".')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s interface command set.`)
  }

  return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized shell state.')
}

function helpFor(state: EngineState): string {
  if (state.mode === 'user') return 'enable'
  if (state.mode === 'global') return 'lldp run, interface fastethernet0/24, end, exit'
  if (state.mode === 'interface') return 'no cdp enable, exit'
  return 'show cdp neighbors [detail], show lldp neighbors, configure terminal, copy running-config startup-config'
}
