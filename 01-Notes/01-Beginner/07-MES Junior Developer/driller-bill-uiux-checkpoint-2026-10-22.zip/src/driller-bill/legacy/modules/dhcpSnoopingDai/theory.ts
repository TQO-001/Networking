import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'dhcp-snooping-basics',
    title: 'DHCP Snooping',
    commandRef: 'ip dhcp snooping / ip dhcp snooping vlan <ids>',
    body: [
      'Classifies each port as trusted (allowed to send DHCP server responses \u2014 only the port facing your real DHCP server) or untrusted (default for every other port \u2014 DHCP responses arriving here get dropped). A rogue DHCP server plugged into a normal access port simply can\u2019t get its offers through.',
      'Builds a binding table (IP-to-MAC-to-port) from legitimate transactions on trusted ports \u2014 this table is what Dynamic ARP Inspection checks against next.',
    ],
  },
  {
    id: 'trust-and-order',
    title: 'Trust the Uplink, and Order Matters',
    commandRef: 'ip dhcp snooping trust',
    body: [
      'Forgetting to trust the port facing your real DHCP server drops the legitimate server\u2019s own offers too \u2014 looks exactly like "DHCP stopped working," not just "rogue servers are blocked."',
      'DAI depends on the DHCP snooping binding table, so DHCP snooping must be enabled and working FIRST \u2014 enabling DAI before that just breaks normal ARP traffic instead of catching attacks.',
    ],
  },
  {
    id: 'dai-basics',
    title: 'Dynamic ARP Inspection',
    commandRef: 'ip arp inspection vlan <ids> / ip arp inspection trust',
    body: [
      'Checks ARP packets on untrusted ports against the DHCP snooping binding table \u2014 an ARP claiming an IP-to-MAC mapping that doesn\u2019t match what was actually leased gets dropped. This is what stops a classic ARP-spoofing man-in-the-middle attack.',
    ],
  },
]
