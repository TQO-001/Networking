import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'config-register',
    title: 'The Config-Register',
    commandRef: 'confreg 0x2142 / config-register 0x2102',
    body: [
      '0x2102 is normal boot: load IOS from flash, load startup-config from NVRAM. 0x2142 tells the bootloader to IGNORE startup-config on boot \u2014 it isn\u2019t erased, just skipped, which is exactly what lets you in without the password.',
      'ROMMON is a separate, minimal bootloader CLI you drop into by interrupting the normal boot \u2014 not IOS, and it only understands a handful of its own commands like confreg and reset.',
    ],
  },
  {
    id: 'recovery-flow',
    title: 'The Recovery Flow',
    commandRef: 'copy startup-config running-config',
    body: [
      'After the register-bypassed reboot you land in privileged EXEC with no password prompt and a blank running-config \u2014 but startup-config is still sitting untouched in NVRAM. Copying it into running-config restores your old VLANs, interfaces, and hostname into memory.',
      'Watch the direction: copy SOURCE DESTINATION. copy startup-config running-config and copy running-config startup-config are opposite operations \u2014 mixing them up here overwrites the very config you\u2019re trying to save.',
    ],
  },
  {
    id: 'restore-register',
    title: 'Restoring the Register \u2014 Don\u2019t Skip This',
    commandRef: 'config-register 0x2102',
    body: [
      'This is the step people forget. Skip it and the switch ignores startup-config on every future reboot forever \u2014 which looks exactly like a switch that "won\u2019t keep its configuration," a classic hours-long troubleshooting trap that\u2019s really just an unset register.',
    ],
  },
]
