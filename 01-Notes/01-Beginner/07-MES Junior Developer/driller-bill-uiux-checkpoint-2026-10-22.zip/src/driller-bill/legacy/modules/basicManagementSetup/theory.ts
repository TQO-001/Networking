import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'hostname-domain',
    title: 'Hostname & Domain Name',
    commandRef: 'hostname <name> / ip domain-name <domain>',
    body: [
      'The hostname is more than cosmetic: it becomes part of the CLI prompt (so you always know which box you\u2019re on), and it feeds directly into SSH key generation later.',
      'The domain name has one real job in this drill: combined with the hostname, it forms the identity IOS uses to name the RSA key pair (e.g. SW-01.laughtale.local). Skip this step and key generation will refuse to run correctly.',
    ],
  },
  {
    id: 'enable-secret',
    title: 'Enable Secret',
    commandRef: 'enable secret <password>',
    body: [
      'Controls privileged EXEC (level 15) access. Stored as a one-way hash in the config, unlike the older enable password which stores plaintext.',
      'Always use enable secret, never enable password \u2014 and never configure both, since it just leaves a weaker plaintext password sitting in the file for no benefit.',
    ],
  },
  {
    id: 'local-auth',
    title: 'Local User Authentication',
    commandRef: 'username <name> privilege 15 secret <password>',
    body: [
      'A line password (line vty ... login) is one shared secret for anyone who has it \u2014 no accountability, no per-user identity.',
      'A local username/secret pair, checked via login local, ties every login to an identifiable account and is what most SSH clients (like PuTTY) actually expect when they prompt for a username.',
    ],
  },
  {
    id: 'rsa-keys',
    title: 'RSA Key Generation',
    commandRef: 'crypto key generate rsa',
    body: [
      'SSH cannot function without an RSA key pair \u2014 generating one is literally what turns the SSH server on.',
      'IOS names the key using hostname.domain-name, which is exactly why hostname and ip domain-name must be configured first. Skip either and this command fails or produces an unusable key.',
      'A 2048-bit modulus is the modern minimum for a reasonably secure key.',
    ],
  },
  {
    id: 'ssh-hardening',
    title: 'SSH Version & Timeouts',
    commandRef: 'ip ssh version 2 / ip ssh time-out / ip ssh authentication-retries',
    body: [
      'SSH version 1 has known vulnerabilities. Explicitly forcing version 2 removes any ambiguity about what a client is allowed to negotiate.',
      'Timeout and retry limits reduce the window an attacker has to brute-force or hang open a connection attempt.',
    ],
  },
  {
    id: 'line-security',
    title: 'Console & VTY Line Security',
    commandRef: 'line console 0 / line vty 0 15',
    body: [
      'The console line is physical, local access \u2014 still worth securing, since anyone with a cable and five minutes alone with the switch otherwise walks straight in.',
      'The vty lines are the 16 virtual terminals used for remote Telnet/SSH access. transport input ssh is what actually blocks Telnet \u2014 without it, a switch with only a password configured is still reachable over cleartext Telnet.',
      'login local (not just login) is what makes the username database in the previous step actually matter for these lines.',
    ],
  },
  {
    id: 'banner',
    title: 'Legal Warning Banner',
    commandRef: 'banner motd # ... #',
    body: [
      'Not a technical control \u2014 a legal one. Courts have repeatedly relied on a login banner to support prosecuting unauthorized access. A friendly "Welcome" banner is a real liability by contrast.',
    ],
  },
  {
    id: 'mgmt-vlan-svi',
    title: 'Management VLAN & SVI',
    commandRef: 'vlan 99 / interface vlan 99',
    body: [
      'A Layer 2 switch has no IP address of its own until you give a VLAN interface (SVI) one. Best practice uses a dedicated management VLAN (not VLAN 1) so management traffic is isolated from user data.',
      'The SVI is a logical, CPU-owned interface \u2014 it does not forward traffic between VLANs by itself; it just gives this VLAN\u2019s broadcast domain an IP presence for management.',
    ],
  },
  {
    id: 'default-gateway',
    title: 'Default Gateway',
    commandRef: 'ip default-gateway <ip>',
    body: [
      'On a pure Layer 2 switch, this tells the switch\u2019s own management traffic (not user traffic) where to send anything destined off-subnet \u2014 essential for reaching this switch from outside its local subnet.',
      'On a multilayer switch with ip routing enabled, this is replaced by a real static or dynamic route instead.',
    ],
  },
  {
    id: 'password-encryption',
    title: 'Password Encryption',
    commandRef: 'service password-encryption',
    body: [
      'Encrypts (weakly \u2014 type 7, reversible) any remaining plaintext passwords sitting in the config, mainly line passwords. It is not a substitute for enable secret\u2019s stronger hashing, just cleanup for what\u2019s left.',
    ],
  },
  {
    id: 'save-config',
    title: 'Saving the Configuration',
    commandRef: 'copy running-config startup-config',
    body: [
      'Everything you type modifies running-config immediately and lives only in RAM. Nothing survives a reload until you copy it into startup-config (NVRAM).',
    ],
  },
]
