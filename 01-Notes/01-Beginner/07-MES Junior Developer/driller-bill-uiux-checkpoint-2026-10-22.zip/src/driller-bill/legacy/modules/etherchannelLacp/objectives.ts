import type { EngineState, Objective } from '../../types'
import type { EtherchannelCustomState } from './state'

function c(state: EngineState): EtherchannelCustomState {
  return state.custom as EtherchannelCustomState
}

export const objectives: Objective[] = [
  {
    id: 'configured-members',
    label: 'Configure both member ports identically',
    description: 'Trunk mode on gi0/1 and gi0/2 before bundling.',
    theoryAnchor: 'matching-config',
    check: (s) => c(s).memberTrunkConfigured['gigabitethernet0/1'] && c(s).memberTrunkConfigured['gigabitethernet0/2'],
  },
  {
    id: 'bundled-active',
    label: 'Bundle with LACP active mode',
    description: 'channel-group 1 mode active on both members.',
    theoryAnchor: 'lacp-modes',
    check: (s) => c(s).channelGroupMode === 'active' && c(s).bundledMembers.includes('gigabitethernet0/1') && c(s).bundledMembers.includes('gigabitethernet0/2'),
  },
  {
    id: 'configured-portchannel',
    label: 'Configure the Port-channel interface',
    description: 'The logical interface needs its own config too.',
    theoryAnchor: 'why-etherchannel',
    check: (s) => c(s).portChannelTrunkConfigured,
  },
  {
    id: 'set-load-balance',
    label: 'Set the load-balancing algorithm',
    description: 'port-channel load-balance src-dst-ip.',
    theoryAnchor: 'why-etherchannel',
    check: (s) => c(s).loadBalanceSet,
  },
  {
    id: 'saved-config',
    label: 'Save the configuration',
    description: 'copy running-config startup-config.',
    theoryAnchor: 'why-etherchannel',
    check: (s) => c(s).savedToStartup,
  },
]
