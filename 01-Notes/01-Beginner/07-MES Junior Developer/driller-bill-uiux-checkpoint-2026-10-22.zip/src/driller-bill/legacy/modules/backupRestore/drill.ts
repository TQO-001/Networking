import type { DrillStep } from '../../types'

export const drill: DrillStep[] = [
  { command: 'enable', explanation: 'Enter privileged EXEC mode.' },
  { command: 'copy running-config tftp:', explanation: 'Back up the current config off-box.', theoryAnchor: 'offbox-backup' },
  { command: '192.168.99.50', explanation: 'Address of the TFTP server.', theoryAnchor: 'offbox-backup' },
  { command: 'SW-01-2026-08-20.cfg', explanation: 'Destination filename \u2014 always name backups with date and switch identity.', theoryAnchor: 'offbox-backup' },
  { command: 'copy tftp: flash:', explanation: 'Copy that same backup into flash \u2014 configure replace needs it there.', theoryAnchor: 'restore-workflow' },
  { command: '192.168.99.50', explanation: 'Address of the TFTP server.', theoryAnchor: 'restore-workflow' },
  { command: 'SW-01-2026-08-20.cfg', explanation: 'Source filename on the TFTP server.', theoryAnchor: 'restore-workflow' },
  { command: '', explanation: 'Accept the default destination filename.', theoryAnchor: 'restore-workflow' },
  { command: 'configure replace flash:SW-01-2026-08-20.cfg time 5', explanation: 'Roll back to this exact config \u2014 with a 5-minute auto-revert safety net.', theoryAnchor: 'merge-vs-replace' },
  { command: '', explanation: 'Confirm the replace operation.', theoryAnchor: 'configure-replace-safety' },
  { command: 'configure confirm', explanation: 'Confirm the change is good \u2014 this cancels the pending auto-revert.', theoryAnchor: 'configure-replace-safety' },
  { command: 'copy running-config startup-config', explanation: 'Save the now-restored config so it survives a reload.' },
]
