export interface VtpCustomState {
  vtpMode: 'server' | 'client' | 'transparent' | null
  vlans: Record<number, { name?: string }>
  checkedStatus: boolean
  savedToStartup: boolean
}

export function initialVtpCustom(): VtpCustomState {
  return {
    vtpMode: null,
    vlans: {},
    checkedStatus: false,
    savedToStartup: false,
  }
}
