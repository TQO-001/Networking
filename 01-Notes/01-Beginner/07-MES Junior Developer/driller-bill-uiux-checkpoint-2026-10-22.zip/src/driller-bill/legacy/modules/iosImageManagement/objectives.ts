import type { EngineState, Objective } from '../../types'
import type { IosImageCustomState } from './state'

function c(state: EngineState): IosImageCustomState {
  return state.custom as IosImageCustomState
}

export const objectives: Objective[] = [
  {
    id: 'checked-flash',
    label: 'Check flash contents before making changes',
    description: 'Run "dir flash:" (or "show flash:") to see current contents and free space.',
    theoryAnchor: 'flash-and-boot-var',
    check: (s) => c(s).flashChecked,
  },
  {
    id: 'confirmed-reachability',
    label: 'Confirm TFTP server reachability',
    description: 'Ping the TFTP server before starting a transfer.',
    theoryAnchor: 'tftp-transfer',
    check: (s) => c(s).pingedServer,
  },
  {
    id: 'freed-space',
    label: 'Delete the old image to free space',
    description: 'Remove the unused image before copying a new one in.',
    theoryAnchor: 'space-cleanup',
    check: (s) => c(s).oldImageDeleted,
  },
  {
    id: 'copied-image',
    label: 'Copy the new image via TFTP',
    description: 'Successfully transfer the new IOS image into flash.',
    theoryAnchor: 'tftp-transfer',
    check: (s) => c(s).newImageCopied,
  },
  {
    id: 'verified-image',
    label: 'Verify the copied image',
    description: 'Checksum-verify the file before trusting it.',
    theoryAnchor: 'verify-image',
    check: (s) => c(s).verified,
  },
  {
    id: 'set-boot-system',
    label: 'Set the boot variable',
    description: 'Point boot system at the new image so it actually loads on reload.',
    theoryAnchor: 'flash-and-boot-var',
    check: (s) => !!c(s).bootSystemSet,
  },
  {
    id: 'saved-config',
    label: 'Save the configuration',
    description: 'The boot system change needs to be saved to startup-config.',
    theoryAnchor: 'save-prompt-context',
    check: (s) => c(s).savedToStartup,
  },
  {
    id: 'reloaded',
    label: 'Reload into the new image',
    description: 'Complete the reload to actually boot the new image.',
    theoryAnchor: 'save-prompt-context',
    check: (s) => c(s).reloaded,
  },
]
