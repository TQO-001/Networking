import type { CommandResult, EngineState, Objective } from '../../types'
import { INCOMPLETE_COMMAND, INVALID_INPUT, popMode, resolveWord } from '../../engine/shell'
import { initialVtpCustom, type VtpCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialVtpCustom(),
  }
}

function c(state: EngineState): VtpCustomState {
  return state.custom as VtpCustomState
}
function withCustom(state: EngineState, patch: Partial<VtpCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}
function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}
function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()
  if (trimmed === '') return ok(state, [])
  const tokens = trimmed.split(/\s+/)
  const first = tokens[0].toLowerCase()
  const cs = c(state)

  if (first === 'end') return ok({ ...state, mode: 'privileged', awaitingInput: null }, [])
  if (resolveWord(first, ['exit']) === 'exit') {
    if (state.mode === 'user') return ok(state, [])
    if (state.mode === 'privileged') return ok({ ...state, mode: 'user' }, [])
    return ok({ ...state, mode: popMode(state.mode) }, [])
  }
  if (first === '?') return ok(state, [helpFor(state)])

  if (state.mode === 'user') {
    if (resolveWord(first, ['enable']) === 'enable') return ok({ ...state, mode: 'privileged' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in user EXEC mode. Try "enable".`)
  }

  if (state.mode === 'privileged') {
    const word = resolveWord(first, ['configure', 'show', 'copy', 'disable'])
    if (word === 'configure') {
      if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure needs an argument.')
      if (resolveWord(tokens[1], ['terminal']) === 'terminal') return ok({ ...state, mode: 'global' }, ['Enter configuration commands, one per line.  End with CNTL/Z.'])
      return errFail(state, [INVALID_INPUT], 'syntax', 'Only "configure terminal" is supported.')
    }
    if (word === 'show') {
      const target = tokens.slice(1).join(' ').toLowerCase()
      if (target === 'vtp status') {
        const next = withCustom(state, { checkedStatus: true })
        return ok(next, [
          `VTP Operating Mode          : ${cs.vtpMode ? cs.vtpMode[0].toUpperCase() + cs.vtpMode.slice(1) : 'Server'}`,
          `Configuration Revision      : ${cs.vtpMode === 'transparent' ? '0' : '0'}`,
          `Maximum VLANs supported     : 1005`,
          `Number of existing VLANs    : ${Object.keys(cs.vlans).length + 5}`,
        ], 'checked-vtp-status')
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "show vtp status".')
    }
    if (word === 'copy') {
      const rest = tokens.slice(1).join(' ').toLowerCase()
      if (rest === 'running-config startup-config') return ok(withCustom(state, { savedToStartup: true }), ['Building configuration...', '[OK]'], 'saved-config')
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "copy running-config startup-config".')
    }
    if (word === 'disable') return ok({ ...state, mode: 'user' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set.`)
  }

  if (state.mode === 'global') {
    const word = resolveWord(first, ['vtp', 'vlan'])
    if (word === 'vtp') {
      const sub = resolveWord(tokens[1] ?? '', ['mode', 'domain', 'password'])
      if (sub === 'mode') {
        const m = resolveWord(tokens[2] ?? '', ['server', 'client', 'transparent'])
        if (m !== 'server' && m !== 'client' && m !== 'transparent') return errFail(state, [INVALID_INPUT], 'syntax', 'Expected server, client, or transparent.')
        return ok(withCustom(state, { vtpMode: m }), [], m === 'transparent' ? 'set-transparent-mode' : undefined)
      }
      if (sub === 'domain' || sub === 'password') {
        if (!tokens[2]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', `vtp ${sub} needs an argument.`)
        return ok(state, [])
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "vtp mode <mode>", "vtp domain <name>", or "vtp password <pass>".')
    }
    if (word === 'vlan') {
      const id = Number(tokens[1])
      if (!Number.isInteger(id)) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'vlan needs a numeric ID.')
      const vlans = { ...cs.vlans, [id]: cs.vlans[id] ?? {} }
      return ok(withCustom({ ...state, mode: 'vlanConfig' }, { vlans }), [])
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in global configuration mode.`)
  }

  if (state.mode === 'vlanConfig') {
    if (resolveWord(first, ['name']) === 'name') {
      const name = tokens.slice(1).join(' ')
      if (!name) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'name needs a VLAN name.')
      const vlanId = Object.keys(cs.vlans).map(Number).find((id) => !cs.vlans[id].name)
      if (vlanId === undefined) return errFail(state, [INVALID_INPUT], 'wrong-mode', 'No pending VLAN to name.')
      const vlans = { ...cs.vlans, [vlanId]: { name } }
      return ok(withCustom(state, { vlans }), [], vlanId === 10 ? 'created-named-vlan' : undefined)
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'Try "name <text>".')
  }

  return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized shell state.')
}

function helpFor(state: EngineState): string {
  if (state.mode === 'user') return 'enable'
  if (state.mode === 'global') return 'vtp mode <server|client|transparent>, vlan <id>, end, exit'
  if (state.mode === 'vlanConfig') return 'name <text>, exit'
  return 'configure terminal, show vtp status, copy running-config startup-config'
}
