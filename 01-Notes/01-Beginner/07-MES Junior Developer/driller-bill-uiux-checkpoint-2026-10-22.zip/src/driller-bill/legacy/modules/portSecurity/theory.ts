import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'port-security-basics',
    title: 'Port Security Fundamentals',
    commandRef: 'switchport port-security',
    body: [
      'Restricts which MAC addresses can talk through an access port \u2014 defends against MAC flooding attacks and rogue devices plugged into wall jacks. It must be explicitly enabled per interface; setting a maximum alone does nothing without this.',
    ],
  },
  {
    id: 'sticky-learning',
    title: 'Sticky Learning',
    commandRef: 'switchport port-security mac-address sticky',
    body: [
      'Dynamically learned MACs are automatically converted into running-config entries \u2014 combining the convenience of dynamic learning with the persistence of a static entry once saved to startup-config.',
    ],
  },
  {
    id: 'violation-modes',
    title: 'Violation Modes',
    commandRef: 'switchport port-security violation <mode>',
    body: [
      'protect: silently drops offending traffic. restrict: drops it AND logs/counts it. shutdown (default): puts the port into err-disabled state, blocking ALL traffic until manually or auto-recovered. restrict is often a better starting point for rollout \u2014 it shows you what\u2019s happening without taking the port down.',
    ],
  },
]
