import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand } from './engine'
import { renderPrompt, withDoSupport } from '../../engine/shell'

export const spanningTreeModule: ModuleDefinition = {
  id: 'spanning-tree',
  title: 'Spanning Tree (PortFast & BPDU Guard)',
  summary: 'Deliberately claim the root bridge role, then configure a genuine edge port with PortFast and its BPDU Guard safety net.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
