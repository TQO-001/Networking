export interface InterfaceTsCustomState {
  checkedStatus: boolean
  checkedInterfaceDetail: boolean
  fa3Speed: number | null
  fa3Duplex: 'half' | 'full' | null
  fixedDuplexMismatch: boolean
  identifiedErrDisableCause: boolean
  fa5ManualShutdown: boolean
  fa5ErrDisabled: boolean
  recoveredPort: boolean
  currentInterface: string | null
  errdisableCauses: string[]
  errdisableIntervalSet: boolean
  configuredAutoRecovery: boolean
  savedToStartup: boolean
}

export function initialInterfaceTsCustom(): InterfaceTsCustomState {
  return {
    checkedStatus: false,
    checkedInterfaceDetail: false,
    fa3Speed: null,
    fa3Duplex: 'half', // starts mismatched: switch side auto, other end forced half
    fixedDuplexMismatch: false,
    identifiedErrDisableCause: false,
    fa5ManualShutdown: false,
    fa5ErrDisabled: true, // seeded scenario: Fa0/5 starts err-disabled
    recoveredPort: false,
    currentInterface: null,
    errdisableCauses: [],
    errdisableIntervalSet: false,
    configuredAutoRecovery: false,
    savedToStartup: false,
  }
}
