export interface InterVlanCustomState {
  ipRoutingEnabled: boolean
  vlans: Record<number, { name?: string }>
  svis: Record<number, { ipAddress?: string; noShutdown?: boolean }>
  currentInterface: string | null
  currentInterfaceRange: string[] | null
  ports: Record<string, { mode?: 'access'; vlan?: number }>
  checkedRoutes: boolean
  savedToStartup: boolean
}

export function initialInterVlanCustom(): InterVlanCustomState {
  return {
    ipRoutingEnabled: false,
    vlans: {},
    svis: {},
    currentInterface: null,
    currentInterfaceRange: null,
    ports: {},
    checkedRoutes: false,
    savedToStartup: false,
  }
}
