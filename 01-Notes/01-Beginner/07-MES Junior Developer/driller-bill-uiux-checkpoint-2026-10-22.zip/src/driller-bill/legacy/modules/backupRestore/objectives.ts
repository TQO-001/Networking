import type { EngineState, Objective } from '../../types'
import type { BackupRestoreCustomState } from './state'

function c(state: EngineState): BackupRestoreCustomState {
  return state.custom as BackupRestoreCustomState
}

export const objectives: Objective[] = [
  {
    id: 'backed-up-config',
    label: 'Back up running-config off-box',
    description: 'Copy running-config to a TFTP server \u2014 this is the actual backup.',
    theoryAnchor: 'offbox-backup',
    check: (s) => c(s).backedUp,
  },
  {
    id: 'copied-backup-to-flash',
    label: 'Copy the backup into flash',
    description: 'configure replace needs the file sitting in flash to point at.',
    theoryAnchor: 'restore-workflow',
    check: (s) => c(s).copiedToFlash,
  },
  {
    id: 'used-configure-replace',
    label: 'Use configure replace (not a plain copy)',
    description: 'A true rollback needs the diff-and-replace behavior, not a merge.',
    theoryAnchor: 'merge-vs-replace',
    check: (s) => c(s).configReplaced,
  },
  {
    id: 'confirmed-replace',
    label: 'Confirm a timed replace with configure confirm',
    description: 'Use the timer safety net and then explicitly confirm the change.',
    theoryAnchor: 'configure-replace-safety',
    check: (s) => c(s).ranConfigureConfirm,
  },
  {
    id: 'saved-config',
    label: 'Save the restored configuration',
    description: 'Copy running-config to startup-config so the rollback survives a reload.',
    theoryAnchor: 'offbox-backup',
    check: (s) => c(s).savedToStartup,
  },
]
