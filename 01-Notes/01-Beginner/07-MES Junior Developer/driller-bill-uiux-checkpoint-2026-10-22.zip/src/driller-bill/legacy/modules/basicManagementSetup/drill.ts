import type { DrillStep } from '../../types'

// This is the "watch it run" guided simulation script. Each step is typed
// into the terminal automatically, with its explanation shown alongside.
// The exercise mode (see exercise.ts / objectives.ts) uses the same
// scenario but with a blank terminal the learner types into themselves.
export const drill: DrillStep[] = [
  { command: 'enable', explanation: 'Enter privileged EXEC mode.', theoryAnchor: 'hostname-domain' },
  { command: 'configure terminal', explanation: 'Enter global configuration mode.' },
  { command: 'hostname SW-01', explanation: 'Set a real hostname \u2014 required before RSA key generation.', theoryAnchor: 'hostname-domain' },
  { command: 'ip domain-name laughtale.local', explanation: 'Set the domain name \u2014 combined with hostname, this names the SSH key.', theoryAnchor: 'hostname-domain' },
  { command: 'enable secret Class123!', explanation: 'Set a hashed privileged-mode password.', theoryAnchor: 'enable-secret' },
  { command: 'username techadmin privilege 15 secret Tech@Admin123!', explanation: 'Create a local account for SSH login, tied to an identity.', theoryAnchor: 'local-auth' },
  { command: 'crypto key generate rsa', explanation: 'Generate the RSA key pair \u2014 this is what actually turns SSH on.', theoryAnchor: 'rsa-keys' },
  { command: '2048', explanation: 'Modulus size in response to the prompt \u2014 2048 bits is the modern minimum.', theoryAnchor: 'rsa-keys' },
  { command: 'ip ssh version 2', explanation: 'Force SSHv2 only \u2014 v1 has known vulnerabilities.', theoryAnchor: 'ssh-hardening' },
  { command: 'ip ssh time-out 60', explanation: 'Limit how long an unauthenticated session can sit open.', theoryAnchor: 'ssh-hardening' },
  { command: 'ip ssh authentication-retries 3', explanation: 'Limit login attempts per session.', theoryAnchor: 'ssh-hardening' },
  { command: 'line console 0', explanation: 'Enter console line configuration.' },
  { command: 'login local', explanation: 'Use the local username database for console login.', theoryAnchor: 'line-security' },
  { command: 'logging synchronous', explanation: 'Keep console output from interleaving with your typing.' },
  { command: 'exec-timeout 5 0', explanation: 'Auto-logout an idle console session after 5 minutes.', theoryAnchor: 'line-security' },
  { command: 'exit', explanation: 'Back to global configuration mode.' },
  { command: 'line vty 0 15', explanation: 'Enter configuration for all 16 virtual terminal lines.' },
  { command: 'login local', explanation: 'Use the local username database for remote login.', theoryAnchor: 'line-security' },
  { command: 'transport input ssh', explanation: 'This is what actually blocks Telnet \u2014 only SSH is now accepted.', theoryAnchor: 'line-security' },
  { command: 'exec-timeout 5 0', explanation: 'Auto-logout an idle remote session after 5 minutes.' },
  { command: 'exit', explanation: 'Back to global configuration mode.' },
  {
    command: 'banner motd #',
    explanation: 'Start a legal warning banner (single-line form shown here for the simulator).',
    theoryAnchor: 'banner',
  },
  { command: 'vlan 99', explanation: 'Create the dedicated management VLAN.', theoryAnchor: 'mgmt-vlan-svi' },
  { command: 'name MGMT', explanation: 'Name it so it\u2019s self-documenting six months from now.' },
  { command: 'exit', explanation: 'Back to global configuration mode.' },
  { command: 'interface vlan 99', explanation: 'Enter the management SVI.' },
  { command: 'description Management-SVI', explanation: 'Document what this interface is for.' },
  { command: 'ip address 192.168.99.2 255.255.255.0', explanation: 'Give the switch a management IP.', theoryAnchor: 'mgmt-vlan-svi' },
  { command: 'no shutdown', explanation: 'Bring the SVI up \u2014 it starts administratively down.' },
  { command: 'exit', explanation: 'Back to global configuration mode.' },
  { command: 'ip default-gateway 192.168.99.1', explanation: 'Tell the switch itself where to send off-subnet traffic.', theoryAnchor: 'default-gateway' },
  { command: 'service password-encryption', explanation: 'Encrypt any remaining plaintext secrets in the config.', theoryAnchor: 'password-encryption' },
  { command: 'end', explanation: 'Return straight to privileged EXEC mode.' },
  { command: 'copy running-config startup-config', explanation: 'Save \u2014 nothing survives a reload until this runs.', theoryAnchor: 'save-config' },
]
