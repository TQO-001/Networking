import type { CommandResult, EngineState, Objective } from '../../types'
import { INCOMPLETE_COMMAND, INVALID_INPUT, normalizeInterfaceName, popMode, resolveWord } from '../../engine/shell'
import { initialTrunkCustom, type TrunkCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialTrunkCustom(),
  }
}

function c(state: EngineState): TrunkCustomState {
  return state.custom as TrunkCustomState
}
function withCustom(state: EngineState, patch: Partial<TrunkCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}
function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}
function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()
  if (trimmed === '') return ok(state, [])
  const tokens = trimmed.split(/\s+/)
  const first = tokens[0].toLowerCase()
  const cs = c(state)

  if (first === 'end') return ok({ ...state, mode: 'privileged', awaitingInput: null }, [])
  if (resolveWord(first, ['exit']) === 'exit') {
    if (state.mode === 'user') return ok(state, [])
    if (state.mode === 'privileged') return ok({ ...state, mode: 'user' }, [])
    return ok({ ...state, mode: popMode(state.mode) }, [])
  }
  if (first === '?') return ok(state, [helpFor(state)])

  if (state.mode === 'user') {
    if (resolveWord(first, ['enable']) === 'enable') return ok({ ...state, mode: 'privileged' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in user EXEC mode. Try "enable".`)
  }

  if (state.mode === 'privileged') {
    const word = resolveWord(first, ['configure', 'copy', 'disable'])
    if (word === 'configure') {
      if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure needs an argument, e.g. "configure terminal".')
      const sub = resolveWord(tokens[1], ['terminal'])
      if (sub === 'terminal') return ok({ ...state, mode: 'global' }, ['Enter configuration commands, one per line.  End with CNTL/Z.'])
      return errFail(state, [INVALID_INPUT], 'syntax', 'Only "configure terminal" is supported.')
    }
    if (word === 'copy') {
      const rest = tokens.slice(1).join(' ').toLowerCase()
      if (rest === 'running-config startup-config') return ok(withCustom(state, { savedToStartup: true }), ['Building configuration...', '[OK]'], 'saved-config')
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "copy running-config startup-config".')
    }
    if (word === 'disable') return ok({ ...state, mode: 'user' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set.`)
  }

  if (state.mode === 'global') {
    const word = resolveWord(first, ['vlan', 'interface'])
    if (word === 'vlan') {
      const id = Number(tokens[1])
      if (!Number.isInteger(id)) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'vlan needs a numeric ID.')
      const vlans = { ...cs.vlans, [id]: cs.vlans[id] ?? {} }
      return ok(withCustom({ ...state, mode: 'vlanConfig' }, { vlans }), [])
    }
    if (word === 'interface') {
      const iface = normalizeInterfaceName(tokens.slice(1).join(''))
      if (iface !== 'gigabitethernet0/1') return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates the uplink port "interface gigabitethernet0/1".')
      return ok(withCustom({ ...state, mode: 'interface' }, { currentInterface: iface }), [])
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in global configuration mode.`)
  }

  if (state.mode === 'vlanConfig') {
    if (resolveWord(first, ['name']) === 'name') {
      const name = tokens.slice(1).join(' ')
      if (!name) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'name needs a VLAN name.')
      const vlanId = Object.keys(cs.vlans).map(Number).find((id) => !cs.vlans[id].name)
      if (vlanId === undefined) return errFail(state, [INVALID_INPUT], 'wrong-mode', 'No pending VLAN to name.')
      const vlans = { ...cs.vlans, [vlanId]: { name } }
      return ok(withCustom(state, { vlans }), [], vlanId === 999 ? 'created-native-vlan' : undefined)
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'Try "name <text>".')
  }

  if (state.mode === 'interface') {
    const word = resolveWord(first, ['switchport', 'no'])
    if (word === 'switchport') {
      const sub = resolveWord(tokens[1] ?? '', ['mode', 'trunk', 'nonegotiate'])
      if (sub === 'mode') {
        if (resolveWord(tokens[2] ?? '', ['trunk']) !== 'trunk') return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer only simulates "switchport mode trunk".')
        return ok(withCustom(state, { trunkMode: true }), [], 'set-trunk-mode')
      }
      if (sub === 'trunk') {
        const opt = resolveWord(tokens[2] ?? '', ['native', 'allowed', 'encapsulation'])
        if (opt === 'native') {
          if (resolveWord(tokens[3] ?? '', ['vlan']) !== 'vlan' || !tokens[4]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Expected "switchport trunk native vlan <id>".')
          const id = Number(tokens[4])
          if (!Number.isInteger(id)) return errFail(state, [INVALID_INPUT], 'syntax', 'VLAN ID must be numeric.')
          return ok(withCustom(state, { nativeVlan: id }), [], id === 999 ? 'set-native-vlan' : undefined)
        }
        if (opt === 'allowed') {
          if (resolveWord(tokens[3] ?? '', ['vlan']) !== 'vlan' || !tokens[4]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Expected "switchport trunk allowed vlan <list>".')
          const ids = tokens[4].split(',').map(Number)
          if (ids.some((n) => !Number.isInteger(n))) return errFail(state, [INVALID_INPUT], 'syntax', 'VLAN list must be numeric, comma-separated.')
          return ok(withCustom(state, { allowedVlans: ids }), [], 'set-allowed-vlans')
        }
        if (opt === 'encapsulation') {
          // Accepted as a no-op for platform compatibility, matching the
          // note that some switches (2960/IE3000) don't need/support it.
          return ok(state, [])
        }
        return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "native vlan <id>" or "allowed vlan <list>".')
      }
      if (sub === 'nonegotiate') return ok(withCustom(state, { nonegotiate: true }), [], 'set-nonegotiate')
      return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized switchport option.')
    }
    if (word === 'no') {
      if (resolveWord(tokens[1] ?? '', ['shutdown']) === 'shutdown') return ok(withCustom(state, { noShutdown: true }), [])
      return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "no shutdown".')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s interface command set.`)
  }

  return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized shell state.')
}

function helpFor(state: EngineState): string {
  if (state.mode === 'user') return 'enable'
  if (state.mode === 'global') return 'vlan <id>, interface gigabitethernet0/1, end, exit'
  if (state.mode === 'vlanConfig') return 'name <text>, exit'
  if (state.mode === 'interface') return 'switchport mode trunk, switchport trunk native vlan <id>, switchport trunk allowed vlan <list>, switchport nonegotiate, no shutdown, exit'
  return 'configure terminal, copy running-config startup-config'
}
