import type { CommandResult, EngineState, Objective } from '../../types'
import { AMBIGUOUS_COMMAND, INCOMPLETE_COMMAND, INVALID_INPUT, popMode, resolveWord } from '../../engine/shell'
import { initialIosImageCustom, type IosImageCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialIosImageCustom(),
  }
}

function c(state: EngineState): IosImageCustomState {
  return state.custom as IosImageCustomState
}
function withCustom(state: EngineState, patch: Partial<IosImageCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}
function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}
function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}
function isYes(input: string): boolean {
  const t = input.trim().toLowerCase()
  return t === '' || t === 'y' || t === 'yes'
}
function isNo(input: string): boolean {
  const t = input.trim().toLowerCase()
  return t === 'n' || t === 'no'
}
function ipLike(token: string): boolean {
  return /^\d{1,3}(\.\d{1,3}){3}$/.test(token)
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()
  const cs = c(state)

  // --- Multi-step confirmation / interactive sequences, checked before
  // the generic empty-input short-circuit. ---
  if (state.awaitingInput === 'delete-filename-confirm') {
    if (trimmed === '' || trimmed === cs.deletedFilename) {
      return ok({ ...state, awaitingInput: 'delete-file-confirm' }, [`Delete flash:${cs.deletedFilename}? [confirm]`])
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'Expected to confirm the filename, or just press Enter to accept the default.')
  }
  if (state.awaitingInput === 'delete-file-confirm') {
    if (isNo(trimmed)) return ok({ ...state, awaitingInput: null }, ['Delete cancelled.'])
    return ok(withCustom({ ...state, awaitingInput: null }, { oldImageDeleted: true }), [], 'freed-space')
  }

  if (state.awaitingInput === 'copy-tftp-host') {
    if (!trimmed) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Enter the TFTP server address.')
    return ok(
      { ...withCustom(state, { tftpHost: trimmed }), awaitingInput: 'copy-tftp-source' },
      ['Source filename []?'],
    )
  }
  if (state.awaitingInput === 'copy-tftp-source') {
    if (!trimmed) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Enter the source filename on the TFTP server.')
    return ok(
      { ...withCustom(state, { sourceFilename: trimmed }), awaitingInput: 'copy-tftp-dest' },
      [`Destination filename [${trimmed}]?`],
    )
  }
  if (state.awaitingInput === 'copy-tftp-dest') {
    const dest = trimmed || cs.sourceFilename!
    const next = withCustom({ ...state, awaitingInput: null }, { newImageCopied: true, copiedFilename: dest })
    return ok(
      next,
      [
        `Accessing tftp://${cs.tftpHost}/${cs.sourceFilename}...`,
        'Loading ' + cs.sourceFilename + ' from ' + cs.tftpHost + ' (via Vlan99): !!!!!!!!!!!!!!!!!!!!!!',
        `[OK - 18620345 bytes]`,
        `${dest} copied successfully.`,
      ],
      'copied-image',
    )
  }

  if (state.awaitingInput === 'reload-save-answer') {
    const wasDirty = cs.configDirtySinceLastSave
    if (isYes(trimmed)) {
      const next = withCustom({ ...state, awaitingInput: 'reload-confirm' }, { savedToStartup: true, configDirtySinceLastSave: false })
      return ok(next, ['Building configuration...', '[OK]', 'Proceed with reload? [confirm]'], wasDirty ? 'saved-config' : undefined)
    }
    if (isNo(trimmed)) {
      const next = { ...state, awaitingInput: 'reload-confirm' as const }
      if (wasDirty) {
        return errFail(
          next,
          ['Proceed with reload? [confirm]'],
          'wrong-order',
          'Answering "no" here discarded the boot system change \u2014 it was never saved to startup-config, so the reload won\u2019t actually boot the new image.',
          'saved-config',
          'save-prompt-context',
        )
      }
      return ok(next, ['Proceed with reload? [confirm]'])
    }
    return errFail(state, ['% Please answer yes or no.'], 'syntax', 'The reload save prompt needs an explicit "yes" or "no" answer.')
  }
  if (state.awaitingInput === 'reload-confirm') {
    if (isNo(trimmed)) return ok({ ...state, awaitingInput: null }, ['Reload cancelled.'])
    const next = withCustom({ ...state, mode: 'user', awaitingInput: null }, { reloaded: true })
    return ok(next, ['', '%SYS-5-RELOAD: Reload requested.', 'System Bootstrap...', '...', 'Press RETURN to get started!'], 'reloaded')
  }

  if (trimmed === '') return ok(state, [])
  const tokens = trimmed.split(/\s+/)
  const first = tokens[0].toLowerCase()

  if (first === 'end') return ok({ ...state, mode: 'privileged', awaitingInput: null }, [])
  if (resolveWord(first, ['exit']) === 'exit') {
    if (state.mode === 'user') return ok(state, [])
    if (state.mode === 'privileged') return ok({ ...state, mode: 'user' }, [])
    return ok({ ...state, mode: popMode(state.mode) }, [])
  }
  if (first === '?') return ok(state, [helpFor(state)])

  if (state.mode === 'user') {
    const word = resolveWord(first, ['enable'])
    if (word === 'enable') return ok({ ...state, mode: 'privileged' }, [])
    if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in user EXEC mode. Try "enable".`)
  }

  if (state.mode === 'global') {
    const word = resolveWord(first, ['boot'])
    if (word === 'boot') {
      const sub = resolveWord(tokens[1] ?? '', ['system'])
      if (sub !== 'system') return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "boot system flash:<filename>".')
      const arg = tokens[2] ?? ''
      const filename = arg.replace(/^flash:/i, '')
      if (!filename) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'boot system needs a flash filename, e.g. "boot system flash:c2960-lanbasek9-mz.new-version.bin".')
      if (!cs.newImageCopied || cs.copiedFilename?.toLowerCase() !== filename.toLowerCase()) {
        return errFail(
          state,
          [`% flash:${filename} not found.`],
          'wrong-order',
          'That file isn\u2019t in flash yet \u2014 copy it in with "copy tftp: flash:" first.',
          'set-boot-system',
          'flash-and-boot-var',
        )
      }
      return ok(withCustom(state, { bootSystemSet: filename, configDirtySinceLastSave: true }), [], 'set-boot-system')
    }
    if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in global configuration mode. Try "boot system flash:<filename>".`)
  }

  // privileged mode
  const word = resolveWord(first, ['dir', 'show', 'ping', 'delete', 'copy', 'verify', 'configure', 'reload', 'disable'])

  if (word === 'dir' || word === 'show') {
    const target = tokens.slice(1).join(' ').toLowerCase()
    if (target === 'flash:' || target === 'flash') {
      return ok(withCustom(state, { flashChecked: true }), flashListing(cs), 'checked-flash')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `This trainer simulates "${word} flash:".`)
  }

  if (word === 'ping') {
    const target = tokens[1]
    if (!target || !ipLike(target)) return errFail(state, [INVALID_INPUT], 'syntax', 'ping needs a valid IPv4 address.')
    return ok(
      withCustom(state, { pingedServer: true }),
      [
        `Type escape sequence to abort.`,
        `Sending 5, 100-byte ICMP Echos to ${target}, timeout is 2 seconds:`,
        `!!!!!`,
        `Success rate is 100 percent (5/5), round-trip min/avg/max = 1/2/4 ms`,
      ],
      'confirmed-reachability',
    )
  }

  if (word === 'delete') {
    const target = tokens.slice(1).join('')
    const filename = target.replace(/^flash:/i, '')
    if (!filename) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'delete needs a filename, e.g. "delete flash:c2960-lanbasek9-mz.old-version.bin".')
    return ok(withCustom({ ...state, awaitingInput: 'delete-filename-confirm' }, { deletedFilename: filename }), [`Delete filename [${filename}]?`])
  }

  if (word === 'copy') {
    const rest = tokens.slice(1).join(' ').toLowerCase()
    if (rest === 'tftp: flash:' || rest === 'tftp flash') {
      return ok({ ...state, awaitingInput: 'copy-tftp-host' }, ['Address or name of remote host []?'])
    }
    if (rest === 'running-config startup-config' || rest === 'run start') {
      return ok(withCustom(state, { savedToStartup: true, configDirtySinceLastSave: false }), ['Building configuration...', '[OK]'], 'saved-config')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "copy tftp: flash:" and "copy running-config startup-config".')
  }

  if (word === 'verify') {
    const target = tokens.slice(1).join('')
    const filename = target.replace(/^flash:/i, '')
    if (!cs.newImageCopied || cs.copiedFilename?.toLowerCase() !== filename.toLowerCase()) {
      return errFail(
        state,
        [`% flash:${filename}: no such file, or checksum could not be verified.`],
        'wrong-order',
        'Nothing to verify yet \u2014 copy the image in first with "copy tftp: flash:".',
        'verified-image',
        'verify-image',
      )
    }
    return ok(withCustom(state, { verified: true }), [`Verified ${filename}`, 'Embedded Hash   SHA1 : verified OK'], 'verified-image')
  }

  if (word === 'configure') {
    if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure needs an argument, e.g. "configure terminal".')
    const sub = resolveWord(tokens[1], ['terminal'])
    if (sub === 'terminal') return ok({ ...state, mode: 'global' }, ['Enter configuration commands, one per line.  End with CNTL/Z.'])
    return errFail(state, [INVALID_INPUT], 'syntax', 'Only "configure terminal" is supported in this trainer.')
  }

  if (word === 'reload') {
    const out = ['System configuration has been modified. Save? [yes/no]:']
    return ok({ ...state, awaitingInput: 'reload-save-answer' }, out)
  }

  if (word === 'disable') return ok({ ...state, mode: 'user' }, [])
  if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
  return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in privileged EXEC mode.`)
}

function flashListing(cs: IosImageCustomState): string[] {
  const lines = ['Directory of flash:/', '']
  let idx = 1
  if (!cs.oldImageDeleted) {
    lines.push(`    ${idx++}  -rwx    18620345   Jan 01 2026 00:00:00 +00:00  c2960-lanbasek9-mz.old-version.bin`)
  }
  if (cs.newImageCopied) {
    lines.push(`    ${idx++}  -rwx    21482112   Jan 01 2026 00:00:00 +00:00  ${cs.copiedFilename}`)
  }
  lines.push(`    ${idx++}  -rwx        4096   Jan 01 2026 00:00:00 +00:00  vlan.dat`)
  lines.push('')
  lines.push(cs.oldImageDeleted ? '32514048 bytes total (24601088 bytes free)' : '32514048 bytes total (5980743 bytes free)')
  return lines
}

function helpFor(state: EngineState): string {
  if (state.mode === 'user') return 'enable'
  if (state.mode === 'global') return 'boot system flash:<filename>, end, exit'
  return 'dir flash:, show flash:, ping <ip>, delete flash:<file>, copy tftp: flash:, verify flash:<file>, configure terminal, copy running-config startup-config, reload'
}
