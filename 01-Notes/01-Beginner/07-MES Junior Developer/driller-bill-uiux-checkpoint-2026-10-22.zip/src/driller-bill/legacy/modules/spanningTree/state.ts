export interface SpanningTreeCustomState {
  rootPrimarySet: boolean
  rootPrimaryVlans: number[]
  currentInterface: string | null
  accessMode: boolean
  portfastEnabled: boolean
  bpduguardEnabled: boolean
  checkedSummary: boolean
  savedToStartup: boolean
}

export function initialSpanningTreeCustom(): SpanningTreeCustomState {
  return {
    rootPrimarySet: false,
    rootPrimaryVlans: [],
    currentInterface: null,
    accessMode: false,
    portfastEnabled: false,
    bpduguardEnabled: false,
    checkedSummary: false,
    savedToStartup: false,
  }
}
