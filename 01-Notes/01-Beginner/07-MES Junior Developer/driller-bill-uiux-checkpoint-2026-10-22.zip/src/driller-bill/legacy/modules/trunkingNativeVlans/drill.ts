import type { DrillStep } from '../../types'

export const drill: DrillStep[] = [
  { command: 'enable', explanation: 'Enter privileged EXEC mode.' },
  { command: 'configure terminal', explanation: 'Enter global configuration mode.' },
  { command: 'vlan 999', explanation: 'Create a dedicated, unused native VLAN.', theoryAnchor: 'native-vlan' },
  { command: 'name NATIVE_UNUSED', explanation: 'Name it clearly so no one puts real traffic on it.', theoryAnchor: 'native-vlan' },
  { command: 'exit', explanation: 'Back to global configuration mode.' },
  { command: 'interface gigabitethernet0/1', explanation: 'Enter the uplink port.' },
  { command: 'switchport mode trunk', explanation: 'Force trunking.', theoryAnchor: 'dot1q-tagging' },
  { command: 'switchport trunk native vlan 999', explanation: 'Set the native VLAN explicitly \u2014 must match on both ends.', theoryAnchor: 'native-vlan' },
  { command: 'switchport trunk allowed vlan 10,20,30,40,50,99', explanation: 'Restrict which VLANs are permitted across the trunk.', theoryAnchor: 'allowed-vlans' },
  { command: 'switchport nonegotiate', explanation: 'Disable DTP negotiation for a predictable, secure trunk.' },
  { command: 'no shutdown', explanation: 'Bring the trunk up.' },
  { command: 'end', explanation: 'Return to privileged EXEC mode.' },
  { command: 'copy running-config startup-config', explanation: 'Save.' },
]
