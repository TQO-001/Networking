import type { CommandResult, EngineState, Objective } from '../../types'
import {
  INCOMPLETE_COMMAND,
  INVALID_INPUT,
  expandInterfaceRange,
  normalizeInterfaceName,
  popMode,
  resolveWord,
} from '../../engine/shell'
import { initialDhcpSnoopingCustom, type DhcpSnoopingCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialDhcpSnoopingCustom(),
  }
}

function c(state: EngineState): DhcpSnoopingCustomState {
  return state.custom as DhcpSnoopingCustomState
}
function withCustom(state: EngineState, patch: Partial<DhcpSnoopingCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}
function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}
function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}
function activeInterfaces(cs: DhcpSnoopingCustomState): string[] {
  if (cs.currentInterfaceRange) return cs.currentInterfaceRange
  if (cs.currentInterface) return [cs.currentInterface]
  return []
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()
  if (trimmed === '') return ok(state, [])
  const tokens = trimmed.split(/\s+/)
  const first = tokens[0].toLowerCase()
  const cs = c(state)

  if (first === 'end') return ok({ ...state, mode: 'privileged', awaitingInput: null }, [])
  if (resolveWord(first, ['exit']) === 'exit') {
    if (state.mode === 'user') return ok(state, [])
    if (state.mode === 'privileged') return ok({ ...state, mode: 'user' }, [])
    return ok(withCustom({ ...state, mode: popMode(state.mode) }, { currentInterface: null, currentInterfaceRange: null }), [])
  }
  if (first === '?') return ok(state, [helpFor(state)])

  if (state.mode === 'user') {
    if (resolveWord(first, ['enable']) === 'enable') return ok({ ...state, mode: 'privileged' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in user EXEC mode. Try "enable".`)
  }

  if (state.mode === 'privileged') {
    const word = resolveWord(first, ['configure', 'copy', 'disable'])
    if (word === 'configure') {
      if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure needs an argument.')
      if (resolveWord(tokens[1], ['terminal']) === 'terminal') return ok({ ...state, mode: 'global' }, ['Enter configuration commands, one per line.  End with CNTL/Z.'])
      return errFail(state, [INVALID_INPUT], 'syntax', 'Only "configure terminal" is supported.')
    }
    if (word === 'copy') {
      const rest = tokens.slice(1).join(' ').toLowerCase()
      if (rest === 'running-config startup-config') return ok(withCustom(state, { savedToStartup: true }), ['Building configuration...', '[OK]'], 'saved-config')
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "copy running-config startup-config".')
    }
    if (word === 'disable') return ok({ ...state, mode: 'user' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set.`)
  }

  if (state.mode === 'global') {
    const word = resolveWord(first, ['ip', 'interface'])
    if (word === 'ip') {
      const sub = resolveWord(tokens[1] ?? '', ['dhcp', 'arp'])
      if (sub === 'dhcp') {
        const sub2 = resolveWord(tokens[2] ?? '', ['snooping'])
        if (sub2 !== 'snooping') return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "ip dhcp snooping" or "ip dhcp snooping vlan <ids>".')
        if (!tokens[3]) return ok(withCustom(state, { dhcpSnoopingEnabled: true }), [])
        const vlanWord = resolveWord(tokens[3], ['vlan'])
        if (vlanWord !== 'vlan' || !tokens[4]) return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "ip dhcp snooping vlan <ids>".')
        const ids = tokens[4].split(',').map(Number)
        if (ids.some((n) => !Number.isInteger(n))) return errFail(state, [INVALID_INPUT], 'syntax', 'VLAN list must be numeric.')
        const next = withCustom(state, { dhcpSnoopingVlans: [...new Set([...cs.dhcpSnoopingVlans, ...ids])] })
        const done = cs.dhcpSnoopingEnabled && c(next).dhcpSnoopingVlans.includes(10) && c(next).dhcpSnoopingVlans.includes(20)
        return ok(next, [], done ? 'enabled-dhcp-snooping' : undefined)
      }
      if (sub === 'arp') {
        const sub2 = resolveWord(tokens[2] ?? '', ['inspection'])
        if (sub2 !== 'inspection') return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "ip arp inspection vlan <ids>".')
        const vlanWord = resolveWord(tokens[3] ?? '', ['vlan'])
        if (vlanWord !== 'vlan' || !tokens[4]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Expected "ip arp inspection vlan <ids>".')
        if (!cs.dhcpSnoopingEnabled) {
          return errFail(
            state,
            ['% Enabling DAI without a working DHCP snooping binding table will break legitimate ARP traffic.'],
            'wrong-order',
            'Enable and confirm DHCP snooping first \u2014 DAI checks against its binding table.',
            'enabled-arp-inspection',
            'trust-and-order',
          )
        }
        const ids = tokens[4].split(',').map(Number)
        if (ids.some((n) => !Number.isInteger(n))) return errFail(state, [INVALID_INPUT], 'syntax', 'VLAN list must be numeric.')
        const next = withCustom(state, { arpInspectionVlans: [...new Set([...cs.arpInspectionVlans, ...ids])] })
        const done = c(next).arpInspectionVlans.includes(10) && c(next).arpInspectionVlans.includes(20)
        return ok(next, [], done ? 'enabled-arp-inspection' : undefined)
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "ip dhcp snooping [vlan <ids>]" and "ip arp inspection vlan <ids>".')
    }
    if (word === 'interface') {
      const rest = tokens.slice(1)
      if (resolveWord(rest[0] ?? '', ['range']) === 'range') {
        const list = expandInterfaceRange(rest.slice(1))
        if (!list) return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "interface range fastethernet0/1 - 20".')
        return ok(withCustom({ ...state, mode: 'interfaceRange' }, { currentInterfaceRange: list, currentInterface: null }), [])
      }
      const iface = normalizeInterfaceName(rest.join(''))
      if (iface !== 'gigabitethernet0/1') return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "interface gigabitethernet0/1" and "interface range fastethernet0/1 - 20".')
      return ok(withCustom({ ...state, mode: 'interface' }, { currentInterface: iface, currentInterfaceRange: null }), [])
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in global configuration mode.`)
  }

  if (state.mode === 'interface' || state.mode === 'interfaceRange') {
    const ifaces = activeInterfaces(cs)
    const onUplink = ifaces.length === 1 && ifaces[0] === 'gigabitethernet0/1'
    if (resolveWord(first, ['ip']) === 'ip') {
      const sub = resolveWord(tokens[1] ?? '', ['dhcp', 'arp'])
      if (sub === 'dhcp') {
        const sub2 = resolveWord(tokens[2] ?? '', ['snooping'])
        if (sub2 !== 'snooping') return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "ip dhcp snooping trust" or "ip dhcp snooping limit rate <n>".')
        const opt = resolveWord(tokens[3] ?? '', ['trust', 'limit'])
        if (opt === 'trust') {
          if (!onUplink) return errFail(state, [INVALID_INPUT], 'wrong-mode', 'Trust only the port facing the real DHCP server \u2014 not the end-user port range.')
          return ok(withCustom(state, { uplinkDhcpTrusted: true }), [], 'trusted-uplink-dhcp')
        }
        if (opt === 'limit') {
          if (resolveWord(tokens[4] ?? '', ['rate']) !== 'rate' || !tokens[5]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Expected "ip dhcp snooping limit rate <n>".')
          return ok(withCustom(state, { dhcpRateLimited: true }), [], 'rate-limited-dhcp')
        }
        return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "trust" or "limit rate <n>".')
      }
      if (sub === 'arp') {
        const sub2 = resolveWord(tokens[2] ?? '', ['inspection'])
        if (sub2 !== 'inspection') return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "ip arp inspection trust" or "ip arp inspection limit rate <n>".')
        const opt = resolveWord(tokens[3] ?? '', ['trust', 'limit'])
        if (opt === 'trust') {
          if (!onUplink) return errFail(state, [INVALID_INPUT], 'wrong-mode', 'Trust only the uplink \u2014 keep it consistent with the DHCP snooping trust setting.')
          return ok(withCustom(state, { uplinkArpTrusted: true }), [], 'trusted-uplink-arp')
        }
        if (opt === 'limit') {
          if (resolveWord(tokens[4] ?? '', ['rate']) !== 'rate' || !tokens[5]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Expected "ip arp inspection limit rate <n>".')
          return ok(withCustom(state, { arpRateLimited: true }), [])
        }
        return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "trust" or "limit rate <n>".')
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized "ip" command here.')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s interface command set.`)
  }

  return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized shell state.')
}

function helpFor(state: EngineState): string {
  if (state.mode === 'user') return 'enable'
  if (state.mode === 'global') return 'ip dhcp snooping [vlan <ids>], ip arp inspection vlan <ids>, interface gigabitethernet0/1, interface range <a> - <b>, end, exit'
  if (state.mode === 'interface' || state.mode === 'interfaceRange') return 'ip dhcp snooping trust, ip dhcp snooping limit rate <n>, ip arp inspection trust, ip arp inspection limit rate <n>, exit'
  return 'configure terminal, copy running-config startup-config'
}
