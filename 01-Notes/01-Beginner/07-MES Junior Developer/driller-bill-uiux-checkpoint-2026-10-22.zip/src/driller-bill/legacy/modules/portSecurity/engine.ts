import type { CommandResult, EngineState, Objective } from '../../types'
import { INCOMPLETE_COMMAND, INVALID_INPUT, normalizeInterfaceName, popMode, resolveWord } from '../../engine/shell'
import { initialPortSecurityCustom, type PortSecurityCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialPortSecurityCustom(),
  }
}

function c(state: EngineState): PortSecurityCustomState {
  return state.custom as PortSecurityCustomState
}
function withCustom(state: EngineState, patch: Partial<PortSecurityCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}
function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}
function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()
  if (trimmed === '') return ok(state, [])
  const tokens = trimmed.split(/\s+/)
  const first = tokens[0].toLowerCase()
  const cs = c(state)

  if (first === 'end') return ok({ ...state, mode: 'privileged', awaitingInput: null }, [])
  if (resolveWord(first, ['exit']) === 'exit') {
    if (state.mode === 'user') return ok(state, [])
    if (state.mode === 'privileged') return ok({ ...state, mode: 'user' }, [])
    return ok({ ...state, mode: popMode(state.mode) }, [])
  }
  if (first === '?') return ok(state, [helpFor(state)])

  if (state.mode === 'user') {
    if (resolveWord(first, ['enable']) === 'enable') return ok({ ...state, mode: 'privileged' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in user EXEC mode. Try "enable".`)
  }

  if (state.mode === 'privileged') {
    const word = resolveWord(first, ['configure', 'copy', 'disable'])
    if (word === 'configure') {
      if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure needs an argument.')
      if (resolveWord(tokens[1], ['terminal']) === 'terminal') return ok({ ...state, mode: 'global' }, ['Enter configuration commands, one per line.  End with CNTL/Z.'])
      return errFail(state, [INVALID_INPUT], 'syntax', 'Only "configure terminal" is supported.')
    }
    if (word === 'copy') {
      const rest = tokens.slice(1).join(' ').toLowerCase()
      if (rest === 'running-config startup-config') return ok(withCustom(state, { savedToStartup: true }), ['Building configuration...', '[OK]'], 'saved-config')
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "copy running-config startup-config".')
    }
    if (word === 'disable') return ok({ ...state, mode: 'user' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set.`)
  }

  if (state.mode === 'global') {
    const word = resolveWord(first, ['interface', 'errdisable'])
    if (word === 'interface') {
      const iface = normalizeInterfaceName(tokens.slice(1).join(''))
      if (iface !== 'fastethernet0/5') return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "interface fastethernet0/5".')
      return ok({ ...state, mode: 'interface' }, [])
    }
    if (word === 'errdisable') {
      const sub = resolveWord(tokens[1] ?? '', ['recovery'])
      if (sub !== 'recovery') return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "errdisable recovery cause <cause>" or "errdisable recovery interval <seconds>".')
      const opt = resolveWord(tokens[2] ?? '', ['cause', 'interval'])
      if (opt === 'cause') {
        const cause = tokens[3]
        if (!cause) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'errdisable recovery cause needs a cause keyword.')
        const causes = cs.errdisableCauses.includes(cause) ? cs.errdisableCauses : [...cs.errdisableCauses, cause]
        const bothSet = causes.length > 0 && cs.errdisableIntervalSet
        const next = withCustom(state, { errdisableCauses: causes, configuredAutoRecovery: bothSet || cs.configuredAutoRecovery })
        return ok(next, [], bothSet && !cs.configuredAutoRecovery ? 'configured-auto-recovery' : undefined)
      }
      if (opt === 'interval') {
        if (!tokens[3] || !Number.isInteger(Number(tokens[3]))) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'errdisable recovery interval needs a seconds value.')
        const bothSet = cs.errdisableCauses.length > 0
        const next = withCustom(state, { errdisableIntervalSet: true, configuredAutoRecovery: bothSet || cs.configuredAutoRecovery })
        return ok(next, [], bothSet && !cs.configuredAutoRecovery ? 'configured-auto-recovery' : undefined)
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "cause" or "interval".')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in global configuration mode.`)
  }

  if (state.mode === 'interface') {
    const word = resolveWord(first, ['switchport', 'no'])
    if (word === 'switchport') {
      const sub = resolveWord(tokens[1] ?? '', ['mode', 'access', 'port-security'])
      if (sub === 'mode') {
        if (resolveWord(tokens[2] ?? '', ['access']) !== 'access') return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer only simulates "switchport mode access".')
        return ok(withCustom(state, { accessMode: true }), [])
      }
      if (sub === 'access') {
        if (resolveWord(tokens[2] ?? '', ['vlan']) !== 'vlan' || !tokens[3]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Expected "switchport access vlan <id>".')
        const id = Number(tokens[3])
        if (!Number.isInteger(id)) return errFail(state, [INVALID_INPUT], 'syntax', 'VLAN ID must be numeric.')
        return ok(withCustom(state, { accessVlan: id }), [])
      }
      if (sub === 'port-security') {
        if (!tokens[2]) return ok(withCustom(state, { portSecurityEnabled: true }), [], 'enabled-port-security')
        const opt = resolveWord(tokens[2], ['maximum', 'mac-address', 'violation'])
        if (opt === 'maximum') {
          const n = Number(tokens[3])
          if (!Number.isInteger(n)) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Expected "switchport port-security maximum <n>".')
          return ok(withCustom(state, { maximum: n }), [], n === 2 ? 'set-maximum' : undefined)
        }
        if (opt === 'mac-address') {
          if (resolveWord(tokens[3] ?? '', ['sticky']) !== 'sticky') return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer only simulates "switchport port-security mac-address sticky".')
          return ok(withCustom(state, { stickyEnabled: true }), [], 'enabled-sticky')
        }
        if (opt === 'violation') {
          const mode = resolveWord(tokens[3] ?? '', ['protect', 'restrict', 'shutdown'])
          if (mode !== 'protect' && mode !== 'restrict' && mode !== 'shutdown') return errFail(state, [INVALID_INPUT], 'syntax', 'Expected protect, restrict, or shutdown.')
          return ok(withCustom(state, { violationMode: mode }), [], mode === 'restrict' ? 'set-violation-restrict' : undefined)
        }
        return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized port-security option.')
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized switchport option.')
    }
    if (word === 'no') {
      if (resolveWord(tokens[1] ?? '', ['shutdown']) === 'shutdown') return ok(withCustom(state, { noShutdown: true }), [])
      return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "no shutdown".')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s interface command set.`)
  }

  return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized shell state.')
}

function helpFor(state: EngineState): string {
  if (state.mode === 'user') return 'enable'
  if (state.mode === 'global') return 'interface fastethernet0/5, errdisable recovery cause <cause>, errdisable recovery interval <seconds>, end, exit'
  if (state.mode === 'interface') return 'switchport mode access, switchport access vlan <id>, switchport port-security [maximum <n> | mac-address sticky | violation <mode>], no shutdown, exit'
  return 'configure terminal, copy running-config startup-config'
}
