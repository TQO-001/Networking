import type { CommandResult, EngineState, Objective } from '../../types'
import { INCOMPLETE_COMMAND, INVALID_INPUT, normalizeInterfaceName, popMode, resolveWord } from '../../engine/shell'
import { initialSpanningTreeCustom, type SpanningTreeCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialSpanningTreeCustom(),
  }
}

function c(state: EngineState): SpanningTreeCustomState {
  return state.custom as SpanningTreeCustomState
}
function withCustom(state: EngineState, patch: Partial<SpanningTreeCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}
function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}
function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()
  if (trimmed === '') return ok(state, [])
  const tokens = trimmed.split(/\s+/)
  const first = tokens[0].toLowerCase()
  const cs = c(state)

  if (first === 'end') return ok({ ...state, mode: 'privileged', awaitingInput: null }, [])
  if (resolveWord(first, ['exit']) === 'exit') {
    if (state.mode === 'user') return ok(state, [])
    if (state.mode === 'privileged') return ok({ ...state, mode: 'user' }, [])
    return ok({ ...state, mode: popMode(state.mode) }, [])
  }
  if (first === '?') return ok(state, [helpFor(state)])

  if (state.mode === 'user') {
    if (resolveWord(first, ['enable']) === 'enable') return ok({ ...state, mode: 'privileged' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in user EXEC mode. Try "enable".`)
  }

  if (state.mode === 'privileged') {
    const word = resolveWord(first, ['configure', 'copy', 'show', 'disable'])
    if (word === 'configure') {
      if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure needs an argument.')
      if (resolveWord(tokens[1], ['terminal']) === 'terminal') return ok({ ...state, mode: 'global' }, ['Enter configuration commands, one per line.  End with CNTL/Z.'])
      return errFail(state, [INVALID_INPUT], 'syntax', 'Only "configure terminal" is supported.')
    }
    if (word === 'show') {
      const target = tokens.slice(1).join(' ').toLowerCase()
      if (target === 'spanning-tree summary') {
        const next = withCustom(state, { checkedSummary: true })
        return ok(next, [
          'Switch is in rapid-pvst mode',
          `Root bridge for: ${cs.rootPrimarySet ? cs.rootPrimaryVlans.join(', ') : '(none \u2014 not configured)'}`,
          `PortFast Default: ${cs.portfastEnabled ? 'enabled on Fa0/1' : 'disabled'}`,
          `BPDU Guard Default: ${cs.bpduguardEnabled ? 'enabled on Fa0/1' : 'disabled'}`,
        ], 'checked-summary')
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "show spanning-tree summary".')
    }
    if (word === 'copy') {
      const rest = tokens.slice(1).join(' ').toLowerCase()
      if (rest === 'running-config startup-config') return ok(withCustom(state, { savedToStartup: true }), ['Building configuration...', '[OK]'], 'saved-config')
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "copy running-config startup-config".')
    }
    if (word === 'disable') return ok({ ...state, mode: 'user' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set.`)
  }

  if (state.mode === 'global') {
    const word = resolveWord(first, ['spanning-tree', 'interface'])
    if (word === 'spanning-tree') {
      const sub = resolveWord(tokens[1] ?? '', ['vlan'])
      if (sub !== 'vlan' || !tokens[2]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Expected "spanning-tree vlan <ids> root primary".')
      const ids = tokens[2].split(',').map(Number)
      if (ids.some((n) => !Number.isInteger(n))) return errFail(state, [INVALID_INPUT], 'syntax', 'VLAN list must be numeric, comma-separated.')
      const rootWord = resolveWord(tokens[3] ?? '', ['root'])
      const primaryWord = resolveWord(tokens[4] ?? '', ['primary'])
      if (rootWord !== 'root' || primaryWord !== 'primary') return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "... root primary".')
      return ok(withCustom(state, { rootPrimarySet: true, rootPrimaryVlans: ids }), [], 'set-root-primary')
    }
    if (word === 'interface') {
      const iface = normalizeInterfaceName(tokens.slice(1).join(''))
      if (iface !== 'fastethernet0/1') return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "interface fastethernet0/1".')
      return ok(withCustom({ ...state, mode: 'interface' }, { currentInterface: iface }), [])
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in global configuration mode.`)
  }

  if (state.mode === 'interface') {
    const word = resolveWord(first, ['switchport', 'spanning-tree'])
    if (word === 'switchport') {
      const sub = resolveWord(tokens[1] ?? '', ['mode'])
      if (sub === 'mode' && resolveWord(tokens[2] ?? '', ['access']) === 'access') return ok(withCustom(state, { accessMode: true }), [])
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer only simulates "switchport mode access".')
    }
    if (word === 'spanning-tree') {
      const sub = resolveWord(tokens[1] ?? '', ['portfast', 'bpduguard'])
      if (sub === 'portfast') return ok(withCustom(state, { portfastEnabled: true }), [], 'enabled-portfast')
      if (sub === 'bpduguard') {
        if (resolveWord(tokens[2] ?? '', ['enable']) !== 'enable') return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Expected "spanning-tree bpduguard enable".')
        if (!cs.portfastEnabled) {
          return errFail(
            withCustom(state, { bpduguardEnabled: true }),
            [],
            'wrong-order',
            'BPDU Guard works, but it\u2019s meant to pair with PortFast \u2014 configure portfast on this port too, not one without the other.',
            'enabled-portfast',
            'bpduguard',
          )
        }
        return ok(withCustom(state, { bpduguardEnabled: true }), [], 'enabled-bpduguard')
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "spanning-tree portfast" or "spanning-tree bpduguard enable".')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s interface command set.`)
  }

  return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized shell state.')
}

function helpFor(state: EngineState): string {
  if (state.mode === 'user') return 'enable'
  if (state.mode === 'global') return 'spanning-tree vlan <ids> root primary, interface fastethernet0/1, end, exit'
  if (state.mode === 'interface') return 'switchport mode access, spanning-tree portfast, spanning-tree bpduguard enable, exit'
  return 'configure terminal, show spanning-tree summary, copy running-config startup-config'
}
