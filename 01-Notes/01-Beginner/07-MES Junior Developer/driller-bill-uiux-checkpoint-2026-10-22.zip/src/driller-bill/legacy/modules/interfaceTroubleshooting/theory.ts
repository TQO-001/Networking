import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'interface-states',
    title: 'Interface States',
    commandRef: 'show interfaces status',
    body: [
      'notconnect = no link partner detected. connected = link up, passing traffic. disabled = administratively shut down (you typed shutdown). err-disabled = the switch detected a problem and shut the port down ITSELF as a protective action \u2014 the config still shows "no shutdown", but the port is down until manually recovered.',
      'Confusing "disabled" (manual) with "err-disabled" (automatic) is the most common mistake here \u2014 they need completely different fixes.',
    ],
  },
  {
    id: 'duplex-mismatch',
    title: 'Duplex/Speed Mismatch',
    commandRef: 'show interfaces <int> | include duplex|speed',
    body: [
      'If one side of a link is forced to a fixed speed/duplex and the other is left on auto-negotiate, auto can settle on half-duplex \u2014 producing a mismatch that shows as SLOW performance and rising late-collision/CRC counters, not as a link that\u2019s simply down.',
      'Fix: either both ends are set to auto, or both ends are explicitly forced to the same values. Never force one side and leave the other on auto.',
    ],
  },
  {
    id: 'errdisable-diagnosis',
    title: 'Finding the Err-Disable Cause',
    commandRef: 'show port-security interface <int> / show interfaces status err-disabled',
    body: [
      'Before recovering an err-disabled port, find out WHY it tripped \u2014 port-security violation, BPDU Guard, a detected loop, link flapping. Re-enabling without fixing the underlying cause just triggers the same shutdown again, often within seconds.',
    ],
  },
  {
    id: 'errdisable-recovery',
    title: 'Recovering an Err-Disabled Port',
    commandRef: 'shutdown / no shutdown, errdisable recovery',
    body: [
      'Manual recovery is a shutdown then no shutdown cycle on the interface \u2014 but only after the root cause is actually fixed.',
      'errdisable recovery cause <cause> plus errdisable recovery interval <seconds>, configured globally, makes err-disabled ports come back on their own after a timeout instead of requiring a manual cycle every single time.',
    ],
  },
]
