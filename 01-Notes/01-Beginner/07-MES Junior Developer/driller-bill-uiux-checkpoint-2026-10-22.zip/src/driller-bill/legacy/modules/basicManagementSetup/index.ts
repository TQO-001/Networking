import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand } from './engine'
import { renderPrompt, withDoSupport } from '../../engine/shell'

export const basicManagementSetupModule: ModuleDefinition = {
  id: 'basic-management-setup',
  title: 'Basic Management Setup (Real SSH)',
  summary:
    'Take a blank switch to secure, SSH-only, remotely manageable status \u2014 hostname, domain, RSA keys, local auth, line security, banner, management SVI, default gateway.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
