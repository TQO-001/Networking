import type { DrillStep } from '../../types'

export const drill: DrillStep[] = [
  { command: 'enable', explanation: 'Enter privileged EXEC mode.' },
  { command: 'show interfaces status', explanation: 'Fast overview of every port \u2014 spot the mismatch on Fa0/3 and the err-disabled Fa0/5.', theoryAnchor: 'interface-states' },
  { command: 'show interfaces fastethernet0/3', explanation: 'Look closer at the port with a possible duplex issue.', theoryAnchor: 'duplex-mismatch' },
  { command: 'show interfaces fastethernet0/3 | include duplex|speed', explanation: 'Filter straight to the duplex/speed line \u2014 confirms half-duplex.', theoryAnchor: 'duplex-mismatch' },
  { command: 'configure terminal', explanation: 'Enter global configuration mode to fix it.' },
  { command: 'interface fastethernet0/3', explanation: 'Enter the interface.' },
  { command: 'speed 100', explanation: 'Force both sides to match \u2014 speed first.', theoryAnchor: 'duplex-mismatch' },
  { command: 'duplex full', explanation: 'Then duplex \u2014 both must match on both ends.', theoryAnchor: 'duplex-mismatch' },
  { command: 'exit', explanation: 'Back to global configuration mode.' },
  { command: 'do show port-security interface fastethernet0/5', explanation: 'Now diagnose Fa0/5 \u2014 find out WHY it\u2019s err-disabled before touching it.', theoryAnchor: 'errdisable-diagnosis' },
  { command: 'interface fastethernet0/5', explanation: 'Enter the err-disabled interface.' },
  { command: 'shutdown', explanation: 'Manual recovery step 1 of 2.', theoryAnchor: 'errdisable-recovery' },
  { command: 'no shutdown', explanation: 'Manual recovery step 2 of 2 \u2014 only after the cause is understood.', theoryAnchor: 'errdisable-recovery' },
  { command: 'exit', explanation: 'Back to global configuration mode.' },
  { command: 'errdisable recovery cause psecure-violation', explanation: 'Set up auto-recovery so this doesn\u2019t need a manual cycle next time.', theoryAnchor: 'errdisable-recovery' },
  { command: 'errdisable recovery interval 300', explanation: 'Auto-recover after 5 minutes.', theoryAnchor: 'errdisable-recovery' },
  { command: 'end', explanation: 'Return to privileged EXEC mode.' },
  { command: 'copy running-config startup-config', explanation: 'Save the fixes.' },
]
