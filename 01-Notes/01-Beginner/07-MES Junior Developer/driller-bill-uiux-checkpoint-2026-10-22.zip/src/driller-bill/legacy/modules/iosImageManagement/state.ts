export interface IosImageCustomState {
  flashChecked: boolean
  pingedServer: boolean
  oldImageDeleted: boolean
  deletedFilename: string | null
  tftpHost: string | null
  sourceFilename: string | null
  newImageCopied: boolean
  copiedFilename: string | null
  verified: boolean
  bootSystemSet: string | null
  savedToStartup: boolean
  configDirtySinceLastSave: boolean
  reloaded: boolean
}

export function initialIosImageCustom(): IosImageCustomState {
  return {
    flashChecked: false,
    pingedServer: false,
    oldImageDeleted: false,
    deletedFilename: null,
    tftpHost: null,
    sourceFilename: null,
    newImageCopied: false,
    copiedFilename: null,
    verified: false,
    bootSystemSet: null,
    savedToStartup: false,
    configDirtySinceLastSave: false,
    reloaded: false,
  }
}
