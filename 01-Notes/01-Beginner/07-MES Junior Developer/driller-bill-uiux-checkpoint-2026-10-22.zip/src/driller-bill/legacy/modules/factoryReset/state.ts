export interface FactoryResetCustomState {
  flashChecked: boolean
  nvramErased: boolean
  vlanDatDeleted: boolean
  reloadSaveAnsweredNo: boolean | null
  reloaded: boolean
}

export function initialFactoryResetCustom(): FactoryResetCustomState {
  return {
    flashChecked: false,
    nvramErased: false,
    vlanDatDeleted: false,
    reloadSaveAnsweredNo: null,
    reloaded: false,
  }
}
