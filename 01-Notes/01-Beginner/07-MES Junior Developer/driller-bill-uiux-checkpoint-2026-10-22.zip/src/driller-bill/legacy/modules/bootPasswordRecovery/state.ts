export interface BootRecoveryCustomState {
  inRommon: boolean
  rommonCounter: number
  confregSet2142: boolean
  bypassedBoot: boolean
  oldConfigLoaded: boolean
  newEnableSecretSet: boolean
  registerRestored: boolean
  savedFinal: boolean
  reloaded: boolean
  registerBugTriggered: boolean
}

export function initialBootRecoveryCustom(): BootRecoveryCustomState {
  return {
    inRommon: true,
    rommonCounter: 1,
    confregSet2142: false,
    bypassedBoot: false,
    oldConfigLoaded: false,
    newEnableSecretSet: false,
    registerRestored: false,
    savedFinal: false,
    reloaded: false,
    registerBugTriggered: false,
  }
}
