import type { EngineState, Objective } from '../../types'
import type { InterVlanCustomState } from './state'

function c(state: EngineState): InterVlanCustomState {
  return state.custom as InterVlanCustomState
}

export const objectives: Objective[] = [
  {
    id: 'enabled-ip-routing',
    label: 'Enable IP routing',
    description: 'ip routing, globally.',
    theoryAnchor: 'why-routing-needed',
    check: (s) => c(s).ipRoutingEnabled,
  },
  {
    id: 'configured-svi10',
    label: 'Configure the VLAN 10 SVI',
    description: 'IP address and no shutdown.',
    theoryAnchor: 'svi-routing',
    check: (s) => !!c(s).svis[10]?.ipAddress && !!c(s).svis[10]?.noShutdown,
  },
  {
    id: 'configured-svi20',
    label: 'Configure the VLAN 20 SVI',
    description: 'IP address and no shutdown.',
    theoryAnchor: 'svi-routing',
    check: (s) => !!c(s).svis[20]?.ipAddress && !!c(s).svis[20]?.noShutdown,
  },
  {
    id: 'assigned-ports',
    label: 'Assign end-user ports to VLAN 10',
    description: 'Fa0/1\u20135, access mode.',
    theoryAnchor: 'svi-routing',
    check: (s) => {
      const cs = c(s)
      for (let n = 1; n <= 5; n++) {
        const p = cs.ports[`fastethernet0/${n}`]
        if (!p || p.mode !== 'access' || p.vlan !== 10) return false
      }
      return true
    },
  },
  {
    id: 'verified-routes',
    label: 'Verify with show ip route',
    description: 'Confirm both VLANs show up as connected routes.',
    theoryAnchor: 'gateway-check',
    check: (s) => c(s).checkedRoutes,
  },
  {
    id: 'saved-config',
    label: 'Save the configuration',
    description: 'copy running-config startup-config.',
    theoryAnchor: 'why-routing-needed',
    check: (s) => c(s).savedToStartup,
  },
]
