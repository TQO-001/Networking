export interface CdpLldpCustomState {
  checkedCdpNeighbors: boolean
  checkedCdpDetail: boolean
  lldpEnabled: boolean
  checkedLldpNeighbors: boolean
  cdpDisabledOnUntrustedPort: boolean
  currentInterface: string | null
  savedToStartup: boolean
}

export function initialCdpLldpCustom(): CdpLldpCustomState {
  return {
    checkedCdpNeighbors: false,
    checkedCdpDetail: false,
    lldpEnabled: false,
    checkedLldpNeighbors: false,
    cdpDisabledOnUntrustedPort: false,
    currentInterface: null,
    savedToStartup: false,
  }
}
