import type { CommandResult, EngineState, Objective } from '../../types'
import { AMBIGUOUS_COMMAND, INCOMPLETE_COMMAND, INVALID_INPUT, popMode, resolveWord } from '../../engine/shell'
import { initialBootRecoveryCustom, type BootRecoveryCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'special',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialBootRecoveryCustom(),
  }
}

export function renderPrompt(state: EngineState): string {
  if (state.awaitingInput) return ''
  const cs = state.custom as BootRecoveryCustomState
  if (cs.inRommon) return `rommon ${cs.rommonCounter} >`
  switch (state.mode) {
    case 'user':
      return `${state.hostname}>`
    case 'privileged':
      return `${state.hostname}#`
    case 'global':
      return `${state.hostname}(config)#`
    default:
      return `${state.hostname}>`
  }
}

function c(state: EngineState): BootRecoveryCustomState {
  return state.custom as BootRecoveryCustomState
}
function withCustom(state: EngineState, patch: Partial<BootRecoveryCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}
function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}
function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}
function isNo(input: string): boolean {
  const t = input.trim().toLowerCase()
  return t === 'n' || t === 'no'
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()
  const cs = c(state)

  if (state.awaitingInput === 'reload-confirm') {
    if (isNo(trimmed)) return ok({ ...state, awaitingInput: null }, ['Reload cancelled.'])
    const next = withCustom({ ...state, awaitingInput: null }, { reloaded: true })
    const messages = cs.registerRestored
      ? ['', '%SYS-5-RELOAD: Reload requested.', 'System Bootstrap...', 'Loading startup-config...', 'Press RETURN to get started!']
      : ['', '%SYS-5-RELOAD: Reload requested.', 'System Bootstrap...', '(config-register is still 0x2142 \u2014 startup-config is being skipped AGAIN)', 'Press RETURN to get started!']
    return ok(next, messages, cs.registerRestored ? 'reloaded-clean' : undefined)
  }

  if (trimmed === '' && !cs.inRommon) return ok(state, [])
  if (trimmed === '' && cs.inRommon) return ok(state, [])

  if (cs.inRommon) {
    const tokens = trimmed.split(/\s+/)
    const first = (tokens[0] ?? '').toLowerCase()
    if (first === 'confreg') {
      const val = tokens[1]
      if (val?.toLowerCase() === '0x2142') {
        const next = withCustom(state, { confregSet2142: true, rommonCounter: cs.rommonCounter + 1 })
        return ok(next, [], 'set-confreg-2142')
      }
      return errFail(state, ['% This trainer expects "confreg 0x2142" for password recovery.'], 'syntax', 'The password-recovery register value is 0x2142.', 'set-confreg-2142', 'config-register')
    }
    if (first === 'reset') {
      if (!cs.confregSet2142) {
        return errFail(
          withCustom(state, { rommonCounter: cs.rommonCounter + 1 }),
          ['% Rebooting with the current register value \u2014 this will just ask for the password again.'],
          'wrong-order',
          'Set confreg 0x2142 before resetting, or this reboot won\u2019t bypass anything.',
          'reset-boot',
          'config-register',
        )
      }
      const next = withCustom({ ...state, mode: 'user' }, { inRommon: false, bypassedBoot: true })
      return ok(next, ['System Bootstrap...', 'Loading IOS... (skipping startup-config, per register 0x2142)', '', 'Switch>'], 'reset-boot')
    }
    return errFail(withCustom(state, { rommonCounter: cs.rommonCounter + 1 }), [INVALID_INPUT], 'syntax', 'This trainer simulates "confreg 0x2142" and "reset" in ROMMON.')
  }

  const tokens = trimmed.split(/\s+/)
  const first = tokens[0].toLowerCase()

  if (first === 'end') return ok({ ...state, mode: 'privileged', awaitingInput: null }, [])
  if (resolveWord(first, ['exit']) === 'exit') {
    if (state.mode === 'user') return ok(state, [])
    if (state.mode === 'privileged') return ok({ ...state, mode: 'user' }, [])
    return ok({ ...state, mode: popMode(state.mode) }, [])
  }
  if (first === '?') return ok(state, [helpFor(state)])

  if (state.mode === 'user') {
    const word = resolveWord(first, ['enable'])
    if (word === 'enable') return ok({ ...state, mode: 'privileged' }, [])
    if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in user EXEC mode. Try "enable".`)
  }

  if (state.mode === 'global') {
    const word = resolveWord(first, ['enable', 'config-register'])
    if (word === 'enable') {
      const sub = resolveWord(tokens[1] ?? '', ['secret'])
      if (sub === 'secret') {
        if (!tokens[2]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'enable secret needs a password argument.')
        return ok(withCustom(state, { newEnableSecretSet: true }), [], 'set-new-secret')
      }
      return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'enable needs "secret".')
    }
    if (word === 'config-register') {
      const val = tokens[1]
      if (val?.toLowerCase() === '0x2102') return ok(withCustom(state, { registerRestored: true }), [], 'restored-register')
      return errFail(state, [INVALID_INPUT], 'syntax', 'Normal boot is config-register 0x2102.')
    }
    if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command in global config mode.')
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in global configuration mode.`)
  }

  // privileged
  const word = resolveWord(first, ['configure', 'copy', 'reload'])
  if (word === 'configure') {
    if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure needs an argument, e.g. "configure terminal".')
    const sub = resolveWord(tokens[1], ['terminal'])
    if (sub === 'terminal') return ok({ ...state, mode: 'global' }, ['Enter configuration commands, one per line.  End with CNTL/Z.'])
    return errFail(state, [INVALID_INPUT], 'syntax', 'Only "configure terminal" is supported in this trainer.')
  }
  if (word === 'copy') {
    const rest = tokens.slice(1).join(' ').toLowerCase()
    if (rest === 'startup-config running-config') {
      return ok(withCustom(state, { oldConfigLoaded: true }), ['Building configuration...', '[OK]'], 'loaded-old-config')
    }
    if (rest === 'running-config startup-config') {
      return ok(withCustom(state, { savedFinal: true }), ['Building configuration...', '[OK]'], 'saved-final')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "copy startup-config running-config" and "copy running-config startup-config" \u2014 mind the direction.')
  }
  if (word === 'reload') return ok({ ...state, awaitingInput: 'reload-confirm' }, ['Proceed with reload? [confirm]'])
  if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
  return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in privileged EXEC mode.`)
}

function helpFor(state: EngineState): string {
  const cs = c(state)
  if (cs.inRommon) return 'confreg 0x2142, reset'
  if (state.mode === 'user') return 'enable'
  if (state.mode === 'global') return 'enable secret <password>, config-register 0x2102, end, exit'
  return 'configure terminal, copy startup-config running-config, copy running-config startup-config, reload'
}
