import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand } from './engine'
import { renderPrompt, withDoSupport } from '../../engine/shell'

export const trunkingNativeVlansModule: ModuleDefinition = {
  id: 'trunking-native-vlans',
  title: 'Trunking & Native VLANs',
  summary: 'Configure a trunk with an explicit, dedicated native VLAN and a pruned allowed-VLAN list.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
