import type { CommandResult, EngineState, Objective } from '../../types'
import {
  AMBIGUOUS_COMMAND,
  INCOMPLETE_COMMAND,
  INVALID_INPUT,
  popMode,
  resolveWord,
  normalizeInterfaceName,
  expandInterfaceRange,
} from '../../engine/shell'
import { initialBmsCustom, type BmsCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialBmsCustom(),
  }
}

function c(state: EngineState): BmsCustomState {
  return state.custom as BmsCustomState
}

function withCustom(state: EngineState, patch: Partial<BmsCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}

function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}

function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}

function ipLike(token: string): boolean {
  return /^\d{1,3}(\.\d{1,3}){3}$/.test(token)
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()

  // --- Special case: mid banner-motd capture -------------------------
  if (state.awaitingInput === 'banner-text') {
    const delim = c(state).bannerDelimiter!
    const idx = trimmed.indexOf(delim)
    if (idx === -1) {
      const next = withCustom(state, { bannerBuffer: [...c(state).bannerBuffer, trimmed] })
      return ok(next, [])
    }
    const finalLine = trimmed.slice(0, idx)
    const buffer = finalLine ? [...c(state).bannerBuffer, finalLine] : c(state).bannerBuffer
    void buffer
    const next: EngineState = {
      ...withCustom(state, { bannerSet: true, bannerDelimiter: null, bannerBuffer: [] }),
      mode: state.previousMode ?? 'global',
      previousMode: null,
      awaitingInput: null,
    }
    return ok(next, [], 'banner')
  }

  // --- Special case: awaiting RSA modulus size ------------------------
  if (state.awaitingInput === 'rsa-modulus') {
    const n = Number(trimmed)
    if (!Number.isInteger(n) || n < 360 || n > 4096) {
      return errFail(
        state,
        ['% Invalid modulus size. Enter a value between 360 and 4096.'],
        'syntax',
        'The RSA modulus prompt expects a number between 360 and 4096.',
        'rsa-key',
        'rsa-keys',
      )
    }
    const next: EngineState = { ...withCustom(state, { rsaKeyGenerated: true }), awaitingInput: null }
    return ok(
      next,
      [
        `The name for the keys will be: ${state.hostname}.${c(state).domainName}`,
        `% The key modulus size is ${n} bits`,
        '% Generating 2048 bit RSA keys, keys will be non-exportable...[OK]',
      ],
      'rsa-key',
    )
  }

  if (trimmed === '') return ok(state, [])
  const tokens = trimmed.split(/\s+/)
  const first = tokens[0].toLowerCase()

  // --- Global, mode-independent commands ------------------------------
  if (first === 'end') {
    return ok({ ...state, mode: 'privileged', previousMode: null, awaitingInput: null }, [])
  }
  if (resolveWord(first, ['exit']) === 'exit') {
    if (state.mode === 'user') return ok(state, [])
    if (state.mode === 'privileged') return ok({ ...state, mode: 'user' }, [])
    return ok({ ...state, mode: popMode(state.mode) }, [])
  }
  if (first === '?') {
    return ok(state, [helpFor(state)])
  }

  switch (state.mode) {
    case 'user':
      return handleUserMode(tokens, state)
    case 'privileged':
      return handlePrivilegedMode(tokens, state)
    case 'global':
      return handleGlobalMode(tokens, raw, state)
    case 'interface':
      return handleInterfaceMode(tokens, state)
    case 'vlanConfig':
      return handleVlanConfigMode(tokens, state)
    case 'lineConsole':
      return handleLineMode(tokens, state, 'console')
    case 'lineVty':
      return handleLineMode(tokens, state, 'vty')
    default:
      return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized shell state.')
  }
}

function helpFor(state: EngineState): string {
  switch (state.mode) {
    case 'user':
      return 'enable'
    case 'privileged':
      return 'configure terminal, copy, show, exit'
    case 'global':
      return 'hostname, ip domain-name, enable secret, username, crypto, ip ssh, line, banner, vlan, interface, ip default-gateway, service, end, exit'
    default:
      return '(context-sensitive help is limited in this trainer \u2014 refer to the theory panel)'
  }
}

function handleUserMode(tokens: string[], state: EngineState): CommandResult {
  const word = resolveWord(tokens[0], ['enable'])
  if (word === 'enable') return ok({ ...state, mode: 'privileged' }, [])
  if (word === 'ambiguous') {
    return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
  }
  return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t a recognized command in user EXEC mode. Try "enable".`)
}

function handlePrivilegedMode(tokens: string[], state: EngineState): CommandResult {
  const word = resolveWord(tokens[0], ['configure', 'copy', 'show', 'disable'])
  if (word === 'configure') {
    if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure needs an argument, e.g. "configure terminal".')
    const sub = resolveWord(tokens[1], ['terminal'])
    if (sub === 'terminal') return ok({ ...state, mode: 'global' }, ['Enter configuration commands, one per line.  End with CNTL/Z.'])
    return errFail(state, [INVALID_INPUT], 'syntax', 'Only "configure terminal" is supported in this trainer.')
  }
  if (word === 'copy') {
    const rest = tokens.slice(1).join(' ').toLowerCase()
    if (rest === 'running-config startup-config' || rest === 'run start') {
      return ok(withCustom(state, { savedToStartup: true }), ['Building configuration...', '[OK]'], 'saved-config')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer only simulates "copy running-config startup-config".')
  }
  if (word === 'show') return handleShow(tokens.slice(1), state)
  if (word === 'disable') return ok({ ...state, mode: 'user' }, [])
  if (word === 'ambiguous') {
    return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
  }
  return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in privileged EXEC mode.`)
}

function handleShow(args: string[], state: EngineState): CommandResult {
  const target = args.join(' ').toLowerCase()
  const cs = c(state)
  if (target.startsWith('ip ssh')) {
    return ok(state, [
      `SSH Enable - version ${cs.sshVersion ?? '1.99'}`,
      `Authentication timeout: ${cs.sshTimeoutSet ? '60' : '120'} secs`,
      `Authentication retries: 3`,
    ])
  }
  if (target.startsWith('crypto key')) {
    return ok(state, cs.rsaKeyGenerated
      ? [`% Key pair was generated at: (simulated)`, `Key name: ${state.hostname}.${cs.domainName}`]
      : ['% No keys generated.'])
  }
  if (target.startsWith('running-config')) return ok(state, buildRunningConfig(state))
  if (target.startsWith('ip interface brief')) {
    const lines=['Interface              IP-Address      OK? Method Status                Protocol']
    const sviEntries=Object.entries(cs.svis ?? {}) as Array<[string,{ipAddress?:string;noShutdown?:boolean}]>
    if (cs.svi99 && !sviEntries.some(([id])=>Number(id)===99)) sviEntries.push(['99',cs.svi99])
    sviEntries.sort((a,b)=>Number(a[0])-Number(b[0])).forEach(([id,v])=>lines.push(`Vlan${id}`.padEnd(23)+`${v.ipAddress ? v.ipAddress.split(/\s+/)[0] : 'unassigned'}`.padEnd(15)+`YES manual ${(v.noShutdown ? 'up' : 'administratively down').padEnd(22)}${v.noShutdown ? 'up' : 'down'}`))
    const ports=[...new Set([...Array.from({length:24},(_,i)=>`fastethernet0/${i+1}`), ...Object.keys(cs.ports ?? {})])].sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}))
    ports.forEach((p)=>{const v=cs.ports?.[p] ?? {}; const display=p.replace('fastethernet','Fa'); const status=v.noShutdown===false?'administratively down':(v.noShutdown===true?'up':'down'); const protocol=v.noShutdown===true?'up':'down'; lines.push(display.padEnd(23)+'unassigned      YES unset  '+status.padEnd(21)+protocol)})
    return ok(state, lines)
  }
  if (target.startsWith('interfaces vlan')) {
    const idMatch=target.match(/vlan\s*(\d+)/); const id=idMatch?Number(idMatch[1]):99; const v=cs.svis?.[id] ?? (id===99?cs.svi99:{})
    return ok(state,[`Vlan${id} is ${v.noShutdown ? 'up' : 'administratively down'}, line protocol is ${v.noShutdown ? 'up' : 'down'}`,`  Internet address is ${v.ipAddress ?? 'unassigned'}`,`  Description: ${v.description ?? '(none set)'}`])
  }
  if (/^interfaces?\s+(?:brief|status)$/i.test(target)) {
    const lines=['Port      Name               Status       Vlan       Duplex  Speed Type']
    const ports=[...new Set([...Array.from({length:24},(_,i)=>`fastethernet0/${i+1}`), ...Object.keys(cs.ports ?? {})])].sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}))
    ports.forEach((p)=>{const v=cs.ports?.[p] ?? {}; const display=p.replace('fastethernet','Fa'); const status=v.noShutdown===false?'disabled':(v.noShutdown===true?'connected':'notconnect'); lines.push(`${display.padEnd(10)}${String(v.description??'').slice(0,18).padEnd(19)}${status.padEnd(13)}${String(v.vlan ?? 1).padEnd(11)}a-full   a-100  10/100BaseTX`)})
    return ok(state,lines)
  }
  if (target === 'vlan brief' || target === 'vlan') {
    const ids=[1,...Object.keys(cs.vlans).map(Number),...Object.keys(cs.svis ?? {}).map(Number)].filter((v,i,a)=>Number.isInteger(v)&&a.indexOf(v)===i).sort((a,b)=>a-b)
    const lines=['VLAN Name                             Status    Ports','---- -------------------------------- --------- -------------------------------']
    const ports=cs.ports ?? {}
    ids.forEach(id=>{const name=id===1?'default':(cs.vlans[id]?.name ?? `VLAN${id}`); const members=Object.entries(ports).filter(([,v])=>(v as any).vlan===id).map(([p])=>p.replace('fastethernet','Fa')).join(', '); lines.push(`${String(id).padEnd(5)}${name.slice(0,32).padEnd(33)}active    ${members}`)})
    return ok(state,lines)
  }
  return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer only simulates a few show commands: show ip ssh, show crypto key mypubkey rsa, show running-config, show ip interface brief, show interfaces vlan 99.')
}

function buildRunningConfig(state: EngineState): string[] {
  const cs = c(state)
  const lines: string[] = ['Building configuration...', '', `hostname ${state.hostname}`]
  if (cs.domainName) lines.push(`ip domain-name ${cs.domainName}`)
  if (cs.enableSecretSet) lines.push('enable secret 5 $1$abcd$hashedvalueXXXXXXXXXXXXX')
  Object.entries(cs.users).forEach(([name, u]) => {
    lines.push(`username ${name} privilege ${u.privilege} secret 5 $1$abcd$hashedvalueXXXXXXXXXXXXX`)
  })
  lines.push('!')
  lines.push('line con 0')
  if (cs.consoleLine.loginLocal) lines.push(' login local')
  if (cs.consoleLine.loggingSync) lines.push(' logging synchronous')
  if (cs.consoleLine.execTimeoutSet) lines.push(' exec-timeout 5 0')
  lines.push('!')
  lines.push('line vty 0 15')
  if (cs.vtyLine.loginLocal) lines.push(' login local')
  if (cs.vtyLine.transportSsh) lines.push(' transport input ssh')
  if (cs.vtyLine.execTimeoutSet) lines.push(' exec-timeout 5 0')
  lines.push('!')
  if (cs.vlans[99]) lines.push(`vlan 99\n name ${cs.vlans[99].name ?? ''}`)
  lines.push('interface Vlan99')
  if (cs.svi99.description) lines.push(` description ${cs.svi99.description}`)
  if (cs.svi99.ipAddress) lines.push(` ip address ${cs.svi99.ipAddress}`)
  lines.push(cs.svi99.noShutdown ? ' no shutdown' : ' shutdown')
  if (cs.defaultGateway) lines.push(`ip default-gateway ${cs.defaultGateway}`)
  Object.entries(cs.vlans).sort(([a],[b])=>Number(a)-Number(b)).forEach(([id,v])=>{ if(Number(id)!==99){ lines.push(`vlan ${id}`); if(v.name) lines.push(` name ${v.name}`) } })
  Object.entries(cs.ports ?? {}).sort(([a],[b])=>a.localeCompare(b,undefined,{numeric:true})).forEach(([name,p])=>{
    lines.push(`interface ${name}`); if(p.description) lines.push(` description ${p.description}`); if(p.mode) lines.push(` switchport mode ${p.mode}`); if(p.vlan) lines.push(` switchport access vlan ${p.vlan}`); lines.push(p.noShutdown===false?' shutdown':' no shutdown')
  })
  Object.entries(cs.svis ?? {}).sort(([a],[b])=>Number(a)-Number(b)).forEach(([id,v])=>{ if(Number(id)!==99){ lines.push(`interface Vlan${id}`); if(v.description) lines.push(` description ${v.description}`); if(v.ipAddress){ const parts=v.ipAddress.split(' '); lines.push(` ip address ${parts.join(' ')}`); } lines.push(v.noShutdown?' no shutdown':' shutdown') } })
  if (cs.passwordEncryption) lines.push('service password-encryption')
  lines.push('end')
  return lines
}

function handleGlobalMode(tokens: string[], raw: string, state: EngineState): CommandResult {
  const word = resolveWord(tokens[0], [
    'hostname', 'ip', 'enable', 'username', 'crypto', 'line', 'banner', 'vlan', 'interface', 'service', 'no',
  ])

  if (word === 'hostname') {
    if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'hostname needs a name argument.')
    return ok({ ...state, hostname: tokens[1] }, [], 'hostname')
  }

  if (word === 'ip') {
    const sub = resolveWord(tokens[1] ?? '', ['domain-name', 'default-gateway', 'ssh'])
    if (sub === 'domain-name') {
      if (!tokens[2]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'ip domain-name needs a domain argument.')
      return ok(withCustom(state, { domainName: tokens[2] }), [], 'domain')
    }
    if (sub === 'default-gateway') {
      const ip = tokens[2]
      if (!ip || !ipLike(ip)) return errFail(state, [INVALID_INPUT], 'syntax', 'ip default-gateway needs a valid IPv4 address, e.g. 192.168.99.1.')
      return ok(withCustom(state, { defaultGateway: ip }), [], 'default-gateway')
    }
    if (sub === 'ssh') {
      const opt = resolveWord(tokens[2] ?? '', ['version', 'time-out', 'authentication-retries'])
      if (opt === 'version') {
        const v = tokens[3]
        if (v !== '1' && v !== '2') return errFail(state, [INVALID_INPUT], 'syntax', 'ip ssh version accepts 1 or 2.')
        return ok(withCustom(state, { sshVersion: v === '2' ? 2 : 1 }), [], v === '2' ? 'ssh-version' : undefined)
      }
      if (opt === 'time-out') {
        if (!tokens[3]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'ip ssh time-out needs a seconds value.')
        return ok(withCustom(state, { sshTimeoutSet: true }), [])
      }
      if (opt === 'authentication-retries') {
        if (!tokens[3]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'ip ssh authentication-retries needs a value.')
        return ok(withCustom(state, { sshRetriesSet: true }), [])
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized "ip ssh" option.')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'Unrecognized "ip" command in this trainer. Try ip domain-name, ip default-gateway, or ip ssh.')
  }

  if (word === 'enable') {
    const sub = resolveWord(tokens[1] ?? '', ['secret', 'password'])
    if (sub === 'secret') {
      if (!tokens[2]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'enable secret needs a password argument.')
      return ok(withCustom(state, { enableSecretSet: true }), [], 'enable-secret')
    }
    if (sub === 'password') {
      return errFail(state, ['% enable password is deprecated in this trainer \u2014 use "enable secret" instead.'], 'wrong-order', 'enable password stores plaintext; always use enable secret.', 'enable-secret', 'enable-secret')
    }
    return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'enable needs "secret" (or "password", not recommended).')
  }

  if (word === 'username') {
    if (tokens.length < 6) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Expected: username <name> privilege 15 secret <password>')
    const name = tokens[1]
    const privWord = resolveWord(tokens[2], ['privilege'])
    const secretWord = resolveWord(tokens[4], ['secret'])
    if (privWord !== 'privilege' || secretWord !== 'secret') {
      return errFail(state, [INVALID_INPUT], 'syntax', 'Expected: username <name> privilege 15 secret <password>')
    }
    const priv = Number(tokens[3])
    if (!Number.isInteger(priv)) return errFail(state, [INVALID_INPUT], 'syntax', 'privilege level must be a number (0-15).')
    const next = withCustom(state, { users: { ...c(state).users, [name]: { privilege: priv, secretSet: true } } })
    return ok(next, [], 'local-user')
  }

  if (word === 'crypto') {
    const sub = resolveWord(tokens[1] ?? '', ['key'])
    const sub2 = resolveWord(tokens[2] ?? '', ['generate'])
    const sub3 = resolveWord(tokens[3] ?? '', ['rsa'])
    if (sub === 'key' && sub2 === 'generate' && sub3 === 'rsa') {
      if (state.hostname === 'Switch' || !c(state).domainName) {
        return errFail(state, ['% Please define a hostname other than Switch and configure a domain name first.'], 'wrong-order', 'RSA key generation needs both a real hostname and ip domain-name set first.', 'rsa-key', 'rsa-keys')
      }
      return ok(
        { ...state, awaitingInput: 'rsa-modulus' },
        [`The name for the keys will be: ${state.hostname}.${c(state).domainName}`, 'How many bits in the modulus [512]:'],
      )
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer only simulates "crypto key generate rsa".')
  }

  if (word === 'line') {
    if (resolveWord(tokens[1] ?? '', ['console']) === 'console') return ok({ ...state, mode: 'lineConsole' }, [])
    if (resolveWord(tokens[1] ?? '', ['vty']) === 'vty') return ok({ ...state, mode: 'lineVty' }, [])
    return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer supports "line console 0" and "line vty 0 15".')
  }

  if (word === 'banner') {
    const sub = resolveWord(tokens[1] ?? '', ['motd'])
    if (sub !== 'motd') return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer only simulates "banner motd".')
    const afterMotd = raw.trim().replace(/^\S+\s+\S+\s*/, '')
    if (!afterMotd) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'banner motd needs a delimiter character, e.g. "banner motd #".')
    const delim = afterMotd[0]
    const rest = afterMotd.slice(1)
    const closeIdx = rest.indexOf(delim)
    if (closeIdx !== -1) {
      const text = rest.slice(0, closeIdx)
      return ok(withCustom(state, { bannerSet: true }), ["Enter TEXT message. End with the character '" + delim + "'.", text], 'banner')
    }
    const next: EngineState = {
      ...withCustom(state, { bannerDelimiter: delim, bannerBuffer: rest ? [rest] : [] }),
      mode: 'special',
      previousMode: 'global',
      awaitingInput: 'banner-text',
    }
    return ok(next, ["Enter TEXT message. End with the character '" + delim + "'."])
  }

  if (word === 'vlan') {
    const id = Number(tokens[1])
    if (!tokens[1] || !Number.isInteger(id)) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'vlan needs a numeric VLAN ID, e.g. "vlan 99".')
    const next = { ...withCustom(state, { vlans: { ...c(state).vlans, [id]: c(state).vlans[id] ?? {} }, currentVlan: id }), mode: 'vlanConfig' as const }
    return ok(next, [])
  }

  if (word === 'interface') {
    const rawIf = tokens.slice(1).join('')
    const normalizedIf = normalizeInterfaceName(rawIf)
    if (!normalizedIf) return errFail(state, [INVALID_INPUT], 'syntax', 'Expected an interface such as fa0/1, gi0/1, or vlan99.')
    if (normalizedIf.startsWith('vlan')) {
      const id = Number(normalizedIf.replace('vlan',''))
      if (!Number.isInteger(id)) return errFail(state, [INVALID_INPUT], 'syntax', 'VLAN interface ID must be numeric.')
      return ok(withCustom({ ...state, mode: 'interface' }, { currentInterface: `Vlan${id}` }), [])
    }
    return ok(withCustom({ ...state, mode: 'interface' }, { currentInterface: normalizedIf }), [])
  }

  if (word === 'service') {
    const sub = resolveWord(tokens[1] ?? '', ['password-encryption'])
    if (sub === 'password-encryption') return ok(withCustom(state, { passwordEncryption: true }), [], 'password-encryption')
    return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer only simulates "service password-encryption".')
  }

  if (word === 'no') {
    return errFail(state, [INVALID_INPUT], 'wrong-mode', '"no" commands at this level aren\u2019t part of this drill \u2014 did you mean to be inside an interface or line first?')
  }
  if (word === 'ambiguous') {
    return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command in global config mode.')
  }
  return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in global configuration mode.`)
}

function handleInterfaceMode(tokens: string[], state: EngineState): CommandResult {
  const current = c(state).currentInterface
  if (!current) return errFail(state, [INVALID_INPUT], 'wrong-mode', 'No interface is currently selected.')
  const isSvi = /^Vlan\d+$/i.test(current)
  const vlanId = isSvi ? Number(current.replace(/vlan/i,'')) : null

  if (isSvi) {
    const existing = c(state).svis[vlanId!] ?? (vlanId === 99 ? c(state).svi99 : {})
    const setSvi = (patch: Partial<typeof existing>) => {
      const nextSvi = { ...existing, ...patch }
      const svis = { ...c(state).svis, [vlanId!]: nextSvi }
      return withCustom(state, { svis, svi99: vlanId === 99 ? nextSvi : c(state).svi99 })
    }
    const word = resolveWord(tokens[0], ['description','ip','no','shutdown'])
    if (word === 'description') {
      const text=tokens.slice(1).join(' ')
      if(!text) return errFail(state,[INCOMPLETE_COMMAND],'incomplete','description needs text.')
      return ok(setSvi({description:text}),[])
    }
    if (word === 'ip') {
      const sub=resolveWord(tokens[1] ?? '',['address'])
      if(sub==='address') {
        const ip=tokens[2], mask=tokens[3]
        if(!ip || !ipLike(ip) || !mask || !ipLike(mask)) return errFail(state,[INVALID_INPUT],'syntax','ip address needs an IP and a subnet mask, e.g. 192.168.99.2 255.255.255.0.')
        return ok(setSvi({ipAddress:`${ip} ${mask}`}),[])
      }
      return errFail(state,[INVALID_INPUT],'syntax','Expected "ip address <ip> <mask>".')
    }
    if (word === 'no' && resolveWord(tokens[1] ?? '', ['shutdown']) === 'shutdown') {
      const next=setSvi({noShutdown:true}); const done=vlanId===99 && c(next).svi99.ipAddress && c(next).svi99.noShutdown ? 'svi-configured' : undefined
      return ok(next,[],done)
    }
    if (word === 'shutdown') return ok(setSvi({noShutdown:false}),[])
    return errFail(state,[INVALID_INPUT],'syntax',`Supported SVI commands: description, ip address, no shutdown, shutdown.`)
  }

  const existing = c(state).ports[current] ?? {}
  const setPort=(patch: Partial<typeof existing>)=>withCustom(state,{ports:{...c(state).ports,[current]:{...existing,...patch}}})
  const word = resolveWord(tokens[0], ['description','switchport','no','shutdown'])
  if(word==='description') {
    const text=tokens.slice(1).join(' '); if(!text) return errFail(state,[INCOMPLETE_COMMAND],'incomplete','description needs text.')
    return ok(setPort({description:text}),[])
  }
  if(word==='switchport') {
    const sub=resolveWord(tokens[1] ?? '',['mode','access'])
    if(sub==='mode') {
      const mode=resolveWord(tokens[2] ?? '',['access','trunk'])
      if(!mode || mode==='ambiguous') return errFail(state,[INVALID_INPUT],'syntax','Expected switchport mode access or switchport mode trunk.')
      return ok(setPort({mode:mode as 'access'|'trunk'}),[])
    }
    if(sub==='access') {
      if(resolveWord(tokens[2] ?? '',['vlan'])!=='vlan' || !tokens[3]) return errFail(state,[INCOMPLETE_COMMAND],'incomplete','Expected switchport access vlan <id>.')
      const id=Number(tokens[3]); if(!Number.isInteger(id)) return errFail(state,[INVALID_INPUT],'syntax','VLAN ID must be numeric.')
      return ok(withCustom(setPort({mode:'access',vlan:id}), { vlans: { ...c(state).vlans, [id]: c(state).vlans[id] ?? {} } }),[])
    }
  }
  if(word==='no' && resolveWord(tokens[1] ?? '',['shutdown'])==='shutdown') return ok(setPort({noShutdown:true}),[])
  if(word==='shutdown') return ok(setPort({noShutdown:false}),[])
  return errFail(state,[INVALID_INPUT],'syntax','Supported interface commands: description, switchport mode access, switchport access vlan <id>, no shutdown, shutdown.')
}

function handleVlanConfigMode(tokens: string[], state: EngineState): CommandResult {
  const word = resolveWord(tokens[0], ['name'])
  if (word === 'name') {
    const text = tokens.slice(1).join(' ')
    if (!text) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'name needs a VLAN name argument.')
    const vlanId = c(state).currentVlan ?? (Object.keys(c(state).vlans).map(Number).find((id) => !c(state).vlans[id].name) ?? 99)
    const next = withCustom(state, { vlans: { ...c(state).vlans, [vlanId]: { ...c(state).vlans[vlanId], name: text } }, currentVlan: null })
    return ok(next, [], 'mgmt-vlan')
  }
  return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s vlan-config command set. Try "name <text>".`)
}

function handleLineMode(tokens: string[], state: EngineState, which: 'console' | 'vty'): CommandResult {
  const word = resolveWord(tokens[0], ['login', 'logging', 'exec-timeout', 'transport'])

  if (which === 'console') {
    const line = c(state).consoleLine
    if (word === 'login') {
      const sub = resolveWord(tokens[1] ?? '', ['local'])
      if (sub === 'local') return ok(withCustom(state, { consoleLine: { ...line, loginLocal: true } }), [])
      return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer expects "login local" here.')
    }
    if (word === 'logging') {
      const sub = resolveWord(tokens[1] ?? '', ['synchronous'])
      if (sub === 'synchronous') return ok(withCustom(state, { consoleLine: { ...line, loggingSync: true } }), [])
      return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "logging synchronous".')
    }
    if (word === 'exec-timeout') {
      if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'exec-timeout needs minutes (and optionally seconds), e.g. "exec-timeout 5 0".')
      return ok(withCustom(state, { consoleLine: { ...line, execTimeoutSet: true } }), [])
    }
    if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s line-config command set.`)
  }

  const line = c(state).vtyLine
  if (word === 'login') {
    const sub = resolveWord(tokens[1] ?? '', ['local'])
    if (sub === 'local') return ok(withCustom(state, { vtyLine: { ...line, loginLocal: true } }), [])
    return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer expects "login local" here.')
  }
  if (word === 'exec-timeout') {
    if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'exec-timeout needs minutes (and optionally seconds), e.g. "exec-timeout 5 0".')
    return ok(withCustom(state, { vtyLine: { ...line, execTimeoutSet: true } }), [])
  }
  if (word === 'transport') {
    const sub = resolveWord(tokens[1] ?? '', ['input'])
    const val = resolveWord(tokens[2] ?? '', ['ssh', 'telnet', 'all', 'none'])
    if (sub === 'input' && val === 'ssh') return ok(withCustom(state, { vtyLine: { ...line, transportSsh: true } }), [])
    if (sub === 'input' && (val === 'telnet' || val === 'all')) {
      return errFail(state, ['(accepted, but leaves Telnet reachable \u2014 not what this drill is going for)'], 'wrong-order', 'transport input telnet/all still allows unencrypted Telnet access. This drill wants "transport input ssh" only.', 'vty-secured', 'line-security')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "transport input ssh".')
  }
  if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
  return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s line-config command set.`)
}
