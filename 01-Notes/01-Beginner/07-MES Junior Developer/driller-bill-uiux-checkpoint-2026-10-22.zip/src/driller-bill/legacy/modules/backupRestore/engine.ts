import type { CommandResult, EngineState, Objective } from '../../types'
import { AMBIGUOUS_COMMAND, INCOMPLETE_COMMAND, INVALID_INPUT, resolveWord } from '../../engine/shell'
import { initialBackupRestoreCustom, type BackupRestoreCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialBackupRestoreCustom(),
  }
}

function c(state: EngineState): BackupRestoreCustomState {
  return state.custom as BackupRestoreCustomState
}
function withCustom(state: EngineState, patch: Partial<BackupRestoreCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}
function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}
function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}
function isNo(input: string): boolean {
  const t = input.trim().toLowerCase()
  return t === 'n' || t === 'no'
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()
  const cs = c(state)

  // --- Interactive sequences ------------------------------------------
  if (state.awaitingInput === 'backup-host') {
    if (!trimmed) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Enter the TFTP server address.')
    return ok({ ...state, awaitingInput: 'backup-filename' }, ['Destination filename [switch-confg]?'])
  }
  if (state.awaitingInput === 'backup-filename') {
    const filename = trimmed || 'switch-confg'
    const next = withCustom({ ...state, awaitingInput: null }, { backedUp: true, backupFilename: filename })
    return ok(next, [`!!`, `${filename} copied successfully.`], 'backed-up-config')
  }

  if (state.awaitingInput === 'flash-host') {
    if (!trimmed) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Enter the TFTP server address.')
    return ok({ ...state, awaitingInput: 'flash-source' }, ['Source filename []?'])
  }
  if (state.awaitingInput === 'flash-source') {
    if (!trimmed) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'Enter the source filename on the TFTP server.')
    return ok({ ...withCustom(state, { flashFilename: trimmed }), awaitingInput: 'flash-dest' }, [`Destination filename [${trimmed}]?`])
  }
  if (state.awaitingInput === 'flash-dest') {
    const dest = trimmed || cs.flashFilename!
    const next = withCustom({ ...state, awaitingInput: null }, { copiedToFlash: true, flashFilename: dest })
    return ok(next, ['!!', `${dest} copied successfully.`], 'copied-backup-to-flash')
  }

  if (state.awaitingInput === 'replace-confirm') {
    if (isNo(trimmed)) return ok({ ...state, awaitingInput: null }, ['Replace operation cancelled.'])
    const usedTimer = cs.pendingConfirmRequired // temporarily stashed the intent here before confirm; see 'configure' handler
    const next = withCustom({ ...state, awaitingInput: null }, { configReplaced: true })
    if (usedTimer) {
      return ok(next, [
        'This will apply all necessary additions and deletions',
        'to replace the current running configuration with the',
        'contents of the specified configuration file, which is',
        'assumed to be a complete configuration, not a partial',
        'configuration. Enter Y if you are sure you want to proceed.',
        '',
        'Total number of passes: 1',
        'Rollback Done',
        'Configuration replace scheduled \u2014 will roll back automatically unless "configure confirm" is entered within the timer window.',
      ], 'used-configure-replace')
    }
    return ok(next, ['Rollback Done'], 'used-configure-replace')
  }

  if (trimmed === '') return ok(state, [])
  const tokens = trimmed.split(/\s+/)
  const first = tokens[0].toLowerCase()

  if (first === '?') return ok(state, [helpFor(state)])

  if (state.mode === 'user') {
    const word = resolveWord(first, ['enable'])
    if (word === 'enable') return ok({ ...state, mode: 'privileged' }, [])
    if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in user EXEC mode. Try "enable".`)
  }

  // privileged mode
  const word = resolveWord(first, ['copy', 'configure', 'disable'])

  if (word === 'copy') {
    const rest = tokens.slice(1).join(' ').toLowerCase()
    if (rest === 'running-config tftp:' || rest === 'run tftp') {
      return ok({ ...state, awaitingInput: 'backup-host' }, ['Address or name of remote host []?'])
    }
    if (rest === 'tftp: flash:' || rest === 'tftp flash') {
      return ok({ ...state, awaitingInput: 'flash-host' }, ['Address or name of remote host []?'])
    }
    if (rest === 'running-config startup-config' || rest === 'run start') {
      return ok(withCustom(state, { savedToStartup: true }), ['Building configuration...', '[OK]'], 'saved-config')
    }
    return errFail(
      state,
      [INVALID_INPUT],
      'syntax',
      'This trainer simulates "copy running-config tftp:", "copy tftp: flash:", and "copy running-config startup-config". (copy tftp: running-config is intentionally out of scope here \u2014 see the Merge vs Replace theory section for why.)',
    )
  }

  if (word === 'configure') {
    const sub = resolveWord(tokens[1] ?? '', ['replace', 'confirm'])
    if (sub === 'replace') {
      const arg = tokens[2] ?? ''
      const filename = arg.replace(/^flash:/i, '')
      if (!filename) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure replace needs a flash filename, e.g. "configure replace flash:SW-01-2026-08-20.cfg".')
      if (!cs.copiedToFlash || cs.flashFilename?.toLowerCase() !== filename.toLowerCase()) {
        return errFail(
          state,
          [`% flash:${filename} not found.`],
          'wrong-order',
          'That file isn\u2019t in flash yet \u2014 copy it in with "copy tftp: flash:" first.',
          'copied-backup-to-flash',
          'restore-workflow',
        )
      }
      const hasTime = resolveWord(tokens[3] ?? '', ['time']) === 'time'
      if (hasTime && !tokens[4]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure replace ... time needs a minutes value, e.g. "time 5".')
      // Stash whether a timer was used in pendingConfirmRequired so the
      // replace-confirm handler above knows which message/flow to run;
      // it gets set for real (meaning "still needs configure confirm")
      // only after the confirm step below completes.
      const stateWithIntent = withCustom(state, { pendingConfirmRequired: hasTime })
      return ok({ ...stateWithIntent, awaitingInput: 'replace-confirm' }, ['This will apply all necessary additions and deletions...', 'Continue? [confirm]'])
    }
    if (sub === 'confirm') {
      if (cs.configReplaced && cs.pendingConfirmRequired && !cs.ranConfigureConfirm) {
        return ok(withCustom(state, { ranConfigureConfirm: true, pendingConfirmRequired: false }), ['Configuration replace completed successfully.'], 'confirmed-replace')
      }
      return errFail(state, ['% Nothing to confirm.'], 'wrong-order', 'There\u2019s no pending timed replace to confirm \u2014 use "configure replace flash:<file> time <minutes>" first.', 'confirmed-replace', 'configure-replace-safety')
    }
    if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure needs an argument, e.g. "configure replace flash:<file> time 5" or "configure confirm".')
    return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "configure replace flash:<file> [time <minutes>]" and "configure confirm".')
  }

  if (word === 'disable') return ok({ ...state, mode: 'user' }, [])
  if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
  return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in privileged EXEC mode.`)
}

function helpFor(state: EngineState): string {
  if (state.mode === 'user') return 'enable'
  return 'copy running-config tftp:, copy tftp: flash:, configure replace flash:<file> [time <minutes>], configure confirm, copy running-config startup-config'
}
