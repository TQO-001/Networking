import type { DrillStep } from '../../types'

export const drill: DrillStep[] = [
  { command: 'enable', explanation: 'Enter privileged EXEC mode.' },
  { command: 'dir flash:', explanation: 'Check what\u2019s actually in flash before touching anything.', theoryAnchor: 'storage-split' },
  { command: 'erase startup-config', explanation: 'Start erasing NVRAM \u2014 this will prompt for confirmation.', theoryAnchor: 'erase-sequence' },
  { command: '', explanation: 'Press Enter to confirm the erase (blank = accept default = yes).', theoryAnchor: 'erase-sequence' },
  { command: 'delete flash:vlan.dat', explanation: 'Start deleting the separate VLAN database file.', theoryAnchor: 'delete-vlan-dat' },
  { command: '', explanation: 'Press Enter to confirm the filename (vlan.dat).', theoryAnchor: 'delete-vlan-dat' },
  { command: '', explanation: 'Press Enter to confirm the deletion itself.', theoryAnchor: 'delete-vlan-dat' },
  { command: 'reload', explanation: 'Reboot the switch to complete the reset.', theoryAnchor: 'reload-save-answer' },
  { command: 'no', explanation: 'Answer "no" \u2014 saying yes here would undo the erase.', theoryAnchor: 'reload-save-answer' },
  { command: '', explanation: 'Press Enter to confirm the reload itself.', theoryAnchor: 'reload-save-answer' },
]
