import type { CommandResult, DeviceCategory, EngineState, ModuleDefinition, Objective, ShellMode, TheorySection, DrillStep } from '../types'
import { popMode, resolveWord, INVALID_INPUT, INCOMPLETE_COMMAND } from '../engine/shell'

type InterfaceConfig = { ip?: string; mask?: string; up?: boolean; description?: string; nameif?: string; securityLevel?: number }
type DeviceLabState = {
  category: DeviceCategory
  platform: 'ios-router' | 'linux-server' | 'cisco-asa'
  interfaces: Record<string, InterfaceConfig>
  routes: string[]
  ospf: { process?: number; networks: string[] }
  services: Record<string, { enabled?: boolean; running?: boolean; port?: number }>
  serverHostname?: string
  serverIp?: string
  defaultGateway?: string
  packages: string[]
  firewallPorts: string[]
  acls: Record<string, string[]>
  accessGroups: Record<string, { direction: 'in' | 'out'; interface: string }>
  natConfigured: boolean
  currentInterface: string | null
  currentContext: 'global' | 'interface' | 'routerOspf' | 'acl' | null
  currentOspfProcess?: number
  currentAcl?: string
}

function initial(category: DeviceCategory): EngineState {
  const platform = category === 'router' ? 'ios-router' : category === 'server' ? 'linux-server' : 'cisco-asa'
  const hostname = category === 'router' ? 'R1' : category === 'server' ? 'server' : 'FW1'
  return {
    mode: 'user',
    previousMode: null,
    hostname,
    awaitingInput: null,
    custom: {
      category,
      platform,
      interfaces: {}, routes: [], ospf: { networks: [] }, services: {}, packages: [], firewallPorts: [],
      acls: {}, accessGroups: {}, natConfigured: false, currentInterface: null, currentContext: null,
    },
  }
}

function c(state: EngineState): DeviceLabState { return state.custom as DeviceLabState }
function withCustom(state: EngineState, patch: Partial<DeviceLabState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}
function ok(state: EngineState, output: string[] = []): CommandResult { return { state, output } }
function fail(state: EngineState, category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous', message: string, theoryAnchor?: string): CommandResult {
  return { state, output: category === 'incomplete' ? [INCOMPLETE_COMMAND] : [INVALID_INPUT], error: { category, message, theoryAnchor } }
}
function tokens(raw: string): string[] { return raw.trim().split(/\s+/).filter(Boolean) }
function copyCustom(state: EngineState): DeviceLabState { const x = c(state); return { ...x, interfaces: { ...x.interfaces }, routes: [...x.routes], ospf: { ...x.ospf, networks: [...x.ospf.networks] }, services: { ...x.services }, packages: [...x.packages], firewallPorts: [...x.firewallPorts], acls: Object.fromEntries(Object.entries(x.acls).map(([k,v]) => [k,[...v]])), accessGroups: { ...x.accessGroups } } }

function handleRouter(raw: string, state: EngineState): CommandResult {
  const t = tokens(raw); if (!t.length) return ok(state)
  const first = resolveWord(t[0], ['enable','configure','conf','exit','end','show','interface','ip','router','hostname','network','no'])
  const cs = copyCustom(state)
  if (first === 'end') return ok({ ...state, mode: 'privileged', custom: { ...cs, currentContext: null, currentInterface: null } })
  if (first === 'exit') {
    const nextMode = state.mode === 'special' ? 'global' : popMode(state.mode)
    return ok({ ...state, mode: nextMode, custom: { ...cs, currentContext: null, currentInterface: null } })
  }
  if (state.mode === 'user') {
    if (first === 'enable') return ok({ ...state, mode: 'privileged' })
    return fail(state, 'wrong-mode', 'Router drills start in user EXEC mode. Enter enable first.')
  }
  if (state.mode === 'privileged') {
    if (first === 'configure' || first === 'conf') return ok({ ...state, mode: 'global', custom: { ...cs, currentContext: 'global' } }, ['Enter configuration commands, one per line. End with CNTL/Z.'])
    if (first === 'show') {
      if (/^show ip route$/i.test(raw.trim())) return ok(state, cs.routes.length ? ['Codes: C - connected, S - static, O - OSPF', ...cs.routes.map(r => `S ${r}`)] : ['Gateway of last resort is not set', 'No static routes configured.'])
      if (/^show ip ospf neighbor$/i.test(raw.trim())) return ok(state, cs.ospf.networks.length ? ['Neighbor ID     Pri   State           Dead Time   Address', '10.0.0.2          1   FULL/ -        00:00:37    10.0.0.2'] : ['% OSPF is not enabled'])
      if (/^show ip interface brief$/i.test(raw.trim())) return ok(state, Object.entries(cs.interfaces).map(([i,v]) => `${i.padEnd(18)} ${v.ip ? `${v.ip}` : 'unassigned'.padEnd(14)} ${v.up ? 'up' : 'administratively down'} ${v.up ? 'up' : 'down'}`))
      return ok(state, ['Router# show commands supported in this lab:', 'show ip route', 'show ip ospf neighbor', 'show ip interface brief'])
    }
    return fail(state, 'syntax', `"${t[0]}" is not part of the router lab command set.`)
  }
  if (state.mode === 'global') {
    if (first === 'hostname') {
      if (!t[1]) return fail(state, 'incomplete', 'hostname requires a device name', 'router-identity')
      return ok({ ...state, hostname: t[1], custom: cs }, [])
    }
    if (first === 'interface') {
      const name = t.slice(1).join('').toLowerCase()
      if (!/^(g|gi|gigabitethernet|f|fa|fastethernet)\d+\/\d+$/.test(name)) return fail(state, 'syntax', 'Expected an interface such as GigabitEthernet0/0.', 'router-interfaces')
      const canonical = name.startsWith('g') ? `GigabitEthernet${name.replace(/^(gigabitethernet|gi|g)/,'')}` : `FastEthernet${name.replace(/^(fastethernet|fa|f)/,'')}`
      cs.interfaces[canonical] = cs.interfaces[canonical] ?? {}
      return ok({ ...state, mode: 'interface', custom: { ...cs, currentInterface: canonical, currentContext: 'interface' } })
    }
    if (first === 'ip' && t[1]?.toLowerCase() === 'route') {
      const route = t.slice(2).join(' ')
      if (!route) return fail(state, 'incomplete', 'ip route requires a destination, mask and next hop', 'static-routes')
      cs.routes = [...new Set([...cs.routes, route])]
      return ok({ ...state, custom: cs })
    }
    if (first === 'router' && /^ospf$/i.test(t[1] ?? '')) {
      const process = Number(t[2]); if (!Number.isInteger(process)) return fail(state, 'syntax', 'Use router ospf <process-id>.', 'ospf-basics')
      cs.currentContext = 'routerOspf'; cs.currentOspfProcess = process
      cs.ospf.process = process
      return ok({ ...state, mode: 'special', custom: cs })
    }
    return fail(state, 'syntax', `"${t[0]}" is not supported in router global configuration.`, 'router-configuration')
  }
  if (state.mode === 'interface') {
    const i = cs.currentInterface!; cs.interfaces[i] = { ...cs.interfaces[i] }
    if (first === 'description') { cs.interfaces[i].description = t.slice(1).join(' '); return ok({ ...state, custom: cs }) }
    if (first === 'ip' && t[1] === 'address') {
      if (!t[2] || !t[3]) return fail(state, 'incomplete', 'ip address requires an address and subnet mask', 'router-interfaces')
      cs.interfaces[i].ip = t[2]; cs.interfaces[i].mask = t[3]; return ok({ ...state, custom: cs })
    }
    if (first === 'no' && t[1] === 'shutdown') { cs.interfaces[i].up = true; return ok({ ...state, custom: cs }) }
    return fail(state, 'syntax', 'Supported interface commands: description, ip address, no shutdown.', 'router-interfaces')
  }
  if (state.mode === 'special' && cs.currentContext === 'routerOspf') {
    if (first === 'network') { const n = t.slice(1).join(' '); if (!n) return fail(state, 'incomplete', 'network requires an address, wildcard and area', 'ospf-basics'); cs.ospf.networks = [...new Set([...cs.ospf.networks, n])]; return ok({ ...state, custom: cs }) }
    return fail(state, 'syntax', 'Supported OSPF command: network <address> <wildcard> area <area>.', 'ospf-basics')
  }
  return fail(state, 'syntax', 'Unsupported router shell state.')
}

function handleServer(raw: string, state: EngineState): CommandResult {
  const t = tokens(raw); if (!t.length) return ok(state)
  const cmd = t[0].toLowerCase(); const cs = copyCustom(state)
  const isRoot = state.mode === 'privileged'
  if (cmd === 'exit') return ok({ ...state, mode: state.mode === 'privileged' ? 'user' : 'user' })
  if (cmd === 'sudo' && /^-i$/.test(t[1] ?? '')) return ok({ ...state, mode: 'privileged' })
  if (cmd === 'clear') return ok(state, [''])
  if (!isRoot) {
    if (cmd === 'hostnamectl') return ok({ ...state, custom: cs }, ['hostnamectl: permission denied in this lab user shell. Use sudo -i first.'])
    return fail(state, 'wrong-mode', 'This server task requires root privileges. Use sudo -i before changing system configuration.', 'linux-privilege')
  }
  if (cmd === 'hostnamectl') {
    if (t[1] !== 'set-hostname' || !t[2]) return fail(state, 'incomplete', 'Use hostnamectl set-hostname <name>.', 'linux-identity')
    cs.serverHostname = t[2]; return ok({ ...state, hostname: t[2], custom: cs })
  }
  if (cmd === 'ip') {
    if (t[1] === 'addr' && t.length === 2) return ok(state, [`2: eth0: <BROADCAST,MULTICAST,${cs.interfaces.eth0?.up ? 'UP,LOWER_UP' : 'DOWN'}> ${cs.serverIp ? `inet ${cs.serverIp}/24` : 'inet 192.168.20.10/24'}`])
    if (t[1] === 'addr' && t[2] === 'add' && t[3] && t[4]) { cs.serverIp = t[3]; const iface = t[4] === 'dev' ? t[5] : undefined; if (iface) { const [address, prefix] = t[3].split('/'); cs.interfaces[iface] = { ...cs.interfaces[iface], ip: address, mask: prefix, up: true }; } return ok({ ...state, custom: cs }) }
    if (t[1] === 'link' && t[2] === 'set' && t[3] && t[4] === 'up') { cs.interfaces[t[3]] = { ...cs.interfaces[t[3]], up: true }; return ok({ ...state, custom: cs }) }
    if (t[1] === 'route' && t[2] === 'add' && t[3] === 'default' && t[4] === 'via' && t[5]) { cs.defaultGateway = t[5]; return ok({ ...state, custom: cs }) }
    return fail(state, 'syntax', 'Supported networking commands: ip addr add <cidr> dev <iface>, ip link set <iface> up, ip route add default via <gateway>.', 'linux-networking')
  }
  if (cmd === 'apt' && ['install','update'].includes(t[1] ?? '')) { if (t[1] === 'install' && t[2]) cs.packages = [...new Set([...cs.packages, ...t.slice(2)])]; return ok({ ...state, custom: cs }, ['Reading package lists... Done', 'Operation completed.']) }
  if (cmd === 'systemctl') {
    const action = t[1]; const service = t[2];
    if (!action || !service || !['enable','start','restart','stop','status'].includes(action)) return fail(state, 'syntax', 'Supported systemctl actions in this lab: enable, start, restart, stop, status.', 'linux-services')
    cs.services[service] = { ...cs.services[service], enabled: action === 'enable' ? true : cs.services[service]?.enabled, running: ['start','restart'].includes(action) ? true : action === 'stop' ? false : cs.services[service]?.running }
    if (action === 'status') return ok({ ...state, custom: cs }, [`● ${service}.service - ${cs.services[service]?.running ? 'active (running)' : 'inactive (dead)'}`])
    return ok({ ...state, custom: cs })
  }
  if (cmd === 'ss') return ok(state, ['Netid State   Local Address:Port', ...Object.entries(cs.services).filter(([,v]) => v.running && v.port).map(([name,v]) => `tcp   LISTEN  0.0.0.0:${v.port}    (${name})`), cs.services.nginx?.running ? 'tcp   LISTEN  0.0.0.0:80     (nginx)' : ''].filter(Boolean))
  if (cmd === 'ufw') {
    if (t[1] !== 'allow' || !t[2]) return fail(state, 'incomplete', 'Use ufw allow <port>/<protocol>.', 'linux-firewall')
    cs.firewallPorts = [...new Set([...cs.firewallPorts, t[2]])]; return ok({ ...state, custom: cs }, ['Rule added'])
  }
  if (cmd === 'ip' && t[1] === 'addr') return ok(state, ['1: lo: <LOOPBACK,UP,LOWER_UP>', `2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> ${cs.serverIp ?? 'inet 192.168.1.20/24'}`])
  return fail(state, 'syntax', `Unknown server command "${t[0]}" for this lab.`)
}

function handleFirewall(raw: string, state: EngineState): CommandResult {
  const t = tokens(raw); if (!t.length) return ok(state)
  const cmd = t[0].toLowerCase(); const cs = copyCustom(state)
  if (cmd === 'exit') return ok({ ...state, mode: state.mode === 'global' ? 'privileged' : state.mode === 'interface' ? 'global' : 'user', custom: { ...cs, currentContext: null, currentInterface: null } })
  if (cmd === 'end') return ok({ ...state, mode: 'privileged', custom: { ...cs, currentContext: null, currentInterface: null } })
  if (state.mode === 'user') {
    if (cmd === 'enable') return ok({ ...state, mode: 'privileged' })
    return fail(state, 'wrong-mode', 'Use enable to enter privileged EXEC mode.')
  }
  if (state.mode === 'privileged') {
    if (cmd === 'configure' && t[1] === 'terminal') return ok({ ...state, mode: 'global', custom: { ...cs, currentContext: 'global' } }, ['Enter configuration commands, one per line. End with CNTL/Z.'])
    if (cmd === 'show') {
      if (t[1] === 'access-list') return ok(state, Object.entries(cs.acls).flatMap(([name, rules]) => [name, ...rules.map(r => ` access-list ${name} ${r}`)]) || ['No access-lists configured.'])
      if (t[1] === 'nat') return ok(state, [cs.natConfigured ? 'NAT configuration is active.' : 'No NAT rules configured.'])
      return ok(state, ['FW1# show commands supported in this lab:', 'show access-list', 'show nat'])
    }
    return fail(state, 'syntax', `"${t[0]}" is not part of the firewall EXEC command set.`)
  }
  if (state.mode === 'global') {
    if (cmd === 'interface' && t[1]) { const iface = t[1]; cs.interfaces[iface] ??= {}; cs.currentInterface = iface; cs.currentContext = 'interface'; return ok({ ...state, mode: 'interface', custom: cs }) }
    if (cmd === 'access-list' && t[1]) { const name = t[1]; const rule = t.slice(2).join(' '); if (!rule) return fail(state, 'incomplete', 'access-list requires a rule.', 'firewall-acl'); cs.acls[name] = [...(cs.acls[name] ?? []), rule]; cs.currentAcl = name; cs.currentContext = 'acl'; return ok({ ...state, custom: cs }) }
    if (cmd === 'access-group' && t[1] && t[2] && t[3] === 'interface' && t[4]) { cs.accessGroups[t[1]] = { direction: t[2].toLowerCase() === 'out' ? 'out' : 'in', interface: t[4] }; return ok({ ...state, custom: cs }) }
    if (cmd === 'nat') { cs.natConfigured = true; return ok({ ...state, custom: cs }) }
    return fail(state, 'syntax', 'Supported firewall global commands: interface, access-list, access-group, nat.', 'firewall-policy')
  }
  if (state.mode === 'interface') {
    const i = cs.currentInterface!; cs.interfaces[i] = { ...cs.interfaces[i] }
    if (cmd === 'nameif' && t[1]) { cs.interfaces[i].nameif = t[1]; return ok({ ...state, custom: cs }) }
    if (cmd === 'security-level' && t[1]) { cs.interfaces[i].securityLevel = Number(t[1]); return ok({ ...state, custom: cs }) }
    if (cmd === 'ip' && t[1] === 'address' && t[2]) { cs.interfaces[i].ip = t[2].split('/')[0]; cs.interfaces[i].mask = t[3]; return ok({ ...state, custom: cs }) }
    if (cmd === 'no' && t[1] === 'shutdown') { cs.interfaces[i].up = true; return ok({ ...state, custom: cs }) }
    return fail(state, 'syntax', 'Supported ASA interface commands: nameif, security-level, ip address, no shutdown.', 'firewall-interfaces')
  }
  return fail(state, 'syntax', 'Unsupported firewall shell state.')
}

function handleCommand(raw: string, state: EngineState): CommandResult {
  const platform = c(state).platform
  return platform === 'ios-router' ? handleRouter(raw, state) : platform === 'linux-server' ? handleServer(raw, state) : handleFirewall(raw, state)
}

function prompt(state: EngineState): string {
  const cs = c(state)
  if (cs.platform === 'linux-server') return state.mode === 'privileged' ? `${state.hostname}#` : `${state.hostname}$`
  if (cs.platform === 'cisco-asa') {
    if (state.mode === 'user') return `${state.hostname}>`
    if (state.mode === 'privileged') return `${state.hostname}#`
    if (state.mode === 'interface') return `${state.hostname}(config-if)#`
    return `${state.hostname}(config)#`
  }
  return state.mode === 'user' ? `${state.hostname}>` : state.mode === 'privileged' ? `${state.hostname}#` : state.mode === 'special' ? `${state.hostname}(config-router)#` : state.mode === 'interface' ? `${state.hostname}(config-if)#` : `${state.hostname}(config)#`
}

const definitions: Array<{
  id: string; category: DeviceCategory; title: string; summary: string; difficulty: 'beginner'|'intermediate'|'advanced'; theory: TheorySection[]; drill: DrillStep[]; objectives: Objective[]
}> = []

function makeDefinition(input: typeof definitions[number]): ModuleDefinition {
  return {
    id: input.id, category: input.category, title: input.title, summary: input.summary, difficulty: input.difficulty,
    theory: input.theory, drill: input.drill, objectives: input.objectives,
    createInitialState: () => initial(input.category), handleCommand: (raw, state) => handleCommand(raw, state), renderPrompt: prompt,
    terminalLabel: input.category === 'server' ? 'Linux server terminal' : input.category === 'firewall' ? 'Cisco ASA terminal' : 'Cisco IOS router terminal',
    completionCandidates: (state) => input.category === 'server' ? ['sudo -i','hostnamectl set-hostname','ip addr add','ip link set','ip route add default via','apt update','apt install','systemctl enable','systemctl start','systemctl status','ufw allow','ss -tulpn','exit'] : input.category === 'firewall' ? ['enable','configure terminal','interface gigabitEthernet0/0','nameif outside','security-level 0','ip address','no shutdown','access-list','access-group','nat','show access-list','show nat','end','exit'] : ['enable','configure terminal','hostname','interface gigabitEthernet0/0','ip address','no shutdown','ip route','router ospf 1','network','show ip route','show ip ospf neighbor','show ip interface brief','end','exit'],
  }
}

const routerStaticTheory: TheorySection[] = [
  { id:'router-identity', title:'Router Identity', commandRef:'hostname R1', body:['A meaningful hostname reduces mistakes in multi-device labs. The prompt is your first safety check before changing a configuration.'] },
  { id:'router-interfaces', title:'Layer-3 Interfaces', commandRef:'interface g0/0 / ip address <ip> <mask> / no shutdown', body:['Router interfaces route between networks only when they have Layer-3 addressing and are administratively enabled.'] },
  { id:'static-routes', title:'Static Routing', commandRef:'ip route <network> <mask> <next-hop>', body:['A static route adds an explicit destination and next hop. It is predictable and useful for small or edge networks.'] },
]
const routerStaticDrill: DrillStep[] = [
  {command:'enable', explanation:'Enter privileged EXEC mode.'}, {command:'configure terminal', explanation:'Enter global configuration mode.'}, {command:'hostname EDGE-R1', explanation:'Identify the edge router.', theoryAnchor:'router-identity'}, {command:'interface gigabitethernet0/0', explanation:'Select the LAN-facing interface.', theoryAnchor:'router-interfaces'}, {command:'ip address 192.168.10.1 255.255.255.0', explanation:'Assign the gateway address.', theoryAnchor:'router-interfaces'}, {command:'no shutdown', explanation:'Enable the interface.', theoryAnchor:'router-interfaces'}, {command:'exit', explanation:'Return to global configuration.'}, {command:'ip route 10.20.0.0 255.255.0.0 192.168.10.254', explanation:'Install the static route.', theoryAnchor:'static-routes'}, {command:'end', explanation:'Return to privileged EXEC.'}, {command:'show ip route', explanation:'Verify the route table.', theoryAnchor:'static-routes'}
]
const routerStaticObjectives: Objective[] = [
  {id:'set-router-name', label:'Set EDGE-R1 hostname', description:'Router hostname must be EDGE-R1.', theoryAnchor:'router-identity', check:s=>s.hostname==='EDGE-R1'},
  {id:'configure-lan-interface', label:'Configure GigabitEthernet0/0', description:'G0/0 must have 192.168.10.1/24 and be up.', theoryAnchor:'router-interfaces', check:s=>{const i=(s.custom as DeviceLabState).interfaces['GigabitEthernet0/0'];return Boolean(i?.up&&i.ip==='192.168.10.1'&&i.mask==='255.255.255.0')}},
  {id:'install-static-route', label:'Install 10.20.0.0/16 static route', description:'Static route must point at 192.168.10.254.', theoryAnchor:'static-routes', check:s=>(s.custom as DeviceLabState).routes.includes('10.20.0.0 255.255.0.0 192.168.10.254')},
]

definitions.push({id:'router-static-routing',category:'router',title:'Static Routing & Interfaces',summary:'Configure a routed interface, enable it, and build a predictable static route.',difficulty:'beginner',theory:routerStaticTheory,drill:routerStaticDrill,objectives:routerStaticObjectives})

const routerOspfTheory: TheorySection[] = [
  {id:'ospf-basics', title:'OSPF Process & Networks', commandRef:'router ospf 1 / network <address> <wildcard> area 0', body:['OSPF is a link-state IGP. The process ID is locally significant; the area statement determines which interfaces participate in an OSPF area.']},
  {id:'ospf-interface', title:'OSPF Adjacency Readiness', commandRef:'ip address ... / no shutdown', body:['An OSPF neighbor relationship cannot form if the participating interface is down or unaddressed.']},
]
const routerOspfDrill: DrillStep[] = [
  {command:'enable', explanation:'Enter privileged EXEC.'}, {command:'configure terminal', explanation:'Enter global configuration.'}, {command:'interface gigabitethernet0/1', explanation:'Prepare the OSPF-facing interface.', theoryAnchor:'ospf-interface'}, {command:'ip address 10.0.0.1 255.255.255.252', explanation:'Address the point-to-point link.', theoryAnchor:'ospf-interface'}, {command:'no shutdown', explanation:'Bring the interface up.', theoryAnchor:'ospf-interface'}, {command:'exit', explanation:'Return to global configuration.'}, {command:'router ospf 1', explanation:'Create OSPF process 1.', theoryAnchor:'ospf-basics'}, {command:'network 10.0.0.0 0.0.0.3 area 0', explanation:'Advertise the link in area 0.', theoryAnchor:'ospf-basics'}, {command:'end', explanation:'Return to privileged EXEC.'}, {command:'show ip ospf neighbor', explanation:'Verify that OSPF is enabled and ready for neighbors.', theoryAnchor:'ospf-basics'}
]
const routerOspfObjectives: Objective[] = [
 {id:'ospf-interface',label:'Address OSPF interface',description:'G0/1 must be 10.0.0.1/30 and up.',theoryAnchor:'ospf-interface',check:s=>{const i=(s.custom as DeviceLabState).interfaces['GigabitEthernet0/1'];return Boolean(i?.up&&i.ip==='10.0.0.1'&&i.mask==='255.255.255.252')}},
 {id:'ospf-process',label:'Create OSPF process 1',description:'OSPF process ID 1 must exist.',theoryAnchor:'ospf-basics',check:s=>(s.custom as DeviceLabState).ospf.process===1},
 {id:'ospf-network',label:'Advertise 10.0.0.0/30 in area 0',description:'The OSPF network statement must be present.',theoryAnchor:'ospf-basics',check:s=>(s.custom as DeviceLabState).ospf.networks.includes('10.0.0.0 0.0.0.3 area 0')},
]
definitions.push({id:'router-ospf',category:'router',title:'OSPF Area 0',summary:'Build an OSPF process, activate a routed link, and advertise it into area 0.',difficulty:'intermediate',theory:routerOspfTheory,drill:routerOspfDrill,objectives:routerOspfObjectives})

const serverLinuxTheory: TheorySection[] = [
 {id:'linux-privilege',title:'Privilege & the Root Shell',commandRef:'sudo -i',body:['Use least privilege, but understand when system changes require root. In this drill you explicitly enter a root shell before changing network and service state.']},
 {id:'linux-identity',title:'Server Identity',commandRef:'hostnamectl set-hostname APP-01',body:['A stable hostname makes logs and remote administration easier to interpret.']},
 {id:'linux-networking',title:'Server Networking',commandRef:'ip addr add ... / ip route add default via ...',body:['Linux uses interfaces, CIDR addresses and a routing table to reach networks. The default route is the fallback for destinations outside local routes.']},
]
const serverLinuxDrill: DrillStep[] = [
 {command:'sudo -i',explanation:'Enter the root shell.',theoryAnchor:'linux-privilege'}, {command:'hostnamectl set-hostname APP-01',explanation:'Set the application server hostname.',theoryAnchor:'linux-identity'}, {command:'ip addr add 192.168.20.10/24 dev eth0',explanation:'Assign the application server address.',theoryAnchor:'linux-networking'}, {command:'ip link set eth0 up',explanation:'Enable the NIC.',theoryAnchor:'linux-networking'}, {command:'ip route add default via 192.168.20.1',explanation:'Set the default gateway.',theoryAnchor:'linux-networking'}, {command:'ip addr',explanation:'Verify the interface state.',theoryAnchor:'linux-networking'}
]
const serverLinuxObjectives: Objective[] = [
 {id:'root-shell',label:'Enter root shell',description:'The session must be in the root/privileged shell.',theoryAnchor:'linux-privilege',check:s=>s.mode==='privileged'},
 {id:'server-name',label:'Set APP-01 hostname',description:'Hostname must be APP-01.',theoryAnchor:'linux-identity',check:s=>s.hostname==='APP-01'},
 {id:'server-ip',label:'Configure eth0 addressing',description:'eth0 must be up with 192.168.20.10/24.',theoryAnchor:'linux-networking',check:s=>{const i=(s.custom as DeviceLabState).interfaces.eth0;return Boolean(i?.up&&i.ip==='192.168.20.10'&&i.mask==='24')}},
 {id:'default-route',label:'Set default gateway',description:'Default route must use 192.168.20.1.',theoryAnchor:'linux-networking',check:s=>(s.custom as DeviceLabState).defaultGateway==='192.168.20.1'},
]
definitions.push({id:'server-linux-essentials',category:'server',title:'Linux Server Essentials',summary:'Configure a Linux application server identity, IP address, interface state and default route.',difficulty:'beginner',theory:serverLinuxTheory,drill:serverLinuxDrill,objectives:serverLinuxObjectives})

const serverServicesTheory: TheorySection[] = [
 {id:'linux-services',title:'Services with systemd',commandRef:'systemctl enable nginx / systemctl start nginx',body:['Enable controls whether a service starts at boot; start controls whether it is running now. Production troubleshooting depends on knowing the difference.']},
 {id:'linux-firewall',title:'Host Firewall Rules',commandRef:'ufw allow 443/tcp',body:['Host firewalls should expose only the ports required by the workload.']},
]
const serverServicesDrill: DrillStep[] = [
 {command:'sudo -i',explanation:'Enter the root shell.'}, {command:'apt update',explanation:'Refresh package metadata.'}, {command:'apt install nginx',explanation:'Install the web server package.',theoryAnchor:'linux-services'}, {command:'systemctl enable nginx',explanation:'Enable nginx at boot.',theoryAnchor:'linux-services'}, {command:'systemctl start nginx',explanation:'Start nginx now.',theoryAnchor:'linux-services'}, {command:'ufw allow 80/tcp',explanation:'Permit HTTP traffic through the host firewall.',theoryAnchor:'linux-firewall'}, {command:'systemctl status nginx',explanation:'Verify the service is active.',theoryAnchor:'linux-services'}, {command:'ss -tulpn',explanation:'Verify a listening service port.',theoryAnchor:'linux-services'}
]
const serverServicesObjectives: Objective[] = [
 {id:'nginx-installed',label:'Install nginx',description:'nginx must be present in the simulated package state.',theoryAnchor:'linux-services',check:s=>(s.custom as DeviceLabState).packages.includes('nginx')},
 {id:'nginx-enabled',label:'Enable nginx at boot',description:'nginx must be enabled.',theoryAnchor:'linux-services',check:s=>Boolean((s.custom as DeviceLabState).services.nginx?.enabled)},
 {id:'nginx-running',label:'Start nginx',description:'nginx must be running.',theoryAnchor:'linux-services',check:s=>Boolean((s.custom as DeviceLabState).services.nginx?.running)},
 {id:'allow-http',label:'Allow HTTP',description:'Host firewall must permit 80/tcp.',theoryAnchor:'linux-firewall',check:s=>(s.custom as DeviceLabState).firewallPorts.includes('80/tcp')},
]
definitions.push({id:'server-services-hardening',category:'server',title:'Web Services & Host Firewall',summary:'Install and supervise nginx, then expose only the HTTP service required for the workload.',difficulty:'intermediate',theory:serverServicesTheory,drill:serverServicesDrill,objectives:serverServicesObjectives})

const firewallBasicTheory: TheorySection[] = [
 {id:'firewall-interfaces',title:'ASA Interfaces',commandRef:'nameif outside / security-level 0 / ip address ... / no shutdown',body:['ASA interfaces are named and assigned security levels. Lower security levels normally represent less trusted zones.']},
 {id:'firewall-policy',title:'Policy Attachment',commandRef:'access-group OUTSIDE-IN in interface outside',body:['Creating an ACL is not enough. The ACL must be applied to an interface and direction before it controls traffic.']},
 {id:'firewall-acl',title:'Extended ACLs',commandRef:'access-list OUTSIDE-IN extended permit tcp any host <server> eq 443',body:['Extended ACLs describe traffic by protocol and endpoints/ports, enabling specific policy decisions rather than broad allow rules.']},
]
const firewallBasicDrill: DrillStep[] = [
 {command:'enable',explanation:'Enter privileged EXEC.'}, {command:'configure terminal',explanation:'Enter global configuration.'}, {command:'interface gigabitethernet0/0',explanation:'Enter the outside interface.',theoryAnchor:'firewall-interfaces'}, {command:'nameif outside',explanation:'Name the trust zone.',theoryAnchor:'firewall-interfaces'}, {command:'security-level 0',explanation:'Mark outside as the least-trusted zone.',theoryAnchor:'firewall-interfaces'}, {command:'ip address 203.0.113.2 255.255.255.0',explanation:'Address the public-facing interface.',theoryAnchor:'firewall-interfaces'}, {command:'no shutdown',explanation:'Enable the interface.',theoryAnchor:'firewall-interfaces'}, {command:'exit',explanation:'Return to global configuration.'}, {command:'access-list OUTSIDE-IN extended permit tcp any host 203.0.113.10 eq 443',explanation:'Permit HTTPS to the public service.',theoryAnchor:'firewall-acl'}, {command:'access-group OUTSIDE-IN in interface outside',explanation:'Attach the ACL inbound on outside.',theoryAnchor:'firewall-policy'}, {command:'end',explanation:'Return to privileged EXEC.'}, {command:'show access-list',explanation:'Verify the policy.'}
]
const firewallBasicObjectives: Objective[] = [
 {id:'outside-zone',label:'Configure outside interface',description:'G0/0 must be named outside, security level 0, addressed and up.',theoryAnchor:'firewall-interfaces',check:s=>{const i=(s.custom as DeviceLabState).interfaces['gigabitethernet0/0'];return Boolean(i?.nameif==='outside'&&i.securityLevel===0&&i.ip==='203.0.113.2'&&i.up)}},
 {id:'https-acl',label:'Create OUTSIDE-IN HTTPS rule',description:'OUTSIDE-IN must permit TCP/443 to 203.0.113.10.',theoryAnchor:'firewall-acl',check:s=>(s.custom as DeviceLabState).acls['OUTSIDE-IN']?.some(r=>/permit tcp any host 203\.0\.113\.10 eq 443/i.test(r)) ?? false},
 {id:'apply-acl',label:'Apply OUTSIDE-IN inbound',description:'ACL must be applied inbound to outside.',theoryAnchor:'firewall-policy',check:s=>{const x=(s.custom as DeviceLabState).accessGroups['OUTSIDE-IN'];return x?.direction==='in'&&x.interface==='outside'}},
]
definitions.push({id:'firewall-asa-access-policy',category:'firewall',title:'ASA Interfaces & Access Policy',summary:'Build an outside zone and apply a precise HTTPS ACL to a public-facing service.',difficulty:'intermediate',theory:firewallBasicTheory,drill:firewallBasicDrill,objectives:firewallBasicObjectives})

const firewallNatTheory: TheorySection[] = [
 {id:'firewall-nat',title:'Inside-to-Outside NAT',commandRef:'nat (inside,outside) ... interface',body:['NAT translates private addresses when they cross a security boundary. Keep policy and translation concerns separate: an ACL decides whether traffic is allowed; NAT changes addressing.']},
 {id:'firewall-policy-2',title:'Verification',commandRef:'show nat / show access-list',body:['Production changes should be verified after configuration. Read the resulting rule table rather than assuming the command was accepted.']},
]
const firewallNatDrill: DrillStep[] = [
 {command:'enable',explanation:'Enter privileged EXEC.'}, {command:'configure terminal',explanation:'Enter global configuration.'}, {command:'nat (inside,outside) after-auto source dynamic any interface',explanation:'Configure dynamic PAT for inside hosts.',theoryAnchor:'firewall-nat'}, {command:'access-list OUTSIDE-ADMIN extended permit tcp any host 203.0.113.10 eq 443',explanation:'Create a narrowly scoped HTTPS rule for the management service.',theoryAnchor:'firewall-policy-2'}, {command:'access-group OUTSIDE-ADMIN in interface outside',explanation:'Apply the rule to the outside interface.',theoryAnchor:'firewall-policy-2'}, {command:'end',explanation:'Return to privileged EXEC.'}, {command:'show nat',explanation:'Verify translation policy.',theoryAnchor:'firewall-policy-2'}, {command:'show access-list',explanation:'Verify the ACL table.',theoryAnchor:'firewall-policy-2'}
]
const firewallNatObjectives: Objective[] = [
 {id:'nat-configured',label:'Configure dynamic PAT',description:'A dynamic inside-to-outside NAT rule must exist.',theoryAnchor:'firewall-nat',check:s=>(s.custom as DeviceLabState).natConfigured},
 {id:'admin-acl',label:'Create OUTSIDE-ADMIN',description:'OUTSIDE-ADMIN must permit TCP/443 to 203.0.113.10.',theoryAnchor:'firewall-policy-2',check:s=>(s.custom as DeviceLabState).acls['OUTSIDE-ADMIN']?.some(r=>/permit tcp any host 203\.0\.113\.10 eq 443/i.test(r)) ?? false},
 {id:'admin-apply',label:'Apply OUTSIDE-ADMIN inbound',description:'The ACL must be attached inbound to outside.',theoryAnchor:'firewall-policy-2',check:s=>{const x=(s.custom as DeviceLabState).accessGroups['OUTSIDE-ADMIN'];return x?.direction==='in'&&x.interface==='outside'}},
]
definitions.push({id:'firewall-nat-verification',category:'firewall',title:'NAT, ACLs & Verification',summary:'Configure dynamic PAT, attach a focused management ACL, and verify the final firewall policy.',difficulty:'advanced',theory:firewallNatTheory,drill:firewallNatDrill,objectives:firewallNatObjectives})

export const deviceLabModules: ModuleDefinition[] = definitions.map(makeDefinition)
