import type { DrillStep } from '../../types'

export const drill: DrillStep[] = [
  { command: 'enable', explanation: 'Enter privileged EXEC mode.' },
  { command: 'dir flash:', explanation: 'Check current flash contents and free space before touching anything.', theoryAnchor: 'flash-and-boot-var' },
  { command: 'ping 192.168.99.50', explanation: 'Confirm the switch can actually reach the TFTP server first.', theoryAnchor: 'tftp-transfer' },
  { command: 'delete flash:c2960-lanbasek9-mz.old-version.bin', explanation: 'Free up space by removing the old image \u2014 do this before copying, not after a failed copy.', theoryAnchor: 'space-cleanup' },
  { command: '', explanation: 'Confirm the filename.', theoryAnchor: 'space-cleanup' },
  { command: '', explanation: 'Confirm the deletion.', theoryAnchor: 'space-cleanup' },
  { command: 'copy tftp: flash:', explanation: 'Start the TFTP transfer.', theoryAnchor: 'tftp-transfer' },
  { command: '192.168.99.50', explanation: 'Address of the TFTP server.', theoryAnchor: 'tftp-transfer' },
  { command: 'c2960-lanbasek9-mz.new-version.bin', explanation: 'Source filename on the TFTP server.', theoryAnchor: 'tftp-transfer' },
  { command: '', explanation: 'Accept the default destination filename.', theoryAnchor: 'tftp-transfer' },
  { command: 'dir flash:', explanation: 'Confirm the new file actually landed in flash.', theoryAnchor: 'flash-and-boot-var' },
  { command: 'verify flash:c2960-lanbasek9-mz.new-version.bin', explanation: 'Checksum-verify the copy completed correctly before trusting it.', theoryAnchor: 'verify-image' },
  { command: 'configure terminal', explanation: 'Enter global configuration mode.' },
  { command: 'boot system flash:c2960-lanbasek9-mz.new-version.bin', explanation: 'Point the boot variable at the new image.', theoryAnchor: 'flash-and-boot-var' },
  { command: 'end', explanation: 'Return to privileged EXEC mode.' },
  { command: 'copy running-config startup-config', explanation: 'Save \u2014 this boot system change needs to survive the reload.', theoryAnchor: 'save-prompt-context' },
  { command: 'reload', explanation: 'Reboot the switch into the new image.', theoryAnchor: 'save-prompt-context' },
  { command: 'yes', explanation: 'Already saved, so this just confirms \u2014 but if you hadn\u2019t saved yet, this is the answer you\u2019d want here.', theoryAnchor: 'save-prompt-context' },
  { command: '', explanation: 'Confirm the reload itself.' },
]
