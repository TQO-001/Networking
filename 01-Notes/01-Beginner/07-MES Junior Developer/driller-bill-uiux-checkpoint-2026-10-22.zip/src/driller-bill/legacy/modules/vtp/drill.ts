import type { DrillStep } from '../../types'

export const drill: DrillStep[] = [
  { command: 'enable', explanation: 'Enter privileged EXEC mode.' },
  { command: 'configure terminal', explanation: 'Enter global configuration mode.' },
  { command: 'vtp mode transparent', explanation: 'The safer default \u2014 removes the revision-number risk entirely.', theoryAnchor: 'transparent-default' },
  { command: 'vlan 10', explanation: 'Configure VLANs locally, as normal.', theoryAnchor: 'vtp-modes' },
  { command: 'name SALES', explanation: 'Name it.' },
  { command: 'exit', explanation: 'Back to global configuration mode.' },
  { command: 'end', explanation: 'Return to privileged EXEC mode.' },
  { command: 'show vtp status', explanation: 'Verify mode and revision number before trusting this switch on a live network.', theoryAnchor: 'revision-trap' },
  { command: 'copy running-config startup-config', explanation: 'Save.' },
]
