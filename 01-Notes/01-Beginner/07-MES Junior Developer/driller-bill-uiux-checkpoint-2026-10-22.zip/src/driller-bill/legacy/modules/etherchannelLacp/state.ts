export interface EtherchannelCustomState {
  currentInterface: string | null
  currentInterfaceRange: string[] | null
  memberTrunkConfigured: Record<string, boolean>
  channelGroupId: number | null
  channelGroupMode: 'active' | 'passive' | null
  bundledMembers: string[]
  portChannelTrunkConfigured: boolean
  loadBalanceSet: boolean
  savedToStartup: boolean
}

export function initialEtherchannelCustom(): EtherchannelCustomState {
  return {
    currentInterface: null,
    currentInterfaceRange: null,
    memberTrunkConfigured: {},
    channelGroupId: null,
    channelGroupMode: null,
    bundledMembers: [],
    portChannelTrunkConfigured: false,
    loadBalanceSet: false,
    savedToStartup: false,
  }
}
