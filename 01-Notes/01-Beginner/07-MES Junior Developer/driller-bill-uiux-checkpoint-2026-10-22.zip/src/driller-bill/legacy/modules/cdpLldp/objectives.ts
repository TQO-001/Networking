import type { EngineState, Objective } from '../../types'
import type { CdpLldpCustomState } from './state'

function c(state: EngineState): CdpLldpCustomState {
  return state.custom as CdpLldpCustomState
}

export const objectives: Objective[] = [
  {
    id: 'checked-cdp-neighbors',
    label: 'Check CDP neighbors',
    description: 'show cdp neighbors.',
    theoryAnchor: 'cdp-basics',
    check: (s) => c(s).checkedCdpNeighbors,
  },
  {
    id: 'checked-cdp-detail',
    label: 'Check CDP neighbor detail',
    description: 'show cdp neighbors detail.',
    theoryAnchor: 'cdp-basics',
    check: (s) => c(s).checkedCdpDetail,
  },
  {
    id: 'enabled-lldp',
    label: 'Enable LLDP globally',
    description: 'lldp run \u2014 off by default.',
    theoryAnchor: 'lldp-basics',
    check: (s) => c(s).lldpEnabled,
  },
  {
    id: 'disabled-cdp-untrusted',
    label: 'Disable CDP on an untrusted-facing port',
    description: 'no cdp enable on Fa0/24.',
    theoryAnchor: 'cdp-security',
    check: (s) => c(s).cdpDisabledOnUntrustedPort,
  },
  {
    id: 'checked-lldp-neighbors',
    label: 'Check LLDP neighbors',
    description: 'show lldp neighbors.',
    theoryAnchor: 'lldp-basics',
    check: (s) => c(s).checkedLldpNeighbors,
  },
  {
    id: 'saved-config',
    label: 'Save the configuration',
    description: 'copy running-config startup-config.',
    theoryAnchor: 'cdp-basics',
    check: (s) => c(s).savedToStartup,
  },
]
