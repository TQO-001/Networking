import type { EngineState, Objective } from '../../types'
import type { DhcpSnoopingCustomState } from './state'

function c(state: EngineState): DhcpSnoopingCustomState {
  return state.custom as DhcpSnoopingCustomState
}

export const objectives: Objective[] = [
  {
    id: 'enabled-dhcp-snooping',
    label: 'Enable DHCP snooping for VLANs 10 and 20',
    description: 'Global enable plus the specific VLANs.',
    theoryAnchor: 'dhcp-snooping-basics',
    check: (s) => c(s).dhcpSnoopingEnabled && c(s).dhcpSnoopingVlans.includes(10) && c(s).dhcpSnoopingVlans.includes(20),
  },
  {
    id: 'trusted-uplink-dhcp',
    label: 'Trust the uplink for DHCP snooping',
    description: 'Or the real DHCP server\u2019s own offers get dropped too.',
    theoryAnchor: 'trust-and-order',
    check: (s) => c(s).uplinkDhcpTrusted,
  },
  {
    id: 'rate-limited-dhcp',
    label: 'Rate-limit DHCP on untrusted ports',
    description: 'ip dhcp snooping limit rate on the access-port range.',
    theoryAnchor: 'trust-and-order',
    check: (s) => c(s).dhcpRateLimited,
  },
  {
    id: 'enabled-arp-inspection',
    label: 'Enable DAI for the same VLANs',
    description: 'Must come after DHCP snooping is already working.',
    theoryAnchor: 'dai-basics',
    check: (s) => c(s).arpInspectionVlans.includes(10) && c(s).arpInspectionVlans.includes(20),
  },
  {
    id: 'trusted-uplink-arp',
    label: 'Trust the uplink for DAI too',
    description: 'Trust settings should be consistent between DHCP snooping and DAI.',
    theoryAnchor: 'dai-basics',
    check: (s) => c(s).uplinkArpTrusted,
  },
  {
    id: 'saved-config',
    label: 'Save the configuration',
    description: 'copy running-config startup-config.',
    theoryAnchor: 'dhcp-snooping-basics',
    check: (s) => c(s).savedToStartup,
  },
]
