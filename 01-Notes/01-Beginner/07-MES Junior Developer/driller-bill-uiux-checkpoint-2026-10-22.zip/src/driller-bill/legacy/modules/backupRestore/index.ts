import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand } from './engine'
import { renderPrompt, withDoSupport } from '../../engine/shell'

export const backupRestoreModule: ModuleDefinition = {
  id: 'backup-restore',
  title: 'Backup, Restore & Config Rollback',
  summary:
    'Back a config up off-box, copy it into flash, and use configure replace with a timed safety net to actually roll back \u2014 not just merge.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
