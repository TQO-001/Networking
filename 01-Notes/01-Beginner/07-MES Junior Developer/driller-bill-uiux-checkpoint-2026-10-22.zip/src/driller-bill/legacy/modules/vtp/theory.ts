import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'vtp-modes',
    title: 'VTP Modes',
    commandRef: 'vtp mode <server|client|transparent>',
    body: [
      'Server (default): can create/modify/delete VLANs, changes propagate domain-wide. Client: only receives updates, can\u2019t originate changes \u2014 but can still receive and apply a bad higher-revision update from elsewhere. Transparent: does NOT participate in synchronization at all; VLANs are configured locally only, though the switch still relays VTP advertisements through on trunk ports.',
    ],
  },
  {
    id: 'revision-trap',
    title: 'The Revision Number Trap',
    commandRef: 'show vtp status',
    body: [
      'Every VLAN change increments the VTP configuration revision number, and the switch with the HIGHER revision number wins when two switches in the same domain compare notes \u2014 regardless of which one is actually current. A stale switch pulled from storage with an old but high revision number can silently overwrite a live domain\u2019s VLAN database the moment it\u2019s connected.',
    ],
  },
  {
    id: 'transparent-default',
    title: 'Why Many Networks Just Use Transparent',
    commandRef: 'vtp mode transparent',
    body: [
      'Transparent mode removes the propagation risk entirely at the cost of configuring VLANs manually on every switch. Given how damaging a revision-number incident can be, many production environments consider that trade worth making by default.',
    ],
  },
]
