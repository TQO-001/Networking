import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'storage-split',
    title: 'Two Separate Storage Locations',
    commandRef: 'dir flash: / show flash:',
    body: [
      'startup-config lives in NVRAM. VLAN and VTP information lives in a completely separate binary file, vlan.dat, in flash. These are two different storage locations, erased by two different commands.',
      'Checking flash contents first (dir flash:) confirms whether vlan.dat is even present before you try to delete it, and gives you a baseline of what\u2019s actually on this switch.',
    ],
  },
  {
    id: 'erase-sequence',
    title: 'Erasing NVRAM',
    commandRef: 'erase startup-config',
    body: [
      'This removes hostname, passwords, interface config, SVIs \u2014 everything that lives in startup-config. It does NOT touch vlan.dat, which is the whole reason this drill has a separate deletion step.',
      'IOS always asks for confirmation before erasing \u2014 pressing Enter (a blank response) accepts the default, which is to proceed.',
    ],
  },
  {
    id: 'delete-vlan-dat',
    title: 'Deleting vlan.dat',
    commandRef: 'delete flash:vlan.dat',
    body: [
      'This is the step people skip. Without it, a switch that "looks" reset (no hostname, no passwords) still carries every old VLAN and a live VTP configuration revision number.',
      'A stale but high VTP revision number, added later to a live VTP domain, can be treated as more authoritative than switches that have been running fine for months \u2014 silently overwriting their VLAN databases. This is a well-documented real-world outage cause.',
      'IOS asks for confirmation twice here: once to confirm the filename, once to confirm the deletion itself.',
    ],
  },
  {
    id: 'reload-save-answer',
    title: 'Why You Must Answer "no" on Reload',
    commandRef: 'reload',
    body: [
      'reload always asks "Save?" if running-config differs from startup-config \u2014 which it will, right after an erase.',
      'Answering "yes" here re-saves the current running-config back into startup-config, completely undoing the erase you just did. Answering "no" is what makes the erase actually stick.',
      'This is arguably the single most common mistake in this whole procedure: doing everything right, then reflexively answering "yes" to a save prompt out of habit.',
    ],
  },
]
