import type { EngineState, Objective } from '../../types'
import type { VtpCustomState } from './state'

function c(state: EngineState): VtpCustomState {
  return state.custom as VtpCustomState
}

export const objectives: Objective[] = [
  {
    id: 'set-transparent-mode',
    label: 'Set VTP mode to transparent',
    description: 'The safer default that avoids the revision-number risk.',
    theoryAnchor: 'transparent-default',
    check: (s) => c(s).vtpMode === 'transparent',
  },
  {
    id: 'created-named-vlan',
    label: 'Create and name a local VLAN',
    description: 'vlan 10 / name SALES.',
    theoryAnchor: 'vtp-modes',
    check: (s) => c(s).vlans[10]?.name === 'SALES',
  },
  {
    id: 'checked-vtp-status',
    label: 'Verify with show vtp status',
    description: 'Confirm mode and revision number before trusting this switch.',
    theoryAnchor: 'revision-trap',
    check: (s) => c(s).checkedStatus,
  },
  {
    id: 'saved-config',
    label: 'Save the configuration',
    description: 'copy running-config startup-config.',
    theoryAnchor: 'vtp-modes',
    check: (s) => c(s).savedToStartup,
  },
]
