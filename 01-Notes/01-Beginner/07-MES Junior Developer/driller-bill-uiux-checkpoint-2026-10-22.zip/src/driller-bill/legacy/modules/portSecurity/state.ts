export interface PortSecurityCustomState {
  currentInterface: string | null
  accessMode: boolean
  accessVlan: number | null
  portSecurityEnabled: boolean
  maximum: number | null
  stickyEnabled: boolean
  violationMode: 'protect' | 'restrict' | 'shutdown' | null
  noShutdown: boolean
  errdisableCauses: string[]
  errdisableIntervalSet: boolean
  configuredAutoRecovery: boolean
  savedToStartup: boolean
}

export function initialPortSecurityCustom(): PortSecurityCustomState {
  return {
    currentInterface: null,
    accessMode: false,
    accessVlan: null,
    portSecurityEnabled: false,
    maximum: null,
    stickyEnabled: false,
    violationMode: null,
    noShutdown: false,
    errdisableCauses: [],
    errdisableIntervalSet: false,
    configuredAutoRecovery: false,
    savedToStartup: false,
  }
}
