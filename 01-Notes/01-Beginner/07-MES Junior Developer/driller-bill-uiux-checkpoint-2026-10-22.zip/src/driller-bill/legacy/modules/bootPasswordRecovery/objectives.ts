import type { EngineState, Objective } from '../../types'
import type { BootRecoveryCustomState } from './state'

function c(state: EngineState): BootRecoveryCustomState {
  return state.custom as BootRecoveryCustomState
}

export const objectives: Objective[] = [
  {
    id: 'set-confreg-2142',
    label: 'Set the register to bypass startup-config',
    description: 'confreg 0x2142 in ROMMON.',
    theoryAnchor: 'config-register',
    check: (s) => c(s).confregSet2142,
  },
  {
    id: 'reset-boot',
    label: 'Reboot with the new register value',
    description: 'The "reset" command in ROMMON.',
    theoryAnchor: 'config-register',
    check: (s) => c(s).bypassedBoot,
  },
  {
    id: 'loaded-old-config',
    label: 'Load the old config into memory',
    description: 'copy startup-config running-config.',
    theoryAnchor: 'recovery-flow',
    check: (s) => c(s).oldConfigLoaded,
  },
  {
    id: 'set-new-secret',
    label: 'Set a new enable secret',
    description: 'Don\u2019t leave the switch with no privileged-mode password.',
    theoryAnchor: 'recovery-flow',
    check: (s) => c(s).newEnableSecretSet,
  },
  {
    id: 'restored-register',
    label: 'Restore the config-register to 0x2102',
    description: 'The step people forget \u2014 skip it and this happens every reboot forever.',
    theoryAnchor: 'restore-register',
    check: (s) => c(s).registerRestored,
  },
  {
    id: 'saved-final',
    label: 'Save the recovered configuration',
    description: 'copy running-config startup-config.',
    theoryAnchor: 'recovery-flow',
    check: (s) => c(s).savedFinal,
  },
  {
    id: 'reloaded-clean',
    label: 'Reload and confirm it comes up clean',
    description: 'Only true recovery if the register was actually restored first.',
    theoryAnchor: 'restore-register',
    check: (s) => c(s).reloaded && c(s).registerRestored,
  },
]
