import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'cdp-basics',
    title: 'CDP',
    commandRef: 'show cdp neighbors detail',
    body: [
      'Cisco-proprietary, Layer 2, enabled by default on every port. Advertises device ID, platform, IOS version, IP, and port ID to directly connected Cisco neighbors \u2014 genuinely one of the most-used diagnostic commands day to day, especially on an undocumented network.',
      'Only shows directly connected, one-hop neighbors \u2014 to map a larger topology you have to walk from switch to switch.',
    ],
  },
  {
    id: 'lldp-basics',
    title: 'LLDP',
    commandRef: 'lldp run',
    body: [
      'The vendor-neutral IEEE standard equivalent, needed when the neighbor isn\u2019t Cisco. Not enabled by default on most Cisco platforms \u2014 needs "lldp run" globally first.',
    ],
  },
  {
    id: 'cdp-security',
    title: 'Security Consideration',
    commandRef: 'no cdp enable',
    body: [
      'CDP/LLDP advertisements leak device model, IOS version, and hostname to anything connected to that port \u2014 disable CDP per-interface on any port facing an untrusted network.',
    ],
  },
]
