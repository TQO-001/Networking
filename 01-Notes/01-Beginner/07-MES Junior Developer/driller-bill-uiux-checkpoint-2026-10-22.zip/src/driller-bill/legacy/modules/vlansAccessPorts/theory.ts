import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'vlan-basics',
    title: 'VLANs Are Broadcast Domains',
    commandRef: 'vlan <id> / name <name>',
    body: [
      'A VLAN is a broadcast domain enforced in hardware \u2014 the MAC address table is keyed by VLAN ID + MAC, so frames only forward within the same VLAN. VLAN 1 exists on every port by default; best practice is to never carry real user data on it.',
      'VLANs live in vlan.dat in flash, not in the text config \u2014 that\u2019s why erasing startup-config alone doesn\u2019t remove them (see the Factory Reset module).',
    ],
  },
  {
    id: 'access-ports',
    title: 'Access Ports',
    commandRef: 'switchport mode access / switchport access vlan <id>',
    body: [
      'An access port belongs to exactly one VLAN. Frames arrive/leave untagged \u2014 the end device never sees any VLAN tagging on this kind of link.',
      'switchport nonegotiate disables DTP on the port so it never accidentally negotiates into a trunk.',
    ],
  },
]
