import type { EngineState, Objective } from '../../types'
import type { VlansCustomState } from './state'

function c(state: EngineState): VlansCustomState {
  return state.custom as VlansCustomState
}

export const objectives: Objective[] = [
  {
    id: 'created-named-vlan10',
    label: 'Create and name VLAN 10',
    description: 'vlan 10 / name SALES.',
    theoryAnchor: 'vlan-basics',
    check: (s) => c(s).vlans[10]?.name === 'SALES',
  },
  {
    id: 'created-named-vlan20',
    label: 'Create and name VLAN 20',
    description: 'vlan 20 / name ENGINEERING.',
    theoryAnchor: 'vlan-basics',
    check: (s) => c(s).vlans[20]?.name === 'ENGINEERING',
  },
  {
    id: 'created-vlan-range',
    label: 'Create VLANs 30, 40, 50 with range syntax',
    description: 'vlan 30,40,50.',
    theoryAnchor: 'vlan-basics',
    check: (s) => !!c(s).vlans[30] && !!c(s).vlans[40] && !!c(s).vlans[50],
  },
  {
    id: 'assigned-single-port',
    label: 'Assign Fa0/1 to VLAN 10',
    description: 'Access mode, VLAN 10, no shutdown.',
    theoryAnchor: 'access-ports',
    check: (s) => {
      const p = c(s).ports['fastethernet0/1']
      return p?.mode === 'access' && p?.vlan === 10 && !!p?.noShutdown
    },
  },
  {
    id: 'assigned-port-range',
    label: 'Assign Fa0/2\u201310 to VLAN 20',
    description: 'The whole range, access mode, VLAN 20.',
    theoryAnchor: 'access-ports',
    check: (s) => {
      const cs = c(s)
      for (let n = 2; n <= 10; n++) {
        const p = cs.ports[`fastethernet0/${n}`]
        if (!p || p.mode !== 'access' || p.vlan !== 20) return false
      }
      return true
    },
  },
  {
    id: 'saved-config',
    label: 'Save the configuration',
    description: 'copy running-config startup-config.',
    theoryAnchor: 'vlan-basics',
    check: (s) => c(s).savedToStartup,
  },
]
