import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'why-etherchannel',
    title: 'Why EtherChannel',
    commandRef: 'channel-group <id> mode active',
    body: [
      'Bundling 2\u20138 physical links into one logical Port-channel gives combined bandwidth and redundancy without Spanning Tree blocking all but one of the redundant links \u2014 STP sees a single logical link, not several parallel ones.',
    ],
  },
  {
    id: 'lacp-modes',
    title: 'LACP Modes',
    commandRef: 'active / passive',
    body: [
      'LACP is the standards-based negotiation protocol \u2014 both sides exchange LACPDUs to confirm they agree on bundling before traffic flows. active sends LACPDUs and initiates; passive only responds. At least one side must be active, or nothing ever negotiates.',
    ],
  },
  {
    id: 'matching-config',
    title: 'Member Ports Must Match',
    commandRef: 'interface range ... (configure BEFORE bundling)',
    body: [
      'All member ports need identical config \u2014 same trunk/access mode, allowed VLANs, native VLAN \u2014 before you bundle them. A mismatch causes the port to be suspended rather than joining the bundle, which is the switch protecting you from a broken aggregation.',
    ],
  },
]
