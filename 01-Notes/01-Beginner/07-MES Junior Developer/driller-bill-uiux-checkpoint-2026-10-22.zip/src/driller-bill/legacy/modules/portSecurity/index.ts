import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand } from './engine'
import { renderPrompt, withDoSupport } from '../../engine/shell'

export const portSecurityModule: ModuleDefinition = {
  id: 'port-security',
  title: 'Port Security Fundamentals',
  summary: 'Lock an access port down to a limited number of sticky-learned MAC addresses, with a restrict violation policy and auto-recovery backstop.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
