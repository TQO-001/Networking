import type { EngineState, Objective } from '../../types'
import type { SpanningTreeCustomState } from './state'

function c(state: EngineState): SpanningTreeCustomState {
  return state.custom as SpanningTreeCustomState
}

export const objectives: Objective[] = [
  {
    id: 'set-root-primary',
    label: 'Claim the root bridge role',
    description: 'spanning-tree vlan <ids> root primary.',
    theoryAnchor: 'root-election',
    check: (s) => c(s).rootPrimarySet,
  },
  {
    id: 'enabled-portfast',
    label: 'Enable PortFast on the edge port',
    description: 'On an access port only.',
    theoryAnchor: 'portfast',
    check: (s) => c(s).portfastEnabled,
  },
  {
    id: 'enabled-bpduguard',
    label: 'Enable BPDU Guard',
    description: 'The safety net for PortFast.',
    theoryAnchor: 'bpduguard',
    check: (s) => c(s).bpduguardEnabled,
  },
  {
    id: 'checked-summary',
    label: 'Verify with show spanning-tree summary',
    description: 'Confirm the configuration actually took.',
    theoryAnchor: 'root-election',
    check: (s) => c(s).checkedSummary,
  },
  {
    id: 'saved-config',
    label: 'Save the configuration',
    description: 'copy running-config startup-config.',
    theoryAnchor: 'root-election',
    check: (s) => c(s).savedToStartup,
  },
]
