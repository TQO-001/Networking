import type { CommandResult, EngineState, Objective } from '../../types'
import {
  AMBIGUOUS_COMMAND,
  INCOMPLETE_COMMAND,
  INVALID_INPUT,
  applyIncludeFilter,
  popMode,
  resolveWord,
  splitPipe,
} from '../../engine/shell'
import { initialInterfaceTsCustom, type InterfaceTsCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialInterfaceTsCustom(),
  }
}

function c(state: EngineState): InterfaceTsCustomState {
  return state.custom as InterfaceTsCustomState
}
function withCustom(state: EngineState, patch: Partial<InterfaceTsCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}
function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}
function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}

function normalizeIface(token: string): string | null {
  const m = token.toLowerCase().match(/^(fa|fastethernet)0?\/?(\d+)$/) || token.toLowerCase().match(/^(fastethernet|fa)\s*0\/(\d+)$/)
  if (m) return `fastethernet0/${m[2]}`
  const m2 = token.toLowerCase().match(/^fastethernet0\/(\d+)$/)
  if (m2) return `fastethernet0/${m2[1]}`
  return null
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()
  const cs = c(state)

  if (trimmed === '') return ok(state, [])
  const { base, filterSpec } = splitPipe(trimmed)
  const tokens = base.split(/\s+/)
  const first = tokens[0].toLowerCase()

  if (first === 'end') return ok({ ...state, mode: 'privileged', awaitingInput: null }, [])
  if (resolveWord(first, ['exit']) === 'exit') {
    if (state.mode === 'user') return ok(state, [])
    if (state.mode === 'privileged') return ok({ ...state, mode: 'user' }, [])
    return ok({ ...state, mode: popMode(state.mode) }, [])
  }
  if (first === '?') return ok(state, [helpFor(state)])

  // "do <privileged command>" from within global/interface config
  if (first === 'do') {
    const inner = base.slice(base.indexOf('do') + 2).trim()
    const result = handleCommand((filterSpec ? inner + ' | ' + filterSpec : inner), { ...state, mode: 'privileged' }, _objectives)
    return { ...result, state: { ...result.state, mode: state.mode } }
  }

  if (state.mode === 'user') {
    const word = resolveWord(first, ['enable'])
    if (word === 'enable') return ok({ ...state, mode: 'privileged' }, [])
    if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in user EXEC mode. Try "enable".`)
  }

  if (state.mode === 'interface') {
    return handleInterfaceMode(tokens, state)
  }

  if (state.mode === 'global') {
    const word = resolveWord(first, ['interface', 'errdisable'])
    if (word === 'interface') {
      const iface = normalizeIface(tokens.slice(1).join(''))
      if (!iface) return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates FastEthernet0/3 and FastEthernet0/5. Try "interface fastethernet0/3".')
      return ok({ ...state, mode: 'interface', custom: { ...cs, currentInterface: iface } }, [])
    }
    if (word === 'errdisable') {
      const sub = resolveWord(tokens[1] ?? '', ['recovery'])
      if (sub !== 'recovery') return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "errdisable recovery cause <cause>" or "errdisable recovery interval <seconds>".')
      const opt = resolveWord(tokens[2] ?? '', ['cause', 'interval'])
      if (opt === 'cause') {
        const cause = tokens[3]
        if (!cause) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'errdisable recovery cause needs a cause keyword, e.g. "psecure-violation".')
        const causes = cs.errdisableCauses.includes(cause) ? cs.errdisableCauses : [...cs.errdisableCauses, cause]
        const bothSet = causes.length > 0 && cs.errdisableIntervalSet
        const next = withCustom(state, { errdisableCauses: causes, configuredAutoRecovery: bothSet || cs.configuredAutoRecovery })
        return ok(next, [], bothSet && !cs.configuredAutoRecovery ? 'configured-auto-recovery' : undefined)
      }
      if (opt === 'interval') {
        if (!tokens[3] || !Number.isInteger(Number(tokens[3]))) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'errdisable recovery interval needs a seconds value.')
        const bothSet = cs.errdisableCauses.length > 0
        const next = withCustom(state, { errdisableIntervalSet: true, configuredAutoRecovery: bothSet || cs.configuredAutoRecovery })
        return ok(next, [], bothSet && !cs.configuredAutoRecovery ? 'configured-auto-recovery' : undefined)
      }
      return errFail(state, [INVALID_INPUT], 'syntax', 'Expected "cause" or "interval".')
    }
    if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command in global config mode.')
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in global configuration mode.`)
  }

  // privileged mode
  const word = resolveWord(first, ['show', 'configure', 'copy', 'disable'])

  if (word === 'show') {
    return handleShow(tokens.slice(1), filterSpec, state)
  }
  if (word === 'configure') {
    if (!tokens[1]) return errFail(state, [INCOMPLETE_COMMAND], 'incomplete', 'configure needs an argument, e.g. "configure terminal".')
    const sub = resolveWord(tokens[1], ['terminal'])
    if (sub === 'terminal') return ok({ ...state, mode: 'global' }, ['Enter configuration commands, one per line.  End with CNTL/Z.'])
    return errFail(state, [INVALID_INPUT], 'syntax', 'Only "configure terminal" is supported in this trainer.')
  }
  if (word === 'copy') {
    const rest = tokens.slice(1).join(' ').toLowerCase()
    if (rest === 'running-config startup-config' || rest === 'run start') {
      return ok(withCustom(state, { savedToStartup: true }), ['Building configuration...', '[OK]'], 'saved-config')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "copy running-config startup-config".')
  }
  if (word === 'disable') return ok({ ...state, mode: 'user' }, [])
  if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
  return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in privileged EXEC mode.`)
}

function handleInterfaceMode(tokens: string[], state: EngineState): CommandResult {
  const cs = c(state)
  const iface = cs.currentInterface
  const word = resolveWord(tokens[0], ['speed', 'duplex', 'shutdown', 'no'])

  if (iface === 'fastethernet0/3') {
    if (word === 'speed') {
      const v = Number(tokens[1])
      if (v !== 100 && v !== 10 && v !== 1000) return errFail(state, [INVALID_INPUT], 'syntax', 'speed accepts 10, 100, or 1000.')
      const withSpeed = withCustom(state, { fa3Speed: v })
      const { state: next, objectiveCompleted } = checkDuplexFix(withSpeed)
      return ok(next, [], objectiveCompleted)
    }
    if (word === 'duplex') {
      const d = resolveWord(tokens[1] ?? '', ['half', 'full'])
      if (d !== 'half' && d !== 'full') return errFail(state, [INVALID_INPUT], 'syntax', 'duplex accepts half or full.')
      const withDuplex = withCustom(state, { fa3Duplex: d })
      const { state: next, objectiveCompleted } = checkDuplexFix(withDuplex)
      return ok(next, [], objectiveCompleted)
    }
  }

  if (iface === 'fastethernet0/5') {
    if (word === 'shutdown') {
      return ok(withCustom(state, { fa5ManualShutdown: true }), [])
    }
    if (word === 'no') {
      const sub = resolveWord(tokens[1] ?? '', ['shutdown'])
      if (sub === 'shutdown') {
        if (!cs.fa5ManualShutdown) {
          return errFail(
            state,
            ['(port stays down)'],
            'wrong-order',
            'This port was err-disabled, not manually shut down \u2014 cycling shutdown/no shutdown is still the right recovery mechanic, but do the "shutdown" step first so the interface state actually resets.',
            'recovered-port',
            'errdisable-recovery',
          )
        }
        const next = withCustom(state, { fa5ManualShutdown: false, fa5ErrDisabled: false, recoveredPort: true })
        return ok(next, ['%LINK-3-UPDOWN: Interface FastEthernet0/5, changed state to up'], 'recovered-port')
      }
    }
  }

  if (!iface) return errFail(state, [INVALID_INPUT], 'wrong-mode', 'No interface context \u2014 this shouldn\u2019t happen; try exiting and re-entering the interface.')
  if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
  return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set for ${iface}.`)
}

function checkDuplexFix(state: EngineState): { state: EngineState; objectiveCompleted?: string } {
  const cs = c(state)
  if (cs.fa3Speed === 100 && cs.fa3Duplex === 'full' && !cs.fixedDuplexMismatch) {
    return { state: withCustom(state, { fixedDuplexMismatch: true }), objectiveCompleted: 'fixed-duplex-mismatch' }
  }
  return { state }
}

function handleShow(args: string[], filterSpec: string | null, state: EngineState): CommandResult {
  const cs = c(state)
  const target = args.join(' ').toLowerCase()
  let lines: string[]
  let objectiveCompleted: string | undefined

  if (target === 'interfaces status') {
    lines = statusListing(cs)
    objectiveCompleted = 'checked-status'
  } else if (target === 'interfaces status err-disabled') {
    lines = statusListing(cs).filter((l) => l.includes('err-disabled') || l.startsWith('Port'))
    objectiveCompleted = 'identified-errdisable-cause'
  } else if (normalizeIface(target.replace(/^interfaces\s+/, '')) === 'fastethernet0/3' && target.startsWith('interfaces')) {
    lines = fa3Detail(cs)
    objectiveCompleted = 'checked-interface-detail'
  } else if (normalizeIface(target.replace(/^interfaces\s+/, '')) === 'fastethernet0/5' && target.startsWith('interfaces')) {
    lines = fa5Detail(cs)
    objectiveCompleted = 'checked-interface-detail'
  } else if (target === 'port-security interface fastethernet0/5') {
    lines = [
      'Port Security              : Enabled',
      'Port Status                : Secure-shutdown',
      'Violation Mode             : Shutdown',
      'Maximum MAC Addresses      : 1',
      'Total MAC Addresses        : 2',
      'Security Violation Count   : 1',
    ]
    objectiveCompleted = 'identified-errdisable-cause'
  } else if (target === 'running-config interface fastethernet0/5') {
    lines = [
      'Building configuration...',
      '',
      'interface FastEthernet0/5',
      ' switchport mode access',
      ' switchport port-security',
      ' no shutdown',
      'end',
    ]
    objectiveCompleted = 'checked-interface-detail'
  } else {
    return errFail(
      state,
      [INVALID_INPUT],
      'syntax',
      'This trainer simulates: show interfaces status, show interfaces fastethernet0/3, show interfaces fastethernet0/5, show port-security interface fastethernet0/5, show running-config interface fastethernet0/5.',
    )
  }

  if (filterSpec) lines = applyIncludeFilter(lines, filterSpec)

  let nextState = state
  if (objectiveCompleted === 'checked-status' && !cs.checkedStatus) {
    nextState = withCustom(nextState, { checkedStatus: true })
  } else if (objectiveCompleted === 'checked-interface-detail' && !cs.checkedInterfaceDetail) {
    nextState = withCustom(nextState, { checkedInterfaceDetail: true })
  } else if (objectiveCompleted === 'identified-errdisable-cause' && !cs.identifiedErrDisableCause) {
    nextState = withCustom(nextState, { identifiedErrDisableCause: true })
  } else {
    objectiveCompleted = undefined // don't re-signal an objective that was already met
  }

  return ok(nextState, lines, objectiveCompleted)
}

function statusListing(cs: InterfaceTsCustomState): string[] {
  const fa3Line = cs.fixedDuplexMismatch
    ? 'Fa0/3     connected    10         a-full a-100'
    : 'Fa0/3     connected    10         a-half a-10'
  const fa5Line = cs.fa5ErrDisabled ? 'Fa0/5     err-disabled 10         auto   auto' : 'Fa0/5     connected    10         auto   auto'
  return [
    'Port      Status       Vlan       Duplex Speed',
    'Fa0/1     connected    1          a-full a-100',
    'Fa0/2     notconnect   1          auto   auto',
    fa3Line,
    'Fa0/4     connected    1          a-full a-100',
    fa5Line,
  ]
}

function fa3Detail(cs: InterfaceTsCustomState): string[] {
  const duplex = cs.fa3Duplex === 'full' ? 'Full-duplex' : 'Half-duplex'
  const speed = cs.fa3Speed === 100 ? '100Mb/s' : '10Mb/s'
  return [
    'FastEthernet0/3 is up, line protocol is up',
    `  ${duplex}, ${speed}, media type is 10/100BaseTX`,
    cs.fixedDuplexMismatch
      ? '  0 late collision, 0 CRC, 0 giants, 0 runts'
      : '  47 late collision, 122 CRC, 0 giants, 0 runts',
  ]
}

function fa5Detail(cs: InterfaceTsCustomState): string[] {
  return [
    `FastEthernet0/5 is ${cs.fa5ErrDisabled ? 'down, line protocol is down (err-disabled)' : 'up, line protocol is up'}`,
    '  Full-duplex, 100Mb/s, media type is 10/100BaseTX',
  ]
}

function helpFor(state: EngineState): string {
  if (state.mode === 'user') return 'enable'
  if (state.mode === 'interface') return 'speed, duplex, shutdown, no shutdown, exit'
  if (state.mode === 'global') return 'interface fastethernet0/3, interface fastethernet0/5, errdisable recovery cause <cause>, errdisable recovery interval <seconds>, end, exit'
  return 'show interfaces status, show interfaces <int>, show port-security interface <int>, show running-config interface <int>, configure terminal, copy running-config startup-config'
}
