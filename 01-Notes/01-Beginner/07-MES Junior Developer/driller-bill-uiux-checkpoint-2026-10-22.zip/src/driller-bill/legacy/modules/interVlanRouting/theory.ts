import type { TheorySection } from '../../types'

export const theory: TheorySection[] = [
  {
    id: 'why-routing-needed',
    title: 'Why VLANs Can\u2019t Talk to Each Other Alone',
    commandRef: 'ip routing',
    body: [
      'A Layer 2 switch forwards based on MAC address within a single broadcast domain \u2014 a frame destined for a different VLAN has no Layer 2 path there. Something has to route it at Layer 3.',
    ],
  },
  {
    id: 'svi-routing',
    title: 'SVI Routing',
    commandRef: 'interface vlan <id> / ip address',
    body: [
      'On a multilayer switch, enabling ip routing globally lets every VLAN\u2019s SVI act as that VLAN\u2019s default gateway directly, with routing calculated in hardware. This is the standard approach when a multilayer switch is available \u2014 a Layer-2-only switch (like the IE 3000\u2019s base image) can\u2019t do this and needs router-on-a-stick instead.',
    ],
  },
  {
    id: 'gateway-check',
    title: 'The First Thing to Check When It Doesn\u2019t Work',
    commandRef: 'show ip route',
    body: [
      'Ping from the switch itself to a host in each VLAN first. If that works but end-device-to-end-device pings don\u2019t, the problem is almost always the end device\u2019s configured default gateway, not the routing config.',
    ],
  },
]
