import type { CommandResult, EngineState, Objective } from '../../types'
import { AMBIGUOUS_COMMAND, INVALID_INPUT, resolveWord } from '../../engine/shell'
import { initialFactoryResetCustom, type FactoryResetCustomState } from './state'

export function createInitialState(): EngineState {
  return {
    mode: 'user',
    previousMode: null,
    hostname: 'Switch',
    awaitingInput: null,
    custom: initialFactoryResetCustom(),
  }
}

function c(state: EngineState): FactoryResetCustomState {
  return state.custom as FactoryResetCustomState
}

function withCustom(state: EngineState, patch: Partial<FactoryResetCustomState>): EngineState {
  return { ...state, custom: { ...c(state), ...patch } }
}

function ok(state: EngineState, output: string[] = [], objectiveCompleted?: string): CommandResult {
  return { output, state, objectiveCompleted }
}

function errFail(
  state: EngineState,
  output: string[],
  category: 'syntax' | 'wrong-mode' | 'wrong-order' | 'incomplete' | 'ambiguous',
  message: string,
  relatedObjectiveId?: string,
  theoryAnchor?: string,
): CommandResult {
  return { output, state, error: { category, message, relatedObjectiveId, theoryAnchor } }
}

function isYes(input: string): boolean {
  const t = input.trim().toLowerCase()
  return t === '' || t === 'y' || t === 'yes'
}
function isNo(input: string): boolean {
  const t = input.trim().toLowerCase()
  return t === 'n' || t === 'no'
}

export function handleCommand(raw: string, state: EngineState, _objectives: Objective[]): CommandResult {
  const trimmed = raw.trim()

  // --- Confirmation sequences, checked before the generic empty-input
  // short-circuit, since a blank Enter is a valid (and common) answer. ---
  if (state.awaitingInput === 'erase-confirm') {
    if (isNo(trimmed)) {
      return ok({ ...state, awaitingInput: null }, ['Erase cancelled by user.'])
    }
    const next = withCustom({ ...state, awaitingInput: null }, { nvramErased: true })
    return ok(next, [], 'erased-nvram')
  }

  if (state.awaitingInput === 'delete-filename-confirm') {
    // Accept blank (default filename) or an explicit "vlan.dat".
    if (trimmed === '' || trimmed.toLowerCase() === 'vlan.dat') {
      return ok({ ...state, awaitingInput: 'delete-file-confirm' }, ['Delete flash:vlan.dat? [confirm]'])
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'Expected to confirm the filename "vlan.dat" (or just press Enter to accept the default).', 'deleted-vlan-dat', 'delete-vlan-dat')
  }

  if (state.awaitingInput === 'delete-file-confirm') {
    if (isNo(trimmed)) {
      return ok({ ...state, awaitingInput: null }, ['Delete cancelled.'])
    }
    const next = withCustom({ ...state, awaitingInput: null }, { vlanDatDeleted: true })
    return ok(next, [], 'deleted-vlan-dat')
  }

  if (state.awaitingInput === 'reload-save-answer') {
    if (isYes(trimmed) && trimmed.trim() !== '') {
      // Explicit "yes" (blank doesn't default here \u2014 real IOS requires
      // an explicit yes/no on this particular prompt).
      const next = withCustom({ ...state, awaitingInput: 'reload-confirm' }, { nvramErased: false, reloadSaveAnsweredNo: false })
      return errFail(
        next,
        ['Building configuration...', '[OK]', 'Proceed with reload? [confirm]'],
        'wrong-order',
        'Answering "yes" here re-saved running-config into startup-config \u2014 that undoes the erase from earlier in this drill.',
        'answered-no-to-save',
        'reload-save-answer',
      )
    }
    if (isNo(trimmed)) {
      const next = withCustom({ ...state, awaitingInput: 'reload-confirm' }, { reloadSaveAnsweredNo: true })
      return ok(next, ['Proceed with reload? [confirm]'])
    }
    return errFail(state, ['% Please answer yes or no.'], 'syntax', 'The reload save prompt needs an explicit "yes" or "no" answer.')
  }

  if (state.awaitingInput === 'reload-confirm') {
    if (isNo(trimmed)) {
      return ok({ ...state, awaitingInput: null }, ['Reload cancelled.'])
    }
    const next = withCustom({ ...state, mode: 'user', awaitingInput: null }, { reloaded: true })
    return ok(
      next,
      [
        '',
        '%SYS-5-RELOAD: Reload requested.',
        'System Bootstrap...',
        'Base ethernet MAC Address: 00:1A:2B:3C:4D:5E',
        '...',
        'Press RETURN to get started!',
      ],
      'reloaded',
    )
  }

  if (trimmed === '') return ok(state, [])
  const tokens = trimmed.split(/\s+/)
  const first = tokens[0].toLowerCase()

  if (first === '?') return ok(state, [helpFor(state)])

  if (state.mode === 'user') {
    const word = resolveWord(first, ['enable'])
    if (word === 'enable') return ok({ ...state, mode: 'privileged' }, [])
    if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
    return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t recognized in user EXEC mode. Try "enable".`)
  }

  // privileged mode is the only other mode this module uses
  const word = resolveWord(first, ['dir', 'show', 'erase', 'delete', 'reload', 'disable'])

  if (word === 'dir') {
    const target = tokens.slice(1).join(' ').toLowerCase()
    if (target === 'flash:' || target === 'flash') {
      return ok(withCustom(state, { flashChecked: true }), flashListing(), 'checked-flash')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "dir flash:".')
  }

  if (word === 'show') {
    const target = tokens.slice(1).join(' ').toLowerCase()
    if (target === 'flash:' || target === 'flash') {
      return ok(withCustom(state, { flashChecked: true }), flashListing(), 'checked-flash')
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "show flash:".')
  }

  if (word === 'erase') {
    const target = tokens.slice(1).join(' ').toLowerCase()
    if (target === 'startup-config' || target === 'nvram:startup-config') {
      return ok(
        { ...state, awaitingInput: 'erase-confirm' },
        ['Erasing the nvram filesystem will remove all configuration files! Continue? [confirm]'],
      )
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "erase startup-config".')
  }

  if (word === 'delete') {
    const target = tokens.slice(1).join(' ').toLowerCase()
    if (target === 'flash:vlan.dat' || target === 'vlan.dat') {
      return ok({ ...state, awaitingInput: 'delete-filename-confirm' }, ['Delete filename [vlan.dat]?'])
    }
    return errFail(state, [INVALID_INPUT], 'syntax', 'This trainer simulates "delete flash:vlan.dat".')
  }

  if (word === 'reload') {
    const cs = c(state)
    const preface: string[] = []
    const warnings: CommandResult['error'] | undefined = !cs.vlanDatDeleted
      ? {
          category: 'wrong-order',
          message: 'Reloading without deleting flash:vlan.dat first leaves the old VLAN database (and its VTP revision number) intact \u2014 this switch would still carry the VTP revision trap if redeployed.',
          relatedObjectiveId: 'deleted-vlan-dat',
          theoryAnchor: 'delete-vlan-dat',
        }
      : !cs.nvramErased
      ? {
          category: 'wrong-order',
          message: 'Reloading without erasing startup-config first means this reload will just reboot back into the existing configuration \u2014 nothing was actually reset.',
          relatedObjectiveId: 'erased-nvram',
          theoryAnchor: 'erase-sequence',
        }
      : undefined

    const next = { ...state, awaitingInput: 'reload-save-answer' as const }
    const out = [...preface, 'System configuration has been modified. Save? [yes/no]:']
    if (warnings) return { output: out, state: next, error: warnings }
    return ok(next, out)
  }

  if (word === 'disable') return ok({ ...state, mode: 'user' }, [])
  if (word === 'ambiguous') return errFail(state, [AMBIGUOUS_COMMAND, tokens[0]], 'ambiguous', 'That abbreviation matches more than one command here.')
  return errFail(state, [INVALID_INPUT], 'syntax', `"${tokens[0]}" isn\u2019t part of this drill\u2019s command set in privileged EXEC mode.`)
}

function flashListing(): string[] {
  return [
    'Directory of flash:/',
    '',
    '    2  -rwx        4096   Jan 01 2026 00:00:00 +00:00  vlan.dat',
    '    3  -rwx    18620345   Jan 01 2026 00:00:00 +00:00  c2960-lanbasek9-mz.152-7.E5.bin',
    '',
    '32514048 bytes total (13805568 bytes free)',
  ]
}

function helpFor(state: EngineState): string {
  if (state.mode === 'user') return 'enable'
  return 'dir flash:, show flash:, erase startup-config, delete flash:vlan.dat, reload'
}
