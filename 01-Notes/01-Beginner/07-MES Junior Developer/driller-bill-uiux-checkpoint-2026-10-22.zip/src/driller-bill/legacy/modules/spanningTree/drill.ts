import type { DrillStep } from '../../types'

export const drill: DrillStep[] = [
  { command: 'enable', explanation: 'Enter privileged EXEC mode.' },
  { command: 'configure terminal', explanation: 'Enter global configuration mode.' },
  { command: 'spanning-tree vlan 1,10,20,30,40,50,99 root primary', explanation: 'Deliberately claim the root role for this switch \u2014 don\u2019t leave it to chance.', theoryAnchor: 'root-election' },
  { command: 'interface fastethernet0/1', explanation: 'Enter a genuine end-device access port.' },
  { command: 'switchport mode access', explanation: 'Confirm access mode.' },
  { command: 'spanning-tree portfast', explanation: 'Skip the STP delay on this edge port.', theoryAnchor: 'portfast' },
  { command: 'spanning-tree bpduguard enable', explanation: 'The safety net \u2014 always paired with PortFast.', theoryAnchor: 'bpduguard' },
  { command: 'end', explanation: 'Return to privileged EXEC mode.' },
  { command: 'show spanning-tree summary', explanation: 'Verify the configuration.' },
  { command: 'copy running-config startup-config', explanation: 'Save.' },
]
