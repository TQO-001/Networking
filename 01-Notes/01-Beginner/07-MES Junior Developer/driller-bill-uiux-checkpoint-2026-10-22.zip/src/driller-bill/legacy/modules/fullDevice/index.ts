import type { ModuleDefinition } from '../../types'
import { createInitialState, handleCommand, renderPrompt } from './engine'

// Sandbox-only: NOT added to the main `modules` registry, so it never shows
// up in the graded Module Picker / Theory / Simulation / Exercise flow \u2014
// there's no coherent single drill or objective set to grade a full-device
// free-play session against. It only appears as an extra option in
// SandboxView's command-set picker (see App.tsx).
export const fullDeviceModule: ModuleDefinition = {
  id: 'full-device',
  title: 'Full Device (All Commands)',
  summary:
    'Every command from all 15 modules, in one continuous session \u2014 configure VLANs, trunks, port security, SSH, and more, all on the same switch.',
  theory: [],
  drill: [],
  objectives: [],
  createInitialState,
  handleCommand,
  renderPrompt,
}
