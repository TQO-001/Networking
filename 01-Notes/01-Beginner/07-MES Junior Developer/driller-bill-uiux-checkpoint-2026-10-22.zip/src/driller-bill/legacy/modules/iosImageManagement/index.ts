import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand } from './engine'
import { renderPrompt, withDoSupport } from '../../engine/shell'

export const iosImageManagementModule: ModuleDefinition = {
  id: 'ios-image-management',
  title: 'IOS Image & Flash Management',
  summary:
    'Copy a new IOS image in over TFTP, verify it, point the boot variable at it, and reload \u2014 without running out of flash space or losing the change to an unsaved reload.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
