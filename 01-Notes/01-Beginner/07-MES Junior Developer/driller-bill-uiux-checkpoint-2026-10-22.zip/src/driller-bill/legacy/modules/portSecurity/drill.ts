import type { DrillStep } from '../../types'

export const drill: DrillStep[] = [
  { command: 'enable', explanation: 'Enter privileged EXEC mode.' },
  { command: 'configure terminal', explanation: 'Enter global configuration mode.' },
  { command: 'interface fastethernet0/5', explanation: 'Enter the port to secure.' },
  { command: 'switchport mode access', explanation: 'Confirm access mode \u2014 port security needs it.' },
  { command: 'switchport access vlan 10', explanation: 'Assign the VLAN.' },
  { command: 'switchport port-security', explanation: 'Enable port security \u2014 nothing works below this without it.', theoryAnchor: 'port-security-basics' },
  { command: 'switchport port-security maximum 2', explanation: 'Cap the number of secure MACs allowed.', theoryAnchor: 'port-security-basics' },
  { command: 'switchport port-security mac-address sticky', explanation: 'Auto-convert learned MACs into persistent entries.', theoryAnchor: 'sticky-learning' },
  { command: 'switchport port-security violation restrict', explanation: 'Log violations without taking the port down.', theoryAnchor: 'violation-modes' },
  { command: 'no shutdown', explanation: 'Enable the port.' },
  { command: 'exit', explanation: 'Back to global configuration mode.' },
  { command: 'errdisable recovery cause psecure-violation', explanation: 'Set up auto-recovery as a backstop.' },
  { command: 'errdisable recovery interval 300', explanation: 'Auto-recover after 5 minutes.' },
  { command: 'end', explanation: 'Return to privileged EXEC mode.' },
  { command: 'copy running-config startup-config', explanation: 'Save.' },
]
