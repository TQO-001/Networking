import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand } from './engine'
import { renderPrompt, withDoSupport } from '../../engine/shell'

export const interVlanRoutingModule: ModuleDefinition = {
  id: 'inter-vlan-routing',
  title: 'Inter-VLAN Routing',
  summary: 'Enable IP routing and configure SVIs so two VLANs can actually reach each other, not just exist side by side.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
