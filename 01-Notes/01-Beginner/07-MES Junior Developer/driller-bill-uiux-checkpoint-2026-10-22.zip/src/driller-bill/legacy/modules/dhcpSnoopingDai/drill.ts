import type { DrillStep } from '../../types'

export const drill: DrillStep[] = [
  { command: 'enable', explanation: 'Enter privileged EXEC mode.' },
  { command: 'configure terminal', explanation: 'Enter global configuration mode.' },
  { command: 'ip dhcp snooping', explanation: 'Enable DHCP snooping globally.', theoryAnchor: 'dhcp-snooping-basics' },
  { command: 'ip dhcp snooping vlan 10,20', explanation: 'Enable it for the specific VLANs you want protected.', theoryAnchor: 'dhcp-snooping-basics' },
  { command: 'interface gigabitethernet0/1', explanation: 'The uplink facing the real DHCP server.' },
  { command: 'ip dhcp snooping trust', explanation: 'Trust it \u2014 forget this and legitimate DHCP breaks too.', theoryAnchor: 'trust-and-order' },
  { command: 'exit', explanation: 'Back to global configuration mode.' },
  { command: 'interface range fastethernet0/1 - 20', explanation: 'The untrusted end-user ports.' },
  { command: 'ip dhcp snooping limit rate 10', explanation: 'Rate-limit DHCP packets to reduce DoS impact.' },
  { command: 'exit', explanation: 'Back to global configuration mode.' },
  { command: 'ip arp inspection vlan 10,20', explanation: 'Enable DAI for the SAME VLANs as DHCP snooping \u2014 order matters.', theoryAnchor: 'dai-basics' },
  { command: 'interface gigabitethernet0/1', explanation: 'The same uplink.' },
  { command: 'ip arp inspection trust', explanation: 'Trust mirrors the DHCP snooping trust setting.', theoryAnchor: 'dai-basics' },
  { command: 'exit', explanation: 'Back to global configuration mode.' },
  { command: 'interface range fastethernet0/1 - 20', explanation: 'The same untrusted ports.' },
  { command: 'ip arp inspection limit rate 15', explanation: 'Rate-limit ARP packets too.' },
  { command: 'end', explanation: 'Return to privileged EXEC mode.' },
  { command: 'copy running-config startup-config', explanation: 'Save.' },
]
