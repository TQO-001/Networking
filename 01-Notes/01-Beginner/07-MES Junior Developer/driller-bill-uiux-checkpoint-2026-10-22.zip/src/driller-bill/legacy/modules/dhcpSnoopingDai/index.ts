import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand } from './engine'
import { renderPrompt, withDoSupport } from '../../engine/shell'

export const dhcpSnoopingDaiModule: ModuleDefinition = {
  id: 'dhcp-snooping-dai',
  title: 'DHCP Snooping & Dynamic ARP Inspection',
  summary: 'Block rogue DHCP servers and ARP spoofing \u2014 in the right order, with trust and rate-limits configured correctly.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
