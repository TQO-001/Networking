import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand } from './engine'
import { renderPrompt, withDoSupport } from '../../engine/shell'

export const etherchannelLacpModule: ModuleDefinition = {
  id: 'etherchannel-lacp',
  title: 'EtherChannel & LACP',
  summary: 'Bundle two matching trunk ports with LACP active mode, then configure the resulting Port-channel interface.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
