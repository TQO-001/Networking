import type { DrillStep } from '../../types'

export const drill: DrillStep[] = [
  { command: 'enable', explanation: 'Enter privileged EXEC mode.' },
  { command: 'show cdp neighbors', explanation: 'Fast summary of every directly connected CDP neighbor.', theoryAnchor: 'cdp-basics' },
  { command: 'show cdp neighbors detail', explanation: 'Full detail \u2014 IP address, platform, IOS version.', theoryAnchor: 'cdp-basics' },
  { command: 'configure terminal', explanation: 'Enter global configuration mode.' },
  { command: 'lldp run', explanation: 'Enable LLDP globally \u2014 off by default.', theoryAnchor: 'lldp-basics' },
  { command: 'interface fastethernet0/24', explanation: 'A port facing an untrusted network.' },
  { command: 'no cdp enable', explanation: 'Stop leaking device info out this specific port.', theoryAnchor: 'cdp-security' },
  { command: 'end', explanation: 'Return to privileged EXEC mode.' },
  { command: 'show lldp neighbors', explanation: 'Check LLDP-only neighbors now that it\u2019s enabled.', theoryAnchor: 'lldp-basics' },
  { command: 'copy running-config startup-config', explanation: 'Save.' },
]
