import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand, renderPrompt } from './engine'
import { withDoSupport } from '../../engine/shell'

export const bootPasswordRecoveryModule: ModuleDefinition = {
  id: 'boot-password-recovery',
  title: 'Boot Process & Password Recovery',
  summary:
    'Interrupt the boot into ROMMON, bypass startup-config with the register, recover the old config, then restore the register \u2014 the step everyone forgets.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
