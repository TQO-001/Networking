import type { EngineState, Objective } from '../../types'
import type { FactoryResetCustomState } from './state'

function c(state: EngineState): FactoryResetCustomState {
  return state.custom as FactoryResetCustomState
}

export const objectives: Objective[] = [
  {
    id: 'checked-flash',
    label: 'Check flash contents before making changes',
    description: 'Run "dir flash:" (or "show flash:") to see what\u2019s actually there first.',
    theoryAnchor: 'storage-split',
    check: (s) => c(s).flashChecked,
  },
  {
    id: 'erased-nvram',
    label: 'Erase startup-config',
    description: 'NVRAM should end up erased \u2014 and stay erased through the reload.',
    theoryAnchor: 'erase-sequence',
    check: (s) => c(s).nvramErased,
  },
  {
    id: 'deleted-vlan-dat',
    label: 'Delete flash:vlan.dat',
    description: 'The separate VLAN database file needs to be removed too.',
    theoryAnchor: 'delete-vlan-dat',
    check: (s) => c(s).vlanDatDeleted,
  },
  {
    id: 'answered-no-to-save',
    label: 'Answer "no" to the reload save prompt',
    description: 'Answering yes here undoes the erase.',
    theoryAnchor: 'reload-save-answer',
    check: (s) => c(s).reloadSaveAnsweredNo === true,
  },
  {
    id: 'reloaded',
    label: 'Complete the reload',
    description: 'The switch should actually reboot to finish the reset.',
    theoryAnchor: 'reload-save-answer',
    check: (s) => c(s).reloaded,
  },
]
