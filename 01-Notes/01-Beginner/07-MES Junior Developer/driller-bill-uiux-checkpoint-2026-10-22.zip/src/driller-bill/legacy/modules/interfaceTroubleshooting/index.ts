import type { ModuleDefinition } from '../../types'
import { theory } from './theory'
import { drill } from './drill'
import { objectives } from './objectives'
import { createInitialState, handleCommand } from './engine'
import { renderPrompt, withDoSupport } from '../../engine/shell'

export const interfaceTroubleshootingModule: ModuleDefinition = {
  id: 'interface-troubleshooting',
  title: 'Interface Troubleshooting & Err-Disabled Recovery',
  summary:
    'Diagnose a duplex mismatch and recover an err-disabled port \u2014 the most common day-to-day switch task there is.',
  theory,
  drill,
  objectives,
  createInitialState,
  handleCommand: withDoSupport(handleCommand),
  renderPrompt,
}
