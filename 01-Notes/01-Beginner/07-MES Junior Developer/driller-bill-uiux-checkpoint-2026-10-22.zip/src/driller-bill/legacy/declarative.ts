import type { CommandResult, DrillStep, EngineState, ModuleDefinition, Objective, TheorySection } from '../types'

export interface DeclarativeCondition {
  state: string
  equals: unknown
}

export interface DeclarativeObjective {
  id: string
  label: string
  description: string
  theoryAnchor: string
  condition: DeclarativeCondition
}

export interface DeclarativeDrill {
  schemaVersion: 1
  id: string
  title: string
  summary: string
  engineModule: string
  metadata: {
    difficulty: 'beginner' | 'intermediate' | 'advanced'
    category?: 'switch' | 'router' | 'server' | 'firewall'
    estimatedMinutes: number
    topics: string[]
    ccnaDomains?: string[]
    tags?: string[]
  }
  theory: TheorySection[]
  drill: DrillStep[]
  objectives: DeclarativeObjective[]
}

function getPathValue(state: EngineState, path: string): unknown {
  const normalized = path.startsWith('state.') ? path.slice(6) : path
  const parts = normalized.split('.').filter(Boolean)
  let current: unknown = state

  for (const part of parts) {
    if (current === null || current === undefined || typeof current !== 'object') return undefined
    const object = current as Record<string, unknown>
    current = object[part]
  }

  return current
}

function makeObjective(objective: DeclarativeObjective): Objective {
  return {
    id: objective.id,
    label: objective.label,
    description: objective.description,
    theoryAnchor: objective.theoryAnchor,
    check: (state) => getPathValue(state, objective.condition.state) === objective.condition.equals,
  }
}

export function declarativeToModule(
  content: DeclarativeDrill,
  engine: ModuleDefinition,
): ModuleDefinition {
  const objectives = content.objectives.map(makeObjective)

  return {
    ...engine,
    id: content.id,
    title: content.title,
    summary: content.summary,
    theory: content.theory,
    drill: content.drill,
    objectives,
    category: content.metadata.category ?? engine.category,
    difficulty: content.metadata.difficulty ?? engine.difficulty,
    tags: [...(engine.tags ?? []), ...(content.metadata.tags ?? [])],
  }
}

export function loadDeclarativeModules(
  contentFiles: Record<string, unknown>,
  engines: ModuleDefinition[],
): ModuleDefinition[] {
  const engineById = new Map(engines.map((engine) => [engine.id, engine]))
  const result: ModuleDefinition[] = []

  for (const [filename, raw] of Object.entries(contentFiles)) {
    const content = raw as Partial<DeclarativeDrill>
    if (content.schemaVersion !== 1 || !content.engineModule || !content.id) continue
    const engine = engineById.get(content.engineModule)
    if (!engine) {
      console.warn(`[Driller-Bill] ${filename}: unknown engineModule "${content.engineModule}"`)
      continue
    }
    try {
      result.push(declarativeToModule(content as DeclarativeDrill, engine))
    } catch (error) {
      console.warn(`[Driller-Bill] Could not load ${filename}`, error)
    }
  }

  return result
}
