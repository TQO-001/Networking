// Shared contracts for the Driller-Bill simulator, assessment system, and
// local learning analytics. Module engines remain responsible for Cisco IOS
// state transitions; UI and storage consume these stable contracts.

export type ShellMode =
  | 'user'
  | 'privileged'
  | 'global'
  | 'interface'
  | 'interfaceRange'
  | 'lineConsole'
  | 'lineVty'
  | 'vlanConfig'
  | 'special'

export interface EngineState<TCustom = Record<string, any>> {
  mode: ShellMode
  previousMode: ShellMode | null
  hostname: string
  awaitingInput: string | null
  custom: TCustom
}

export type ErrorCategory =
  | 'syntax'
  | 'wrong-mode'
  | 'wrong-order'
  | 'incomplete'
  | 'ambiguous'

export interface ErrorRecord {
  id: string
  timestamp: number
  raw: string
  mode: ShellMode
  category: ErrorCategory
  message: string
  relatedObjectiveId?: string
  theoryAnchor?: string
}

export interface CommandResult {
  output: string[]
  state: EngineState
  error?: Omit<ErrorRecord, 'id' | 'timestamp' | 'raw' | 'mode'>
  objectiveCompleted?: string
}

export interface Objective {
  id: string
  label: string
  description: string
  theoryAnchor: string
  check: (state: EngineState) => boolean
}

export interface TheorySection {
  id: string
  title: string
  body: string[]
  commandRef?: string
}

export interface DrillStep {
  command: string
  explanation: string
  theoryAnchor?: string
}

export interface ModuleDefinition {
  id: string
  category?: DeviceCategory
  deviceLabel?: string
  difficulty?: 'beginner' | 'intermediate' | 'advanced'
  tags?: string[]
  title: string
  summary: string
  theory: TheorySection[]
  drill: DrillStep[]
  objectives: Objective[]
  createInitialState: () => EngineState
  handleCommand: (raw: string, state: EngineState, objectives: Objective[]) => CommandResult
  renderPrompt: (state: EngineState) => string
  terminalLabel?: string
  completionCandidates?: (state: EngineState) => string[]
}

export type ExerciseMode = 'standard' | 'speed'

export type DeviceCategory = 'switch' | 'router' | 'server' | 'firewall'


export interface SpeedDrillScore {
  accuracyPct: number
  speedPct: number
  objectivePct: number
  score: number
  elapsedMs: number
  targetDurationMs: number
  hardLimitMs: number
  timedOut: boolean
}

export interface TwinSessionSnapshot {
  startedAt: number
  finalState: EngineState
  entries: {
    id: string
    timestamp: number
    elapsedMs: number
    prompt: string
    command: string
    outputs: string[]
    modeBefore: ShellMode
    modeAfter: ShellMode
    error?: ErrorRecord
    typo: boolean
  }[]
}

export interface AssessmentReport {
  moduleId: string
  moduleTitle: string
  generatedAt: number
  durationMs: number
  objectivesTotal: number
  objectivesCompleted: number
  completionPct: number
  errors: ErrorRecord[]
  errorsByCategory: Record<ErrorCategory, number>
  weakAreas: { theoryAnchor: string; title: string; count: number }[]
  strengths: string[]
  recommendations: string[]
  mode: ExerciseMode
  speedScore?: SpeedDrillScore
  xpAwarded: number
  twinSession?: TwinSessionSnapshot
}

export interface ModuleProgress {
  attempts: number
  completions: number
  bestScore: number
  bestTimeMs: number | null
  lastCompletedAt: number | null
}

export interface TopicProgress {
  attempts: number
  errors: number
  mastery: number
  lastPracticedAt: number | null
}

export interface LearnerProgress {
  version: 1
  streak: {
    current: number
    longest: number
    lastPracticeDate: string | null
  }
  xp: number
  modules: Record<string, ModuleProgress>
  topics: Record<string, TopicProgress>
  dailyActivity: Record<string, {
    drillsCompleted: number
    minutes: number
    xp: number
  }>
}
