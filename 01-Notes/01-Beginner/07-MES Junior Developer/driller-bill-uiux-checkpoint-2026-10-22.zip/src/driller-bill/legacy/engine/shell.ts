import type { CommandResult, EngineState, Objective, ShellMode } from '../types'

// Splits a raw CLI line into tokens, collapsing whitespace. Good enough for
// every command in these modules — none of them need quoted-string args.
export function tokenize(raw: string): string[] {
  return raw.trim().split(/\s+/).filter(Boolean)
}

// Resolves a possibly-abbreviated token against a candidate word list, the
// way real IOS does: any unambiguous prefix is accepted. Returns the full
// matched word, 'ambiguous' if more than one candidate matches, or null if
// none match.
export function resolveWord(token: string, candidates: string[]): string | 'ambiguous' | null {
  const lower = token.toLowerCase()
  if (candidates.includes(lower)) return lower
  const matches = candidates.filter((c) => c.startsWith(lower))
  if (matches.length === 1) return matches[0]
  if (matches.length > 1) return 'ambiguous'
  return null
}

export function renderPrompt(state: EngineState): string {
  if (state.awaitingInput) return ''
  const host = state.hostname
  switch (state.mode) {
    case 'user':
      return `${host}>`
    case 'privileged':
      return `${host}#`
    case 'global':
      return `${host}(config)#`
    case 'interface':
      return `${host}(config-if)#`
    case 'interfaceRange':
      return `${host}(config-if-range)#`
    case 'lineConsole':
    case 'lineVty':
      return `${host}(config-line)#`
    case 'vlanConfig':
      return `${host}(config-vlan)#`
    case 'special':
      return ''
    default:
      return `${host}>`
  }
}

export const INVALID_INPUT = "% Invalid input detected at '^' marker."
export const INCOMPLETE_COMMAND = '% Incomplete command.'
export const AMBIGUOUS_COMMAND = '% Ambiguous command:'

// Modes from which a plain "exit" returns to the mode above it in the
// config hierarchy, and modes from which "end" jumps straight to privileged.
export function popMode(mode: ShellMode): ShellMode {
  switch (mode) {
    case 'interface':
    case 'interfaceRange':
    case 'lineConsole':
    case 'lineVty':
    case 'vlanConfig':
      return 'global'
    case 'global':
      return 'privileged'
    case 'privileged':
      return 'user'
    default:
      return mode
  }
}

export function isConfigSubmode(mode: ShellMode): boolean {
  return (
    mode === 'interface' ||
    mode === 'interfaceRange' ||
    mode === 'lineConsole' ||
    mode === 'lineVty' ||
    mode === 'vlanConfig'
  )
}

// Wraps a module's handleCommand so "do <privileged command>" works from
// any config submode, without every module having to implement it
// separately. Temporarily forces mode to 'privileged' for the inner call,
// then restores whatever mode the module was actually in.
export function withDoSupport(
  handleCommand: (raw: string, state: EngineState, objectives: Objective[]) => CommandResult,
) {
  return (raw: string, state: EngineState, objectives: Objective[]): CommandResult => {
    const trimmed = raw.trim()
    const m = trimmed.match(/^do\s+(.+)$/i)
    const inConfigContext = state.mode === 'global' || isConfigSubmode(state.mode)
    if (m && inConfigContext) {
      const result = handleCommand(m[1], { ...state, mode: 'privileged' }, objectives)
      return { ...result, state: { ...result.state, mode: state.mode, previousMode: state.previousMode } }
    }
    return handleCommand(raw, state, objectives)
  }
}

// Splits a raw command on the first pipe character, the way IOS output
// filtering works: "show interfaces fa0/3 | include duplex|speed" ->
// base = "show interfaces fa0/3", filterSpec = "include duplex|speed".
export function splitPipe(raw: string): { base: string; filterSpec: string | null } {
  const idx = raw.indexOf('|')
  if (idx === -1) return { base: raw.trim(), filterSpec: null }
  return { base: raw.slice(0, idx).trim(), filterSpec: raw.slice(idx + 1).trim() }
}

// Applies a simple "include <term>|<term>|..." filter to a block of output
// lines (case-insensitive substring match, OR'd across terms). Good enough
// for the "| include duplex|speed" / "| section line vty" style filtering
// used throughout the notes without building a full IOS filter grammar.
export function applyIncludeFilter(lines: string[], filterSpec: string): string[] {
  const words = filterSpec.trim().split(/\s+/)
  const keyword = resolveWord(words[0] ?? '', ['include', 'section'])
  const rest = words.slice(1).join(' ')
  if (!keyword || !rest) return lines
  const terms = rest.split('|').map((t) => t.trim().toLowerCase()).filter(Boolean)
  if (terms.length === 0) return lines
  return lines.filter((l) => terms.some((t) => l.toLowerCase().includes(t)))
}

// Normalizes a Cisco interface reference in any common abbreviation/spacing
// to a canonical "fastethernet0/N" / "gigabitethernet0/N" / "vlanN" /
// "port-channelN" form. Returns null if it doesn't look like an interface.
const IFACE_PREFIXES: [RegExp, string][] = [
  [/^(fa|fastethernet)$/i, 'fastethernet0/'],
  [/^(gi|gigabitethernet)$/i, 'gigabitethernet0/'],
  [/^(te|tengigabitethernet)$/i, 'tengigabitethernet0/'],
  [/^(po|port-channel)$/i, 'port-channel'],
  [/^(vl|vlan)$/i, 'vlan'],
]

export function normalizeInterfaceName(raw: string): string | null {
  const s = raw.trim().toLowerCase().replace(/\s+/g, '')
  // Forms like "fa0/1", "fastethernet0/1", "gi0/1", "vlan99", "po1"
  const m = s.match(/^([a-z-]+)0?\/?(\d+)$/)
  if (!m) return null
  const [, prefix, num] = m
  for (const [re, canon] of IFACE_PREFIXES) {
    if (re.test(prefix)) return `${canon}${num}`
  }
  return null
}

// Expands "fastethernet0/2 - 10" style range tokens (already split on
// whitespace, with "-" as its own token) into a list of normalized
// interface names. Returns null if the tokens don't parse as a range.
export function expandInterfaceRange(tokens: string[]): string[] | null {
  const dashIdx = tokens.indexOf('-')
  if (dashIdx === -1 || dashIdx === 0 || dashIdx === tokens.length - 1) return null
  const startTok = tokens.slice(0, dashIdx).join('')
  const endNum = Number(tokens[dashIdx + 1])
  const start = normalizeInterfaceName(startTok)
  if (!start || !Number.isInteger(endNum)) return null
  const numMatch = start.match(/(\d+)$/)
  if (!numMatch) return null
  const startNum = Number(numMatch[1])
  const prefix = start.slice(0, start.length - numMatch[1].length)
  if (endNum < startNum) return null
  const result: string[] = []
  for (let n = startNum; n <= endNum; n++) result.push(`${prefix}${n}`)
  return result
}


// A permissive, read-mostly IOS compatibility layer. Narrow learning engines are
// still the source of truth for graded state transitions, but this layer prevents
// the frustrating "invalid input" experience for common IOS commands that are
// useful during exploration, verification, and troubleshooting.
export function normalizeIosCommand(raw: string): string {
  return raw.trim().replace(/\s+/g, ' ').replace(/\s+([,|])/g, '$1').toLowerCase()
}


export function iosCompletionCandidates(state: EngineState): string[] {
  if (state.mode === 'user') return ['enable', 'exit']
  if (state.mode === 'privileged') return [
    'configure terminal', 'copy running-config startup-config', 'write memory', 'disable', 'exit',
    'show version', 'show running-config', 'show startup-config', 'show ip interface brief', 'show interfaces',
    'show interfaces status', 'show interfaces trunk', 'show interfaces switchport', 'show vlan brief',
    'show mac address-table', 'show spanning-tree', 'show etherchannel summary', 'show ip route',
    'show ip protocols', 'show arp', 'show cdp neighbors', 'show cdp neighbors detail', 'show lldp neighbors',
    'show ip ssh', 'show vtp status', 'show port-security', 'show ip dhcp snooping', 'show clock', 'show terminal',
    'terminal length 0', 'terminal width 0', 'ping', 'traceroute', 'reload', 'erase startup-config',
  ]
  if (state.mode === 'global') return [
    'hostname', 'interface', 'interface range', 'vlan', 'ip routing', 'ip default-gateway', 'ip address',
    'ip domain-name', 'ip name-server', 'ip ssh version 2', 'no ip domain-lookup', 'service password-encryption',
    'enable secret', 'username', 'crypto key generate rsa', 'line console 0', 'line vty 0 4', 'banner motd',
    'do show running-config', 'end', 'exit',
  ]
  if (state.mode === 'interface' || state.mode === 'interfaceRange') return [
    'description', 'shutdown', 'no shutdown', 'speed', 'duplex', 'switchport mode access',
    'switchport mode trunk', 'switchport access vlan', 'switchport trunk native vlan',
    'switchport trunk allowed vlan', 'switchport nonegotiate', 'spanning-tree portfast',
    'spanning-tree bpduguard enable', 'channel-group', 'ip address', 'ip helper-address', 'no cdp enable',
    'do show running-config', 'end', 'exit',
  ]
  if (state.mode === 'vlanConfig') return ['name', 'state active', 'state suspend', 'exit', 'end']
  if (state.mode === 'lineConsole' || state.mode === 'lineVty') return [
    'login', 'login local', 'password', 'logging synchronous', 'exec-timeout', 'transport input ssh', 'transport input all',
    'access-class', 'end', 'exit',
  ]
  return ['end', 'exit']
}

export function completeIosCommand(raw: string, state: EngineState): string | null {
  const original = raw
  const trimmed = raw.trimStart()
  const lower = trimmed.toLowerCase()
  if (!trimmed) return null
  const candidates = iosCompletionCandidates(state)
  const exact = candidates.find((candidate) => candidate.toLowerCase() === lower)
  if (exact) return exact

  const direct = candidates.filter((candidate) => candidate.toLowerCase().startsWith(lower))
  if (direct.length === 1) return `${original.slice(0, original.length - trimmed.length)}${direct[0]}`

  const tokens = trimmed.split(/\s+/)
  const last = tokens[tokens.length - 1].toLowerCase()
  const samePrefix = candidates.filter((candidate) => {
    const cTokens = candidate.toLowerCase().split(/\s+/)
    if (cTokens.length !== tokens.length) return false
    return cTokens.slice(0, -1).every((token, index) => token === tokens[index].toLowerCase()) && cTokens[cTokens.length - 1].startsWith(last)
  })
  if (samePrefix.length === 1) return `${original.slice(0, original.length - trimmed.length)}${samePrefix[0]}`
  return null
}

/** Return IOS-style inline help candidates for a partially typed command. */
export function iosHelpCandidates(rawPrefix: string, state: EngineState): string[] {
  const original = String(rawPrefix ?? '');
  const prefix = original.trimStart().toLowerCase();
  const candidates = iosCompletionCandidates(state);

  if (!prefix.trim()) {
    return [...new Set(candidates.map((candidate) => candidate.split(/\s+/)[0]))];
  }

  if (/\s$/.test(original)) {
    const base = prefix.trimEnd();
    const matches = candidates
      .filter((candidate) => candidate.toLowerCase().startsWith(`${base} `))
      .map((candidate) => candidate.slice(base.length + 1));
    return [...new Set(matches)];
  }

  return [...new Set(candidates.filter((candidate) => candidate.toLowerCase().startsWith(prefix)))];
}

function isReadOnlyCompatibilityCommand(raw: string): boolean {
  const value = raw.trim().toLowerCase()
  return /^(?:do\s+)?(?:show|ping|traceroute|terminal(?:\s|$)|clear(?:\s+)?$)/.test(value)
}

export function genericIosCommand(raw: string, state: EngineState): CommandResult | null {
  const pipe = splitPipe(raw)
  if (!isReadOnlyCompatibilityCommand(pipe.base) && !state.awaitingInput?.startsWith('generic:')) return null
  if (pipe.filterSpec) {
    const piped = genericIosCommand(pipe.base, state)
    if (!piped) return null
    return { ...piped, output: applyIncludeFilter(piped.output, pipe.filterSpec) }
  }

  const normalized = normalizeIosCommand(raw)
  if (!normalized && state.awaitingInput !== 'generic:copy-start') return { output: [], state }

  const [command, ...args] = normalized.split(' ')
  const argText = args.join(' ')

  if (state.awaitingInput === 'generic:copy-start') {
    return {
      output: ['Building configuration...', '[OK]'],
      state: { ...state, awaitingInput: null, custom: { ...(state.custom as Record<string, unknown>), __generic: { ...(((state.custom as Record<string, unknown>).__generic ?? {}) as Record<string, unknown>), savedAt: Date.now() } } },
    }
  }
  const generic = ((state.custom as Record<string, unknown>).__generic ?? {}) as Record<string, unknown>
  const config = Array.isArray(generic.runningConfig) ? [...generic.runningConfig] as string[] : []
  const nextGeneric = (patch: Record<string, unknown> = {}) => ({
    ...state,
    custom: { ...(state.custom as Record<string, unknown>), __generic: { ...generic, ...patch } },
  })
  const okConfig = (nextState: EngineState, commandLine?: string, output: string[] = []) => {
    if (commandLine) config.push(commandLine)
    const ns = { ...nextState, custom: { ...(nextState.custom as Record<string, unknown>), __generic: { ...generic, runningConfig: config } } }
    return { output, state: ns }
  }

  // Global shell controls. IOS accepts these in many contexts.
  if (command === 'end' || command === '^z') return { output: [], state: { ...state, mode: 'privileged', previousMode: null, awaitingInput: null } }
  if (command === 'exit' || command === 'logout') return { output: [], state: { ...state, mode: popMode(state.mode), awaitingInput: null } }
  if (normalized === '?' || normalized === 'help') return { output: contextHelp(state), state }

  if (state.mode === 'user') {
    if (resolveWord(command, ['enable']) === 'enable') return { output: [], state: { ...state, mode: 'privileged' } }
    if (resolveWord(command, ['show','ping','traceroute']) !== null) return genericIosCommand(`${command} ${argText}`.trim(), { ...state, mode: 'privileged' })
    return null
  }

  if (state.mode === 'privileged') {
    const first = resolveWord(command, ['configure','copy','write','show','clear','ping','traceroute','terminal','disable'])
    if (first === 'configure') {
      if (!args[0]) return { output: [INCOMPLETE_COMMAND], state }
      if (resolveWord(args[0], ['terminal','memory','replace']) === 'terminal') return { output: ['Enter configuration commands, one per line.  End with CNTL/Z.'], state: { ...state, mode: 'global' } }
      if (args[0] === 't') return { output: ['Enter configuration commands, one per line.  End with CNTL/Z.'], state: { ...state, mode: 'global' } }
      return { output: [INVALID_INPUT], state }
    }
    if (first === 'disable') return { output: [], state: { ...state, mode: 'user' } }
    if (first === 'write') {
      const writeArg = argText
      if (!writeArg || /^(memory|mem)$/i.test(writeArg)) return { output: ['Building configuration...', '[OK]'], state: nextGeneric({ savedAt: Date.now(), startupConfig: config }) }
      if (/^(terminal|erase)$/i.test(writeArg)) return { output: [INCOMPLETE_COMMAND], state }
      return { output: [INVALID_INPUT], state }
    }
    if (first === 'copy') {
      if (/^(run|running-config)\s+(start|startup-config)$/.test(argText)) {
        return { output: ['Destination filename [startup-config]?'], state: { ...nextGeneric({ startupConfig: config }), awaitingInput: 'generic:copy-start' } }
      }
      if (/^(startup-config)\s+(running-config|run)$/.test(argText)) return { output: ['Destination filename [running-config]?', '[OK]'], state }
      if (/^running-config\s+(usb|flash|tftp):/i.test(argText)) return { output: ['Destination filename? ', '[OK]'], state }
      return { output: [INCOMPLETE_COMMAND], state }
    }
    if (first === 'terminal') {
      if (!args[0]) return { output: [INCOMPLETE_COMMAND], state }
      if (args[0] === 'length' || args[0] === 'width') return { output: [], state: nextGeneric({ terminalLength: args[1] ?? '24', terminalWidth: args[1] ?? '80' }) }
      if (args[0] === 'monitor' || args[0] === 'no') return { output: [], state }
      return { output: [INVALID_INPUT], state }
    }
    if (first === 'clear') return { output: [''], state }
    if (first === 'show' || first === 'ping' || first === 'traceroute') {
      const result = first === 'show' ? handleGenericShow(argText, state) : handleConnectivity(first, argText, state)
      return result ?? { output: [INVALID_INPUT], state }
    }
  }

  // `do <exec-command>` in configuration contexts.
  if ((state.mode === 'global' || isConfigSubmode(state.mode)) && command === 'do' && argText) {
    const inner = genericIosCommand(argText, { ...state, mode: 'privileged' })
    if (inner) {
      return { ...inner, state: { ...inner.state, mode: state.mode, previousMode: state.previousMode } }
    }
  }

  if (state.mode === 'global') {
    if (command === 'hostname') {
      if (!args[0]) return { output: [INCOMPLETE_COMMAND], state }
      return okConfig({ ...state, hostname: args[0] }, `hostname ${args[0]}`)
    }
    if (command === 'no' && args[0] === 'hostname') return okConfig({ ...state, hostname: 'Switch' }, normalized)
    if (command === 'service') return okConfig(state, normalized)
    if (command === 'ip') {
      if (args[0] === 'routing') return okConfig(state, normalized)
      if (args[0] === 'domain-name' && args[1]) return okConfig(nextGeneric({ domainName: args[1] }), normalized)
      if (args[0] === 'name-server' && args[1]) return okConfig(state, normalized)
      if (args[0] === 'default-gateway' && args[1]) return okConfig(state, normalized)
      if (args[0] === 'ssh' && args[1] === 'version') return okConfig(state, normalized)
    }
    if (command === 'enable' && args[0] === 'secret') return okConfig(nextGeneric({ hasEnableSecret: true }), normalized)
    if (command === 'username' && args.length >= 2) return okConfig(state, normalized.replace(/(secret|password)\s+\S+$/i, '$1 [redacted]'))
    if (command === 'crypto' && args[0] === 'key') return okConfig(nextGeneric({ rsaKeys: true }), normalized)
    if (command === 'banner' && args[0]) return okConfig(nextGeneric({ banner: argText }), normalized)
    if (command === 'line') {
      if (args[0] === 'console' && (args[1] === '0' || !args[1])) return { output: [], state: { ...state, mode: 'lineConsole' } }
      if (args[0] === 'vty') return { output: [], state: { ...state, mode: 'lineVty' } }
    }
    if (command === 'interface') {
      const iface = normalizeInterfaceName(args.join(''))
      if (iface) return { output: [], state: { ...state, mode: 'interface', custom: { ...(state.custom as Record<string, unknown>), __generic: { ...generic, currentInterface: iface } } } }
    }
    if (command === 'vlan' && args[0] && /^\d+$/.test(args[0])) return { output: [], state: { ...state, mode: 'vlanConfig', custom: { ...(state.custom as Record<string, unknown>), __generic: { ...generic, currentVlan: Number(args[0]) } } } }
    if (command === 'ip' && args[0] === 'access-list') return okConfig(state, normalized)
    if (command === 'no') return okConfig(state, normalized)
  }

  if (state.mode === 'lineConsole' || state.mode === 'lineVty') {
    if (command === 'login' || command === 'password' || command === 'logging' || command === 'exec-timeout' || command === 'transport' || command === 'access-class' || command === 'privilege') return okConfig(state, normalized.replace(/(password|secret)\s+\S+$/i, '$1 [redacted]'))
    if (command === 'no') return okConfig(state, normalized)
  }

  if (state.mode === 'vlanConfig') {
    if (command === 'name' && args.length) return okConfig(state, normalized)
    if (command === 'state' && args.length) return okConfig(state, normalized)
  }

  if (state.mode === 'interface' || state.mode === 'interfaceRange') {
    if (command === 'description') return okConfig(state, normalized)
    if (command === 'shutdown' || (command === 'no' && args[0] === 'shutdown')) return okConfig(state, normalized)
    if (command === 'speed' || command === 'duplex' || command === 'switchport' || command === 'spanning-tree' || command === 'channel-group' || command === 'ip' || command === 'no') return okConfig(state, normalized)
  }

  return null
}

function contextHelp(state: EngineState): string[] {
  if (state.mode === 'user') return ['enable', 'exit']
  if (state.mode === 'privileged') return ['configure terminal', 'show ?', 'copy running-config startup-config', 'write memory', 'terminal length 0', 'ping', 'traceroute', 'exit']
  if (state.mode === 'global') return ['hostname', 'interface', 'interface range', 'vlan', 'ip', 'enable secret', 'username', 'crypto', 'line', 'banner', 'service', 'do', 'end', 'exit']
  if (state.mode === 'interface' || state.mode === 'interfaceRange') return ['description', 'shutdown', 'no shutdown', 'switchport', 'switchport mode', 'switchport access vlan', 'speed', 'duplex', 'spanning-tree', 'channel-group', 'ip address', 'do', 'end', 'exit']
  if (state.mode === 'vlanConfig') return ['name', 'exit', 'end']
  if (state.mode === 'lineConsole' || state.mode === 'lineVty') return ['login', 'login local', 'password', 'exec-timeout', 'logging synchronous', 'transport input', 'do', 'end', 'exit']
  return ['end', 'exit']
}

function handleConnectivity(command: string, target: string, _state: EngineState): CommandResult {
  const host = target || (command === 'ping' ? '127.0.0.1' : '127.0.0.1')
  if (command === 'ping') return { output: ['Type escape sequence to abort.', `Sending 5, 100-byte ICMP Echos to ${host}, timeout is 2 seconds:`, '!!!!!', `Success rate is 100 percent (5/5), round-trip min/avg/max = 1/2/4 ms`], state: _state }
  return { output: ['Type escape sequence to abort.', `Tracing the route to ${host}`, '  1  192.168.1.1  1 msec  1 msec  1 msec', `  2  ${host}  2 msec  2 msec  2 msec`], state: _state }
}

function canonicalShowTarget(target: string): string {
  const value = target.trim().toLowerCase().replace(/\s+/g, ' ')
  const aliases: Array<[RegExp, string]> = [
    [/^run(?:ning-config)?$/, 'running-config'],
    [/^start(?:up-config)?$/, 'startup-config'],
    [/^ver(?:sion)?$/, 'version'],
    [/^int(?:erfaces?)?$/, 'interfaces'],
    [/^int(?:erfaces?)?\s+(?:status|brief)$/, value.replace(/^int(?:erfaces?)?\s+/, 'interfaces ')],
    [/^int(?:erface)?\s+brief$/, 'interfaces status'],
    [/^int(?:erfaces?)?\s+brief$/, 'interfaces status'],
    [/^int(?:erfaces?)?\s+(gi|gig|gigabitethernet|fa|fastethernet|te|tengigabitethernet).*/i, value],
    [/^ip\s+int(?:erface)?\s+br(?:ief)?$/, 'ip interface brief'],
    [/^vl(?:an)?\s+br(?:ief)?$/, 'vlan brief'],
    [/^mac(?:-address-table| address-table)?$/, 'mac address-table'],
    [/^mac(?:-address-table| address-table)\s+dyn(?:amic)?$/, 'mac address-table dynamic'],
    [/^ip\s+r(?:oute|outes)?$/, 'ip route'],
    [/^cdp\s+n(?:eighbors?)?$/, 'cdp neighbors'],
    [/^lldp\s+n(?:eighbors?)?$/, 'lldp neighbors'],
    [/^spanning-tree\s+sum(?:mary)?$/, 'spanning-tree summary'],
    [/^clk$/, 'clock'],
    [/^term(?:inal)?$/, 'terminal'],
  ]
  for (const [pattern, replacement] of aliases) if (pattern.test(value)) return replacement
  return value
}

function handleGenericShow(target: string, state: EngineState): CommandResult | null {
  const normalized = canonicalShowTarget(target.trim().toLowerCase())
  const g = ((state.custom as Record<string, unknown>).__generic ?? {}) as Record<string, unknown>
  const genericConfig = Array.isArray(g.runningConfig) ? g.runningConfig as string[] : []
  if (!normalized || normalized === '?') return { output: ['version', 'running-config', 'startup-config', 'ip interface brief', 'interfaces', 'interfaces status', 'vlan brief', 'mac address-table', 'ip route', 'cdp neighbors', 'lldp neighbors', 'spanning-tree', 'clock', 'terminal'], state }
  if (normalized === 'version' || normalized.startsWith('version ')) return { output: ['Cisco IOS Software, Driller-Bill Simulation', 'Compiled for educational use', `Device name: ${state.hostname}`, 'System image file is "flash:driller-bill-sim.bin"', '64K/32K memory', 'Configuration register is 0x2102'], state }
  if (normalized === 'clock') return { output: [`*${new Date().toString()}`], state }
  if (normalized === 'terminal') return { output: [`Line 0, Location: "console"`, `Length: ${String(g.terminalLength ?? 24)} lines, Width: ${String(g.terminalWidth ?? 80)} columns`, `Mode: ${state.mode}`], state }
  if (normalized === 'running-config' || normalized === 'run' || normalized.startsWith('running-config ')) {
    const lines = ['Building configuration...', '!', `hostname ${state.hostname}`, ...genericConfig.map((x) => ` ${x}`), '!', 'end']
    return { output: lines, state }
  }
  if (normalized === 'startup-config' || normalized === 'start') {
    const lines = ['Using 5 out of 32768 bytes', '!', `hostname ${state.hostname}`, ...(Array.isArray(g.startupConfig) ? (g.startupConfig as string[]).map((x) => ` ${x}`) : genericConfig.map((x) => ` ${x}`)), '!', 'end']
    return { output: lines, state }
  }
  const custom = state.custom as Record<string, any>
  const ports = (custom.ports && typeof custom.ports === 'object') ? custom.ports as Record<string, any> : {}
  const vlans = (custom.vlans && typeof custom.vlans === 'object') ? custom.vlans as Record<string, any> : {}
  const svis = (custom.svis && typeof custom.svis === 'object') ? custom.svis as Record<string, any> : {}
  const svi99 = custom.svi99 && typeof custom.svi99 === 'object' ? { ...custom.svi99 } : null
  const physicalPorts = Object.keys(ports).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}))
  const defaultPorts = Array.from({length: 24},(_,i)=>`fastethernet0/${i+1}`)
  const allPorts = [...new Set([...defaultPorts, ...physicalPorts])]
  const portDisplay = (name:string) => name.replace(/^fastethernet/i,'Fa').replace(/^gigabitethernet/i,'Gi').replace(/^tengigabitethernet/i,'Te')
  const portVlan = (name:string) => ports[name]?.vlan ?? 1
  const portUp = (name:string) => ports[name]?.noShutdown === true
  const sviEntries = Object.entries(svis).map(([id,v]:[string,any])=>({id:Number(id), ip:v?.ipAddress ?? 'unassigned', up:!!v?.noShutdown}))
  if (svi99 && !sviEntries.some(x=>x.id===99)) sviEntries.push({id:99, ip:svi99.ipAddress ?? 'unassigned', up:!!svi99.noShutdown})
  sviEntries.sort((a,b)=>a.id-b.id)
  if (normalized === 'ip interface brief' || normalized === 'ip int brief') {
    const lines=['Interface              IP-Address      OK? Method Status                Protocol']
    for (const e of sviEntries) lines.push(`Vlan${e.id}`.padEnd(23)+`${e.ip}`.padEnd(15)+`YES manual ${e.up ? 'up'.padEnd(21) : 'administratively down'.padEnd(22)}${e.up ? 'up' : 'down'}`)
    for (const p of allPorts) lines.push(`${portDisplay(p)}`.padEnd(23)+'unassigned      YES unset  '+(portUp(p)?'up'.padEnd(21):'administratively down'.padEnd(21))+(portUp(p)?'up':'down'))
    return { output: lines, state }
  }
  if (normalized === 'interfaces brief' ) return handleGenericShow('interfaces status', state)
  if (normalized === 'interfaces' || normalized === 'interfaces status') {
    const lines=['Port      Name               Status       Vlan       Duplex  Speed Type']
    for (const p of allPorts) {
      const cfg=ports[p] ?? {}; const status=cfg.noShutdown===false?'disabled':(cfg.vlan!=null||cfg.noShutdown?'connected':'notconnect')
      lines.push(`${portDisplay(p).padEnd(10)}${String(cfg.description??'').slice(0,18).padEnd(19)}${status.padEnd(13)}${String(portVlan(p)).padEnd(11)}a-full   a-100  10/100BaseTX`)
    }
    return { output: lines, state }
  }
  if (normalized === 'vlan brief' || normalized === 'vlan') {
    const ids=[1,...Object.keys(vlans).map(Number),...Object.keys(svis).map(Number)].filter((x,i,a)=>Number.isInteger(x)&&a.indexOf(x)===i).sort((a,b)=>a-b)
    const lines=['VLAN Name                             Status    Ports','---- -------------------------------- --------- -------------------------------']
    for (const id of ids) {
      const name=id===1?'default':(vlans[id]?.name ?? (svis[id] ? `VLAN${id}` : ''))
      const members=allPorts.filter(p=>portVlan(p)===id).map(portDisplay).join(', ')
      lines.push(`${String(id).padEnd(5)}${name.slice(0,32).padEnd(33)}active    ${members}`)
    }
    return { output: lines, state }
  }
  if (normalized === 'mac address-table' || normalized === 'mac address-table dynamic' || normalized === 'mac address-table dynamic interface fa0/1') return { output: [
    '          Mac Address Table',
    '-------------------------------------------',
    'Vlan    Mac Address       Type        Ports',
    '----    -----------       --------    -----',
    '  10    0050.56aa.1001    DYNAMIC     Fa0/1',
    '  20    0050.56aa.2001    DYNAMIC     Fa0/2',
  ], state }
  if (normalized === 'ip route' || normalized === 'ip route summary') return { output: [
    'Codes: C - connected, S - static, R - RIP, O - OSPF, D - EIGRP',
    'Gateway of last resort is not set',
    'C    10.0.0.0/24 is directly connected, Vlan10',
    'C    10.0.1.0/24 is directly connected, Vlan20',
  ], state }
  if (normalized.startsWith('cdp neighbors')) return { output: [
    'Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID',
    'R2               Fa0/1             145        R S I       ISR       Gi0/0',
  ], state }
  if (normalized.startsWith('lldp neighbors')) return { output: [
    'Capability codes: R - Router, B - Bridge, T - Telephone',
    'Device ID        Local Intf     Hold-time  Capability      Port ID',
    'R2               Fa0/1          120        R               Gi0/0',
  ], state }
  if (normalized === 'spanning-tree' || normalized === 'spanning-tree summary') return { output: [
    'VLAN0001', 'Spanning tree enabled protocol rstp', 'Root ID    Priority    32769', '           Address     0000.1111.2222', 'Bridge ID  Priority    32769',
  ], state }
  if (normalized.startsWith('interfaces ') || normalized.startsWith('int ')) {
    const target = normalized.replace(/^interfaces?\s+/,'').trim()
    const canonical = normalizeInterfaceName(target)
    if (canonical && canonical.startsWith('fastethernet')) {
      const cfg = ports[canonical] ?? {}; const up = cfg.noShutdown !== false
      return { output: [
        `${canonical.replace(/^fastethernet/i,'FastEthernet')} is ${up?'up':'administratively down'}, line protocol is ${up?'up':'down'}`,
        `  Hardware is Fast Ethernet, address is 0050.56aa.${canonical.split('/')[1].padStart(4,'0')}`,
        '  MTU 1500 bytes, BW 100000 Kbit/sec',
        `  Description: ${cfg.description ?? '(none set)'}`,
        `  Switchport access VLAN ${cfg.vlan ?? 1}`,
      ], state }
    }
    if (canonical && canonical.startsWith('vlan')) {
      const id=Number(canonical.replace('vlan','')); const cfg=svis[id] ?? (id===99?svi99:null) ?? {}
      return { output: [
        `Vlan${id} is ${cfg.noShutdown?'up':'administratively down'}, line protocol is ${cfg.noShutdown?'up':'down'}`,
        `  Internet address is ${cfg.ipAddress ?? 'unassigned'}`,
        `  Description: ${cfg.description ?? '(none set)'}`,
      ], state }
    }
    return { output: [
      'Interface not found in the current simulator inventory.',
    ], state }
  }
  return null
}
