import { backupRestoreModule } from './legacy/modules/backupRestore/index.ts';
import { basicManagementSetupModule } from './legacy/modules/basicManagementSetup/index.ts';
import { bootPasswordRecoveryModule } from './legacy/modules/bootPasswordRecovery/index.ts';
import { cdpLldpModule } from './legacy/modules/cdpLldp/index.ts';
import { dhcpSnoopingDaiModule } from './legacy/modules/dhcpSnoopingDai/index.ts';
import { etherchannelLacpModule } from './legacy/modules/etherchannelLacp/index.ts';
import { factoryResetModule } from './legacy/modules/factoryReset/index.ts';
import { fullDeviceModule } from './legacy/modules/fullDevice/index.ts';
import { interVlanRoutingModule } from './legacy/modules/interVlanRouting/index.ts';
import { interfaceTroubleshootingModule } from './legacy/modules/interfaceTroubleshooting/index.ts';
import { iosImageManagementModule } from './legacy/modules/iosImageManagement/index.ts';
import { portSecurityModule } from './legacy/modules/portSecurity/index.ts';
import { spanningTreeModule } from './legacy/modules/spanningTree/index.ts';
import { trunkingNativeVlansModule } from './legacy/modules/trunkingNativeVlans/index.ts';
import { vlansAccessPortsModule } from './legacy/modules/vlansAccessPorts/index.ts';
import { vtpModule } from './legacy/modules/vtp/index.ts';
import { deviceLabModules } from './legacy/modules/deviceLabs.ts';

const core = [
  backupRestoreModule,
  basicManagementSetupModule,
  bootPasswordRecoveryModule,
  cdpLldpModule,
  dhcpSnoopingDaiModule,
  etherchannelLacpModule,
  factoryResetModule,
  fullDeviceModule,
  interVlanRoutingModule,
  interfaceTroubleshootingModule,
  iosImageManagementModule,
  portSecurityModule,
  spanningTreeModule,
  trunkingNativeVlansModule,
  vlansAccessPortsModule,
  vtpModule,
];

function categoryFor(module) {
  if (module.category) return module.category;
  const id = module.id.toLowerCase();
  if (/router|routing|ospf|inter-vlan/.test(id)) return 'router';
  if (/server|linux/.test(id)) return 'server';
  if (/firewall|asa/.test(id)) return 'firewall';
  return 'switch';
}

export const DRILLER_BILL_MODULES = [...core, ...deviceLabModules].map((module) => ({
  ...module,
  category: categoryFor(module),
  difficulty: module.difficulty ?? 'beginner',
}));

export const DRILLER_BILL_CATEGORIES = [
  { id: 'switch', label: 'Switches', description: 'VLANs, trunks, STP, EtherChannel and Layer 2 security.' },
  { id: 'router', label: 'Routers', description: 'Interfaces, static routes, OSPF and inter-VLAN routing.' },
  { id: 'server', label: 'Servers', description: 'Linux privilege, addressing, services and host firewall.' },
  { id: 'firewall', label: 'Firewalls', description: 'ASA interfaces, ACLs, NAT and policy verification.' },
];

export function getDrillModule(id) {
  return DRILLER_BILL_MODULES.find((module) => module.id === id);
}
