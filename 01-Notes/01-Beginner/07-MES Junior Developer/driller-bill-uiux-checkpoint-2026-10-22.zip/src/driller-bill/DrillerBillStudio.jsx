import React, { useEffect, useMemo, useRef, useState } from 'react';
import { DRILLER_BILL_CATEGORIES, DRILLER_BILL_MODULES } from './DrillCatalog.js';
import { analyzeTwin, buildTwinFiles, filesToZipPayload, looksLikeTypo, redactSensitive } from './twin.js';
import { createZip } from './zip.js';
import { safeStorage } from '../storage.js';
import UnifiedWorkflowBar from '../UnifiedWorkflowBar.jsx';
import TerminalToolbar from '../terminal/TerminalToolbar.jsx';
import { useTerminalPreferences } from '../terminal/terminalPreferences.js';
import { copyTerminalText } from '../terminal/terminalUtils.js';
import { completeIosCommand, iosHelpCandidates } from './legacy/engine/shell.ts';

const PROGRESS_KEY = 'driller-bill.progress.v2';
const MODULE_KEY = 'driller-bill.last-module.v2';
const TWIN_KEY = 'driller-bill.last-twin.v1';
const TWIN_INTELLIGENCE_KEY = 'driller-bill.twin-intelligence.v1';
const LETTERS = ['A', 'B', 'C', 'D'];

const NOTE_FILES = import.meta.glob('./content/notes/*.md', { eager: true, query: '?raw', import: 'default' });

function readJSON(key, fallback) {
  try {
    const raw = safeStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}
function writeJSON(key, value) {
  try { safeStorage.setItem(key, JSON.stringify(value)); } catch {}
}
function downloadBlob(name, blob) {
  const href = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = href;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(href), 0);
}
function downloadText(name, content) {
  downloadBlob(name, new Blob([content], { type: 'text/plain;charset=utf-8' }));
}
function formatDuration(ms) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
}
function slugify(value) {
  return String(value || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'community-drill';
}
function parseValue(value) {
  const text = String(value ?? '').trim();
  if (text === 'true') return true;
  if (text === 'false') return false;
  if (text !== '' && Number.isFinite(Number(text))) return Number(text);
  return text;
}

function Icon({ symbol }) {
  return <span aria-hidden="true" className="db-icon">{symbol}</span>;
}
function DeviceBadge({ category }) {
  const label = DRILLER_BILL_CATEGORIES.find((x) => x.id === category)?.label ?? category;
  return <span className="db-badge">{label}</span>;
}

function TheoryView({ module, onPractice }) {
  return <section className="db-content-card">
    <div className="db-section-label">GUIDED LEARNING / THEORY</div>
    <div className="db-section-head">
      <div><h2>{module.title}</h2><p>{module.summary}</p></div>
      <button className="button primary" onClick={onPractice}>Start terminal practice →</button>
    </div>
    {module.theory.length === 0 ? <div className="db-empty">This full-device module is an open command surface. Jump directly into Sandbox or practice.</div> :
      <div className="db-theory-grid">{module.theory.map((section) => <article key={section.id} className="db-theory-card">
        <div className="db-theory-kicker">{section.commandRef || 'CONCEPT'}</div>
        <h3>{section.title}</h3>
        {(section.body || []).map((body, i) => <p key={i}>{body}</p>)}
      </article>)}</div>}
  </section>;
}

function SimulationView({ module, onPractice }) {
  const [step, setStep] = useState(0);
  const [state, setState] = useState(() => module.createInitialState());
  const [output, setOutput] = useState([]);
  const current = module.drill[step];
  const runStep = () => {
    if (!current) return;
    try {
      const result = module.handleCommand(current.command, state, module.objectives);
      setState(result.state);
      setOutput(result.output || []);
    } catch (error) {
      setOutput([`% Simulation error: ${error instanceof Error ? error.message : String(error)}`]);
    }
  };
  return <section className="db-content-card">
    <div className="db-section-label">GUIDED LEARNING / SIMULATION</div>
    <div className="db-section-head">
      <div><h2>Watch the command sequence.</h2><p>Follow the state transitions the hands-on terminal will expect.</p></div>
      <span className="db-counter">STEP {current ? step + 1 : 0} / {module.drill.length}</span>
    </div>
    {!current ? <div className="db-empty">This module does not have a guided command sequence. Open Sandbox to explore it interactively.</div> : <div className="db-sim-grid">
      <div className="db-command-card">
        <div className="db-command-meta">EXPECTED COMMAND</div>
        <code>{current.command}</code>
        <p>{current.explanation || 'Execute the next learning step and inspect the resulting state.'}</p>
        <div className="db-sim-actions">
          <button className="button" onClick={() => setStep((v) => Math.max(0, v - 1))} disabled={step === 0}>← Previous</button>
          <button className="button primary" onClick={runStep}>Run step</button>
          <button className="button" onClick={() => step < module.drill.length - 1 ? (setStep(step + 1), setOutput([])) : onPractice()}>{step < module.drill.length - 1 ? 'Next step →' : 'Practice yourself →'}</button>
        </div>
      </div>
      <div className="db-terminal-mini">
        <div className="db-terminal-head"><span>{module.renderPrompt(state)}</span><span>SIMULATION</span></div>
        <div className="db-terminal-body">
          <div className="db-terminal-line"><span>{module.renderPrompt(state)}</span>{current.command}</div>
          {output.map((line, i) => <div key={i} className="db-terminal-output">{line}</div>)}
        </div>
      </div>
    </div>}
  </section>;
}

function TwinPanel({ module, session, state, errors, onClose, intelligence }) {
  const [tab, setTab] = useState('live');
  const files = useMemo(() => buildTwinFiles(module, session, state, errors), [module, session, state, errors]);
  const analysis = useMemo(() => intelligence || analyzeTwin(module, session, state, errors), [module, session, state, errors, intelligence]);
  const typos = session.entries.filter((e) => e.typo).length;
  const elapsed = session.entries.length ? session.entries[session.entries.length - 1].elapsedMs : 0;
  const exportAll = () => downloadBlob(`${module.id}-twin.zip`, createZip(filesToZipPayload(files)));
  const content = tab === 'documentation' ? files.documentation : tab === 'errors' ? files.errors : tab === 'improvements' ? files.improvements : tab === 'cards' ? files.cueCards : null;
  return <section className="db-content-card db-twin-panel">
    <div className="db-section-head">
      <div><div className="db-section-label">TWIN / SESSION INTELLIGENCE</div><h2>Command Co-Pilot</h2><p>Every command, output, mode change, error and suspected typo is captured locally. Sensitive-looking values are redacted before export.</p></div>
      <div className="db-twin-actions"><button className="button primary" onClick={exportAll}>↓ Download Twin ZIP</button>{onClose && <button className="button" onClick={onClose}>Close</button>}</div>
    </div>
    <div className="db-twin-tabs">{['live','intelligence','documentation','errors','improvements','cards'].map((item) => <button key={item} className={tab === item ? 'active' : ''} onClick={() => setTab(item)}>{item === 'cards' ? 'Cue Cards' : item}</button>)}</div>
    <div className="db-twin-layout">
      {tab === 'intelligence' ? <div className="db-twin-intelligence">
        <div className="db-intel-hero"><div><div className="db-section-label">TWIN INFERENCE</div><h3>{analysis.primary.title}</h3><p>{analysis.primary.detail}</p></div><strong>{analysis.stats.errorRate}% error rate</strong></div>
        <div className="db-intel-grid">{analysis.signals.map((signal) => <article key={signal.id} className="db-intel-card"><span>{signal.type.replace('-', ' ')}</span><h4>{signal.title}</h4><p>{signal.detail}</p></article>)}</div>
        <div className="db-intel-next"><div><div className="db-panel-title">RECOMMENDED NEXT MOVES</div>{analysis.recommendations.map((item, index) => <div key={index} className="db-intel-recommendation"><b>{index + 1}</b><span>{item.label}</span></div>)}</div>{analysis.repeatedCommand && <div><div className="db-panel-title">REPEATED FRICTION</div><code>{redactSensitive(analysis.repeatedCommand.command)}</code><p>Rejected {analysis.repeatedCommand.count} times in this session.</p></div>}</div>
      </div> : content ? <pre className="db-twin-document">{content}</pre> : <div className="db-twin-live">{session.entries.length === 0 ? <div className="db-empty">Start typing in the terminal and Twin will capture the session in real time.</div> : session.entries.map((entry) => <article key={entry.id} className="db-twin-entry">
        <div className="db-twin-meta"><span>{formatDuration(entry.elapsedMs)}</span><span>{entry.modeBefore} → {entry.modeAfter}</span>{entry.typo && <span className="db-chip-warn">TYPO?</span>}{entry.error && <span className="db-chip-error">{entry.error.category}</span>}</div>
        <div className="db-twin-command">{redactSensitive(entry.prompt)} {redactSensitive(entry.command)}</div>
        {entry.outputs.length > 0 && <pre>{entry.outputs.map(redactSensitive).join('\n')}</pre>}
      </article>)}</div>}
      <aside className="db-twin-stats">
        <div className="db-twin-stat"><b>{session.entries.length}</b><span>commands</span></div>
        <div className="db-twin-stat"><b>{errors.length}</b><span>errors</span></div>
        <div className="db-twin-stat"><b>{typos}</b><span>typos</span></div>
        <div className="db-twin-stat"><b>{formatDuration(elapsed)}</b><span>elapsed</span></div>
        <div className="db-twin-files"><div className="db-panel-title">GENERATED FILES</div>{['Documentation.md','Errors.md','Areas-of-improvement.md','Cue-Cards.md'].map((name) => <button key={name} className="button" onClick={() => downloadText(name, filesToZipPayload(files)[name])}>{name}</button>)}</div>
      </aside>
    </div>
  </section>;
}


function TwinLiveTelemetry({ module, entries, errors, state, startedAt }) {
  const session = useMemo(() => ({ startedAt, entries }), [startedAt, entries]);
  const typos = entries.filter((entry) => entry.typo).length;
  const elapsed = entries.length ? entries[entries.length - 1].elapsedMs : 0;
  const latest = entries[entries.length - 1];
  const twinFiles = useMemo(() => buildTwinFiles(module, session, state, errors), [module, session, state, errors]);
  const analysis = useMemo(() => analyzeTwin(module, session, state, errors), [module, session, state, errors]);
  return <aside className="db-live-twin">
    <div className="db-live-twin-head"><div><div className="db-section-label">TWIN LIVE</div><h3>Command Co-Pilot</h3></div><span className="db-live-dot">● ACTIVE</span></div>
    <div className="db-live-metrics"><div><b>{entries.length}</b><span>commands</span></div><div><b>{errors.length}</b><span>errors</span></div><div><b>{typos}</b><span>typos</span></div><div><b>{formatDuration(elapsed)}</b><span>time</span></div></div>
    <div className="db-twin-checklist"><div className="db-panel-title">CAPTURING</div><span>✓ Commands</span><span>✓ Outputs</span><span>✓ Mode changes</span><span>✓ Errors</span><span>✓ Typo signals</span><span>✓ Redacted docs</span></div>
    <div className="db-live-log"><div className="db-panel-title">LIVE LOG</div>{latest ? <article><div className="db-live-log-meta">{formatDuration(latest.elapsedMs)} · {latest.modeBefore} → {latest.modeAfter}</div><code>{redactSensitive(latest.command)}</code>{latest.error && <small className="db-cli-error">{latest.error.category}: {latest.error.message}</small>}</article> : <div className="db-empty">Twin is waiting for your first command.</div>}</div>
    {errors.length > 0 && <div className="db-live-inference"><div className="db-panel-title">TWIN INFERENCE</div><strong>{analysis.primary.title}</strong><small>{analysis.primary.detail}</small></div>}
    <div className="db-live-export"><button className="button" onClick={() => downloadBlob(`${module.id}-twin.zip`, createZip(filesToZipPayload(twinFiles)))}>↓ Export Twin ZIP</button><button className="button" onClick={() => downloadText('Documentation.md', twinFiles.documentation)}>Documentation</button></div>
  </aside>;
}

function PracticeView({ module, mode, onFinish, onBack }) {
  const [state, setState] = useState(() => module.createInitialState());
  const [lines, setLines] = useState([]);
  const [input, setInput] = useState('');
  const [history, setHistory] = useState([]);
  const [historyPos, setHistoryPos] = useState(null);
  const [entries, setEntries] = useState([]);
  const [errors, setErrors] = useState([]);
  const [lastFeedback, setLastFeedback] = useState(null);
  const [startedAt] = useState(() => Date.now());
  const [now, setNow] = useState(() => Date.now());
  const inputRef = useRef(null);
  const terminalRef = useRef(null);
  const outputRef = useRef(null);
  const [terminalExpanded, setTerminalExpanded] = useState(false);
  const { fontSize: terminalFontSize, changeFontSize: changeTerminalFontSize, autoFollow: terminalAutoFollow, toggleAutoFollow: toggleTerminalAutoFollow } = useTerminalPreferences();
  const required = module.objectives.length;
  const completed = useMemo(() => module.objectives.filter((objective) => objective.check(state)), [module, state]);
  const targetDurationMs = Math.min(15 * 60 * 1000, Math.max(60 * 1000, module.drill.length * 12 * 1000));
  const hardLimitMs = mode === 'speed' ? Math.round(targetDurationMs * 1.5) : Infinity;
  const elapsedMs = now - startedAt;
  const speedRemaining = Math.max(0, hardLimitMs - elapsedMs);

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 250);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (!terminalAutoFollow || !outputRef.current) return;
    outputRef.current.scrollTop = outputRef.current.scrollHeight;
  }, [lines, terminalAutoFollow, terminalExpanded]);

  useEffect(() => {
    if (!terminalExpanded) return undefined;
    const previousOverflow = document.body.style.overflow;
    const previousFocus = document.activeElement;
    document.body.style.overflow = 'hidden';
    const focusInput = requestAnimationFrame(() => inputRef.current?.focus());
    const onKeyDown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        setTerminalExpanded(false);
        return;
      }
      if (event.key !== 'Tab' || !terminalRef.current) return;
      const focusable = [...terminalRef.current.querySelectorAll('button:not(:disabled), input:not(:disabled), [tabindex="0"]')];
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => {
      cancelAnimationFrame(focusInput);
      window.removeEventListener('keydown', onKeyDown);
      document.body.style.overflow = previousOverflow;
      if (previousFocus instanceof HTMLElement && previousFocus.isConnected) previousFocus.focus();
    };
  }, [terminalExpanded]);

  useEffect(() => {
    if (mode !== 'speed' || elapsedMs < hardLimitMs) return;
    finish(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, elapsedMs, hardLimitMs]);

  function submit() {
    const raw = input.trim();
    if (!raw) return;
    const before = state;
    let result;
    try {
      result = module.handleCommand(raw, state, module.objectives);
    } catch (error) {
      result = {
        state,
        output: [`% Application error: ${error instanceof Error ? error.message : String(error)}`],
        error: { category: 'syntax', message: 'The simulator rejected the command unexpectedly.' },
      };
    }
    const typo = Boolean(result.error && looksLikeTypo(raw, module));
    setLastFeedback(result.error ? { type: 'error', title: result.error.category || 'Command rejected', message: result.error.message || 'The simulator did not accept that command.', command: raw, typo } : { type: 'success', title: 'State updated', message: 'Command accepted. Check the objective rail for the state you are building toward.', command: raw });
    const id = `${Date.now()}-${entries.length}`;
    const errorRecord = result.error ? { ...result.error, id, timestamp: Date.now(), raw, mode: before.mode } : null;
    const entry = {
      id,
      timestamp: Date.now(),
      elapsedMs: Date.now() - startedAt,
      prompt: module.renderPrompt(before),
      command: raw,
      outputs: result.output || [],
      modeBefore: before.mode,
      modeAfter: result.state.mode,
      error: errorRecord || undefined,
      typo,
    };
    setState(result.state);
    setLines((current) => [...current, { prompt: entry.prompt, command: raw, output: entry.outputs, error: errorRecord }]);
    setEntries((current) => [...current, entry]);
    if (errorRecord) setErrors((current) => [...current, errorRecord]);
    setHistory((current) => [...current, raw]);
    setHistoryPos(null);
    setInput('');
    inputRef.current?.focus();
  }

  const lastTabRef = useRef({ time: 0, input: '' });

  function appendTerminalNotice(command, output, prompt = module.renderPrompt(state)) {
    setLines((current) => [...current, { prompt, command, output, help: true }]);
    setLastFeedback({ type: 'success', title: 'Terminal help', message: output.join(' · ') || 'Terminal control accepted.' });
  }

  function showIosHelp(prefix) {
    const candidates = iosHelpCandidates(prefix, state);
    const output = candidates.length
      ? candidates.map((candidate) => `  ${candidate}`)
      : [`% No matching commands for "${prefix.trim()}".`];
    appendTerminalNotice(`${prefix}?`, output);
  }

  function completeFromKeyboard() {
    const nowTime = Date.now();
    const lastTab = lastTabRef.current;
    if (lastTab.input === input && lastTab.time > 0 && nowTime - lastTab.time < 900) {
      const candidates = iosHelpCandidates(input, state);
      appendTerminalNotice(input || '', candidates.length ? candidates.map((candidate) => `  ${candidate}`) : ['% No matching commands.']);
      lastTabRef.current = { time: 0, input: '' };
      return;
    }

    const completed = completeIosCommand(input, state);
    if (completed && completed !== input) {
      setInput(completed);
      lastTabRef.current = { time: 0, input: '' };
      return;
    }
    lastTabRef.current = { time: nowTime, input };
  }

  function dispatchTerminalKey(key, ctrlKey = false) {
    onTerminalKeyDown({ key, ctrlKey, preventDefault() {} });
  }

  function insertTerminalText(text) {
    const inputElement = inputRef.current;
    const start = inputElement?.selectionStart ?? input.length;
    const end = inputElement?.selectionEnd ?? input.length;
    const next = `${input.slice(0, start)}${text}${input.slice(end)}`;
    setInput(next);
    requestAnimationFrame(() => {
      inputElement?.focus();
      inputElement?.setSelectionRange(start + text.length, start + text.length);
    });
  }

  function onTerminalKeyDown(event) {
    if (event.ctrlKey && event.key.toLowerCase() === 'c') {
      event.preventDefault();
      appendTerminalNotice('^C', state.awaitingInput ? ['% Input cancelled.'] : []);
      setInput('');
      if (state.awaitingInput) setState((current) => ({ ...current, awaitingInput: null }));
      lastTabRef.current = { time: 0, input: '' };
      return;
    }
    if (event.ctrlKey && event.key.toLowerCase() === 'z') {
      event.preventDefault();
      appendTerminalNotice('^Z', [], module.renderPrompt(state));
      setState((current) => ({ ...current, mode: 'privileged', previousMode: null, awaitingInput: null }));
      setInput('');
      lastTabRef.current = { time: 0, input: '' };
      return;
    }
    if (event.ctrlKey && event.key.toLowerCase() === 'l') {
      event.preventDefault();
      setLines([]);
      lastTabRef.current = { time: 0, input: '' };
      return;
    }
    if (event.key === '?') {
      event.preventDefault();
      showIosHelp(input);
      lastTabRef.current = { time: 0, input: '' };
      return;
    }
    if (event.key === 'Tab') {
      event.preventDefault();
      completeFromKeyboard();
      return;
    }
    if (event.key === 'Enter') {
      event.preventDefault();
      lastTabRef.current = { time: 0, input: '' };
      submit();
      return;
    }
    if (event.key === 'ArrowUp') {
      event.preventDefault();
      recallHistory(-1);
      return;
    }
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      recallHistory(1);
    }
  }

  function finish(timedOut = false) {
    const finalState = state;
    const objectiveRows = module.objectives.map((objective) => ({ id: objective.id, label: objective.label, completed: objective.check(finalState) }));
    const twin = buildTwinFiles(module, { startedAt, entries }, finalState, errors);
    const completionPct = required === 0 ? 100 : Math.round((completed.length / required) * 100);
    const accuracyPct = entries.length === 0 ? 100 : Math.round(((entries.length - errors.length) / entries.length) * 100);
    const speedPct = Math.max(0, Math.min(100, Math.round((1 - Math.max(0, elapsedMs - targetDurationMs) / targetDurationMs) * 100)));
    const speedScore = mode === 'speed' ? {
      accuracyPct,
      speedPct,
      objectivePct: completionPct,
      score: Math.max(0, Math.min(100, Math.round((accuracyPct * 0.4) + (completionPct * 0.3) + (speedPct * 0.3)))),
      elapsedMs,
      targetDurationMs,
      hardLimitMs,
      timedOut,
    } : undefined;
    const xp = required === 0 ? 0 : completed.length === required ? (mode === 'speed' ? 150 + Math.max(0, Math.round((targetDurationMs - elapsedMs) / 1000)) : 100) : Math.max(20, completed.length * 12);
    onFinish({ durationMs: elapsedMs, completed: completed.length, required, objectiveRows, errors, entries, finalState, twin, xp, mode, speedScore });
  }

  function recallHistory(direction) {
    if (!history.length) return;
    const next = historyPos == null ? (direction < 0 ? history.length - 1 : 0) : Math.max(0, Math.min(history.length - 1, historyPos + direction));
    setHistoryPos(next);
    setInput(history[next] || '');
  }

  const practiceHeight = mode === 'speed' ? 'db-practice-head-speed' : '';
  return <section className="db-practice-shell">
    <div className={`db-practice-head ${practiceHeight}`}>
      <div><div className="db-section-label">{mode === 'speed' ? 'SPEED DRILL' : 'HANDS-ON TERMINAL'}</div><h2>{module.title}</h2><p className="db-practice-subtitle">{mode === 'speed' ? 'Prioritise accuracy first. Speed is measured after the state is correct.' : 'Build the target state deliberately. Twin is watching the session so mistakes become review material.'}</p></div>
      <div className="db-practice-stats">
        <span>{required === 0 ? 'OPEN SANDBOX' : `${completed.length}/${required} objectives`}</span>
        <span>{errors.length} errors</span>
        {mode === 'speed' && <span className="db-speed-clock">{formatDuration(speedRemaining)}</span>}
        <button className="button" onClick={onBack}>Exit drill</button>
        <button className="button primary" onClick={() => finish(false)}>Finish & analyse</button>
      </div>
    </div>
    <div className="db-drill-brief">
      <div><span className="db-brief-label">SESSION BRIEF</span><strong>{required === 0 ? 'Explore freely' : completed.length === required ? 'All objectives satisfied' : `${required - completed.length} objective${required - completed.length === 1 ? '' : 's'} remaining`}</strong></div>
      <div><span className="db-brief-label">CURRENT TARGET</span><strong>{module.objectives.find((objective) => !objective.check(state))?.label || 'Review your final state'}</strong></div>
      <div className={`db-feedback ${lastFeedback?.type === 'error' ? 'error' : lastFeedback ? 'success' : ''}`}><span className="db-brief-label">COACH CUE</span><strong>{lastFeedback ? lastFeedback.title : 'Read the objective, then work from the prompt.'}</strong><small>{lastFeedback ? lastFeedback.message : 'Use ? when you need command help. Errors are recorded by Twin for review.'}</small></div>
    </div>
    <div className="db-practice-grid with-twin">
      {required > 0 ? <aside className="db-objectives"><div className="db-panel-title">OBJECTIVES</div>{module.objectives.map((objective) => { const done = objective.check(state); return <div key={objective.id} className={`db-objective ${done ? 'done' : ''}`}><span>{done ? '✓' : '○'}</span><div><b>{objective.label}</b><small>{objective.description}</small></div></div>; })}</aside> : <aside className="db-objectives"><div className="db-panel-title">SANDBOX</div><div className="db-sandbox-note">No objectives. Explore the simulator freely, experiment with commands, and use Twin to review your session.</div></aside>}
      <div ref={terminalRef} className={`db-cli ${terminalExpanded ? 'terminal-workbench-expanded' : ''}`} style={{ '--terminal-font-size': `${terminalFontSize}px` }} role={terminalExpanded ? 'dialog' : undefined} aria-modal={terminalExpanded ? 'true' : undefined} aria-label={terminalExpanded ? 'Expanded Cisco IOS practice terminal' : undefined}>
        <div className="db-cli-head"><span>{module.terminalLabel || 'Cisco IOS practice terminal'}</span><span>● LIVE</span></div>
        <TerminalToolbar
          fontSize={terminalFontSize}
          onFontSizeChange={changeTerminalFontSize}
          autoFollow={terminalAutoFollow}
          onToggleAutoFollow={toggleTerminalAutoFollow}
          expanded={terminalExpanded}
          onToggleExpanded={() => setTerminalExpanded(value => !value)}
          onCopy={() => copyTerminalText(lines.map(line => `${redactSensitive(line.prompt)} ${redactSensitive(line.command)}${line.output.length ? `\n${line.output.map(redactSensitive).join('\n')}` : ''}`).join('\n\n'))}
          onClear={() => setLines([])}
        />
        <div className="db-cli-key-row" role="group" aria-label="Touch-friendly IOS terminal keys">
          <button type="button" onClick={() => dispatchTerminalKey('Tab')} aria-label="Complete command">Tab</button>
          <button type="button" onClick={() => dispatchTerminalKey('?')} aria-label="Show context help">?</button>
          <button type="button" onClick={() => insertTerminalText('|')} aria-label="Insert pipe filter">|</button>
          <button type="button" onClick={() => insertTerminalText('/')} aria-label="Insert slash">/</button>
          <button type="button" onClick={() => dispatchTerminalKey('ArrowUp')} aria-label="Previous command">↑</button>
          <button type="button" onClick={() => dispatchTerminalKey('ArrowDown')} aria-label="Next command">↓</button>
          <button type="button" onClick={() => dispatchTerminalKey('c', true)} aria-label="Cancel input">^C</button>
          <button type="button" onClick={() => dispatchTerminalKey('z', true)} aria-label="Return to privileged EXEC">^Z</button>
          <button type="button" onClick={() => dispatchTerminalKey('l', true)} aria-label="Clear terminal">^L</button>
        </div>
        <div ref={outputRef} className="db-cli-screen" onClick={() => inputRef.current?.focus()} role="log" aria-label="Cisco terminal output" aria-live="off" tabIndex={0}>
          {lines.map((line, i) => <div key={i} className="db-cli-command"><div><span>{redactSensitive(line.prompt)}</span> <span className="db-command-text">{redactSensitive(line.command)}</span></div>{line.output.map((out, j) => <div key={j} className={line.error ? 'db-cli-error' : 'db-cli-output'}>{redactSensitive(out)}</div>)}</div>)}
          <div className="db-cli-current"><span>{module.renderPrompt(state)}</span><input ref={inputRef} value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={onTerminalKeyDown} aria-label="Cisco command input" autoFocus spellCheck={false} autoCapitalize="off" autoCorrect="off" autoComplete="off" /></div>
        </div>
        <div className="db-cli-hints">Enter executes · Tab completes · ? shows context help · Ctrl+C cancels · Ctrl+Z returns to privileged EXEC · Ctrl+L clears the screen</div>
      </div>
      <TwinLiveTelemetry module={module} entries={entries} errors={errors} state={state} startedAt={startedAt} />
    </div>
  </section>;
}

function DrillBuilderView({ modules }) {
  const [engineModule, setEngineModule] = useState(modules[0]?.id || '');
  const [id, setId] = useState('community-drill');
  const [title, setTitle] = useState('Community Drill');
  const [summary, setSummary] = useState('A contributor-authored Cisco practice scenario.');
  const [difficulty, setDifficulty] = useState('beginner');
  const [steps, setSteps] = useState('enable\nconfigure terminal');
  const [objectives, setObjectives] = useState([{ id: 'objective-1', label: 'Reach the target state', description: 'Verify the required state value.', theoryAnchor: '', path: 'mode', value: 'global' }]);
  const engine = useMemo(() => modules.find((m) => m.id === engineModule) || modules[0], [engineModule, modules]);
  const build = () => {
    const firstAnchor = engine?.theory?.[0]?.id || '';
    const content = {
      schemaVersion: 1,
      id: slugify(id),
      title: title.trim() || 'Community Drill',
      summary: summary.trim(),
      engineModule,
      metadata: { difficulty, estimatedMinutes: Math.max(1, Math.ceil(steps.split('\n').filter(Boolean).length / 2)), topics: engine?.theory?.map((s) => s.title) || [] },
      theory: engine?.theory || [],
      drill: steps.split('\n').map((command) => command.trim()).filter(Boolean).map((command) => ({ command, explanation: 'Contributor-authored step.', theoryAnchor: firstAnchor })),
      objectives: objectives.filter((x) => x.id.trim() && x.path.trim()).map((x) => ({ id: x.id.trim(), label: x.label.trim(), description: x.description.trim(), theoryAnchor: x.theoryAnchor || firstAnchor, condition: { state: x.path.trim(), equals: parseValue(x.value) } })),
    };
    downloadText(`${content.id}.json`, JSON.stringify(content, null, 2));
  };
  const updateObjective = (index, patch) => setObjectives((items) => items.map((item, i) => i === index ? { ...item, ...patch } : item));
  return <div className="db-shell">
    <section className="db-content-card"><div className="db-section-label">CREATE DRILL / SCHEMA V1</div><div className="db-section-head"><div><h2>Build a drill without touching the engine.</h2><p>Reuse an existing simulator engine, author the command sequence and define a state-based objective. Export the result as declarative JSON.</p></div></div></section>
    <div className="db-builder-grid">
      <section className="db-content-card"><h3>Scenario</h3><div className="db-form-grid">
        <label>Engine<select value={engineModule} onChange={(e) => setEngineModule(e.target.value)}>{modules.map((m) => <option key={m.id} value={m.id}>{m.title}</option>)}</select></label>
        <label>ID<input value={id} onChange={(e) => setId(e.target.value)} /></label>
        <label>Title<input value={title} onChange={(e) => setTitle(e.target.value)} /></label>
        <label>Difficulty<select value={difficulty} onChange={(e) => setDifficulty(e.target.value)}><option>beginner</option><option>intermediate</option><option>advanced</option></select></label>
        <label className="full">Summary<textarea value={summary} onChange={(e) => setSummary(e.target.value)} /></label>
        <label className="full">Command steps<textarea className="db-code-input" value={steps} onChange={(e) => setSteps(e.target.value)} /></label>
      </div></section>
      <section className="db-content-card"><div className="db-builder-head"><h3>Objectives</h3><button className="button" onClick={() => setObjectives((items) => [...items, { id: `objective-${items.length + 1}`, label: 'New objective', description: 'Describe the expected state.', theoryAnchor: engine?.theory?.[0]?.id || '', path: 'mode', value: 'privileged' }])}>+ Add</button></div>
        <div className="db-objective-builder">{objectives.map((item, index) => <div key={`${item.id}-${index}`} className="db-objective-draft"><div className="db-form-grid two"><input value={item.id} onChange={(e) => updateObjective(index, { id: e.target.value })} placeholder="objective-id"/><input value={item.label} onChange={(e) => updateObjective(index, { label: e.target.value })} placeholder="Label"/><input value={item.path} onChange={(e) => updateObjective(index, { path: e.target.value })} placeholder="state.custom.foo"/><input value={item.value} onChange={(e) => updateObjective(index, { value: e.target.value })} placeholder="Expected value"/></div><input value={item.description} onChange={(e) => updateObjective(index, { description: e.target.value })} placeholder="Description"/>
          <select value={item.theoryAnchor} onChange={(e) => updateObjective(index, { theoryAnchor: e.target.value })}><option value="">Select theory anchor</option>{engine?.theory?.map((s) => <option key={s.id} value={s.id}>{s.title}</option>)}</select>
        </div>)}</div>
      </section>
    </div>
    <div className="db-builder-actions"><button className="button primary" onClick={build}>↓ Export Drill JSON</button></div>
  </div>;
}

function NotesView() {
  const notes = useMemo(() => Object.entries(NOTE_FILES).map(([path, content]) => ({ id: path.split('/').pop(), title: path.split('/').pop().replace(/\.md$/, '').replace(/^\d+-/, '').replace(/-/g, ' '), filename: path.split('/').pop(), content: String(content) })).sort((a, b) => a.filename.localeCompare(b.filename, undefined, { numeric: true })), []);
  const [selectedId, setSelectedId] = useState(notes[0]?.id || '');
  const selected = notes.find((n) => n.id === selectedId) || notes[0];
  return <section className="db-content-card"><div className="db-section-head"><div><div className="db-section-label">NOTES / MARKDOWN</div><h2>Networking knowledge base.</h2><p>These notes come from the original Driller Bill content pack and are bundled directly into the application.</p></div>{selected && <button className="button" onClick={() => downloadText(selected.filename, selected.content)}>↓ Download note</button>}</div><div className="db-notes-grid"><aside className="db-notes-list">{notes.map((note) => <button key={note.id} className={selected?.id === note.id ? 'active' : ''} onClick={() => setSelectedId(note.id)}>{note.title}</button>)}</aside><article className="db-note-document"><pre>{selected?.content || 'No notes loaded.'}</pre></article></div></section>;
}

function ProgressView() {
  const progress = readJSON(PROGRESS_KEY, {});
  const rows = DRILLER_BILL_MODULES.map((module) => ({ module, progress: progress[module.id] || {} })).filter(({ progress: p }) => p.attempts || p.completions || p.xp);
  const totalXp = Object.values(progress).reduce((sum, item) => sum + Number(item?.xp || 0), 0);
  const totalAttempts = rows.reduce((sum, row) => sum + Number(row.progress.attempts || 0), 0);
  return <section className="db-content-card"><div className="db-section-head"><div><div className="db-section-label">PROGRESS / DRILLS</div><h2>Practice telemetry.</h2><p>Module completion and XP are stored locally and remain separate from the larger CCNA assessment history.</p></div></div><div className="db-progress-stats"><div><b>{totalXp.toLocaleString()}</b><span>XP</span></div><div><b>{totalAttempts}</b><span>attempts</span></div><div><b>{rows.length}</b><span>modules touched</span></div></div><div className="db-progress-table">{rows.length ? rows.map(({ module, progress: p }) => <div key={module.id} className="db-progress-row"><div><b>{module.title}</b><small>{p.completions || 0} completions · {p.attempts || 0} attempts</small></div><strong>{p.bestScore || 0}%</strong></div>) : <div className="db-empty">Complete a drill and your local progress will appear here.</div>}</div></section>;
}

function LibraryView({ modules, active, category, setCategory, search, setSearch, progress, select, startPractice, setTab, setView }) {
  const filtered = modules.filter((module) => (category === 'all' || module.category === category) && (!search || `${module.title} ${module.summary} ${(module.tags || []).join(' ')}`.toLowerCase().includes(search.toLowerCase())));
  return <div className="db-shell"><UnifiedWorkflowBar view="drills" setView={setView}/>
    <section className="db-hero"><div><div className="db-section-label">DRILLER BILL / CCNA CLI TRAINER</div><h1>Practice. Document. <span>Master.</span></h1><p>The original Driller Bill command-learning system is now part of the full CCNA assessment platform. Choose a module, learn the theory, watch the simulation, practice in the terminal, then let Twin document the session.</p></div><div className="db-hero-stats"><div><b>{modules.length}</b><span>modules</span></div><div><b>{Object.values(progress).reduce((sum, item) => sum + Number(item?.xp || 0), 0).toLocaleString()}</b><span>XP earned</span></div></div></section>
    <div className="db-toolbar"><div className="db-tabs"><button className="active" onClick={() => setTab('library')}>Drills</button><button onClick={() => setTab('notes')}>Notes</button><button onClick={() => startPractice('speed', active?.id)}>Speed run</button><button onClick={() => setTab('sandbox')}>Sandbox</button><button onClick={() => setTab('progress')}>Progress</button><button onClick={() => setTab('create')}>Create drill</button></div><input className="db-search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Filter modules…" aria-label="Filter modules" /></div>
    <div className="db-category-row"><button className={category === 'all' ? 'active' : ''} onClick={() => setCategory('all')}>All modules</button>{DRILLER_BILL_CATEGORIES.map((item) => <button key={item.id} className={category === item.id ? 'active' : ''} onClick={() => setCategory(item.id)}>{item.label}</button>)}</div>
    <div className="db-module-grid">{filtered.map((module) => { const p = progress[module.id] || {}; return <article key={module.id} className={`db-module-card ${active?.id === module.id ? 'selected' : ''}`}>
      <div className="db-module-top"><DeviceBadge category={module.category}/><span className="db-difficulty">{module.difficulty}</span></div>
      <h3>{module.title}</h3><p>{module.summary}</p>
      <div className="db-module-meta"><span>{module.objectives.length} objectives</span><span>{module.drill.length} steps</span><span>{p.completions || 0} completed</span></div>
      <div className="db-module-actions"><button className="button" onClick={() => select(module.id, 'theory')}>Learn</button><button className="button" onClick={() => select(module.id, 'simulation')}>Simulate</button><button className="button primary" onClick={() => startPractice('standard', module.id)}>Drill</button></div>
    </article>; })}</div>
  </div>;
}

export default function DrillerBillStudio({ setView }) {
  const [selectedId, setSelectedId] = useState(() => safeStorage.getItem(MODULE_KEY) || DRILLER_BILL_MODULES[0]?.id || '');
  const [tab, setTab] = useState('library');
  const [category, setCategory] = useState('all');
  const [search, setSearch] = useState('');
  const [practiceMode, setPracticeMode] = useState('standard');
  const [result, setResult] = useState(null);
  const [lastTwin, setLastTwin] = useState(() => readJSON(TWIN_KEY, null));
  const [twinIntelligence, setTwinIntelligence] = useState(() => readJSON(TWIN_INTELLIGENCE_KEY, null));
  const [selectedForPractice, setSelectedForPractice] = useState(null);
  const active = DRILLER_BILL_MODULES.find((module) => module.id === selectedId) || DRILLER_BILL_MODULES[0];
  const progress = readJSON(PROGRESS_KEY, {});
  const twinModule = lastTwin ? DRILLER_BILL_MODULES.find((m) => m.id === lastTwin.moduleId) : null;

  const select = (id, nextTab = 'theory') => {
    setSelectedId(id);
    safeStorage.setItem(MODULE_KEY, id);
    setTab(nextTab);
    setResult(null);
  };
  const startPractice = (mode = 'standard', id = selectedId) => {
    setSelectedId(id);
    safeStorage.setItem(MODULE_KEY, id);
    setPracticeMode(mode);
    setSelectedForPractice(id);
    setResult(null);
    setTab('practice');
  };
  const onFinish = (data) => {
    const moduleId = selectedForPractice || selectedId;
    const next = { ...data, moduleId };
    const current = progress[moduleId] || { attempts: 0, completions: 0, bestScore: 0, xp: 0 };
    const score = data.required === 0 ? 0 : Math.round((data.completed / Math.max(1, data.required)) * 100);
    const updated = { ...progress, [moduleId]: { ...current, attempts: current.attempts + 1, completions: current.completions + (data.required > 0 && data.completed === data.required ? 1 : 0), bestScore: Math.max(current.bestScore || 0, score), xp: (current.xp || 0) + data.xp } };
    writeJSON(PROGRESS_KEY, updated);
    const session = { startedAt: Date.now() - data.durationMs, entries: data.entries || [] };
    const intelligence = analyzeTwin(module, session, data.finalState, data.errors || []);
    const twinRecord = { moduleId, ...data, startedAt: session.startedAt, intelligence };
    writeJSON(TWIN_KEY, twinRecord);
    writeJSON(TWIN_INTELLIGENCE_KEY, intelligence);
    setLastTwin(twinRecord);
    setTwinIntelligence(intelligence);
    setResult(next);
    setTab('result');
  };

  if (tab === 'practice' && active) return <div className="db-shell"><UnifiedWorkflowBar view="drills" setView={setView}/><PracticeView module={active} mode={practiceMode} onBack={() => setTab('theory')} onFinish={onFinish} /></div>;
  if (tab === 'result' && active && result) {
    const files = result.twin;
    const score = result.required === 0 ? 0 : Math.round((result.completed / Math.max(1, result.required)) * 100);
    const incomplete = result.objectiveRows.filter((row) => !row.completed);
    const errorCount = result.errors.length;
    const recommended = incomplete[0];
    const outcomeLabel = score === 100 ? 'TARGET STATE REACHED' : score >= 70 ? 'MOSTLY COMPLETE' : 'REMEDIATION NEEDED';
    const outcomeCopy = score === 100
      ? 'You reached every required objective. The next useful step is retention: review the Twin record or run the module again under pressure.'
      : recommended
        ? `The next useful step is to reinforce “${recommended.label}” before adding new material.`
        : 'Review the recorded errors, then run a fresh attempt.';
    return <div className="db-shell"><UnifiedWorkflowBar view="drills" setView={setView}/><section className="db-content-card db-result-page"><div className="db-result-hero"><div><div className="db-section-label">DRILL RESULT / SESSION DEBRIEF</div><h2>{active.title}</h2><p>{result.completed}/{result.required} objectives · {errorCount} errors · +{result.xp} XP</p>{result.speedScore && <><p className="db-speed-summary">Speed score {result.speedScore.score}/100 · {formatDuration(result.speedScore.elapsedMs)} elapsed{result.speedScore.timedOut ? ' · timed out' : ''}</p><p className="db-speed-formula">Score = accuracy × 0.40 + objectives × 0.30 + speed × 0.30. Accuracy {result.speedScore.accuracyPct}% · objectives {result.speedScore.objectivePct}% · speed {result.speedScore.speedPct}%.</p></>}<div className="db-result-status">{outcomeLabel}</div></div><div className="db-score-ring">{score}<small>%</small></div></div>
      <section className="db-remediation"><div><div className="db-section-label">NEXT STEP</div><h3>{recommended ? `Reinforce ${recommended.label}` : 'Lock it in'}</h3><p>{outcomeCopy}</p></div><div className="db-remediation-actions">{recommended && <button className="button primary" onClick={() => startPractice(practiceMode, active.id)}>Targeted retry</button>}<button className="button" onClick={() => setTab('twin')}>Open Twin analysis</button></div></section>
      <div className="db-result-grid"><div className="db-result-card"><div className="db-result-card-kicker">STATE CHECK</div><h3>What changed</h3>{result.objectiveRows.map((row) => <div key={row.id} className="db-result-row"><span className={row.completed ? 'done' : ''}>{row.completed ? '✓' : '○'}</span><div><b>{row.label}</b>{!row.completed && <small>Still requires attention</small>}</div></div>)}</div><div className="db-result-card"><div className="db-result-card-kicker">TWIN RECORD</div><h3>Your session, documented.</h3><p>Twin captured the commands, state transitions and errors from this attempt. Four local Markdown artifacts are ready for review.</p><div className="db-file-list">{['Documentation.md','Errors.md','Areas-of-improvement.md','Cue-Cards.md'].map((name) => <div key={name}><span>MD</span>{name}</div>)}</div><button className="button primary" onClick={() => downloadBlob(`${active.id}-twin.zip`, createZip(filesToZipPayload(files)))}>Download Twin ZIP</button></div></div>
      {errorCount > 0 && <section className="db-error-summary"><div><div className="db-section-label">ERROR LOOP</div><h3>{errorCount} recorded {errorCount === 1 ? 'error' : 'errors'}</h3><p>These events are preserved in Twin so the next attempt can focus on the parts that actually caused friction.</p></div><button className="button" onClick={() => setTab('twin')}>Review errors</button></section>}
      <div className="db-result-actions"><button className="button" onClick={() => setTab('library')}>Back to Drills</button><button className="button" onClick={() => setTab('twin')}>Open Twin</button><button className="button primary" onClick={() => startPractice(practiceMode, active.id)}>Retry module</button></div></section></div>;
  }
  if (tab === 'theory' && active) return <div className="db-shell"><UnifiedWorkflowBar view="drills" setView={setView}/><TheoryView module={active} onPractice={() => startPractice('standard', active.id)} /><div className="db-secondary-actions"><button className="button" onClick={() => setTab('simulation')}>Watch simulation</button><button className="button primary" onClick={() => startPractice('standard', active.id)}>Start drill</button><button className="button" onClick={() => startPractice('speed', active.id)}>Speed run</button><button className="button" onClick={() => setTab('sandbox')}>Open sandbox</button><button className="button" onClick={() => setTab('library')}>← Drill library</button></div></div>;
  if (tab === 'simulation' && active) return <div className="db-shell"><UnifiedWorkflowBar view="drills" setView={setView}/><SimulationView module={active} onPractice={() => startPractice('standard', active.id)} /><div className="db-secondary-actions"><button className="button" onClick={() => setTab('theory')}>← Theory</button><button className="button primary" onClick={() => startPractice('standard', active.id)}>Start drill</button></div></div>;
  if (tab === 'twin' && twinModule && lastTwin) return <div className="db-shell"><UnifiedWorkflowBar view="drills" setView={setView}/><TwinPanel module={twinModule} session={{ startedAt: lastTwin.startedAt, entries: lastTwin.entries || [] }} state={lastTwin.finalState} errors={lastTwin.errors || []} intelligence={lastTwin.intelligence || twinIntelligence} onClose={() => setTab('library')} /></div>;
  if (tab === 'notes') return <div className="db-shell"><UnifiedWorkflowBar view="drills" setView={setView}/><NotesView /></div>;
  if (tab === 'create') return <div className="db-shell"><UnifiedWorkflowBar view="drills" setView={setView}/><DrillBuilderView modules={DRILLER_BILL_MODULES.filter((m) => m.id !== 'full-device')} /></div>;
  if (tab === 'progress') return <div className="db-shell"><UnifiedWorkflowBar view="drills" setView={setView}/><ProgressView /></div>;
  if (tab === 'sandbox' && active) return <div className="db-shell"><UnifiedWorkflowBar view="drills" setView={setView}/><div className="db-content-card"><div className="db-section-head"><div><div className="db-section-label">SANDBOX / OPEN CONSOLE</div><h2>Explore a device without objectives.</h2><p>Use the original Driller Bill sandbox concept with the unified simulator modules.</p></div><select className="db-search" value={selectedId} onChange={(e) => select(e.target.value, 'sandbox')}>{DRILLER_BILL_MODULES.map((m) => <option key={m.id} value={m.id}>{m.title}</option>)}</select></div></div><PracticeView key={`sandbox-${active.id}`} module={active} mode="sandbox" onBack={() => setTab('library')} onFinish={onFinish} /></div>;

  return <LibraryView modules={DRILLER_BILL_MODULES} active={active} category={category} setCategory={setCategory} search={search} setSearch={setSearch} progress={progress} select={select} startPractice={startPractice} setTab={setTab} setView={setView} />;
}
