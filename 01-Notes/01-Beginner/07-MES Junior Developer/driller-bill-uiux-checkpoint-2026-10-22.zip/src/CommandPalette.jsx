import React, { useEffect, useMemo, useRef, useState } from 'react';

const COMMANDS = [
  { id: 'dashboard', label: 'Console', group: 'Start', detail: 'Training overview and next best action', terms: 'home dashboard assessment' },
  { id: 'drills', label: 'Guided drills', group: 'Learn', detail: 'Learn concepts through guided Cisco CLI practice', terms: 'practice tutorial module' },
  { id: 'studio', label: 'Question studio', group: 'Learn', detail: 'Create and manage question families', terms: 'authoring questions exams' },
  { id: 'knowledge', label: 'Knowledge base', group: 'Learn', detail: 'Browse concepts, commands, and related resources', terms: 'articles documentation vlan ospf' },
  { id: 'mistakes', label: 'Mistake bank', group: 'Practice', detail: 'Revisit questions and concepts you missed', terms: 'wrong answers errors weak areas' },
  { id: 'review', label: 'Review queue', group: 'Practice', detail: 'Review concepts due for spaced repetition', terms: 'mastery spaced repetition flash cards' },
  { id: 'analytics', label: 'Progress & analytics', group: 'Practice', detail: 'Track assessment results and objectives', terms: 'stats performance score history' },
  { id: 'discovery', label: 'Network discovery', group: 'Engineering', detail: 'Discover CDP/LLDP neighbors and review topology drift', terms: 'cdp lldp network map neighbors' },
  { id: 'devices', label: 'Devices', group: 'Engineering', detail: 'Connect to and inspect network devices', terms: 'ssh serial console router switch inventory' },
  { id: 'config', label: 'Configuration', group: 'Engineering', detail: 'Plan, preflight, approve, apply, and verify changes', terms: 'config vlan interface routing intent' },
  { id: 'runbooks', label: 'Runbooks', group: 'Engineering', detail: 'Execute step-by-step operational procedures', terms: 'procedure workflow checklist automation' },
  { id: 'troubleshooting', label: 'Troubleshooting', group: 'Engineering', detail: 'Investigate symptoms using evidence and hypotheses', terms: 'diagnose fault recovery' },
  { id: 'twin', label: 'Twin intelligence', group: 'Engineering', detail: 'Explain findings and propose reviewed actions', terms: 'assistant ai explain diagnose' },
  { id: 'workflows', label: 'Unified workflows', group: 'Engineering', detail: 'Resume connected learning and engineering threads', terms: 'workflow thread resume' },
  { id: 'changeSets', label: 'Change sets', group: 'Engineering', detail: 'Coordinate reviewed changes across devices', terms: 'multi device batch rollout' },
  { id: 'lab', label: 'CLI lab', group: 'Network lab', detail: 'Practice commands in a stateful IOS-style terminal', terms: 'terminal sandbox cisco command line' },
  { id: 'topology', label: 'Topology workbench', group: 'Network lab', detail: 'Build and inspect a network topology', terms: 'diagram devices links network map' },
  { id: 'protocol', label: 'Protocol lab', group: 'Network lab', detail: 'Inspect and repair protocol behavior', terms: 'ospf stp dhcp nat' },
  { id: 'flow', label: 'Flow lab', group: 'Network lab', detail: 'Trace a packet through a protocol flow', terms: 'packet trace troubleshooting' },
  { id: 'packet', label: 'Packet lab', group: 'Network lab', detail: 'Study packet behavior and protocol evidence', terms: 'capture networking' },
  { id: 'packet-workshop', label: 'Packet workshop', group: 'Network lab', detail: 'Inject faults and repair packet flows', terms: 'fault repair simulation' },
  { id: 'advanced', label: 'Advanced PBQs', group: 'Network lab', detail: 'Practice multi-step performance-based questions', terms: 'exam performance based questions' },
  { id: 'data-safety', label: 'Data & recovery', group: 'System', detail: 'Back up, restore, or reset local application data', terms: 'backup export import restore privacy' },
  { id: 'cloud', label: 'Cloud sync', group: 'System', detail: 'Manage optional account and cloud synchronization', terms: 'account sync server' },
];

function SearchMark() {
  return <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.4 4.4"/></svg>;
}

function ArrowMark() {
  return <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 12h13"/><path d="m13 6 6 6-6 6"/></svg>;
}

export default function CommandPalette({ open, onClose, onNavigate }) {
  const [query, setQuery] = useState('');
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRef = useRef(null);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return COMMANDS;
    return COMMANDS.filter((item) => `${item.label} ${item.group} ${item.detail} ${item.terms}`.toLowerCase().includes(needle));
  }, [query]);

  useEffect(() => {
    if (!open) {
      setQuery('');
      setActiveIndex(0);
      return undefined;
    }
    const previousFocus = document.activeElement;
    inputRef.current?.focus();
    return () => {
      if (previousFocus instanceof HTMLElement && previousFocus.isConnected) previousFocus.focus();
    };
  }, [open]);

  useEffect(() => setActiveIndex(0), [query]);

  if (!open) return null;

  const selectItem = (item) => {
    if (!item) return;
    onClose();
    onNavigate(item.id);
  };

  const trapDialogFocus = (event) => {
    if (event.key !== 'Tab') return;
    const focusable = [...event.currentTarget.querySelectorAll('input:not([disabled]), button:not([disabled]):not([tabindex="-1"])')];
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Escape') {
      event.preventDefault();
      onClose();
      return;
    }
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      setActiveIndex((index) => filtered.length ? (index + 1) % filtered.length : 0);
      return;
    }
    if (event.key === 'ArrowUp') {
      event.preventDefault();
      setActiveIndex((index) => filtered.length ? (index - 1 + filtered.length) % filtered.length : 0);
      return;
    }
    if (event.key === 'Enter') {
      event.preventDefault();
      selectItem(filtered[activeIndex]);
    }
  };

  return (
    <div className="command-palette-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="command-palette" role="dialog" aria-modal="true" aria-labelledby="command-palette-title" aria-describedby="command-palette-help" onKeyDown={trapDialogFocus}>
        <h2 id="command-palette-title" className="sr-only">Find a workspace</h2>
        <div className="command-palette-search">
          <SearchMark />
          <input
            ref={inputRef}
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Find a workspace, lab, or tool…"
            aria-label="Search Driller Bill workspaces"
            aria-controls="command-palette-options"
            aria-activedescendant={filtered[activeIndex] ? `command-option-${filtered[activeIndex].id}` : undefined}
            autoComplete="off"
            spellCheck="false"
          />
          <button type="button" className="command-palette-escape" onClick={onClose} aria-label="Close workspace search">Esc</button>
        </div>
        <div className="command-palette-results-head"><span>{query.trim() ? `${filtered.length} result${filtered.length === 1 ? '' : 's'}` : 'WORKSPACES'}</span><span>↑ ↓ MOVE · ENTER OPEN</span></div>
        <div className="command-palette-options" id="command-palette-options" role="listbox" aria-label="Workspace results">
          {filtered.map((item, index) => (
            <button
              key={item.id}
              type="button"
              id={`command-option-${item.id}`}
              role="option"
              aria-selected={index === activeIndex}
              tabIndex={-1}
              className={`command-palette-option ${index === activeIndex ? 'active' : ''}`}
              onMouseEnter={() => setActiveIndex(index)}
              onClick={() => selectItem(item)}
            >
              <span className="command-palette-option-mark" aria-hidden="true"><SearchMark /></span>
              <span className="command-palette-option-copy"><strong>{item.label}</strong><small>{item.detail}</small></span>
              <span className="command-palette-option-group">{item.group}</span>
              <span className="command-palette-option-arrow"><ArrowMark /></span>
            </button>
          ))}
          {!filtered.length && <div className="command-palette-empty"><strong>No workspace found</strong><span>Try “device”, “terminal”, “VLAN”, or “review”.</span></div>}
        </div>
        <div className="command-palette-footer" id="command-palette-help"><span>Tip: search by task or networking concept.</span><span><kbd>Ctrl</kbd> / <kbd>⌘</kbd> <kbd>K</kbd> to open</span></div>
      </section>
    </div>
  );
}
