import React, {useEffect, useMemo, useRef, useState} from 'react';
import { safeStorage } from './storage.js';
import { createHealthyLiveLab } from './core/live-network-engine.js';
import {executeCommand, freshLab, HELP, LAB_TASKS, LINKS, TOPOLOGY, evaluateTask, networkHealth, promptFor, deriveShow, taskFixture, compactInterface, commandSuggestions, normalizeLabState} from './core/cli-engine.js';
import { useNetworkWorkspace } from './context/NetworkWorkspaceContext.jsx';
import TerminalToolbar from './terminal/TerminalToolbar.jsx';
import { useTerminalPreferences } from './terminal/terminalPreferences.js';
import { copyTerminalText, formatTerminalTranscript } from './terminal/terminalUtils.js';

const LAB_STORAGE='pennyFarthingLabV11';
const HISTORY_STORAGE=`${LAB_STORAGE}:history`;
const COMPLETION_STORAGE=`${LAB_STORAGE}:completions`;

const HOSTS=new Set(['PC1','PC2','SRV1']);

function MiniLogo(){return <div className="lab-logo"><span/></div>}
function LabHeader({onHome}){return <header className="exam-topbar lab-topbar"><button className="exam-brand" onClick={onHome}><div className="brand-lockup"><MiniLogo/><div><div className="brand-name">Driller Bill</div><div className="brand-sub">CCNA NETWORK LAB / IOS STATE</div></div></div></button><div className="exam-center"><span className="live-dot"/> STATEFUL LAB <em>/</em> CANONICAL IOS</div><div className="exam-actions"><span className="lab-local-status">LOCAL STATE</span><button className="button" onClick={onHome}>Exit lab</button></div></header>}

function Topology({state,selected,onSelect}){
  const health=networkHealth(state);
  const coords=Object.fromEntries(TOPOLOGY.map(n=>[n.id,n]));
  const nodeStatus=id=>{
    if(HOSTS.has(id)){const client=state.clients[id];const link=LINKS.find(l=>l.a===id||l.b===id);return link&&health.links.find(x=>x.id===link.id)?.healthy?'healthy':'degraded';}
    const dev=state.devices[id]; if(!dev)return 'host';
    return Object.values(dev.interfaces).some(i=>i.admin&&i.link)?'online':'degraded';
  };
  return <section className="panel state-topology"><div className="panel-head"><div><div className="kicker">01 / LIVE TOPOLOGY</div><h2>Network state.</h2></div><div className="topology-health"><b>{health.healthyLinks}/{health.totalLinks}</b><span>LINKS HEALTHY</span></div></div><div className="topology-canvas-v5"><svg className="topology-svg" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">{LINKS.map(link=>{const a=coords[link.from],b=coords[link.to],ok=health.links.find(x=>x.id===link.id)?.healthy;return <line key={link.id} x1={a.x} y1={a.y} x2={b.x} y2={b.y} className={ok?'link-good':'link-bad'}/>})}</svg>{LINKS.map(link=>{const a=coords[link.from],b=coords[link.to],midX=(a.x+b.x)/2,midY=(a.y+b.y)/2,ok=health.links.find(x=>x.id===link.id)?.healthy;return <span key={link.id} className={`link-label-v5 ${ok?'good':'bad'}`} style={{left:`${midX}%`,top:`${midY}%`}}>{link.left}</span>})}{TOPOLOGY.map(n=>{const selectable=!HOSTS.has(n.id);return <button key={n.id} className={`topo-node-v5 ${n.kind} ${selected===n.id?'selected':''}`} style={{left:`${n.x}%`,top:`${n.y}%`}} disabled={!selectable} onClick={()=>onSelect(n.id)}><strong>{n.label}</strong><small>{n.kind==='router'?'ROUTER':n.kind==='switch'?'SWITCH':n.kind==='server'?'SERVER':'HOST'}</small><i className={nodeStatus(n.id)}/></button>})}<div className="topology-legend-v5"><span><i className="good"/> healthy</span><span><i className="bad"/> fault</span><span><i className="selected"/> selected</span></div></div></section>
}

function CommandPills({commands,onRun}){return <div className="command-pills-v5">{commands.map(c=><button key={c} className="command-pill-v5" onClick={()=>onRun(c)}>{c}</button>)}</div>}

function StateCard({label,value,detail,tone=''}){return <div className={`state-metric ${tone}`}><span>{label}</span><strong>{value}</strong><small>{detail}</small></div>}

export default function StatefulLab({onHome}){
  const workspace = useNetworkWorkspace();
  const state = workspace.labState;
  const setState = workspace.setLabState;
  const [device,setDevice]=useState('SW2');
  const [taskId,setTaskId]=useState(()=>safeStorage.getItem(`${LAB_STORAGE}:task`)||LAB_TASKS[0].id);
  const [entries,setEntries]=useState(()=>{try{return JSON.parse(safeStorage.getItem(HISTORY_STORAGE))||{R1:[],SW1:[],SW2:[]}}catch{return {R1:[],SW1:[],SW2:[]}}});
  const [input,setInput]=useState('');
  const [commandHistory,setCommandHistory]=useState([]);
  const [historyIndex,setHistoryIndex]=useState(-1);
  const [suggestions,setSuggestions]=useState([]);
  const [taskResult,setTaskResult]=useState(null);
  const [saved,setSaved]=useState(false);
  const [completions,setCompletions]=useState(()=>{try{return JSON.parse(safeStorage.getItem(COMPLETION_STORAGE))||{}}catch{return {}}});
  const inputRef=useRef(null);
  const terminalRef=useRef(null);
  const [terminalExpanded,setTerminalExpanded]=useState(false);
  const {fontSize:terminalFontSize,changeFontSize:changeTerminalFontSize,autoFollow:terminalAutoFollow,toggleAutoFollow:toggleTerminalAutoFollow}=useTerminalPreferences();
  const task=LAB_TASKS.find(t=>t.id===taskId)||LAB_TASKS[0];
  const deviceNames=useMemo(()=>Object.keys(state.devices||{}).sort(),[state.devices]);
  const activeDevice=deviceNames.includes(device)?device:(deviceNames[0]||'R1');
  const dev=state.devices[activeDevice];
  const activeEntries=entries[activeDevice]||[];
  const health=useMemo(()=>networkHealth(state),[state]);
  const targetDevice=state.devices[task.device];
  const targetIface=task.target.iface||'GigabitEthernet0/24';
  const targetInterface=task.target.route?null:targetDevice?.interfaces[targetIface];
  const completedCount=Object.values(completions).filter(Boolean).length;

  useEffect(()=>{safeStorage.setItem(HISTORY_STORAGE,JSON.stringify(entries));safeStorage.setItem(`${LAB_STORAGE}:task`,taskId);safeStorage.setItem(COMPLETION_STORAGE,JSON.stringify(completions));},[entries,taskId,completions]);

  useEffect(()=>{if(!terminalAutoFollow||!terminalRef.current)return;terminalRef.current.scrollTop=terminalRef.current.scrollHeight;},[activeEntries,terminalAutoFollow,terminalExpanded]);
  useEffect(()=>{if(!terminalExpanded)return;const previousOverflow=document.body.style.overflow;document.body.style.overflow='hidden';const onKeyDown=event=>{if(event.key==='Escape')setTerminalExpanded(false);};window.addEventListener('keydown',onKeyDown);return()=>{document.body.style.overflow=previousOverflow;window.removeEventListener('keydown',onKeyDown);};},[terminalExpanded]);

  const addEntry=(command,output)=>setEntries(prev=>({...prev,[activeDevice]:[...(prev[activeDevice]||[]),{id:`${Date.now()}-${Math.random()}`,command,output}].slice(-120)}));
  const run=value=>{const raw=(value??input).trim();if(!raw||!activeDevice)return;const {state:next,output}=executeCommand(state,activeDevice,raw);if(raw.toLowerCase()==='clear'){setEntries(prev=>({...prev,[activeDevice]:[]}));setInput('');setHistoryIndex(-1);return;}addEntry(raw,output);setState(next);setCommandHistory(prev=>[raw,...prev.filter(x=>x!==raw)].slice(0,60));setHistoryIndex(-1);setInput('');setSuggestions([]);setTaskResult(null);};
  const selectDevice=d=>{setDevice(d);setInput('');setHistoryIndex(-1);setTaskResult(null);setTimeout(()=>inputRef.current?.focus(),0);};
  const loadCommand=cmd=>{setInput(cmd);setTimeout(()=>inputRef.current?.focus(),0)};
  const loadTask=id=>{setTaskId(id);setState(taskFixture(id));setDevice(LAB_TASKS.find(t=>t.id===id)?.device||'SW2');setEntries({R1:[],SW1:[],SW2:[]});setInput('');setHistoryIndex(-1);setTaskResult(null);safeStorage.setItem(`${LAB_STORAGE}:task`,id);};
  const verify=()=>{const result=evaluateTask(state,task.id);setTaskResult(result);if(result.ok)setCompletions(prev=>({...prev,[task.id]:true}));};
  const resetTask=()=>loadTask(task.id);
  const resetAll=()=>{if(window.confirm('Reset every Driller Bill lab case, saved device state and terminal history?')){safeStorage.removeItem(LAB_STORAGE);safeStorage.removeItem(HISTORY_STORAGE);safeStorage.removeItem(COMPLETION_STORAGE);setState(createHealthyLiveLab());setTaskId(LAB_TASKS[0].id);setDevice('SW2');setEntries({R1:[],SW1:[],SW2:[]});setCompletions({});setTaskResult(null);}};
  useEffect(()=>{if(device!==activeDevice)setDevice(activeDevice);},[device,activeDevice]);
  const prompt=promptFor(state,activeDevice);
  const evidence=(task.device==='R1'||task.device==='R2')?['show ip route','show ip interface brief','show ip protocols','show ip ospf neighbor','show running-config']:['show interfaces trunk','show interfaces switchport gi0/24','show vlan brief','show running-config'];
  const quick=dev.kind==='switch'?['enable','configure terminal','show interfaces trunk','show vlan brief','show spanning-tree','show mac address-table']:['show ip interface brief','show ip route','show ip ospf neighbor','show running-config','ping 10.20.20.10'];

  return <div className="lab-shell stateful-v5"><LabHeader onHome={onHome}/><main className="lab-page stateful-page-v5">
    <section className="stateful-hero-v5"><div><div className="eyebrow">NETWORK REASONING / STATEFUL IOS</div><h1>Configure the <span>network.</span></h1><p>Every command changes a simulated device. Inspect the topology, troubleshoot the fault, change configuration, and verify the resulting state.</p><div className="hero-chip-row-v5"><span>STATEFUL DEVICE MODEL</span><span>DERIVED SHOW OUTPUT</span><span>PERFORMANCE TASKS</span><span>LOCAL SAVE</span></div></div><div className="state-hero-card"><div className="kicker">ACTIVE CASE</div><strong>{task.title}</strong><span>{task.objective}</span><small>{completedCount}/{LAB_TASKS.length} CASES COMPLETE</small><div className={`case-state-v5 ${taskResult?.ok?'complete':''}`}><i/>{taskResult?.ok?'OBJECTIVE COMPLETE':'IN PROGRESS'}</div></div></section>

    <section className="state-metrics"><StateCard label="LINKS" value={`${health.healthyLinks}/${health.totalLinks}`} detail="healthy physical paths" tone={health.healthyLinks<health.totalLinks?'warn':'ok'}/><StateCard label="ACTIVE DEVICE" value={device} detail={`${dev.kind} / ${dev.mode}`}/><StateCard label="TASK SCORE" value={taskResult?`${taskResult.score}%`:'—'} detail={taskResult?.ok?'verified':'not verified yet'} tone={taskResult?.ok?'ok':''}/><StateCard label="CASES" value={`${completedCount}/${LAB_TASKS.length}`} detail="objectives completed"/></section>

    <div className="stateful-grid-v5"><div className="stateful-main-v5"><Topology state={state} selected={device} onSelect={selectDevice}/>
      <section className={`panel cli-workbench-v5 ${terminalExpanded?'terminal-workbench-expanded':''}`} role={terminalExpanded?'dialog':undefined} aria-modal={terminalExpanded?'true':undefined} aria-label={terminalExpanded?'Expanded IOS terminal':undefined} onKeyDown={event=>{if(!terminalExpanded||event.key!=='Tab')return;const focusable=[...event.currentTarget.querySelectorAll('button:not(:disabled),input:not(:disabled),[tabindex="0"]')];if(!focusable.length)return;const first=focusable[0],last=focusable[focusable.length-1];if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}}>
        <div className="panel-head cli-workbench-heading"><div><div className="kicker">02 / DEVICE CONSOLE</div><h2>{dev.hostname} <span className="muted">· {dev.kind.toUpperCase()}</span></h2><p className="terminal-heading-copy">Enter IOS-style commands; output reflects the current simulated device state.</p></div><div className="device-tabs-v5" role="tablist" aria-label="Live devices">{deviceNames.map((d,i)=><button key={d} className={activeDevice===d?'active':''} role="tab" aria-selected={activeDevice===d} tabIndex={activeDevice===d?0:-1} onClick={()=>selectDevice(d)} onKeyDown={e=>{if(e.key==='ArrowRight'||e.key==='ArrowDown'){e.preventDefault();selectDevice(deviceNames[(i+1)%deviceNames.length])}if(e.key==='ArrowLeft'||e.key==='ArrowUp'){e.preventDefault();selectDevice(deviceNames[(i-1+deviceNames.length)%deviceNames.length])}}}>{d}</button>)}</div></div>
        <div className="cli-toolbar-v5"><span>MODE <b>{dev.mode}</b></span><span>HOSTNAME <b>{dev.hostname}</b></span><span>INTERFACES <b>{Object.keys(dev.interfaces).length}</b></span><span>VLANs <b>{dev.kind==='switch'?Object.keys(dev.vlans).length:'—'}</b></span><span>ENGINE <b>CANONICAL</b></span></div>
        <TerminalToolbar fontSize={terminalFontSize} onFontSizeChange={changeTerminalFontSize} autoFollow={terminalAutoFollow} onToggleAutoFollow={toggleTerminalAutoFollow} expanded={terminalExpanded} onToggleExpanded={()=>setTerminalExpanded(value=>!value)} onCopy={()=>copyTerminalText(formatTerminalTranscript(activeEntries.map(item=>({command:item.command,output:item.output})),prompt))} onClear={()=>run('clear')}/>
        <div ref={terminalRef} className="terminal-v5" style={{'--terminal-font-size':`${terminalFontSize}px`}} role="log" aria-label={`Terminal output for ${dev.hostname}`} aria-live="off" tabIndex={0} onClick={()=>inputRef.current?.focus()}><div className="terminal-banner-v5">DRILLER BILL IOS ENGINE / STATE-DERIVED OUTPUT</div>{activeEntries.map(item=><div className="terminal-entry-v5" key={item.id}><div className="term-command-v5"><span>{prompt}</span> {item.command}</div>{item.output&&item.output!=='__CLEAR__'?<pre>{item.output}</pre>:null}</div>)}<div className="term-input-row-v5"><span>{prompt}</span><input aria-label={`IOS command for ${dev.hostname}`} ref={inputRef} value={input} onChange={e=>{setInput(e.target.value);setSuggestions(commandSuggestions(state,activeDevice,e.target.value).slice(0,8))}} onKeyDown={e=>{if(e.ctrlKey&&e.key.toLowerCase()==='c'){e.preventDefault();setInput('');setSuggestions([]);return;}if(e.key==='Enter'){e.preventDefault();run()}else if(e.key==='Tab'){e.preventDefault();const next=suggestions[0];if(next){setInput(next);setSuggestions([])}}else if(e.key==='Escape'){setSuggestions([])}else if(e.key==='ArrowUp'){e.preventDefault();const n=Math.min(historyIndex+1,commandHistory.length-1);setHistoryIndex(n);setInput(commandHistory[n]||'')}else if(e.key==='ArrowDown'){e.preventDefault();const n=Math.max(historyIndex-1,-1);setHistoryIndex(n);setInput(n===-1?'':commandHistory[n]||'')}}} placeholder="Enter a command…" autoComplete="off" spellCheck={false}/></div>{suggestions.length>0&&<div className="cli-suggestions-v11" role="listbox" aria-label="Command suggestions">{suggestions.map((s,index)=><button type="button" role="option" aria-selected={index===0} key={s} onMouseDown={e=>{e.preventDefault();setInput(s);setSuggestions([]);inputRef.current?.focus()}}>{s}</button>)}</div>}</div>
        <div className="terminal-actions-v5"><button type="button" className="button primary" onClick={()=>run()}>Run command</button><button type="button" className="button" onClick={()=>loadCommand('show running-config')}>Prepare show config</button><button type="button" className="button" onClick={()=>loadCommand(dev.kind==='switch'?'show interfaces trunk':'show ip route')}>Prepare inspection</button></div><CommandPills commands={quick} onRun={loadCommand}/>
      </section>

      <section className="panel command-reference-v5"><div className="panel-head"><div><div className="kicker">03 / COMMAND REFERENCE</div><h2>Supported IOS surface</h2></div><span className="panel-micro">CONTROLLED SUBSET</span></div><pre>{HELP}</pre></section>
    </div>

    <aside className="stateful-side-v5"><section className="panel case-panel-v5"><div className="panel-head"><div><div className="kicker">04 / PERFORMANCE TASK</div><h2>Repair the case.</h2></div><span className="panel-micro">{task.objective}</span></div><select className="task-select-v5" value={taskId} onChange={e=>loadTask(e.target.value)}>{LAB_TASKS.map(t=><option key={t.id} value={t.id}>{t.title}</option>)}</select><div className="case-copy-v5"><strong>{task.title}</strong><p>{task.brief}</p></div><div className="target-device-v5"><span>TARGET DEVICE</span><b>{task.device}</b><code>{targetIface==='GigabitEthernet0/24'?'Gi0/24':compactInterface(targetIface)}</code></div><div className="task-checks-v5">{(taskResult?.checks||task.checks.map(label=>({label,ok:false}))).map((check,i)=><div key={`${check.label}-${i}`}><span className={check.ok?'done':''}>{check.ok?'✓':String(i+1).padStart(2,'0')}</span><p>{check.label}</p></div>)}</div>{taskResult&&<div className={`task-result-v5 ${taskResult.ok?'ok':'bad'}`}><div><b>{taskResult.ok?'OBJECTIVE COMPLETE':'NOT COMPLETE'}</b><strong>{taskResult.score}/100</strong></div><p>{taskResult.message}</p>{!taskResult.ok&&<small>Hint: {task.hint}</small>}</div>}<div className="case-actions-v5"><button className="button primary full" onClick={verify}>Verify objective</button><button className="button full" onClick={resetTask}>Reset current case</button></div></section>

      <section className="panel evidence-panel-v5"><div className="panel-head"><div><div className="kicker">05 / EVIDENCE DECK</div><h2>Inspect before changing.</h2></div></div><p className="panel-intro-v5">These commands are common investigation starting points for this case. Click one to load it into the console.</p><div className="evidence-list-v5">{evidence.map(cmd=><button key={cmd} onClick={()=>loadCommand(cmd)}><code>{cmd}</code><span>load into console</span></button>)}</div></section>

      <section className="panel state-inspector-v5"><div className="panel-head"><div><div className="kicker">06 / DEVICE STATE</div><h2>{targetDevice?.hostname} snapshot</h2></div><button className="button small" onClick={()=>{safeStorage.setItem(LAB_STORAGE,JSON.stringify(state));setSaved(true);setTimeout(()=>setSaved(false),1000)}}>{saved?'Saved':'Save'}</button></div>{task.target.route?<div className="state-list-v5"><div><span>Gi0/0</span><b>{targetDevice.interfaces['GigabitEthernet0/0']?.ip||'unassigned'}</b></div><div><span>Gi0/1</span><b>{targetDevice.interfaces['GigabitEthernet0/1']?.ip||'unassigned'}</b></div><div><span>Remote route</span><b>{targetDevice.routes.some(r=>r.type.startsWith('S')&&r.prefix===task.target.route)?'installed':'missing'}</b></div><div><span>Next hop</span><b>{targetDevice.routes.find(r=>r.type.startsWith('S')&&r.prefix===task.target.route)?.next||'—'}</b></div></div>:<div className="state-list-v5"><div><span>{compactInterface(targetIface)} mode</span><b>{targetInterface?.mode||'—'}</b></div><div><span>Admin state</span><b>{targetInterface?.admin?'up':'shutdown'}</b></div><div><span>Native VLAN</span><b>{targetInterface?.nativeVlan??'—'}</b></div><div><span>Allowed VLANs</span><b>{targetInterface?.allowedVlans?.join(', ')||'—'}</b></div></div>}</section>

      <section className="panel progression-v5"><div className="panel-head"><div><div className="kicker">07 / CASE TRACKER</div><h2>Lab progression</h2></div><span className="panel-micro">{completedCount}/{LAB_TASKS.length}</span></div>{LAB_TASKS.map(t=>{const done=!!completions[t.id];return <button key={t.id} className={`task-row-v5 ${taskId===t.id?'active':''}`} onClick={()=>loadTask(t.id)}><span className={done?'done':''}>{done?'✓':'○'}</span><div><b>{t.title}</b><small>{t.objective}</small></div><strong>{done?'100':'—'}</strong></button>})}</section>

      <section className="panel lab-control-v5"><div><div className="kicker">08 / LAB CONTROL</div><strong>Start over.</strong><span>Reset all device configuration and terminal history.</span></div><button className="button" onClick={resetAll}>Reset lab</button></section></aside>
    </div>
  </main></div>;
}
