import React, { useEffect, useState } from 'react';
import { safeStorage } from './storage.js';
import { UNIFIED_WORKFLOW_EVENT, completeWorkflowStage, getActiveWorkflow, progressForWorkflow, stageForView, stageDefinition } from './core/unified-workflows.js';

export default function UnifiedWorkflowBar({ view, setView }) {
  const [workflow, setWorkflow] = useState(() => getActiveWorkflow(safeStorage));
  useEffect(() => {
    const refresh = () => setWorkflow(getActiveWorkflow(safeStorage));
    window.addEventListener(UNIFIED_WORKFLOW_EVENT, refresh);
    window.addEventListener('storage', refresh);
    return () => { window.removeEventListener(UNIFIED_WORKFLOW_EVENT, refresh); window.removeEventListener('storage', refresh); };
  }, []);
  if (!workflow) return null;
  const progress = progressForWorkflow(workflow);
  const viewStage = stageForView(view);
  const current = progress.current;
  const relevant = viewStage && workflow.stages.some(stage => stage.id === viewStage);
  const completeHere = relevant && workflow.stages.find(stage => stage.id === viewStage)?.status !== 'complete';
  const complete = () => {
    completeWorkflowStage(safeStorage, viewStage, { note: `Completed from ${view}.` });
    setWorkflow(getActiveWorkflow(safeStorage));
  };
  return <div className="unified-context-bar" role="region" aria-label="Active engineering workflow">
    <div className="unified-context-main"><span className="unified-context-dot"/><div><strong>{workflow.title}</strong><small>{current ? `Current: ${stageDefinition(current.id)?.label || current.id}` : 'Workflow complete'}</small></div></div>
    <div className="unified-context-progress"><i style={{ width: `${progress.percent}%` }}/></div>
    <span className="unified-context-percent">{progress.percent}%</span>
    <div className="unified-context-actions"><button className="button" onClick={() => { if (setView) setView('workflows'); else window.dispatchEvent(new CustomEvent('driller-bill:navigate', { detail: 'workflows' })); }}>Open workflow</button>{completeHere && <button className="button primary" onClick={complete}>Complete {stageDefinition(viewStage)?.label || 'stage'}</button>}</div>
  </div>;
}
