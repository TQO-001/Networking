import React,{useEffect,useMemo,useState} from 'react';
import { LIVE_PACKET_PROFILES, LIVE_WORKSHOP_FAULTS, simulateLivePacket, injectLiveFault, resetLiveNetwork, liveSnapshot } from './core/live-network-engine.js';
import { useNetworkWorkspace } from './context/NetworkWorkspaceContext.jsx';

const Badge=({ok,children})=><span className={`flow-badge ${ok?'good':''}`}>{children}</span>;

export default function PacketWorkshop(){
  const { labState, setLabState, workspaceRevision } = useNetworkWorkspace();
  const [profileId,setProfileId]=useState(LIVE_PACKET_PROFILES[0].id);
  const [faultId,setFaultId]=useState('none');
  const [visible,setVisible]=useState(1);
  const profile=LIVE_PACKET_PROFILES.find(p=>p.id===profileId)||LIVE_PACKET_PROFILES[0];
  const state=labState;
  const snapshot=useMemo(()=>liveSnapshot(state),[state]);
  const trace=useMemo(()=>simulateLivePacket(state,profileId),[state,profileId]);
  const applyFault=(id)=>{setFaultId(id);setLabState(prev=>injectLiveFault(prev,id));setVisible(1)};
  const reset=()=>{setFaultId('none');setLabState(resetLiveNetwork());setVisible(1)};
  useEffect(()=>{setVisible(1);},[profileId]);
  const cliAffected = faultId!=='none' && !trace.complete ? 'Fault fixture active' : 'Reading shared CLI state';
  return <main className="page p22-page">
    <div className="page-title p22-title">
      <div><div className="eyebrow">NETWORK LAB / PACKET WORKSHOP</div><h1>Build the <span>flow.</span></h1><p>Packet decisions now read the same device state used by the CLI Lab. Configure a device, return here, and replay the packet without importing a second copy of the network.</p></div>
      <div className="flow-title-meta"><span>V24 / SHARED STATE</span><b>{cliAffected} · REV {workspaceRevision}</b></div>
    </div>
    <div className="p22-layout">
      <aside className="panel p22-controls">
        <div className="panel-head"><div><div className="kicker">01 / PACKET</div><h2>Packet builder.</h2></div><span className="panel-micro">LIVE CLI</span></div>
        <label className="p22-field"><span>Flow profile</span><select value={profileId} onChange={e=>setProfileId(e.target.value)}>{LIVE_PACKET_PROFILES.map(p=><option key={p.id} value={p.id}>{p.label}</option>)}</select></label>
        <div className="p22-packet-card"><div><small>SOURCE</small><strong>{profile.source}</strong></div><div><small>DESTINATION</small><strong>{profile.destinationIp}</strong></div><div><small>PROTOCOL</small><strong>{profile.protocol}</strong></div></div>
        <div className="kicker p22-section-kicker">02 / FAULT FIXTURES</div>
        <div className="p22-fault-list">{LIVE_WORKSHOP_FAULTS.map(f=><button key={f.id} className={`p22-fault ${faultId===f.id?'active':''}`} onClick={()=>f.id==='none'?reset():applyFault(f.id)}><span>{faultId===f.id?'●':'○'}</span><div><strong>{f.label}</strong><small>{f.description}</small></div></button>)}</div>
        <div className="p22-actions"><button className="button primary" onClick={()=>setVisible(trace.steps.length)}>Replay packet</button><button className="button" onClick={reset}>Reset live network</button></div>
        
      </aside>
      <section className="p22-main">
        <section className="panel p22-hero">
          <div className="flow-hero-head"><div><div className="kicker">03 / LIVE OBSERVATORY</div><h2>{profile.label}</h2><p>The packet is evaluated against the current shared CLI configuration. There is no second simulated network state hiding underneath the UI.</p></div><Badge ok={trace.complete}>{trace.complete?'DELIVERED':'STOPPED'}</Badge></div>
          <div className="flow-metrics"><div><small>SOURCE</small><b>{profile.source}</b></div><div><small>DESTINATION</small><b>{profile.destination}</b></div><div><small>FAULT</small><b>{LIVE_WORKSHOP_FAULTS.find(f=>f.id===faultId)?.label}</b></div><div><small>SCORE</small><b>{trace.score}%</b></div></div>
          <div className="p22-state-strip">{Object.entries(snapshot).map(([k,v])=><span key={k} className={v?'good':''}>{k.replace(/[A-Z]/g,m=>` ${m}`).toUpperCase()} <b>{v?'UP':'DOWN'}</b></span>)}</div>
        </section>
        <section className="panel p22-trace">
          <div className="panel-head"><div><div className="kicker">04 / PACKET TRACE</div><h2>Forwarding decisions.</h2></div><span className="panel-micro">{trace.passed}/{trace.total} PASS</span></div>
          <div className="p22-step-list">{trace.steps.map((s,i)=><article key={s.id} className={`p22-step ${s.ok?'pass':'fail'} ${i<visible?'visible':''}`}><div className="p22-step-no">{String(i+1).padStart(2,'0')}</div><div><div className="p22-step-meta"><span>{s.layer}</span><strong>{s.device}</strong><Badge ok={s.ok}>{s.status}</Badge></div><h3>{s.event}</h3><p>{s.detail}</p><code>{s.evidence}</code></div></article>)}</div>
          <div className="p22-trace-actions"><button className="button" onClick={()=>setVisible(v=>Math.min(trace.steps.length,v+1))} disabled={visible>=trace.steps.length}>Reveal next decision</button><span>First failure: {trace.firstFailure||'none'} · {trace.complete?'end-to-end delivery':'diagnosis required'}</span></div>
        </section>
        <section className="panel p22-summary"><div><div className="kicker">05 / SHARED STATE</div><h2>{trace.complete?'The current CLI configuration passes this flow.':'The packet is blocked by current device state.'}</h2><p>Use the CLI Lab to change configuration, then come back and hit Replay. Packet Workshop reads the same lifted React state held by the workspace.</p></div><div className="p22-result-score"><small>PATH SCORE</small><strong>{trace.score}%</strong></div></section>
      </section>
    </div>
  </main>;
}
