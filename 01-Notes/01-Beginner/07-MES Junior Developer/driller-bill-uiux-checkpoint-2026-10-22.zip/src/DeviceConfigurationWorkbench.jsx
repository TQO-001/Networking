import React, { useMemo, useState } from 'react';

function ToolKicker({ children }) {
  return <div className="device-card-kicker">{children}</div>;
}

function EmptyState({ title, copy }) {
  return <div className="device-tool-empty"><strong>{title}</strong><span>{copy}</span></div>;
}

export default function DeviceConfigurationWorkbench({
  device,
  inspection,
  connected,
  busy,
  intentType,
  fields,
  intent,
  plan,
  configIntents,
  onIntent,
  onField,
  onPreview,
  onPreflight,
  onApply,
  changePreflight = null,
  changeHistory = [],
  onInspect,
  inspectionLoading,
  scenarios = [],
  selectedScenario = null,
  scenarioVerification = null,
  onSelectScenario,
  onPreviewScenarioStep,
  onApplyScenarioStep,
  scenarioBusy = false,
}) {
  const [tab, setTab] = useState(device?.kind === 'router' ? 'routing' : 'vlans');
  const intentCategories = useMemo(() => ({
    vlans: ['switching'],
    interfaces: ['interfaces'],
    routing: ['routing'],
    security: ['security'],
    services: ['services'],
    management: ['management'],
  }), []);
  const tabIntents = useMemo(() => (configIntents || []).filter(item => (intentCategories[tab] || []).includes(item.category) || (tab === 'interfaces' && item.capabilities?.includes('interfaces'))), [configIntents, intentCategories, tab]);
  const vlanOptions = useMemo(() => (inspection?.vlans || []).slice().sort((a, b) => a.id - b.id), [inspection]);
  const interfaces = useMemo(() => inspection?.interfaces || [], [inspection]);
  const routes = useMemo(() => inspection?.routes || [], [inspection]);
  const hasInspection = !!inspection;
  const scenarioNextStep = selectedScenario && scenarioVerification ? selectedScenario.steps.find(step => !scenarioVerification.steps.find(check => check.id === step.id)?.completed) : selectedScenario?.steps?.[0];

  const chooseIntent = (type, nextFields = {}) => {
    const next = { ...fields, ...nextFields };
    onIntent(type, next);
  };

  return <section className="panel device-workbench">
    <div className="device-title-row device-workbench-head">
      <div>
        <div className="eyebrow">ENGINEERING / CONFIGURATION WORKBENCH</div>
        <h2>Operate by intent</h2>
        <p>Use structured device state to build a change, preview the vendor commands, then apply and verify it through the Device Agent.</p>
      </div>
      <div className="device-workbench-status">
        <span className={connected ? 'connected' : 'offline'}>{connected ? 'DEVICE CONNECTED' : 'DEVICE OFFLINE'}</span>
        {inspection?.inspectedAt && <small>State captured {new Date(inspection.inspectedAt).toLocaleString()}</small>}
        {connected && <button className="text-button" onClick={onInspect} disabled={busy || inspectionLoading}>{inspectionLoading ? 'Refreshing…' : 'Refresh device state'}</button>}
      </div>
    </div>

    {!hasInspection && <div className="device-tool-notice"><strong>Structured state is not loaded.</strong><span>Connect to the device and inspect it before relying on the tables below. Configuration actions remain available through the intent builder.</span></div>}

    <div className="device-tool-tabs" role="tablist" aria-label="Configuration tools">
      <button className={tab === 'vlans' ? 'active' : ''} onClick={() => setTab('vlans')} role="tab" aria-selected={tab === 'vlans'} tabIndex={tab === 'vlans' ? 0 : -1}>VLANs</button>
      <button className={tab === 'interfaces' ? 'active' : ''} onClick={() => setTab('interfaces')} role="tab" aria-selected={tab === 'interfaces'} tabIndex={tab === 'interfaces' ? 0 : -1}>Interfaces</button>
      <button className={tab === 'routing' ? 'active' : ''} onClick={() => setTab('routing')} role="tab" aria-selected={tab === 'routing'} tabIndex={tab === 'routing' ? 0 : -1}>Routing</button>
      <button className={tab === 'security' ? 'active' : ''} onClick={() => setTab('security')} role="tab" aria-selected={tab === 'security'} tabIndex={tab === 'security' ? 0 : -1}>Security</button>
      <button className={tab === 'services' ? 'active' : ''} onClick={() => setTab('services')} role="tab" aria-selected={tab === 'services'} tabIndex={tab === 'services' ? 0 : -1}>Services</button>
      <button className={tab === 'management' ? 'active' : ''} onClick={() => setTab('management')} role="tab" aria-selected={tab === 'management'} tabIndex={tab === 'management' ? 0 : -1}>Management</button>
      {scenarios.length > 0 && <button className={tab === 'scenarios' ? 'active' : ''} onClick={() => setTab('scenarios')} role="tab" aria-selected={tab === 'scenarios'} tabIndex={tab === 'scenarios' ? 0 : -1}>Scenarios</button>}
    </div>

    {['security','services','management'].includes(tab) && <div className="device-operation-card">
      <div className="device-operation-head"><div><ToolKicker>{tab.toUpperCase()} OPERATIONS</ToolKicker><h3>Describe the change, then review the exact commands.</h3><p>Each operation uses the same typed intent pipeline as VLANs and routing. Live devices still require an explicit reviewed apply.</p></div><span>{tabIntents.length} available</span></div>
      <div className="device-operation-grid">{tabIntents.map(item => <button className="device-operation-option" key={item.id} onClick={() => chooseIntent(item.id, {})}>
        <strong>{item.title}</strong><span>{item.description}</span><b>{item.capabilities?.filter(cap => !['configuration'].includes(cap)).slice(0, 3).join(' · ')}</b>
      </button>)}</div>
    </div>}

    {tab === 'vlans' && <div className="device-tool-grid">
      <div className="device-tool-card">
        <ToolKicker>OBSERVED STATE</ToolKicker>
        <div className="device-tool-card-head"><div><h3>VLAN inventory</h3><p>{vlanOptions.length} VLAN records currently visible on the device.</p></div><button className="button primary" onClick={() => chooseIntent('create-vlan', { id: '', name: '' })}>＋ Create VLAN</button></div>
        {vlanOptions.length ? <div className="device-vlan-table"><div className="device-table-head"><span>ID</span><span>NAME</span><span>STATUS</span><span>PORTS</span><span /></div>{vlanOptions.map(vlan => <div className="device-table-row" key={vlan.id}><strong>{vlan.id}</strong><span>{vlan.name}</span><span className={vlan.status === 'active' ? 'state-good' : 'state-warn'}>{vlan.status}</span><span>{vlan.ports?.length ? vlan.ports.join(', ') : '—'}</span><button className="text-button" onClick={() => chooseIntent('assign-access-vlan', { vlan: String(vlan.id) })}>Assign ports</button></div>)}</div> : <EmptyState title="No VLAN inventory" copy="Inspect the device to populate VLAN state." />}
      </div>
      <div className="device-tool-card device-tool-guide">
        <ToolKicker>CONFIGURATION FLOW</ToolKicker>
        <h3>VLAN workflow</h3>
        <div className="device-flow-steps"><div><b>01</b><span>Inspect</span><small>Read the current VLAN state.</small></div><div><b>02</b><span>Build</span><small>Describe the VLAN intent.</small></div><div><b>03</b><span>Preview</span><small>Review the IOS command plan.</small></div><div><b>04</b><span>Apply</span><small>Send the approved change to the device.</small></div><div><b>05</b><span>Verify</span><small>Re-inspect and capture configuration.</small></div></div>
      </div>
    </div>}

    {tab === 'interfaces' && <div className="device-tool-card">
      <ToolKicker>INTERFACE MANAGER</ToolKicker>
      <div className="device-tool-card-head"><div><h3>Interfaces</h3><p>Jump from observed interface state into an access-port or trunk configuration intent.</p></div></div>
      {interfaces.length ? <div className="device-interface-grid">{interfaces.map(item => <div className="device-interface-card" key={item.name}>
        <div className="device-interface-top"><code>{item.name}</code><span className={item.status === 'up' && item.protocol === 'up' ? 'state-good' : 'state-warn'}>{item.status}/{item.protocol}</span></div>
        <div className="device-interface-ip">{item.ip}</div>
        <div className="device-interface-actions"><button className="text-button" onClick={() => chooseIntent('assign-access-vlan', { interface: item.name.replace(/^GigabitEthernet/i, 'Gi') })}>Access VLAN</button>{device?.kind === 'switch' && <button className="text-button" onClick={() => chooseIntent('set-trunk-vlans', { interface: item.name.replace(/^GigabitEthernet/i, 'Gi') })}>Configure trunk</button>}</div>
      </div>)}</div> : <EmptyState title="No interfaces available" copy="Inspect the device to populate interface state." />}
    </div>}

    {tab === 'routing' && <div className="device-tool-grid">
      <div className="device-tool-card">
      <ToolKicker>ROUTING TABLE</ToolKicker>
      <div className="device-tool-card-head"><div><h3>Observed routes</h3><p>Inspect the live routing table, then use the same reviewed intent builder to add or remove routes and operate OSPF/IPv6.</p></div><button className="button primary" onClick={() => chooseIntent(device?.kind === 'router' ? 'add-static-route' : 'set-stp-mode', device?.kind === 'router' ? { network: '', mask: '', nextHop: '' } : {})} disabled={device?.kind !== 'router'}>＋ Add static route</button></div>
      {routes.length ? <div className="device-route-table"><div className="device-table-head"><span>CODE</span><span>NETWORK</span><span>NEXT HOP</span><span>INTERFACE</span></div>{routes.map((route, index) => <div className="device-table-row route" key={`${route.network}-${index}`}><strong>{route.code}</strong><span>{route.network}</span><span>{route.nextHop || 'connected'}</span><span>{route.interface || '—'}</span></div>)}</div> : <EmptyState title="No routes parsed" copy="Inspect the device to populate routing state." />}
      </div>
      <div className="device-tool-card device-tool-guide"><ToolKicker>ROUTING OPERATIONS</ToolKicker><h3>Protocols & forwarding</h3><p>Use the change builder for OSPF process/network/interface operations, static routes, IPv6 forwarding and IPv6 static routes.</p><div className="device-operation-grid compact">{tabIntents.map(item => <button className="device-operation-option" key={item.id} onClick={() => chooseIntent(item.id, {})}><strong>{item.title}</strong><span>{item.description}</span></button>)}</div></div>
    </div>}

    {tab === 'scenarios' && <div className="device-scenario-grid">
      <div className="device-tool-card">
        <ToolKicker>JOB-STYLE LABS</ToolKicker>
        <div className="device-tool-card-head"><div><h3>Operational scenarios</h3><p>Use the same intent engine to perform a defined network-engineering job, then verify the resulting device state.</p></div></div>
        <div className="device-scenario-picker">{scenarios.map(item => <button key={item.id} className={`device-scenario-option ${selectedScenario?.id === item.id ? 'active' : ''}`} onClick={() => onSelectScenario?.(item.id)}><span><strong>{item.title}</strong><small>{item.summary}</small></span><b>{item.difficulty}</b></button>)}</div>
      </div>
      {selectedScenario && <div className="device-tool-card device-scenario-card">
        <div className="device-card-kicker">SCENARIO / {selectedScenario.id.replaceAll('-', ' ')}</div>
        <div className="device-scenario-head"><div><h3>{selectedScenario.title}</h3><p>{selectedScenario.summary}</p></div><strong>{scenarioVerification?.completed || 0}/{scenarioVerification?.total || selectedScenario.steps.length}</strong></div>
        <div className="device-scenario-progress"><span style={{width: `${Math.round(((scenarioVerification?.completed || 0) / Math.max(1, scenarioVerification?.total || selectedScenario.steps.length)) * 100)}%`}} /></div>
        <div className="device-scenario-steps">{selectedScenario.steps.map((step, index) => { const result = scenarioVerification?.steps?.find(item => item.id === step.id); return <div className={result?.completed ? 'complete' : ''} key={step.id}><span>{result?.completed ? '✓' : String(index + 1).padStart(2, '0')}</span><div><strong>{step.label}</strong><small>{result?.completed ? 'Verified from current device state.' : 'Not yet verified.'}</small></div></div>; })}</div>
        {scenarioNextStep && <div className="device-scenario-next"><span>NEXT STEP</span><strong>{scenarioNextStep.label}</strong><div className="device-scenario-next-actions"><button className="button" onClick={() => onPreviewScenarioStep?.(scenarioNextStep)} disabled={busy || scenarioBusy}>Review command plan</button><button className="button primary" onClick={() => onApplyScenarioStep?.(scenarioNextStep)} disabled={!connected || busy || scenarioBusy}> {scenarioBusy ? 'Applying…' : 'Apply step'}</button></div></div>}
        {!scenarioNextStep && scenarioVerification?.valid && <div className="device-scenario-complete"><strong>SCENARIO COMPLETE</strong><span>Every required state is currently verified. Capture a snapshot to preserve this successful state in configuration history.</span></div>}
      </div>}
    </div>}

    {tab === 'security' && <div className="device-tool-notice"><strong>SECURITY CHANGE BOUNDARY</strong><span>ACLs, port-security and management hardening are mutable configuration. Review the generated command plan before applying it to a real device.</span></div>}
    {tab === 'services' && <div className="device-tool-notice"><strong>SERVICE OPERATIONS</strong><span>DHCP and NAT changes alter traffic behavior. Use inspection and diagnostics before and after applying the change.</span></div>}
    {tab === 'management' && <div className="device-tool-notice"><strong>MANAGEMENT OPERATIONS</strong><span>Hostname, SSH, VTY and default-gateway changes affect device access. Credential-bearing local-user changes are intentionally excluded from reusable runbooks.</span></div>}

    <div className="device-workbench-plan">
      <div className="device-plan-source"><ToolKicker>CHANGE BUILDER</ToolKicker><span>{intent?.title || 'Configuration intent'}</span></div>
      <div className="device-tool-intent-form">
        {intent?.fields?.map(field => <label key={field.id}><span>{field.label}{field.required ? ' *' : ''}</span>{field.input === 'select' ? <select value={fields[field.id] ?? field.options?.[0]?.value ?? ''} onChange={event => onField(field.id, event.target.value)}>{(field.options || []).map(option => <option key={option.value} value={option.value}>{option.label}</option>)}</select> : <input type={field.input} value={fields[field.id] ?? ''} placeholder={field.placeholder} onChange={event => onField(field.id, event.target.value)} />}</label>)}
        <label><span>INTENT TYPE</span><select value={intentType} onChange={event => onIntent(event.target.value, fields)}>{configIntents.map(item => <option key={item.id} value={item.id}>{item.title}</option>)}</select></label>
      </div>
      <div className={`device-plan ${plan?.valid ? 'valid' : 'invalid'}`}><div className="device-plan-head"><span>COMMAND PLAN</span><strong>{plan?.valid ? 'READY' : 'NEEDS INPUT'}</strong></div>{plan?.errors?.length ? <div className="device-errors">{plan.errors.map(error => <div key={error}>× {error}</div>)}</div> : <div className="device-command-preview">{(plan?.displayCommands || plan?.commands)?.map((entry, index) => <div key={`${entry}-${index}`}><span>{String(index + 1).padStart(2, '0')}</span><code>{entry}</code><small>{plan.explanations[index]?.reason}</small></div>)}</div>}</div>
      <div className="device-change-safety">
        <div className="device-change-safety-head"><div><ToolKicker>CHANGE CONTROL / PREFLIGHT</ToolKicker><h3>{changePreflight ? `Risk: ${changePreflight.preflight?.risk?.label || 'review'}` : 'Establish a safe change baseline'}</h3></div><span className={`change-risk ${String(changePreflight?.preflight?.risk?.level || 'unknown')}`}>{changePreflight ? String(changePreflight.preflight?.risk?.level || 'review').toUpperCase() : 'NOT PREFLIGHTED'}</span></div>
        {!changePreflight ? <><p>Driller Bill will inspect the target, capture a pre-change snapshot, evaluate health signals and create a short-lived approval record before a configuration mutation can be sent to a physical device.</p><button className="button" onClick={onPreflight} disabled={!plan?.valid || !connected || busy}>{busy ? 'Preparing…' : 'Run change preflight'}</button></> : <><div className="device-change-checks">{(changePreflight.preflight?.checks || []).map(check => <div className={check.status} key={check.id}><b>{check.status === 'pass' ? '✓' : check.status === 'attention' ? '!' : '×'}</b><span><strong>{check.label}</strong><small>{check.detail}</small></span></div>)}</div><div className="device-change-approval"><div><strong>{changePreflight.preflight?.summary}</strong><small>Approval expires {changePreflight.expiresAt ? new Date(changePreflight.expiresAt).toLocaleTimeString() : 'soon'} · pre-change snapshot captured</small></div><button className="button primary" onClick={onApply} disabled={!plan?.valid || !connected || busy || !changePreflight.changeId}>{busy ? 'Applying…' : 'Approve & apply change'}</button></div></>}
      </div>
      {changeHistory.length > 0 && <div className="device-change-history-mini"><ToolKicker>RECENT CHANGE CONTROL</ToolKicker>{changeHistory.slice(-3).reverse().map(change => <div key={change.id}><span>{change.risk?.label || 'Review'}</span><strong>{change.intent?.type?.replaceAll('-', ' ')}</strong><small>{change.status} · {change.diffSummary || 'preflight recorded'}</small></div>)}</div>}
      <div className="device-intent-actions"><button className="button" onClick={onPreview} disabled={!plan?.valid}>Preview in CLI</button><span>Intent → Preflight → Approve → Apply → Verify → Snapshot</span></div>
    </div>
  </section>;
}
