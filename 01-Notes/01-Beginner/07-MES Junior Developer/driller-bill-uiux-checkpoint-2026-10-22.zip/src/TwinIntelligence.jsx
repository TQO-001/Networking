import React, { useMemo, useState } from 'react';
import { safeStorage } from './storage.js';
import { buildDeviceInventory } from './core/device-model.js';
import { inspectSimulatedDevice } from './core/device-inspection.js';
import { buildDeviceDiagnostics } from './core/device-diagnostics.js';
import { useNetworkWorkspace } from './context/NetworkWorkspaceContext.jsx';
import UnifiedWorkflowBar from './UnifiedWorkflowBar.jsx';
import { startWorkflow, workflowFromTwin } from './core/unified-workflows.js';
import { buildModelContext, buildTwinContext, generateTwinResponse, inferTwinMode, loadTwinHistory, saveTwinHistory, TWIN_MODES } from './core/twin-intelligence.js';

const MODE_META = {
  investigate: ['Investigate', 'Assemble the relevant evidence and knowledge around a network question.'],
  explain: ['Explain', 'Turn network concepts and observed state into a practical engineering explanation.'],
  diagnose: ['Diagnose', 'Reason from observed evidence without claiming a root cause the data does not support.'],
  plan: ['Plan change', 'Translate a supported request into a typed, reviewable configuration proposal.'],
  review: ['Review', 'Look at health and recent configuration evidence before another change.'],
  document: ['Document', 'Produce a concise engineering record from the current evidence and linked knowledge.'],
};

function Icon({ name, size = 16 }) {
  const paths = {
    brain: <><path d="M9.5 4a3.5 3.5 0 0 0-3.2 4.9A3.5 3.5 0 0 0 5 15.5 3.5 3.5 0 0 0 9.5 19H10V4z"/><path d="M14.5 4a3.5 3.5 0 0 1 3.2 4.9A3.5 3.5 0 0 1 19 15.5a3.5 3.5 0 0 1-4.5 3.5H14V4z"/><path d="M10 8h4M10 12h4M10 16h4"/></>,
    arrow: <><path d="M5 12h13"/><path d="m13 6 6 6-6 6"/></>,
    copy: <><rect x="8" y="8" width="11" height="12" rx="1"/><path d="M16 8V5H5a1 1 0 0 0-1 1v12h4"/></>,
    download: <><path d="M12 4v11"/><path d="m8 11 4 4 4-4"/><path d="M5 20h14"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    external: <><path d="M14 5h5v5"/><path d="m19 5-8 8"/><path d="M19 13v5a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

export default function TwinIntelligence({ setView }) {
  const { labState, topology } = useNetworkWorkspace();
  const devices = useMemo(() => buildDeviceInventory(labState), [labState]);
  const [deviceId, setDeviceId] = useState(devices[0]?.id || '');
  const selectedDevice = devices.find(device => device.id === deviceId) || devices[0] || null;
  const [mode, setMode] = useState('investigate');
  const [prompt, setPrompt] = useState('Why is Gi0/1 down on this device?');
  const [includeLab, setIncludeLab] = useState(true);
  const [includeMemory, setIncludeMemory] = useState(true);
  const [response, setResponse] = useState(null);
  const [history, setHistory] = useState(() => loadTwinHistory(safeStorage));
  const [message, setMessage] = useState('');

  const context = useMemo(() => {
    if (!selectedDevice || !includeLab) return buildTwinContext({ prompt, mode, topology });
    const inspection = inspectSimulatedDevice(labState, selectedDevice.id);
    const diagnostics = buildDeviceDiagnostics({ device: selectedDevice, inspection, history: [], connected: true });
    return buildTwinContext({ prompt, mode, device: selectedDevice, inspection, diagnostics, history: [], twinHistory: includeMemory ? history.slice(-5) : [], topology });
  }, [prompt, mode, selectedDevice, labState, topology, includeLab, includeMemory, history]);

  const runTwin = () => {
    const result = generateTwinResponse(context);
    setResponse(result);
    setHistory(current => saveTwinHistory(safeStorage, current, { mode, prompt, answer: result.answer, confidence: result.confidence, knowledge: result.knowledge }));
    setMessage('Twin response generated from the selected local context.');
  };

  const adoptProposal = () => {
    if (!response?.proposal?.valid) return;
    setMessage('Typed proposal prepared. Opening Configuration keeps the normal Preview → Apply → Verify controls in charge.');
    setView?.('config');
  };

  const modelContext = useMemo(() => buildModelContext(context), [context]);

  const startTwinWorkflow = () => {
    startWorkflow(safeStorage, workflowFromTwin(prompt, { target: selectedDevice ? { type: 'device', id: selectedDevice.id } : null }));
    setView?.('workflows');
  };

  const copyContext = async () => {
    try {
      await navigator.clipboard.writeText(modelContext);
      setMessage('Redacted model context copied to the clipboard.');
    } catch {
      setMessage('Clipboard access is unavailable. Use Export context instead.');
    }
  };

  const exportContext = () => {
    const blob = new Blob([modelContext], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'driller-bill-twin-context.json';
    anchor.click();
    URL.revokeObjectURL(url);
    setMessage('Redacted model context exported.');
  };

  return <main className="page twin-intelligence-page"><UnifiedWorkflowBar view="twin" setView={setView}/>
    <section className="twin-intelligence-hero">
      <div>
        <div className="eyebrow">ENGINEERING / TWIN INTELLIGENCE / LOCAL-FIRST</div>
        <h1>Reason from <span>evidence.</span></h1>
        <p>Twin combines the Knowledge Graph with observed network state to explain, investigate, review and prepare engineering changes. No external model is required.</p>
      </div>
      <div className="twin-hero-badge"><Icon name="brain" size={20}/><div><strong>TWIN {response ? 'ACTIVE' : 'READY'}</strong><span>Deterministic reasoning layer</span></div></div>
    </section>

    <section className="panel twin-mode-panel">
      <div className="twin-section-head"><div><div className="kicker">01 / MODE</div><h2>Choose the kind of reasoning you need.</h2></div><span>{MODE_META[mode][1]}</span></div>
      <div className="twin-mode-grid">{TWIN_MODES.map(id => <button key={id} className={`twin-mode-card ${mode === id ? 'selected' : ''}`} onClick={() => { setMode(id); if (id !== 'investigate') setPrompt(id === 'diagnose' ? 'Diagnose the most important problem visible on this device.' : id === 'explain' ? 'Explain the most relevant concept for this device.' : id === 'plan' ? 'Create VLAN 20 named ENGINEERING.' : id === 'review' ? 'Review the current device state for configuration risk.' : 'Document the current engineering state.'); }}><b>{MODE_META[id][0]}</b><span>{MODE_META[id][1]}</span></button>)}</div>
    </section>

    <section className="twin-work-grid">
      <section className="panel twin-prompt-panel">
        <div className="twin-section-head"><div><div className="kicker">02 / REQUEST</div><h2>Ask Twin</h2></div><span>LOCAL CONTEXT</span></div>
        <label className="twin-field"><span>TARGET DEVICE</span><select value={deviceId} onChange={event => setDeviceId(event.target.value)}>{devices.map(device => <option key={device.id} value={device.id}>{device.id} · {device.kind}</option>)}</select></label>
        <label className="twin-field"><span>REQUEST</span><textarea value={prompt} onChange={event => setPrompt(event.target.value)} rows={7} placeholder="Describe the network question, symptom, desired change, or review task." /></label>
        <div className="twin-context-options"><label><input type="checkbox" checked={includeLab} onChange={event => setIncludeLab(event.target.checked)}/><span>Use current lab state</span></label><label><input type="checkbox" checked={includeMemory} onChange={event => setIncludeMemory(event.target.checked)}/><span>Include Twin memory</span></label></div>
        <div className="twin-prompt-actions"><button className="button primary large" onClick={runTwin} disabled={!prompt.trim()}><Icon name="brain" size={15}/> Run Twin</button><small>Mode inference: {inferTwinMode(prompt)}</small></div>
        <div className="twin-example-row"><span>TRY</span><button onClick={() => { setMode('diagnose'); setPrompt('Why is Gi0/24 not carrying VLAN 20?'); }}>trunk diagnosis</button><button onClick={() => { setMode('plan'); setPrompt('Create VLAN 30 named ENGINEERING.'); }}>typed change</button><button onClick={() => { setMode('explain'); setPrompt('Explain why trunks need an explicit VLAN allow-list.'); }}>concept explanation</button></div>
      </section>

      <section className="panel twin-result-panel">
        <div className="twin-section-head"><div><div className="kicker">03 / RESULT</div><h2>{response ? MODE_META[response.mode][0] : 'Twin response'}</h2></div>{response && <div className="twin-confidence"><strong>{response.confidence}%</strong><span>context confidence</span></div>}</div>
        {!response ? <div className="twin-empty"><Icon name="brain" size={25}/><strong>Nothing inferred yet.</strong><span>Run Twin after selecting a device and writing the engineering question. The response will separate evidence from inference.</span></div> : <div className="twin-result-body">
          <div className="twin-answer"><span>ASSESSMENT</span><p>{response.answer}</p></div>
          <div className="twin-two-col">
            <div><div className="twin-subhead">EVIDENCE</div>{response.evidence.length ? response.evidence.map((item, index) => <div className={`twin-evidence ${item.severity}`} key={`${item.label}-${index}`}><span>{item.label}</span><strong>{item.value}</strong></div>) : <div className="twin-muted">No device-specific evidence is available.</div>}</div>
            <div><div className="twin-subhead">NEXT ACTIONS</div>{response.recommendations.map((item, index) => <div className="twin-recommendation" key={index}><Icon name="check" size={13}/><span>{item}</span></div>)}</div>
          </div>
          {response.proposal?.intent && <div className={`twin-proposal ${response.proposal.valid ? 'valid' : 'invalid'}`}><div><span>STRUCTURED PROPOSAL</span><strong>{response.proposal.intent.title}</strong></div>{(response.proposal.displayCommands || response.proposal.commands)?.map((command, index) => <code key={`${command}-${index}`}>{command}</code>)}{response.proposal.errors?.length > 0 && response.proposal.errors.map((error, index) => <small key={index}>{error}</small>)}{response.proposal.valid && <button className="button" onClick={adoptProposal}>Prepare in Configuration <Icon name="arrow" size={11}/></button>}</div>}
          <div className="twin-guardrails"><span>GUARDRAILS</span>{response.guardrails.map((item, index) => <p key={index}>{item}</p>)}</div>
        </div>}
      </section>
    </section>

    <section className="twin-lower-grid">
      <section className="panel twin-knowledge-panel"><div className="twin-section-head"><div><div className="kicker">04 / KNOWLEDGE</div><h2>Connected references</h2></div><span>{response?.knowledge?.length || 0} matches</span></div>{response?.knowledge?.length ? response.knowledge.map(item => <article className="twin-knowledge-card" key={item.article.id}><div><span>{item.article.category} · {item.article.level}</span><strong>{item.article.title}</strong><p>{item.article.summary}</p></div><div className="twin-resource-counts">{Object.entries(item.connections).filter(([, values]) => values.length).map(([type, values]) => <b key={type}>{values.length} {type.replace(/s$/, '')}{values.length === 1 ? '' : 's'}</b>)}</div></article>) : <div className="twin-muted">Relevant articles appear here after the first Twin run.</div>}</section>

      <section className="panel twin-history-panel"><div className="twin-section-head"><div><div className="kicker">05 / MEMORY</div><h2>Local Twin history</h2></div><span>{history.length} records</span></div>{history.length ? <div className="twin-history-list">{[...history].reverse().slice(0, 8).map(item => <button key={item.id} onClick={() => { setPrompt(item.prompt); setMode(item.mode); }}><span>{item.mode}</span><strong>{item.prompt}</strong><small>{new Date(item.createdAt).toLocaleString()}</small></button>)}</div> : <div className="twin-muted">Twin keeps a small local history of requests and conclusions. Sensitive-looking text is redacted before storage.</div>}</section>
    </section>

    <section className="panel twin-handoff-panel"><div><div className="kicker">06 / MODEL HANDOFF</div><h2>Bring your own LLM later.</h2><p>Twin already produces a sanitized, structured context package. Copy or export it to an external model when you choose one; device credentials and secret-looking configuration values are redacted first.</p></div><div className="twin-handoff-actions"><button className="button primary" onClick={startTwinWorkflow}><Icon name="arrow" size={13}/> Start workflow thread</button><button className="button" onClick={copyContext}><Icon name="copy" size={13}/> Copy context</button><button className="button" onClick={exportContext}><Icon name="download" size={13}/> Export context</button></div></section>
    {message && <div className="twin-toast" role="status">{message}</div>}
  </main>;
}
