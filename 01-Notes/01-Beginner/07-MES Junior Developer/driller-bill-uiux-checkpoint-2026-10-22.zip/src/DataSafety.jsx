import React, { useEffect, useState } from 'react';
import { createStudySnapshot, restoreStudySnapshot, validateStudySnapshot, downloadStudySnapshot } from './core/data-safety.js';

function humanSize(text) {
  const bytes = new Blob([text]).size;
  if (bytes < 1024) return `${bytes} B`;
  return `${(bytes / 1024).toFixed(1)} KB`;
}

export default function DataSafety({ onReload }) {
  const [online, setOnline] = useState(() => typeof navigator === 'undefined' ? true : navigator.onLine !== false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [backupText, setBackupText] = useState('');

  useEffect(() => {
    const onlineHandler = () => setOnline(true);
    const offlineHandler = () => setOnline(false);
    window.addEventListener('online', onlineHandler);
    window.addEventListener('offline', offlineHandler);
    return () => {
      window.removeEventListener('online', onlineHandler);
      window.removeEventListener('offline', offlineHandler);
    };
  }, []);

  const createBackup = () => {
    try {
      const snapshot = createStudySnapshot();
      const text = JSON.stringify(snapshot, null, 2);
      setBackupText(text);
      setError('');
      setMessage(`Backup ready · ${humanSize(text)}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not create backup.');
      setMessage('');
    }
  };

  const restoreFromText = () => {
    try {
      const parsed = JSON.parse(backupText);
      const validation = validateStudySnapshot(parsed);
      if (!validation.valid) throw new Error(validation.errors.join(' '));
      restoreStudySnapshot(parsed);
      setError('');
      setMessage('Study data restored. Reload Driller Bill to apply it everywhere.');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not restore backup.');
      setMessage('');
    }
  };

  const importFile = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    try {
      const text = await file.text();
      setBackupText(text);
      const validation = validateStudySnapshot(JSON.parse(text));
      if (!validation.valid) throw new Error(validation.errors.join(' '));
      setError('');
      setMessage(`Valid backup detected · ${humanSize(text)}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'That file is not a valid Driller Bill backup.');
      setMessage('');
    }
  };

  return (
    <main className="page data-safety-page">
      <section className="hero compact-hero">
        <div className="hero-copy">
          <div className="eyebrow">SYSTEM / DATA & RECOVERY</div>
          <h1>Keep your study data<br/><span>under your control.</span></h1>
          <p>Driller Bill stores your local history, mastery, authored content, live lab state, and saved assessments in the browser.</p>
          <div className="hero-actions">
            <button className="button primary" onClick={() => { createBackup(); downloadStudySnapshot(); }}>Download backup</button>
            <label className="button large file-button">Import backup<input type="file" accept="application/json,.json" onChange={importFile}/></label>
          </div>
        </div>
        <div className="hero-stats">
          <div className="stat"><span>Connection</span><strong>{online ? 'ONLINE' : 'OFFLINE'}</strong><small>{online ? 'browser network available' : 'local-first mode is still usable'}</small></div>
          <div className="stat"><span>Backup format</span><strong>V1</strong><small>portable JSON snapshot</small></div>
        </div>
      </section>

      <div className="data-safety-grid">
        <section className="panel">
          <div className="panel-head"><div><div className="kicker">01 / BACKUP</div><h2>Create a recovery point.</h2></div><span className="panel-micro">LOCAL EXPORT</span></div>
          <p className="panel-copy">A backup contains completed attempts, question exposure history, mastery cards, settings, authored questions, the live network lab, and the saved topology. It does not upload anything to a server.</p>
          <div className="safety-actions">
            <button className="button primary" onClick={createBackup}>Generate backup JSON</button>
            <button className="button" onClick={downloadStudySnapshot}>Download directly</button>
          </div>
          {backupText && <textarea className="backup-preview" value={backupText} onChange={(e) => setBackupText(e.target.value)} aria-label="Backup JSON preview" spellCheck="false" />}
        </section>

        <section className="panel">
          <div className="panel-head"><div><div className="kicker">02 / RESTORE</div><h2>Restore a known-good state.</h2></div><span className="panel-micro">VALIDATED JSON</span></div>
          <p className="panel-copy">Driller Bill validates the backup schema before writing anything. Existing data is preserved unless a matching backup field is restored.</p>
          <button className="button primary" onClick={restoreFromText} disabled={!backupText}>Restore current backup</button>
          {onReload && <button className="button" onClick={onReload}>Reload workspace</button>}
          {(message || error) && <div className={`feedback ${error ? 'bad' : 'ok'}`} role="status"><b>{error ? 'RECOVERY CHECK FAILED' : 'RECOVERY READY'}</b><p>{error || message}</p></div>}
        </section>
      </div>
    </main>
  );
}
