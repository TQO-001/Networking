/* Driller Bill v13 expanded question families — original CCNA-aligned practice content. */
const F=(domain,topic,id,q,options,answer,explanation,type='single',meta={})=>({domain,topic,id,q,options,answer:Array.isArray(answer)?answer:[answer],explanation,type,...meta});
export const PF_EXPANDED_FAMILIES=
[
  {
    "domain": "1",
    "topic": "1.1",
    "id": "NF-V13-01",
    "q": "Which device is designed primarily to enforce security policy between network security zones?",
    "options": [
      "Firewall",
      "Repeater",
      "Patch panel",
      "Layer 1 transceiver"
    ],
    "answer": [
      0
    ],
    "explanation": "A firewall applies security policy to traffic between defined security zones.",
    "type": "application",
    "tags": [
      "security-device",
      "firewall"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "1",
    "topic": "1.2",
    "id": "NF-V13-02",
    "q": "Which campus design separates user-facing switching from aggregation and the network core?",
    "options": [
      "Three-tier architecture",
      "Bus topology",
      "Single-cable ring",
      "Point-to-point host topology"
    ],
    "answer": [
      0
    ],
    "explanation": "The classic three-tier campus design separates access, distribution, and core roles.",
    "type": "foundation",
    "tags": [
      "campus-architecture"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "1",
    "topic": "1.3",
    "id": "NF-V13-03",
    "q": "A switch interface is operating at 1000 Mb/s full duplex. What does full duplex imply?",
    "options": [
      "The interface can transmit and receive simultaneously",
      "The interface can only receive frames",
      "The link uses CSMA/CD for every frame",
      "The cable must be coaxial"
    ],
    "answer": [
      0
    ],
    "explanation": "Full duplex allows simultaneous transmission and reception on a switched Ethernet link.",
    "type": "foundation",
    "tags": [
      "duplex",
      "ethernet"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "1",
    "topic": "1.4",
    "id": "NF-V13-04",
    "q": "A cable works intermittently when physically moved near the connector. Which cause is most plausible?",
    "options": [
      "A damaged connector or cable termination",
      "A wrong DNS record",
      "An OSPF area mismatch",
      "An incorrect NTP stratum"
    ],
    "answer": [
      0
    ],
    "explanation": "Movement affecting link quality strongly suggests a physical cable, connector, or termination fault.",
    "type": "analysis",
    "tags": [
      "layer1",
      "troubleshooting"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "1",
    "topic": "1.5",
    "id": "NF-V13-05",
    "q": "Which transport-layer value allows multiple applications on one host to use the same IP address?",
    "options": [
      "TCP or UDP port numbers",
      "MAC address table entries",
      "VLAN names",
      "ARP cache timers"
    ],
    "answer": [
      0
    ],
    "explanation": "Transport port numbers identify application endpoints and allow multiple flows to share an IP address.",
    "type": "foundation",
    "tags": [
      "ports",
      "tcp",
      "udp"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "1",
    "topic": "1.12",
    "id": "NF-V13-06",
    "q": "Why would an organization use a separate VRF for management traffic?",
    "options": [
      "To keep the management routing table logically separate from production routing",
      "To encrypt every management packet automatically",
      "To replace all Layer 2 VLANs",
      "To provide wireless roaming"
    ],
    "answer": [
      0
    ],
    "explanation": "A separate VRF can isolate management routing from production routing on the same device.",
    "type": "application",
    "tags": [
      "vrf",
      "management"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "1",
    "topic": "1.5",
    "id": "NF-V13-M02",
    "q": "Which TWO statements correctly describe TCP and UDP?",
    "options": [
      "TCP is connection-oriented and supports reliable delivery",
      "UDP is connectionless and has lower protocol overhead than TCP",
      "UDP guarantees ordered retransmission",
      "TCP does not use port numbers"
    ],
    "answer": [
      0,
      1
    ],
    "explanation": "TCP provides connection-oriented reliable transport features. UDP is connectionless and has less transport overhead.",
    "type": "multi",
    "tags": [
      "tcp",
      "udp"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "2",
    "topic": "2.1",
    "id": "NA-V13-01",
    "q": "What happens when a switchport is configured with `switchport access vlan 20` in access mode?",
    "options": [
      "Frames arriving from the endpoint are associated with VLAN 20",
      "The interface becomes a routed port",
      "All VLANs become tagged on the endpoint link",
      "The interface automatically joins an EtherChannel"
    ],
    "answer": [
      0
    ],
    "explanation": "An access port is associated with its configured access VLAN.",
    "type": "foundation",
    "tags": [
      "vlan",
      "access-port"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "2",
    "topic": "2.2",
    "id": "NA-V13-02",
    "q": "Why are VLAN tags useful on an interswitch trunk?",
    "options": [
      "They preserve VLAN identity while multiple VLANs share the link",
      "They replace IP addresses",
      "They provide encryption by default",
      "They identify the physical cable vendor"
    ],
    "answer": [
      0
    ],
    "explanation": "802.1Q tagging carries VLAN identity across a shared trunk link.",
    "type": "foundation",
    "tags": [
      "8021q",
      "trunks"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "2",
    "topic": "2.3",
    "id": "NA-V13-03",
    "q": "Which trunk condition is commonly associated with untagged Ethernet frames?",
    "options": [
      "The native VLAN",
      "The routing protocol metric",
      "The OSPF router ID",
      "The DHCP lease timer"
    ],
    "answer": [
      0
    ],
    "explanation": "The native VLAN is used for traffic that is sent without an 802.1Q tag on a trunk.",
    "type": "foundation",
    "tags": [
      "native-vlan"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "2",
    "topic": "2.4",
    "id": "NA-V13-04",
    "q": "What is the purpose of the Port-Channel logical interface?",
    "options": [
      "It represents a bundled set of physical links as one logical link",
      "It replaces every physical interface with a console line",
      "It creates a new IP subnet automatically",
      "It disables spanning tree globally"
    ],
    "answer": [
      0
    ],
    "explanation": "The port-channel represents the EtherChannel bundle as one logical interface to Layer 2 or Layer 3 protocols.",
    "type": "application",
    "tags": [
      "etherchannel",
      "port-channel"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "2",
    "topic": "2.5",
    "id": "NA-V13-05",
    "q": "A switch receives a superior BPDU on a port that was forwarding. What can STP do as a result?",
    "options": [
      "Recalculate the spanning-tree topology and change port roles if required",
      "Assign a new IP address to the port",
      "Disable DNS resolution",
      "Create an OSPF area automatically"
    ],
    "answer": [
      0
    ],
    "explanation": "A superior BPDU can trigger STP to recalculate the tree and change forwarding/blocking roles.",
    "type": "analysis",
    "tags": [
      "stp",
      "bpdu"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "2",
    "topic": "2.7",
    "id": "NA-V13-06",
    "q": "Which WLAN design lets an AP continue using centralized policy while the controller handles configuration and coordination?",
    "options": [
      "Lightweight/controller-based WLAN architecture",
      "Standalone unmanaged Ethernet only",
      "Passive copper distribution",
      "Console-only WLAN"
    ],
    "answer": [
      0
    ],
    "explanation": "Controller-based WLANs centralize configuration and policy while APs provide radio access.",
    "type": "application",
    "tags": [
      "wlc",
      "wireless"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "2",
    "topic": "2.4",
    "id": "NA-V13-M02",
    "q": "Which TWO statements describe LACP EtherChannel?",
    "options": [
      "It negotiates link aggregation between compatible member interfaces",
      "The resulting port-channel is treated as one logical link by STP",
      "Each member must have a different VLAN configuration",
      "LACP requires BGP on every member"
    ],
    "answer": [
      0,
      1
    ],
    "explanation": "LACP negotiates the bundle and the resulting Port-Channel is treated as one logical link by STP.",
    "type": "multi",
    "tags": [
      "lacp",
      "stp"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "3",
    "topic": "3.1",
    "id": "IP-V13-01",
    "q": "What does the routing-table code `C` commonly represent on Cisco IOS?",
    "options": [
      "A directly connected network",
      "An OSPF learned route",
      "A static route",
      "A default route only"
    ],
    "answer": [
      0
    ],
    "explanation": "C denotes a connected route associated with an active Layer 3 interface.",
    "type": "foundation",
    "tags": [
      "routing-table",
      "connected"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "3",
    "topic": "3.2",
    "id": "IP-V13-02",
    "q": "A router has 192.168.0.0/16 and 192.168.50.0/24. Which route matches 192.168.50.25?",
    "options": [
      "192.168.50.0/24",
      "192.168.0.0/16",
      "Both routes equally",
      "Neither route"
    ],
    "answer": [
      0
    ],
    "explanation": "The /24 is the longest matching prefix for 192.168.50.25.",
    "type": "analysis",
    "tags": [
      "longest-prefix"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "3",
    "topic": "3.2",
    "id": "IP-V13-03",
    "q": "If two routes to the same prefix come from the same routing protocol, which value is typically compared after the protocol is selected?",
    "options": [
      "That protocol\u2019s metric",
      "The DNS TTL",
      "The switch MAC address table",
      "The VLAN name"
    ],
    "answer": [
      0
    ],
    "explanation": "Within the same routing protocol, its metric is used to compare candidate paths according to that protocol\u2019s rules.",
    "type": "application",
    "tags": [
      "metrics",
      "route-selection"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "3",
    "topic": "3.3",
    "id": "IP-V13-04",
    "q": "Which static route uses an exit interface rather than a next-hop address?",
    "options": [
      "ip route 10.30.0.0 255.255.0.0 GigabitEthernet0/1",
      "ip route 10.30.0.0 255.255.0.0 10.0.0.2",
      "router ospf 1",
      "ip default-gateway 10.0.0.2"
    ],
    "answer": [
      0
    ],
    "explanation": "The first form specifies the outgoing interface directly.",
    "type": "application",
    "tags": [
      "static-route",
      "exit-interface"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "3",
    "topic": "3.4",
    "id": "IP-V13-05",
    "q": "Why is a loopback interface commonly useful as an OSPF router ID source?",
    "options": [
      "It is a stable logical interface that can remain available when a physical interface changes state",
      "It automatically becomes the default gateway for hosts",
      "It disables OSPF hello packets",
      "It converts IPv4 to IPv6"
    ],
    "answer": [
      0
    ],
    "explanation": "A loopback is a stable logical interface and is commonly preferred as a router ID source when configured appropriately.",
    "type": "application",
    "tags": [
      "ospf",
      "loopback"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "3",
    "topic": "3.5",
    "id": "IP-V13-06",
    "q": "What advantage does an FHRP virtual IP provide to hosts?",
    "options": [
      "Hosts can keep the same default-gateway address while the active gateway device changes",
      "Hosts no longer need subnet masks",
      "The router can remove all static routes",
      "The switch no longer needs STP"
    ],
    "answer": [
      0
    ],
    "explanation": "A virtual gateway address remains stable while different physical routers can provide forwarding service.",
    "type": "application",
    "tags": [
      "fhrp",
      "gateway-redundancy"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "3",
    "topic": "3.2",
    "id": "IP-V13-M02",
    "q": "Which TWO items can affect the final route selected for a destination?",
    "options": [
      "Prefix specificity",
      "Administrative distance and, where applicable, routing metric",
      "The hostname of the router",
      "The length of an interface description"
    ],
    "answer": [
      0,
      1
    ],
    "explanation": "Longest-prefix matching determines which route entries apply, followed by route-selection criteria such as administrative distance and metric.",
    "type": "multi",
    "tags": [
      "route-selection"
    ],
    "cognitiveLevel": "analysis",
    "misconception": null
  },
  {
    "domain": "4",
    "topic": "4.1",
    "id": "IS-V13-01",
    "q": "What information does a PAT translation normally need to distinguish simultaneous connections from many internal hosts?",
    "options": [
      "Transport-layer port information",
      "VLAN names only",
      "OSPF area numbers",
      "The switch hostname"
    ],
    "answer": [
      0
    ],
    "explanation": "PAT uses port information to distinguish multiple translated flows sharing public addressing.",
    "type": "application",
    "tags": [
      "pat",
      "nat"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "4",
    "topic": "4.2",
    "id": "IS-V13-02",
    "q": "A device clock is drifting several minutes each day. Which service should be investigated?",
    "options": [
      "NTP",
      "DNS",
      "TFTP",
      "STP"
    ],
    "answer": [
      0
    ],
    "explanation": "NTP is used to synchronize device clocks with a reliable time source.",
    "type": "foundation",
    "tags": [
      "ntp",
      "time"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "4",
    "topic": "4.3",
    "id": "IS-V13-03",
    "q": "Which DNS record type maps a hostname to an IPv6 address?",
    "options": [
      "AAAA",
      "A",
      "MX",
      "PTR-only"
    ],
    "answer": [
      0
    ],
    "explanation": "AAAA records map hostnames to IPv6 addresses.",
    "type": "foundation",
    "tags": [
      "dns",
      "ipv6"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "4",
    "topic": "4.4",
    "id": "IS-V13-04",
    "q": "Why is SNMP useful for network monitoring?",
    "options": [
      "It provides a standardized way to collect management and monitoring information",
      "It replaces every routing protocol",
      "It automatically configures switchports",
      "It assigns IPv4 addresses to clients"
    ],
    "answer": [
      0
    ],
    "explanation": "SNMP is commonly used to monitor and manage network devices by exchanging structured management information.",
    "type": "foundation",
    "tags": [
      "snmp",
      "monitoring"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "4",
    "topic": "4.5",
    "id": "IS-V13-05",
    "q": "Which syslog severity is more severe: 2 or 6?",
    "options": [
      "2",
      "6",
      "They are equally severe",
      "Severity depends only on the hostname"
    ],
    "answer": [
      0
    ],
    "explanation": "Lower syslog severity numbers represent more severe events; 2 is more severe than 6.",
    "type": "foundation",
    "tags": [
      "syslog",
      "severity"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "4",
    "topic": "4.6",
    "id": "IS-V13-06",
    "q": "A client and its DHCP server are separated by a router. What allows the DHCP request to cross the Layer 3 boundary?",
    "options": [
      "A DHCP relay agent such as `ip helper-address`",
      "A trunk native VLAN mismatch",
      "An OSPF router ID",
      "A MAC aging timer"
    ],
    "answer": [
      0
    ],
    "explanation": "A DHCP relay forwards client DHCP messages across a Layer 3 boundary to the remote server.",
    "type": "application",
    "tags": [
      "dhcp",
      "relay"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "4",
    "topic": "4.5",
    "id": "IS-V13-M02",
    "q": "Which TWO services improve the quality of centralized network-event investigation?",
    "options": [
      "Consistent NTP time across devices",
      "Centralized syslog collection",
      "Disabling timestamps",
      "Keeping logs only on each local console"
    ],
    "answer": [
      0,
      1
    ],
    "explanation": "Consistent time and centralized event records help correlate events across multiple devices.",
    "type": "multi",
    "tags": [
      "ntp",
      "syslog"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "5",
    "topic": "5.1",
    "id": "SEC-V13-01",
    "q": "Which action best describes phishing?",
    "options": [
      "Using deceptive messages to persuade a user to reveal information or take an unsafe action",
      "Scanning a switch for MAC addresses only",
      "Changing a VLAN from 10 to 20",
      "Synchronizing device clocks"
    ],
    "answer": [
      0
    ],
    "explanation": "Phishing uses deception, often through messages or websites, to manipulate users into unsafe actions.",
    "type": "foundation",
    "tags": [
      "phishing",
      "social-engineering"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "5",
    "topic": "5.2",
    "id": "SEC-V13-02",
    "q": "Which security approach assumes no implicit trust solely because a user or device is already on the internal network?",
    "options": [
      "Zero-trust principles",
      "Open authentication",
      "Implicit trust",
      "Shared broadcast flooding"
    ],
    "answer": [
      0
    ],
    "explanation": "Zero-trust principles require explicit verification and policy enforcement rather than trusting users or devices solely by network location.",
    "type": "application",
    "tags": [
      "zero-trust"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "5",
    "topic": "5.3",
    "id": "SEC-V13-03",
    "q": "Which AAA component verifies that a username and password belong to the claimed user?",
    "options": [
      "Authentication",
      "Authorization",
      "Accounting",
      "Auditing only"
    ],
    "answer": [
      0
    ],
    "explanation": "Authentication verifies identity.",
    "type": "foundation",
    "tags": [
      "aaa",
      "authentication"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "5",
    "topic": "5.4",
    "id": "SEC-V13-04",
    "q": "Why is ACL placement important?",
    "options": [
      "The location affects which traffic is filtered and how much unwanted traffic is allowed farther into the network",
      "ACLs always work identically on every interface",
      "Placement changes the MAC address of packets",
      "Placement determines DHCP lease duration"
    ],
    "answer": [
      0
    ],
    "explanation": "ACL placement determines where filtering occurs and which traffic is prevented from traveling further through the network.",
    "type": "application",
    "tags": [
      "acl",
      "placement"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "5",
    "topic": "5.5",
    "id": "SEC-V13-05",
    "q": "What does port security primarily control on a switch access port?",
    "options": [
      "Which source MAC addresses and how many source MAC addresses may be learned",
      "Which OSPF area is used",
      "Which DNS server a host selects",
      "Which VLAN is the native VLAN on every trunk"
    ],
    "answer": [
      0
    ],
    "explanation": "Port security constrains source MAC addresses and the number of allowed secure addresses on an interface.",
    "type": "application",
    "tags": [
      "port-security"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "5",
    "topic": "5.7",
    "id": "SEC-V13-06",
    "q": "Why can DAI reduce ARP spoofing risk?",
    "options": [
      "It validates ARP information against trusted bindings or configured inspection data",
      "It hides every MAC address from switches",
      "It disables all IPv4 routing",
      "It converts ARP into OSPF"
    ],
    "answer": [
      0
    ],
    "explanation": "Dynamic ARP Inspection validates ARP information to reduce spoofed ARP mappings.",
    "type": "application",
    "tags": [
      "dai",
      "arp"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "5",
    "topic": "5.4",
    "id": "SEC-V13-M02",
    "q": "Which TWO controls can provide defense in depth for an administrator-accessible switch?",
    "options": [
      "MFA for administrative access",
      "Role-based authorization / least privilege",
      "Removing all logging",
      "Using Telnet instead of SSH"
    ],
    "answer": [
      0,
      1
    ],
    "explanation": "MFA strengthens identity verification and least privilege reduces the authorization available to an account.",
    "type": "multi",
    "tags": [
      "mfa",
      "aaa",
      "least-privilege"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "6",
    "topic": "6.1",
    "id": "AUTO-V13-01",
    "q": "What is a key operational benefit of using a repeatable automation workflow?",
    "options": [
      "The same validated procedure can be applied consistently across many devices",
      "It removes the need to understand the network",
      "It guarantees no configuration can ever be wrong",
      "It prevents all outages automatically"
    ],
    "answer": [
      0
    ],
    "explanation": "Repeatable automation can improve consistency and reduce manual variation, while still requiring validation.",
    "type": "application",
    "tags": [
      "automation",
      "consistency"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "6",
    "topic": "6.2",
    "id": "AUTO-V13-02",
    "q": "Which capability is commonly centralized by a controller in a controller-based architecture?",
    "options": [
      "Policy, orchestration, and management of multiple devices",
      "Physical cable termination",
      "The Ethernet preamble",
      "The electrical signaling of every switchport"
    ],
    "answer": [
      0
    ],
    "explanation": "Controllers can centralize policy, orchestration, and management across multiple network devices.",
    "type": "foundation",
    "tags": [
      "controller",
      "policy"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "6",
    "topic": "6.3",
    "id": "AUTO-V13-03",
    "q": "Which statement best describes an overlay tunnel?",
    "options": [
      "A logical connectivity construct that uses an underlay transport network",
      "A physical copper cable standard",
      "A DNS record",
      "A local console password"
    ],
    "answer": [
      0
    ],
    "explanation": "An overlay is a logical network construct carried over an underlying transport network.",
    "type": "foundation",
    "tags": [
      "overlay",
      "tunnel"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "6",
    "topic": "6.4",
    "id": "AUTO-V13-04",
    "q": "Which machine-learning approach uses labeled examples to learn a mapping from input to known output categories?",
    "options": [
      "Supervised learning",
      "Unsupervised learning",
      "Random cabling",
      "Manual configuration"
    ],
    "answer": [
      0
    ],
    "explanation": "Supervised learning trains on labeled examples with known outputs.",
    "type": "foundation",
    "tags": [
      "machine-learning",
      "supervised"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "6",
    "topic": "6.5",
    "id": "AUTO-V13-05",
    "q": "Which REST method is commonly used to partially update an existing resource?",
    "options": [
      "PATCH",
      "GET",
      "DELETE",
      "HEAD-only"
    ],
    "answer": [
      0
    ],
    "explanation": "PATCH is commonly used for partial updates to a resource.",
    "type": "foundation",
    "tags": [
      "rest",
      "http"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "6",
    "topic": "6.6",
    "id": "AUTO-V13-06",
    "q": "Which approach is most associated with declarative infrastructure management?",
    "options": [
      "Describe desired state and let the tool determine the changes",
      "Manually type each device command in a fixed order",
      "Replace all routing protocols with scripts",
      "Avoid storing configuration as code"
    ],
    "answer": [
      0
    ],
    "explanation": "Declarative tooling focuses on desired end state rather than prescribing every implementation step.",
    "type": "application",
    "tags": [
      "iac",
      "declarative"
    ],
    "cognitiveLevel": "application",
    "misconception": null
  },
  {
    "domain": "6",
    "topic": "6.5",
    "id": "AUTO-V13-M02",
    "q": "Which TWO statements correctly describe JSON used by network APIs?",
    "options": [
      "Objects use key/value pairs separated by colons",
      "Arrays use square brackets",
      "Object members are separated by equals signs",
      "JSON requires single quotes around every string"
    ],
    "answer": [
      0,
      1
    ],
    "explanation": "JSON objects use key/value pairs and arrays use square brackets. JSON strings use double quotes.",
    "type": "multi",
    "tags": [
      "json",
      "rest"
    ],
    "cognitiveLevel": "foundation",
    "misconception": null
  }
]
;

export const PF_EXPANDED_VARIANT_TEMPLATES=[
  q=>q,
  q=>`A network engineer is assessing this situation. ${q}`,
  q=>`During troubleshooting, the engineer asks: ${q}`,
  q=>`Which response is technically correct for this requirement? ${q}`,
  q=>`Choose the option that best resolves or explains the networking issue: ${q}`
];

export function expandQuestionFamilies(){
  return PF_EXPANDED_FAMILIES.flatMap(f=>PF_EXPANDED_VARIANT_TEMPLATES.map((wrap,i)=>({...f,questionId:`${f.id}-V${i+1}`,variant:i+1,prompt:wrap(f.q),presentation:i===2?'troubleshooting':i===1?'scenario':'standard'})));
}
