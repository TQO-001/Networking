// Driller Bill 3.0 — original exhibit/scenario assessment bank.
// These are authored training items, not Cisco exam content.

const E = (domain, topic, id, concept, promptVariants, options, answer, explanation, exhibit) => ({
  domain, topic, id, concept, promptVariants, options, answer: Array.isArray(answer) ? answer : [answer], explanation, exhibit,
});

export const PF_EXHIBITS = [
  E('1','1.6','EX-NF-01','IPv4 subnetting',[
    'Review the address assignment below. Which subnet contains Host-A?',
    'An engineer is verifying Host-A. Which network boundary applies to its address?',
    'Based on the given IPv4 address and prefix, identify the correct containing subnet.',
    'The addressing plan is shown below. Where does Host-A logically belong?',
    'Which subnet should be listed for Host-A from the exhibit?'
  ], ['192.168.50.0/26','192.168.50.64/26','192.168.50.128/26','192.168.50.192/26'], 1,
    'A /26 creates blocks of 64 addresses. 192.168.50.77 falls in the .64 through .127 block.',
    { type:'address-table', title:'IPv4 ADDRESS PLAN', rows:[['Host-A','192.168.50.77/26'],['Host-B','192.168.50.130/26'],['Gateway','192.168.50.65/26']] }
  ),
  E('1','1.13','EX-NF-02','MAC learning',[
    'Based on the frame flow shown, which MAC address will the switch learn on Gi0/3?',
    'A frame enters the switch on Gi0/3. Which address is added to the MAC table?',
    'The switch receives the Ethernet frame below. What source information does it learn?',
    'Which MAC-to-port mapping should appear after this frame arrives?',
    'Use the exhibit to determine the switch learning result.'
  ], ['AA:AA:AA:AA:AA:10 → Gi0/3','BB:BB:BB:BB:BB:20 → Gi0/1','CC:CC:CC:CC:CC:30 → Gi0/2','FF:FF:FF:FF:FF:FF → Gi0/3'], 0,
    'A Layer 2 switch learns from the source MAC of an incoming frame and associates it with the receiving interface and VLAN.',
    { type:'frame-flow', title:'INGRESS FRAME', nodes:[['HOST-A','AA:AA:AA:AA:AA:10'],['SW1','Gi0/3'],['SERVER','BB:BB:BB:BB:BB:20']], emphasis:'AA:AA:AA:AA:AA:10 → SW1 Gi0/3' }
  ),
  E('1','1.5','EX-NF-03','TCP / UDP',[
    'Which transport-layer behavior is represented by the sequence in the exhibit?',
    'The capture shows a connection being established before data exchange. Which protocol behavior fits?',
    'Based on the handshake shown, which transport protocol is being used?',
    'What transport service matches the packet exchange in the exhibit?',
    'Interpret the simplified transport exchange and select the correct protocol.'
  ], ['TCP','UDP','ARP','ICMP'], 0,
    'A TCP three-way handshake uses SYN, SYN-ACK, and ACK to establish a reliable connection.',
    { type:'packet-sequence', title:'SIMPLIFIED PACKET FLOW', rows:[['01','SYN','Client → Server'],['02','SYN-ACK','Server → Client'],['03','ACK','Client → Server'],['04','DATA','Client ↔ Server']] }
  ),
  E('2','2.2','EX-NA-01','802.1Q trunks',[
    'A host in VLAN 20 on SW1 must reach a host in VLAN 20 on SW2. What must be true of the inter-switch link?',
    'Which trunk condition allows VLAN 20 traffic to cross from SW1 to SW2?',
    'Use the configuration excerpt to identify the required Layer 2 behavior between the switches.',
    'What does the exhibit imply about the SW1–SW2 link?',
    'Which statement best explains why VLAN 20 traffic can or cannot traverse the link?'
  ], ['VLAN 20 is permitted on an 802.1Q trunk','The link must be a routed port','VLAN 20 must use an access port between the switches','STP must be disabled on VLAN 20'], 0,
    'A trunk must carry VLAN 20 for the same Layer 2 broadcast domain to span the switches.',
    { type:'topology-config', title:'SW1 / SW2 LINK', topology:['PC-A — SW1 Gi0/1','SW1 Gi0/24 ===== SW2 Gi0/24','PC-B — SW2 Gi0/1'], code:'SW1# show interfaces gi0/24 switchport\nMode: trunk\nTrunking VLANs: 10,20,30\n\nSW2# show interfaces gi0/24 switchport\nMode: trunk\nTrunking VLANs: 10,30' }
  ),
  E('2','2.5','EX-NA-02','STP root bridge',[
    'Which switch becomes the root bridge for the VLAN shown?',
    'Based on the bridge IDs, which device is selected as the STP root?',
    'An engineer reviews the following STP values. Which switch wins root-bridge election?',
    'Use the exhibit to determine the result of the STP election.',
    'Which bridge is preferred under the normal STP election process?'
  ], ['SW1 because it has the lowest bridge ID','SW2 because it has the highest MAC address','SW3 because it has the highest priority','All three equally share the root role'], 0,
    'The switch with the lowest bridge ID wins the root election. Bridge ID comparison starts with bridge priority and then uses the MAC address as a tiebreaker.',
    { type:'stp-table', title:'BRIDGE IDs', rows:[['SW1','Priority 24576','MAC 00:11:22:33:44:55'],['SW2','Priority 32768','MAC 00:11:22:33:44:10'],['SW3','Priority 28672','MAC 00:11:22:33:44:01']] }
  ),
  E('2','2.4','EX-NA-03','LACP EtherChannel',[
    'What is the most likely reason the EtherChannel is not forming?',
    'Which mismatch prevents these interfaces from successfully joining the bundle?',
    'Based on the two switch outputs, identify the configuration inconsistency.',
    'What should the engineer correct before expecting the channel to form?',
    'Interpret the port-channel evidence and select the best diagnosis.'
  ], ['The member interfaces use different trunk settings','The switches use different hostnames','The interfaces have different console speeds','NTP is not synchronized'], 0,
    'EtherChannel member links need compatible Layer 2 or Layer 3 parameters. A trunk/access mismatch is a common reason a bundle cannot form correctly.',
    { type:'topology-config', title:'ETHERCHANNEL CHECK', topology:['SW1 Gi0/1 ===== SW2 Gi0/1','SW1 Gi0/2 ===== SW2 Gi0/2'], code:'SW1# show interfaces trunk\nGi0/1  trunking\nGi0/2  trunking\n\nSW2# show interfaces trunk\nGi0/1  trunking\nGi0/2  access' }
  ),
  E('3','3.1','EX-IP-01','Routing table interpretation',[
    'Which route is selected for 10.20.30.40?',
    'A packet is destined for 10.20.30.40. Which routing-table entry wins?',
    'Interpret the routing table and determine the installed next-hop decision.',
    'Which route provides the forwarding decision for the destination shown?',
    'Apply normal route-selection rules to the exhibit.'
  ], ['10.20.0.0/16 via 10.0.0.2','10.20.30.0/24 via 10.0.0.3','10.0.0.0/8 via 10.0.0.1','0.0.0.0/0 via 192.0.2.1'], 1,
    'The /24 route is the longest matching prefix for 10.20.30.40, so it is preferred over /16, /8, and /0.',
    { type:'route-table', title:'R1 — SHOW IP ROUTE', code:'C    10.0.0.0/8 is directly connected, Gi0/0\nO    10.20.0.0/16 [110/20] via 10.0.0.2\nS    10.20.30.0/24 [1/0] via 10.0.0.3\nS*   0.0.0.0/0 [1/0] via 192.0.2.1', target:'10.20.30.40' }
  ),
  E('3','3.2','EX-IP-02','Administrative distance',[
    'The router has two routes to the same /24. Which source is preferred?',
    'Which route will be installed when both routes have an identical prefix?',
    'Use the administrative-distance values in the exhibit to select the preferred route.',
    'What does Cisco prefer for this destination when the competing prefixes are equal?',
    'Which candidate route wins the first comparison between different routing sources?'
  ], ['The route with AD 90','The route with AD 110','The route with the higher metric regardless of AD','Both routes equally'], 0,
    'When comparing routes to the same prefix from different sources, the lower administrative distance is preferred before comparing protocol-specific metrics.',
    { type:'route-table', title:'R2 — COMPETING ROUTES', code:'O    172.16.40.0/24 [110/30] via 10.0.0.2\nS    172.16.40.0/24 [90/0] via 10.0.0.6', target:'172.16.40.10' }
  ),
  E('3','3.4','EX-IP-03','OSPF neighbor states',[
    'Which adjacency is fully established according to the exhibit?',
    'Which OSPF neighbor has reached the FULL state?',
    'Identify the neighbor that has completed database synchronization.',
    'Based on the neighbor table, which relationship is fully adjacent?',
    'Which entry represents the completed OSPF adjacency?'
  ], ['Neighbor 2.2.2.2','Neighbor 3.3.3.3','Both neighbors','Neither neighbor'], 1,
    'A FULL OSPF neighbor relationship indicates that the databases are synchronized for that adjacency. A 2WAY relationship is not the same state.',
    { type:'route-table', title:'R1 — SHOW IP OSPF NEIGHBOR', code:'Neighbor ID     Pri   State\n2.2.2.2           1   2WAY\n3.3.3.3           1   FULL\n4.4.4.4           1   INIT' }
  ),
  E('3','3.4','EX-IP-04','OSPF router ID',[
    'Which router ID is selected from the information shown?',
    'Using normal OSPF router-ID selection rules, what value wins?',
    'Which address becomes the OSPF router ID in this configuration?',
    'Review the loopback and interface addresses. Which value is selected?',
    'What identity does the OSPF process use for this router?'
  ], ['10.1.1.1','192.0.2.10','10.255.255.1','The lowest interface IP'], 2,
    'When a router ID is not manually configured, OSPF prefers the highest IP address on a loopback interface over other interface addresses.',
    { type:'address-table', title:'R3 — INTERFACES', rows:[['Loopback0','10.1.1.1','up'],['Loopback1','10.255.255.1','up'],['Gi0/0','192.0.2.10','up']], note:'No manual router-id configured.' }
  ),
  E('4','4.1','EX-IS-01','NAT translation',[
    'Which translation is represented by the NAT table?',
    'A packet from the inside host reaches the edge. What source translation occurs?',
    'Interpret the NAT table and identify the inside local / inside global mapping.',
    'Which public-facing source address represents the internal host?',
    'What translation should the outside network observe?'
  ], ['10.10.10.20 becomes 203.0.113.20','203.0.113.20 becomes 10.10.10.20 only for inbound traffic','10.10.10.20 becomes 10.10.10.21','No translation occurs'], 0,
    'The NAT table maps the inside local address to the inside global address shown in the exhibit.',
    { type:'route-table', title:'EDGE — SHOW IP NAT TRANSLATIONS', code:'Pro  Inside global     Inside local       Outside local\ntcp  203.0.113.20:443   10.10.10.20:443   198.51.100.50:5151' }
  ),
  E('4','4.6','EX-IS-02','DHCP relay',[
    'Why does the router need a DHCP relay configuration in this topology?',
    'What problem is the `ip helper-address` solving?',
    'Interpret the topology and identify why DHCP requests need relay support.',
    'Why would the client broadcast fail without the helper configuration?',
    'Which statement best explains the relay requirement?'
  ], ['The DHCP server is on a different IP subnet','DHCP requires TCP instead of UDP','The switch cannot learn MAC addresses','The client has no Ethernet address'], 0,
    'DHCP clients initially send broadcasts. A Layer 3 router does not normally forward those broadcasts, so a relay such as `ip helper-address` forwards the request to a remote DHCP server.',
    { type:'topology', title:'DHCP PATH', nodes:[['CLIENT','VLAN 20'],['R1','Gi0/0 VLAN 20'],['R1','Gi0/1 10.0.0.1/30'],['DHCP-SRV','10.0.0.2/30']], code:'R1(config-if)# ip helper-address 10.0.0.2' }
  ),
  E('5','5.4','EX-SEC-01','ACL processing',[
    'Which statement explains the result of the ACL applied to Gi0/0?',
    'A packet from 10.10.10.50 arrives. What happens according to the shown ACL?',
    'Use the ACL entries and processing order to determine the outcome.',
    'Which traffic is denied by this access list?',
    'Interpret the ACL sequentially and select the correct behavior.'
  ], ['10.10.10.50 is denied by the first matching ACE','10.10.10.50 is permitted by the implicit deny','All traffic is permitted because one ACE matches','The ACL is evaluated from bottom to top'], 0,
    'Cisco ACLs are processed top-down. Once an ACE matches, processing stops. The first entry explicitly denies 10.10.10.50.',
    { type:'code', title:'R1 — ACL 110', code:'access-list 110 deny ip host 10.10.10.50 any\naccess-list 110 permit ip 10.10.10.0 0.0.0.255 any\n! implicit deny at the end\n\ninterface Gi0/0\n ip access-group 110 in', target:'Source: 10.10.10.50' }
  ),
  E('5','5.5','EX-SEC-02','DHCP snooping',[
    'Which interface should normally be trusted for DHCP server responses?',
    'What port treatment is appropriate for the interface connected to the legitimate DHCP server?',
    'Use the topology to determine where DHCP snooping trust belongs.',
    'Which switch port should be configured as a trusted DHCP-snooping interface?',
    'Which placement best matches the security boundary shown?'
  ], ['Gi0/24 toward the legitimate DHCP server','All user access ports','The console port only','Every port connected to an unknown host'], 0,
    'DHCP snooping normally trusts the interface that legitimately sources DHCP server messages and leaves untrusted user-facing ports blocked from sourcing server replies.',
    { type:'topology', title:'SW1 — DHCP SNOOPING', nodes:[['Gi0/1–Gi0/23','USER ACCESS'],['Gi0/24','UPLINK → DHCP SERVER']], code:'ip dhcp snooping\nip dhcp snooping vlan 20\ninterface Gi0/24\n ip dhcp snooping trust' }
  ),
  E('5','5.6','EX-SEC-03','Wireless security',[
    'Which WLAN security choice provides the strongest option among those shown for a modern enterprise deployment?',
    'Which security configuration should be selected from the available options?',
    'Based on the security choices in the exhibit, which provides the strongest protection?',
    'Which WLAN setting is the most appropriate from a security perspective?',
    'Select the strongest modern WLAN security option presented.'
  ], ['WPA3 with appropriate enterprise authentication','Open authentication','WEP','WPA with TKIP'], 0,
    'WPA3 provides modern Wi-Fi security. Older WEP and legacy WPA/TKIP options are not equivalent to current WPA3 protections.',
    { type:'wlan-table', title:'WLAN SECURITY OPTIONS', rows:[['CORP-WIFI','WPA3-Enterprise','802.1X'],['GUEST','Open','Captive portal'],['LEGACY','WEP','Shared key']] }
  ),
  E('6','6.2','EX-AUTO-01','Controller-based networking',[
    'Which architectural layer is most closely associated with policy and centralized management in the exhibit?',
    'What role is represented by the controller in this architecture?',
    'Identify the function of the centralized controller shown.',
    `Which statement best describes the controller's purpose?`,
    'Interpret the controller architecture and select the most accurate role.'
  ], ['Centralized policy and management','Replacing every physical switch port','Providing DHCP to every host without configuration','Converting all IPv4 packets into IPv6'], 0,
    'A controller-based design centralizes management and policy while network devices continue to handle forwarding and other data-plane functions as designed.',
    { type:'controller', title:'CONTROL / DATA PLANE', layers:[['CONTROLLER','Policy / intent / management'],['NETWORK DEVICES','Forwarding / execution'],['ENDPOINTS','Applications / users']], note:'Southbound interfaces connect controller services to network infrastructure.' }
  ),
  E('6','6.5','EX-AUTO-02','REST APIs',[
    'Which HTTP method is most appropriate when retrieving an existing resource through a REST API?',
    'An API client needs to read an existing object. Which method should it commonly use?',
    'Based on the API exchange, which operation is being performed?',
    'Which request method maps to a typical REST read operation?',
    'Interpret the HTTP request and choose the correct REST action.'
  ], ['GET','POST','DELETE','PATCH only'], 0,
    'GET is conventionally used to retrieve a resource. POST commonly creates, PATCH partially updates, and DELETE removes resources.',
    { type:'http', title:'API REQUEST', code:'GET /api/v1/interfaces/1\nAccept: application/json\n\nHTTP/1.1 200 OK\nContent-Type: application/json\n{ "name": "GigabitEthernet0/1", "status": "up" }' }
  ),
  E('6','6.7','EX-AUTO-03','JSON',[
    'Which value represents the interface state in this JSON object?',
    'What data does the `status` key contain?',
    'Read the JSON object and identify the value assigned to the interface state.',
    'Which JSON property reports whether the interface is up?',
    'Use the response body to determine the interface status value.'
  ], ['up','GigabitEthernet0/1','1','interfaces'], 0,
    'The `status` property contains the string value `up` in the JSON object.',
    { type:'json', title:'API RESPONSE', code:'{\n  "interface": {\n    "name": "GigabitEthernet0/1",\n    "status": "up",\n    "mtu": 1500\n  }\n}' }
  ),
  E('3','3.3','EX-IP-05','Static routing',[
    'Which static route would provide reachability to the destination network shown?',
    'Based on the topology, which Cisco IOS command is appropriate on R1?',
    'Which configuration matches the destination and next hop in the exhibit?',
    'What static route should the engineer enter on R1?',
    'Use the interface addressing to build the correct IPv4 static route.'
  ], ['ip route 10.20.0.0 255.255.255.0 192.0.2.2','ip route 192.0.2.2 255.255.255.0 10.20.0.0','ip route 10.20.0.0 255.255.0.0 192.0.2.1','ip route 10.20.0.0 255.255.255.0 10.20.0.1'], 0,
    'The destination is 10.20.0.0/24 and the directly connected neighbor providing the next hop is 192.0.2.2.',
    { type:'topology', title:'STATIC ROUTE PATH', nodes:[['LAN-A','10.10.10.0/24'],['R1','192.0.2.1/30'],['R2','192.0.2.2/30'],['LAN-B','10.20.0.0/24']] }
  ),
  E('2','2.3','EX-NA-04','Native VLAN',[
    'Which configuration detail should be checked first when the two switches report a native-VLAN mismatch?',
    'What is the most direct item to verify in the exhibit?',
    'The trunk reports a mismatch. Which setting should be compared on both ends?',
    'Which Layer 2 parameter is most relevant to this warning?',
    'Identify the likely source of the trunk warning.'
  ], ['The native VLAN configured on each trunk endpoint','The DNS resolver IP','The OSPF process ID','The NTP stratum'], 0,
    'A native-VLAN mismatch means the trunk endpoints are using different native VLAN assignments. The native VLAN should be checked and made consistent when the design requires it.',
    { type:'topology-config', title:'TRUNK WARNING', code:'SW1# show interfaces trunk\nGi0/24  native VLAN 99\n\nSW2# show interfaces trunk\nGi0/24  native VLAN 10\n\n%CDP-4-NATIVE_VLAN_MISMATCH: Native VLAN mismatch discovered on Gi0/24' }
  ),
  E('4','4.2','EX-IS-03','NTP',[
    'Which device is behaving as the NTP client?',
    'Which node receives time information from the configured NTP source?',
    'Interpret the NTP configuration and identify the client role.',
    'Which device is synchronizing its clock to the server?',
    'Use the exhibit to identify the NTP relationship.'
  ], ['R1','NTP-SRV','SW2','All devices equally'], 0,
    'R1 is configured with the NTP server address, making R1 the client that synchronizes to the server.',
    { type:'topology-config', title:'TIME SYNCHRONIZATION', code:'R1# show running-config | include ntp\nntp server 192.0.2.10\n\nNTP-SRV\n192.0.2.10' }
  ),
  E('5','5.3','EX-SEC-04','AAA',[
    'Which AAA function is being exercised when the server checks whether the user has permission to enter configuration mode?',
    'What AAA service corresponds to determining what an authenticated user is allowed to do?',
    'The device already knows who the user is. Which AAA component determines permitted actions?',
    'Which AAA function decides the user privilege level or allowed commands?',
    'Identify the AAA phase shown by the exhibit.'
  ], ['Authorization','Authentication','Accounting','Encryption'], 0,
    'Authentication determines identity, authorization determines permitted actions, and accounting records activity.',
    { type:'aaa-flow', title:'AAA FLOW', nodes:[['AUTHENTICATION','Who are you?'],['AUTHORIZATION','What may you do?'],['ACCOUNTING','What did you do?']] }
  ),
  E('1','1.11','EX-NF-04','Wireless channels',[
    'Which statement best explains why the 2.4 GHz network in the exhibit may experience more contention?',
    'What characteristic of 2.4 GHz is highlighted by the channel plan?',
    'Why is the 2.4 GHz band more likely to show co-channel or adjacent-channel interference here?',
    'Interpret the channel reuse pattern and select the most accurate statement.',
    'Which radio-frequency observation fits the exhibit?'
  ], ['There are fewer non-overlapping channels in common 2.4 GHz use','2.4 GHz always has more available channels than 5 GHz','2.4 GHz never experiences interference','Every 2.4 GHz channel is completely isolated'], 0,
    'Common 2.4 GHz deployments have fewer non-overlapping channels, making careful planning important in dense environments.',
    { type:'channel-plan', title:'2.4 GHZ CHANNEL PLAN', rows:[['AP-1','Channel 1','Office A'],['AP-2','Channel 6','Office B'],['AP-3','Channel 1','Office C'],['AP-4','Channel 11','Office D']] }
  ),
  E('6','6.6','EX-AUTO-04','Infrastructure as Code',[
    'Which tool category best matches a workflow that declares infrastructure state in configuration files and applies it consistently?',
    'Which approach is represented by the configuration excerpt?',
    'What automation model is shown in the exhibit?',
    'Which tooling concept best fits this declarative infrastructure workflow?',
    'Interpret the automation snippet and select the matching concept.'
  ], ['Infrastructure as Code','Manual CLI-only configuration','Packet capture','Layer 2 loop prevention'], 0,
    'A declarative configuration describing desired infrastructure and allowing a tool to create or reconcile that state is characteristic of Infrastructure as Code.',
    { type:'code', title:'DECLARATIVE CONFIGURATION', code:'resource "network" "branch01" {\n  name   = "branch01"\n  cidr   = "10.50.0.0/16"\n  region = "za-jhb"\n}' }
  ),
  E('3','3.1','EX-IP-06','Default route',[
    'Which route is used when no more-specific entry matches the destination?',
    'The packet matches no specific route. Which entry provides the fallback?',
    'Use the routing table to identify the default forwarding path.',
    'Which route acts as the least-specific catch-all?',
    'What destination prefix represents the default route here?'
  ], ['0.0.0.0/0 via 192.0.2.254','10.0.0.0/8 via 10.0.0.1','172.16.0.0/16 via 10.0.0.2','192.168.1.0/24 via 10.0.0.3'], 0,
    '0.0.0.0/0 is the IPv4 default route and matches any IPv4 destination that has no more-specific route.',
    { type:'route-table', title:'EDGE ROUTING TABLE', code:'C    10.0.0.0/24 is directly connected, Gi0/0\nO    172.16.0.0/16 [110/20] via 10.0.0.2\nS*   0.0.0.0/0 [1/0] via 192.0.2.254', target:'198.51.100.40' }
  ),
  E('5','5.7','EX-SEC-05','Port security',[
    'Which behavior is represented by the configured maximum of two secure MAC addresses?',
    'What does the port-security configuration limit?',
    'Based on the interface configuration, what condition is being enforced?',
    'Which statement best describes this switch-port policy?',
    'Interpret the port-security settings shown.'
  ], ['No more than two learned/secured MAC addresses can be associated with the port','Exactly two VLANs can cross the port','The port can only use two IP addresses','Two SSH sessions are allowed'], 0,
    'The maximum setting limits how many secure MAC addresses can be associated with the port.',
    { type:'code', title:'SW1 — PORT SECURITY', code:'interface Gi0/8\n switchport mode access\n switchport port-security\n switchport port-security maximum 2\n switchport port-security violation restrict' }
  ),
];

export const PF_EXHIBIT_QUESTIONS = PF_EXHIBITS.flatMap((family) => family.promptVariants.map((prompt, index) => ({
  ...family,
  questionId: `${family.id}-V${index+1}`,
  variant: index + 1,
  prompt,
})));
