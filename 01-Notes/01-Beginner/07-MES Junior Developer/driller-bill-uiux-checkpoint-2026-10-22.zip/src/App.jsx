import React, { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { safeStorage } from './storage.js';
import { PF_DOMAINS } from './data/question-bank.js';
import { STORAGE, MODE_META, DIFFICULTIES, EXHIBIT_QUESTIONS, ALL_STATIC_QUESTIONS, FAMILIES, conceptName, makeExam, objectiveStats, familyStats, readStorage, writeStorage, formatDuration, formatShortDuration, formatDate, getCorrect, computeResult, normalizeExhibit } from './core/exam-engine.js';
import './styles.css';
import './ux-foundation.css';
import NavigationSidebar from './NavigationSidebar.jsx';
import CommandPalette from './CommandPalette.jsx';

// Workspace routes are loaded on demand so the first screen does not have to
// download every lab, engineering view, and the complete Driller Bill studio.
const StatefulLab = lazy(() => import('./StatefulLab.jsx'));
const ProtocolLab = lazy(() => import('./ProtocolLab.jsx'));
const FlowLab = lazy(() => import('./FlowLab.jsx'));
const PacketLab = lazy(() => import('./PacketLab.jsx'));
const PacketWorkshop = lazy(() => import('./PacketWorkshop.jsx'));
const AdvancedPBQLab = lazy(() => import('./AdvancedPBQLab.jsx'));
const TopologyBuilder = lazy(() => import('./topology/TopologyBuilder.jsx'));
const MasteryReview = lazy(() => import('./MasteryReview.jsx'));
const QuestionAuthoringStudio = lazy(() => import('./QuestionAuthoringStudio.jsx'));
const DataSafety = lazy(() => import('./DataSafety.jsx'));
const CloudSync = lazy(() => import('./cloud/CloudSync.jsx'));
const KnowledgeBase = lazy(() => import('./knowledge/KnowledgeBase.jsx'));
const Devices = lazy(() => import('./Devices.jsx'));
const Runbooks = lazy(() => import('./Runbooks.jsx'));
const Troubleshooting = lazy(() => import('./Troubleshooting.jsx'));
const TwinIntelligence = lazy(() => import('./TwinIntelligence.jsx'));
const UnifiedWorkflows = lazy(() => import('./UnifiedWorkflows.jsx'));
const ChangeSets = lazy(() => import('./ChangeSets.jsx'));
const NetworkDiscovery = lazy(() => import('./NetworkDiscovery.jsx'));
const DrillerBillStudio = lazy(() => import('./driller-bill/DrillerBillStudio.jsx'));
import { MASTERY_STORAGE, syncMasteryWithHistory, emptyCard, scheduleCard, masteryStats } from './core/mastery-engine.js';
import { createHealthyLiveLab, LIVE_LAB_STORAGE, prepareLiveLabState, resetLiveNetwork } from './core/live-network-engine.js';
import { loadTopology, demoTopology, saveTopology } from './core/topology-engine.js';
import { NetworkWorkspaceProvider } from './context/NetworkWorkspaceContext.jsx';
import { syncTopologyToLabState, projectLabStateOntoTopology } from './core/network-topology-sync.js';

const LETTERS=['A','B','C','D'];
const C={orange:'#59D9FF'};
const LIVE_LAB_KEY = LIVE_LAB_STORAGE;
const PF_TRACE = typeof import.meta !== 'undefined' && import.meta.env?.DEV;
function pfTrace(label, data) {
  if (!PF_TRACE) return;
  if (data === undefined) console.log(`[Driller Bill][data-flow] ${label}`);
  else console.log(`[Driller Bill][data-flow] ${label}`, data);
}

function Icon({name,size=17}){const p={
  play:<path d="M8 5l11 7-11 7V5z" fill="currentColor"/>, clock:<><circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3.5 2"/></>,terminal:<><path d="M4 5h16v14H4z"/><path d="m7 9 3 3-3 3M12 15h5"/></>,sun:<><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></>,moon:<path d="M20.5 14.9A8.5 8.5 0 0 1 9.1 3.5 8.8 8.8 0 1 0 20.5 14.9Z"/>,target:<><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.2"/><circle cx="12" cy="12" r="1" fill="currentColor"/></>,arrow:<><path d="M5 12h13"/><path d="m13 6 6 6-6 6"/></>,check:<path d="m5 12 4 4L19 6"/>,x:<><path d="m6 6 12 12"/><path d="m18 6-12 12"/></>,flag:<><path d="M6 20V4"/><path d="M6 5h10l-2 3 2 3H6"/></>,chart:<><path d="M5 19V10"/><path d="M12 19V5"/><path d="M19 19v-7"/><path d="M3 19h18"/></>,book:<><path d="M5 5.5A2.5 2.5 0 0 1 7.5 3H19v17H7.5A2.5 2.5 0 0 0 5 22z"/><path d="M5 5.5v16"/></>,brain:<><path d="M9.5 4a3.5 3.5 0 0 0-3.2 4.9A3.5 3.5 0 0 0 5 15.5 3.5 3.5 0 0 0 9.5 19H10V4z"/><path d="M14.5 4a3.5 3.5 0 0 1 3.2 4.9A3.5 3.5 0 0 1 19 15.5a3.5 3.5 0 0 1-4.5 3.5H14V4z"/><path d="M10 8h4M10 12h4M10 16h4"/></>,settings:<><circle cx="12" cy="12" r="3"/><path d="M19 14.6a7.4 7.4 0 0 0 0-5.2l2-1.4-2-3.4-2.4 1a7 7 0 0 0-4.5-2.6L11.8 0H8.2L8 3a7 7 0 0 0-4.3 2.5L1.4 4.5l-2 3.4 2 1.4a7.4 7.4 0 0 0 0 5.2l-2 1.4 2 3.4 2.4-1A7 7 0 0 0 8 21l.2 3h3.6l.2-3a7 7 0 0 0 4.5-2.6l2.4 1 2-3.4z" transform="translate(1 -1) scale(.9)"/></>,search:<><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.4 4.4"/></>,network:<><circle cx="12" cy="5" r="2.5"/><circle cx="5" cy="19" r="2.5"/><circle cx="19" cy="19" r="2.5"/><path d="m10.5 7-4 9.5M13.5 7l4 9.5M7.5 19h9"/></>,router:<><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 9h.1M10 9h.1M13 9h.1M6 14h12M8 17h.1M16 17h.1"/></>,wrench:<><path d="M14.7 6.3a5 5 0 0 0-6.9 6.9L3 18l3 3 4.8-4.8a5 5 0 0 0 6.9-6.9l-3 3-3-3z"/></>
};return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{p[name]}</svg>}
const inline=(text='')=>String(text).split(/(`[^`]+`)/g).map((x,i)=>x.startsWith('`')&&x.endsWith('`')?<code key={i}>{x.slice(1,-1)}</code>:<React.Fragment key={i}>{x}</React.Fragment>);

function Brand(){return <div className="brand-lockup"><div className="pf-logo"><span/></div><div><div className="brand-name">Driller Bill</div><div className="brand-sub">NETWORK ENGINEERING WORKSPACE</div></div></div>}
function ThemeToggle({theme,onToggle}){const dark=theme==='dark';return <button type="button" className="theme-toggle" onClick={onToggle} aria-label={dark?'Switch to light mode':'Switch to dark mode'} aria-pressed={dark} title={dark?'Switch to light mode':'Switch to dark mode'}><span className="theme-toggle-icon"><Icon name={dark?'sun':'moon'} size={17}/></span><span className="theme-toggle-label">{dark?'Light':'Dark'}</span></button>}
function Header({view,setView,compact=false,theme,onToggleTheme,onOpenSearch=()=>{}}){const labels={dashboard:'CONSOLE',analytics:'ANALYTICS',mistakes:'MISTAKE BANK',review:'REVIEW QUEUE',knowledge:'KNOWLEDGE BASE',devices:'DEVICES',config:'CONFIGURATION',runbooks:'RUNBOOKS',changeSets:'CHANGE SETS',troubleshooting:'TROUBLESHOOTING',twin:'TWIN INTELLIGENCE',discovery:'NETWORK DISCOVERY',workflows:'WORKFLOWS',lab:'CLI LAB',topology:'TOPOLOGY',protocol:'PROTOCOL LAB',flow:'FLOW LAB',packet:'PACKET LAB',advanced:'ADVANCED PBQs'};return <header className="topbar"><button className="brand-button" onClick={()=>setView('dashboard')} aria-label="Driller Bill dashboard"><Brand/></button><div className="topbar-context"><span>DRILLER BILL</span><b>{labels[view]||'WORKSPACE'}</b></div><button type="button" className="header-search" onClick={onOpenSearch} aria-label="Find a workspace" aria-haspopup="dialog"><Icon name="search" size={17}/><span>Find a workspace…</span><kbd>Ctrl / ⌘ K</kbd></button><div className="header-actions"><div className="header-status" role="status" aria-live="polite"><i/>LOCAL-FIRST</div>{!compact&&onToggleTheme&&<ThemeToggle theme={theme} onToggle={onToggleTheme}/>}</div></header>}

function Blueprint({history,onStart}){const agg=PF_DOMAINS.map(d=>{const vals=history.flatMap(a=>a.domains?.[d.id]?[a.domains[d.id].pct]:[]);return {...d,pct:vals.length?Math.round(vals.reduce((s,v)=>s+v,0)/vals.length):null};});return <section className="panel blueprint"><div className="panel-head"><div><div className="kicker">01 / EXAM BLUEPRINT</div><h2>Know the terrain.</h2></div><span className="panel-micro">20 / 20 / 25 / 10 / 15 / 10</span></div><div className="blueprint-grid">{agg.map(d=><button key={d.id} className="blueprint-row" onClick={()=>onStart('domain',d.id)}><div className="blueprint-id">0{d.id}</div><div className="blueprint-copy"><strong>{d.name}</strong><span>{d.weight}% blueprint</span></div><div className="blueprint-meter"><i style={{width:`${d.pct??0}%`}}/></div><div className="blueprint-pct">{d.pct===null?'—':`${d.pct}%`}</div><Icon name="arrow" size={14}/></button>)}</div></section>}

function Stat({label,value,note=''}){return <div className="stat"><span>{label}</span><strong>{value}</strong>{note&&<small>{note}</small>}</div>}

function Dashboard({history,savedSession,objective,wrongCount,mode,setMode,domain,setDomain,adaptive,setAdaptive,coldStart,setColdStart,difficulty,setDifficulty,startAssessment,resume,startStudy,startRemediation,resetData,setView,masteryDue}){
  const dashboardTraceEnabled = typeof import.meta !== 'undefined' && import.meta.env?.DEV;
  useEffect(() => {
    if (!dashboardTraceEnabled) return;
    console.log('[Driller Bill][data-flow][Dashboard] props received from App', {
      historyCount: history.length, savedSession: Boolean(savedSession), objectiveCount: Object.keys(objective).length, wrongCount,
      mode, domain, adaptive, coldStart, difficulty, masteryDue,
      callbacks: { startAssessment: typeof startAssessment === 'function', resume: typeof resume === 'function', setView: typeof setView === 'function' }
    });
  }, [dashboardTraceEnabled, history.length, Boolean(savedSession), Object.keys(objective).length, wrongCount, mode, domain, adaptive, coldStart, difficulty, masteryDue]);
  const familyCount=FAMILIES.length; const variantCount=ALL_STATIC_QUESTIONS.length; const objectiveCount=new Set(FAMILIES.map(q=>q.topic)).size;
  const avg=history.length?Math.round(history.reduce((s,a)=>s+a.pct,0)/history.length):0; const coverage=Object.keys(objective).length?Math.round(Object.keys(objective).length/53*100):0; const streak=Math.min(30,history.length);
  const weak=Object.values(objective).filter(x=>x.total).sort((a,b)=>a.pct-b.pct)[0];
  const focusTitle = masteryDue > 0 ? `${masteryDue} review${masteryDue === 1 ? '' : 's'} due` : weak ? `Reinforce ${weak.concept}` : history.length ? 'Keep your momentum' : 'Explore the engineering workspace';
  const focusCopy = masteryDue > 0 ? 'A short review session is waiting. Clear the queue before adding more material.' : weak ? `${weak.objective} is currently your weakest tracked objective. Target it before another full form.` : history.length ? 'Your next best move is a focused practice session, then a full simulation when you are ready.' : 'Start with discovery to explore the workspace, inspect simulated devices, and move into hands-on labs when you are ready.';
  const focusAction = masteryDue > 0 ? () => setView('review') : weak ? startRemediation : history.length ? () => startAssessment('full') : () => setView('discovery');
  const focusLabel = masteryDue > 0 ? 'Open review queue' : weak ? 'Start remediation' : history.length ? 'Start full simulation' : 'Open discovery';
  return <main className="page dashboard"><section className="hero"><div className="hero-copy"><div className="eyebrow">NETWORK ENGINEERING / LOCAL-FIRST</div><h1>Understand the network.<br/><span>Change it with confidence.</span></h1><p>Inspect devices, explore topology, troubleshoot with evidence, and build CCNA skills in one connected engineering workspace.</p><div className="hero-actions"><button className="button primary large" onClick={()=>{dashboardTraceEnabled&&console.log('[Driller Bill][data-flow][Dashboard] child action -> setView', {to:'devices'});setView('devices')}}><Icon name="router" size={17}/> Inspect devices</button><button className="button large" onClick={()=>{dashboardTraceEnabled&&console.log('[Driller Bill][data-flow][Dashboard] child action -> setView', {to:'discovery'});setView('discovery')}}><Icon name="network" size={17}/> Network discovery</button><button className="button large" onClick={()=>{dashboardTraceEnabled&&console.log('[Driller Bill][data-flow][Dashboard] child action -> setView', {to:'lab'});setView('lab')}}><Icon name="terminal" size={17}/> CLI lab</button>{savedSession&&<button className="button large saved" onClick={resume}>Resume saved form <span>→</span></button>}</div></div><div className="hero-stats" aria-label="Learning progress"><Stat label="Average score" value={avg?`${avg}%`:'—'} note="all completed forms"/><Stat label="Objective coverage" value={coverage?`${coverage}%`:'—'} note="of 53 tracked objectives"/><Stat label="Mistakes to revisit" value={wrongCount} note="families in rotation"/><Stat label="Assessments" value={history.length} note="completed locally"/></div></section>
    <section className="daily-focus panel"><div className="daily-focus-mark"><Icon name={masteryDue > 0 ? 'clock' : weak ? 'target' : history.length ? 'play' : 'network'} size={20}/></div><div className="daily-focus-copy"><div className="kicker">NEXT BEST ACTION</div><h2>{focusTitle}</h2><p>{focusCopy}</p></div><div className="daily-focus-meta"><span>{history.length ? `${history.length} completed form${history.length === 1 ? '' : 's'}` : 'Ready to explore'}</span><button className="button primary" onClick={focusAction}>{focusLabel}<Icon name="arrow" size={14}/></button></div></section>
    <section className="workspace-launchpad" aria-labelledby="workspace-launchpad-title"><div className="workspace-launchpad-head"><div><div className="kicker">YOUR WORKSPACE</div><h2 id="workspace-launchpad-title">What do you need to do?</h2><p>Jump straight into an engineering task or learning tool.</p></div><span className="workspace-launchpad-count">6 WORKSPACES</span></div><div className="workspace-launch-grid">{[{id:'devices',icon:'router',title:'Inspect devices',copy:'Connect to devices and review their current state.'},{id:'discovery',icon:'network',title:'Discover the network',copy:'Review neighbors, topology, and drift evidence.'},{id:'config',icon:'settings',title:'Configure safely',copy:'Plan changes, review risk, then verify results.'},{id:'troubleshooting',icon:'wrench',title:'Troubleshoot a fault',copy:'Gather evidence and test likely causes.'},{id:'knowledge',icon:'book',title:'Find a concept',copy:'Look up commands, explanations, and related labs.'},{id:'lab',icon:'terminal',title:'Open the CLI lab',copy:'Experiment with IOS-style commands in a sandbox.'}].map(item=><button type="button" className="workspace-launch-card" key={item.id} onClick={()=>setView(item.id)}><span className="workspace-launch-icon"><Icon name={item.icon} size={22}/></span><span className="workspace-launch-copy"><strong>{item.title}</strong><span>{item.copy}</span></span><span className="workspace-launch-arrow" aria-hidden="true"><Icon name="arrow" size={18}/></span></button>)}</div></section>
    <div className="console-grid"><section className="panel launch-panel"><div className="panel-head"><div><div className="kicker">02 / FORM GENERATOR</div><h2>Build your paper.</h2></div><span className="panel-micro">LIVE CONFIG</span></div><div className="launch-grid"><label>MODE<select value={mode} onChange={e=>setMode(e.target.value)}>{Object.entries(MODE_META).map(([id,m])=><option key={id} value={id}>{m.label}</option>)}</select></label>{mode==='domain'&&<label>DOMAIN<select value={domain} onChange={e=>setDomain(e.target.value)}>{PF_DOMAINS.map(d=><option key={d.id} value={d.id}>0{d.id} · {d.name}</option>)}</select></label>}<label>DIFFICULTY<select value={difficulty} onChange={e=>setDifficulty(e.target.value)}>{DIFFICULTIES.map(d=><option key={d} value={d}>{d==='mixed'?'Mixed':d[0].toUpperCase()+d.slice(1)}</option>)}</select></label><div className="toggle-stack"><button type="button" className={`toggle ${adaptive?'on':''}`} aria-pressed={adaptive} onClick={()=>setAdaptive(v=>!v)}><span aria-hidden="true"/>ADAPTIVE FORM</button><button type="button" className={`toggle ${coldStart?'on':''}`} aria-pressed={coldStart} onClick={()=>setColdStart(v=>!v)}><span aria-hidden="true"/>COLD START</button></div></div><div className="launch-footer"><div><strong>{MODE_META[mode]?.questions}</strong><span>questions</span><strong>{MODE_META[mode]?.minutes}m</strong><span>timebox</span></div><button className="button primary" onClick={()=>startAssessment(mode)}>Generate form <Icon name="arrow" size={14}/></button></div></section><section className="panel focus-panel"><div className="panel-head"><div><div className="kicker">03 / NEXT SIGNAL</div><h2>{weak?weak.concept:'Start your baseline.'}</h2></div><div className="signal-value">{weak?`${weak.pct}%`:'—'}</div></div><p>{weak?`Your lowest tracked objective. Driller Bill will bias adaptive practice toward ${weak.objective}.`:'Complete a form to activate concept-level weakness analysis.'}</p><button className="text-button" onClick={()=>{dashboardTraceEnabled&&console.log('[Driller Bill][data-flow][Dashboard] child action -> setView', {to:'analytics'});setView('analytics')}}>Open analytics <Icon name="arrow" size={13}/></button></section></div>
    <Blueprint history={history} onStart={(m,d)=>startAssessment(m,d)}/>
    <div className="feature-grid"><section className="panel feature"><div className="feature-icon"><Icon name="brain" size={20}/></div><div><div className="kicker">ADAPTIVE ENGINE</div><h3>Make every repeat count.</h3><p>Unseen variants, weak objectives and missed families influence future forms without turning the exam into a fixed script.</p></div></section><section className="panel feature"><div className="feature-icon"><Icon name="book" size={20}/></div><div><div className="kicker">STUDY MODE</div><h3>Learn from the same bank.</h3><p>Immediate rationale, concept tags and one-question-at-a-time review when you are not pretending to be in a live exam.</p><button className="text-button" onClick={()=>startStudy('exhibits')}>Open exhibit study <Icon name="arrow" size={13}/></button></div></section><section className="panel feature"><div className="feature-icon"><Icon name="target" size={20}/></div><div><div className="kicker">MISTAKE LOOP</div><h3>Miss it. Target it.</h3><p>Turn missed families into a remediation form focused on the exact objectives that are not sticking.</p><button className="text-button" onClick={()=>setView('mistakes')}>Open mistake bank <Icon name="arrow" size={13}/></button></div></section></div>
    <section className="panel mastery-callout"><div className="mastery-callout-copy"><div className="kicker">04 / SPACED REPETITION</div><h2>{masteryDue?`${masteryDue} concepts are due.`:'Build your review queue.'}</h2><p>Remembered concepts move farther away. Missed concepts come back sooner, giving your daily practice a memory-driven rhythm.</p></div><div className="mastery-callout-stat"><strong>{masteryDue}</strong><span>due now</span><button className="button primary" onClick={()=>setView('review')} disabled={!masteryDue}>Open review queue <Icon name="arrow" size={14}/></button></div></section>
    <section className="panel history-panel"><div className="panel-head"><div><div className="kicker">04 / ATTEMPT LOG</div><h2>Latest forms</h2></div><span className="panel-micro">LOCAL STORAGE</span></div>{history.length?<div className="history-list">{history.slice(0,8).map((a,i)=><div className="history-row" key={a.id}><div className="history-index">{String(i+1).padStart(2,'0')}</div><div className="history-main"><strong>{MODE_META[a.mode]?.label||a.mode}</strong><span>{formatDate(a.date)} · {a.total} questions · {formatShortDuration(a.timeUsed)}</span></div><div className="history-domain">{Object.values(a.domains||{}).slice(0,3).map(d=><span key={d.name}>{d.name.split(' ')[0]} {d.pct}%</span>)}</div><div className="history-score"><strong>{a.pct}%</strong><span>{a.correct}/{a.total}</span></div></div>)}</div>:<div className="empty-state"><strong>No completed forms.</strong><span>Your first assessment will populate domain, objective and mistake analytics.</span></div>}</section>
    <footer className="footer"><span>DRILLER BILL / NETWORK ENGINEERING</span><span>Cyan console · local-first</span><button className="text-button" onClick={resetData}>Reset data</button></footer>
  </main>
}

function Analytics({history,objective,startRemediation}){const avg=history.length?Math.round(history.reduce((s,a)=>s+a.pct,0)/history.length):0;const weak=Object.values(objective).filter(x=>x.total).sort((a,b)=>a.pct-b.pct).slice(0,10);const domains=PF_DOMAINS.map(d=>{const vals=history.flatMap(a=>a.domains?.[d.id]?[a.domains[d.id].pct]:[]);return {...d,pct:vals.length?Math.round(vals.reduce((s,v)=>s+v,0)/vals.length):null};});return <main className="page"><section className="page-title"><div><div className="eyebrow">ANALYTICS / LEARNER TELEMETRY</div><h1>See the pattern.<br/><span>Attack the gap.</span></h1><p>Performance is grouped by blueprint domain and objective. This is a training diagnostic, not a Cisco pass/fail prediction.</p></div><div className="headline-stat"><strong>{avg||'—'}</strong><span>overall average %</span></div></section><div className="analytics-grid"><section className="panel"><div className="panel-head"><div><div className="kicker">01 / BLUEPRINT</div><h2>Domain performance</h2></div></div><div className="domain-list">{domains.map(d=><div className="domain-row" key={d.id}><div className="domain-name"><b>0{d.id}</b><span>{d.name}</span><small>{d.weight}% blueprint</small></div><div className="bar"><i style={{width:`${d.pct??0}%`}}/></div><strong>{d.pct===null?'—':`${d.pct}%`}</strong></div>)}</div></section><section className="panel"><div className="panel-head"><div><div className="kicker">02 / OBJECTIVES</div><h2>Weakest tracked signals</h2></div><button className="button" onClick={startRemediation}>Remediate</button></div>{weak.length?<div className="objective-table">{weak.map(x=><div key={x.objective} className="objective-row"><div><b>{x.objective}</b><span>{x.concept}</span></div><strong className={x.pct<60?'critical':''}>{x.pct}%</strong></div>)}</div>:<div className="empty-state"><strong>Nothing to diagnose yet.</strong><span>Complete a form first.</span></div>}</section></div><section className="panel trend-panel"><div className="panel-head"><div><div className="kicker">03 / TREND</div><h2>Recent scores</h2></div></div>{history.length?<div className="trend">{history.slice(0,12).reverse().map((a,i)=><div className="trend-item" key={a.id}><span>{a.pct}%</span><i style={{height:`${Math.max(8,a.pct)}%`}}/><small>{i+1}</small></div>)}</div>:<div className="empty-state"><strong>No trend yet.</strong></div>}</section></main>}

function Mistakes({wrongQuestions,objective,startRemediation,startAssessment}){const sorted=[...wrongQuestions].sort((a,b)=>(objective[a.topic]?.pct??100)-(objective[b.topic]?.pct??100));return <main className="page"><section className="page-title compact"><div><div className="eyebrow">MISTAKE BANK / REMEDIATION</div><h1>Wrong answers become<br/><span>future questions.</span></h1><p>Every missed family is a signal. Driller Bill uses the signal to target objectives and rotate variants.</p></div><button className="button primary large" onClick={startRemediation} disabled={!wrongQuestions.length}><Icon name="target" size={15}/> Generate remediation</button></section><section className="panel"><div className="panel-head"><div><div className="kicker">01 / FAMILY ROTATION</div><h2>{wrongQuestions.length} families</h2></div></div>{sorted.length?<div className="mistake-grid">{sorted.map(q=><article className="mistake-card" key={q.id}><div className="mistake-top"><span>{q.topic}</span><span>{objective[q.topic]?.pct??'—'}%</span></div><h3>{q.concept}</h3><p>{inline(q.q||q.prompt)}</p><div className="mistake-foot"><span>{q.difficulty}</span><button className="text-button" onClick={()=>startAssessment('domain',q.domain,{objectiveFilter:[q.topic],adaptive:true})}>Drill <Icon name="arrow" size={12}/></button></div></article>)}</div>:<div className="empty-state"><Icon name="check" size={22}/><strong>Mistake bank is empty.</strong><span>Complete an assessment and incorrect families will appear here.</span></div>}</section></main>}

function ExhibitBody({exhibit}){
  const e=normalizeExhibit(exhibit)||{};
  const {type}=e;
  if(type==='code'||type==='route-table'||type==='topology-config'||type==='http'||type==='json') return <pre>{e.code ?? ''}</pre>;
  if(type==='address-table'||type==='stp-table'||type==='wlan-table'||type==='channel-plan'||type==='packet-sequence'||type==='mac-table'||type==='interface-table') return <div className="exhibit-table">{(e.rows||[]).map((r,i)=><div className="e-row" key={i}>{r.map((c,j)=><span key={j} className={j===0?'e-key':''}>{c}</span>)}</div>)}</div>;
  if(type==='topology'||type==='frame-flow') return <div className="node-flow">{(e.nodes||[]).map((n,i)=><React.Fragment key={i}><div className="node"><b>{n[0]}</b><span>{n[1]}</span></div>{i<(e.nodes||[]).length-1&&<i className="flow-line"/>}</React.Fragment>)}</div>;
  if(type==='controller') return <div className="stack-diagram">{(e.layers||[]).map((l,i)=><React.Fragment key={i}><div className="stack-box"><b>{l[0]}</b><span>{l[1]}</span></div>{i<(e.layers||[]).length-1&&<i className="stack-arrow">↓</i>}</React.Fragment>)}</div>;
  if(type==='aaa-flow') return <div className="aaa-flow">{(e.nodes||[]).map(n=><div key={n[0]}><b>{n[0]}</b><span>{n[1]}</span></div>)}</div>;
  if(type==='workbench') return null;
  return <pre>{e.code||''}</pre>;
}

function ExhibitWorkbench({exhibit}){
  const normalized=normalizeExhibit(exhibit)||{};
  const tabs=Array.isArray(normalized.tabs)?normalized.tabs:[];
  const [active,setActive]=useState(0);
  useEffect(()=>setActive(0),[exhibit?.title,tabs.map(t=>t.label||'').join('|')]);
  const current=tabs[active]?.exhibit||tabs[active]||normalized;
  if(!tabs.length) return <section className={`exhibit exhibit-${normalized.type||'code'}`}><div className="exhibit-head"><span>EXHIBIT</span><strong>{normalized.title}</strong></div><ExhibitBody exhibit={normalized}/></section>;
  return <section className="exhibit exhibit-workbench" aria-label={normalized.title||'Exhibit evidence'}>
    <div className="exhibit-head"><span>EXHIBIT WORKBENCH</span><strong>{normalized.title||'CASE EVIDENCE'}</strong></div>
    <div className="exhibit-tabs" role="tablist" aria-label="Evidence views">
      {tabs.map((tab,i)=><button key={tab.label||i} className={active===i?'active':''} role="tab" aria-selected={active===i} tabIndex={active===i?0:-1} onClick={()=>setActive(i)} onKeyDown={e=>{if(e.key==='ArrowRight' || e.key==='ArrowDown'){e.preventDefault();setActive((i+1)%tabs.length)}if(e.key==='ArrowLeft' || e.key==='ArrowUp'){e.preventDefault();setActive((i-1+tabs.length)%tabs.length)}}}>{tab.label||`Evidence ${i+1}`}</button>)}
      {(current?.type==='code'||current?.code) && <button className="exhibit-copy" onClick={()=>navigator.clipboard?.writeText(normalizeExhibit(current)?.code||'').catch(()=>{})}>Copy</button>}
    </div>
    <div className="exhibit-tab-title"><span>VIEW {String(active+1).padStart(2,'0')}</span><strong>{current?.title||tabs[active]?.label||'Evidence'}</strong></div>
    <ExhibitBody exhibit={current}/>
  </section>;
}

function Exam({questions,index,setIndex,answers,setAnswers,review,setReview,timeLeft,mode,domain,onSubmit,onQuit,theme,onToggleTheme}){const q=questions[index];const selected=answers[q.questionId]||[];const answered=questions.filter(x=>(answers[x.questionId]||[]).length>0).length;const progress=((index+1)/questions.length)*100;const danger=timeLeft<=5*60*1000;return <div className="exam-shell"><header className="exam-topbar"><button className="exam-brand" onClick={onQuit}><Brand/></button><div className="exam-center"><span className="live-dot"/>ASSESSMENT ACTIVE <em>/</em> CLOSED BOOK</div><div className="exam-actions"><ThemeToggle theme={theme} onToggle={onToggleTheme}/><div className={`timer ${danger?'danger':''}`} role="timer" aria-live="polite" aria-label={`Time remaining ${formatDuration(timeLeft)}`}><Icon name="clock" size={16}/>{formatDuration(timeLeft)}</div><button className="button danger" onClick={onQuit}><Icon name="x" size={14}/> Exit</button></div></header><main className="exam-page"><div className="exam-meta"><div><span>QUESTION {String(index+1).padStart(3,'0')}</span><strong>{q.topic} / {q.concept}</strong></div><div className="exam-progress"><div><i style={{width:`${progress}%`}}/></div><span>{index+1}/{questions.length}</span></div><b className="mode-badge">{MODE_META[mode]?.label}</b></div><div className="exam-grid"><section className="question-card"><div className="question-tools"><div className="tags"><span className="tag pink">{q.presentation==='scenario'?'SCENARIO':q.presentation==='exhibit'?'EXHIBIT':'THEORY'}</span><span className="tag">{q.difficulty}</span>{q.type==='multi'&&<span className="tag">MULTIPLE RESPONSE</span>}</div><button className={`review-btn ${review.has(q.questionId)?'active':''}`} onClick={()=>setReview(s=>{const n=new Set(s);n.has(q.questionId)?n.delete(q.questionId):n.add(q.questionId);return n;})}><Icon name="flag" size={14}/> {review.has(q.questionId)?'Marked':'Mark for review'}</button></div><div className="question-id">PF / {q.id}</div>{q.scenarioTitle&&<div className="scenario-banner"><div><span>STEP {String(q.scenarioStep).padStart(2,'0')} / {String(q.scenarioTotal||q.scenarioStep).padStart(2,'0')}</span><strong>{q.scenarioTitle}</strong></div><p>{inline(q.scenarioBrief)}</p></div>}{q.context&&<div className="question-context">{inline(q.context)}</div>}{q.exhibit&&<ExhibitWorkbench exhibit={q.exhibit}/>}<h1>{inline(q.prompt)}</h1>{q.type==='multi'&&<div className="response-note"><b>SELECT ALL THAT APPLY</b> Choose every option you judge correct.</div>}<div className="answers">{q.options.map((o,i)=>{const active=selected.includes(i);return <button key={i} className={`answer ${active?'active':''}`} onClick={()=>setAnswers(a=>{const now=a[q.questionId]||[];const n=q.type==='single'?[i]:(now.includes(i)?now.filter(x=>x!==i):[...now,i].sort((x,y)=>x-y));return {...a,[q.questionId]:n};})}><span>{LETTERS[i]}</span><p>{inline(o)}</p><i>{active?<Icon name="check" size={15}/>:null}</i></button>})}</div><div className="question-footer"><button className="button" disabled={index===0} onClick={()=>setIndex(index-1)}>← Previous</button><span className="keyhelp">1–4 select · N next · P previous · M mark</span><button className="button primary" onClick={()=>index===questions.length-1?onSubmit():setIndex(index+1)}>{index===questions.length-1?'Submit assessment':'Next question'} <Icon name="arrow" size={14}/></button></div></section><aside className="exam-side"><section className="side-box"><div className="side-title"><div><span>QUESTION MAP</span><strong>{answered}/{questions.length} answered</strong></div></div><div className="nav-grid">{questions.map((x,i)=><button key={x.questionId} className={`${i===index?'current ':''}${(answers[x.questionId]||[]).length?'answered ':''}${review.has(x.questionId)?'review':''}`} onClick={()=>setIndex(i)}>{i+1}</button>)}</div><div className="legend"><span><i className="l current"/>current</span><span><i className="l answered"/>answered</span><span><i className="l review"/>review</span></div></section><section className="side-box session-box"><div className="side-title"><div><span>SESSION</span><strong>Live status</strong></div><Icon name="target" size={15}/></div><div className="session-stats"><Stat label="Answered" value={answered}/><Stat label="Blank" value={questions.length-answered}/><Stat label="Marked" value={review.size}/><Stat label="Time" value={formatDuration(timeLeft)}/></div></section><section className="side-box rules"><div className="side-title"><div><span>RULES</span><strong>Exam discipline</strong></div></div><p>No correctness feedback until submission. Exhibits may be revisited from the question itself.</p></section></aside></div></main></div>}

function Study({questions,index,setIndex,answers,setAnswers,onFinish,theme,onToggleTheme}){const q=questions[index],selected=answers[q.questionId]||[],done=selected.length>0,ok=getCorrect(q,selected);return <div className="study-shell"><header className="exam-topbar"><button className="exam-brand" onClick={onFinish}><Brand/></button><div className="exam-center">STUDY MODE <em>/</em> IMMEDIATE FEEDBACK</div><div className="exam-actions"><ThemeToggle theme={theme} onToggle={onToggleTheme}/><span className="study-count">{index+1}/{questions.length}</span><button className="button" onClick={onFinish}>End study</button></div></header><main className="study-page"><div className="study-meta"><span>LEARN / {q.topic} / {q.concept}</span><b>{q.difficulty}</b></div><section className="study-card">{q.scenarioTitle&&<div className="scenario-banner"><div><span>STEP {String(q.scenarioStep).padStart(2,'0')} / {String(q.scenarioTotal||q.scenarioStep).padStart(2,'0')}</span><strong>{q.scenarioTitle}</strong></div><p>{inline(q.scenarioBrief)}</p></div>}{q.exhibit&&<ExhibitWorkbench exhibit={q.exhibit}/>}<div className="question-id">STUDY / {q.id}</div><h1>{inline(q.prompt)}</h1><div className="answers">{q.options.map((o,i)=>{const correct=q.answer.includes(i);const active=selected.includes(i);let cls=`answer ${active?'active':''}`;if(done&&correct)cls+=' correct';if(done&&active&&!correct)cls+=' wrong';return <button key={i} className={cls} onClick={()=>setAnswers(a=>({...a,[q.questionId]:q.type==='single'?[i]:(a[q.questionId]||[]).includes(i)?(a[q.questionId]||[]).filter(x=>x!==i):[...(a[q.questionId]||[]),i].sort((x,y)=>x-y)}))}><span>{LETTERS[i]}</span><p>{inline(o)}</p><i>{done&&correct?<Icon name="check" size={15}/>:null}</i></button>})}</div>{done&&<div className={`feedback ${ok?'ok':'bad'}`}><b>{ok?'CORRECT':'REVIEW THIS'}</b><h2>{ok?'Concept confirmed.':'The key idea needs another pass.'}</h2><p>{inline(q.explanation)}</p><span>{q.topic} · {q.concept}</span></div>}<div className="question-footer"><button className="button" disabled={index===0} onClick={()=>setIndex(index-1)}>← Previous</button><span className="keyhelp">Immediate feedback / concept learning</span><button className="button primary" onClick={()=>index===questions.length-1?onFinish():setIndex(index+1)}>{index===questions.length-1?'Finish study':'Next concept'} <Icon name="arrow" size={14}/></button></div></section></main></div>}

function Result({result,onHome,onAgain,onRemediate,theme,onToggleTheme,onOpenSearch}){const weak=Object.values(result.domains||{}).sort((a,b)=>a.pct-b.pct).slice(0,3);return <div className="result-shell"><Header view="" setView={onHome} theme={theme} onToggleTheme={onToggleTheme} onOpenSearch={onOpenSearch}/><main className="page results"><section className="result-hero"><div><div className="eyebrow">ASSESSMENT COMPLETE {result.autoSubmitted&&'/ AUTO-SUBMITTED'}</div><h1>{MODE_META[result.mode]?.label}</h1><p>{formatDate(result.date)} · {result.total} questions · {formatShortDuration(result.timeUsed)}</p></div><div className="result-score"><strong>{result.pct}</strong><span>%</span></div></section><div className="result-strip"><Stat label="Correct" value={result.correct}/><Stat label="Incorrect / blank" value={result.total-result.correct}/><Stat label="Questions" value={result.total}/><Stat label="Time used" value={formatShortDuration(result.timeUsed)}/></div><div className="result-grid"><section className="panel"><div className="panel-head"><div><div className="kicker">01 / BLUEPRINT</div><h2>Domain performance</h2></div></div><div className="domain-list">{Object.values(result.domains).map(d=><div className="domain-row" key={d.id}><div className="domain-name"><b>0{d.id}</b><span>{d.name}</span><small>{d.correct}/{d.total}</small></div><div className="bar"><i style={{width:`${d.pct}%`}}/></div><strong>{d.pct}%</strong></div>)}</div></section><section className="panel"><div className="panel-head"><div><div className="kicker">02 / NEXT ACTION</div><h2>Study targets</h2></div></div>{weak.map(d=><div className="target-row" key={d.id}><span>{d.name}</span><strong>{d.pct}%</strong></div>)}<button className="button primary full" onClick={onRemediate}>Generate remediation <Icon name="arrow" size={14}/></button><p className="note">The readiness system uses your training history. It does not claim to predict the live Cisco score.</p></section></div><section className="panel review-panel"><div className="panel-head"><div><div className="kicker">03 / QUESTION REVIEW</div><h2>{result.questions.length} questions</h2></div><button className="button" onClick={()=>window.print()}>Print</button></div>{result.questions.map(q=><Review key={q.questionId} q={q} selected={result.answers[q.questionId]||[]}/>)}</section></main></div>}
function Review({q,selected}){const ok=getCorrect(q,selected);const selectedText=selected.length?selected.map(i=>`${LETTERS[i]}. ${q.options[i]}`).join(' | '):'No answer';const answerText=q.answer.map(i=>`${LETTERS[i]}. ${q.options[i]}`).join(' | ');return <article className={`review ${ok?'good':'bad'}`}><div className="review-head"><div><span>Q{q.order||''} · {q.topic} · {q.difficulty}</span><strong>{inline(q.prompt)}</strong></div><b>{ok?'CORRECT':'REVIEW'}</b></div><div className="review-body">{!ok&&<div><span>CORRECT ANSWER</span><p>{inline(answerText)}</p></div>}<div><span>YOUR ANSWER</span><p>{inline(selectedText)}</p></div><div className="explanation"><span>RATIONALE</span><p>{inline(q.explanation)}</p></div></div></article>}



function PlaceholderEngineeringView({ title, kicker, copy }) {
  return <main className="page engineering-placeholder"><section className="panel engineering-placeholder-card"><div className="eyebrow">{kicker}</div><h1>{title}</h1><p>{copy}</p><div className="engineering-placeholder-grid"><div><span>FOUNDATION</span><strong>Architecture first</strong><small>Shared device, intent and knowledge models will feed this workspace.</small></div><div><span>NEXT</span><strong>Local device agent</strong><small>SSH and serial connections will be isolated from the browser.</small></div><div><span>GUARDRAIL</span><strong>Preview → Apply → Verify</strong><small>Every future configuration action gets an auditable change path.</small></div></div></section></main>;
}

const WORKSPACE_LABELS = {
  studio: 'Question Studio', knowledge: 'Knowledge Base', discovery: 'Network Discovery',
  devices: 'Devices', config: 'Configuration', changeSets: 'Change Sets', runbooks: 'Runbooks',
  troubleshooting: 'Troubleshooting', twin: 'Twin Intelligence', workflows: 'Unified Workflows',
  review: 'Review Queue', lab: 'CLI Lab', topology: 'Topology Workbench', protocol: 'Protocol Lab',
  flow: 'Flow Lab', packet: 'Packet Lab', 'packet-workshop': 'Packet Workshop', advanced: 'Advanced PBQs',
  'data-safety': 'Data & Recovery', cloud: 'Cloud Sync', drills: 'Guided Drills',
  dashboard: 'Console', analytics: 'Progress & Analytics', mistakes: 'Mistake Bank'
};

function WorkspaceLoading({ view, screen }) {
  const label = screen === 'exam' ? 'Assessment' : screen === 'study' ? 'Study Session' : (WORKSPACE_LABELS[view] || 'Workspace');
  return (
    <main className="page workspace-loading" aria-busy="true">
      <div className="workspace-loading-heading">
        <div className="workspace-loading-mark" aria-hidden="true"><span /></div>
        <div>
          <p className="eyebrow">PREPARING WORKSPACE</p>
          <h1>{label}</h1>
          <p className="workspace-loading-status" role="status">Loading tools and saved state…</p>
        </div>
      </div>
      <div className="workspace-loading-grid" aria-hidden="true">
        <div className="workspace-loading-card"><i /><i /><i /></div>
        <div className="workspace-loading-card"><i /><i /><i /></div>
        <div className="workspace-loading-card wide"><i /><i /><i /><i /></div>
      </div>
    </main>
  );
}

export default function App(){
  const [view,setView]=useState('dashboard'),[screen,setScreen]=useState('home'); const [mode,setMode]=useState('full'),[domain,setDomain]=useState('1');const [adaptive,setAdaptive]=useState(true),[coldStart,setColdStart]=useState(false),[difficulty,setDifficulty]=useState('mixed');
  const [history,setHistory]=useState(()=>readStorage(STORAGE.history,[]));const [seen,setSeen]=useState(()=>readStorage(STORAGE.seen,{}));const [savedSession,setSavedSession]=useState(()=>readStorage(STORAGE.session,null));const [settings,setSettings]=useState(()=>readStorage(STORAGE.settings,{compact:false,sidebarCollapsed:false,theme:'light'}));
  const [theme,setTheme]=useState(()=>{const stored=readStorage(STORAGE.settings,{}).theme;if(stored==='dark'||stored==='light') return stored;return typeof window!=='undefined'&&window.matchMedia?.('(prefers-color-scheme: dark)').matches?'dark':'light';});
  const [commandOpen,setCommandOpen]=useState(false);
  useEffect(()=>{
    const onShortcut=(event)=>{
      const target=event.target;
      const editing=target instanceof HTMLElement && (target.isContentEditable || Boolean(target.closest('input,textarea,select,[contenteditable="true"]')));
      if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'&&!editing){event.preventDefault();setCommandOpen(true);}
    };
    window.addEventListener('keydown',onShortcut);
    return ()=>window.removeEventListener('keydown',onShortcut);
  },[]);
  useEffect(()=>{document.documentElement.dataset.theme=theme;document.documentElement.style.colorScheme=theme;document.querySelector('meta[name="theme-color"]')?.setAttribute('content',theme==='dark'?'#12191d':'#52d8ef');const current={...readStorage(STORAGE.settings,{}),theme};writeStorage(STORAGE.settings,current);setSettings(prev=>({...prev,theme}));},[theme]);
  const [mastery,setMastery]=useState(()=>syncMasteryWithHistory(readStorage(STORAGE.history,[])));
  useEffect(()=>{
    pfTrace('App mounted / initial state', {view, screen, mode, domain, adaptive, coldStart, difficulty, sidebarCollapsed: undefined});
    return ()=>pfTrace('App unmounted');
  }, []);
  useEffect(()=>pfTrace('App navigation state changed', {view, screen}), [view, screen]);
  const [questions,setQuestions]=useState([]),[answers,setAnswers]=useState({}),[review,setReview]=useState(new Set()),[index,setIndex]=useState(0),[startedAt,setStartedAt]=useState(null),[endAt,setEndAt]=useState(null),[timeLeft,setTimeLeft]=useState(0),[result,setResult]=useState(null);const timer=useRef(null);
  const objective=useMemo(()=>objectiveStats(history),[history]);const familyPerf=useMemo(()=>familyStats(history),[history]);const wrongQuestions=useMemo(()=>{const map=new Map();for(const a of history)for(const q of a.questions||[]){if(!getCorrect(q,a.answers?.[q.questionId]||[]))map.set(q.id,{...q,lastSeen:a.date});}return [...map.values()];},[history]);
  const persistSession=useCallback((data)=>{const payload={mode:data.mode??mode,domain:data.domain??domain,questions:data.questions??questions,answers:data.answers??answers,review:[...(data.review??review)],index:data.index??index,startedAt:data.startedAt??startedAt,endAt:data.endAt??endAt};pfTrace('App -> storage: persist session', {mode:payload.mode, domain:payload.domain, questionCount:payload.questions?.length??0, index:payload.index});writeStorage(STORAGE.session,payload);setSavedSession(payload)},[mode,domain,questions,answers,review,index,startedAt,endAt]);
  const startAssessment=useCallback((m='full',d=domain,opts={})=>{if(screen==='exam'&&!opts.force){const ok=window.confirm('An assessment is already active. Start a new one and replace the saved form?');if(!ok){pfTrace('Assessment start cancelled because an active form exists');return;}}const actual=m==='domain'?d:'all';const gen=makeExam({mode:m,domain:actual,history,seen,adaptive:opts.adaptive??adaptive,coldStart:opts.coldStart??coldStart,difficulty:opts.difficulty??difficulty,objectiveFilter:opts.objectiveFilter});const now=Date.now(),mins=MODE_META[m]?.minutes||30,deadline=now+mins*60000;pfTrace('Assessment start requested', {mode:m, domain:actual, questionCount:gen.length, adaptive:opts.adaptive??adaptive, coldStart:opts.coldStart??coldStart, difficulty:opts.difficulty??difficulty});setMode(m);setDomain(actual);setQuestions(gen);setAnswers({});setReview(new Set());setIndex(0);setStartedAt(now);setEndAt(deadline);setTimeLeft(mins*60000);setResult(null);setScreen('exam');setView('dashboard');persistSession({mode:m,domain:actual,questions:gen,answers:{},review:new Set(),index:0,startedAt:now,endAt:deadline});},[adaptive,coldStart,difficulty,domain,history,seen,persistSession,screen]);
  const startStudy=useCallback((m='exhibits')=>{const gen=makeExam({mode:m,domain:'all',history,seen,adaptive:false,coldStart:true,difficulty:'mixed'}).slice(0,12);setMode(m);setQuestions(gen);setAnswers({});setIndex(0);setReview(new Set());setResult(null);setScreen('study');},[history,seen]);
  const startRemediation=useCallback(()=>{const topics=Object.values(objective).filter(x=>x.total&&x.pct<80).sort((a,b)=>a.pct-b.pct).map(x=>x.objective).slice(0,8);startAssessment('remediation','all',{adaptive:true,objectiveFilter:topics.length?topics:null});},[objective,startAssessment]);
  const finish=useCallback((auto=false)=>{if(!questions.length)return;const r=computeResult({mode,domain,questions,answers,review,startedAt,autoSubmitted:auto});const next=[r,...history].slice(0,50);setHistory(next);writeStorage(STORAGE.history,next);const ns={...seen};questions.forEach(q=>{ns[q.questionId]=(ns[q.questionId]||0)+1;});setSeen(ns);writeStorage(STORAGE.seen,ns);
    const masteryNext={...mastery}; questions.forEach(q=>{const base=masteryNext[q.id]||emptyCard(q); const ok=getCorrect(q,answers[q.questionId]||[]); const grade=ok?(review.has(q.questionId)?'hard':'good'):'again'; masteryNext[q.id]={...scheduleCard({...base,question:base.question||emptyCard(q).question},grade,Date.now()),lastSeenAttemptId:r.id};}); writeStorage(MASTERY_STORAGE,masteryNext); setMastery(masteryNext);
    safeStorage.removeItem(STORAGE.session);setSavedSession(null);setResult(r);setScreen('result');setEndAt(null);},[answers,domain,history,mode,questions,review,seen,startedAt,mastery]);
  useEffect(()=>{if(screen!=='exam'||!endAt)return;pfTrace('Effect: exam timer attached', {endAt, questionCount:questions.length});const update=()=>{const l=Math.max(0,endAt-Date.now());setTimeLeft(l);if(l<=0)finish(true)};update();timer.current=setInterval(update,400);return()=>{clearInterval(timer.current);pfTrace('Effect cleanup: exam timer detached');};},[screen,endAt,finish,questions.length]);
  useEffect(()=>{if(screen!=='exam'||!questions.length||!startedAt)return;pfTrace('Effect: exam session persistence triggered', {index,answered:Object.values(answers).filter(v=>Array.isArray(v)&&v.length).length,reviewed:review.size});persistSession({answers,index,review});},[screen,questions.length,startedAt,answers,index,review,persistSession]);
  useEffect(() => {
    if (screen !== 'exam') return undefined;
    const key = (e) => {
      if (['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName)) return;
      const q = questions[index];
      if (q && e.key >= '1' && e.key <= '4') {
        const choice = Number(e.key) - 1;
        setAnswers((current) => {
          const selected = current[q.questionId] || [];
          const next = q.type === 'single'
            ? [choice]
            : (selected.includes(choice) ? selected.filter(x => x !== choice) : [...selected, choice].sort((a,b) => a-b));
          return {...current, [q.questionId]: next};
        });
      }
      if (e.key.toLowerCase() === 'n') setIndex(i => Math.min(questions.length - 1, i + 1));
      if (e.key.toLowerCase() === 'p') setIndex(i => Math.max(0, i - 1));
      if (e.key.toLowerCase() === 'm') {
        setReview((current) => {
          const next = new Set(current);
          const id = questions[index]?.questionId;
          if (!id) return next;
          if (next.has(id)) next.delete(id); else next.add(id);
          return next;
        });
      }
    };
    window.addEventListener('keydown', key);
    pfTrace('Effect: exam keyboard shortcuts attached', {questionIndex:index});
    return () => { window.removeEventListener('keydown', key); pfTrace('Effect cleanup: exam keyboard shortcuts detached'); };
  }, [screen, questions, index]);

  const resume=()=>{if(!savedSession)return;setMode(savedSession.mode);setDomain(savedSession.domain);setQuestions(savedSession.questions);setAnswers(savedSession.answers);setReview(new Set(savedSession.review||[]));setIndex(savedSession.index||0);setStartedAt(savedSession.startedAt);setEndAt(savedSession.endAt);setTimeLeft(Math.max(0,savedSession.endAt-Date.now()));setScreen('exam');};
  const quit=()=>{if(window.confirm('Exit and discard this saved assessment?')){safeStorage.removeItem(STORAGE.session);setSavedSession(null);setScreen('home');setQuestions([])}};
  const gradeReview=useCallback((card,grade)=>{const next={...mastery,[card.key]:{...scheduleCard(card,grade,Date.now()),question:card.question}};writeStorage(MASTERY_STORAGE,next);setMastery(next);},[mastery]);
  const resetData=()=>{if(window.confirm('Reset Driller Bill local history, mistakes, mastery and saved forms?')){try{Object.values(STORAGE).forEach(k=>safeStorage.removeItem(k));safeStorage.removeItem(MASTERY_STORAGE);}catch{}setHistory([]);setSeen({});setMastery({});setSavedSession(null);setScreen('home');setView('dashboard')}};
  const masterySummary=masteryStats(mastery);
  const [labState,setLabState]=useState(()=>{try{return prepareLiveLabState(JSON.parse(safeStorage.getItem(LIVE_LAB_KEY))||createHealthyLiveLab())}catch{return createHealthyLiveLab()}});
  useEffect(()=>{safeStorage.setItem(LIVE_LAB_KEY,JSON.stringify(labState));},[labState]);
  const [topology,setTopology]=useState(loadTopology);
  useEffect(()=>{saveTopology(topology);},[topology]);
  useEffect(()=>{
    if (labState?.meta?.topologyRevision === topology?.updatedAt && labState?.meta?.topologyId === topology?.id) return;
    setLabState(prev=>syncTopologyToLabState(prev, topology));
  },[topology.id, topology.updatedAt, topology, labState?.meta?.topologyRevision, labState?.meta?.topologyId]);
  useEffect(()=>{
    setTopology(prev=>projectLabStateOntoTopology(prev, labState));
  },[labState]);
  const workspaceRevision = `${labState?.meta?.liveNetworkVersion || 1}:${labState?.devices?.R1?.mode || 'exec'}:${topology?.updatedAt || 0}`;
  const networkWorkspaceValue = useMemo(() => ({
    labState, setLabState, topology, setTopology,
    prepareLiveLabState, resetLiveNetwork,
    resetTopology: () => setTopology(demoTopology()),
    workspaceRevision,
  }), [labState, topology, workspaceRevision]);
  const [sidebarCollapsed,setSidebarCollapsed]=useState(()=>readStorage(STORAGE.settings,{compact:false,sidebarCollapsed:false}).sidebarCollapsed??false);
  const [mobileNavOpen,setMobileNavOpen]=useState(false);
  useEffect(()=>pfTrace('Sidebar state changed', {view, screen, sidebarCollapsed, mobileNavOpen}), [view, screen, sidebarCollapsed, mobileNavOpen]);
  const navigateToView=useCallback((next)=>{
    pfTrace('NavigationSidebar -> App.navigateToView', {from:view, screen, to:next});
    if(screen==='exam' && next!==view){
      const ok=window.confirm('Leave the active assessment? Your saved form will remain available to resume.');
      if(!ok){pfTrace('Navigation blocked: active assessment preserved');setMobileNavOpen(false);return;}
    }
    setView(next);
    setScreen('home');
    setMobileNavOpen(false);
  },[screen,view]);
  useEffect(() => {
    const onWorkspaceNavigate = (event) => {
      const next = event?.detail;
      if (typeof next === 'string' && next) navigateToView(next);
    };
    window.addEventListener('driller-bill:navigate', onWorkspaceNavigate);
    return () => window.removeEventListener('driller-bill:navigate', onWorkspaceNavigate);
  }, [navigateToView]);
  const toggleSidebarCollapsed=useCallback((next)=>{const value=typeof next==='function'?next(sidebarCollapsed):next;pfTrace('Sidebar collapse requested', {from:sidebarCollapsed, to:value});setSidebarCollapsed(value);const nextSettings={...settings,sidebarCollapsed:value};setSettings(nextSettings);writeStorage(STORAGE.settings,nextSettings);},[sidebarCollapsed,settings]);
  const workspace = (content) => (
    <NetworkWorkspaceProvider value={networkWorkspaceValue}>
      <>
        <a className="skip-link" href="#main-content">Skip to main content</a>
        <div className={`pf-workspace ${sidebarCollapsed ? 'nav-collapsed' : ''} ${mobileNavOpen ? 'nav-open' : ''}`}>
          <NavigationSidebar
            view={view}
            onNavigate={navigateToView}
            startAssessment={startAssessment}
            collapsed={sidebarCollapsed}
            setCollapsed={toggleSidebarCollapsed}
            mobileOpen={mobileNavOpen}
            setMobileOpen={(next) => {
              pfTrace('Sidebar mobile state requested', { from: mobileNavOpen, to: next });
              setMobileNavOpen(next);
            }}
            assessmentActive={screen === 'exam' || screen === 'study'}
            masteryDue={masterySummary.due}
            mistakeCount={wrongQuestions.length}
          />
          <div className="pf-workspace-main" id="main-content" tabIndex={-1}>
            {screen === 'home' && (
              <Header
                view={view}
                setView={navigateToView}
                theme={theme}
                onToggleTheme={() => setTheme((current) => current === 'dark' ? 'light' : 'dark')}
                onOpenSearch={() => setCommandOpen(true)}
              />
            )}
            <Suspense fallback={<WorkspaceLoading view={view} screen={screen} />}>
              {content}
            </Suspense>
          </div>
        </div>
        <CommandPalette open={commandOpen} onClose={() => setCommandOpen(false)} onNavigate={navigateToView} />
      </>
    </NetworkWorkspaceProvider>
  );
  const homeProps={history,savedSession,objective,wrongCount:wrongQuestions.length,mode,domain,adaptive,coldStart,difficulty,setMode,setDomain,setAdaptive,setColdStart,setDifficulty,startAssessment,resume,startStudy,startRemediation,setView:navigateToView,resetData,masteryDue:masterySummary.due};
  if(screen==='exam'){pfTrace('Sidebar mount boundary: exam screen uses workspace shell', {view, screen});return workspace(<Exam theme={theme} onToggleTheme={()=>setTheme(t=>t==='dark'?'light':'dark')} questions={questions} index={index} setIndex={setIndex} answers={answers} setAnswers={setAnswers} review={review} setReview={setReview} timeLeft={timeLeft} mode={mode} domain={domain} onSubmit={()=>{const blank=questions.filter(q=>(!(answers[q.questionId]||[]).length)).length;if(window.confirm(blank?`${blank} questions are unanswered. Submit anyway?`:'Submit assessment and reveal results?'))finish(false)}} onQuit={quit}/>);}
  if(screen==='study'){pfTrace('Sidebar mount boundary: study screen uses workspace shell', {view, screen});return workspace(<Study theme={theme} onToggleTheme={()=>setTheme(t=>t==='dark'?'light':'dark')} questions={questions} index={index} setIndex={setIndex} answers={answers} setAnswers={setAnswers} onFinish={()=>{setScreen('home');setQuestions([])}}/>);}
  if(screen==='result'&&result)return workspace(<Result theme={theme} onToggleTheme={()=>setTheme(t=>t==='dark'?'light':'dark')} onOpenSearch={()=>setCommandOpen(true)} result={result} onHome={()=>navigateToView('dashboard')} onAgain={()=>startAssessment(result.mode,result.domain)} onRemediate={startRemediation}/>);
  if(view==='studio')return workspace(<QuestionAuthoringStudio/>);
  if(view==='knowledge')return workspace(<KnowledgeBase setView={navigateToView} startAssessment={startAssessment}/>);
  if(view==='discovery')return workspace(<NetworkDiscovery/>);
  if(view==='devices')return workspace(<Devices/>);
  if(view==='config')return workspace(<Devices focus="configuration"/>);
  if(view==='changeSets')return workspace(<ChangeSets/>);
  if(view==='runbooks')return workspace(<Runbooks setView={navigateToView}/>);
  if(view==='troubleshooting')return workspace(<Troubleshooting setView={navigateToView}/>);
  if(view==='twin')return workspace(<TwinIntelligence setView={navigateToView}/>);
  if(view==='workflows')return workspace(<UnifiedWorkflows setView={navigateToView}/>);
  if(view==='review')return workspace(<MasteryReview mastery={mastery} onGrade={gradeReview} onBack={()=>navigateToView('dashboard')}/>);
  if(view==='lab')return workspace(<StatefulLab onHome={()=>navigateToView('dashboard')}/>);
  if(view==='topology')return workspace(<TopologyBuilder onHome={()=>navigateToView('dashboard')}/>);
  if(view==='protocol')return workspace(<ProtocolLab onHome={()=>navigateToView('dashboard')}/>);
  if(view==='flow')return workspace(<FlowLab/>);
  if(view==='packet')return workspace(<PacketLab/>);
  if(view==='packet-workshop')return workspace(<PacketWorkshop/>);
  if(view==='advanced')return workspace(<AdvancedPBQLab onHome={()=>navigateToView('dashboard')}/>);
  if(view==='data-safety')return workspace(<DataSafety onReload={()=>window.location.reload()}/>);
  if(view==='cloud')return workspace(<CloudSync/>);
  if(view==='drills')return workspace(<DrillerBillStudio setView={navigateToView}/>);
  return workspace(<div className={`app ${settings.compact?'compact':''}`}><div className="app-content">{view==='dashboard'&&<Dashboard {...homeProps}/>} {view==='analytics'&&<Analytics history={history} objective={objective} startRemediation={startRemediation}/>} {view==='mistakes'&&<Mistakes wrongQuestions={wrongQuestions} objective={objective} startRemediation={startRemediation} startAssessment={startAssessment}/>}</div></div>);
}
