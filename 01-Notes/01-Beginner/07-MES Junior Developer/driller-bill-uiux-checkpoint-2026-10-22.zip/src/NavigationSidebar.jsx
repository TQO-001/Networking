import React, { useEffect, useRef, useState } from 'react';

const NAV = [
  { title: 'START', collapsible: false, items: [['dashboard', 'Console']] },
  { title: 'LEARN', items: [['drills', 'Guided drills'], ['studio', 'Question studio'], ['knowledge', 'Knowledge base']] },
  { title: 'PRACTICE', items: [['mistakes', 'Mistake bank'], ['review', 'Review queue'], ['analytics', 'Progress & analytics']] },
  { title: 'ENGINEERING', items: [['discovery', 'Network discovery'], ['devices', 'Devices'], ['config', 'Configuration'], ['runbooks', 'Runbooks'], ['troubleshooting', 'Troubleshooting'], ['twin', 'Twin intelligence'], ['workflows', 'Unified workflows'], ['changeSets', 'Change sets']] },
  { title: 'NETWORK LAB', items: [['lab', 'CLI Lab'], ['topology', 'Topology workbench'], ['protocol', 'Protocol Lab'], ['flow', 'Flow Lab'], ['packet', 'Packet Lab'], ['packet-workshop', 'Packet Workshop'], ['advanced', 'Advanced PBQs']] },
  { title: 'SYSTEM', items: [['data-safety', 'Data & recovery'], ['cloud', 'Cloud sync']] },
];

const ICON_PATHS = {
  clock: <><circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3.5 2"/></>,
  dashboard: <><path d="M3.5 10.5 12 3.5l8.5 7"/><path d="M5.5 9.5v10h13v-10M9.5 19.5v-6h5v6"/></>,
  drills: <><path d="m14.5 4.5 5 5-9.7 9.7-5.2 1.2 1.2-5.2z"/><path d="m12.8 6.2 5 5M4 4h5M4 8h3"/></>,
  studio: <><path d="M4 20h4l11-11a2.1 2.1 0 0 0-4-4L4 16z"/><path d="m13.5 6.5 4 4M4 20h16"/></>,
  knowledge: <><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v17H6.5A2.5 2.5 0 0 0 4 22z"/><path d="M4 5.5v14A2.5 2.5 0 0 1 6.5 17H20M8 7h8M8 11h8"/></>,
  mistakes: <><path d="M12 3.5 22 20H2z"/><path d="M12 9v5M12 17.2v.1"/></>,
  review: <><path d="M20 11a8 8 0 0 0-14.5-4L4 9"/><path d="M4 4v5h5M4 13a8 8 0 0 0 14.5 4L20 15"/><path d="M20 20v-5h-5"/></>,
  analytics: <><path d="M4 20V11M10 20V5M16 20v-7M22 20H2"/></>,
  discovery: <><circle cx="12" cy="5" r="2.5"/><circle cx="5" cy="19" r="2.5"/><circle cx="19" cy="19" r="2.5"/><path d="m10.5 7-4 9.5M13.5 7l4 9.5M7.5 19h9"/></>,
  devices: <><rect x="3" y="4" width="18" height="6" rx="1"/><rect x="3" y="14" width="18" height="6" rx="1"/><path d="M7 7h.1M10 7h.1M7 17h.1M10 17h.1M16 7h2M16 17h2"/></>,
  config: <><path d="M4 6h16M4 12h16M4 18h16"/><circle cx="9" cy="6" r="2" fill="currentColor" stroke="none"/><circle cx="15" cy="12" r="2" fill="currentColor" stroke="none"/><circle cx="11" cy="18" r="2" fill="currentColor" stroke="none"/></>,
  runbooks: <><path d="M5 4h14v17H5z"/><path d="M8 8h8M8 12h8M8 16h5"/><path d="m3 7 2-1M3 12l2-1M3 17l2-1"/></>,
  troubleshooting: <><path d="M9 4a4 4 0 0 0-5 5l5 5 5-5a4 4 0 0 0-5-5z"/><path d="m11 13 2 2 6-6 2 2-6 6a2.8 2.8 0 0 1-4-4z"/><path d="m4 16-1.5 1.5a2.1 2.1 0 0 0 3 3L7 19"/></>,
  twin: <><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1" fill="currentColor" stroke="none"/></>,
  workflows: <><rect x="3.5" y="3.5" width="6" height="6" rx="1"/><rect x="14.5" y="14.5" width="6" height="6" rx="1"/><path d="M9.5 6.5h4a2 2 0 0 1 2 2v6M14.5 17.5h-4a2 2 0 0 1-2-2v-6"/></>,
  changeSets: <><path d="M4 7h15l-3-3M20 17H5l3 3"/><path d="M16 4h3v3M5 17v3h3"/></>,
  lab: <><path d="m4 5 6 5-6 5M12 16h8"/></>,
  topology: <><rect x="3" y="3" width="6" height="6" rx="1"/><rect x="15" y="15" width="6" height="6" rx="1"/><rect x="15" y="3" width="6" height="6" rx="1"/><path d="M9 6h6M18 9v6M6 9v8h9"/></>,
  protocol: <><path d="M3 7h5l3 5h5l3-5h2M3 17h5l3-5M16 12l3 5h2"/></>,
  flow: <><path d="M3 6h7l3 6h8M3 18h7l3-6"/><path d="m17 8 4 4-4 4"/></>,
  packet: <><path d="m12 3 8 4.5v9L12 21l-8-4.5v-9z"/><path d="m4 7.5 8 4.7 8-4.7M12 12.2V21"/></>,
  'packet-workshop': <><path d="m12 3 8 4.5v9L12 21l-8-4.5v-9z"/><path d="m8 12 2.5 2.5L16 9"/></>,
  advanced: <><rect x="3.5" y="3.5" width="17" height="17" rx="2"/><path d="m8 12 2.5 2.5L16.5 8"/></>,
  'data-safety': <><path d="M12 3 20 6v5c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6z"/><path d="m8 12 2.5 2.5L16 9"/></>,
  cloud: <><path d="M7 18.5H18a3.5 3.5 0 0 0 .5-7A6 6 0 0 0 7 9.5a4.5 4.5 0 0 0 0 9z"/><path d="m9 14 3-3 3 3M12 11v7"/></>,
  play: <path d="M8 5.5 19 12 8 18.5z" fill="currentColor"/>,
  scenario: <><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.5"/><path d="M12 2v2M22 12h-2"/></>,
  section: <path d="m9 18 6-6-6-6"/>,
};

function NavIcon({ id, size = 19 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">{ICON_PATHS[id] || <circle cx="12" cy="12" r="8" />}</svg>;
}

function readCollapsedSections() {
  const fallback = ['PRACTICE', 'NETWORK LAB', 'SYSTEM'];
  try {
    const stored = JSON.parse(window.localStorage.getItem('drillerBillCollapsedSectionsV2') || 'null');
    return Array.isArray(stored) ? stored.filter((title) => NAV.some((section) => section.title === title && section.collapsible !== false)) : fallback;
  } catch {
    return fallback;
  }
}

const PF_TRACE = typeof import.meta !== 'undefined' && import.meta.env?.DEV;
function sidebarTrace(label, data) {
  if (!PF_TRACE) return;
  if (data === undefined) console.log(`[Driller Bill][data-flow][Sidebar] ${label}`);
  else console.log(`[Driller Bill][data-flow][Sidebar] ${label}`, data);
}

export default function NavigationSidebar({ view, onNavigate, startAssessment, collapsed, setCollapsed, mobileOpen, setMobileOpen, assessmentActive = false, masteryDue = 0, mistakeCount = 0 }) {
  const mobileMenuButtonRef = useRef(null);
  const sidebarRef = useRef(null);
  const [collapsedSections, setCollapsedSections] = useState(readCollapsedSections);

  useEffect(() => {
    sidebarTrace('props received from App', { view, collapsed, mobileOpen, hasNavigate: typeof onNavigate === 'function', hasStartAssessment: typeof startAssessment === 'function' });
  }, [view, collapsed, mobileOpen, onNavigate, startAssessment]);

  useEffect(() => {
    try { window.localStorage.setItem('drillerBillCollapsedSectionsV2', JSON.stringify(collapsedSections)); } catch { /* Navigation preferences are optional. */ }
  }, [collapsedSections]);

  useEffect(() => {
    const activeSection = NAV.find((section) => section.items.some(([id]) => id === view));
    if (activeSection) setCollapsedSections((current) => current.filter((title) => title !== activeSection.title));
  }, [view]);

  useEffect(() => {
    if (!mobileOpen) return undefined;
    const previousFocus = document.activeElement;
    const previousOverflow = document.body.style.overflow;
    const getFocusable = () => [...(sidebarRef.current?.querySelectorAll('button:not([disabled]), a[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])') || [])]
      .filter((element) => element.getAttribute('aria-hidden') !== 'true' && element.offsetParent !== null);
    document.body.style.overflow = 'hidden';
    const focusFrame = requestAnimationFrame(() => getFocusable()[0]?.focus());
    const onDrawerKeyDown = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        setMobileOpen(false);
        mobileMenuButtonRef.current?.focus();
        return;
      }
      if (event.key !== 'Tab') return;
      const focusable = getFocusable();
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    window.addEventListener('keydown', onDrawerKeyDown);
    return () => {
      window.removeEventListener('keydown', onDrawerKeyDown);
      cancelAnimationFrame(focusFrame);
      document.body.style.overflow = previousOverflow;
      if (previousFocus instanceof HTMLElement && previousFocus.isConnected) previousFocus.focus();
    };
  }, [mobileOpen, setMobileOpen]);

  const navigate = (next) => {
    sidebarTrace('child click -> parent callback', { from: view, to: next, collapsed, mobileOpen });
    onNavigate(next);
    setMobileOpen(false);
  };

  const toggleSection = (title) => setCollapsedSections((current) => current.includes(title)
    ? current.filter((item) => item !== title)
    : [...current, title]);

  return (
    <>
      {mobileOpen && <button type="button" className="pf-sidebar-scrim" aria-label="Close navigation" onClick={() => setMobileOpen(false)} />}
      <aside
        ref={sidebarRef}
        id="driller-bill-sidebar"
        data-testid="pf-sidebar"
        className={`pf-sidebar ${collapsed ? 'collapsed' : ''} ${mobileOpen ? 'mobile-open' : ''}`}
        role={mobileOpen ? 'dialog' : undefined}
        aria-modal={mobileOpen ? 'true' : undefined}
        aria-label={mobileOpen ? 'Workspace navigation' : undefined}
      >
        <div className="pf-sidebar-brand">
          <button type="button" className="pf-sidebar-brand-btn" onClick={() => navigate('dashboard')} aria-label="Open Driller Bill console">
            <span className="pf-sidebar-mark"><i /></span>
            <span className="pf-sidebar-brand-copy"><b>Driller Bill</b><small>NETWORK ENGINEERING WORKSPACE</small></span>
          </button>
          <button type="button" className="pf-sidebar-collapse" onClick={() => setCollapsed((value) => !value)} aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'} aria-expanded={!collapsed} title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}>
            <NavIcon id="section" size={18} />
          </button>
        </div>

        <nav data-testid="pf-sidebar-nav" className="pf-sidebar-scroll" aria-label="Driller Bill workspace navigation">
          {NAV.map((section) => {
            const sectionCollapsed = !collapsed && section.collapsible !== false && collapsedSections.includes(section.title);
            const sectionId = `pf-nav-section-${section.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
            return (
              <div className={`pf-sidebar-section ${sectionCollapsed ? 'is-collapsed' : ''}`} key={section.title}>
                {section.collapsible === false ? (
                  !collapsed && <div className="pf-sidebar-section-title static">{section.title}</div>
                ) : (
                  !collapsed && <button type="button" className="pf-sidebar-section-title" aria-expanded={!sectionCollapsed} aria-controls={sectionId} onClick={() => toggleSection(section.title)}>
                    <span>{section.title}</span><span className="pf-sidebar-section-count" aria-hidden="true">{section.items.length}</span><NavIcon id="section" size={14} />
                  </button>
                )}
                <div className="pf-sidebar-section-items" id={sectionId} hidden={sectionCollapsed}>
                  {section.items.map(([id, label]) => {
                    const count = id === 'review' ? masteryDue : id === 'mistakes' ? mistakeCount : 0;
                    return (
                      <button
                        key={id}
                        type="button"
                        data-testid={`nav-${id}`}
                        className={`pf-nav-item ${view === id ? 'active' : ''}`}
                        onClick={() => navigate(id)}
                        title={label}
                        aria-label={collapsed ? label : undefined}
                        aria-current={view === id ? 'page' : undefined}
                      >
                        <span className="pf-nav-glyph"><NavIcon id={id} /></span>
                        {!collapsed && <span className="pf-nav-label">{label}</span>}
                        {!collapsed && count > 0 && <span className="pf-nav-count">{count > 99 ? '99+' : count}</span>}
                        {view === id && <i className="pf-nav-active-dot" aria-hidden="true" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}

          <div className="pf-sidebar-section pf-sidebar-quick-start">
            {!collapsed && <div className="pf-sidebar-section-title static">{assessmentActive ? 'ACTIVE SESSION' : 'QUICK START'}</div>}
            {assessmentActive ? (
              <div className="pf-nav-lock" title="Active assessment" aria-label="Assessment active">
                <span className="pf-nav-glyph"><NavIcon id="clock" /></span>
                {!collapsed && <span className="pf-nav-label">Assessment active</span>}
              </div>
            ) : (
              <>
                <button type="button" className="pf-nav-action" onClick={() => { setMobileOpen(false); startAssessment('full'); }} title="Full simulation" aria-label={collapsed ? 'Start full simulation' : undefined}>
                  <span className="pf-nav-glyph"><NavIcon id="play" /></span>{!collapsed && <span className="pf-nav-label">Full simulation</span>}
                </button>
                <button type="button" className="pf-nav-action secondary" onClick={() => { setMobileOpen(false); startAssessment('scenario'); }} title="Scenario form" aria-label={collapsed ? 'Start scenario form' : undefined}>
                  <span className="pf-nav-glyph"><NavIcon id="scenario" /></span>{!collapsed && <span className="pf-nav-label">Scenario form</span>}
                </button>
              </>
            )}
          </div>
        </nav>

        <div className="pf-sidebar-foot">
          {!collapsed ? (
            <>
              <span className="pf-status-dot" aria-hidden="true" />
              <div><b>LOCAL-FIRST</b><small>Engineering workspace</small></div>
            </>
          ) : <span className="pf-status-dot" aria-hidden="true" />}
        </div>
      </aside>
      <button
        ref={mobileMenuButtonRef}
        type="button"
        className="pf-mobile-menu"
        onClick={() => setMobileOpen(true)}
        aria-label="Open navigation"
        aria-expanded={mobileOpen}
        aria-controls="driller-bill-sidebar"
      ><svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16" /></svg></button>
    </>
  );
}
