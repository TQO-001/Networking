import React, { useMemo, useRef, useState } from 'react';
import { PF_DOMAINS } from './data/question-bank.js';
import { conceptName, DIFFICULTIES, readStorage, writeStorage } from './core/exam-engine.js';

export const AUTHORING_STORAGE = 'pennyFarthingAuthoringV15';

const PRESENTATIONS = ['standard', 'scenario', 'exhibit', 'cli', 'configuration', 'troubleshooting'];
const COGNITIVE = ['knowledge', 'comprehension', 'application', 'analysis'];
const TYPE_OPTIONS = ['single', 'multi'];

function uid(prefix = 'USR') {
  return `${prefix}-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
}

function makeVariant(n = 1, seed = {}) {
  const id = uid('Q');
  return {
    id,
    questionId: id,
    variant: n,
    q: seed.q || '',
    prompt: seed.prompt || seed.q || '',
    options: Array.isArray(seed.options) && seed.options.length ? [...seed.options] : ['', '', '', ''],
    answer: Array.isArray(seed.answer) ? [...seed.answer] : [],
    type: seed.type || 'single',
    explanation: seed.explanation || '',
    difficulty: seed.difficulty || 'application',
    presentation: seed.presentation || 'standard',
    cognitiveLevel: seed.cognitiveLevel || 'application',
    misconception: seed.misconception || '',
    tags: Array.isArray(seed.tags) ? [...seed.tags] : [],
  };
}

function makeFamily() {
  const id = uid('FAM');
  return {
    id,
    name: 'Untitled question family',
    domain: '1',
    topic: '1.1',
    concept: conceptName('1.1'),
    published: false,
    variants: [1, 2, 3, 4, 5].map(n => makeVariant(n)),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

function normalizeFamily(raw) {
  const f = { ...raw };
  f.id = String(f.id || uid('FAM'));
  f.name = f.name || 'Untitled question family';
  f.domain = String(f.domain || '1');
  f.topic = String(f.topic || '1.1');
  f.concept = f.concept || conceptName(f.topic);
  f.published = !!f.published;
  const source = Array.isArray(f.variants) ? f.variants : [];
  f.variants = [1, 2, 3, 4, 5].map((n, idx) => makeVariant(n, source[idx] || {}));
  f.variants.forEach((v, idx) => {
    v.variant = idx + 1;
    v.id = v.id || uid('Q');
    v.questionId = v.questionId || v.id;
    v.prompt = v.prompt || v.q || '';
    v.q = v.q || v.prompt || '';
  });
  f.createdAt = f.createdAt || new Date().toISOString();
  f.updatedAt = new Date().toISOString();
  return f;
}

export function readAuthoringFamilies() {
  const raw = readStorage(AUTHORING_STORAGE, []);
  return Array.isArray(raw) ? raw.map(normalizeFamily) : [];
}

export function validateVariant(v) {
  const errors = [];
  const warnings = [];
  if (!String(v.q || '').trim()) errors.push('Question stem is empty.');
  if (!Array.isArray(v.options) || v.options.length !== 4) errors.push('Exactly four answer choices are required.');
  else if (v.options.some(x => !String(x || '').trim())) errors.push('All four answer choices must contain text.');
  if (!Array.isArray(v.answer) || !v.answer.length) errors.push('At least one correct answer is required.');
  if (v.type === 'multi' && (!Array.isArray(v.answer) || v.answer.length < 2)) warnings.push('Multi-select questions normally benefit from two or more correct answers.');
  if (v.presentation === 'cli' && !v.exhibitText && !v.exhibit) warnings.push('CLI presentation is selected but no exhibit/CLI output is attached.');
  if (String(v.explanation || '').trim().length < 30) warnings.push('Explanation is very short; add enough rationale for remediation review.');
  if (!v.misconception?.trim()) warnings.push('No common misconception is recorded.');
  return { errors, warnings };
}

export function validateFamily(f) {
  const errors = [];
  const warnings = [];
  if (!f.name?.trim()) errors.push('Family name is required.');
  if (!PF_DOMAINS.some(d => String(d.id) === String(f.domain))) errors.push('Domain is invalid.');
  if (!/^\d+\.\d+$/.test(String(f.topic))) errors.push('Objective must look like 1.1, 2.4, 3.4, etc.');
  if (!Array.isArray(f.variants) || f.variants.length !== 5) errors.push('Exactly five variants are required.');
  f.variants.forEach((v, i) => {
    const result = validateVariant(v);
    result.errors.forEach(e => errors.push(`Variant ${i + 1}: ${e}`));
    result.warnings.forEach(w => warnings.push(`Variant ${i + 1}: ${w}`));
  });
  return { valid: errors.length === 0, errors, warnings };
}

function Badge({ children, tone = 'default' }) {
  return <span className={`studio-badge ${tone}`}>{children}</span>;
}

function Field({ label, children, hint }) {
  return <label className="studio-field"><span>{label}</span>{children}{hint && <small>{hint}</small>}</label>;
}

export default function QuestionAuthoringStudio() {
  const [families, setFamilies] = useState(readAuthoringFamilies);
  const [selectedId, setSelectedId] = useState(() => readAuthoringFamilies()[0]?.id || null);
  const [variantIndex, setVariantIndex] = useState(0);
  const [search, setSearch] = useState('');
  const [onlyPublished, setOnlyPublished] = useState(false);
  const [preview, setPreview] = useState(false);
  const [message, setMessage] = useState('');
  const fileRef = useRef(null);

  const selected = families.find(f => f.id === selectedId) || null;
  const variant = selected?.variants?.[variantIndex] || null;
  const selectedValidation = useMemo(() => selected ? validateFamily(selected) : null, [selected]);
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return families.filter(f => (!onlyPublished || f.published) && (!q || `${f.name} ${f.topic} ${f.concept} ${f.id}`.toLowerCase().includes(q)));
  }, [families, search, onlyPublished]);

  const persist = (next, toast = '') => {
    setFamilies(next);
    writeStorage(AUTHORING_STORAGE, next);
    if (toast) { setMessage(toast); window.setTimeout(() => setMessage(''), 2200); }
  };

  const selectFamily = (id) => {
    setSelectedId(id);
    setVariantIndex(0);
    setPreview(false);
  };

  const updateFamily = (patch) => {
    if (!selected) return;
    const next = families.map(f => f.id === selected.id ? { ...f, ...patch, updatedAt: new Date().toISOString() } : f);
    persist(next);
  };

  const updateVariant = (patch) => {
    if (!selected || !variant) return;
    const variants = selected.variants.map((v, i) => i === variantIndex ? { ...v, ...patch } : v);
    const next = families.map(f => f.id === selected.id ? { ...f, variants, updatedAt: new Date().toISOString() } : f);
    persist(next);
  };

  const updateOption = (index, value) => {
    const options = [...variant.options];
    options[index] = value;
    updateVariant({ options });
  };

  const toggleAnswer = (index) => {
    const selectedAnswers = new Set(variant.answer || []);
    if (variant.type === 'multi') {
      if (selectedAnswers.has(index)) selectedAnswers.delete(index); else selectedAnswers.add(index);
      updateVariant({ answer: [...selectedAnswers].sort((a, b) => a - b) });
    } else {
      updateVariant({ answer: [index] });
    }
  };

  const addFamily = () => {
    const f = makeFamily();
    const next = [f, ...families];
    persist(next, 'New five-variant family created.');
    setSelectedId(f.id);
    setVariantIndex(0);
  };

  const duplicateFamily = () => {
    if (!selected) return;
    const copy = normalizeFamily({ ...selected, id: uid('FAM'), name: `${selected.name} copy`, published: false, variants: selected.variants.map(v => ({ ...v, id: uid('Q'), questionId: uid('Q') })) });
    copy.variants = copy.variants.map((v, i) => ({ ...v, id: uid('Q'), questionId: undefined, variant: i + 1 }));
    copy.variants.forEach(v => { v.questionId = v.id; });
    const next = [copy, ...families];
    persist(next, 'Family duplicated.');
    setSelectedId(copy.id);
  };

  const deleteFamily = () => {
    if (!selected) return;
    if (!window.confirm(`Delete “${selected.name}” and all five variants?`)) return;
    const next = families.filter(f => f.id !== selected.id);
    persist(next, 'Family deleted.');
    setSelectedId(next[0]?.id || null);
    setVariantIndex(0);
  };

  const publish = () => {
    if (!selected) return;
    const result = validateFamily(selected);
    if (!result.valid) {
      setMessage(`${result.errors.length} validation error${result.errors.length === 1 ? '' : 's'} found.`);
      return;
    }
    updateFamily({ published: true });
    setMessage('Published to Driller Bill’s local question pool.');
    window.setTimeout(() => setMessage(''), 2200);
  };

  const unpublish = () => updateFamily({ published: false });

  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(families, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'driller-bill-authoring-bank.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const importJSON = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      if (!Array.isArray(parsed)) throw new Error('Expected an array of question families.');
      const imported = parsed.map(normalizeFamily);
      const existing = new Set(families.map(f => f.id));
      const safe = imported.map(f => existing.has(f.id) ? normalizeFamily({ ...f, id: uid('FAM'), name: `${f.name} imported` }) : f);
      const next = [...safe, ...families];
      persist(next, `${safe.length} family${safe.length === 1 ? '' : 'ies'} imported.`);
      setSelectedId(safe[0]?.id || selectedId);
    } catch (error) {
      setMessage(`Import failed: ${error.message}`);
    } finally {
      event.target.value = '';
    }
  };

  const resetDraft = () => {
    if (!selected) return;
    const fresh = makeFamily();
    fresh.id = selected.id;
    fresh.name = selected.name;
    const next = families.map(f => f.id === selected.id ? fresh : f);
    persist(next, 'Family reset to a five-variant draft.');
  };

  const validationTone = selectedValidation?.valid ? 'good' : 'bad';

  return (
    <main className="page studio-page">
      <section className="page-title studio-title">
        <div>
          <div className="eyebrow">QUESTION AUTHORING / LOCAL CONTENT STUDIO</div>
          <h1>Build questions<br/><span>worth getting wrong.</span></h1>
          <p>Create, validate, preview, publish, import and export original CCNA question families. Published families join the local exam generator.</p>
        </div>
        <div className="studio-title-actions">
          <button className="button" onClick={() => fileRef.current?.click()}>Import JSON</button>
          <input ref={fileRef} type="file" accept="application/json,.json" onChange={importJSON} hidden />
          <button className="button" onClick={exportJSON} disabled={!families.length}>Export bank</button>
          <button className="button primary" onClick={addFamily}>+ New family</button>
        </div>
      </section>

      <div className="studio-metrics">
        <div><span>Families</span><strong>{families.length}</strong><small>local authored</small></div>
        <div><span>Variants</span><strong>{families.length * 5}</strong><small>five per family</small></div>
        <div><span>Published</span><strong>{families.filter(f => f.published).length}</strong><small>available to exams</small></div>
        <div><span>Valid</span><strong>{families.filter(f => validateFamily(f).valid).length}</strong><small>ready to publish</small></div>
      </div>

      <div className="studio-layout">
        <section className="panel studio-library">
          <div className="studio-panel-head">
            <div><div className="kicker">01 / CONTENT LIBRARY</div><h2>Question families</h2></div>
            <Badge>{families.length}</Badge>
          </div>
          <div className="studio-search">
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search family, objective, concept..." aria-label="Search question families" />
            <button className={`studio-filter ${onlyPublished ? 'active' : ''}`} onClick={() => setOnlyPublished(v => !v)}>Published only</button>
          </div>
          <div className="studio-family-list">
            {filtered.length ? filtered.map(f => {
              const validation = validateFamily(f);
              return <button key={f.id} className={`studio-family ${f.id === selectedId ? 'active' : ''}`} onClick={() => selectFamily(f.id)}>
                <div className="studio-family-top"><span>{f.topic}</span>{f.published && <Badge tone="published">LIVE</Badge>}</div>
                <strong>{f.name}</strong>
                <small>{f.concept}</small>
                <div className="studio-family-foot"><span>{validation.valid ? 'READY' : `${validation.errors.length} ERRORS`}</span><span>{f.variants.length}/5 variants</span></div>
              </button>;
            }) : <div className="empty-state"><strong>No families match.</strong><span>Clear the filter or create a new family.</span></div>}
          </div>
        </section>

        {selected ? <>
          <section className="panel studio-editor">
            <div className="studio-panel-head">
              <div><div className="kicker">02 / FAMILY EDITOR</div><h2>Metadata & variants</h2></div>
              <div className="studio-head-buttons"><button className="button" onClick={duplicateFamily}>Duplicate</button><button className="button danger" onClick={deleteFamily}>Delete</button></div>
            </div>
            <div className="studio-family-meta">
              <Field label="Family name"><input value={selected.name} onChange={e => updateFamily({ name: e.target.value })} /></Field>
              <Field label="Domain"><select value={selected.domain} onChange={e => { const d = PF_DOMAINS.find(x => String(x.id) === e.target.value); updateFamily({ domain: e.target.value, concept: d?.name || selected.concept }); }}><option value="1">01 · Network Fundamentals</option><option value="2">02 · Network Access</option><option value="3">03 · IP Connectivity</option><option value="4">04 · IP Services</option><option value="5">05 · Security Fundamentals</option><option value="6">06 · Automation & Programmability</option></select></Field>
              <Field label="Objective"><input value={selected.topic} onChange={e => updateFamily({ topic: e.target.value, concept: conceptName(e.target.value) })} /></Field>
              <Field label="Concept"><input value={selected.concept} onChange={e => updateFamily({ concept: e.target.value })} /></Field>
            </div>

            <div className="studio-variants-tabs">
              {selected.variants.map((v, i) => { const r = validateVariant(v); return <button key={v.id} className={i === variantIndex ? 'active' : ''} onClick={() => { setVariantIndex(i); setPreview(false); }}><b>V{i + 1}</b><span className={r.errors.length ? 'bad' : 'good'}>{r.errors.length ? 'ERROR' : 'OK'}</span></button>; })}
            </div>

            {variant && <div className="studio-variant-editor">
              <div className="studio-form-row">
                <Field label="Question type"><select value={variant.type || 'single'} onChange={e => updateVariant({ type: e.target.value, answer: e.target.value === 'multi' ? variant.answer : variant.answer.slice(0, 1) })}>{TYPE_OPTIONS.map(x => <option key={x} value={x}>{x === 'single' ? 'Single answer' : 'Multiple response'}</option>)}</select></Field>
                <Field label="Difficulty"><select value={variant.difficulty} onChange={e => updateVariant({ difficulty: e.target.value })}>{DIFFICULTIES.filter(x => x !== 'mixed').map(x => <option key={x} value={x}>{x}</option>)}</select></Field>
                <Field label="Presentation"><select value={variant.presentation} onChange={e => updateVariant({ presentation: e.target.value })}>{PRESENTATIONS.map(x => <option key={x} value={x}>{x}</option>)}</select></Field>
                <Field label="Cognitive level"><select value={variant.cognitiveLevel} onChange={e => updateVariant({ cognitiveLevel: e.target.value })}>{COGNITIVE.map(x => <option key={x} value={x}>{x}</option>)}</select></Field>
              </div>
              <Field label={`Variant ${variantIndex + 1} question`} hint="Write a genuinely different presentation of the same underlying concept."><textarea className="studio-textarea" value={variant.q} onChange={e => updateVariant({ q: e.target.value, prompt: e.target.value })} rows={5} /></Field>
              <div className="studio-answer-grid">
                {variant.options.map((option, i) => <div className={`studio-answer ${variant.answer?.includes(i) ? 'correct' : ''}`} key={i}>
                  <button className="studio-answer-toggle" onClick={() => toggleAnswer(i)} aria-label={`Mark option ${i + 1} correct`}><b>{String.fromCharCode(65 + i)}</b><span>{variant.answer?.includes(i) ? 'CORRECT' : 'MARK'}</span></button>
                  <input value={option} onChange={e => updateOption(i, e.target.value)} placeholder={`Answer choice ${String.fromCharCode(65 + i)}`} />
                </div>)}
              </div>
              <div className="studio-form-row two">
                <Field label="Explanation"><textarea className="studio-textarea compact" value={variant.explanation} onChange={e => updateVariant({ explanation: e.target.value })} rows={5} /></Field>
                <Field label="Common misconception"><textarea className="studio-textarea compact" value={variant.misconception || ''} onChange={e => updateVariant({ misconception: e.target.value })} rows={5} /></Field>
              </div>
              <Field label="Tags" hint="Comma-separated. Example: ospf, adjacency, hello, timers"><input value={(variant.tags || []).join(', ')} onChange={e => updateVariant({ tags: e.target.value.split(',').map(x => x.trim()).filter(Boolean) })} /></Field>
              {(variant.presentation === 'cli' || variant.presentation === 'exhibit' || variant.presentation === 'configuration') && <Field label="Exhibit / CLI output" hint="Optional evidence block used by the question renderer."><textarea className="studio-textarea" value={variant.exhibitText || ''} onChange={e => updateVariant({ exhibitText: e.target.value })} rows={6} placeholder={'R1# show ip route\n...'} /></Field>}
            </div>}
          </section>

          <aside className="studio-right">
            <section className="panel studio-preview">
              <div className="studio-panel-head"><div><div className="kicker">03 / LIVE PREVIEW</div><h2>Candidate view</h2></div><button className="studio-filter" onClick={() => setPreview(v => !v)}>{preview ? 'Editor' : 'Preview'}</button></div>
              {preview && variant ? <div className="studio-candidate">
                <div className="studio-candidate-meta"><Badge>{selected.topic}</Badge><Badge>{variant.difficulty}</Badge><Badge>{variant.presentation}</Badge></div>
                <h3>{variant.q || 'Your question will appear here.'}</h3>
                <div className="studio-preview-options">{variant.options.map((o, i) => <div key={i} className={variant.answer?.includes(i) ? 'preview-option correct' : 'preview-option'}><b>{String.fromCharCode(65 + i)}</b><span>{o || 'Empty answer choice'}</span></div>)}</div>
                <div className="studio-preview-note">Answer key is hidden in candidate mode.</div>
              </div> : <div className="studio-preview-idle"><div className="studio-preview-mark">PF</div><strong>Preview the candidate experience.</strong><span>The preview reflects the current variant without exposing authoring controls.</span></div>}
            </section>

            <section className="panel studio-validation">
              <div className="studio-panel-head"><div><div className="kicker">04 / VALIDATION</div><h2>Content gate</h2></div><Badge tone={selectedValidation?.valid ? 'published' : 'error'}>{selectedValidation?.valid ? 'READY' : 'BLOCKED'}</Badge></div>
              <div className="studio-checks">
                {(selectedValidation?.errors || []).map((x, i) => <div className="studio-check error" key={`e${i}`}><i>×</i><span>{x}</span></div>)}
                {(selectedValidation?.warnings || []).map((x, i) => <div className="studio-check warning" key={`w${i}`}><i>!</i><span>{x}</span></div>)}
                {selectedValidation?.valid && !selectedValidation.warnings.length && <div className="studio-check good"><i>✓</i><span>All five variants pass the publication gate.</span></div>}
              </div>
              <div className="studio-publish-actions">
                {!selected.published ? <button className="button primary full" onClick={publish}>Validate & publish</button> : <button className="button full" onClick={unpublish}>Unpublish</button>}
                <button className="button full" onClick={resetDraft}>Reset family draft</button>
              </div>
            </section>
          </aside>
        </> : <section className="panel studio-empty-editor"><div className="studio-preview-mark">PF</div><h2>Start the content library.</h2><p>Create your first five-variant family. The authoring studio keeps content separate from React source and publishes valid families into the local exam pool.</p><button className="button primary" onClick={addFamily}>Create first family</button></section>}
      </div>

      <section className="panel studio-usage">
        <div><div className="kicker">05 / CONTENT PIPELINE</div><h2>Author once. Assess everywhere.</h2><p>Published local families are consumed by the randomized exam engine, domain drills, adaptive remediation, and study workflows. Exported JSON can also be moved between Driller Bill environments.</p></div>
        <div className="studio-pipeline"><span>AUTHOR</span><b>→</b><span>VALIDATE</span><b>→</b><span>PUBLISH</span><b>→</b><span>RANDOMIZE</span><b>→</b><span>ANALYZE</span></div>
      </section>

      {message && <div className="studio-toast">{message}</div>}
    </main>
  );
}
