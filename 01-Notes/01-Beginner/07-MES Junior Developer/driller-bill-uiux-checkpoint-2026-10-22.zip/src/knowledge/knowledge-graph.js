export const KNOWLEDGE_GRAPH_VERSION = '1.0.0';

export const KNOWLEDGE_RESOURCE_TYPES = [
  'drill',
  'runbook',
  'scenario',
  'intent',
  'workflow',
];

export const KNOWLEDGE_RESOURCES = {
  'vlans-access-ports': { type: 'drill', id: 'vlans-access-ports', title: 'VLANs & Access Ports', summary: 'Create VLANs and assign switch access ports.', view: 'drills', action: 'drill' },
  'trunking-native-vlans': { type: 'drill', id: 'trunking-native-vlans', title: 'Trunking & Native VLANs', summary: 'Configure explicit trunk and native-VLAN policy.', view: 'drills', action: 'drill' },
  'spanning-tree': { type: 'drill', id: 'spanning-tree', title: 'Spanning Tree Protocol', summary: 'Practice root selection, port roles and loop prevention.', view: 'drills', action: 'drill' },
  'etherchannel-lacp': { type: 'drill', id: 'etherchannel-lacp', title: 'EtherChannel / LACP', summary: 'Build and verify a logical Port-Channel.', view: 'drills', action: 'drill' },
  'inter-vlan-routing': { type: 'drill', id: 'inter-vlan-routing', title: 'Inter-VLAN Routing', summary: 'Practice SVI and routed gateway configuration.', view: 'drills', action: 'drill' },
  'interface-troubleshooting': { type: 'drill', id: 'interface-troubleshooting', title: 'Interface Troubleshooting', summary: 'Use the CLI to isolate interface-state faults.', view: 'drills', action: 'drill' },
  'basic-management-setup': { type: 'drill', id: 'basic-management-setup', title: 'Basic Management Setup', summary: 'Practice foundational Cisco management configuration.', view: 'drills', action: 'drill' },
  'port-security': { type: 'drill', id: 'port-security', title: 'Port Security', summary: 'Practice access-layer security controls.', view: 'drills', action: 'drill' },
  'dhcp-snooping-dai': { type: 'drill', id: 'dhcp-snooping-dai', title: 'DHCP Snooping & DAI', summary: 'Practice DHCP security inspection and trust boundaries.', view: 'drills', action: 'drill' },

  'access-switch-baseline': { type: 'runbook', id: 'access-switch-baseline', title: 'Access Switch Baseline', summary: 'Build and verify a small access-switch baseline.', view: 'runbooks', action: 'runbook' },
  'routed-edge-recovery': { type: 'runbook', id: 'routed-edge-recovery', title: 'Routed Edge Recovery', summary: 'Recover a routed uplink and missing static path.', view: 'runbooks', action: 'runbook' },
  'switch-port-standardization': { type: 'runbook', id: 'switch-port-standardization', title: 'Switch Port Standardization', summary: 'Standardize access-port assignment across a port group.', view: 'runbooks', action: 'runbook' },
  'trunk-standardization': { type: 'runbook', id: 'trunk-standardization', title: 'Trunk Standardization', summary: 'Apply a reviewed native-VLAN and allow-list policy.', view: 'runbooks', action: 'runbook' },

  'SC19-11': { type: 'scenario', id: 'SC19-11', title: 'Branch VLAN outage', summary: 'Interpret VLAN, trunk, native-VLAN, STP and OSPF evidence.', view: 'assessment', action: 'scenario', domain: '2' },
  'SC19-12': { type: 'scenario', id: 'SC19-12', title: 'Routing table investigation', summary: 'Verify forwarding from route and OSPF evidence.', view: 'assessment', action: 'scenario', domain: '3' },
  'SC19-13': { type: 'scenario', id: 'SC19-13', title: 'Branch services recovery', summary: 'Interpret DHCP, NAT, SSH and AAA evidence.', view: 'assessment', action: 'scenario', domain: '4' },
  'SC19-14': { type: 'scenario', id: 'SC19-14', title: 'Campus redundancy event', summary: 'Interpret LACP, RSTP, root and trunk evidence.', view: 'assessment', action: 'scenario', domain: '2' },
  'SC19-15': { type: 'scenario', id: 'SC19-15', title: 'Access security incident', summary: 'Trace DHCP snooping, port security, ACL and management evidence.', view: 'assessment', action: 'scenario', domain: '5' },
  'SC19-16': { type: 'scenario', id: 'SC19-16', title: 'Wireless rollout', summary: 'Reason about controller-managed wireless design and policy.', view: 'assessment', action: 'scenario', domain: '6' },
  'SC19-17': { type: 'scenario', id: 'SC19-17', title: 'Automation operations', summary: 'Interpret API-driven network automation evidence.', view: 'assessment', action: 'scenario', domain: '6' },
  'SC19-18': { type: 'scenario', id: 'SC19-18', title: 'IPv6 and gateway edge', summary: 'Reason about IPv6 and first-hop resiliency evidence.', view: 'assessment', action: 'scenario', domain: '3' },

  'intent:create-vlan': { type: 'intent', id: 'create-vlan', title: 'Create VLAN', summary: 'Describe a VLAN change as typed intent.', view: 'config', action: 'config' },
  'intent:assign-access-vlan': { type: 'intent', id: 'assign-access-vlan', title: 'Assign Access VLAN', summary: 'Assign an interface to an access VLAN.', view: 'config', action: 'config' },
  'intent:assign-access-vlan-bulk': { type: 'intent', id: 'assign-access-vlan-bulk', title: 'Bulk Assign Access VLAN', summary: 'Apply a reviewed access-VLAN change to multiple interfaces.', view: 'config', action: 'config' },
  'intent:set-trunk-policy': { type: 'intent', id: 'set-trunk-policy', title: 'Configure Trunk Policy', summary: 'Set trunk mode, native VLAN and an explicit allow-list.', view: 'config', action: 'config' },
  'intent:set-trunk-vlans': { type: 'intent', id: 'set-trunk-vlans', title: 'Set Trunk VLANs', summary: 'Control the VLAN allow-list on a trunk.', view: 'config', action: 'config' },
  'intent:set-interface-state': { type: 'intent', id: 'set-interface-state', title: 'Set Interface State', summary: 'Administratively enable or disable an interface.', view: 'config', action: 'config' },
  'intent:add-static-route': { type: 'intent', id: 'add-static-route', title: 'Add Static Route', summary: 'Describe a static route change with a destination and next hop.', view: 'config', action: 'config' },
  'intent:set-interface-description': { type: 'intent', id: 'set-interface-description', title: 'Set Interface Description', summary: 'Document the purpose of a network interface.', view: 'config', action: 'config' },
  'intent:save-running-config': { type: 'intent', id: 'save-running-config', title: 'Save Startup Configuration', summary: 'Persist the verified running configuration.', view: 'config', action: 'config' },

  'workflow:topology': { type: 'workflow', id: 'topology', title: 'Topology Builder', summary: 'Model the network and inspect how devices and links relate.', view: 'topology', action: 'workflow' },
  'workflow:lab': { type: 'workflow', id: 'lab', title: 'CLI Lab', summary: 'Work through a stateful network lab.', view: 'lab', action: 'workflow' },
  'workflow:devices': { type: 'workflow', id: 'devices', title: 'Device Workspace', summary: 'Inspect devices, diagnostics and live sessions.', view: 'devices', action: 'workflow' },
  'workflow:troubleshooting': { type: 'workflow', id: 'troubleshooting', title: 'Troubleshooting Workspace', summary: 'Move from symptom to evidence, hypothesis, test and verification.', view: 'troubleshooting', action: 'workflow' },
};

export const KNOWLEDGE_RELATIONS = {
  vlan: {
    drills: ['vlans-access-ports', 'inter-vlan-routing'],
    runbooks: ['access-switch-baseline', 'switch-port-standardization'],
    scenarios: ['SC19-11', 'SC19-15'],
    intents: ['intent:create-vlan', 'intent:assign-access-vlan', 'intent:assign-access-vlan-bulk'],
    workflows: ['workflow:topology', 'workflow:lab'],
  },
  trunking: {
    drills: ['trunking-native-vlans', 'spanning-tree'],
    runbooks: ['access-switch-baseline', 'trunk-standardization'],
    scenarios: ['SC19-11', 'SC19-14'],
    intents: ['intent:set-trunk-policy', 'intent:set-trunk-vlans'],
    workflows: ['workflow:topology', 'workflow:devices'],
  },
  stp: {
    drills: ['spanning-tree', 'etherchannel-lacp'],
    runbooks: [],
    scenarios: ['SC19-11', 'SC19-14'],
    intents: [],
    workflows: ['workflow:topology', 'workflow:lab'],
  },
  etherchannel: {
    drills: ['etherchannel-lacp'],
    runbooks: [],
    scenarios: ['SC19-14'],
    intents: [],
    workflows: ['workflow:topology', 'workflow:lab'],
  },
  'inter-vlan-routing': {
    drills: ['inter-vlan-routing'],
    runbooks: ['access-switch-baseline'],
    scenarios: ['SC19-11', 'SC19-13'],
    intents: ['intent:set-interface-state'],
    workflows: ['workflow:topology', 'workflow:lab'],
  },
  ipv4: {
    drills: ['inter-vlan-routing'],
    runbooks: ['routed-edge-recovery'],
    scenarios: ['SC19-12', 'SC19-13', 'SC19-18'],
    intents: ['intent:add-static-route', 'intent:set-interface-state'],
    workflows: ['workflow:topology', 'workflow:lab'],
  },
  ospf: {
    drills: [],
    runbooks: ['routed-edge-recovery'],
    scenarios: ['SC19-11', 'SC19-12'],
    intents: ['intent:add-static-route'],
    workflows: ['workflow:topology', 'workflow:troubleshooting'],
  },
  acl: {
    drills: ['full-device', 'interface-troubleshooting'],
    runbooks: [],
    scenarios: ['SC19-15'],
    intents: [],
    workflows: ['workflow:devices', 'workflow:troubleshooting'],
  },
  ssh: {
    drills: ['basic-management-setup'],
    runbooks: [],
    scenarios: ['SC19-13'],
    intents: [],
    workflows: ['workflow:devices'],
  },
  troubleshooting: {
    drills: ['interface-troubleshooting', 'full-device'],
    runbooks: ['routed-edge-recovery'],
    scenarios: ['SC19-11', 'SC19-12', 'SC19-13', 'SC19-15'],
    intents: ['intent:set-interface-state', 'intent:add-static-route'],
    workflows: ['workflow:troubleshooting', 'workflow:devices'],
  },
};

const uniq = (values) => [...new Set(values.filter(Boolean))];

export function resourceKey(type, id) {
  return type === 'intent' || type === 'workflow' ? `${type}:${id}` : id;
}

export function getKnowledgeConnections(articleId) {
  const relation = KNOWLEDGE_RELATIONS[articleId] || {};
  return Object.fromEntries(KNOWLEDGE_RESOURCE_TYPES.map((type) => [
    `${type}s`, uniq((relation[`${type}s`] || []).map((id) => {
      const key = resourceKey(type, id);
      return KNOWLEDGE_RESOURCES[key] || KNOWLEDGE_RESOURCES[id] ? (KNOWLEDGE_RESOURCES[key] || KNOWLEDGE_RESOURCES[id]) : null;
    })),
  ]));
}

export function buildKnowledgeGraph(articleIds = Object.keys(KNOWLEDGE_RELATIONS)) {
  const nodes = [];
  const edges = [];
  const seen = new Set();
  for (const articleId of articleIds) {
    const articleNode = `article:${articleId}`;
    if (!seen.has(articleNode)) {
      nodes.push({ id: articleNode, type: 'article', ref: articleId });
      seen.add(articleNode);
    }
    const relation = KNOWLEDGE_RELATIONS[articleId] || {};
    for (const type of KNOWLEDGE_RESOURCE_TYPES) {
      for (const id of relation[`${type}s`] || []) {
        const key = resourceKey(type, id);
        const resource = KNOWLEDGE_RESOURCES[key] || KNOWLEDGE_RESOURCES[id];
        if (!resource) continue;
        const resourceNode = `${type}:${resource.id}`;
        if (!seen.has(resourceNode)) {
          nodes.push({ id: resourceNode, type, ref: resource.id, title: resource.title });
          seen.add(resourceNode);
        }
        edges.push({ from: articleNode, to: resourceNode, type: 'connects' });
      }
    }
  }
  return { version: KNOWLEDGE_GRAPH_VERSION, nodes, edges };
}

export function knowledgeGraphStats() {
  const graph = buildKnowledgeGraph();
  return {
    articles: graph.nodes.filter((node) => node.type === 'article').length,
    resources: graph.nodes.filter((node) => node.type !== 'article').length,
    edges: graph.edges.length,
    byType: Object.fromEntries(KNOWLEDGE_RESOURCE_TYPES.map((type) => [type, graph.nodes.filter((node) => node.type === type).length])),
  };
}
