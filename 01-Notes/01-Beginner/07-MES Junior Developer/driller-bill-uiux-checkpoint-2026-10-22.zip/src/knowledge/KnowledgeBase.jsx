import React, { useMemo, useState } from 'react';
import { safeStorage } from '../storage.js';
import { KNOWLEDGE_ARTICLES, KNOWLEDGE_CATEGORIES, getKnowledgeArticle, searchKnowledge } from './knowledge-base.js';
import { getKnowledgeConnections, knowledgeGraphStats } from './knowledge-graph.js';
import UnifiedWorkflowBar from '../UnifiedWorkflowBar.jsx';
import { startWorkflow, workflowFromKnowledge } from '../core/unified-workflows.js';

const DRILL_MODULE_KEY = 'driller-bill.last-module.v2';
const RUNBOOK_FOCUS_KEY = 'drillerBill.runbooks.focus.v1';

function Icon({ name, size = 16 }) {
  const paths = {
    search: <><circle cx="10.8" cy="10.8" r="6.5"/><path d="m16 16 4.2 4.2"/></>,
    arrow: <><path d="M5 12h13"/><path d="m13 6 6 6-6 6"/></>,
    book: <><path d="M5 5.5A2.5 2.5 0 0 1 7.5 3H19v17H7.5A2.5 2.5 0 0 0 5 22z"/><path d="M5 5.5v16"/></>,
    play: <path d="M8 5l11 7-11 7V5z" fill="currentColor"/>,
    terminal: <><path d="m5 7 5 5-5 5"/><path d="M12 17h7"/></>,
    shield: <><path d="M12 3 19 6v5c0 4.3-2.5 7.8-7 10-4.5-2.2-7-5.7-7-10V6z"/><path d="m9 12 2 2 4-4"/></>,
    link: <><path d="m9.5 14.5 5-5"/><path d="M7 17H5.5A3.5 3.5 0 0 1 2 13.5v0A3.5 3.5 0 0 1 5.5 10H9"/><path d="M15 7h3.5a3.5 3.5 0 0 1 0 7H15"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

const TYPE_LABELS = {
  drills: 'Learning',
  runbooks: 'Operations',
  scenarios: 'Cases',
  intents: 'Configuration',
  workflows: 'Workspaces',
};

const TYPE_ACTIONS = {
  drill: 'Open drill',
  runbook: 'Open runbook',
  scenario: 'Start case',
  config: 'Open configuration',
  workflow: 'Open workspace',
};

export default function KnowledgeBase({ setView, startAssessment }) {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('all');
  const [selectedId, setSelectedId] = useState('vlan');
  const [copied, setCopied] = useState('');
  const results = useMemo(() => searchKnowledge(query, category), [query, category]);
  const selected = getKnowledgeArticle(selectedId);
  const related = selected.related.map((id) => KNOWLEDGE_ARTICLES.find((article) => article.id === id)).filter(Boolean);
  const connections = useMemo(() => getKnowledgeConnections(selected.id), [selected.id]);
  const graphStats = useMemo(() => knowledgeGraphStats(), []);
  const connectionCount = Object.values(connections).reduce((sum, items) => sum + items.length, 0);

  const selectArticle = (id) => { setSelectedId(id); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const copyCode = async (text) => {
    try { await navigator.clipboard.writeText(text); setCopied(text); window.setTimeout(() => setCopied(''), 1200); } catch {}
  };

  const startKnowledgeWorkflow = () => {
    startWorkflow(safeStorage, workflowFromKnowledge(selected, { target: null }));
    setView?.('workflows');
  };

  const openResource = (resource) => {
    if (!resource) return;
    if (resource.action === 'drill') {
      safeStorage.setItem(DRILL_MODULE_KEY, resource.id);
      setView?.('drills');
      return;
    }
    if (resource.action === 'runbook') {
      safeStorage.setItem(RUNBOOK_FOCUS_KEY, resource.id);
      setView?.('runbooks');
      return;
    }
    if (resource.action === 'scenario') {
      if (resource.domain && startAssessment) startAssessment('domain', resource.domain, { coldStart: false });
      return;
    }
    if (resource.action === 'config') {
      setView?.('config');
      return;
    }
    if (resource.action === 'workflow') {
      setView?.(resource.view || 'lab');
    }
  };

  return <main className="page kb-page"><UnifiedWorkflowBar view="knowledge" setView={setView}/>
    <section className="kb-hero">
      <div className="kb-hero-copy">
        <div className="eyebrow">KNOWLEDGE / NETWORK ENGINEERING</div>
        <h1>Understand the network.<br/><span>Then change it.</span></h1>
        <p>A local-first technical knowledge base where concepts connect directly to drills, evidence-driven cases, typed configuration intents, operational runbooks and network workspaces.</p>
      </div>
      <div className="kb-hero-stat"><strong>{KNOWLEDGE_ARTICLES.length}</strong><span>seeded articles</span><small>{graphStats.resources} linked resources · {graphStats.edges} relationships</small></div>
    </section>

    <section className="kb-graph-strip">
      {['drills', 'runbooks', 'scenarios', 'intents', 'workflows'].map((type) => <div key={type}><span>{TYPE_LABELS[type]}</span><b>{graphStats.byType[type.slice(0, -1)] ?? graphStats.byType[type] ?? 0}</b></div>)}
    </section>

    <section className="kb-search panel">
      <div className="kb-search-box"><Icon name="search" size={17}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search concepts, commands, symptoms..." aria-label="Search knowledge base" /></div>
      <div className="kb-category-row">
        <button className={category === 'all' ? 'active' : ''} onClick={() => setCategory('all')}>All</button>
        {KNOWLEDGE_CATEGORIES.map(item => <button key={item.id} className={category === item.id ? 'active' : ''} onClick={() => setCategory(item.id)}>{item.label}</button>)}
      </div>
    </section>

    <div className="kb-layout">
      <aside className="kb-index panel">
        <div className="panel-head"><div><div className="kicker">KNOWLEDGE INDEX</div><h2>{results.length} results</h2></div><span className="panel-micro">LOCAL</span></div>
        <div className="kb-result-list">
          {results.map(article => <button key={article.id} className={`kb-result ${selected.id === article.id ? 'active' : ''}`} onClick={() => selectArticle(article.id)}>
            <span className="kb-result-category">{KNOWLEDGE_CATEGORIES.find(c => c.id === article.category)?.label || article.category}</span>
            <strong>{article.title}</strong>
            <small>{article.summary}</small>
          </button>)}
          {!results.length && <div className="kb-empty">No knowledge entries match that search.</div>}
        </div>
      </aside>

      <article className="kb-article">
        <header className="kb-article-head panel">
          <div><span className="kb-level">{selected.level.toUpperCase()} · {KNOWLEDGE_CATEGORIES.find(c => c.id === selected.category)?.label.toUpperCase()}</span><h2>{selected.title}</h2><p>{selected.summary}</p></div>
          <div className="kb-command-box"><span>COMMAND SURFACE</span><b>{selected.commands.length}</b><small>known references</small><button className="button" onClick={startKnowledgeWorkflow}>Start workflow</button></div>
        </header>

        <section className="kb-tags">{selected.tags.map(tag => <span key={tag}>#{tag}</span>)}</section>

        <section className="panel kb-network-map">
          <div className="panel-head"><div><div className="kicker">KNOWLEDGE GRAPH</div><h2>{connectionCount} connected resources</h2></div><span className="panel-micro">ARTICLE → ACTION</span></div>
          <p className="kb-network-copy">This concept is now an entry point into the rest of Driller Bill. Learn it, investigate it, configure it, or operate it without losing the context you started from.</p>
          <div className="kb-resource-groups">
            {Object.entries(connections).filter(([, items]) => items.length).map(([group, items]) => <section key={group} className="kb-resource-group">
              <div className="kb-resource-group-head"><span>{TYPE_LABELS[group] || group.toUpperCase()}</span><b>{items.length}</b></div>
              <div className="kb-resource-grid">{items.map(resource => <button key={`${resource.type}-${resource.id}`} className="kb-resource-card" onClick={() => openResource(resource)}>
                <span className="kb-resource-icon"><Icon name={resource.type === 'drill' ? 'terminal' : resource.type === 'scenario' ? 'search' : resource.type === 'intent' ? 'shield' : resource.type === 'workflow' ? 'link' : 'book'} size={14}/></span>
                <span className="kb-resource-body"><strong>{resource.title}</strong><small>{resource.summary}</small></span>
                <span className="kb-resource-action">{TYPE_ACTIONS[resource.action] || 'Open'} <Icon name="arrow" size={11}/></span>
              </button>)}</div>
            </section>)}
          </div>
        </section>

        <div className="kb-sections">
          {selected.sections.map(([title, body]) => <section className="panel kb-section" key={title}>
            <div className="kb-section-kicker">{title.toUpperCase()}</div>
            {title.toLowerCase().includes('example') || title.toLowerCase().includes('verification') ? <div className="kb-code-wrap"><pre>{body}</pre><button onClick={() => copyCode(body)}>{copied === body ? 'COPIED' : 'COPY'}</button></div> : <p>{body}</p>}
          </section>)}
        </div>

        <section className="panel kb-command-list">
          <div className="panel-head"><div><div className="kicker">COMMAND REFERENCES</div><h2>From intent to CLI</h2></div></div>
          <div className="kb-command-grid">{selected.commands.map(command => <code key={command}>{command}</code>)}</div>
          <p>These references are knowledge objects, not just strings. The device layer can map an intent such as <b>create VLAN</b> to a vendor implementation and preserve verification as a separate concern.</p>
        </section>

        <section className="panel kb-related">
          <div className="panel-head"><div><div className="kicker">CONCEPT GRAPH</div><h2>Related concepts</h2></div></div>
          <div className="kb-related-grid">{related.map(article => <button key={article.id} onClick={() => selectArticle(article.id)}><Icon name="book" size={15}/><span><strong>{article.title}</strong><small>{article.summary}</small></span><Icon name="arrow" size={13}/></button>)}</div>
        </section>
      </article>
    </div>
  </main>;
}
