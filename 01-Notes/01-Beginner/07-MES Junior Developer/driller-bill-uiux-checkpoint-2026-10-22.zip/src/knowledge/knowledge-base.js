export const KNOWLEDGE_CATEGORIES = [
  { id: 'fundamentals', label: 'Fundamentals' },
  { id: 'switching', label: 'Switching' },
  { id: 'routing', label: 'Routing' },
  { id: 'services', label: 'Services' },
  { id: 'security', label: 'Security' },
  { id: 'operations', label: 'Operations' },
];

export const KNOWLEDGE_ARTICLES = [
  {
    id: 'vlan', title: 'Virtual LANs', category: 'switching', level: 'foundation', summary: 'Segment a switched network into logical broadcast domains.',
    tags: ['VLAN', 'switching', 'broadcast domain'], commands: ['vlan', 'name', 'show vlan brief', 'show interfaces switchport'],
    related: ['trunking', 'inter-vlan-routing', 'stp'],
    sections: [
      ['Overview', 'A VLAN gives a switched network a logical broadcast boundary. Hosts in different VLANs require a Layer 3 function to communicate.'],
      ['Configuration model', 'Create the VLAN, give it a meaningful name, then associate access interfaces with it. Keep the intent separate from the vendor-specific command syntax.'],
      ['Cisco example', 'vlan 10\n name SALES\n\ninterface GigabitEthernet0/1\n switchport mode access\n switchport access vlan 10'],
      ['Verification', 'show vlan brief\nshow interfaces GigabitEthernet0/1 switchport'],
      ['Common failure modes', 'The VLAN does not exist, the interface is still in the wrong mode, the port is assigned to the wrong VLAN, or the expected trunk path does not carry the VLAN.'],
    ],
  },
  {
    id: 'trunking', title: '802.1Q Trunking', category: 'switching', level: 'intermediate', summary: 'Carry multiple VLANs across a single Layer 2 link.',
    tags: ['802.1Q', 'trunk', 'native VLAN'], commands: ['switchport mode trunk', 'switchport trunk allowed vlan', 'show interfaces trunk'], related: ['vlan', 'stp', 'inter-vlan-routing'],
    sections: [
      ['Overview', 'A trunk carries traffic for multiple VLANs between network devices. IEEE 802.1Q identifies the VLAN associated with an Ethernet frame.'],
      ['Configuration model', 'Set the link to trunk mode, define the permitted VLAN set, and explicitly document native-VLAN expectations where applicable.'],
      ['Cisco example', 'interface GigabitEthernet0/24\n switchport mode trunk\n switchport trunk allowed vlan 10,20,30'],
      ['Verification', 'show interfaces trunk\nshow interfaces GigabitEthernet0/24 switchport'],
      ['Common failure modes', 'A VLAN is absent from the allowed list, the two sides disagree about trunk expectations, or native-VLAN assumptions differ.'],
    ],
  },
  {
    id: 'stp', title: 'Spanning Tree Protocol', category: 'switching', level: 'intermediate', summary: 'Prevent Layer 2 loops while preserving redundant paths.',
    tags: ['STP', 'RSTP', 'root bridge', 'loop prevention'], commands: ['show spanning-tree', 'spanning-tree vlan'], related: ['vlan', 'trunking', 'etherchannel'],
    sections: [
      ['Overview', 'STP creates a loop-free Layer 2 topology by selecting forwarding and non-forwarding paths. Redundancy can remain physically present without allowing a persistent switching loop.'],
      ['Operational model', 'The network elects a root bridge and evaluates paths toward it. Port roles and states determine which links forward traffic.'],
      ['Cisco verification', 'show spanning-tree\nshow spanning-tree vlan 10'],
      ['Troubleshooting', 'Start with the root bridge, then inspect the affected VLAN, port roles, blocked paths, topology changes and the physical topology.'],
    ],
  },
  {
    id: 'etherchannel', title: 'EtherChannel', category: 'switching', level: 'intermediate', summary: 'Bundle multiple physical links into one logical link.',
    tags: ['LACP', 'EtherChannel', 'Port-Channel'], commands: ['channel-group', 'interface Port-channel', 'show etherchannel summary'], related: ['stp', 'trunking'],
    sections: [
      ['Overview', 'EtherChannel combines compatible physical links into a logical Port-Channel. STP and higher-level configuration can then treat the bundle as a logical connection.'],
      ['Operational model', 'Member interfaces need compatible settings. LACP is commonly used to negotiate the bundle.'],
      ['Cisco example', 'interface range GigabitEthernet0/1-2\n channel-group 1 mode active\n\ninterface Port-channel1\n switchport mode trunk'],
      ['Verification', 'show etherchannel summary\nshow interfaces port-channel 1'],
    ],
  },
  {
    id: 'inter-vlan-routing', title: 'Inter-VLAN Routing', category: 'routing', level: 'intermediate', summary: 'Provide Layer 3 connectivity between VLANs.',
    tags: ['SVI', 'router-on-a-stick', 'default gateway'], commands: ['interface vlan', 'ip address', 'show ip interface brief'], related: ['vlan', 'trunking', 'ipv4'],
    sections: [
      ['Overview', 'Hosts in separate VLANs need a Layer 3 gateway to communicate. The gateway can be provided by a router subinterface or a multilayer switch SVI.'],
      ['SVI model', 'An SVI represents the Layer 3 interface for a VLAN on a multilayer switch. Hosts normally use that address as their default gateway.'],
      ['Cisco example', 'interface vlan 10\n ip address 192.168.10.1 255.255.255.0\n no shutdown'],
      ['Verification', 'show ip interface brief\nshow ip route\nshow interfaces vlan 10'],
    ],
  },
  {
    id: 'ipv4', title: 'IPv4 Addressing & Subnetting', category: 'fundamentals', level: 'foundation', summary: 'Plan IPv4 networks, masks, host ranges and gateways.',
    tags: ['IPv4', 'subnetting', 'CIDR'], commands: ['show ip interface brief', 'show ip route'], related: ['inter-vlan-routing', 'ospf'],
    sections: [
      ['Overview', 'An IPv4 prefix defines a network portion and a host portion. CIDR notation expresses the prefix length, such as /24 or /27.'],
      ['Engineering workflow', 'Determine the required number of networks and hosts, choose a prefix, document the network and usable ranges, then allocate gateways and infrastructure addresses.'],
      ['Verification', 'show ip interface brief\nshow ip route'],
      ['Common failure modes', 'Overlapping prefixes, incorrect masks, wrong default gateways, duplicate addresses, and routes that do not cover the destination.'],
    ],
  },
  {
    id: 'ospf', title: 'OSPF', category: 'routing', level: 'intermediate', summary: 'Exchange link-state routing information within an OSPF domain.',
    tags: ['OSPF', 'routing', 'area 0', 'neighbors'], commands: ['router ospf', 'network', 'show ip ospf neighbor', 'show ip route ospf'], related: ['ipv4', 'troubleshooting'],
    sections: [
      ['Overview', 'OSPF forms adjacencies with neighbors and builds a link-state database from which routes are calculated.'],
      ['Operational model', 'Start with interface reachability and addressing, then verify OSPF process parameters, area membership, network advertisements and neighbor state.'],
      ['Verification', 'show ip ospf neighbor\nshow ip ospf interface brief\nshow ip route ospf'],
      ['Troubleshooting', 'If a route is missing, verify the local interface, neighbor relationship, advertised prefix, area and resulting route selection.'],
    ],
  },
  {
    id: 'acl', title: 'Access Control Lists', category: 'security', level: 'intermediate', summary: 'Match traffic against ordered permit and deny rules.',
    tags: ['ACL', 'security', 'traffic filtering'], commands: ['access-list', 'ip access-group', 'show access-lists'], related: ['ipv4', 'troubleshooting'],
    sections: [
      ['Overview', 'An ACL evaluates traffic against an ordered sequence of rules. A packet can be affected by the first matching entry and by the implicit behavior at the end of the list.'],
      ['Engineering workflow', 'Define the traffic that should be permitted, place specific rules before broader rules, apply the ACL in the intended direction and verify counters.'],
      ['Verification', 'show access-lists\nshow ip interface'],
      ['Common failure modes', 'Wrong source or destination, wrong direction, overly broad entries, incorrect wildcard masks, or an unintended final deny.'],
    ],
  },
  {
    id: 'ssh', title: 'Secure Device Management with SSH', category: 'operations', level: 'foundation', summary: 'Manage network equipment through an authenticated encrypted management session.',
    tags: ['SSH', 'management', 'AAA'], commands: ['ip domain-name', 'crypto key generate rsa', 'transport input ssh', 'show ip ssh'], related: ['troubleshooting'],
    sections: [
      ['Overview', 'SSH provides an encrypted remote management channel. A production design should also control who can authenticate and what they are allowed to do.'],
      ['Device workflow', 'Give the device an identity, configure the required cryptographic material and local or external authentication, then restrict the management lines to the intended protocol.'],
      ['Verification', 'show ip ssh\nshow users\nshow running-config | section line vty'],
      ['Operational note', 'Driller Bill should treat credentials as secrets. A future device agent should keep authentication material outside browser state and never place passwords into configuration history or telemetry.'],
    ],
  },
  {
    id: 'troubleshooting', title: 'Network Troubleshooting Method', category: 'operations', level: 'foundation', summary: 'Use evidence to isolate a fault instead of changing configuration blindly.',
    tags: ['troubleshooting', 'methodology', 'verification'], commands: ['show interfaces', 'show ip route', 'show logging', 'ping', 'traceroute'], related: ['vlan', 'trunking', 'ospf', 'acl'],
    sections: [
      ['Start with the symptom', 'Define what works, what fails, when it started, and which devices or users are affected.'],
      ['Move through layers', 'Check physical state, Layer 2 adjacency, Layer 3 addressing and routing, services, then application behavior. Use the smallest useful test at each stage.'],
      ['Change one thing at a time', 'Record observations before changing configuration. Make a reversible change, verify the expected effect, and document the result.'],
      ['Useful evidence', 'Interface counters, link state, MAC tables, VLAN membership, ARP, routing tables, neighbor state, ACL counters and logs can turn a vague symptom into a bounded fault domain.'],
    ],
  },
];

export function getKnowledgeArticle(id) {
  return KNOWLEDGE_ARTICLES.find(article => article.id === id) || KNOWLEDGE_ARTICLES[0];
}

export function searchKnowledge(query = '', category = 'all') {
  const needle = query.trim().toLowerCase();
  return KNOWLEDGE_ARTICLES
    .filter(article => category === 'all' || article.category === category)
    .map(article => {
      const haystack = [article.title, article.summary, article.category, article.level, ...article.tags, ...article.commands, ...article.sections.flat()].join(' ').toLowerCase();
      const score = !needle ? 1 : (article.title.toLowerCase().includes(needle) ? 5 : 0) + (article.tags.some(tag => tag.toLowerCase().includes(needle)) ? 3 : 0) + (haystack.includes(needle) ? 1 : 0);
      return { article, score };
    })
    .filter(result => result.score > 0)
    .sort((a, b) => b.score - a.score || a.article.title.localeCompare(b.article.title))
    .map(result => result.article);
}
