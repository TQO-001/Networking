import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import ErrorBoundary from './ErrorBoundary.jsx';
import '@fontsource/google-sans/latin-400.css';
import '@fontsource/google-sans/latin-500.css';
import '@fontsource/google-sans/latin-600.css';
import '@fontsource/google-sans/latin-700.css';
import '@fontsource/google-sans/latin-ext-400.css';
import '@fontsource/google-sans/latin-ext-500.css';
import '@fontsource/google-sans/latin-ext-600.css';
import '@fontsource/google-sans/latin-ext-700.css';
import '@fontsource/google-sans-code/latin-400.css';
import '@fontsource/google-sans-code/latin-500.css';
import '@fontsource/google-sans-code/latin-ext-400.css';
import '@fontsource/google-sans-code/latin-ext-500.css';
import './ux-system.css';

createRoot(document.getElementById('root')).render(
  <React.StrictMode><ErrorBoundary><App /></ErrorBoundary></React.StrictMode>
);

if (import.meta.env.PROD && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {
      // Offline enhancement is optional; the app remains fully usable without it.
    });
  });
}
