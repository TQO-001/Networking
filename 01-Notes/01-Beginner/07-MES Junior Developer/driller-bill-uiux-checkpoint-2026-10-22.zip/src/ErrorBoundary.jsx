import React from 'react';
import { safeStorage } from './storage.js';

export default class ErrorBoundary extends React.Component {
  state = { hasError: false, errorId: null };

  static getDerivedStateFromError(error) {
    const seed = `${Date.now()}-${String(error?.message || 'ui').slice(0, 24)}`;
    return { hasError: true, errorId: seed };
  }

  componentDidCatch(error, info) {
    // Keep diagnostics local; do not expose the stack to the learner UI.
    try {
      safeStorage.setItem('pennyFarthing:last-ui-error', JSON.stringify({
        at: new Date().toISOString(),
        message: String(error?.message || 'Unknown UI error'),
        componentStack: String(info?.componentStack || ''),
      }));
    } catch {
      // Recovery must continue even when session storage is unavailable.
    }
  }

  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <main className="page" aria-live="assertive">
        <section className="panel empty-state" role="alert">
          <div className="kicker">APPLICATION RECOVERY</div>
          <strong>Driller Bill hit an unexpected UI error.</strong>
          <span>Your local study data has not been intentionally cleared.</span>
          <small className="muted">Recovery reference: {this.state.errorId || 'local-ui-error'}</small>
          <button type="button" className="button primary" onClick={() => window.location.reload()}>Reload workspace</button>
        </section>
      </main>
    );
  }
}
