import React, { useEffect, useMemo, useState } from 'react';
import { safeStorage, safeSessionStorage } from './storage.js';
import { buildDeviceInventory } from './core/device-model.js';
import { agentConnect, agentDiagnostics, agentDevices, agentExecute, agentHealth, agentInspect, DEVICE_AGENT_URL } from './core/device-agent-client.js';
import { buildDeviceDiagnostics } from './core/device-diagnostics.js';
import { inspectSimulatedDevice } from './core/device-inspection.js';
import { deriveShow } from './core/network-base.js';
import { injectLiveFault, resetLiveNetwork } from './core/live-network-engine.js';
import UnifiedWorkflowBar from './UnifiedWorkflowBar.jsx';
import { startWorkflow, workflowFromTroubleshooting } from './core/unified-workflows.js';
import { loadCustomTroubleshootingCases, analyzeTroubleshootingCase, evaluateEvidenceTest, remediationPlan, TROUBLESHOOTING_CASES, saveCustomTroubleshootingCases, validateTroubleshootingCase, normalizeTroubleshootingCase } from './core/troubleshooting.js';
import { useNetworkWorkspace } from './context/NetworkWorkspaceContext.jsx';

const AGENT_SETTINGS_KEY = 'drillerBill.deviceAgent.v48';
const CASE_FOCUS_KEY = 'drillerBill.troubleshooting.focus.v1';
const MODE_KEY = 'drillerBill.troubleshooting.mode.v1';

function Icon({ name, size = 16 }) {
  const paths = {
    search: <><circle cx="10.8" cy="10.8" r="6.5"/><path d="m16 16 4.2 4.2"/></>,
    play: <path d="M8 5l11 7-11 7V5z" fill="currentColor"/>,
    check: <path d="m5 12 4 4L19 6"/>,
    x: <><path d="m6 6 12 12"/><path d="m18 6-12 12"/></>,
    arrow: <><path d="M5 12h13"/><path d="m13 6 6 6-6 6"/></>,
    shield: <><path d="M12 3 19 6v5c0 4.3-2.5 7.8-7 10-4.5-2.2-7-5.7-7-10V6z"/><path d="m9 12 2 2 4-4"/></>,
    terminal: <><path d="m5 7 5 5-5 5"/><path d="M12 17h7"/></>,
    refresh: <><path d="M20 11a8 8 0 1 0 1 4"/><path d="M20 5v6h-6"/></>,
    book: <><path d="M5 5.5A2.5 2.5 0 0 1 7.5 3H19v17H7.5A2.5 2.5 0 0 0 5 22z"/><path d="M5 5.5v16"/></>,
    alert: <><path d="M12 4 21 20H3z"/><path d="M12 9v5"/><path d="M12 17.5h.01"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

function readAgentSettings() {
  try {
    const local = JSON.parse(safeStorage.getItem(AGENT_SETTINGS_KEY) || '{}');
    const session = JSON.parse(safeSessionStorage.getItem(AGENT_SETTINGS_KEY) || '{}');
    if (Object.hasOwn(local, 'token')) safeStorage.setItem(AGENT_SETTINGS_KEY, JSON.stringify({ url: local.url || '' }));
    return { url: local.url || '', token: session.token || '' };
  } catch { return {}; }
}

function statusClass(status) { return status === 'pass' ? 'pass' : status === 'fail' ? 'fail' : 'unknown'; }

const CASE_FAULTS = {
  'interface-down': 'interface-down',
  'vlan-trunk': 'trunk-vlan20',
  'static-route': 'static-route',
  'ospf-neighbor': 'ospf-adjacency',
};

export default function Troubleshooting({ setView }) {
  const { labState, setLabState } = useNetworkWorkspace();
  const [customCases, setCustomCases] = useState(() => loadCustomTroubleshootingCases(safeStorage));
  const allCases = useMemo(() => [...TROUBLESHOOTING_CASES, ...customCases], [customCases]);
  const [selectedId, setSelectedId] = useState(() => safeStorage.getItem(CASE_FOCUS_KEY) || allCases[0]?.id || '');
  const [mode, setMode] = useState(() => safeStorage.getItem(MODE_KEY) || 'simulation');
  const [agentUrl, setAgentUrl] = useState(() => readAgentSettings().url || DEVICE_AGENT_URL);
  const [agentToken, setAgentToken] = useState(() => readAgentSettings().token || '');
  const [agentState, setAgentState] = useState({ status: 'unknown', message: 'Not checked' });
  const [agentInventory, setAgentInventory] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState('');
  const [connected, setConnected] = useState(false);
  const [inspection, setInspection] = useState(null);
  const [diagnostics, setDiagnostics] = useState(null);
  const [testResults, setTestResults] = useState({});
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [selectedHypothesisId, setSelectedHypothesisId] = useState('');
  const [showBuilder, setShowBuilder] = useState(false);
  const [builder, setBuilder] = useState({ title: '', symptom: '', summary: '', targetKind: 'any', interface: 'Gi0/1', tags: '', hypothesis: '', rationale: '', command: 'show ip interface brief' });

  const workspaceDevices = useMemo(() => buildDeviceInventory(labState), [labState]);
  const devices = useMemo(() => {
    if (mode === 'live') return agentInventory;
    return workspaceDevices;
  }, [mode, agentInventory, workspaceDevices]);
  const caseData = allCases.find(item => item.id === selectedId) || allCases[0];
  const selectedDevice = devices.find(item => item.id === selectedDeviceId)
    || devices.find(item => item.id === caseData?.target?.preferredDevice)
    || devices.find(item => caseData?.targetKind === 'any' || item.kind === caseData?.targetKind)
    || devices[0];
  const analysis = useMemo(() => analyzeTroubleshootingCase(caseData || {}, { inspection, diagnostics, results: testResults }), [caseData, inspection, diagnostics, testResults]);
  const selectedHypothesis = analysis.hypotheses.find(item => item.id === selectedHypothesisId) || analysis.topHypothesis;
  const remediation = useMemo(() => remediationPlan(caseData, selectedHypothesis, selectedDevice), [caseData, selectedHypothesis, selectedDevice]);

  useEffect(() => { if (!allCases.some(item => item.id === selectedId)) setSelectedId(allCases[0]?.id || ''); }, [allCases, selectedId]);
  useEffect(() => { if (selectedId) safeStorage.setItem(CASE_FOCUS_KEY, selectedId); }, [selectedId]);
  useEffect(() => { safeStorage.setItem(MODE_KEY, mode); }, [mode]);
  useEffect(() => { setSelectedHypothesisId(''); setTestResults({}); setInspection(null); setDiagnostics(null); setMessage(''); }, [selectedId, mode]);
  useEffect(() => {
    const preferred = caseData?.target?.preferredDevice;
    const match = devices.find(device => device.id === preferred) || devices.find(device => caseData?.targetKind === 'any' || device.kind === caseData?.targetKind);
    if (match && (!selectedDeviceId || !devices.some(device => device.id === selectedDeviceId))) setSelectedDeviceId(match.id);
  }, [caseData?.id, caseData?.targetKind, caseData?.target?.preferredDevice, devices, selectedDeviceId]);

  const selectCase = id => setSelectedId(id);

  const inspectTarget = async () => {
    if (!selectedDevice?.id) return null;
    setBusy(true);
    try {
      if (mode === 'simulation') {
        const report = inspectSimulatedDevice(labState, selectedDevice.id);
        const localDiagnostics = buildDeviceDiagnostics({ device: selectedDevice, inspection: report, connected: true });
        setInspection(report);
        setDiagnostics(localDiagnostics);
        setMessage(`Observed ${selectedDevice.id} from the shared simulation state.`);
        return report;
      }
      if (!agentToken) throw new Error('Enter the Device Agent token before inspecting a live device.');
      const result = await agentInspect(selectedDevice.id, { baseUrl: agentUrl, token: agentToken });
      const diag = await agentDiagnostics(selectedDevice.id, { baseUrl: agentUrl, token: agentToken });
      setInspection(result.report || null);
      setDiagnostics(diag.diagnostics || null);
      setMessage('Fresh evidence captured from the live device.');
      return result.report || null;
    } catch (error) {
      setMessage(error.message);
      return null;
    } finally { setBusy(false); }
  };

  const refreshLiveDevices = async () => {
    if (!agentToken) { setAgentState({ status: 'locked', message: 'Enter the Device Agent token.' }); return; }
    setBusy(true);
    try {
      const health = await agentHealth({ baseUrl: agentUrl });
      const result = await agentDevices({ baseUrl: agentUrl, token: agentToken });
      setAgentInventory(result.devices || []);
      setAgentState({ status: 'ready', message: `${result.devices?.length || 0} live device${result.devices?.length === 1 ? '' : 's'} available · ${health.protocol || 'agent'}` });
      safeStorage.setItem(AGENT_SETTINGS_KEY, JSON.stringify({ url: agentUrl })); safeSessionStorage.setItem(AGENT_SETTINGS_KEY, JSON.stringify({ token: agentToken }));
      if (result.devices?.[0] && !selectedDeviceId) setSelectedDeviceId(result.devices[0].id);
    } catch (error) { setAgentState({ status: 'error', message: error.message }); }
    finally { setBusy(false); }
  };

  const connectLive = async () => {
    if (!selectedDevice?.id || !agentToken) return;
    setBusy(true);
    try {
      const result = await agentConnect(selectedDevice.id, { baseUrl: agentUrl, token: agentToken });
      setConnected(true);
      setAgentInventory(current => current.map(item => item.id === selectedDevice.id ? result.result.device : item));
      setMessage(`${selectedDevice.id} connected. Troubleshooting tests remain evidence-only until you choose a remediation.`);
    } catch (error) { setConnected(false); setMessage(error.message); }
    finally { setBusy(false); }
  };

  const runTest = async (test) => {
    if (!selectedDevice?.id || busy) return;
    setBusy(true);
    try {
      let nextInspection = inspection;
      let result;
      if (mode === 'simulation') {
        nextInspection = inspectSimulatedDevice(labState, selectedDevice.id);
        setInspection(nextInspection);
        const output = test.kind === 'command' ? (deriveShow(labState, selectedDevice.id, test.command) || '') : '';
        result = evaluateEvidenceTest(test, {
          inspection: nextInspection,
          diagnostics: buildDeviceDiagnostics({ device: selectedDevice, inspection: nextInspection, connected: true }),
          commandResult: { output },
          caseData,
        });
        setDiagnostics(buildDeviceDiagnostics({ device: selectedDevice, inspection: nextInspection, connected: true }));
      } else {
        if (!connected || !agentToken) throw new Error('Connect the live device before running an evidence test.');
        if (test.kind === 'command') {
          const response = await agentExecute(selectedDevice.id, test.command, { baseUrl: agentUrl, token: agentToken });
          result = evaluateEvidenceTest(test, { inspection, diagnostics, commandResult: response.result, caseData });
        } else {
          nextInspection = await inspectTarget();
          result = evaluateEvidenceTest(test, { inspection: nextInspection, diagnostics, caseData });
        }
      }
      setTestResults(current => ({ ...current, [test.id]: result }));
      setSelectedHypothesisId(analysis.topHypothesis?.id || selectedHypothesisId);
      setMessage(`${test.label}: ${result.status.toUpperCase()} · ${result.detail}`);
    } catch (error) { setMessage(error.message); }
    finally { setBusy(false); }
  };

  const loadFault = () => {
    if (mode !== 'simulation') return;
    const faultId = CASE_FAULTS[caseData?.id];
    if (!faultId) { setMessage('This case has no built-in fault injector. Start with the current shared lab state.'); return; }
    setLabState(current => injectLiveFault(current, faultId));
    setInspection(null); setDiagnostics(null); setTestResults({});
    setMessage(`Loaded the local lab fault for “${caseData.title}”. Evidence is now intentionally degraded.`);
  };

  const resetSimulation = () => {
    if (mode !== 'simulation') return;
    setLabState(resetLiveNetwork());
    setInspection(null); setDiagnostics(null); setTestResults({}); setMessage('Shared simulation restored to a healthy baseline.');
  };

  const saveBuilder = () => {
    const draft = normalizeTroubleshootingCase({
      id: `custom-${Date.now()}`,
      title: builder.title,
      summary: builder.summary,
      symptom: builder.symptom,
      targetKind: builder.targetKind,
      tags: builder.tags.split(',').map(v => v.trim()).filter(Boolean),
      knowledge: ['troubleshooting'],
      target: { interface: builder.interface },
      hypotheses: [{ id: 'primary', title: builder.hypothesis, rationale: builder.rationale, remediation: null }],
      tests: [{ id: 'primary-test', label: 'Collect primary evidence', command: builder.command, kind: builder.command.startsWith('show ') ? 'command' : 'inspection' }],
      source: 'custom',
    });
    if (!validateTroubleshootingCase(draft).valid) return;
    const next = [...customCases, draft];
    const saved = saveCustomTroubleshootingCases(safeStorage, next);
    setCustomCases(saved);
    setSelectedId(draft.id);
    setShowBuilder(false);
    setBuilder({ title: '', symptom: '', summary: '', targetKind: 'any', interface: 'Gi0/1', tags: '', hypothesis: '', rationale: '', command: 'show ip interface brief' });
    setMessage(`Saved “${draft.title}” locally. It is now available as a reusable case.`);
  };

  const deleteCase = () => {
    if (caseData?.source !== 'custom') return;
    const next = customCases.filter(item => item.id !== caseData.id);
    saveCustomTroubleshootingCases(safeStorage, next);
    setCustomCases(next);
    setSelectedId(TROUBLESHOOTING_CASES[0]?.id || '');
  };

  if (!caseData) return <main className="page troubleshooting-page"><UnifiedWorkflowBar view="troubleshooting" setView={setView}/><section className="panel troubleshooting-empty"><h1>No troubleshooting cases</h1><p>Add a custom case to start building an evidence-driven workflow.</p></section></main>;

  const evidenceCount = Object.keys(testResults).length;
  const passedTests = Object.values(testResults).filter(item => item.status === 'pass').length;

  return <main className="page troubleshooting-page"><UnifiedWorkflowBar view="troubleshooting" setView={setView}/>
    <section className="troubleshooting-hero">
      <div>
        <div className="eyebrow">ENGINEERING / TROUBLESHOOTING</div>
        <h1>Find the fault.<br/><span>Prove the fix.</span></h1>
        <p>Turn a vague network symptom into a bounded fault domain using observed evidence, explicit hypotheses, targeted tests and a reviewed remediation path.</p>
      </div>
      <div className="troubleshooting-hero-stats">
        <div><strong>{allCases.length}</strong><span>cases</span><small>{customCases.length} custom</small></div>
        <div><strong>{passedTests}/{evidenceCount || 0}</strong><span>tests passed</span><small>current case</small></div>
        <div><strong>{analysis.confidence}%</strong><span>top confidence</span><small>{analysis.readyForRemediation ? 'remediation candidate' : 'keep testing'}</small></div>
      </div>
    </section>

    <section className="troubleshooting-modebar panel">
      <div className="troubleshooting-modecopy"><span className="kicker">EVIDENCE SOURCE</span><strong>{mode === 'simulation' ? 'Shared simulation' : 'Physical / live device'}</strong><small>{mode === 'simulation' ? 'Safe local fault injection and deterministic device state.' : 'Read-only inspection and approved evidence commands through the local Device Agent.'}</small></div>
      <div className="troubleshooting-mode-actions"><button className={mode === 'simulation' ? 'button active' : 'button'} onClick={() => setMode('simulation')}>Simulation</button><button className={mode === 'live' ? 'button active' : 'button'} onClick={() => setMode('live')}>Live device</button>{mode === 'simulation' ? <><button className="button" onClick={loadFault}><Icon name="alert" size={12}/> Load case fault</button><button className="button" onClick={resetSimulation}><Icon name="refresh" size={12}/> Reset lab</button></> : <button className="button" onClick={refreshLiveDevices} disabled={busy}>Refresh agent</button>}</div>
    </section>

    <div className="troubleshooting-layout">
      <aside className="troubleshooting-index panel">
        <div className="panel-head"><div><div className="kicker">CASE LIBRARY</div><h2>{allCases.length} procedures</h2></div><button className="text-button" onClick={() => setShowBuilder(value => !value)}>+ NEW</button></div>
        <div className="troubleshooting-case-list">{allCases.map(item => <button key={item.id} className={`troubleshooting-case ${selectedId === item.id ? 'selected' : ''}`} onClick={() => selectCase(item.id)}><span>{item.scope}</span><div><strong>{item.title}</strong><small>{item.summary}</small></div><b>{item.difficulty}</b></button>)}</div>
      </aside>

      <section className="troubleshooting-main">
        <header className="panel troubleshooting-case-head">
          <div><span className="troubleshooting-case-label">{caseData.category.toUpperCase()} · {caseData.difficulty} · {caseData.scope}</span><h2>{caseData.title}</h2><p>{caseData.summary}</p><div className="troubleshooting-tags">{(caseData.tags || []).map(tag => <span key={tag}>#{tag}</span>)}</div></div>
          <div className="troubleshooting-case-actions"><button className="button" onClick={() => { startWorkflow(safeStorage, workflowFromTroubleshooting(caseData, { target: selectedDevice ? { type: 'device', id: selectedDevice.id } : null })); setView?.('workflows'); }}>Start recovery thread <Icon name="arrow" size={11}/></button>{caseData.source === 'custom' && <button className="button danger" onClick={deleteCase}><Icon name="x" size={12}/> Delete case</button>}</div>
        </header>

        <section className="panel troubleshooting-symptom">
          <div className="troubleshooting-section-head"><div><div className="kicker">01 / SYMPTOM</div><h3>What exactly is failing?</h3></div><span>{caseData.targetKind.toUpperCase()}</span></div>
          <div className="symptom-card"><div className="symptom-mark"><Icon name="alert" size={19}/></div><div><strong>{caseData.symptom}</strong><small>Target: {selectedDevice?.id || 'not selected'}{caseData.target?.interface ? ` · ${caseData.target.interface}` : ''}{caseData.target?.network ? ` · ${caseData.target.network}` : ''}</small></div></div>
        </section>

        <section className="panel troubleshooting-target">
          <div className="troubleshooting-section-head"><div><div className="kicker">02 / EVIDENCE TARGET</div><h3>Choose the device and collect a baseline.</h3></div><span className={`troubleshooting-agent ${mode === 'simulation' ? 'ready' : agentState.status}`}>{mode === 'simulation' ? 'SIMULATION' : agentState.status.toUpperCase()}</span></div>
          <div className="troubleshooting-target-grid"><label><span>DEVICE</span><select value={selectedDevice?.id || ''} onChange={event => { setSelectedDeviceId(event.target.value); setInspection(null); setDiagnostics(null); setTestResults({}); setConnected(false); }}>{devices.map(device => <option key={device.id} value={device.id}>{device.id} · {device.kind}</option>)}</select></label>{mode === 'live' && <><label><span>AGENT URL</span><input value={agentUrl} onChange={event => setAgentUrl(event.target.value)} /></label><label><span>AGENT TOKEN</span><input value={agentToken} onChange={event => setAgentToken(event.target.value)} type="password" /></label></>} </div>
          <div className="troubleshooting-target-actions"><button className="button primary" onClick={inspectTarget} disabled={busy || !selectedDevice}>{busy ? 'Collecting…' : 'Inspect device'}</button>{mode === 'live' && <button className="button" onClick={connectLive} disabled={busy || !agentToken || !selectedDevice}>{connected ? 'Connected' : 'Connect'}</button>}<div className="troubleshooting-connection"><i className={mode === 'simulation' || connected ? 'on' : ''}/>{mode === 'simulation' ? 'Local evidence source' : connected ? `Live session · ${selectedDevice?.id}` : 'No live session'}</div></div>
        </section>

        <section className="troubleshooting-evidence-grid">
          <section className="panel troubleshooting-observed">
            <div className="troubleshooting-section-head"><div><div className="kicker">03 / OBSERVATIONS</div><h3>Observed state</h3></div><span>{analysis.evidence.length} signals</span></div>
            <div className="troubleshooting-evidence-list">{analysis.evidence.length ? analysis.evidence.map((item, index) => <div key={`${item.label}-${index}`} className={`troubleshooting-evidence-item ${item.severity}`}><span>{item.label}</span><strong>{item.value}</strong></div>) : <div className="troubleshooting-empty-inline">Inspect the target or run an evidence test. Nothing is being inferred from the symptom alone.</div>}</div>
            {diagnostics && <div className="troubleshooting-health"><span>DEVICE HEALTH</span><strong>{diagnostics.score}/100 · {diagnostics.status.toUpperCase()}</strong><small>{diagnostics.warnings} warnings · {diagnostics.attention} attention signals</small></div>}
          </section>

          <section className="panel troubleshooting-tests">
            <div className="troubleshooting-section-head"><div><div className="kicker">04 / TESTS</div><h3>Test one hypothesis at a time.</h3></div><span>{evidenceCount}/{caseData.tests.length}</span></div>
            <div className="troubleshooting-test-list">{caseData.tests.map(test => { const result = testResults[test.id]; return <div className={`troubleshooting-test ${result ? result.status : ''}`} key={test.id}><div><strong>{test.label}</strong><code>{test.command || 'structured inspection'}</code><small>{result?.detail || 'Not run yet.'}</small></div><button className="button" onClick={() => runTest(test)} disabled={busy || (mode === 'live' && !connected)}>{result ? 'Run again' : 'Run test'}</button></div>; })}</div>
          </section>
        </section>

        <section className="panel troubleshooting-hypotheses">
          <div className="troubleshooting-section-head"><div><div className="kicker">05 / HYPOTHESES</div><h3>Ranked fault theories</h3></div><span>{analysis.readyForRemediation ? 'ACTIONABLE' : 'INVESTIGATE'}</span></div>
          <div className="hypothesis-grid">{analysis.hypotheses.map(item => <button key={item.id} className={`hypothesis-card ${selectedHypothesis?.id === item.id ? 'selected' : ''}`} onClick={() => setSelectedHypothesisId(item.id)}><div className="hypothesis-score"><strong>{item.confidence}</strong><span>%</span></div><div><strong>{item.title}</strong><p>{item.rationale}</p></div><span className="hypothesis-indicator">{item.confidence >= 75 ? 'LIKELY' : item.confidence >= 40 ? 'POSSIBLE' : 'LOW'}</span></button>)}</div>
        </section>

        <section className="panel troubleshooting-resolution">
          <div className="troubleshooting-section-head"><div><div className="kicker">06 / REMEDIATION</div><h3>{selectedHypothesis?.title || 'Select a hypothesis'}</h3></div><span>{remediation.valid ? 'TYPED INTENT' : 'NO AUTO-FIX'}</span></div>
          <p>{selectedHypothesis?.rationale || 'Choose a hypothesis after collecting evidence.'}</p>
          {remediation.valid ? <><div className="troubleshooting-remediation-plan"><div><span>PROPOSED CHANGE</span><strong>{remediation.commands.length} commands</strong></div>{remediation.commands.map((command, index) => <code key={`${command}-${index}`}>{command}</code>)}</div><div className="troubleshooting-resolution-actions"><button className="button" onClick={() => setMessage('Remediation is prepared as a typed intent. Open Configuration to review/apply it with the normal Preview → Apply → Verify controls.')}><Icon name="shield" size={12}/> Prepare change</button><button className="button" onClick={() => { safeStorage.setItem('drillerBill.runbooks.focus.v1', caseData.id === 'static-route' ? 'routed-edge-recovery' : caseData.id === 'vlan-trunk' ? 'trunk-standardization' : 'access-switch-baseline'); setView?.('runbooks'); }}>Open runbook path <Icon name="arrow" size={11}/></button></div></> : <div className="troubleshooting-no-fix"><Icon name="shield" size={14}/><span>This hypothesis has no deterministic auto-remediation. Keep collecting evidence and document the manual change path rather than guessing a command.</span></div>}
          {message && <div className="troubleshooting-message">{message}</div>}
        </section>

        {showBuilder && <section className="panel troubleshooting-builder">
          <div className="troubleshooting-section-head"><div><div className="kicker">07 / AUTHORING</div><h3>Create a reusable troubleshooting case</h3></div><span>LOCAL</span></div>
          <div className="troubleshooting-builder-grid">
            <label><span>TITLE</span><input value={builder.title} onChange={e => setBuilder(v => ({ ...v, title: e.target.value }))} placeholder="Branch uplink investigation" /></label>
            <label><span>TARGET</span><select value={builder.targetKind} onChange={e => setBuilder(v => ({ ...v, targetKind: e.target.value }))}><option value="any">Any device</option><option value="switch">Switch</option><option value="router">Router</option></select></label>
            <label><span>INTERFACE</span><input value={builder.interface} onChange={e => setBuilder(v => ({ ...v, interface: e.target.value }))} placeholder="Gi0/1" /></label>
            <label className="wide"><span>SYMPTOM</span><input value={builder.symptom} onChange={e => setBuilder(v => ({ ...v, symptom: e.target.value }))} placeholder="Users cannot reach the upstream service." /></label>
            <label className="wide"><span>SUMMARY</span><input value={builder.summary} onChange={e => setBuilder(v => ({ ...v, summary: e.target.value }))} placeholder="Describe the investigation outcome." /></label>
            <label><span>HYPOTHESIS</span><input value={builder.hypothesis} onChange={e => setBuilder(v => ({ ...v, hypothesis: e.target.value }))} placeholder="Transit interface is unavailable" /></label>
            <label><span>TEST COMMAND</span><input value={builder.command} onChange={e => setBuilder(v => ({ ...v, command: e.target.value }))} placeholder="show ip interface brief" /></label>
            <label className="wide"><span>RATIONALE</span><input value={builder.rationale} onChange={e => setBuilder(v => ({ ...v, rationale: e.target.value }))} placeholder="Explain why this hypothesis is plausible." /></label>
            <label className="wide"><span>TAGS</span><input value={builder.tags} onChange={e => setBuilder(v => ({ ...v, tags: e.target.value }))} placeholder="uplink, routing, interface" /></label>
          </div>
          <div className="troubleshooting-builder-footer"><span>Custom cases are stored in this browser only. This feature writes no credentials.</span><button className="button primary" disabled={!builder.title.trim() || !builder.symptom.trim() || !builder.hypothesis.trim() || !builder.command.trim()} onClick={saveBuilder}>Save case</button></div>
        </section>}
      </section>
    </div>
  </main>;
}
