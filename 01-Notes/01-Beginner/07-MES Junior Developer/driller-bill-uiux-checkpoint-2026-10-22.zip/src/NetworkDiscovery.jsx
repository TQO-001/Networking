import React, { useMemo, useState } from 'react';
import { useNetworkWorkspace } from './context/NetworkWorkspaceContext.jsx';
import { safeStorage, safeSessionStorage } from './storage.js';
import { agentConnect, agentDiscover, agentDevices, agentHealth, agentDiscovery, DEVICE_AGENT_URL } from './core/device-agent-client.js';
import { buildDiscoveryGraph, reconcileDiscoveryTopology, summarizeDiscoveryRun } from './core/network-discovery.js';

const SETTINGS_KEY = 'drillerBill.deviceAgent.v48';
const DISCOVERY_KEY = 'drillerBill.networkDiscovery.v61';

function settings() {
  try {
    const local = JSON.parse(safeStorage.getItem(SETTINGS_KEY) || '{}');
    const session = JSON.parse(safeSessionStorage.getItem(SETTINGS_KEY) || '{}');
    if (Object.hasOwn(local, 'token')) safeStorage.setItem(SETTINGS_KEY, JSON.stringify({ url: local.url || '' }));
    return { url: local.url || '', token: session.token || '' };
  } catch { return {}; }
}

function loadSaved() {
  try { return JSON.parse(safeStorage.getItem(DISCOVERY_KEY) || '{}'); } catch { return {}; }
}

function saveDiscovery(run) {
  safeStorage.setItem(DISCOVERY_KEY, JSON.stringify(run));
}

function Pill({ children, tone='' }) { return <span className={`nd-pill ${tone}`}>{children}</span>; }

export default function NetworkDiscovery() {
  const { topology, setTopology } = useNetworkWorkspace();
  const [agentUrl] = useState(() => settings().url || DEVICE_AGENT_URL);
  const [token] = useState(() => settings().token || '');
  const [inventory, setInventory] = useState([]);
  const [selected, setSelected] = useState([]);
  const [run, setRun] = useState(loadSaved);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [expanded, setExpanded] = useState('');

  const graph = useMemo(() => run?.graph || buildDiscoveryGraph(run?.reports || [], inventory), [run, inventory]);
  const preview = useMemo(() => topology && run?.reports?.length ? reconcileDiscoveryTopology(topology, { ...run, graph }, { inventory }) : null, [topology, run, graph, inventory]);
  const reportMap = useMemo(() => new Map((run?.reports || []).map(report => [report.deviceId, report])), [run]);

  const refresh = async () => {
    setBusy(true); setMessage('');
    try {
      await agentHealth({ baseUrl: agentUrl });
      const result = await agentDevices({ baseUrl: agentUrl, token });
      setInventory(result.devices || []);
      if (!selected.length) setSelected((result.devices || []).filter(device => device.connection?.status === 'connected' || device.connection?.type === 'simulated').map(device => device.id));
      setMessage(`Agent inventory loaded: ${result.devices?.length || 0} devices.`);
    } catch (error) { setMessage(error.message); }
    finally { setBusy(false); }
  };

  const discover = async () => {
    const ids = selected.length ? selected : inventory.map(device => device.id);
    if (!ids.length) return setMessage('Select at least one device or refresh the Device Agent inventory.');
    setBusy(true); setMessage('Running read-only CDP / LLDP discovery…');
    const reports = [];
    const failures = [];
    try {
      for (const deviceId of ids) {
        let device = inventory.find(item => item.id === deviceId);
        if (!device) continue;
        if (device.connection?.status !== 'connected') {
          try {
            const connected = await agentConnect(deviceId, { baseUrl: agentUrl, token });
            device = connected.result?.device || device;
          } catch (error) {
            failures.push(`${device.name}: ${error.message}`);
            continue;
          }
        }
        try {
          const result = await agentDiscover(deviceId, { baseUrl: agentUrl, token });
          reports.push(result.report);
        } catch (error) {
          failures.push(`${device.name}: ${error.message}`);
        }
      }
      const next = { version: '1.0.0', runAt: new Date().toISOString(), reports, inventory, graph: buildDiscoveryGraph(reports, inventory), changes: null };
      const reconciled = reconcileDiscoveryTopology(topology, next, { inventory });
      next.graph = reconciled.graph;
      next.changes = reconciled.changes;
      setRun(next); saveDiscovery(next);
      setMessage(`${summarizeDiscoveryRun(next)}${failures.length ? ` ${failures.length} device${failures.length === 1 ? '' : 's'} failed.` : ''}`);
    } catch (error) { setMessage(error.message); }
    finally { setBusy(false); }
  };

  const syncTopology = () => {
    if (!preview) return;
    setTopology(preview.topology);
    const next = { ...run, changes: preview.changes, syncedAt: new Date().toISOString() };
    setRun(next); saveDiscovery(next);
    setMessage(`Topology synchronized: +${preview.changes.addedDevices.length} devices, +${preview.changes.addedLinks.length} links. Existing links are never deleted automatically.`);
  };

  const toggle = id => setSelected(current => current.includes(id) ? current.filter(x => x !== id) : [...current, id]);

  return <div className="nd-shell">
    <header className="nd-topbar">
      <div><span className="nd-eyebrow">NETWORK OPERATIONS / 06</span><h1>Discovery <em>& topology sync.</em></h1><p>Read the network as it exists, compare it with the design model, and bring confirmed relationships into Driller Bill without silently deleting anything.</p></div>
      <div className="nd-actions"><button className="button" onClick={refresh} disabled={busy}>Refresh agent</button><button className="button primary" onClick={discover} disabled={busy}>{busy ? 'Discovering…' : 'Discover network'}</button></div>
    </header>

    <main className="nd-page">
      <section className="nd-metrics">
        <div><span>Agent devices</span><strong>{inventory.length}</strong></div>
        <div><span>Selected</span><strong>{selected.length}</strong></div>
        <div><span>Discovered nodes</span><strong>{graph.nodes.length}</strong></div>
        <div><span>Observed links</span><strong>{graph.edges.length}</strong></div>
        <div><span>Topology drift</span><strong className={preview?.changes?.drift?.length ? 'warn' : 'good'}>{preview?.changes?.drift?.length || 0}</strong></div>
      </section>

      {message && <div className="nd-message">{message}</div>}

      <div className="nd-grid">
        <section className="panel nd-device-panel">
          <div className="panel-head"><div><div className="kicker">01 / TARGETS</div><h2>Devices to discover</h2></div><span className="panel-micro">READ ONLY</span></div>
          <div className="nd-device-list">
            {inventory.length === 0 && <div className="empty-state"><strong>No agent inventory loaded.</strong><span>Refresh the local Device Agent to see simulated and registered SSH/serial devices.</span></div>}
            {inventory.map(device => {
              const checked = selected.includes(device.id);
              const report = reportMap.get(device.id);
              return <button key={device.id} className={`nd-device-row ${checked ? 'selected' : ''}`} onClick={() => toggle(device.id)}>
                <span className="nd-checkbox">{checked ? '✓' : ''}</span>
                <div><strong>{device.name}</strong><span>{device.kind} · {device.connection?.type || 'simulated'} · {device.connection?.status || 'ready'}</span></div>
                <div className="nd-device-meta">{report ? <Pill tone="good">{report.counts.unique} links</Pill> : <Pill>not discovered</Pill>}</div>
              </button>;
            })}
          </div>
        </section>

        <section className="panel nd-graph-panel">
          <div className="panel-head"><div><div className="kicker">02 / OBSERVATIONS</div><h2>Discovered relationships</h2></div><span className="panel-micro">CDP + LLDP</span></div>
          <div className="nd-edge-list">
            {graph.edges.length === 0 && <div className="empty-state"><strong>No relationships discovered yet.</strong><span>Run a read-only discovery scan against one or more connected devices.</span></div>}
            {graph.edges.map(edge => {
              const a = graph.nodes.find(node => node.id === edge.a);
              const b = graph.nodes.find(node => node.id === edge.b);
              return <div className="nd-edge-row" key={edge.id}>
                <div className="nd-edge-main"><strong>{a?.name || edge.a}</strong><span>{edge.ai}</span><i>↔</i><strong>{b?.name || edge.b}</strong><span>{edge.bi}</span></div>
                <div className="nd-edge-meta"><Pill tone={edge.protocol === 'cdp' ? 'good' : ''}>{(edge.protocols || [edge.protocol]).join(' + ').toUpperCase()}</Pill><small>{edge.evidence?.length || 1} observation{edge.evidence?.length === 1 ? '' : 's'}</small></div>
              </div>;
            })}
          </div>
        </section>

        <section className="panel nd-sync-panel">
          <div className="panel-head"><div><div className="kicker">03 / TOPOLOGY RECONCILIATION</div><h2>Review before sync</h2></div><span className={`nd-status ${preview?.changes?.drift?.length ? 'warn' : 'good'}`}>{preview ? (preview.changes.drift.length ? 'DRIFT' : 'CLEAN') : 'IDLE'}</span></div>
          {!preview ? <div className="empty-state"><strong>Nothing to reconcile.</strong><span>Discovery results will be compared with your current topology design here.</span></div> : <>
            <div className="nd-change-summary"><div><span>New devices</span><strong>{preview.changes.addedDevices.length}</strong></div><div><span>New links</span><strong>{preview.changes.addedLinks.length}</strong></div><div><span>Confirmed</span><strong>{preview.changes.confirmedLinks.length}</strong></div><div><span>Drift</span><strong className={preview.changes.drift.length ? 'warn' : 'good'}>{preview.changes.drift.length}</strong></div></div>
            <div className="nd-review-list">
              {preview.changes.addedDevices.map(name => <div key={`d-${name}`} className="nd-review-row"><b>DEVICE</b><span>Discovered {name} is not in the current topology.</span><Pill tone="good">ADD</Pill></div>)}
              {preview.changes.addedLinks.map(id => <div key={`l-${id}`} className="nd-review-row"><b>LINK</b><span>{id.replace(/^disc-link-/, '').replace(/-/g, ' ')}</span><Pill tone="good">ADD</Pill></div>)}
              {preview.changes.confirmedLinks.map(id => <div key={`c-${id}`} className="nd-review-row"><b>LINK</b><span>Existing topology link {id} was independently observed.</span><Pill tone="good">CONFIRMED</Pill></div>)}
              {preview.changes.drift.map(item => <div key={`x-${item.linkId}`} className="nd-review-row"><b>DRIFT</b><span>{item.message}</span><Pill tone="warn">REVIEW</Pill></div>)}
            </div>
            <div className="nd-sync-foot"><span>Discovery never removes topology objects automatically.</span><button className="button primary" onClick={syncTopology} disabled={!preview.changes.addedDevices.length && !preview.changes.addedLinks.length}>Sync confirmed map</button></div>
          </>}
        </section>

        <section className="panel nd-reports-panel">
          <div className="panel-head"><div><div className="kicker">04 / DEVICE EVIDENCE</div><h2>Discovery reports</h2></div><span className="panel-micro">PERSISTED LOCALLY</span></div>
          {(run?.reports || []).map(report => <div key={report.deviceId} className="nd-report-row"><button onClick={() => setExpanded(expanded === report.deviceId ? '' : report.deviceId)}><div><strong>{report.deviceName}</strong><span>{report.counts.unique} unique neighbor links · {new Date(report.inspectedAt).toLocaleString()}</span></div><span>{expanded === report.deviceId ? '−' : '+'}</span></button>{expanded === report.deviceId && <div className="nd-report-detail"><div className="nd-report-tags"><Pill>{report.counts.cdp} CDP</Pill><Pill>{report.counts.lldp} LLDP</Pill></div>{report.observations.map((obs, index) => <div key={index}><b>{obs.remoteName}</b><span>{obs.localInterface} ↔ {obs.remoteInterface}</span><small>{obs.protocol.toUpperCase()} · {obs.platform} · {obs.capability || 'capability unknown'}</small></div>)}</div>}</div>)}
          {!run?.reports?.length && <div className="empty-state"><strong>No saved reports.</strong><span>Discovery results are kept locally so you can close the workspace and review them later.</span></div>}
        </section>
      </div>
    </main>
  </div>;
}
