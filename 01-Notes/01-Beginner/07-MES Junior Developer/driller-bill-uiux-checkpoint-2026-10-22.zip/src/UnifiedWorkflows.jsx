import React, { useMemo, useState } from 'react';
import { safeStorage } from './storage.js';
import { KNOWLEDGE_ARTICLES } from './knowledge/knowledge-base.js';
import { TROUBLESHOOTING_CASES } from './core/troubleshooting.js';
import { buildDeviceInventory } from './core/device-model.js';
import { useNetworkWorkspace } from './context/NetworkWorkspaceContext.jsx';
import {
  WORKFLOW_TEMPLATES,
  UNIFIED_WORKFLOW_VERSION,
  addWorkflowNote,
  abandonWorkflow,
  activateWorkflowStage,
  buildWorkflowContext,
  completeWorkflowStage,
  getActiveWorkflow,
  loadWorkflowStore,
  progressForWorkflow,
  saveWorkflowStore,
  stageDefinition,
  startWorkflow,
  updateWorkflow,
  workflowFromKnowledge,
  workflowFromTroubleshooting,
  workflowFromTwin,
} from './core/unified-workflows.js';

function Icon({ name, size = 16 }) {
  const paths = {
    route: <><circle cx="5" cy="5" r="2.2"/><circle cx="19" cy="19" r="2.2"/><path d="M7 5h6a6 6 0 0 1 6 6v6"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    arrow: <><path d="M5 12h13"/><path d="m13 6 6 6-6 6"/></>,
    x: <><path d="m6 6 12 12"/><path d="m18 6-12 12"/></>,
    plus: <><path d="M12 5v14"/><path d="M5 12h14"/></>,
    brain: <><path d="M9.5 4a3.5 3.5 0 0 0-3.2 4.9A3.5 3.5 0 0 0 5 15.5 3.5 3.5 0 0 0 9.5 19H10V4z"/><path d="M14.5 4a3.5 3.5 0 0 1 3.2 4.9A3.5 3.5 0 0 1 19 15.5a3.5 3.5 0 0 1-4.5 3.5H14V4z"/><path d="M10 8h4M10 12h4M10 16h4"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

function openView(setView, view) {
  setView?.(view);
}

function WorkflowStageCard({ stage, index, total, active, onOpen, onComplete }) {
  const definition = stageDefinition(stage.id);
  return <article className={`unified-stage-card ${stage.status} ${active ? 'active' : ''}`}>
    <div className="unified-stage-index">0{index + 1}</div>
    <div className="unified-stage-main">
      <div className="unified-stage-kicker">{stage.status === 'complete' ? 'COMPLETE' : active ? 'CURRENT' : stage.status.toUpperCase()}</div>
      <h3>{definition?.label || stage.id}</h3>
      <p>{definition?.description || ''}</p>
      {stage.note && <small>{stage.note}</small>}
    </div>
    <div className="unified-stage-actions">
      {stage.status !== 'complete' && definition?.view && <button className="button" onClick={() => onOpen(stage.id)}>{active ? 'Open' : 'Prepare'} <Icon name="arrow" size={11}/></button>}
      {stage.status !== 'complete' && active && <button className="button primary" onClick={() => onComplete(stage.id)}><Icon name="check" size={11}/> Complete</button>}
      {stage.status === 'complete' && <span className="unified-stage-done"><Icon name="check" size={12}/> verified</span>}
    </div>
  </article>;
}

export default function UnifiedWorkflows({ setView }) {
  const { labState } = useNetworkWorkspace();
  const devices = useMemo(() => buildDeviceInventory(labState), [labState]);
  const [active, setActive] = useState(() => getActiveWorkflow(safeStorage));
  const [history, setHistory] = useState(() => loadWorkflowStore(safeStorage).history.slice().reverse());
  const [templateId, setTemplateId] = useState('engineering-case');
  const [title, setTitle] = useState('');
  const [selectedArticle, setSelectedArticle] = useState('vlan');
  const [selectedCase, setSelectedCase] = useState(TROUBLESHOOTING_CASES[0]?.id || '');
  const [deviceId, setDeviceId] = useState(devices[0]?.id || '');
  const [note, setNote] = useState('');
  const [message, setMessage] = useState('');

  const progress = progressForWorkflow(active);
  const context = useMemo(() => buildWorkflowContext(active), [active]);

  const refresh = () => {
    const store = loadWorkflowStore(safeStorage);
    setActive(store.active);
    setHistory(store.history.slice().reverse());
  };

  const createFromTemplate = () => {
    const template = WORKFLOW_TEMPLATES[templateId];
    const workflow = startWorkflow(safeStorage, {
      templateId,
      title: title.trim() || template.title,
      target: deviceId ? { type: 'device', id: deviceId } : null,
    });
    setActive(workflow);
    setMessage(`Started ${workflow.title}.`);
    setTitle('');
  };

  const createFromArticle = () => {
    const article = KNOWLEDGE_ARTICLES.find(item => item.id === selectedArticle);
    if (!article) return;
    const workflow = startWorkflow(safeStorage, workflowFromKnowledge(article, { target: { type: 'device', id: deviceId } }));
    setActive(workflow);
    setMessage(`Started a workflow from ${article.title}.`);
  };

  const createFromCase = () => {
    const caseData = TROUBLESHOOTING_CASES.find(item => item.id === selectedCase);
    if (!caseData) return;
    const workflow = startWorkflow(safeStorage, workflowFromTroubleshooting(caseData, { target: { type: 'device', id: deviceId } }));
    setActive(workflow);
    setMessage(`Started a recovery workflow from ${caseData.title}.`);
  };

  const openStage = (stageId) => {
    const definition = stageDefinition(stageId);
    if (!definition || !active) return;
    activateWorkflowStage(safeStorage, stageId);
    refresh();
    openView(setView, definition.view);
  };

  const completeStage = (stageId) => {
    completeWorkflowStage(safeStorage, stageId, { note: note.trim(), artifact: note.trim() ? { note: note.trim() } : null });
    setNote('');
    refresh();
    setMessage(`Marked ${stageDefinition(stageId)?.label || stageId} complete.`);
  };

  const addNoteAndSave = () => {
    if (!active || !note.trim()) return;
    addWorkflowNote(safeStorage, note.trim());
    setNote('');
    refresh();
    setMessage('Workflow note saved.');
  };

  const attachTwin = () => {
    if (!active) return;
    const updated = updateWorkflow(safeStorage, current => ({
      ...current,
      source: current.source || { type: 'twin', id: 'twin-workflow', title: 'Twin-assisted workflow' },
      timeline: [...current.timeline, { at: new Date().toISOString(), type: 'handoff', stage: current.currentStage, text: 'Twin handoff context attached.' }],
    }));
    setActive(updated);
    setMessage('Twin context is now part of this workflow thread.');
  };

  const abandon = () => {
    abandonWorkflow(safeStorage);
    refresh();
    setMessage('Active workflow closed and preserved in local history.');
  };

  return <main className="page unified-workflows-page">
    <section className="unified-hero">
      <div>
        <div className="eyebrow">ENGINEERING / WORKFLOW ORCHESTRATION</div>
        <h1>One thread.<br/><span>Every tool connected.</span></h1>
        <p>Carry the same engineering context from knowledge and learning through diagnosis, configuration, runbooks, verification and Twin documentation.</p>
      </div>
      <div className="unified-hero-metric"><strong>{active ? `${progress.percent}%` : '—'}</strong><span>{active ? `${progress.completed}/${progress.total} stages complete` : 'no active workflow'}</span></div>
    </section>

    {active ? <section className="panel unified-active-panel">
      <div className="unified-section-head"><div><div className="kicker">ACTIVE THREAD</div><h2>{active.title}</h2><p>{active.description}</p></div><div className="unified-active-meta"><span>{active.templateId}</span><b>{progress.percent}%</b></div></div>
      <div className="unified-progress"><i style={{ width: `${progress.percent}%` }}/></div>
      <div className="unified-stage-list">
        {active.stages.map((stage, index) => <WorkflowStageCard key={stage.id} stage={stage} index={index} total={active.stages.length} active={stage.id === progress.current?.id} onOpen={openStage} onComplete={completeStage} />)}
      </div>
      <div className="unified-active-footer">
        <div><span>CURRENT TARGET</span><strong>{active.target?.id || 'Not assigned'}</strong></div>
        <div className="unified-footer-actions"><button className="button" onClick={() => openView(setView, 'twin')}><Icon name="brain" size={12}/> Open Twin</button><button className="button" onClick={attachTwin}>Attach Twin handoff</button><button className="button danger" onClick={abandon}><Icon name="x" size={11}/> Close workflow</button></div>
      </div>
    </section> : <section className="panel unified-empty-panel"><Icon name="route" size={26}/><h2>No active engineering thread</h2><p>Start one below. Once a thread exists, the same context remains available as you move between Driller Bill workspaces.</p></section>}

    <section className="unified-create-grid">
      <section className="panel unified-create-card"><div className="kicker">01 / START WITH A WORKFLOW</div><h2>Choose a path.</h2><label><span>Template</span><select value={templateId} onChange={event => setTemplateId(event.target.value)}>{Object.values(WORKFLOW_TEMPLATES).map(item => <option key={item.id} value={item.id}>{item.title}</option>)}</select></label><label><span>Title (optional)</span><input value={title} onChange={event => setTitle(event.target.value)} placeholder="Branch switch rollout"/></label><label><span>Target device</span><select value={deviceId} onChange={event => setDeviceId(event.target.value)}>{devices.map(device => <option key={device.id} value={device.id}>{device.id} · {device.kind}</option>)}</select></label><button className="button primary" onClick={createFromTemplate}><Icon name="plus" size={12}/> Start workflow</button></section>
      <section className="panel unified-create-card"><div className="kicker">02 / START WITH KNOWLEDGE</div><h2>Turn a concept into work.</h2><select value={selectedArticle} onChange={event => setSelectedArticle(event.target.value)}>{KNOWLEDGE_ARTICLES.map(article => <option key={article.id} value={article.id}>{article.title}</option>)}</select><p>{KNOWLEDGE_ARTICLES.find(article => article.id === selectedArticle)?.summary}</p><button className="button" onClick={createFromArticle}><Icon name="arrow" size={12}/> Create knowledge thread</button></section>
      <section className="panel unified-create-card"><div className="kicker">03 / START WITH A FAULT</div><h2>Turn a symptom into recovery.</h2><select value={selectedCase} onChange={event => setSelectedCase(event.target.value)}>{TROUBLESHOOTING_CASES.map(item => <option key={item.id} value={item.id}>{item.title}</option>)}</select><p>{TROUBLESHOOTING_CASES.find(item => item.id === selectedCase)?.symptom}</p><button className="button" onClick={createFromCase}><Icon name="arrow" size={12}/> Create recovery thread</button></section>
    </section>

    {active && <section className="panel unified-notes-panel"><div className="unified-section-head"><div><div className="kicker">ENGINEERING JOURNAL</div><h2>Keep the thread intact.</h2></div><span>LOCAL ONLY</span></div><textarea value={note} onChange={event => setNote(event.target.value)} rows={4} placeholder="Record a decision, observation, verification result, or follow-up."/><div className="unified-note-actions"><button className="button" onClick={addNoteAndSave} disabled={!note.trim()}>Save note</button><button className="button" onClick={() => openView(setView, 'twin')}>Use Twin to document</button></div></section>}

    <section className="panel unified-history-panel"><div className="unified-section-head"><div><div className="kicker">RECENT THREADS</div><h2>{history.length} preserved locally</h2></div><span>Version {UNIFIED_WORKFLOW_VERSION || '1.0.0'}</span></div>{history.length ? <div className="unified-history-list">{history.slice(0, 8).map(item => <button key={item.id} onClick={() => { saveWorkflowStore(safeStorage, { ...loadWorkflowStore(safeStorage), active: item }); refresh(); }}><span>{item.status}</span><strong>{item.title}</strong><small>{item.percent}% · {new Date(item.updatedAt).toLocaleString()}</small><Icon name="arrow" size={12}/></button>)}</div> : <div className="unified-muted">Completed and closed engineering threads will appear here.</div>}</section>
    {message && <div className="unified-toast" role="status">{message}</div>}
  </main>;
}

export function createTwinWorkflowFromContext(prompt, target = null) {
  return startWorkflow(safeStorage, workflowFromTwin(prompt, { target }));
}
