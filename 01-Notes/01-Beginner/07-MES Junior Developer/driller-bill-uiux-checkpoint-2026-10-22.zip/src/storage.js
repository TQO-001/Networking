const memory = new Map();


function hasSessionStorage() {
  try {
    return typeof window !== 'undefined' && !!window.sessionStorage;
  } catch {
    return false;
  }
}

function hasWindowStorage() {
  try {
    return typeof window !== 'undefined' && !!window.localStorage;
  } catch {
    return false;
  }
}

export const safeStorage = {
  getItem(key) {
    try {
      if (hasWindowStorage()) return window.localStorage.getItem(key);
      return memory.has(key) ? memory.get(key) : null;
    } catch {
      return memory.has(key) ? memory.get(key) : null;
    }
  },
  setItem(key, value) {
    const stringValue = String(value);
    try {
      if (hasWindowStorage()) {
        window.localStorage.setItem(key, stringValue);
        return true;
      }
      memory.set(key, stringValue);
      return true;
    } catch {
      try {
        memory.set(key, stringValue);
        return true;
      } catch {
        return false;
      }
    }
  },
  removeItem(key) {
    try {
      if (hasWindowStorage()) window.localStorage.removeItem(key);
    } catch {
      // Fall through to the in-memory fallback.
    }
    memory.delete(key);
  },
  clear() {
    try {
      if (hasWindowStorage()) window.localStorage.clear();
    } catch {
      // Keep in-memory fallback available.
    }
    memory.clear();
  },
};


export const safeSessionStorage = {
  getItem(key) {
    try {
      if (hasSessionStorage()) return window.sessionStorage.getItem(key);
      return memory.has(`session:${key}`) ? memory.get(`session:${key}`) : null;
    } catch {
      return memory.has(`session:${key}`) ? memory.get(`session:${key}`) : null;
    }
  },
  setItem(key, value) {
    const stringValue = String(value);
    try {
      if (hasSessionStorage()) {
        window.sessionStorage.setItem(key, stringValue);
        return true;
      }
      memory.set(`session:${key}`, stringValue);
      return true;
    } catch {
      try {
        memory.set(`session:${key}`, stringValue);
        return true;
      } catch {
        return false;
      }
    }
  },
  removeItem(key) {
    try {
      if (hasSessionStorage()) window.sessionStorage.removeItem(key);
    } catch {
      // Keep the in-memory session fallback available.
    }
    memory.delete(`session:${key}`);
  },
  clear() {
    try {
      if (hasSessionStorage()) window.sessionStorage.clear();
    } catch {
      // Keep the in-memory session fallback available.
    }
    for (const key of memory.keys()) if (String(key).startsWith('session:')) memory.delete(key);
  },
};
