import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import DeviceConfigurationWorkbench from './DeviceConfigurationWorkbench.jsx';
import { useNetworkWorkspace } from './context/NetworkWorkspaceContext.jsx';
import { safeStorage, safeSessionStorage } from './storage.js';
import { buildDeviceInventory, CONFIG_INTENTS, deviceAgentContract, deviceCapabilitySummary, planIntent } from './core/device-model.js';
import { DEVICE_SCENARIOS, verifyScenario } from './core/device-scenarios.js';
import UnifiedWorkflowBar from './UnifiedWorkflowBar.jsx';
import { agentApplyIntent, agentChangeHistory, agentConfigDiff, agentConfigHistory, agentConnect, agentDevices, agentDiagnostics, agentDisconnect, agentExecute, agentHealth, agentInspect, agentInspection, agentPreflightIntent, agentRegisterDevice, agentRemoveDevice, agentSnapshot, DEVICE_AGENT_URL } from './core/device-agent-client.js';
import TerminalToolbar from './terminal/TerminalToolbar.jsx';
import { useTerminalPreferences } from './terminal/terminalPreferences.js';
import { copyTerminalText, formatTerminalTranscript } from './terminal/terminalUtils.js';
import { completeCommandPrefix, insertAtSelection, stepCommandHistory } from './terminal/commandInput.js';

const AGENT_SETTINGS_KEY = 'drillerBill.deviceAgent.v48';
const QUICK_COMMANDS = ['show ip interface brief', 'show interfaces status', 'show vlan brief', 'show interfaces trunk', 'show ip route', 'show ip protocols', 'show ip ospf neighbor', 'show cdp neighbors'];

function readAgentSettings() {
  try {
    const local = JSON.parse(safeStorage.getItem(AGENT_SETTINGS_KEY) || '{}');
    const session = JSON.parse(safeSessionStorage.getItem(AGENT_SETTINGS_KEY) || '{}');
    if (Object.hasOwn(local, 'token')) safeStorage.setItem(AGENT_SETTINGS_KEY, JSON.stringify({ url: local.url || '' }));
    return { url: local.url || '', token: session.token || '' };
  } catch { return {}; }
}

function StatusDot({ state = 'ready' }) {
  return <span className={`device-status-dot ${state}`} aria-label={state} />;
}

const EMPTY_DEVICE = {
  id: 'SW-REAL-01', name: 'SW-REAL-01', hostname: 'SW-REAL-01', kind: 'switch', connectionType: 'ssh',
  host: '', port: '22', username: '', privateKeyPath: '', passwordEnv: '', enablePasswordEnv: '',
  serialPort: '', baudRate: '9600', dataBits: '8', stopBits: '1', parity: 'none', flowControl: 'none', timeoutMs: '5000',
  assumePrivileged: true, strictHostKeyChecking: 'accept-new',
};

export default function Devices({ focus = 'devices', setView } = {}) {
  const configurationFocus = focus === 'configuration';
  const { labState } = useNetworkWorkspace();
  const workspaceDevices = useMemo(() => buildDeviceInventory(labState), [labState]);
  const [selectedId, setSelectedId] = useState(workspaceDevices[0]?.id || '');
  const [intentType, setIntentType] = useState(CONFIG_INTENTS[0].id);
  const [fields, setFields] = useState({ id: '10', name: 'SALES', interface: 'Gi0/1', vlan: '10', vlans: '10,20,99' });
  const [agentUrl, setAgentUrl] = useState(() => readAgentSettings().url || DEVICE_AGENT_URL);
  const [agentToken, setAgentToken] = useState(() => readAgentSettings().token || '');
  const [agentState, setAgentState] = useState({ status: 'unknown', message: 'Not checked' });
  const [agentInventory, setAgentInventory] = useState([]);
  const [connected, setConnected] = useState(false);
  const [terminal, setTerminal] = useState([]);
  const terminalRef = useRef(null);
  const [terminalExpanded, setTerminalExpanded] = useState(false);
  const { fontSize: terminalFontSize, changeFontSize: changeTerminalFontSize, autoFollow: terminalAutoFollow, toggleAutoFollow: toggleTerminalAutoFollow } = useTerminalPreferences();
  const [command, setCommand] = useState('show vlan brief');
  const commandInputRef = useRef(null);
  const [commandHistoryIndex, setCommandHistoryIndex] = useState(-1);
  const commandDraftRef = useRef('');
  const [busy, setBusy] = useState(false);
  const [snapshot, setSnapshot] = useState(null);
  const [configHistory, setConfigHistory] = useState([]);
  const [compareFrom, setCompareFrom] = useState('');
  const [compareTo, setCompareTo] = useState('');
  const [configDiffState, setConfigDiffState] = useState(null);
  const [changePreflight, setChangePreflight] = useState(null);
  const [changeHistory, setChangeHistory] = useState([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [inspection, setInspection] = useState(null);
  const [inspectionLoading, setInspectionLoading] = useState(false);
  const [diagnostics, setDiagnostics] = useState(null);
  const [diagnosticsLoading, setDiagnosticsLoading] = useState(false);
  const [showAddDevice, setShowAddDevice] = useState(false);
  const [newDevice, setNewDevice] = useState(EMPTY_DEVICE);
  const [registrationMessage, setRegistrationMessage] = useState('');
  const [selectedScenarioId, setSelectedScenarioId] = useState(DEVICE_SCENARIOS[0]?.id || '');
  const [scenarioBusy, setScenarioBusy] = useState(false);
  const selected = useMemo(() => {
    const byId = new Map(workspaceDevices.map(device => [device.id, device]));
    for (const device of agentInventory) byId.set(device.id, device);
    return byId.get(selectedId) || [...byId.values()][0];
  }, [workspaceDevices, agentInventory, selectedId]);
  const allDevices = useMemo(() => {
    const byId = new Map(workspaceDevices.map(device => [device.id, device]));
    for (const device of agentInventory) byId.set(device.id, device);
    return [...byId.values()];
  }, [workspaceDevices, agentInventory]);
  const physicalIds = useMemo(() => new Set(agentInventory.filter(d => ['ssh', 'serial'].includes(d.connection?.type)).map(d => d.id)), [agentInventory]);
  const intent = CONFIG_INTENTS.find(x => x.id === intentType) || CONFIG_INTENTS[0];
  const plan = selected ? planIntent({ type: intentType, fields }, selected) : null;
  const contract = deviceAgentContract();
  const availableScenarios = useMemo(() => DEVICE_SCENARIOS.filter(item => !item.kind || item.kind === selected?.kind), [selected]);
  const selectedScenario = useMemo(() => availableScenarios.find(item => item.id === selectedScenarioId) || availableScenarios[0] || null, [availableScenarios, selectedScenarioId]);
  const scenarioVerification = useMemo(() => selectedScenario ? verifyScenario(selectedScenario, { inspection, diagnostics }) : null, [selectedScenario, inspection, diagnostics]);

  const persistAgentSettings = useCallback(() => {
    safeStorage.setItem(AGENT_SETTINGS_KEY, JSON.stringify({ url: agentUrl })); safeSessionStorage.setItem(AGENT_SETTINGS_KEY, JSON.stringify({ token: agentToken }));
  }, [agentUrl, agentToken]);

  const refreshAgent = useCallback(async () => {
    setAgentState(current => ({ ...current, status: 'checking', message: 'Checking local agent…' }));
    try {
      await agentHealth({ baseUrl: agentUrl });
      const result = await agentDevices({ baseUrl: agentUrl, token: agentToken });
      setAgentInventory(result.devices || []);
      setAgentState({ status: 'ready', message: `Connected to ${result.devices?.length || 0} agent devices` });
      persistAgentSettings();
      return result.devices || [];
    } catch (error) {
      setAgentState({ status: 'offline', message: error.message });
      setAgentInventory([]);
      return [];
    }
  }, [agentUrl, agentToken, persistAgentSettings]);

  useEffect(() => { refreshAgent(); }, []);

  useEffect(() => { if (!terminalAutoFollow || !terminalRef.current) return; terminalRef.current.scrollTop = terminalRef.current.scrollHeight; }, [terminal, terminalAutoFollow, terminalExpanded]);

  useEffect(() => { if (!terminalExpanded) return; const previousOverflow = document.body.style.overflow; document.body.style.overflow = 'hidden'; const onKeyDown = event => { if (event.key === 'Escape') setTerminalExpanded(false); }; window.addEventListener('keydown', onKeyDown); return () => { document.body.style.overflow = previousOverflow; window.removeEventListener('keydown', onKeyDown); }; }, [terminalExpanded]);

  useEffect(() => {
    const current = agentInventory.find(d => d.id === selectedId);
    setConnected(current?.connection?.status === 'connected');
  }, [agentInventory, selectedId]);

  const loadHistory = useCallback(async () => {
    if (!selectedId || !agentToken) { setConfigHistory([]); setConfigDiffState(null); return []; }
    setHistoryLoading(true);
    try {
      const result = await agentConfigHistory(selectedId, { baseUrl: agentUrl, token: agentToken });
      const history = result.history || [];
      setConfigHistory(history);
      setCompareFrom(current => current && history.some(item => item.id === current) ? current : history.at(-2)?.id || history[0]?.id || '');
      setCompareTo(current => current && history.some(item => item.id === current) ? current : history.at(-1)?.id || '');
      return history;
    } catch {
      setConfigHistory([]);
      setConfigDiffState(null);
      return [];
    } finally { setHistoryLoading(false); }
  }, [selectedId, agentUrl, agentToken]);

  const loadChangeHistory = useCallback(async () => {
    if (!selectedId || !agentToken) { setChangeHistory([]); return []; }
    try {
      const result = await agentChangeHistory(selectedId, { baseUrl: agentUrl, token: agentToken });
      const history = result.history || [];
      setChangeHistory(history);
      return history;
    } catch {
      setChangeHistory([]);
      return [];
    }
  }, [selectedId, agentUrl, agentToken]);

  useEffect(() => {
    if (selectedId && agentToken) { loadHistory(); loadChangeHistory(); }
  }, [selectedId, agentToken, loadHistory, loadChangeHistory]);

  const loadDiagnostics = useCallback(async () => {
    if (!selectedId || !agentToken) { setDiagnostics(null); return null; }
    setDiagnosticsLoading(true);
    try {
      const result = await agentDiagnostics(selectedId, { baseUrl: agentUrl, token: agentToken });
      setDiagnostics(result.diagnostics || null);
      return result.diagnostics || null;
    } catch {
      setDiagnostics(null);
      return null;
    } finally { setDiagnosticsLoading(false); }
  }, [selectedId, agentUrl, agentToken]);

  const loadInspection = useCallback(async () => {
    if (!selectedId || !agentToken) { setInspection(null); return null; }
    try {
      const result = await agentInspection(selectedId, { baseUrl: agentUrl, token: agentToken });
      setInspection(result.report || null);
      return result.report || null;
    } catch {
      setInspection(null);
      return null;
    }
  }, [selectedId, agentUrl, agentToken]);

  useEffect(() => {
    loadInspection();
    loadDiagnostics();
  }, [selectedId, agentToken, loadInspection, loadDiagnostics]);

  const loadConfigDiff = useCallback(async (fromId = compareFrom, toId = compareTo) => {
    if (!selectedId || !fromId || !toId || fromId === toId) { setConfigDiffState(null); return; }
    try {
      const result = await agentConfigDiff(selectedId, fromId, toId, { baseUrl: agentUrl, token: agentToken });
      setConfigDiffState(result);
    } catch (error) {
      setConfigDiffState({ error: error.message });
    }
  }, [selectedId, agentUrl, agentToken, compareFrom, compareTo]);

  useEffect(() => {
    if (!selectedId && allDevices[0]) setSelectedId(allDevices[0].id);
  }, [selectedId, allDevices]);

  const updateField = (id, value) => { setChangePreflight(null); setFields(current => ({ ...current, [id]: value })); };
  const chooseIntent = (type, nextFields = {}) => {
    setChangePreflight(null);
    setIntentType(type);
    setFields(current => ({ ...current, ...nextFields }));
  };
  const updateNewDevice = (id, value) => setNewDevice(current => ({ ...current, [id]: value }));

  const selectDevice = (id) => {
    setTerminalExpanded(false);
    setSelectedId(id);
    setTerminal([]);
    setSnapshot(null);
    setConfigHistory([]);
    setConfigDiffState(null);
    setChangePreflight(null);
    setInspection(null);
    setDiagnostics(null);
    setCompareFrom('');
    setCompareTo('');
    const agentDevice = agentInventory.find(d => d.id === id);
    setConnected(agentDevice?.connection?.status === 'connected');
  };

  const connectDevice = async () => {
    if (!selectedId) return;
    setBusy(true);
    try {
      const result = await agentConnect(selectedId, { baseUrl: agentUrl, token: agentToken });
      setConnected(true);
      setAgentState({ status: 'ready', message: `${selectedId} connected through local agent` });
      setAgentInventory(current => current.map(d => d.id === selectedId ? result.result.device : d));
      setTerminal(current => [...current, { command: '[session]', output: [`Connected to ${selectedId} through the local Device Agent.`] }]);
      await loadDiagnostics();
      persistAgentSettings();
    } catch (error) {
      setConnected(false);
      setAgentState({ status: 'error', message: error.message });
    } finally { setBusy(false); }
  };

  const disconnectDevice = async () => {
    if (!selectedId) return;
    setBusy(true);
    try {
      await agentDisconnect(selectedId, { baseUrl: agentUrl, token: agentToken });
      setConnected(false);
      setTerminal(current => [...current, { command: '[session]', output: [`Disconnected from ${selectedId}.`] }]);
      await refreshAgent();
    } catch (error) {
      setAgentState({ status: 'error', message: error.message });
    } finally { setBusy(false); }
  };

  const removePhysicalDevice = async () => {
    if (!selectedId || !physicalIds.has(selectedId)) return;
    setBusy(true);
    try {
      await agentRemoveDevice(selectedId, { baseUrl: agentUrl, token: agentToken });
      setSelectedId(workspaceDevices[0]?.id || '');
      setConnected(false);
      setTerminal([]);
      setSnapshot(null);
      await refreshAgent();
    } catch (error) {
      setAgentState({ status: 'error', message: error.message });
    } finally { setBusy(false); }
  };

  const registerDevice = async (event) => {
    event.preventDefault();
    setBusy(true);
    setRegistrationMessage('');
    try {
      const result = await agentRegisterDevice({ ...newDevice, port: Number(newDevice.port || 22) }, { baseUrl: agentUrl, token: agentToken });
      setShowAddDevice(false);
      setNewDevice(EMPTY_DEVICE);
      setSelectedId(result.device.id);
      setAgentState({ status: 'ready', message: `${result.device.hostname} added to the agent inventory` });
      await refreshAgent();
    } catch (error) {
      setRegistrationMessage(error.message);
      setAgentState({ status: 'error', message: error.message });
    } finally { setBusy(false); }
  };

  const insertCommandText = (text) => {
    const inputElement = commandInputRef.current;
    const start = inputElement?.selectionStart ?? command.length;
    const end = inputElement?.selectionEnd ?? command.length;
    const result = insertAtSelection(command, start, end, text);
    setCommand(result.value);
    setCommandHistoryIndex(-1);
    requestAnimationFrame(() => {
      inputElement?.focus();
      inputElement?.setSelectionRange(result.caret, result.caret);
    });
  };

  const handleDeviceTouchKey = (key) => {
    if (key === 'Tab') {
      const completed = completeCommandPrefix(command, QUICK_COMMANDS);
      if (completed !== command) setCommand(completed);
      commandInputRef.current?.focus();
      return;
    }
    if (key === '?') { insertCommandText('?'); return; }
    if (key === '|' || key === '/') { insertCommandText(key); return; }
    if (key === 'ArrowUp' || key === 'ArrowDown') {
      const history = terminal.map(entry => entry.command).filter(value => value && !value.startsWith('[')).reverse();
      if (!history.length) return;
      const result = stepCommandHistory({
        history,
        index: commandHistoryIndex,
        direction: key === 'ArrowUp' ? 'up' : 'down',
        draft: commandDraftRef.current,
        currentValue: command,
      });
      setCommandHistoryIndex(result.index);
      commandDraftRef.current = result.draft;
      setCommand(result.value);
      commandInputRef.current?.focus();
      return;
    }
    if (key === 'clear-input') {
      setCommand('');
      setCommandHistoryIndex(-1);
      commandInputRef.current?.focus();
    }
    if (key === 'clear-screen') setTerminal([]);
  };

  const runCommand = async (event) => {
    event?.preventDefault();
    const value = command.trim();
    if (!value || !selectedId || !connected) return;
    setBusy(true);
    try {
      const result = await agentExecute(selectedId, value, { baseUrl: agentUrl, token: agentToken });
      setTerminal(current => [...current, { command: value, output: result.result.output || [] }].slice(-60));
      setAgentInventory(current => current.map(d => d.id === selectedId ? result.result.device : d));
      setCommandHistoryIndex(-1);
      commandDraftRef.current = '';
    } catch (error) {
      setTerminal(current => [...current, { command: value, output: [`% ${error.message}`], error: true }].slice(-60));
    } finally { setBusy(false); }
  };

  const preflightIntent = async (override = null) => {
    const effectiveType = override?.type || intentType;
    const effectiveFields = override?.fields || fields;
    const effectiveIntent = { type: effectiveType, fields: effectiveFields };
    const effectivePlan = planIntent(effectiveIntent, selected);
    if (!selectedId || !connected || !effectivePlan?.valid) return null;
    setBusy(true);
    try {
      const result = await agentPreflightIntent(selectedId, effectiveIntent, { baseUrl: agentUrl, token: agentToken });
      const preflight = result.result || null;
      if (!preflight) throw new Error('The Device Agent returned no preflight result.');
      setChangePreflight({ ...preflight, intent: effectiveIntent });
      setTerminal(current => [...current, { command: `[preflight] ${effectiveType}`, output: [preflight.preflight?.summary || 'Change preflight completed.'] }].slice(-60));
      await loadChangeHistory();
      return preflight;
    } catch (error) {
      setChangePreflight(null);
      setAgentState({ status: 'error', message: error.message });
      return null;
    } finally { setBusy(false); }
  };

  const applyIntent = async (override = null, suppliedPreflight = null) => {
    const effectiveType = override?.type || intentType;
    const effectiveFields = override?.fields || fields;
    const effectiveIntent = { type: effectiveType, fields: effectiveFields };
    const effectivePlan = planIntent(effectiveIntent, selected);
    if (!selectedId || !connected || !effectivePlan?.valid) return null;
    const matchingPreflight = suppliedPreflight || (changePreflight?.intent?.type === effectiveType && JSON.stringify(changePreflight.intent?.fields || {}) === JSON.stringify(effectiveFields) ? changePreflight : null);
    if (!matchingPreflight?.changeId) {
      setAgentState({ status: 'ready', message: 'Run change preflight before applying this configuration.' });
      setChangePreflight(null);
      return null;
    }
    setBusy(true);
    try {
      const result = await agentApplyIntent(selectedId, effectiveIntent, { baseUrl: agentUrl, token: agentToken, changeId: matchingPreflight.changeId });
      const displayCommands = effectivePlan?.displayCommands || effectivePlan?.commands || [];
      const lines = (result.result.transcript || []).flatMap((entry, index) => [displayCommands[index] || `${entry.command}`, ...(entry.output || [])]);
      setTerminal(current => [...current, { command: `[intent] ${effectiveType}`, output: lines }].slice(-60));
      if (result.result.applied) {
        setSnapshot(result.result.snapshot || null);
        await loadHistory();
        const inspectionResult = await agentInspect(selectedId, { baseUrl: agentUrl, token: agentToken });
        setInspection(inspectionResult.report || null);
        await loadDiagnostics();
      }
      await loadChangeHistory();
      setChangePreflight(null);
      await refreshAgent();
      setConnected(true);
      return result.result;
    } catch (error) {
      setAgentState({ status: 'error', message: error.message });
      return null;
    } finally { setBusy(false); }
  };

  const previewScenarioStep = (step) => {
    if (!step) return;
    previewIntent(step.intent);
  };

  const applyScenarioStep = async (step) => {
    if (!step || !selectedScenario || !selectedId || !connected) return;
    setScenarioBusy(true);
    try {
      const preflight = await preflightIntent(step.intent);
      if (preflight?.changeId) await applyIntent(step.intent, preflight);
    } finally {
      setScenarioBusy(false);
    }
  };

  const previewIntent = (override = null) => {
    const effectiveType = override?.type || intentType;
    const effectiveFields = override?.fields || fields;
    const effectivePlan = planIntent({ type: effectiveType, fields: effectiveFields }, selected);
    if (!effectivePlan.valid) return;
    setTerminal(current => [...current, { command: `[preview] ${effectiveType}`, output: effectivePlan.displayCommands || effectivePlan.commands }].slice(-60));
  };

  const inspectDevice = async () => {
    if (!selectedId || !connected) return;
    setInspectionLoading(true);
    setBusy(true);
    try {
      const result = await agentInspect(selectedId, { baseUrl: agentUrl, token: agentToken });
      setInspection(result.report || null);
      await loadDiagnostics();
      await refreshAgent();
      setConnected(true);
      setTerminal(current => [...current, { command: '[inspect]', output: [`Device inspection captured: ${(result.report?.signals || []).length} signal${(result.report?.signals || []).length === 1 ? '' : 's'}.`] }].slice(-60));
    } catch (error) {
      setAgentState({ status: 'error', message: error.message });
    } finally { setInspectionLoading(false); setBusy(false); }
  };

  const takeSnapshot = async () => {
    if (!selectedId || !connected) return;
    setBusy(true);
    try {
      const result = await agentSnapshot(selectedId, { baseUrl: agentUrl, token: agentToken });
      setSnapshot(result.result);
      setTerminal(current => [...current, { command: '[snapshot]', output: ['Running and startup configuration captured and added to history.'] }].slice(-60));
      const history = await loadHistory();
      await loadDiagnostics();
      if (history.length > 1) {
        const from = history.at(-2).id;
        const to = history.at(-1).id;
        setCompareFrom(from);
        setCompareTo(to);
        await loadConfigDiff(from, to);
      }
    } catch (error) {
      setAgentState({ status: 'error', message: error.message });
    } finally { setBusy(false); }
  };

  const selectedHistoryFrom = configHistory.find(item => item.id === compareFrom);
  const selectedHistoryTo = configHistory.find(item => item.id === compareTo);


  return <main className={`page devices-page ${configurationFocus ? 'configuration-page' : ''}`}>
    <UnifiedWorkflowBar view={configurationFocus ? 'config' : 'devices'} setView={setView}/>
    <section className="device-hero">
      <div>
        <div className="eyebrow">ENGINEERING / {configurationFocus ? 'CONFIGURATION' : 'DEVICES'}</div>
        <h1>{configurationFocus ? 'Configuration workspace' : 'Device workspace'}</h1>
        <p>{configurationFocus ? 'Build reviewed changes against a selected device. Inspect observed state, describe the desired intent, preview the exact IOS command plan, apply it through the local agent and preserve the result in configuration history.' : 'Connect Driller Bill to simulated or physical equipment through a localhost agent. The browser owns intent and presentation; the agent owns SSH, execution and configuration snapshots.'}</p>
      </div>
      <div className="device-hero-actions"><div className="device-hero-stat"><strong>{allDevices.length}</strong><span>{configurationFocus ? 'available targets' : 'known devices'}</span><small>{physicalIds.size} physical · {allDevices.length - physicalIds.size} simulated</small></div>{!configurationFocus && <button className="button primary" onClick={() => { setShowAddDevice(value => !value); setRegistrationMessage(''); }} disabled={agentState.status !== 'ready'}>{showAddDevice ? 'Close form' : '＋ Add physical device'}</button>}</div>
    </section>

    <section className="panel device-agent-bar">
      <div className="device-agent-copy"><div className="device-card-kicker">LOCAL DEVICE AGENT / V57</div><h2>Browser ↔ local agent ↔ device</h2><p>The browser never opens SSH sockets. Credentials stay on the machine running the agent; the UI sends device intent, commands and agent-side credential references.</p></div>
      <div className="device-agent-controls">
        <label><span>AGENT URL</span><input value={agentUrl} onChange={event => setAgentUrl(event.target.value)} spellCheck="false" /></label>
        <label><span>BEARER TOKEN</span><input value={agentToken} onChange={event => setAgentToken(event.target.value)} type="password" placeholder="paste token printed by agent" autoComplete="off" /></label>
        <button className="button primary" onClick={refreshAgent} disabled={busy}>{agentState.status === 'checking' ? 'Checking…' : 'Check agent'}</button>
      </div>
      <div className={`device-agent-status ${agentState.status}`}><StatusDot state={agentState.status === 'ready' ? 'ready' : 'offline'} /><span>{agentState.message}</span></div>
    </section>

    {!configurationFocus && showAddDevice && <section className="panel device-register">
      <div className="device-register-head"><div><div className="device-card-kicker">PHYSICAL DEVICE / TRANSPORT</div><h2>Add a physical console or SSH device</h2><p>SSH uses the host's OpenSSH client. Serial/console uses a local COM or tty device exposed to the agent. Secrets and transport handles stay inside the agent process.</p></div><div className="device-register-note"><strong>Security boundary</strong><span>Only the agent process sees credentials and serial handles.</span></div></div>
      <form className="device-register-grid" onSubmit={registerDevice}>
        <label><span>DEVICE ID *</span><input value={newDevice.id} onChange={e => updateNewDevice('id', e.target.value)} required /></label>
        <label><span>DISPLAY NAME *</span><input value={newDevice.name} onChange={e => updateNewDevice('name', e.target.value)} required /></label>
        <label><span>TRANSPORT</span><select value={newDevice.connectionType} onChange={e => updateNewDevice('connectionType', e.target.value)}><option value="ssh">SSH</option><option value="serial">Serial / Console</option></select></label>
        <label><span>ROLE</span><select value={newDevice.kind} onChange={e => updateNewDevice('kind', e.target.value)}><option value="switch">Switch</option><option value="router">Router</option></select></label>
        {newDevice.connectionType === 'serial' ? <>
          <label className="wide"><span>SERIAL PORT *</span><input value={newDevice.serialPort} onChange={e => updateNewDevice('serialPort', e.target.value)} placeholder="/dev/ttyUSB0 or COM3" spellCheck="false" required /></label>
          <label><span>BAUD RATE</span><select value={newDevice.baudRate} onChange={e => updateNewDevice('baudRate', e.target.value)}>{['1200','2400','4800','9600','19200','38400','57600','115200','230400','460800','921600'].map(v => <option key={v}>{v}</option>)}</select></label>
          <label><span>DATA BITS</span><select value={newDevice.dataBits} onChange={e => updateNewDevice('dataBits', e.target.value)}>{['5','6','7','8'].map(v => <option key={v}>{v}</option>)}</select></label>
          <label><span>STOP BITS</span><select value={newDevice.stopBits} onChange={e => updateNewDevice('stopBits', e.target.value)}><option value="1">1</option><option value="2">2</option></select></label>
          <label><span>PARITY</span><select value={newDevice.parity} onChange={e => updateNewDevice('parity', e.target.value)}><option value="none">None</option><option value="even">Even</option><option value="odd">Odd</option></select></label>
          <label><span>FLOW CONTROL</span><select value={newDevice.flowControl} onChange={e => updateNewDevice('flowControl', e.target.value)}><option value="none">None</option><option value="hardware">Hardware (RTS/CTS)</option><option value="software">Software (XON/XOFF)</option></select></label>
          <label><span>COMMAND TIMEOUT MS</span><input type="number" min="500" max="120000" value={newDevice.timeoutMs} onChange={e => updateNewDevice('timeoutMs', e.target.value)} /></label>
        </> : <>
          <label><span>HOST / IP *</span><input value={newDevice.host} onChange={e => updateNewDevice('host', e.target.value)} placeholder="10.10.22.10" required /></label>
          <label><span>SSH PORT</span><input type="number" min="1" max="65535" value={newDevice.port} onChange={e => updateNewDevice('port', e.target.value)} /></label>
          <label><span>USERNAME *</span><input value={newDevice.username} onChange={e => updateNewDevice('username', e.target.value)} required /></label>
          <label><span>PRIVATE KEY PATH</span><input value={newDevice.privateKeyPath} onChange={e => updateNewDevice('privateKeyPath', e.target.value)} placeholder="C:\\Users\\you\\.ssh\\id_ed25519" spellCheck="false" /></label>
          <label><span>PASSWORD ENV VAR</span><input value={newDevice.passwordEnv} onChange={e => updateNewDevice('passwordEnv', e.target.value)} placeholder="DB_SWITCH_PASSWORD" spellCheck="false" /></label>
          <label><span>HOST KEY POLICY</span><select value={newDevice.strictHostKeyChecking} onChange={e => updateNewDevice('strictHostKeyChecking', e.target.value)}><option value="accept-new">Accept new, reject changed</option><option value="yes">Require known host</option><option value="no">Disable verification</option></select></label>
        </>}
        <label><span>ENABLE PASSWORD ENV VAR</span><input value={newDevice.enablePasswordEnv} onChange={e => updateNewDevice('enablePasswordEnv', e.target.value)} placeholder="DB_ENABLE_PASSWORD" spellCheck="false" /></label>
        <label className="device-check"><input type="checkbox" checked={newDevice.assumePrivileged} onChange={e => updateNewDevice('assumePrivileged', e.target.checked)} /><span>Session is already privileged (disable to use the configured enable-password environment variable)</span></label>
        <div className="device-register-actions"><button className="button" type="button" onClick={() => setShowAddDevice(false)}>Cancel</button><button className="button primary" type="submit" disabled={busy || agentState.status !== 'ready'}>Add device</button></div>
      </form>
      {registrationMessage && <div className="device-errors register-error">× {registrationMessage}</div>}
    </section>}

    <section className="device-layout">
      <aside className="panel device-index">
        <div className="device-panel-head"><span>DEVICES</span><b>{allDevices.length}</b></div>
        <div className="device-list">
          {allDevices.map(device => {
            const isConnected = device.connection?.status === 'connected' && connected && selectedId === device.id;
            const physical = ['ssh', 'serial'].includes(device.connection?.type);
            return <button key={device.id} className={`device-list-item ${selected?.id === device.id ? 'active' : ''}`} onClick={() => selectDevice(device.id)}>
              <span className="device-list-icon">{physical ? (device.connection?.type === 'serial' ? 'CON' : 'SSH') : device.kind === 'switch' ? 'SW' : 'R'}</span>
              <span><strong>{device.hostname}</strong><small>{physical ? `${device.vendor} · ${device.connection?.type === 'serial' ? 'Serial console' : 'SSH'}` : `${device.vendor} · ${device.kind}`}</small></span>
              <StatusDot state={isConnected ? 'connected' : 'ready'} />
            </button>;
          })}
        </div>
      </aside>

      {selected && <div className="device-main">
        <section className="panel device-overview">
          <div className="device-title-row">
            <div><div className="eyebrow">{selected.connection?.type === 'serial' ? 'PHYSICAL DEVICE / SERIAL CONSOLE' : selected.connection?.type === 'ssh' ? 'PHYSICAL DEVICE / SSH' : 'SIMULATED WORKSPACE DEVICE'} / {selected.id}</div><h2>{selected.hostname}</h2><p>{selected.vendor} {selected.platform} · {selected.connection?.endpoint || 'Shared Driller Bill lab'}{selected.connection?.serial ? ` · ${selected.connection.serial.baudRate}/${selected.connection.serial.dataBits}${selected.connection.serial.parity[0].toUpperCase()}${selected.connection.serial.stopBits}` : ''}</p></div>
            <div className="device-overview-actions"><div className="device-connection-badge"><StatusDot state={connected ? 'connected' : 'ready'} /> {connected ? 'AGENT / CONNECTED' : 'NOT CONNECTED'}</div>{connected && <button className="button" onClick={inspectDevice} disabled={busy}>{inspectionLoading ? 'Inspecting…' : 'Inspect device'}</button>}{connected ? <button className="button" onClick={disconnectDevice} disabled={busy}>Disconnect</button> : <button className="button primary" onClick={connectDevice} disabled={busy || agentState.status !== 'ready'}>Connect</button>}{physicalIds.has(selected.id) && <button className="button danger" onClick={removePhysicalDevice} disabled={busy}>Remove</button>}</div>
          </div>
          <div className="device-metric-grid">
            <div><span>PLATFORM</span><strong>{selected.platform}</strong></div><div><span>VERSION</span><strong>{selected.version}</strong></div><div><span>INTERFACES</span><strong>{selected.upInterfaceCount}/{selected.interfaceCount}</strong></div><div><span>VLANs</span><strong>{selected.vlanCount}</strong></div><div><span>ROUTES</span><strong>{selected.routeCount}</strong></div><div><span>MODE</span><strong>{selected.mode}</strong></div>
          </div>
        </section>

        {!configurationFocus && <section className="device-two-col">
          <div className="panel device-card"><div className="device-card-kicker">DEVICE CAPABILITIES</div><h3>What this device can expose</h3><div className="device-capabilities">{deviceCapabilitySummary(selected).map(item => <div key={item.id}><span>✓</span><strong>{item.label}</strong></div>)}</div></div>
          <div className="panel device-card"><div className="device-card-kicker">AGENT CONTRACT</div><h3>Transport stays outside the UI</h3><p className="device-copy">The browser asks for intent, commands and snapshots. The local agent owns SSH/serial sockets, authentication and transport-specific failures.</p><div className="device-contract"><div><span>PROTOCOL</span><strong>{contract.protocol}</strong></div><div><span>OPERATIONS</span><strong>{contract.operations.length}</strong></div><div><span>TRANSPORTS</span><strong>{contract.transports.join(' · ')}</strong></div></div></div>
        </section>}

        {!configurationFocus && connected && <section className={`panel device-console ${terminalExpanded ? 'terminal-workbench-expanded' : ''}`} role={terminalExpanded?'dialog':undefined} aria-modal={terminalExpanded?'true':undefined} aria-label={terminalExpanded?`Expanded terminal for ${selected.hostname}`:undefined} onKeyDown={event=>{if(!terminalExpanded||event.key!=='Tab')return;const focusable=[...event.currentTarget.querySelectorAll('button:not(:disabled),input:not(:disabled),[tabindex="0"]')];if(!focusable.length)return;const first=focusable[0],last=focusable[focusable.length-1];if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}}>
          <div className="device-title-row"><div><div className="eyebrow">LIVE DEVICE SESSION</div><h2>CLI bridge</h2><p>Commands travel through the local agent. SSH uses OpenSSH; serial sessions use the local COM/tty device. Both preserve the same browser-facing protocol as the simulator.</p></div><div className="device-console-actions"><button className="button" type="button" onClick={inspectDevice} disabled={busy}>{inspectionLoading ? 'Inspecting…' : 'Inspect'}</button><button className="button" type="button" onClick={takeSnapshot} disabled={busy}>Capture snapshot</button></div></div>
          <div className="device-quickbar" aria-label="Suggested show commands">{QUICK_COMMANDS.map(item => <button type="button" key={item} onClick={() => setCommand(item)}>{item}</button>)}</div>
          <TerminalToolbar fontSize={terminalFontSize} onFontSizeChange={changeTerminalFontSize} autoFollow={terminalAutoFollow} onToggleAutoFollow={toggleTerminalAutoFollow} expanded={terminalExpanded} onToggleExpanded={()=>setTerminalExpanded(value=>!value)} onCopy={()=>copyTerminalText(formatTerminalTranscript(terminal, 'DB>'))} onClear={()=>setTerminal([])}/>
          <div className="db-cli-key-row device-touch-key-row" role="group" aria-label="Touch-friendly device command keys">
            <button type="button" onClick={() => handleDeviceTouchKey('Tab')} aria-label="Complete a common read-only command">Tab</button>
            <button type="button" onClick={() => handleDeviceTouchKey('?')} aria-label="Insert IOS context-help marker">?</button>
            <button type="button" onClick={() => handleDeviceTouchKey('|')} aria-label="Insert pipe filter">|</button>
            <button type="button" onClick={() => handleDeviceTouchKey('/')} aria-label="Insert slash">/</button>
            <button type="button" onClick={() => handleDeviceTouchKey('ArrowUp')} aria-label="Previous command">↑</button>
            <button type="button" onClick={() => handleDeviceTouchKey('ArrowDown')} aria-label="Next command">↓</button>
            <button type="button" onClick={() => handleDeviceTouchKey('clear-input')} aria-label="Clear command input">Clear input</button>
            <button type="button" onClick={() => handleDeviceTouchKey('clear-screen')} aria-label="Clear terminal output">Clear screen</button>
          </div>
          <div ref={terminalRef} className="device-terminal" style={{'--terminal-font-size': `${terminalFontSize}px`}} role="log" aria-label={`Live command output for ${selected.hostname}`} aria-live="off" tabIndex={0}>{terminal.length === 0 && <div className="device-terminal-empty">Connected. Run an IOS-style command to begin.</div>}{terminal.map((entry, index) => <div className={`device-terminal-entry ${entry.error ? 'error' : ''}`} key={`${entry.command}-${index}`}><div><span>DB&gt;</span> {entry.command}</div><pre>{entry.output.join('\n') || '(no output)'}</pre></div>)}</div>
          <form className="device-terminal-input" onSubmit={runCommand}><span aria-hidden="true">DB&gt;</span><input ref={commandInputRef} aria-label={`Command for ${selected.hostname}`} value={command} onChange={event => { setCommand(event.target.value); setCommandHistoryIndex(-1); }} spellCheck={false} autoCapitalize="off" autoCorrect="off" autoComplete="off"/><button className="button primary" type="submit" disabled={busy}>{busy ? 'Running…' : 'Run command'}</button></form>
        </section>}

        {inspection && <section className="panel device-inspection">
          <div className="device-title-row"><div><div className="eyebrow">DEVICE / INSPECTION</div><h2>Structured device state</h2><p>Driller Bill turns standard show-command evidence into a reusable device model. The raw command output remains available for engineering verification.</p></div><div className="device-inspection-meta"><span>Captured</span><strong>{new Date(inspection.inspectedAt).toLocaleString()}</strong></div></div>
          <div className="device-inspection-overview">{[['HOSTNAME', inspection.overview.hostname], ['VERSION', inspection.overview.version], ['INTERFACES', `${inspection.overview.upInterfaceCount}/${inspection.overview.interfaceCount} up`], ['VLANs', inspection.overview.vlanCount], ['ROUTES', inspection.overview.routeCount], ['TRUNKS', inspection.overview.trunkCount]].map(([label, value]) => <div key={label}><span>{label}</span><strong>{value}</strong></div>)}</div>
          {!!inspection.signals?.length && <div className="device-inspection-signals"><div className="device-card-kicker">OBSERVATIONS</div>{inspection.signals.map(signal => <div key={`${signal.type}-${signal.message}`} className={`device-inspection-signal ${signal.severity}`}><strong>{signal.type.replaceAll('-', ' ')}</strong><span>{signal.message}</span></div>)}</div>}
          <div className="device-inspection-tables">
            <div><div className="device-card-kicker">INTERFACES</div>{inspection.interfaces.length ? <div className="device-structured-list">{inspection.interfaces.map(item => <div key={item.name}><code>{item.name}</code><span>{item.ip}</span><b>{item.status}/{item.protocol}</b></div>)}</div> : <p className="device-muted">No interface rows were parsed.</p>}</div>
            <div><div className="device-card-kicker">VLANs</div>{inspection.vlans.length ? <div className="device-structured-list">{inspection.vlans.map(item => <div key={item.id}><code>{item.id}</code><span>{item.name}</span><b>{item.status}</b></div>)}</div> : <p className="device-muted">No VLAN rows were parsed.</p>}</div>
            <div><div className="device-card-kicker">TRUNKS</div>{inspection.trunks.length ? <div className="device-structured-list">{inspection.trunks.map(item => <div key={item.interface}><code>{item.interface}</code><span>{item.mode} · native {item.nativeVlan}</span><b>{item.status}</b></div>)}</div> : <p className="device-muted">No trunk rows were parsed.</p>}</div>
            <div><div className="device-card-kicker">ROUTES</div>{inspection.routes.length ? <div className="device-structured-list">{inspection.routes.map((item, index) => <div key={`${item.network}-${index}`}><code>{item.code}</code><span>{item.network} via {item.nextHop || 'connected'}</span><b>{item.interface || '—'}</b></div>)}</div> : <p className="device-muted">No route rows were parsed.</p>}</div>
          </div>
        </section>}

        {diagnostics && <section className="panel device-diagnostics">
          <div className="device-title-row"><div><div className="eyebrow">DEVICE / DIAGNOSTICS</div><h2>Engineering health</h2><p>Diagnostics combine live inspection, configuration history and startup alignment. Facts are surfaced as evidence; they are not treated as proof of intent.</p></div><div className={`device-health-badge ${diagnostics.status}`}><strong>{diagnostics.score}</strong><span>{diagnostics.status}</span></div></div>
          <div className="device-diagnostics-grid">
            <div className="device-health-card"><div className="device-card-kicker">HEALTH CHECKS</div>{diagnostics.checks.map(item => <div className={`device-health-check ${item.status}`} key={item.id}><div><strong>{item.label}</strong><span>{item.detail}</span></div><b>{item.value || item.status}</b></div>)}</div>
            <div className="device-health-card"><div className="device-card-kicker">RECENT CHANGE</div>{diagnostics.recentChanges ? <><div className="device-change-summary"><strong>{diagnostics.recentChanges.summary}</strong><span>{diagnostics.recentChanges.from} → {diagnostics.recentChanges.to}</span></div><div className="device-diff-mini">{diagnostics.recentChanges.removed.map((line, index) => <div className="removed" key={`dr-${index}`}><b>−</b><code>{line}</code></div>)}{diagnostics.recentChanges.added.map((line, index) => <div className="added" key={`da-${index}`}><b>+</b><code>{line}</code></div>)}</div></> : <p className="device-muted">No change between the latest two configuration snapshots.</p>}
              <div className="device-card-kicker device-diagnostics-subkicker">ACTIONABLE OBSERVATIONS</div>{diagnostics.actionableSignals.length ? diagnostics.actionableSignals.map(signal => <div className="device-actionable" key={`${signal.type}-${signal.message}`}><b>{signal.type.replaceAll('-', ' ')}</b><span>{signal.message}</span></div>) : <p className="device-muted">No warning-level observations were generated by the latest inspection.</p>}
            </div>
          </div>
          <div className="device-diagnostics-footer"><span>{diagnostics.historyCount} snapshots in local history</span>{diagnostics.latestSnapshot && <span>Latest: {new Date(diagnostics.latestSnapshot.capturedAt).toLocaleString()}</span>}<button className="text-button" onClick={loadDiagnostics} disabled={diagnosticsLoading}>{diagnosticsLoading ? 'Refreshing…' : 'Refresh diagnostics'}</button></div>
        </section>}

        <DeviceConfigurationWorkbench
          device={selected}
          inspection={inspection}
          connected={connected}
          busy={busy}
          intentType={intentType}
          fields={fields}
          intent={intent}
          plan={plan}
          configIntents={CONFIG_INTENTS}
          onIntent={chooseIntent}
          onField={updateField}
          onPreview={() => previewIntent()}
          onPreflight={() => preflightIntent()}
          onApply={() => applyIntent()}
          changePreflight={changePreflight}
          changeHistory={changeHistory}
          onInspect={inspectDevice}
          inspectionLoading={inspectionLoading}
          scenarios={availableScenarios}
          selectedScenario={selectedScenario}
          scenarioVerification={scenarioVerification}
          onSelectScenario={(id) => setSelectedScenarioId(id)}
          onPreviewScenarioStep={previewScenarioStep}
          onApplyScenarioStep={applyScenarioStep}
          scenarioBusy={scenarioBusy}
        />

        <section className="panel device-history"><div className="device-title-row"><div><div className="eyebrow">CONFIGURATION / HISTORY</div><h2>Configuration timeline</h2><p>Every captured state is kept in the local Device Agent for comparison. History is capped at the most recent 50 snapshots per device.</p></div><div className="device-history-actions"><button className="button" onClick={loadHistory} disabled={historyLoading}>{historyLoading ? 'Refreshing…' : 'Refresh history'}</button></div></div>{configHistory.length === 0 ? <div className="device-history-empty">No snapshots yet. Connect to the device and capture a baseline, or apply a configuration intent.</div> : <><div className="device-history-list">{configHistory.slice().reverse().map((item, index) => <div className={`device-history-row ${item.id === compareTo ? 'current' : ''}`} key={item.id}><div><strong>{item.label}</strong><span>{new Date(item.capturedAt).toLocaleString()} · {item.source}</span></div><div className="device-history-summary">{index === configHistory.length - 1 ? 'LATEST' : item.summary}</div><button className="text-button" onClick={() => setCompareTo(item.id)}>Use as “to”</button></div>)}</div>{configHistory.length > 1 && <div className="device-diff"><div className="device-diff-controls"><label><span>FROM</span><select value={compareFrom} onChange={event => setCompareFrom(event.target.value)}>{configHistory.map(item => <option key={item.id} value={item.id}>{new Date(item.capturedAt).toLocaleString()} · {item.label}</option>)}</select></label><label><span>TO</span><select value={compareTo} onChange={event => setCompareTo(event.target.value)}>{configHistory.map(item => <option key={item.id} value={item.id}>{new Date(item.capturedAt).toLocaleString()} · {item.label}</option>)}</select></label><button className="button primary" onClick={() => loadConfigDiff()} disabled={!compareFrom || !compareTo || compareFrom === compareTo}>Compare</button></div>{selectedHistoryFrom && selectedHistoryTo && <div className="device-diff-meta"><span>{selectedHistoryFrom.label}</span><b>→</b><span>{selectedHistoryTo.label}</span>{configDiffState?.summary && <strong>{configDiffState.summary}</strong>}</div>}{configDiffState?.error ? <div className="device-errors"><div>× {configDiffState.error}</div></div> : configDiffState?.diff ? <div className="device-diff-output">{!configDiffState.diff.changed && <div className="device-diff-empty">No running-configuration changes were detected between these snapshots.</div>}{configDiffState.diff.removed.map((line, index) => <div className="removed" key={`r-${index}`}><b>−</b><code>{line}</code></div>)}{configDiffState.diff.added.map((line, index) => <div className="added" key={`a-${index}`}><b>+</b><code>{line}</code></div>)}</div> : <div className="device-diff-empty">Choose two different snapshots and compare them.</div>}</div>}</>}</section>

        {snapshot && <section className="panel device-snapshot"><div className="device-title-row"><div><div className="eyebrow">CONFIGURATION / SNAPSHOT</div><h2>Captured device state</h2><p>Running and startup configuration were captured by the local agent at {new Date(snapshot.capturedAt).toLocaleString()}. Sensitive credential values are redacted in stored history.</p></div></div><div className="device-snapshot-grid"><div><span>RUNNING-CONFIG</span><pre>{snapshot.runningConfig}</pre></div><div><span>STARTUP-CONFIG</span><pre>{snapshot.startupConfig}</pre></div></div></section>}
      </div>}
    </section>
  </main>;
}
