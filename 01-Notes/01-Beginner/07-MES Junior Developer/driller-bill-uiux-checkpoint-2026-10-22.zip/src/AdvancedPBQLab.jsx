import React, { useEffect, useMemo, useRef, useState } from 'react';
import { safeStorage } from './storage.js';
import { ADVANCED_CASES, ADVANCED_STORAGE, advancedFixture, advancedRun, advancedSnapshot, evaluateAdvancedCase } from './core/advanced-pbq-engine.js';

const DEVICES = ['R1','R2','SW1','SW2'];
const HINTS = {
  R1:['show ip dhcp pool','show ip dhcp binding','show ip nat statistics','show ip nat translations','show ip route','show ip ospf neighbor'],
  R2:['show ip ospf neighbor','show ip ospf interface','show ip route','show ip interface brief'],
  SW1:['show interfaces trunk','show spanning-tree vlan 10','show spanning-tree vlan 20','show etherchannel summary','show vlan brief'],
  SW2:['show interfaces trunk','show spanning-tree vlan 10','show spanning-tree vlan 20','show etherchannel summary','show interfaces switchport gi0/5','show vlan brief']
};
const load = (k, f) => { try { return JSON.parse(safeStorage.getItem(k)) ?? f; } catch { return f; } };
const save = (k, v) => safeStorage.setItem(k, JSON.stringify(v));

function Badge({children, tone=''}) { return <span className={`v9-badge ${tone}`}>{children}</span>; }
function Stat({label, value, tone=''}) { return <div className={`v9-stat ${tone}`}><span>{label}</span><strong>{value}</strong></div>; }

function Topology({state}) {
  const s = advancedSnapshot(state);
  const route = state.devices.R1.routes.some(r => r.type==='S' && r.prefix==='10.20.20.0/24');
  const stp = s.stp.VLAN10 === 'SW1' && s.stp.VLAN20 === 'SW1';
  const lacp = s.etherchannel.SW1 && s.etherchannel.SW2;
  const ospf = s.ospf.R1 === 'FULL' && s.ospf.R2 === 'FULL';
  const nodes = [
    ['R1','router',22,20,`OSPF ${s.ospf.R1}`],
    ['R2','router',78,20,`OSPF ${s.ospf.R2}`],
    ['SW1','switch',22,58,`ROOT ${s.stp.VLAN10}`],
    ['SW2','switch',78,58,`ROOT ${s.stp.VLAN20}`],
    ['PC1','host',8,86,'VLAN 10'],
    ['PC2','host',36,86,'VLAN 20'],
    ['SRV1','server',92,86,'VLAN 20']
  ];
  const status = (id, kind) => kind==='router' ? (ospf?'good':'bad') : kind==='switch' ? ((stp&&lacp)?'good':'warn') : 'good';
  return <section className="v9-panel v9-topology-panel">
    <div className="v9-panel-head"><div><small>01 / MULTI-FAILURE TOPOLOGY</small><h2>Observe the network, not just the terminal.</h2></div><Badge tone="live">STATE DERIVED</Badge></div>
    <div className="v9-topology-canvas">
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
        <line x1="22" y1="26" x2="78" y2="26" className={ospf?'v9-good-line':'v9-bad-line'}/>
        <line x1="22" y1="26" x2="22" y2="52" className="v9-good-line"/>
        <line x1="78" y1="26" x2="78" y2="52" className="v9-good-line"/>
        <line x1="22" y1="58" x2="78" y2="58" className={lacp?'v9-good-line':'v9-bad-line'}/>
        <line x1="22" y1="64" x2="8" y2="80" className="v9-good-line"/>
        <line x1="22" y1="64" x2="36" y2="80" className={stp?'v9-good-line':'v9-bad-line'}/>
        <line x1="78" y1="64" x2="92" y2="80" className="v9-good-line"/>
      </svg>
      {nodes.map(([id,kind,x,y,detail])=><div key={id} className={`v9-node ${kind}`} style={{left:`${x}%`,top:`${y}%`}}><strong>{id}</strong><small>{detail}</small><i className={status(id,kind)}/></div>)}
      <div className="v9-topology-legend"><span><i className="good"/> verified</span><span><i className="warn"/> dependent</span><span><i className="bad"/> fault</span></div>
    </div>
    <div className="v9-topology-strip"><Stat label="OSPF" value={ospf?'FULL':'DOWN'} tone={ospf?'good':'bad'}/><Stat label="RSTP" value={stp?'ROOT / ROOT':'ROOT MOVED'} tone={stp?'good':'warn'}/><Stat label="LACP" value={lacp?'PO1 UP':'PO1 DEGRADED'} tone={lacp?'good':'bad'}/><Stat label="STATIC BACKUP" value={route?'INSTALLED':'ABSENT'} tone={route?'good':'warn'}/></div>
  </section>;
}

function Terminal({state,setState,device,setDevice,history,setHistory}) {
  const [input,setInput] = useState('');
  const [cmdHistory,setCmdHistory] = useState([]);
  const [histIndex,setHistIndex] = useState(-1);
  const inputRef = useRef(null);
  const dev = state.devices[device];
  const entries = history[device] || [];
  const prompt = `${dev.hostname}${dev.mode==='config'?'(config)':dev.mode==='config-if'?'(config-if)':dev.mode==='config-dhcp'?'(dhcp)':dev.mode==='config-router'?'(config-router)':''}#`;
  const run = raw => {
    const command = String(raw ?? input).trim();
    if(!command) return;
    const result = advancedRun(state, device, command);
    if(command.toLowerCase()==='clear') {
      setHistory(h => ({...h,[device]:[]})); setInput(''); setHistIndex(-1); return;
    }
    setState(result.state);
    setHistory(h => ({...h,[device]:[...(h[device]||[]),{id:`${Date.now()}-${Math.random()}`,command,output:result.output}].slice(-160)}));
    setCmdHistory(h => [command,...h.filter(x=>x!==command)].slice(0,80));
    setInput(''); setHistIndex(-1);
  };
  const quick = HINTS[device] || [];
  return <section className="v9-panel v9-cli-panel">
    <div className="v9-panel-head"><div><small>02 / STATEFUL IOS</small><h2>{dev.hostname} <span className="muted">· {dev.kind.toUpperCase()}</span></h2></div><div className="v9-device-tabs">{DEVICES.map(d=><button key={d} className={device===d?'active':''} onClick={()=>setDevice(d)}>{d}</button>)}</div></div>
    <div className="v9-cli-meta"><span>MODE <b>{dev.mode}</b></span><span>HOSTNAME <b>{dev.hostname}</b></span><span>INTERFACES <b>{Object.keys(dev.interfaces).length}</b></span></div>
    <div className="v9-terminal" onClick={()=>inputRef.current?.focus()}>
      <div className="v9-terminal-banner">DRILLER BILL IOS ENGINE // MULTI-FAILURE PBQ</div>
      {entries.map(e=><div className="v9-term-entry" key={e.id}><div><span>{prompt}</span> {e.command}</div>{e.output&&e.output!=='__CLEAR__'?<pre>{e.output}</pre>:null}</div>)}
      <div className="v9-terminal-input"><span>{prompt}</span><input ref={inputRef} autoFocus value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{
        if(e.key==='Enter'){run();return;} if(e.key==='ArrowUp'){e.preventDefault();const n=Math.min(histIndex+1,cmdHistory.length-1);setHistIndex(n);setInput(cmdHistory[n]||'');} if(e.key==='ArrowDown'){e.preventDefault();const n=Math.max(histIndex-1,-1);setHistIndex(n);setInput(n===-1?'':cmdHistory[n]||'');}
      }} placeholder="inspect, configure, verify…" /></div>
    </div>
    <div className="v9-quickbar">{quick.map(c=><button key={c} onClick={()=>run(c)}>{c}</button>)}</div>
  </section>;
}

function CaseRail({cases,active,setActive,history}) {
  return <section className="v9-panel v9-case-rail"><div className="v9-panel-head"><div><small>03 / ADVANCED CASES</small><h2>Multi-failure workshop.</h2></div><Badge>{cases.length} CASES</Badge></div>{cases.map((c,i)=>{const best=history[c.id]?.best;return <button key={c.id} className={`v9-case-card ${active===i?'active':''}`} onClick={()=>setActive(i)}><div><span>{c.code}</span><strong>{c.title}</strong><small>{c.protocol} · {c.difficulty}</small></div><div className={`v9-case-score ${best===100?'done':''}`}>{best==null?'—':`${best}%`}</div></button>})}</section>;
}

function Brief({caseData,result,onVerify,onSubmit,onReset}) {
  return <section className="v9-panel v9-brief-panel"><div className="v9-panel-head"><div><small>04 / INCIDENT BRIEF</small><h2>{caseData.code} · {caseData.title}</h2></div><Badge tone="orange">{caseData.timeMinutes} MIN</Badge></div><div className="v9-incident"><span>INCIDENT</span><p>{caseData.incident}</p></div><div className="v9-objective-title">REPAIR OBJECTIVES</div><div className="v9-objectives">{(caseData.objectives||[]).map((x,i)=><div key={x}><span>{String(i+1).padStart(2,'0')}</span><b>{x}</b></div>)}</div><div className="v9-actions"><button className="v9-btn primary" onClick={onVerify}>Evaluate network</button><button className="v9-btn" onClick={onSubmit}>Submit PBQ</button><button className="v9-btn" onClick={onReset}>Reset</button></div>{result&&<div className={`v9-grade ${result.ok?'good':''}`}><div className="v9-grade-top"><span>{result.ok?'OBJECTIVE COMPLETE':'IN PROGRESS'}</span><strong>{result.score}%</strong></div><div className="v9-grade-grid">{result.checks.map(c=><div key={c.label} className={c.ok?'good':''}><i>{c.ok?'✓':'·'}</i><span>{c.label}</span></div>)}</div><p>{result.ok?'Every required network state is satisfied.':result.hint}</p></div>}</section>;
}

export default function AdvancedPBQLab({onHome}) {
  const [caseIndex,setCaseIndex] = useState(()=>Number(safeStorage.getItem(`${ADVANCED_STORAGE}:case`))||0);
  const [state,setState] = useState(()=>load(`${ADVANCED_STORAGE}:state:${ADVANCED_CASES[caseIndex].id}`,advancedFixture(ADVANCED_CASES[caseIndex].id)));
  const [device,setDevice] = useState('SW2');
  const [history,setHistory] = useState(()=>load(`${ADVANCED_STORAGE}:terminal`,{R1:[],R2:[],SW1:[],SW2:[]}));
  const [result,setResult] = useState(null);
  const [submissions,setSubmissions] = useState(()=>load(`${ADVANCED_STORAGE}:history`,{}));
  const caseData = ADVANCED_CASES[caseIndex];
  const snapshot = useMemo(()=>advancedSnapshot(state),[state]);

  useEffect(()=>{
    save(`${ADVANCED_STORAGE}:state:${caseData.id}`,state);
    save(`${ADVANCED_STORAGE}:terminal`,history);
    save(`${ADVANCED_STORAGE}:history`,submissions);
    safeStorage.setItem(`${ADVANCED_STORAGE}:case`,String(caseIndex));
  },[state,history,submissions,caseData.id,caseIndex]);

  const loadCase = i => {
    const c = ADVANCED_CASES[i];
    setCaseIndex(i); setState(advancedFixture(c.id)); setHistory({R1:[],R2:[],SW1:[],SW2:[]}); setResult(null);
    setDevice(c.recommended?.[0]||'SW2');
  };
  const verify = () => setResult(evaluateAdvancedCase(state,caseData.id));
  const submit = () => {
    const r = evaluateAdvancedCase(state,caseData.id); setResult(r);
    setSubmissions(h => ({...h,[caseData.id]:{last:r.score,best:Math.max(h[caseData.id]?.best||0,r.score),attempts:(h[caseData.id]?.attempts||0)+1,date:new Date().toISOString()}}));
  };
  const reset = () => loadCase(caseIndex);
  const totalSolved = Object.values(submissions).filter(x=>x.best===100).length;
  const commandCount = Object.values(history).flat().length;

  return <div className="v9-shell">
    <header className="v9-topbar"><button className="v9-brand" onClick={onHome}><strong>DRILLER BILL</strong><span>// ADVANCED PBQ WORKSHOP</span></button><div className="v9-top-status"><i/> MULTI-DEVICE / CYAN / LOCAL-FIRST</div></header>
    <main className="v9-page">
      <section className="v9-hero"><div><small>05 / PERFORMANCE-BASED ASSESSMENT</small><h1>Break the network.<br/><span>Then fix it.</span></h1><p>Advanced cases combine Layer 2 and Layer 3 failures. Gather evidence, make targeted changes across devices, and submit only when the whole topology is healthy.</p></div><div className="v9-hero-stats"><Stat label="CASES SOLVED" value={`${totalSolved}/${ADVANCED_CASES.length}`} tone={totalSolved===ADVANCED_CASES.length?'good':''}/><Stat label="COMMANDS" value={commandCount}/><Stat label="PROTOCOLS" value="5+"/><Stat label="DEVICES" value="4"/></div></section>
      <CaseRail cases={ADVANCED_CASES} active={caseIndex} setActive={loadCase} history={submissions}/>
      <div className="v9-layout">
        <div className="v9-main"><Topology state={state}/><Terminal state={state} setState={setState} device={device} setDevice={setDevice} history={history} setHistory={setHistory}/></div>
        <aside className="v9-side"><Brief caseData={caseData} result={result} onVerify={verify} onSubmit={submit} onReset={reset}/><section className="v9-panel v9-telemetry"><div className="v9-panel-head"><div><small>05 / LIVE TELEMETRY</small><h2>Protocol dependencies.</h2></div></div><div className="v9-telemetry-grid"><Stat label="DHCP" value={snapshot.dhcp?.status||'INIT'} tone={snapshot.dhcp?.status==='BOUND'?'good':'warn'}/><Stat label="NAT" value={`${snapshot.nat.translations.length} XLATE`} tone={snapshot.nat.translations.length?'good':'warn'}/><Stat label="RSTP VLAN 10" value={snapshot.stp.VLAN10||'—'} /><Stat label="RSTP VLAN 20" value={snapshot.stp.VLAN20||'—'} /><Stat label="LACP SW1" value={snapshot.etherchannel.SW1?'FORMED':'DOWN'} tone={snapshot.etherchannel.SW1?'good':'bad'}/><Stat label="LACP SW2" value={snapshot.etherchannel.SW2?'FORMED':'DOWN'} tone={snapshot.etherchannel.SW2?'good':'bad'}/><Stat label="OSPF R1" value={snapshot.ospf.R1} tone={snapshot.ospf.R1==='FULL'?'good':'bad'}/><Stat label="OSPF R2" value={snapshot.ospf.R2} tone={snapshot.ospf.R2==='FULL'?'good':'bad'}/></div></section><section className="v9-panel v9-history"><div className="v9-panel-head"><div><small>06 / SUBMISSION HISTORY</small><h2>Case performance.</h2></div></div>{Object.keys(submissions).length?ADVANCED_CASES.filter(c=>submissions[c.id]).map(c=><div key={c.id} className="v9-history-row"><div><b>{c.code}</b><span>{c.title}</span></div><strong>{submissions[c.id].best}%</strong><small>{submissions[c.id].attempts} attempt{submissions[c.id].attempts===1?'':'s'}</small></div>):<div className="v9-empty">Complete and submit a PBQ to build your case history.</div>}</section></aside>
      </div>
    </main>
  </div>;
}
