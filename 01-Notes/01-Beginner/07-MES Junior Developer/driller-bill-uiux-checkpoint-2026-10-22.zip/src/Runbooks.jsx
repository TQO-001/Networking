import React, { useEffect, useMemo, useState } from 'react';
import { safeStorage, safeSessionStorage } from './storage.js';
import { buildDeviceInventory, CONFIG_INTENTS, planIntent } from './core/device-model.js';
import { agentApplyIntent, agentConnect, agentDevices, agentDiagnostics, agentInspect, agentHealth, agentPreflightIntent, DEVICE_AGENT_URL } from './core/device-agent-client.js';
import UnifiedWorkflowBar from './UnifiedWorkflowBar.jsx';
import { loadCustomRunbooks, planRunbookStep, RUNBOOKS, runbookProgress, saveCustomRunbooks, validateRunbook, verificationForIntent, verifyRunbookStep } from './core/runbooks.js';
import { useNetworkWorkspace } from './context/NetworkWorkspaceContext.jsx';

const AGENT_SETTINGS_KEY = 'drillerBill.deviceAgent.v48';
const RUNBOOK_FOCUS_KEY = 'drillerBill.runbooks.focus.v1';

function Icon({ name, size = 16 }) {
  const paths = {
    book: <><path d="M5 5.5A2.5 2.5 0 0 1 7.5 3H19v17H7.5A2.5 2.5 0 0 0 5 22z"/><path d="M5 5.5v16"/></>,
    play: <path d="M8 5l11 7-11 7V5z" fill="currentColor"/>,
    check: <path d="m5 12 4 4L19 6"/>,
    arrow: <><path d="M5 12h13"/><path d="m13 6 6 6-6 6"/></>,
    plus: <><path d="M12 5v14"/><path d="M5 12h14"/></>,
    link: <><path d="m9.5 14.5 5-5"/><path d="M7 17H5.5A3.5 3.5 0 0 1 2 13.5v0A3.5 3.5 0 0 1 5.5 10H9"/><path d="M15 7h3.5a3.5 3.5 0 0 1 0 7H15"/></>,
    shield: <><path d="M12 3 19 6v5c0 4.3-2.5 7.8-7 10-4.5-2.2-7-5.7-7-10V6z"/><path d="m9 12 2 2 4-4"/></>,
    trash: <><path d="M4 7h16"/><path d="M10 11v6M14 11v6"/><path d="M6 7l1 13h10l1-13"/><path d="M9 7V4h6v3"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

function readAgentSettings() {
  try {
    const local = JSON.parse(safeStorage.getItem(AGENT_SETTINGS_KEY) || '{}');
    const session = JSON.parse(safeSessionStorage.getItem(AGENT_SETTINGS_KEY) || '{}');
    if (Object.hasOwn(local, 'token')) safeStorage.setItem(AGENT_SETTINGS_KEY, JSON.stringify({ url: local.url || '' }));
    return { url: local.url || '', token: session.token || '' };
  } catch { return {}; }
}

function fieldDefaults(intent) {
  return Object.fromEntries((intent?.fields || []).map(field => [field.id, field.options?.[0]?.value ?? '']));
}

export default function Runbooks({ setView }) {
  const { labState } = useNetworkWorkspace();
  const [customRunbooks, setCustomRunbooks] = useState(() => loadCustomRunbooks(safeStorage));
  const allRunbooks = useMemo(() => [...RUNBOOKS, ...customRunbooks], [customRunbooks]);
  const [selectedId, setSelectedId] = useState(() => safeStorage.getItem(RUNBOOK_FOCUS_KEY) || allRunbooks[0]?.id || '');
  const [stepIndex, setStepIndex] = useState(0);
  const [agentUrl, setAgentUrl] = useState(() => readAgentSettings().url || DEVICE_AGENT_URL);
  const [agentToken, setAgentToken] = useState(() => readAgentSettings().token || '');
  const [agentState, setAgentState] = useState({ status: 'unknown', message: 'Not checked' });
  const [agentInventory, setAgentInventory] = useState([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState('');
  const [connected, setConnected] = useState(false);
  const [inspection, setInspection] = useState(null);
  const [diagnostics, setDiagnostics] = useState(null);
  const [verification, setVerification] = useState({});
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState(null);
  const [message, setMessage] = useState('');
  const [showBuilder, setShowBuilder] = useState(false);
  const [builder, setBuilder] = useState({ title: '', summary: '', category: 'custom', targetKind: 'any', tags: '', steps: [] });
  const [builderIntentType, setBuilderIntentType] = useState(CONFIG_INTENTS[0]?.id || '');
  const [builderFields, setBuilderFields] = useState(() => fieldDefaults(CONFIG_INTENTS[0]));

  const workspaceDevices = useMemo(() => buildDeviceInventory(labState), [labState]);
  const devices = useMemo(() => {
    const map = new Map(workspaceDevices.map(device => [device.id, { ...device, source: 'workspace' }]));
    for (const device of agentInventory) map.set(device.id, { ...device, source: 'agent' });
    return [...map.values()];
  }, [workspaceDevices, agentInventory]);
  const runbook = allRunbooks.find(item => item.id === selectedId) || allRunbooks[0];
  const step = runbook?.steps?.[stepIndex];
  const selectedDevice = devices.find(item => item.id === selectedDeviceId) || devices.find(item => runbook && (runbook.targetKind === 'any' || item.kind === runbook.targetKind));
  const plan = useMemo(() => step && selectedDevice ? planRunbookStep(runbook, stepIndex, selectedDevice) : null, [runbook, stepIndex, selectedDevice]);
  const progress = useMemo(() => runbookProgress(runbook, verification), [runbook, verification]);
  const builderIntent = CONFIG_INTENTS.find(item => item.id === builderIntentType) || CONFIG_INTENTS[0];
  const builderDevice = devices.find(item => item.kind === builder.targetKind) || devices[0];
  const builderPlan = builderDevice && builderIntent ? planIntent({ type: builderIntent.id, fields: builderFields }, builderDevice) : null;

  useEffect(() => {
    if (!allRunbooks.some(item => item.id === selectedId)) setSelectedId(allRunbooks[0]?.id || '');
  }, [allRunbooks, selectedId]);

  useEffect(() => {
    if (selectedId) safeStorage.setItem(RUNBOOK_FOCUS_KEY, selectedId);
  }, [selectedId]);

  useEffect(() => {
    if (!selectedDeviceId && selectedDevice) setSelectedDeviceId(selectedDevice.id);
  }, [selectedDeviceId, selectedDevice]);

  useEffect(() => {
    const matching = devices.find(device => runbook && (runbook.targetKind === 'any' || device.kind === runbook.targetKind));
    if (matching && (!selectedDeviceId || devices.find(device => device.id === selectedDeviceId)?.kind !== runbook?.targetKind)) {
      setSelectedDeviceId(matching.id);
    }
  }, [runbook?.id, runbook?.targetKind, devices]);

  useEffect(() => {
    if (!runbook) return;
    setStepIndex(0);
    setVerification({});
    setPreview(null);
    setMessage('');
  }, [runbook?.id]);

  useEffect(() => {
    if (!runbook?.steps?.length) return;
    setStepIndex(current => Math.min(current, runbook.steps.length - 1));
  }, [runbook?.steps?.length]);

  const refreshAgent = async () => {
    if (!agentToken) {
      setAgentState({ status: 'locked', message: 'Enter the Device Agent token to access live devices.' });
      return [];
    }
    setBusy(true);
    try {
      const health = await agentHealth({ baseUrl: agentUrl });
      const result = await agentDevices({ baseUrl: agentUrl, token: agentToken });
      setAgentInventory(result.devices || []);
      setAgentState({ status: 'ready', message: `${result.devices?.length || 0} device${result.devices?.length === 1 ? '' : 's'} available · ${health.protocol || 'agent'}` });
      safeStorage.setItem(AGENT_SETTINGS_KEY, JSON.stringify({ url: agentUrl })); safeSessionStorage.setItem(AGENT_SETTINGS_KEY, JSON.stringify({ token: agentToken }));
      return result.devices || [];
    } catch (error) {
      setAgentState({ status: 'error', message: error.message });
      return [];
    } finally { setBusy(false); }
  };

  const connectSelected = async () => {
    if (!selectedDevice?.id || !agentToken) return;
    setBusy(true);
    try {
      const result = await agentConnect(selectedDevice.id, { baseUrl: agentUrl, token: agentToken });
      setConnected(true);
      setAgentInventory(current => current.map(item => item.id === selectedDevice.id ? result.result.device : item));
      setMessage(`${selectedDevice.id} connected. The runbook remains step-gated.`);
    } catch (error) {
      setConnected(false);
      setMessage(error.message);
    } finally { setBusy(false); }
  };

  const refreshEvidence = async () => {
    if (!selectedDevice?.id || !agentToken || !connected) return;
    setBusy(true);
    try {
      const [inspectionResult, diagnosticsResult] = await Promise.all([
        agentInspect(selectedDevice.id, { baseUrl: agentUrl, token: agentToken }),
        agentDiagnostics(selectedDevice.id, { baseUrl: agentUrl, token: agentToken }),
      ]);
      const nextInspection = inspectionResult.report || null;
      const nextDiagnostics = diagnosticsResult.diagnostics || null;
      setInspection(nextInspection);
      setDiagnostics(nextDiagnostics);
      const nextVerification = {};
      runbook.steps.forEach(item => { nextVerification[item.id] = verifyRunbookStep(item, { inspection: nextInspection, diagnostics: nextDiagnostics }); });
      setVerification(nextVerification);
      setMessage('Evidence refreshed from the device. Verification is based on observed state, not on command history alone.');
      return { inspection: nextInspection, diagnostics: nextDiagnostics };
    } catch (error) {
      setMessage(error.message);
      return null;
    } finally { setBusy(false); }
  };

  const previewStep = () => {
    if (!step || !plan?.valid) return;
    setPreview(plan);
    setMessage(`Step ${stepIndex + 1} is ready for review.`);
  };

  const applyStep = async () => {
    if (!step || !plan?.valid || !selectedDevice?.id || !connected || busy) return;
    setBusy(true);
    try {
      const preflightResult = await agentPreflightIntent(selectedDevice.id, step.intent, { baseUrl: agentUrl, token: agentToken });
      const preflight = preflightResult.result;
      if (!preflight?.changeId) throw new Error('Change preflight did not return an approval record.');
      if (!preflight.preflight?.valid) throw new Error(preflight.preflight?.summary || 'Change preflight blocked this step.');
      const result = await agentApplyIntent(selectedDevice.id, step.intent, { baseUrl: agentUrl, token: agentToken, changeId: preflight.changeId });
      setPreview(result.result?.transcript || null);
      const inspectionResult = await agentInspect(selectedDevice.id, { baseUrl: agentUrl, token: agentToken });
      const diagnosticsResult = await agentDiagnostics(selectedDevice.id, { baseUrl: agentUrl, token: agentToken });
      const nextInspection = inspectionResult.report || null;
      const nextDiagnostics = diagnosticsResult.diagnostics || null;
      setInspection(nextInspection);
      setDiagnostics(nextDiagnostics);
      const resultVerification = verifyRunbookStep(step, { inspection: nextInspection, diagnostics: nextDiagnostics });
      setVerification(current => ({ ...current, [step.id]: resultVerification }));
      setMessage(resultVerification.completed ? `Step verified: ${step.label}` : `Step applied, but verification did not pass yet.`);
    } catch (error) {
      setMessage(error.message);
    } finally { setBusy(false); }
  };

  const addBuilderStep = () => {
    if (!builderIntent?.id) return;
    const stepNumber = builder.steps.length + 1;
    const summary = builderIntent.description || 'Review and apply this configuration change.';
    setBuilder(current => ({ ...current, steps: [...current.steps, { id: `step-${stepNumber}`, label: builderIntent.title, summary, intent: { type: builderIntent.id, fields: { ...builderFields } }, verify: verificationForIntent({ type: builderIntent.id, fields: { ...builderFields } }) }] }));
  };

  const removeBuilderStep = (index) => setBuilder(current => ({ ...current, steps: current.steps.filter((_, itemIndex) => itemIndex !== index).map((item, itemIndex) => ({ ...item, id: `step-${itemIndex + 1}` })) }));

  const saveBuilder = () => {
    const next = {
      id: `custom-${Date.now()}`,
      title: builder.title,
      summary: builder.summary,
      category: builder.category,
      targetKind: builder.targetKind,
      tags: builder.tags.split(',').map(item => item.trim()).filter(Boolean),
      source: 'custom',
      steps: builder.steps,
    };
    const normalized = { ...next, version: '1.0.0' };
    const validation = validateRunbook(normalized);
    if (!validation.valid) { setMessage(validation.errors.join(' ')); return; }
    const saved = saveCustomRunbooks(safeStorage, [...customRunbooks, normalized]);
    setCustomRunbooks(saved);
    setSelectedId(normalized.id);
    setShowBuilder(false);
    setBuilder({ title: '', summary: '', category: 'custom', targetKind: 'any', tags: '', steps: [] });
    setMessage('Custom runbook saved locally.');
  };

  const deleteCustom = () => {
    if (!runbook || runbook.source === 'builtin') return;
    const saved = saveCustomRunbooks(safeStorage, customRunbooks.filter(item => item.id !== runbook.id));
    setCustomRunbooks(saved);
    setSelectedId(RUNBOOKS[0]?.id || '');
    setMessage('Custom runbook removed from local storage.');
  };

  if (!runbook) return <main className="page runbooks-page"><UnifiedWorkflowBar view="runbooks" setView={setView}/><section className="panel runbook-empty"><h1>No runbooks available.</h1><p>Create a custom runbook to get started.</p></section></main>;

  return <main className="page runbooks-page"><UnifiedWorkflowBar view="runbooks" setView={setView}/>
    <section className="runbook-hero">
      <div><div className="eyebrow">ENGINEERING / RUNBOOKS</div><h1>Procedures that <span>operate.</span></h1><p>Turn repeatable network jobs into reviewed procedures connected to devices, intents, verification evidence and configuration history.</p></div>
      <div className="runbook-hero-stats"><div><strong>{allRunbooks.length}</strong><span>runbooks</span></div><div><strong>{runbook.steps.length}</strong><span>steps in procedure</span></div><div><strong>{progress.percent}%</strong><span>verified</span></div></div>
    </section>

    <section className="runbook-layout">
      <aside className="panel runbook-index">
        <div className="runbook-index-head"><div><div className="kicker">PROCEDURE LIBRARY</div><h2>{allRunbooks.length} available</h2></div><button className="button" onClick={() => setShowBuilder(value => !value)}><Icon name="plus" size={13}/>{showBuilder ? 'Close builder' : 'New runbook'}</button></div>
        <div className="runbook-library">{allRunbooks.map(item => <button key={item.id} className={`runbook-library-item ${item.id === runbook.id ? 'active' : ''}`} onClick={() => setSelectedId(item.id)}><div><span>{item.category} · {item.difficulty}</span><strong>{item.title}</strong><small>{item.summary}</small></div><b>{item.steps.length}</b></button>)}</div>
      </aside>

      <section className="runbook-main">
        <header className="panel runbook-head">
          <div><span className="runbook-label">{runbook.category.toUpperCase()} · {runbook.difficulty}</span><h2>{runbook.title}</h2><p>{runbook.description || runbook.summary}</p><div className="runbook-tags">{(runbook.tags || []).map(tag => <span key={tag}>#{tag}</span>)}</div></div>
          <div className="runbook-head-actions">{runbook.source === 'custom' && <button className="button danger" onClick={deleteCustom}><Icon name="trash" size={13}/> Delete</button>}</div>
        </header>

        <section className="panel runbook-target">
          <div className="runbook-section-head"><div><div className="kicker">01 / TARGET</div><h3>Choose the device this procedure will operate on.</h3></div><span className={`runbook-agent-state ${agentState.status}`}>{agentState.status.toUpperCase()}</span></div>
          <div className="runbook-target-grid"><label><span>DEVICE</span><select value={selectedDevice?.id || ''} onChange={event => { setSelectedDeviceId(event.target.value); setConnected(false); setInspection(null); setDiagnostics(null); setVerification({}); }}>{devices.map(device => <option key={device.id} value={device.id}>{device.id} · {device.kind} · {device.source}</option>)}</select></label><label><span>AGENT URL</span><input value={agentUrl} onChange={event => setAgentUrl(event.target.value)} /></label><label><span>AGENT TOKEN</span><input value={agentToken} onChange={event => setAgentToken(event.target.value)} type="password" /></label></div>
          <div className="runbook-target-actions"><button className="button" onClick={refreshAgent} disabled={busy}>Refresh devices</button><button className="button" onClick={connectSelected} disabled={busy || !selectedDevice?.id || !agentToken}>{connected ? 'Connected' : 'Connect device'}</button><button className="button primary" onClick={refreshEvidence} disabled={busy || !connected}>{busy ? 'Working…' : 'Inspect & verify'}</button><div className={`runbook-connection ${connected ? 'connected' : ''}`}><i/>{connected ? `Connected to ${selectedDevice?.id}` : 'No active device session'}</div></div>
          <div className="runbook-agent-note"><Icon name="shield" size={13}/><span>{agentState.message}. Runbook actions still require explicit step application; there is no unattended “apply all” path.</span></div>
        </section>

        <div className="runbook-work-grid">
          <section className="panel runbook-steps">
            <div className="runbook-section-head"><div><div className="kicker">02 / PROCEDURE</div><h3>{progress.completed}/{progress.total} verified</h3></div><span>{progress.percent}%</span></div>
            <div className="runbook-progress"><i style={{ width: `${progress.percent}%` }}/></div>
            <div className="runbook-step-list">{runbook.steps.map((item, index) => { const result = verification[item.id]; return <button key={item.id} className={`runbook-step ${index === stepIndex ? 'selected' : ''} ${result?.completed ? 'complete' : ''}`} onClick={() => setStepIndex(index)}><span>{result?.completed ? <Icon name="check" size={13}/> : String(index + 1).padStart(2, '0')}</span><div><strong>{item.label}</strong><small>{result?.detail || item.summary}</small></div><b>{result?.completed ? 'VERIFIED' : 'OPEN'}</b></button>; })}</div>
          </section>

          <section className="panel runbook-step-detail">
            <div className="runbook-section-head"><div><div className="kicker">03 / CHANGE</div><h3>{step?.label}</h3></div><span>STEP {String(stepIndex + 1).padStart(2, '0')}</span></div>
            <p className="runbook-step-summary">{step?.summary}</p>
            {preview && <div className="runbook-preview"><div className="runbook-preview-head"><span>COMMAND PLAN</span><b>{plan?.valid ? 'VALIDATED' : 'RESULT'}</b></div>{Array.isArray(preview) ? preview.map((entry, index) => <div className="runbook-terminal-line" key={`${entry}-${index}`}><span>{String(index + 1).padStart(2, '0')}</span><code>{typeof entry === 'string' ? entry : JSON.stringify(entry)}</code></div>) : <pre>{JSON.stringify(preview, null, 2)}</pre>}</div>}
            {!preview && plan && <div className={`runbook-plan ${plan.valid ? 'valid' : 'invalid'}`}><div><span>COMMAND PLAN</span><strong>{plan.valid ? `${plan.commands.length} commands` : 'Needs input'}</strong></div>{plan.errors?.length ? <p>{plan.errors.join(' ')}</p> : <div>{(plan.displayCommands || plan.commands).map((command, index) => <code key={`${command}-${index}`}>{command}</code>)}</div>}</div>}
            {verification[step?.id] && <div className={`runbook-verification ${verification[step.id].completed ? 'complete' : 'pending'}`}><div><span>VERIFICATION</span><strong>{verification[step.id].completed ? 'PASS' : 'NOT CONFIRMED'}</strong></div><p>{verification[step.id].detail}</p></div>}
            <div className="runbook-step-actions"><button className="button" onClick={previewStep} disabled={!plan?.valid || busy}><Icon name="book" size={13}/> Review plan</button><button className="button primary" onClick={applyStep} disabled={!plan?.valid || !connected || busy}><Icon name="play" size={12}/>{busy ? 'Applying…' : 'Apply & verify'}</button>{stepIndex < runbook.steps.length - 1 && <button className="button" onClick={() => setStepIndex(current => current + 1)} disabled={!verification[step?.id]?.completed}>Next verified step <Icon name="arrow" size={12}/></button>}</div>
            {message && <div className="runbook-message">{message}</div>}
          </section>
        </div>

        {progress.valid && <section className="panel runbook-complete"><div><span>PROCEDURE COMPLETE</span><h3>Every step is currently verified.</h3><p>The device state satisfies this runbook. The underlying Device Agent has also captured configuration history as each intent was applied.</p></div><button className="button primary" onClick={refreshEvidence} disabled={busy}>Re-verify procedure</button></section>}

        {showBuilder && <section className="panel runbook-builder"><div className="runbook-section-head"><div><div className="kicker">04 / AUTHORING</div><h3>Create a reusable procedure</h3></div><span>LOCAL</span></div><div className="runbook-builder-grid"><label><span>TITLE</span><input value={builder.title} onChange={event => setBuilder(current => ({ ...current, title: event.target.value }))} placeholder="Branch switch onboarding" /></label><label><span>CATEGORY</span><input value={builder.category} onChange={event => setBuilder(current => ({ ...current, category: event.target.value }))} placeholder="switching" /></label><label><span>TARGET</span><select value={builder.targetKind} onChange={event => setBuilder(current => ({ ...current, targetKind: event.target.value }))}><option value="any">Any device</option><option value="switch">Switch</option><option value="router">Router</option></select></label><label className="wide"><span>SUMMARY</span><input value={builder.summary} onChange={event => setBuilder(current => ({ ...current, summary: event.target.value }))} placeholder="Describe the operational outcome." /></label><label className="wide"><span>TAGS</span><input value={builder.tags} onChange={event => setBuilder(current => ({ ...current, tags: event.target.value }))} placeholder="baseline, vlan, access" /></label></div>
          <div className="runbook-builder-step"><div className="runbook-builder-step-head"><div><span>ADD STEP</span><strong>Use the same typed intents as Configuration.</strong></div></div><div className="runbook-builder-controls"><label><span>INTENT</span><select value={builderIntentType} onChange={event => { const next = CONFIG_INTENTS.find(item => item.id === event.target.value) || CONFIG_INTENTS[0]; setBuilderIntentType(next.id); setBuilderFields(fieldDefaults(next)); }}>{CONFIG_INTENTS.map(item => <option key={item.id} value={item.id}>{item.title}</option>)}</select></label>{builderIntent?.fields?.map(field => <label key={field.id}><span>{field.label}</span>{field.input === 'select' ? <select value={builderFields[field.id] ?? ''} onChange={event => setBuilderFields(current => ({ ...current, [field.id]: event.target.value }))}>{field.options.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}</select> : <input type={field.input} value={builderFields[field.id] ?? ''} onChange={event => setBuilderFields(current => ({ ...current, [field.id]: event.target.value }))} placeholder={field.placeholder} />}</label>)}<button className="button" onClick={addBuilderStep} disabled={!builderIntent?.id || !builderPlan?.valid}><Icon name="plus" size={13}/> Add step</button></div></div>
          <div className="runbook-builder-list">{builder.steps.map((item, index) => <div key={item.id}><span>{String(index + 1).padStart(2, '0')}</span><div><strong>{item.label}</strong><small>{item.intent.type}</small></div><button className="text-button" onClick={() => removeBuilderStep(index)}>Remove</button></div>)}{!builder.steps.length && <div className="runbook-builder-empty">No steps yet. Add a typed intent above; verification can be strengthened later with device-state checks.</div>}</div>
          <div className="runbook-builder-footer"><span>Custom runbooks are stored locally in this browser.</span><button className="button primary" onClick={saveBuilder} disabled={!builder.title.trim() || !builder.steps.length}>Save runbook</button></div>
        </section>}
      </section>
    </section>
  </main>;
}
