import { useCallback, useEffect, useState } from 'react';
import { safeStorage } from '../storage.js';

const FONT_SIZE_KEY = 'drillerBill.terminal.fontSize.v1';
const FOLLOW_KEY = 'drillerBill.terminal.autoFollow.v1';
const MIN_FONT_SIZE = 16;
const MAX_FONT_SIZE = 24;

function readFontSize() {
  const value = Number(safeStorage.getItem(FONT_SIZE_KEY));
  return Number.isFinite(value) && value >= MIN_FONT_SIZE && value <= MAX_FONT_SIZE
    ? value
    : 18;
}

export function useTerminalPreferences() {
  const [fontSize, setFontSize] = useState(readFontSize);
  const [autoFollow, setAutoFollow] = useState(() => safeStorage.getItem(FOLLOW_KEY) !== 'false');

  useEffect(() => { safeStorage.setItem(FONT_SIZE_KEY, String(fontSize)); }, [fontSize]);
  useEffect(() => { safeStorage.setItem(FOLLOW_KEY, String(autoFollow)); }, [autoFollow]);

  const changeFontSize = useCallback((delta) => {
    setFontSize(current => Math.min(MAX_FONT_SIZE, Math.max(MIN_FONT_SIZE, current + Math.sign(delta) * 2)));
  }, []);
  const toggleAutoFollow = useCallback(() => setAutoFollow(value => !value), []);

  return { fontSize, changeFontSize, autoFollow, toggleAutoFollow };
}

export const TERMINAL_FONT_LIMITS = Object.freeze({ min: MIN_FONT_SIZE, max: MAX_FONT_SIZE, default: 18 });
