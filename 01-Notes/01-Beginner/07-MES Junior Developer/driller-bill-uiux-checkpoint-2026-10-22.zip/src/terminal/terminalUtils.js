const SECRET_LINE = /^(\s*(?:(?:enable|username\s+\S+)\s+(?:password|secret)|(?:password|secret|wpa-psk|pre-shared-key)\b)(?:\s+\S+)*?\s+)(?:\S.*)$/i;
const SECRET_COMMAND = /\b(password|secret|pre-shared-key|wpa-psk)\s+(?:0|5|7|8|9)?\s*\S+/i;

export function redactTerminalSecrets(value) {
  return String(value ?? '').split('\n').map(line => {
    const match = line.match(SECRET_LINE);
    if (match) return `${match[1]}<redacted>`;
    if (SECRET_COMMAND.test(line) && /(?:password|secret|pre-shared-key|wpa-psk)/i.test(line)) {
      return line.replace(/\b(password|secret|pre-shared-key|wpa-psk)(\s+(?:0|5|7|8|9)?\s*)\S+/i, '$1$2<redacted>');
    }
    return line;
  }).join('\n');
}

export function formatTerminalTranscript(entries, prompt = 'DB>') {
  return (Array.isArray(entries) ? entries : []).map(entry => {
    const command = String(entry?.command ?? '[unknown command]');
    const output = Array.isArray(entry?.output) ? entry.output.join('\n') : String(entry?.output ?? '');
    const lines = [`${prompt} ${command}`];
    if (output) lines.push(redactTerminalSecrets(output));
    return lines.join('\n');
  }).join('\n\n');
}

export async function copyTerminalText(value) {
  const text = String(value ?? '');
  if (!text) return false;
  try {
    if (globalThis.navigator?.clipboard?.writeText) {
      await globalThis.navigator.clipboard.writeText(text);
      return true;
    }
  } catch { /* Use the compatibility fallback below when browser permissions deny clipboard access. */ }

  try {
    if (typeof document === 'undefined') return false;
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    textarea.style.pointerEvents = 'none';
    document.body.appendChild(textarea);
    textarea.select();
    const copied = document.execCommand?.('copy') === true;
    textarea.remove();
    return copied;
  } catch {
    return false;
  }
}
