/** Complete only from an explicitly supplied safe command catalogue. */
export function completeCommandPrefix(value, commands) {
  const original = String(value ?? '');
  const prefix = original.trimStart();
  if (!prefix || !Array.isArray(commands) || commands.length === 0) return original;

  const candidates = commands.filter(command => String(command).toLowerCase().startsWith(prefix.toLowerCase()));
  if (!candidates.length) return original;
  if (candidates.length === 1) return candidates[0];

  let common = candidates[0];
  for (const candidate of candidates.slice(1)) {
    while (common && !candidate.toLowerCase().startsWith(common.toLowerCase())) common = common.slice(0, -1);
  }
  return common.length > prefix.length ? common : original;
}

/** Insert text at the selection/caret without losing the text after the caret. */
export function insertAtSelection(value, start, end, insertion) {
  const text = String(value ?? '');
  const from = Math.max(0, Math.min(text.length, Number.isFinite(start) ? start : text.length));
  const to = Math.max(from, Math.min(text.length, Number.isFinite(end) ? end : from));
  const added = String(insertion ?? '');
  return { value: `${text.slice(0, from)}${added}${text.slice(to)}`, caret: from + added.length };
}

/** Move through a newest-first command list while preserving a draft. */
export function stepCommandHistory({ history, index, direction, draft, currentValue }) {
  const entries = Array.isArray(history) ? history : [];
  const currentIndex = Number.isInteger(index) ? index : -1;
  if (!entries.length || !['up', 'down'].includes(direction)) {
    return { index: currentIndex, value: String(currentValue ?? ''), draft: String(draft ?? '') };
  }

  if (direction === 'up') {
    const nextIndex = Math.min(currentIndex + 1, entries.length - 1);
    return {
      index: nextIndex,
      value: String(entries[nextIndex] ?? ''),
      draft: currentIndex === -1 ? String(currentValue ?? '') : String(draft ?? ''),
    };
  }

  if (currentIndex <= 0) return { index: -1, value: String(draft ?? ''), draft: '' };
  const nextIndex = currentIndex - 1;
  return { index: nextIndex, value: String(entries[nextIndex] ?? ''), draft: String(draft ?? '') };
}
