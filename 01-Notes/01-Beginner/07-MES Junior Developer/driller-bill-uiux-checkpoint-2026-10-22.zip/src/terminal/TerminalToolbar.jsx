import React, { useState } from 'react';

export default function TerminalToolbar({
  fontSize = 18,
  onFontSizeChange,
  autoFollow = true,
  onToggleAutoFollow,
  expanded = false,
  onToggleExpanded,
  onCopy,
  onClear,
}) {
  const [feedback, setFeedback] = useState('');

  const copy = async () => {
    try {
      const copied = await onCopy?.();
      setFeedback(copied ? 'Output copied (secrets redacted).' : 'Could not copy output.');
    } catch {
      setFeedback('Could not copy output.');
    }
    window.setTimeout(() => setFeedback(''), 2600);
  };

  return <div className="terminal-toolbar-v1" role="group" aria-label="Terminal controls">
    <div className="terminal-font-controls" role="group" aria-label="Terminal text size">
      <span className="terminal-control-label">TEXT</span>
      <button type="button" className="terminal-tool-button terminal-font-step" onClick={() => onFontSizeChange?.(-1)} disabled={fontSize <= 16} aria-label="Decrease terminal text size">A−</button>
      <output className="terminal-font-value" aria-live="polite">{fontSize}px</output>
      <button type="button" className="terminal-tool-button terminal-font-step" onClick={() => onFontSizeChange?.(1)} disabled={fontSize >= 24} aria-label="Increase terminal text size">A+</button>
    </div>
    <button type="button" className={`terminal-tool-button ${autoFollow ? 'selected' : ''}`} onClick={onToggleAutoFollow} aria-pressed={autoFollow} title="Keep the newest terminal output in view">{autoFollow ? 'Following output' : 'Follow output'}</button>
    <button type="button" className="terminal-tool-button" onClick={copy} disabled={!onCopy}>Copy output</button>
    {onClear && <button type="button" className="terminal-tool-button" onClick={onClear}>Clear screen</button>}
    {onToggleExpanded && <button type="button" className="terminal-tool-button terminal-expand-button" onClick={onToggleExpanded} aria-pressed={expanded}>{expanded ? 'Exit expanded view' : 'Expand terminal'}</button>}
    <span className="terminal-tool-feedback" role="status" aria-live="polite">{feedback}</span>
  </div>;
}
