import React, { createContext, useCallback, useContext, useMemo } from 'react';

const NetworkWorkspaceContext = createContext(null);

export function NetworkWorkspaceProvider({ value, children }) {
  const updateLabState = useCallback((updater) => {
    value.setLabState((current) => {
      const next = typeof updater === 'function' ? updater(current) : updater;
      return value.prepareLiveLabState(next);
    });
  }, [value]);

  const contextValue = useMemo(() => ({
    labState: value.labState,
    setLabState: updateLabState,
    topology: value.topology,
    setTopology: value.setTopology,
    resetLiveNetwork: value.resetLiveNetwork,
    resetTopology: value.resetTopology,
    workspaceRevision: value.workspaceRevision,
  }), [value.labState, updateLabState, value.topology, value.setTopology, value.resetLiveNetwork, value.resetTopology, value.workspaceRevision]);

  return <NetworkWorkspaceContext.Provider value={contextValue}>{children}</NetworkWorkspaceContext.Provider>;
}

export function useNetworkWorkspace() {
  const context = useContext(NetworkWorkspaceContext);
  if (!context) throw new Error('useNetworkWorkspace must be used inside NetworkWorkspaceProvider');
  return context;
}
