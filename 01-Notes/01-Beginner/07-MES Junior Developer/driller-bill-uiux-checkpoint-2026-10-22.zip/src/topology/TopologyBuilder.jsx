import React, { useEffect, useMemo, useRef, useState } from 'react';
import { DEVICE_TYPES, addDevice, makePorts, addLink, cloneTopology, demoTopology, exportTopology, findPath, importTopology, isLinkHealthy, removeDevice, removeLink, topologyStats, updateDevice, updateLink, validateTopology } from '../core/topology-engine.js';
import { useNetworkWorkspace } from '../context/NetworkWorkspaceContext.jsx';

const TYPE_ORDER = ['router','switch','host','server','wireless'];

function TypeGlyph({type}) {
  const icon = { router:'R', switch:'SW', host:'PC', server:'SV', wireless:'AP' }[type] || '?';
  return <span className={`tb-glyph tb-glyph-${type}`}>{icon}</span>;
}

function SectionTitle({eyebrow, title, right=null}) { return <div className="tb-section-head"><div><span>{eyebrow}</span><h2>{title}</h2></div>{right}</div>; }

export default function TopologyBuilder({ onHome }) {
  const { topology, setTopology, resetTopology, labState } = useNetworkWorkspace();
  const [selected, setSelected] = useState({ type: null, id: null });
  const [connectMode, setConnectMode] = useState(false);
  const [connectSource, setConnectSource] = useState(null);
  const [linkKind, setLinkKind] = useState('copper');
  const [source, setSource] = useState('');
  const [target, setTarget] = useState('');
  const [pathResult, setPathResult] = useState(null);
  const [message, setMessage] = useState('');
  const [drag, setDrag] = useState(null);
  const fileRef = useRef(null);
  const canvasRef = useRef(null);

  const stats = topologyStats(topology);
  const liveDevices = Object.keys(labState?.devices || {}).filter(name => topology.devices.some(d => d.name === name)).length;
  const validation = useMemo(() => validateTopology(topology), [topology]);
  const selectedDevice = selected.type === 'device' ? topology.devices.find(d => d.id === selected.id) : null;
  const selectedLink = selected.type === 'link' ? topology.links.find(l => l.id === selected.id) : null;

  const flashTimer = useRef(null);
  const flash = (text) => { setMessage(text); window.clearTimeout(flashTimer.current); flashTimer.current = window.setTimeout(() => setMessage(''), 2200); };

  const update = (next) => setTopology(next);

  const add = (type) => {
    const next = addDevice(topology, type);
    setTopology(next);
    const d = next.devices[next.devices.length - 1];
    setSelected({ type:'device', id:d.id });
    flash(`${DEVICE_TYPES[type].label} added.`);
  };

  const beginConnect = (id) => {
    if (!connectMode) return;
    if (!connectSource) { setConnectSource(id); flash('Select the second device.'); return; }
    if (connectSource === id) return;
    setTopology(addLink(topology, connectSource, id, linkKind));
    setConnectSource(null);
    flash('Link added.');
  };

  const handleNodePointerDown = (event, id) => {
    event.stopPropagation();
    setSelected({ type:'device', id });
    if (connectMode) { beginConnect(id); return; }
    const rect = canvasRef.current.getBoundingClientRect();
    setDrag({ id, dx: event.clientX - rect.left - topology.devices.find(d => d.id === id).x, dy: event.clientY - rect.top - topology.devices.find(d => d.id === id).y });
    event.currentTarget.setPointerCapture?.(event.pointerId);
  };

  const handleMove = (event) => {
    if (!drag) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const x = Math.max(58, Math.min(942, event.clientX - rect.left - drag.dx));
    const y = Math.max(58, Math.min(582, event.clientY - rect.top - drag.dy));
    setTopology(prev => updateDevice(prev, drag.id, { x, y }));
  };

  const endDrag = () => setDrag(null);

  const handleCanvasDown = () => { setSelected({type:null,id:null}); if (connectMode && connectSource) setConnectSource(null); };

  const removeSelected = () => {
    if (selectedDevice) { setTopology(removeDevice(topology, selectedDevice.id)); setSelected({type:null,id:null}); flash('Device removed.'); }
    else if (selectedLink) { setTopology(removeLink(topology, selectedLink.id)); setSelected({type:null,id:null}); flash('Link removed.'); }
  };

  const runPath = () => {
    if (!source || !target) return;
    const path = findPath(topology, source, target);
    setPathResult(path);
  };

  const doExport = () => {
    const blob = new Blob([exportTopology(topology)], { type: 'application/json' });
    const href = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = href; a.download = `${topology.name.toLowerCase().replace(/[^a-z0-9]+/g,'-') || 'topology'}.pftopology.json`; a.click(); URL.revokeObjectURL(href);
    flash('Topology exported.');
  };

  const doImport = (file) => {
    const reader = new FileReader(); reader.onload = () => {
      try { setTopology(importTopology(reader.result)); setSelected({type:null,id:null}); setPathResult(null); flash('Topology imported.'); }
      catch (e) { flash(e.message || 'Import failed.'); }
    }; reader.readAsText(file);
  };

  const reset = () => { resetTopology(); setSelected({type:null,id:null}); setPathResult(null); flash('Demo topology restored.'); };

  const names = Object.fromEntries(topology.devices.map(d => [d.id, d.name]));
  const pathNames = pathResult?.map(id => names[id]) || [];

  return <div className="tb-shell">
    <header className="tb-topbar">
      <button className="tb-back" onClick={onHome}>← Console</button>
      <div className="tb-brand"><strong>Driller Bill</strong><span>TOPOLOGY BUILDER / DESIGN WORKBENCH</span></div>
      <div className="tb-top-actions"><button onClick={doExport}>Export JSON</button><button onClick={()=>fileRef.current?.click()}>Import</button><input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={e=>e.target.files?.[0]&&doImport(e.target.files[0])}/></div>
    </header>

    <main className="tb-page">
      <section className="tb-hero">
        <div><div className="tb-eyebrow">03 / NETWORK WORKBENCH</div><h1>Draw the network.<br/><span>Then make it real.</span></h1><p>Build a reusable topology, inspect its health, trace paths, and prepare it for future stateful labs. Nodes and links are first-class data, not decoration.</p></div>
        <div className="tb-hero-stats"><div><span>Devices</span><strong>{stats.devices}</strong></div><div><span>Links</span><strong>{stats.links}</strong></div><div><span>Healthy</span><strong className={stats.degraded?'warn':'good'}>{stats.healthy}</strong></div><div><span>Hosts</span><strong>{stats.hosts}</strong></div></div>
      </section>

      <div className="tb-layout">
        <section className="tb-canvas-panel">
          <div className="tb-panelbar"><div><span>TOPOLOGY</span><strong>{topology.name}</strong></div><div className="tb-panel-actions"><button className={connectMode?'active':''} onClick={()=>{setConnectMode(v=>!v);setConnectSource(null);}}>{connectMode?'Connecting…':'Connect nodes'}</button><button onClick={reset}>Reset</button></div></div>
          <div className="tb-live-banner"><i className={liveDevices===stats.devices?'':'warn'}/><span>{liveDevices}/{stats.devices} topology devices are mapped into the canonical network state. CLI runtime is reflected on ports without overwriting design state.</span></div>
          <div className="tb-tool-rail">
            {TYPE_ORDER.map(type => <button key={type} onClick={()=>add(type)} title={`Add ${DEVICE_TYPES[type].label}`}><TypeGlyph type={type}/><span>{DEVICE_TYPES[type].label}</span></button>)}
            <div className="tb-tool-sep"/>
            <label>LINK<select value={linkKind} onChange={e=>setLinkKind(e.target.value)}><option value="copper">Copper</option><option value="trunk">802.1Q trunk</option><option value="fiber">Fiber</option><option value="wireless">Wireless</option></select></label>
          </div>
          <div ref={canvasRef} className="tb-canvas" onPointerMove={handleMove} onPointerUp={endDrag} onPointerCancel={endDrag} onPointerDown={handleCanvasDown}>
            <div className="tb-grid"/>
            <svg className="tb-links" viewBox="0 0 1000 640" preserveAspectRatio="none">
              {topology.links.map(link => {
                const a=topology.devices.find(d=>d.id===link.a), b=topology.devices.find(d=>d.id===link.b); if(!a||!b)return null;
                const healthy=isLinkHealthy(topology,link); const active=selected.type==='link'&&selected.id===link.id;
                return <g key={link.id} onPointerDown={e=>{e.stopPropagation();setSelected({type:'link',id:link.id});}} className="tb-link-hit">
                  <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} className={`tb-link ${healthy?'healthy':'down'} ${active?'selected':''}`} />
                  <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} className="tb-link-hitline" />
                  {link.kind==='trunk'&&<text x={(a.x+b.x)/2} y={(a.y+b.y)/2-8} className="tb-link-label">TRUNK</text>}
                </g>;
              })}
              {pathResult?.slice(0,-1).map((id,i)=>{const next=pathResult[i+1],a=topology.devices.find(d=>d.id===id),b=topology.devices.find(d=>d.id===next);return a&&b?<line key={`${id}-${next}`} x1={a.x} y1={a.y} x2={b.x} y2={b.y} className="tb-path-line"/>:null;})}
            </svg>
            {topology.devices.map(d => <div key={d.id} className={`tb-node ${d.type} ${selectedDevice?.id===d.id?'selected':''} ${connectSource===d.id?'connect-source':''} ${d.runtimeEnabled===false?'disabled':''}`} style={{left:`${d.x/10}%`,top:`${d.y/6.4}%`}} onPointerDown={e=>handleNodePointerDown(e,d.id)}>
              <TypeGlyph type={d.type}/><div className="tb-node-copy"><strong>{d.name}</strong><small>{DEVICE_TYPES[d.type].label}{d.ip?` · ${d.ip}`:''}</small></div><i className={(d.runtimeEnabled ?? d.enabled)?'up':'down'}/>
            </div>)}
            {connectMode&&<div className="tb-connect-banner">CLICK TWO DEVICES TO CREATE A LINK {connectSource&&'· SELECT SECOND NODE'}</div>}
            <div className="tb-canvas-legend"><span><i className="good"/> link healthy</span><span><i className="bad"/> link down</span><span><i className="path"/> traced path</span></div>
          </div>
        </section>

        <aside className="tb-side">
          <section className="tb-panel">
            <SectionTitle eyebrow="01 / INSPECT" title={selectedDevice?'Device selected':selectedLink?'Link selected':'No selection'} right={selectedDevice||selectedLink?<button className="tb-delete" onClick={removeSelected}>Delete</button>:null}/>
            {selectedDevice&&<div className="tb-editor">
              <label>DEVICE NAME<input value={selectedDevice.name} onChange={e=>setTopology(updateDevice(topology,selectedDevice.id,{name:e.target.value}))}/></label>
              <label>TYPE<select value={selectedDevice.type} onChange={e=>{const next=e.target.value;setTopology(updateDevice(topology,selectedDevice.id,{type:next,ports:selectedDevice.ports?.length===DEVICE_TYPES[next].ports?selectedDevice.ports:makePorts(next)}));}}>{TYPE_ORDER.map(t=><option key={t} value={t}>{DEVICE_TYPES[t].label}</option>)}</select></label>
              <label>IP / MANAGEMENT<input placeholder="Optional" value={selectedDevice.ip} onChange={e=>setTopology(updateDevice(topology,selectedDevice.id,{ip:e.target.value}))}/></label>
              <label>NOTES<textarea rows="3" value={selectedDevice.notes} onChange={e=>setTopology(updateDevice(topology,selectedDevice.id,{notes:e.target.value}))}/></label>
              <button className={`tb-enable ${selectedDevice.enabled?'enabled':''}`} onClick={()=>setTopology(updateDevice(topology,selectedDevice.id,{enabled:!selectedDevice.enabled}))}>{selectedDevice.enabled?'Disable device':'Enable device'}</button>
            </div>}
            {selectedLink&&<div className="tb-editor">
              <div className="tb-endpoints"><strong>{names[selectedLink.a]}</strong><span>↔</span><strong>{names[selectedLink.b]}</strong></div>
              <label>LINK TYPE<select value={selectedLink.kind} onChange={e=>setTopology(updateLink(topology,selectedLink.id,{kind:e.target.value}))}><option value="copper">Copper</option><option value="trunk">802.1Q trunk</option><option value="fiber">Fiber</option><option value="wireless">Wireless</option></select></label>
              <label>STATE<select value={selectedLink.state} onChange={e=>setTopology(updateLink(topology,selectedLink.id,{state:e.target.value}))}><option value="up">Up</option><option value="down">Down</option></select></label>
              <div className="tb-port-pair"><div><span>{names[selectedLink.a]}</span><strong>{selectedLink.ai}</strong></div><div><span>{names[selectedLink.b]}</span><strong>{selectedLink.bi}</strong></div></div>
            </div>}
            {!selectedDevice&&!selectedLink&&<div className="tb-empty">Select a device or link on the canvas to edit its properties. Drag devices to reposition them.</div>}
          </section>

          <section className="tb-panel">
            <SectionTitle eyebrow="02 / PATH ANALYSIS" title="Trace a route" right={<button className="tb-run" onClick={runPath}>Trace</button>}/>
            <div className="tb-path-form"><label>FROM<select value={source} onChange={e=>setSource(e.target.value)}><option value="">Select</option>{topology.devices.map(d=><option key={d.id} value={d.id}>{d.name}</option>)}</select></label><label>TO<select value={target} onChange={e=>setTarget(e.target.value)}><option value="">Select</option>{topology.devices.map(d=><option key={d.id} value={d.id}>{d.name}</option>)}</select></label></div>
            {pathResult&&<div className={`tb-path-result ${pathResult.length?'reachable':'blocked'}`}><span>{pathResult.length?'PATH AVAILABLE':'NO PATH FOUND'}</span><strong>{pathResult.length?pathNames.join('  →  '):'The current topology has no healthy route between these devices.'}</strong></div>}
          </section>

          <section className="tb-panel">
            <SectionTitle eyebrow="03 / VALIDATION" title={validation.valid?'Topology valid':'Issues detected'} right={<span className={`tb-status ${validation.valid?'good':'bad'}`}>{validation.valid?'PASS':'CHECK'}</span>}/>
            <div className="tb-issues">{validation.issues.length===0?<div className="tb-empty compact">No structural issues detected. This topology can be saved as a reusable design.</div>:validation.issues.map((issue,i)=><div key={i} className={`tb-issue ${issue.severity}`}><i/>{issue.message}</div>)}</div>
          </section>

          <section className="tb-panel tb-progression">
            <SectionTitle eyebrow="04 / NEXT STEP" title="Turn design into a lab"/>
            <p>Build the topology first, then carry its device inventory into a future stateful lab scenario. Your design is automatically saved locally.</p>
            <div className="tb-progression-row"><span>LOCAL SAVE</span><strong>ACTIVE</strong></div><div className="tb-progression-row"><span>SCHEMA</span><strong>PF-TOPOLOGY / 1</strong></div>
          </section>
        </aside>
      </div>
    </main>
    {message&&<div className="tb-toast">{message}</div>}
  </div>;
}
