const API_BASE = (import.meta.env?.VITE_PF_API_URL || '/api/v1').replace(/\/$/, '');

let accessToken = null;

async function request(path, options = {}, allowRefresh = true) {
  const headers = new Headers(options.headers || {});
  if (options.body !== undefined && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  if (accessToken) headers.set('Authorization', `Bearer ${accessToken}`);
  const response = await fetch(`${API_BASE}${path}`, { ...options, headers, credentials: 'include' });
  if (response.status === 401 && allowRefresh && path !== '/auth/refresh') {
    try {
      await refresh();
      return request(path, options, false);
    } catch {
      accessToken = null;
    }
  }
  const text = await response.text();
  let body = null;
  try { body = text ? JSON.parse(text) : null; } catch { body = { error: text || 'Unknown response' }; }
  if (!response.ok) {
    const error = new Error(body?.error || `HTTP ${response.status}`);
    error.status = response.status;
    error.body = body;
    throw error;
  }
  return body;
}

export async function health() { return request('/health', {}, false); }
export async function register(email, password) { const result = await request('/auth/register', { method: 'POST', body: JSON.stringify({ email, password }) }, false); accessToken = result.accessToken; return result; }
export async function login(email, password) { const result = await request('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }, false); accessToken = result.accessToken; return result; }
export async function refresh() { const result = await request('/auth/refresh', { method: 'POST' }, false); accessToken = result.accessToken; return result; }
export async function logout() { try { await request('/auth/logout', { method: 'POST' }, false); } finally { accessToken = null; } }
export async function me() { return request('/me'); }
export async function getSync() { return request('/sync'); }
export async function pushSnapshot(payload, baseVersion) { return request('/sync', { method: 'PUT', body: JSON.stringify({ payload, baseVersion }) }); }
export async function overwriteSnapshot(payload) { return request('/sync/overwrite', { method: 'POST', body: JSON.stringify({ payload, baseVersion: 0 }) }); }
export function isAuthenticated() { return Boolean(accessToken); }
