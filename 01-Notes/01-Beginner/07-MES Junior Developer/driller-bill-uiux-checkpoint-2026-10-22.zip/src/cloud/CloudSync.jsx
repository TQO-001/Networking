import React, { useEffect, useMemo, useState } from 'react';
import { createStudySnapshot, restoreStudySnapshot } from '../core/data-safety.js';
import { safeStorage } from '../storage.js';
import * as api from './api.js';

const CONFLICT_BACKUP_KEY = 'pennyFarthingCloudConflictBackupV1';
const prettyBytes = (bytes) => bytes < 1024 ? `${bytes} B` : bytes < 1024 * 1024 ? `${(bytes / 1024).toFixed(1)} KB` : `${(bytes / 1024 / 1024).toFixed(2)} MB`;

const cloudErrorMessage = (error) => error?.status === 413
  ? 'This snapshot exceeds the cloud sync limit (2 MB). Your local data remains on this device; export a local backup before reducing stored data and retrying.'
  : (error?.message || 'Cloud request failed. Please try again.');

export default function CloudSync() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState('login');
  const [user, setUser] = useState(null);
  const [serverVersion, setServerVersion] = useState(0);
  const [serverUpdatedAt, setServerUpdatedAt] = useState(null);
  const [status, setStatus] = useState({ kind: 'idle', text: '' });
  const [conflict, setConflict] = useState(null);
  const [apiStatus, setApiStatus] = useState('checking');
  const [busy, setBusy] = useState(false);

  const localSnapshot = createStudySnapshot();
  const localSize = prettyBytes(new Blob([JSON.stringify(localSnapshot)]).size);

  useEffect(() => {
    let active = true;
    api.health().then(() => active && setApiStatus('online')).catch(() => active && setApiStatus('offline'));
    api.refresh().then((result) => {
      if (!active) return;
      setUser(result.user);
      return api.getSync();
    }).then((remote) => {
      if (!active || !remote) return;
      setServerVersion(remote.version || 0);
      setServerUpdatedAt(remote.updatedAt || null);
    }).catch(() => {});
    return () => { active = false; };
  }, []);

  const loadRemoteMetadata = async () => {
    const remote = await api.getSync();
    setServerVersion(remote.version || 0);
    setServerUpdatedAt(remote.updatedAt || null);
    return remote;
  };

  const submitAuth = async (event) => {
    event.preventDefault();
    setBusy(true); setStatus({ kind: 'idle', text: '' });
    try {
      const result = mode === 'login' ? await api.login(email, password) : await api.register(email, password);
      setUser(result.user);
      setPassword('');
      await loadRemoteMetadata();
      setStatus({ kind: 'success', text: mode === 'login' ? 'Signed in. Your local study data remains local until you sync it.' : 'Account created. Your local study data has not been uploaded automatically.' });
    } catch (error) {
      setStatus({ kind: 'error', text: cloudErrorMessage(error) });
    } finally { setBusy(false); }
  };

  const push = async (force = false) => {
    setBusy(true); setStatus({ kind: 'idle', text: '' });
    try {
      const snapshot = createStudySnapshot();
      const result = force ? await api.overwriteSnapshot(snapshot) : await api.pushSnapshot(snapshot, serverVersion);
      setServerVersion(result.version);
      setServerUpdatedAt(new Date().toISOString());
      setConflict(null);
      setStatus({ kind: 'success', text: `Cloud copy saved at revision ${result.version}.` });
    } catch (error) {
      if (error.body?.code === 'SYNC_CONFLICT') {
        safeStorage.setItem(CONFLICT_BACKUP_KEY, JSON.stringify(createStudySnapshot()));
        setConflict(error.body.server);
        setServerVersion(error.body.server?.version || 0);
        setServerUpdatedAt(error.body.server?.updatedAt || null);
        setStatus({ kind: 'error', text: 'The server changed since your last sync. Your local snapshot was backed up before showing the conflict options.' });
      } else setStatus({ kind: 'error', text: cloudErrorMessage(error) });
    } finally { setBusy(false); }
  };

  const pull = async () => {
    setBusy(true);
    try {
      const remote = await loadRemoteMetadata();
      if (!remote.exists) return setStatus({ kind: 'idle', text: 'There is no cloud copy for this account yet.' });
      safeStorage.setItem(CONFLICT_BACKUP_KEY, JSON.stringify(createStudySnapshot()));
      restoreStudySnapshot(remote.payload, { clearMissing: false });
      setStatus({ kind: 'success', text: 'Cloud snapshot restored. Reload Driller Bill to refresh the live React state.' });
    } catch (error) { setStatus({ kind: 'error', text: cloudErrorMessage(error) }); }
    finally { setBusy(false); }
  };

  const useServer = async () => {
    if (!conflict?.payload) return;
    safeStorage.setItem(CONFLICT_BACKUP_KEY, JSON.stringify(createStudySnapshot()));
    restoreStudySnapshot(conflict.payload, { clearMissing: false });
    setConflict(null);
    setStatus({ kind: 'success', text: 'Server snapshot applied. Reload Driller Bill to refresh the workspace.' });
  };

  const logout = async () => { setBusy(true); try { await api.logout(); setUser(null); setStatus({ kind: 'success', text: 'Signed out. Local study data remains on this device.' }); } finally { setBusy(false); } };

  return <main className="page cloud-page">
    <section className="page-title compact"><div><div className="eyebrow">CLOUD / LOCAL-FIRST SYNC</div><h1>Keep your progress<br/><span>wherever you train.</span></h1><p>Cloud sync is optional. Driller Bill keeps working locally and only sends your study snapshot when you explicitly sync it.</p></div><div className={`cloud-status ${apiStatus}`}><i/>{apiStatus==='online'?'API ONLINE':apiStatus==='offline'?'API OFFLINE':'CHECKING API'}</div></section>

    {!user ? <section className="cloud-grid"><section className="panel cloud-auth"><div className="panel-head"><div><div className="kicker">01 / ACCOUNT</div><h2>{mode==='login'?'Sign in':'Create your account'}</h2></div></div><form onSubmit={submitAuth} className="cloud-form"><label>Email<input type="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} required /></label><label>Password<input type="password" autoComplete={mode==='login'?'current-password':'new-password'} value={password} onChange={e=>setPassword(e.target.value)} minLength={12} maxLength={72} required /></label><button className="button primary large" disabled={busy||apiStatus==='offline'}>{busy?'Working…':mode==='login'?'Sign in':'Create account'}</button></form><button className="text-button" onClick={()=>setMode(mode==='login'?'register':'login')}>{mode==='login'?'Need an account? Register':'Already have an account? Sign in'}</button>{status.text&&<div className={`cloud-message ${status.kind}`}>{status.text}</div>}</section><section className="panel"><div className="panel-head"><div><div className="kicker">02 / PRINCIPLE</div><h2>Local first.</h2></div></div><div className="cloud-principles"><div><b>01</b><strong>Nothing uploads automatically.</strong><span>Your browser remains the primary source of truth.</span></div><div><b>02</b><strong>Conflicts don't overwrite silently.</strong><span>A local backup is created before conflict resolution.</span></div><div><b>03</b><strong>Cloud is a mirror, not a requirement.</strong><span>You can keep using Driller Bill entirely offline.</span></div></div></section></section> : <section className="cloud-grid"><section className="panel cloud-account"><div className="panel-head"><div><div className="kicker">01 / ACCOUNT</div><h2>{user.email}</h2></div><button className="button" onClick={logout} disabled={busy}>Sign out</button></div><div className="cloud-stats"><div><span>LOCAL SNAPSHOT</span><strong>{localSize}</strong></div><div><span>SERVER REVISION</span><strong>{serverVersion || '—'}</strong></div><div><span>LAST SERVER UPDATE</span><strong>{serverUpdatedAt ? new Date(serverUpdatedAt).toLocaleString() : '—'}</strong></div></div><div className="cloud-actions"><button className="button primary large" onClick={()=>push(false)} disabled={busy}>Push local → cloud</button><button className="button large" onClick={pull} disabled={busy}>Pull cloud → local</button><button className="button large" onClick={loadRemoteMetadata} disabled={busy}>Refresh status</button></div>{status.text&&<div className={`cloud-message ${status.kind}`}>{status.text}</div>}</section><section className="panel"><div className="panel-head"><div><div className="kicker">02 / CONFLICT POLICY</div><h2>Explicit overwrite.</h2></div></div>{conflict ? <div className="cloud-conflict"><strong>Revision {conflict.version} is newer than your local revision.</strong><span>Your local snapshot is backed up under the cloud conflict recovery key.</span><div><button className="button" onClick={useServer} disabled={busy}>Use server copy</button><button className="button primary" onClick={()=>push(true)} disabled={busy}>Keep local / overwrite</button></div></div> : <div className="empty-state"><strong>No sync conflict.</strong><span>Driller Bill will stop a stale local revision from silently overwriting newer cloud data.</span></div>}</section></section>}
  </main>;
}
