import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));

export function syncDistMetadata({ distDir = resolve(root, 'dist'), version } = {}) {
  const packageJson = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'));
  const release = String(version || packageJson.version || '').trim();
  if (!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(release)) {
    throw new Error(`Invalid Driller Bill release version: ${release || '(empty)'}`);
  }

  const healthPath = resolve(distDir, 'health.json');
  const serviceWorkerPath = resolve(distDir, 'sw.js');
  if (!existsSync(healthPath) || !existsSync(serviceWorkerPath)) {
    throw new Error('Built assets are missing health.json or sw.js. Run vite build before syncing release metadata.');
  }

  const health = JSON.parse(readFileSync(healthPath, 'utf8'));
  health.release = release;
  health.version = release;
  writeFileSync(healthPath, `${JSON.stringify(health, null, 2)}\n`);

  const serviceWorker = readFileSync(serviceWorkerPath, 'utf8');
  const updatedWorker = serviceWorker.replace(
    /const CACHE = 'driller-bill-shell-v[^']+';/,
    `const CACHE = 'driller-bill-shell-v${release}';`,
  );
  if (updatedWorker === serviceWorker && !serviceWorker.includes(`const CACHE = 'driller-bill-shell-v${release}';`)) {
    throw new Error('Could not update the service-worker cache version; expected CACHE declaration is missing.');
  }
  writeFileSync(serviceWorkerPath, updatedWorker);
  return { release, healthPath, serviceWorkerPath };
}

const isMain = process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href;
if (isMain) {
  try {
    const result = syncDistMetadata();
    console.log(`PASS — generated Driller Bill ${result.release} metadata in dist/health.json and dist/sw.js`);
  } catch (error) {
    console.error(`FAIL — ${error instanceof Error ? error.message : String(error)}`);
    process.exitCode = 1;
  }
}
