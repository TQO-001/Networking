import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';

/** Check the API through the published web/nginx service, not the API container. */
export async function checkCloudHealth({
  baseUrl = process.env.CLOUD_SMOKE_URL || 'http://127.0.0.1:8080',
  fetchImpl = globalThis.fetch,
  timeoutMs = 5000,
} = {}) {
  const url = `${String(baseUrl).replace(/\/+$/, '')}/api/v1/health`;
  let response;
  try {
    response = await fetchImpl(url, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      cache: 'no-store',
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch (error) {
    throw new Error(`Could not reach ${url}. Start the cloud Compose stack and check nginx/API health. ${error instanceof Error ? error.message : String(error)}`);
  }

  const bodyText = await response.text();
  let body;
  try { body = JSON.parse(bodyText); } catch { body = null; }
  if (!response.ok) {
    throw new Error(`Cloud health endpoint returned HTTP ${response.status}: ${bodyText.slice(0, 400)}`);
  }
  if (body?.status !== 'ok' || body?.database !== 'ok' || body?.service !== 'driller-bill-api') {
    throw new Error(`Cloud health endpoint responded, but the API/database is not healthy: ${bodyText.slice(0, 400)}`);
  }
  return { url, status: response.status, body };
}

const isMain = process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href;
if (isMain) {
  try {
    const result = await checkCloudHealth();
    console.log(`PASS — ${result.url} returned HTTP ${result.status}; API and database are healthy.`);
  } catch (error) {
    console.error(`FAIL — ${error instanceof Error ? error.message : String(error)}`);
    process.exitCode = 1;
  }
}
