import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const defaultRoot = resolve(fileURLToPath(new URL('..', import.meta.url)));
const read = (root, file) => readFileSync(resolve(root, file), 'utf8');

/** Verify all committed release pointers against package.json. */
export function checkReleaseMetadata({ rootDir = defaultRoot } = {}) {
  const pkg = JSON.parse(read(rootDir, 'package.json'));
  const version = String(pkg.version || '').trim();
  if (!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(version)) {
    throw new Error(`package.json contains an invalid semantic version: ${version || '(empty)'}`);
  }

  const checks = [];
  const expect = (description, condition, actual) => {
    if (!condition) throw new Error(`${description} does not match package version ${version}${actual ? ` (found ${actual})` : ''}.`);
    checks.push(description);
  };

  const health = JSON.parse(read(rootDir, 'public/health.json'));
  expect('public/health.json release', health.release === version, health.release);
  expect('public/health.json version', health.version === version, health.version);

  const worker = read(rootDir, 'public/sw.js');
  expect('public/sw.js cache key', worker.includes(`driller-bill-shell-v${version}`), worker.match(/driller-bill-shell-v[^'"\s]+/)?.[0]);

  const dataSafety = read(rootDir, 'src/core/data-safety.js');
  expect('APP_DATA_VERSION', new RegExp(`APP_DATA_VERSION\\s*=\\s*['"]${version.replaceAll('.', '\\.')}['"]`).test(dataSafety));

  const releaseLine = new RegExp(`Current release:\\s*\\*\\*v${version.replaceAll('.', '\\.')}\\b`);
  expect('README current release', releaseLine.test(read(rootDir, 'README.md')));
  expect('RELEASE-NOTES current release', releaseLine.test(read(rootDir, 'RELEASE-NOTES.md')));

  const changelog = read(rootDir, 'CHANGELOG.md');
  expect('CHANGELOG current heading', new RegExp(`^## v${version.replaceAll('.', '\\.')}\\s+—`, 'm').test(changelog));
  const releaseNote = `docs/releases/RELEASE-NOTES-V${version}.md`;
  expect('versioned release note exists', existsSync(resolve(rootDir, releaseNote)), releaseNote);

  const distHealthPath = resolve(rootDir, 'dist/health.json');
  const distWorkerPath = resolve(rootDir, 'dist/sw.js');
  if (existsSync(distHealthPath) || existsSync(distWorkerPath)) {
    if (!existsSync(distHealthPath) || !existsSync(distWorkerPath)) {
      throw new Error('dist must contain both health.json and sw.js when build output exists.');
    }
    const distHealth = JSON.parse(readFileSync(distHealthPath, 'utf8'));
    const distWorker = readFileSync(distWorkerPath, 'utf8');
    expect('dist/health.json release', distHealth.release === version, distHealth.release);
    expect('dist/health.json version', distHealth.version === version, distHealth.version);
    expect('dist/sw.js cache key', distWorker.includes(`driller-bill-shell-v${version}`), distWorker.match(/driller-bill-shell-v[^'"\s]+/)?.[0]);
  }

  return { version, checks };
}

const isMain = process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href;
if (isMain) {
  try {
    const result = checkReleaseMetadata();
    console.log(`PASS — ${result.checks.length} release metadata checks match Driller Bill ${result.version}`);
  } catch (error) {
    console.error(`FAIL — ${error instanceof Error ? error.message : String(error)}`);
    process.exitCode = 1;
  }
}
