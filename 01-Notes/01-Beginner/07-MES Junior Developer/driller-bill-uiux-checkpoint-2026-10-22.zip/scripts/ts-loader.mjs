import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const extensions = ['.ts', '.tsx']

export async function resolve(specifier, context, nextResolve) {
  if (specifier.startsWith('.') || specifier.startsWith('/')) {
    const parent = context.parentURL ? fileURLToPath(context.parentURL) : process.cwd()
    const base = specifier.startsWith('/') ? specifier : path.resolve(path.dirname(parent), specifier)
    for (const ext of extensions) {
      try {
        await fs.access(base + ext)
        return { url: pathToFileURL(base + ext).href, shortCircuit: true }
      } catch {}
    }
  }
  return nextResolve(specifier, context)
}

