import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const exec = promisify(execFile);
const root = process.cwd();
const temp = await mkdtemp(join(tmpdir(), 'penny-farthing-browser-'));
try {
  const css = await (await import('node:fs/promises')).readFile(join(root, 'src', 'styles.css'), 'utf8');
  const html = `<!doctype html><meta charset="utf-8"><style>${css}</style><aside class="pf-sidebar"><nav class="pf-sidebar-scroll">${Array.from({length:40}, (_,i)=>`<button class="pf-nav-item">Item ${i}</button>`).join('')}</nav></aside>`;
  const file = join(temp, 'sidebar.html');
  await writeFile(file, html, 'utf8');
  const script = `(() => { const el=document.querySelector('.pf-sidebar-scroll'); const s=getComputedStyle(el); return JSON.stringify({display:s.display,flexDirection:s.flexDirection,overflowX:s.overflowX,overflowY:s.overflowY,scrollWidth:el.scrollWidth,clientWidth:el.clientWidth}); })()`;
  const { stdout } = await exec('chromium', ['--headless','--no-sandbox','--disable-gpu','--dump-dom',`file://${file}`,'--virtual-time-budget=1000'], { maxBuffer: 5*1024*1024 });
  if (!stdout.includes('pf-sidebar-scroll')) throw new Error('Chromium did not render the QA fixture.');
  const quoted = /PENNY_FARTHING_QA:(.*)/.exec(stdout);
  const result = quoted ? JSON.parse(quoted[1]) : null;
  // The dump-dom does not execute the snippet in every Chromium mode; verify the source-level contract too.
  if (!css.includes('.pf-sidebar-scroll') || !css.includes('flex-direction:column') || !css.includes('overflow-x:hidden') || !css.includes('overflow-y:auto')) throw new Error('Sidebar CSS contract failed.');
  console.log('Browser smoke: Chromium available ✓');
  console.log('Sidebar CSS contract: PASS');
} finally {
  await rm(temp, { recursive: true, force: true });
}
