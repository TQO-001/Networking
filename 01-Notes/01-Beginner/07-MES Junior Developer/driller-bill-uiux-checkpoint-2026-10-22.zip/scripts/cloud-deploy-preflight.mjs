import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';

for (const file of ['docker-compose.cloud.yml','Dockerfile.cloud-web','nginx.cloud.conf','backend/Dockerfile','backend/requirements.txt','backend/scripts/migrate.py','.env.example','CLOUD-DEPLOY.md']) {
  assert.ok(existsSync(resolve(file)), `Missing deployment file: ${file}`);
}
const compose = readFileSync(resolve('docker-compose.cloud.yml'),'utf8');
assert.match(compose, /driller-bill-web:/);
assert.match(compose, /driller-bill-api:/);
assert.match(compose, /driller-bill-db:/);
assert.match(compose, /backend\/Dockerfile/);
assert.match(compose, /postgresql\+psycopg:/);
assert.match(compose, /PF_DB_PASSWORD:\?PF_DB_PASSWORD must be set/);
assert.match(compose, /PF_JWT_SECRET:\?PF_JWT_SECRET must be set/);
const dockerfile = readFileSync(resolve('backend/Dockerfile'),'utf8');
assert.match(dockerfile, /python backend\/scripts\/migrate\.py/);
assert.match(dockerfile, /uvicorn app\.main:app/);
console.log('Cloud deployment preflight: PASS');
