import assert from 'node:assert/strict';
import { ALL_STATIC_QUESTIONS, FAMILIES, getCorrect, normalizeExhibit } from '../src/core/exam-engine.js';

const issues = [];
const push = (kind, id, detail='') => issues.push(`${kind}: ${id}${detail ? ` — ${detail}` : ''}`);
const normalize = (s) => String(s ?? '').replace(/\s+/g, ' ').trim().toLowerCase();

const familyIds = new Set();
for (const family of FAMILIES) {
  if (!family?.id) push('missing family id', '<unknown>');
  else if (familyIds.has(family.id)) push('duplicate family id', family.id);
  else familyIds.add(family.id);
  if (!String(family.domain || '').match(/^[1-6]$/)) push('invalid domain', family.id, family.domain);
  if (!String(family.topic || '').match(/^[1-6]\.\d+$/)) push('invalid objective', family.id, family.topic);
}

const byFamily = new Map();
const questionIds = new Set();
const globalPrompts = new Map();
let exhibitCount = 0;
let generatedLikeCount = 0;

for (const q of ALL_STATIC_QUESTIONS) {
  const id = q.questionId || q.id;
  if (!id) { push('missing question id', '<unknown>'); continue; }
  if (questionIds.has(id)) push('duplicate question id', id);
  questionIds.add(id);
  if (!q.familyId) push('missing familyId', id);
  const list = byFamily.get(q.familyId) || [];
  list.push(q); byFamily.set(q.familyId, list);
  if (q.options?.length !== 4) push('wrong option count', id, `expected 4, got ${q.options?.length ?? 0}`);
  const answers = Array.isArray(q.answer) ? q.answer : [];
  if (!answers.length) push('missing answer', id);
  if (new Set(answers).size !== answers.length) push('duplicate answer index', id);
  if (answers.some((a) => !Number.isInteger(a) || a < 0 || a >= 4)) push('invalid answer index', id, answers.join(','));
  const optionSet = new Set((q.options || []).map(normalize));
  if (optionSet.size !== (q.options || []).length) push('duplicate options', id);
  if (!String(q.prompt || '').trim()) push('empty prompt', id);
  if (!String(q.explanation || '').trim()) push('empty explanation', id);
  if (/\{q\}|TODO|TBD|PLACEHOLDER|Lorem ipsum/i.test(`${q.prompt || ''} ${q.explanation || ''}`)) push('placeholder content', id);
  if (q.exhibit) exhibitCount++;
  if (q.generated) generatedLikeCount++;
  if (q.exhibit) {
    try { normalizeExhibit(q.exhibit); } catch (error) { push('invalid exhibit', id, error.message); }
  }
  const stem = normalize(q.prompt);
  if (stem) {
    const prev = globalPrompts.get(stem);
    if (prev && !q.exhibit && !prev.exhibit) push('duplicate prompt across families', id, `matches ${prev.questionId}`);
    else if (!prev) globalPrompts.set(stem, q);
  }
}

for (const [familyId, variants] of byFamily) {
  if (variants.length !== 5) push('family variant count', familyId, `expected 5, got ${variants.length}`);
  const stems = new Set(variants.map((q) => normalize(q.prompt)));
  if (stems.size !== variants.length) push('duplicate variant prompt', familyId);
}

const expectedObjectives = [];
for (const [domain, max] of [[1,13],[2,9],[3,5],[4,9],[5,10],[6,7]]) {
  for (let n=1;n<=max;n++) expectedObjectives.push(`${domain}.${n}`);
}
const objectiveCounts = new Map();
for (const f of FAMILIES) objectiveCounts.set(f.topic, (objectiveCounts.get(f.topic)||0)+1);
for (const objective of expectedObjectives) {
  if (!objectiveCounts.has(objective)) push('missing objective coverage', objective);
}

assert.deepEqual(issues, [], `Content QA failed with ${issues.length} issue(s):\n${issues.slice(0, 100).join('\n')}`);
assert.ok(questionIds.size >= 1900, `Unexpectedly small static bank: ${questionIds.size}`);
assert.equal(expectedObjectives.filter((x)=>objectiveCounts.has(x)).length, 53, 'Expected all 53 current v1.1 objective numbers to be represented');

console.log(`PASS — content QA: ${FAMILIES.length} families, ${questionIds.size} static questions, ${exhibitCount} exhibit questions, ${generatedLikeCount} generated questions, 53 objectives covered.`);
