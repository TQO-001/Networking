import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';

const exec = promisify(execFile);
const chromiumCandidates = ['chromium', 'chromium-browser', 'google-chrome'];
let browser = null;
for (const candidate of chromiumCandidates) {
  try {
    const { stdout, stderr } = await exec(candidate, ['--version'], { timeout: 3000 });
    browser = `${candidate}: ${(stdout || stderr).trim()}`;
    break;
  } catch {}
}

const css = await readFile(join(process.cwd(), 'src', 'styles.css'), 'utf8');
const contract = [
  css.includes('.pf-sidebar-scroll'),
  css.includes('flex-direction:column'),
  css.includes('overflow-x:hidden'),
  css.includes('overflow-y:auto'),
  css.includes('body{overflow-x:hidden}') || css.includes('body { overflow-x: hidden')
];
if (!contract.every(Boolean)) throw new Error('Sidebar overflow/layout contract failed.');

console.log(browser ? `Browser available ✓ (${browser})` : 'Browser binary not available (install Chromium for E2E).');
console.log('Sidebar CSS contract: PASS');
console.log('Playwright E2E suite: configured — run `npm run qa:release` after dependencies and Chromium are installed.');
