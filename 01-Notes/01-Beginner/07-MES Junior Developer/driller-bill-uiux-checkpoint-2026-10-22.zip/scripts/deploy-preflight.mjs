import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';

const root = resolve(process.cwd());
const pkg = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'));

for (const file of [
  'Dockerfile', 'nginx.conf', 'docker-compose.yml', 'public/health.json', 'scripts/sync-dist-metadata.mjs',
  '.dockerignore', 'CLOUD-DEPLOY.md', 'scripts/doctor.mjs',
  'scripts/browser-preflight.mjs', 'playwright.config.js'
]) {
  assert.ok(existsSync(resolve(root, file)), `Missing deployment file: ${file}`);
}

const health = JSON.parse(readFileSync(resolve(root, 'public/health.json'), 'utf8'));
assert.equal(health.status, 'ok');
assert.equal(health.service, 'driller-bill');
assert.equal(health.release, pkg.version);
assert.equal(health.backend, 'fastapi');

const dockerfile = readFileSync(resolve(root, 'Dockerfile'), 'utf8');
for (const pattern of [
  /FROM node:22-bookworm-slim/, /FROM nginx:1\.27-alpine/, /npm run build/, /health\.json/
]) assert.match(dockerfile, pattern);
assert.doesNotMatch(dockerfile, /npm run check:web/, 'container builds must not run documentation-dependent unit tests in the slim context');

const nginx = readFileSync(resolve(root, 'nginx.conf'), 'utf8');
for (const pattern of [
  /try_files \$uri \$uri\/ \/index\.html/,
  /X-Content-Type-Options/, /Referrer-Policy/, /Permissions-Policy/,
  /location = \/health\.json/, /Cache-Control "no-store/
]) assert.match(nginx, pattern);

const compose = readFileSync(resolve(root, 'docker-compose.yml'), 'utf8');
for (const pattern of [/driller-bill-web:/, /"8080:80"/, /health\.json/]) assert.match(compose, pattern);

assert.ok(/^\d+\.\d+\.\d+$/.test(pkg.version), `Invalid package version: ${pkg.version}`);
assert.equal(pkg.scripts['release:check'], 'npm run check && npm run deploy:preflight');
assert.equal(pkg.scripts['check:web'], 'npm run validate && npm run validate:driller-bill && npm run validate:cloud && npm run qa:content && npm run typecheck:core && npm run release:metadata:check && npm test');

console.log(`PASS — deployment preflight for ${pkg.name}@${pkg.version}`);
