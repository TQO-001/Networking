import assert from 'node:assert/strict';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';

const root = resolve(process.cwd());
const loader = pathToFileURL(resolve(root, 'scripts/ts-loader.mjs')).href;
const expression = `import('./src/driller-bill/DrillCatalog.js').then(({DRILLER_BILL_MODULES})=>{\nconst issues=[];\nconst ids=new Set();\nfor(const m of DRILLER_BILL_MODULES){\n  if(!m.id||!m.title||!Array.isArray(m.theory)||!Array.isArray(m.drill)||!Array.isArray(m.objectives)||typeof m.createInitialState!=='function'||typeof m.handleCommand!=='function'||typeof m.renderPrompt!=='function') issues.push(m.id||'<missing-id>');\n  if(ids.has(m.id)) issues.push('duplicate:'+m.id); ids.add(m.id);\n  try{ let s=m.createInitialState(); for(const step of m.drill){ const r=m.handleCommand(step.command,s,m.objectives); if(!r||!r.state) throw new Error('invalid command result'); s=r.state; } }catch(e){ issues.push(m.id+': '+e.message); }\n}\nif(issues.length){console.error(JSON.stringify(issues));process.exit(1)}\nconsole.log('PASS — '+DRILLER_BILL_MODULES.length+' Driller Bill modules validated.');\n}).catch(e=>{console.error(e);process.exit(1)})`;

const result = spawnSync(process.execPath, ['--experimental-strip-types', '--loader', loader, '--input-type=module', '-e', expression], { cwd: root, encoding: 'utf8' });
assert.equal(result.status, 0, `Driller Bill module validation failed.\n${result.stdout}\n${result.stderr}`);
process.stdout.write(result.stdout);
