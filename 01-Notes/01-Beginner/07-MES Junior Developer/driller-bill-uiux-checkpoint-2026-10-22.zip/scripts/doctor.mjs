import { existsSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { resolve } from 'node:path';

const pkg = JSON.parse(readFileSync(resolve('package.json'), 'utf8'));
const nodeVersion = process.versions.node;
const major = Number(nodeVersion.split('.')[0]);
const viteInstalled = existsSync(resolve('node_modules/.bin/vite')) || existsSync(resolve('node_modules/vite'));
const reactInstalled = existsSync(resolve('node_modules/react'));

console.log('Driller Bill environment doctor');
console.log(`Node: ${nodeVersion} ${major >= 20 ? '✓' : '✗ requires Node 20+'}`);
console.log(`npm: ${execFileSync('npm', ['--version'], { encoding: 'utf8' }).trim()} ✓`);
console.log(`React dependency: ${reactInstalled ? 'installed ✓' : `not installed (run npm install)`}`);
console.log(`Vite dependency: ${viteInstalled ? 'installed ✓' : `not installed (run npm install)`}`);
console.log(`Package: ${pkg.name}@${pkg.version}`);
console.log(`Core barrel: ${existsSync(resolve('src/core/index.js')) ? 'present ✓' : 'missing ✗'}`);

if (!viteInstalled || !reactInstalled) {
  console.log('\nThe source package is present. Install dependencies before running the browser build.');
  console.log('Commands: npm install && npm run check && npm run build');
}
