import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { resolve, relative, extname, basename } from 'node:path';

const root = resolve(process.cwd());
const src = resolve(root, 'src');

function walk(dir) {
  const out = [];
  for (const name of readdirSync(dir)) {
    const path = resolve(dir, name);
    if (statSync(path).isDirectory()) out.push(...walk(path));
    else out.push(path);
  }
  return out;
}

const sourceFiles = walk(src).filter((file) => ['.js', '.jsx'].includes(extname(file)));
const jsFiles = sourceFiles.filter((file) => file.endsWith('.js'));
for (const file of jsFiles) {
  const check = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  assert.equal(check.status, 0, `Syntax error in ${relative(root, file)}\n${check.stderr}`);
}

const missingImports = [];
for (const file of sourceFiles) {
  const text = readFileSync(file, 'utf8');
  const importRegex = /(?:from\s+|import\s*\(\s*)['"](\.[^'"]+)['"]/g;
  for (const match of text.matchAll(importRegex)) {
    const request = match[1];
    const base = resolve(file, '..', request);
    const candidates = [base, `${base}.js`, `${base}.jsx`, resolve(base, 'index.js'), resolve(base, 'index.jsx')];
    if (!candidates.some(existsSync)) missingImports.push(`${relative(root, file)} -> ${request}`);
  }
}
assert.deepEqual(missingImports, [], `Missing relative imports: ${missingImports.join(', ')}`);

const legacyEngineNames = [
  'network-simulator.js','network-lab-v6.js','network-lab-v7.js','cli-engine-v11.js','protocol-engine-v8.js',
  'flow-engine-v20.js','packet-engine-v21.js','advanced-engine-v9.js','mastery-engine-v14.js','packet-workshop-engine-v21.js','engine.js'
];
const legacyEngineFiles = sourceFiles.filter((file) => legacyEngineNames.includes(basename(file)));
assert.deepEqual(legacyEngineFiles, [], `Legacy versioned engine files remain: ${legacyEngineFiles.map((x) => relative(root, x)).join(', ')}`);

const staleRefs = [];
for (const file of sourceFiles) {
  const text = readFileSync(file, 'utf8');
  for (const token of ['network-simulator.js','network-lab-v6.js','network-lab-v7.js','cli-engine-v11.js','protocol-engine-v8.js','flow-engine-v20.js','packet-engine-v21.js','advanced-engine-v9.js','mastery-engine-v14.js','live-network-engine.js','network-topology-sync.js','packet-workshop-engine.js']) {
    // Canonical names are allowed only when the token itself names the new file.
    const canonical = new Set(['live-network-engine.js','network-topology-sync.js','packet-workshop-engine.js']);
    if (!canonical.has(token) && text.includes(token)) staleRefs.push(`${relative(root, file)} contains ${token}`);
  }
}
assert.deepEqual(staleRefs, [], `Stale engine references remain: ${staleRefs.join(', ')}`);

await import('../src/core/index.js');
const { ALL_STATIC_QUESTIONS, FAMILIES, makeExam, weightedCounts, randomizeChoices, getCorrect } = await import('../src/core/exam-engine.js');
assert.ok(ALL_STATIC_QUESTIONS.length >= 1700, 'Static question bank unexpectedly small after v18 expansion');
assert.ok(FAMILIES.length >= 340, 'Authored family count unexpectedly small after v18 expansion');
assert.ok(ALL_STATIC_QUESTIONS.filter(q => q.id?.includes('V18-')).length >= 750, 'v18 authored question variants missing');
assert.equal(Object.values(weightedCounts(100)).reduce((sum, value) => sum + value, 0), 100, 'Blueprint weights do not sum to 100');
for (const [mode, expected] of Object.entries({ full: 100, sprint: 20, exhibits: 20, scenario: 30, remediation: 24 })) {
  const paper = makeExam({ mode, domain: 'all', history: [], seen: {}, adaptive: false, coldStart: true, difficulty: 'mixed' });
  assert.equal(paper.length, expected, `${mode} generated ${paper.length}, expected ${expected}`);
  assert.equal(new Set(paper.map((q) => q.questionId)).size, paper.length, `${mode} contains duplicate question IDs`);
}
const domainPaper = makeExam({ mode: 'domain', domain: '3', history: [], seen: {}, adaptive: false, coldStart: true, difficulty: 'mixed' });
assert.equal(domainPaper.length, 20, 'Domain drill size changed');
assert.ok(domainPaper.every((q) => String(q.domain) === '3'), 'Domain drill leaked another domain');
const original = ALL_STATIC_QUESTIONS.find((q) => q.answer?.length === 1 && q.options?.length === 4);
const randomized = randomizeChoices(original);
assert.equal(randomized.options.length, 4, 'Choice randomizer changed option count');
assert.equal(randomized.answer.length, 1, 'Choice randomizer changed answer cardinality');
assert.equal(getCorrect(original, original.answer), true, 'Correct-answer evaluator rejected known answer');

const { demoTopology, findPath, validateTopology } = await import('../src/core/topology-engine.js');
const topology = demoTopology();
assert.equal(validateTopology(topology).valid, true, 'Demo topology is invalid');
assert.ok(findPath(topology, topology.devices[0].id, topology.devices.at(-1).id).length >= 2, 'Demo topology path is missing');

const { freshLab, executeCommand, deriveShow } = await import('../src/core/cli-engine.js');
let cli = freshLab();
for (const command of ['enable', 'configure terminal', 'interface gi0/24', 'switchport trunk allowed vlan 10,20,99', 'end']) cli = executeCommand(cli, 'SW2', command).state;
assert.match(deriveShow(cli, 'SW2', 'show interfaces trunk'), /10,20,99/);

const { freshProtocolState, executeProtocolCommand, evaluateProtocolCase } = await import('../src/core/protocol-engine.js');
let protocol = freshProtocolState('ospf-timers');
for (const command of ['enable', 'configure terminal', 'interface gi0/0']) protocol = executeProtocolCommand(protocol, 'R2', command).state;
protocol = executeProtocolCommand(protocol, 'R2', 'exit').state;
for (const command of ['router ospf 1', 'ip ospf hello-interval 10', 'ip ospf dead-interval 40']) protocol = executeProtocolCommand(protocol, 'R2', command).state;
assert.ok(evaluateProtocolCase(protocol, 'ospf-timers').score >= 0, 'Protocol evaluator failed');

const { emptyCard, scheduleCard } = await import('../src/core/mastery-engine.js');
const card = scheduleCard(emptyCard({ id: 'test', questionId: 'test', topic: '3.4', concept: 'OSPF', q: 'x', options: ['a','b','c','d'], answer: [0] }), 'good', 1700000000000);
assert.equal(card.streak, 1, 'Mastery streak did not advance');
assert.ok(card.interval >= 1, 'Mastery interval did not advance');

const sidebarCss = readFileSync(resolve(root, 'src/styles.css'), 'utf8');
assert.match(sidebarCss, /\.topbar nav\{display:flex;/, 'Topbar nav rule is not scoped');
assert.equal(sidebarCss.includes('}nav{display:flex;') || sidebarCss.startsWith('nav{display:flex;'), false, 'Unscoped global nav rule can hijack sidebar layout');
assert.match(sidebarCss, /\.pf-sidebar-scroll\{[^}]*display:flex;[^}]*flex-direction:column;[^}]*overflow-x:hidden;[^}]*overflow-y:auto;/, 'Sidebar scroll container must be vertical');

const app = readFileSync(resolve(root, 'src/App.jsx'), 'utf8');
assert.match(app, /from '\.\/core\/topology-engine\.js'/, 'App must use canonical topology engine');
const stateful = readFileSync(resolve(root, 'src/StatefulLab.jsx'), 'utf8');
assert.match(stateful, /from '\.\/core\/cli-engine\.js'/, 'StatefulLab must use canonical CLI engine');
assert.match(app, /from '\.\/core\/exam-engine\.js'/, 'App must use canonical exam engine');
assert.match(app, /view==='data-safety'/, 'App must expose Data & Recovery route');
assert.equal(existsSync(resolve(root, 'public', 'sw.js')), true, 'Offline service worker is missing');

const packageJson = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'));
assert.ok(/^\d+\.\d+\.\d+$/.test(packageJson.version), `Invalid package version: ${packageJson.version}`);
assert.equal(packageJson.dependencies.react, '19.3.0');
assert.equal(packageJson.dependencies['react-dom'], '19.3.0');
assert.equal(packageJson.devDependencies.vite, '8.3.1');
assert.equal(packageJson.devDependencies['@vitejs/plugin-react'], '6.1.1');

console.log(`PASS — ${sourceFiles.length} source files scanned, ${ALL_STATIC_QUESTIONS.length} static questions, ${FAMILIES.length} families.`);
