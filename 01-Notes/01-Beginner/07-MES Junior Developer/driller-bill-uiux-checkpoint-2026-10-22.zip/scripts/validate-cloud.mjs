import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { resolve } from 'node:path';

const required = [
  'backend/requirements.txt', 'backend/app/main.py', 'backend/app/security.py',
  'backend/app/policy.py', 'backend/app/snapshot.py', 'backend/app/db.py',
  'backend/scripts/migrate.py', 'backend/tests/run_tests.py',
  'backend/migrations/versions/0001_initial.sql', 'src/cloud/api.js',
  'src/cloud/CloudSync.jsx', 'Dockerfile.cloud-web',
  'docker-compose.cloud.yml', 'nginx.cloud.conf', '.env.example', 'CLOUD-DEPLOY.md'
];
const missing = required.filter((file) => !existsSync(resolve(file)));
if (missing.length) { console.error('Python cloud validation failed:', missing); process.exit(1); }
const root = resolve('.');
function walk(dir) {
  const result=[];
  for (const name of readdirSync(dir)) {
    const path=resolve(dir,name);
    const stat=statSync(path);
    if (stat.isDirectory()) result.push(...walk(path)); else result.push(path);
  }
  return result;
}
const pyFiles = walk(resolve(root,'backend')).filter((f)=>f.endsWith('.py'));
if (!pyFiles.length) throw new Error('No Python backend files found.');
const compose = readFileSync(resolve('docker-compose.cloud.yml'),'utf8');
if (!/backend\/Dockerfile/.test(compose) || !/postgresql\+psycopg:/.test(compose)) throw new Error('Cloud compose does not use the Python/PostgreSQL backend.');
const frontend = readFileSync(resolve('src/cloud/api.js'),'utf8');
if (!frontend.includes("/auth/register") || !frontend.includes("/sync")) throw new Error('Frontend cloud API contract is incomplete.');
const pkg = JSON.parse(readFileSync(resolve('package.json'),'utf8'));
if (!/^\d+\.\d+\.\d+$/.test(pkg.version)) throw new Error(`Invalid frontend version: ${pkg.version}`);
for (const legacy of ['server/app.mjs','server/package.json','server/start.mjs']) {
  if (existsSync(resolve(legacy))) throw new Error(`Legacy Node backend remains: ${legacy}`);
}
console.log(`Python cloud validation: PASS — ${pyFiles.length} backend Python files.`);
