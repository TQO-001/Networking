Current release: **v64.0.6 — Workspace layouts + terminal ergonomics**

## v64.0.6 — Workspace layouts + terminal ergonomics

- Unified the simulated and physical CLI terminal controls.
- Added persistent text-size control, auto-follow, safe transcript copy, clear screen and expanded terminal mode.
- Made the device workspace responsive and clarified the hierarchy of device inventory, status metrics, inspection and configuration actions.
- Improved mobile quick commands and long CLI output behavior.

See `docs/releases/RELEASE-NOTES-V64.0.6.md` and `docs/releases/TEST-REPORT-V64.0.6.md` for implementation and validation details.

---

## v64.0.5 — Engineering-first UX polish

- Reframed the home console around network engineering tasks, not only assessment forms.
- Added six large, readable quick-launch cards for Devices, Discovery, Configuration, Troubleshooting, Knowledge, and the CLI Lab.
- Replaced sidebar Unicode glyphs with a consistent inline SVG icon set.
- Added collapsible navigation groups with the active workspace group automatically expanded and preferences persisted locally.
- Improved the mobile drawer with focus management, focus trapping, Escape-to-close, body-scroll locking, and clearer expanded-state semantics.
- Kept workspace search available on mobile as an icon button instead of hiding it below tablet widths.
- Increased high-value workspace copy to a consistent 16px body size while preserving 12px as the metadata floor.
- Updated current backup metadata, package version, PWA cache version, and release pointers.

See `docs/releases/RELEASE-NOTES-V64.0.5.md` and `docs/releases/TEST-REPORT-V64.0.5.md` for details.

---

# Historical release notes

## v64.0.4 — Workspace loading + Windows QA + performance polish

- Fixed the Driller Bill module validator to pass a `file://` URL to Node's ESM loader on Windows.
- Split large engineering and lab workspaces into on-demand route chunks.
- Added an accessible loading state for workspaces while their chunks initialize.
- Reduced bundled font assets by loading Google Sans and Google Sans Code Latin/Latin Extended subsets only.
- Replaced the decorative header search bar with a keyboard-accessible workspace command palette (`Ctrl/⌘+K`).
- Versioned the service-worker cache, backup metadata, and release pointers for v64.0.4.

See `docs/releases/RELEASE-NOTES-V64.0.4.md` and `docs/releases/TEST-REPORT-V64.0.4.md` for details.

## v64.0.3 — Windows-safe QA + final font precedence fix

- Fixed Windows path resolution in three Node tests using `fileURLToPath()`.
- Fixed the remaining global display token so Google Sans takes precedence over Jost.
- Added regression coverage for portable test paths and font precedence.
- Updated package/data/cache/release metadata to v64.0.3.

See `docs/releases/RELEASE-NOTES-V64.0.3.md` and `docs/releases/TEST-REPORT-V64.0.3.md` for details.

## v64.0.2 — Critical JSX Build Fix

- Fixed the malformed exam timer JSX expression that prevented Vite from parsing `src/App.jsx`.
- Added a test that parses all JavaScript/JSX/MJS/CJS files on every test run.
- Version-pinned `@serialport/bindings-cpp` install-script approval for the native serial transport.
- Updated Playwright to the version selected by the supplied audit fix.
- Made the service-worker cache patch-version-specific to ensure updates invalidate previous cache contents.

See `docs/releases/RELEASE-NOTES-V64.0.2.md` and `docs/releases/TEST-REPORT-V64.0.2.md` for details.

# Driller Bill Release Notes


## v61.0.0 — Network Discovery & Topology Synchronization
Driller Bill can now discover neighboring network devices using CDP/LLDP through the local Device Agent, build a normalized relationship graph, compare it with the current topology and review non-destructive synchronization changes before applying them to the design model.

See `docs/releases/RELEASE-NOTES-V61.md` for details.

## v60.0.0 — Multi-device Operations & Change Sets

Driller Bill can now coordinate one typed configuration intent across multiple selected devices while preserving independent per-device plan, preflight, approval, apply, verification and audit records.

See `docs/releases/RELEASE-NOTES-V60.md` for details.

# v59.0.0 — Change Control & Operational Hardening
- Added change-control core for risk classification, preflight checks, approval records and sanitized audit history.
- Added Plan → Preflight → Approve → Apply → Verify gating for live SSH/serial mutations.
- Added pre-change baseline and post-change configuration snapshots linked to each change record.
- Added persistent change history to the local Device Agent state file without persisting raw credentials or command secrets.
- Hardened snapshots/transcripts/API responses so credential-bearing simulated state and commands are not returned to the browser.
- Preserved simulation compatibility while requiring matching preflight approval for physical devices.

# v57.0.0 — Serial / Console Device Support
- Added serial/console as a live Device Agent transport beside simulated and SSH.
- Added COM/tty configuration, handshake, command execution, inspection and snapshots.
- Extended physical-device registration and inventory for Serial / Console targets.
- Kept the existing typed Configuration, Runbooks, Troubleshooting and Twin workflows transport-agnostic.

# v56.0.0 — Network & Device Operations
- Expanded device operations to 32 typed Cisco IOS-style intents across routing, security, switching, services, management and IPv6.
- Added structured inspection for protocol/service state and stronger scoped verification.
- Added redacted display commands for credential-bearing local-user operations.
- Extended Twin request detection and model context with v56 operational state.

## v55.0.0
- Twin Intelligence engineering workspace with six reasoning modes.
- Knowledge Graph retrieval and structured device-evidence context.
- Typed configuration proposal generation with Preview → Apply → Verify handoff.
- Redacted local Twin history and external model-context export.

# Driller Bill 26.0 — Consolidation & Reliability

## What changed

- Consolidated versioned executable engines into `src/core/` canonical modules.
- Removed unused `network-lab-v7.js` and `MultiDeviceLab.jsx`.
- Added `src/core/index.js` as a stable barrel for core logic.
- Updated all application/test imports to canonical engine paths.
- Renamed remaining V6 API identifiers in the canonical network model where safe.
- Preserved historical local-storage keys to avoid stranding existing study data.
- Added architecture and install-status documentation.
- Added `npm run doctor` to diagnose missing dependencies and environment issues.
- Added release gates for stale engines, unresolved imports, source syntax, question inventory, exam generation, topology, mastery, protocol state, and sidebar structure.

## Verification

`npm run check` passes with 28/28 tests.

`npm run build` was attempted in the isolated workspace but Vite is not installed because npm registry resolution timed out in this environment. The doctor command reports this clearly instead of masking it.

## Run locally

```bash
npm install
npm run doctor
npm run check
npm run build
npm run dev
```

## 28.0.0 — Browser QA & release hardening

- Added Playwright browser smoke suite for workspace boot, sidebar navigation, mobile navigation, full simulation launch, and page-error detection.
- Added browser preflight and separated local QA from full release QA.
- Added explicit test IDs to the persistent navigation sidebar.
- Hardened version validation so it tracks the package version instead of hard-coding a prior release.
- Kept the canonical network/assessment regression suite intact.

## 27.0.0 — QA / Core type safety
- Fixed canonical core export collisions.
- Fixed `show mac address-table` dead state-client path.
- Hardened optional UI props/defaults and topology timer ownership.
- Added core JavaScript typecheck gate.
- Added explicit Vite `ImportMeta.env` typing.
