from __future__ import annotations

import os
from dataclasses import dataclass


def _str(name: str, default: str = "") -> str:
    return os.getenv(name, default).strip()


def _int(name: str, default: int) -> int:
    try:
        return int(_str(name, str(default)))
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    app_env: str = _str("APP_ENV", "production")
    port: int = _int("PORT", 8787)
    database_url: str = _str("DATABASE_URL")
    jwt_secret: str = _str("PF_JWT_SECRET")
    allowed_origins: str = _str("PF_ALLOWED_ORIGINS", "http://localhost:5173,http://localhost:8080")
    access_token_minutes: int = _int("PF_ACCESS_TOKEN_MINUTES", 15)
    refresh_days: int = _int("PF_REFRESH_DAYS", 30)
    db_pool_size: int = _int("PF_DB_POOL_SIZE", 10)
    db_max_overflow: int = _int("PF_DB_MAX_OVERFLOW", 10)
    db_ssl: bool = _str("PF_DB_SSL", "false").lower() == "true"

    @property
    def normalized_database_url(self) -> str:
        url = self.database_url
        if url.startswith("postgres://"):
            return "postgresql+psycopg://" + url[len("postgres://"):]
        if url.startswith("postgresql://"):
            return "postgresql+psycopg://" + url[len("postgresql://"):]
        return url

    @property
    def production(self) -> bool:
        # Fail closed: security controls stay enabled unless development is explicit.
        return self.app_env.lower() != "development"

    def assert_valid(self) -> None:
        if not self.database_url:
            raise RuntimeError("DATABASE_URL is required.")
        if self.production and len(self.jwt_secret) < 32:
            raise RuntimeError("PF_JWT_SECRET must be at least 32 characters in production.")
        if self.access_token_minutes <= 0 or self.access_token_minutes > 60:
            raise RuntimeError("PF_ACCESS_TOKEN_MINUTES must be between 1 and 60.")
        if self.refresh_days <= 0 or self.refresh_days > 365:
            raise RuntimeError("PF_REFRESH_DAYS must be between 1 and 365.")

    def origins(self) -> list[str]:
        return [item.strip() for item in self.allowed_origins.split(",") if item.strip()]


settings = Settings()
