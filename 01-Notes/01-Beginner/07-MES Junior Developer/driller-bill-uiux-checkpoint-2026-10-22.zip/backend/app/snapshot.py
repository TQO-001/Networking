from __future__ import annotations

import json

from .constants import CLOUD_SCHEMA, CLOUD_VERSION, MAX_PAYLOAD_BYTES

_KNOWN_FIELDS = {
    "history", "seen", "session", "settings", "mastery", "authoring", "liveLab", "topology"
}


def _object(value: object) -> bool:
    return isinstance(value, dict)


def validate_cloud_snapshot(snapshot: object) -> dict:
    errors: list[str] = []
    if not _object(snapshot):
        errors.append("Snapshot must be an object.")
    if isinstance(snapshot, dict):
        if snapshot.get("schema") != CLOUD_SCHEMA:
            errors.append("Unsupported Driller Bill snapshot schema.")
        if snapshot.get("version") != CLOUD_VERSION:
            errors.append("Unsupported Driller Bill snapshot version.")
        data = snapshot.get("data")
        if not _object(data):
            errors.append("Snapshot data is missing.")
        else:
            for key in data:
                if key not in _KNOWN_FIELDS:
                    errors.append(f"Unknown snapshot field: {key}.")
            if "history" in data and not isinstance(data["history"], list):
                errors.append("history must be an array.")
            if "seen" in data and not _object(data["seen"]):
                errors.append("seen must be an object.")
            if "mastery" in data and not _object(data["mastery"]):
                errors.append("mastery must be an object.")
            if "authoring" in data and not isinstance(data["authoring"], list):
                errors.append("authoring must be an array.")
    payload_bytes = len(json.dumps(snapshot, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
    if payload_bytes > MAX_PAYLOAD_BYTES:
        errors.append("Snapshot exceeds the 2 MB limit.")
    return {"valid": not errors, "errors": errors, "bytes": payload_bytes}
