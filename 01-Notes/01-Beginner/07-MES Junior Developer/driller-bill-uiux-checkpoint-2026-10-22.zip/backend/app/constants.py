CLOUD_SCHEMA = "penny-farthing-study-backup"
CLOUD_VERSION = 1
MAX_PAYLOAD_BYTES = 2 * 1024 * 1024
