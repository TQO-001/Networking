from __future__ import annotations

import re

EMAIL_RE = re.compile(r"^(?=.{3,254}$)[^\s@]+@[^\s@]+\.[^\s@]+$")


def normalize_email(email: object) -> str:
    return str(email or "").strip().lower()


def validate_credentials(email: object, password: object) -> dict:
    normalized = normalize_email(email)
    if not EMAIL_RE.fullmatch(normalized):
        return {"ok": False, "error": "Enter a valid email address."}
    if not isinstance(password, str) or len(password) < 12:
        return {"ok": False, "error": "Password must be at least 12 characters."}
    if len(password.encode("utf-8")) > 72:
        return {"ok": False, "error": "Password must be 72 UTF-8 bytes or fewer."}
    return {"ok": True, "email": normalized}
