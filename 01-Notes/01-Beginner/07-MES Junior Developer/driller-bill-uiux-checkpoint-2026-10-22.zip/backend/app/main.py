from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
import os
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError

from .config import settings
from .constants import CLOUD_VERSION
from .db import session_scope
from .policy import validate_credentials
from .rate_limit import RateLimiter
from .security import (
    hash_password, hash_refresh_token, issue_access_token, new_id, new_refresh_token,
    verify_access_token, verify_password,
)
from .snapshot import validate_cloud_snapshot

if settings.production:
    settings.assert_valid()

def _application_version() -> str:
    configured = os.getenv("DRILLER_BILL_VERSION", "").strip()
    if configured:
        return configured
    # The cloud image copies package.json alongside the API, keeping the web
    # and API release identifiers aligned when no build-arg override is given.
    candidates = (Path("/app/package.json"), Path(__file__).resolve().parents[2] / "package.json")
    for candidate in candidates:
        try:
            version = json.loads(candidate.read_text(encoding="utf-8")).get("version")
            if isinstance(version, str) and version.strip():
                return version.strip()
        except (OSError, ValueError, TypeError):
            continue
    return "0.0.0"


APP_VERSION = _application_version()
app = FastAPI(title="Driller Bill API", version=APP_VERSION, docs_url="/docs", redoc_url=None)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.origins(),
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
)


@app.middleware("http")
async def prevent_api_response_caching(request: Request, call_next):
    """Keep identity and sync responses out of browser and intermediary caches."""
    response = await call_next(request)
    if request.url.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, private"
        response.headers["Pragma"] = "no-cache"
    return response

auth_limiter = RateLimiter(60, 12)
api_limiter = RateLimiter(60, 120)


@app.exception_handler(HTTPException)
async def http_exception_handler(_request: Request, exc: HTTPException):
    if isinstance(exc.detail, dict):
        payload = dict(exc.detail)
        payload.setdefault("error", payload.get("message", "Request failed."))
    else:
        payload = {"error": str(exc.detail)}
    return JSONResponse(status_code=exc.status_code, content=payload, headers=exc.headers)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(_request: Request, exc: RequestValidationError):
    return JSONResponse(status_code=400, content={"error": "Invalid request.", "details": exc.errors()})


class Credentials(BaseModel):
    model_config = ConfigDict(extra="forbid")
    email: str = Field(min_length=3, max_length=254)
    password: str = Field(min_length=1, max_length=200)


class SnapshotRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    payload: dict
    baseVersion: int = Field(default=0, ge=0)


def _client_key(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for", "")
    return (forwarded.split(",")[0].strip() or (request.client.host if request.client else "unknown"))


def _require_rate(limiter: RateLimiter, request: Request) -> None:
    if not limiter.allow(_client_key(request)):
        raise HTTPException(status_code=429, detail="Too many requests. Try again shortly.")


def _bearer(request: Request) -> str:
    header = request.headers.get("authorization", "")
    return header[7:].strip() if header.startswith("Bearer ") else ""


def _cookie_value(request: Request, name: str) -> str | None:
    return request.cookies.get(name)


def require_auth(request: Request) -> dict:
    _require_rate(api_limiter, request)
    token = _bearer(request)
    if not token:
        raise HTTPException(status_code=401, detail="Authentication required.")
    try:
        payload = verify_access_token(token)
        user_id = str(payload.get("sub", ""))
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid or expired authentication token.")
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid authentication token.")
    with session_scope() as db:
        row = db.execute(text("SELECT id, email FROM users WHERE id = :id"), {"id": user_id}).mappings().first()
    if not row:
        raise HTTPException(status_code=401, detail="User account not found.")
    return {"id": str(row["id"]), "email": row["email"]}


def _set_refresh_cookie(response: Response, token: str) -> None:
    response.set_cookie(
        key="pf_refresh",
        value=token,
        max_age=settings.refresh_days * 24 * 60 * 60,
        httponly=True,
        secure=settings.production,
        samesite="lax",
        path="/api/v1/auth",
    )


def _clear_refresh_cookie(response: Response) -> None:
    response.delete_cookie("pf_refresh", path="/api/v1/auth")


def _create_session(user_id: str, email: str, request: Request, response: Response) -> dict:
    token = new_refresh_token()
    expires_at = datetime.now(timezone.utc) + timedelta(days=settings.refresh_days)
    with session_scope() as db:
        db.execute(
            text("""
            INSERT INTO refresh_sessions(id, user_id, token_hash, expires_at, user_agent, ip_address)
            VALUES (:id, :user_id, :token_hash, :expires_at, :user_agent, :ip_address)
            """),
            {
                "id": new_id(), "user_id": user_id, "token_hash": hash_refresh_token(token),
                "expires_at": expires_at, "user_agent": request.headers.get("user-agent", "")[:1000],
                "ip_address": _client_key(request)[:128],
            },
        )
    _set_refresh_cookie(response, token)
    return {"accessToken": issue_access_token(user_id, email), "user": {"id": user_id, "email": email}}


@app.get("/api/v1/health")
def health() -> dict:
    try:
        with session_scope() as db:
            db.execute(text("SELECT 1"))
        return {"status": "ok", "database": "ok", "service": "driller-bill-api", "cloudVersion": CLOUD_VERSION}
    except Exception:
        raise HTTPException(status_code=503, detail={"status": "degraded", "database": "unavailable", "service": "driller-bill-api"})


@app.post("/api/v1/auth/register", status_code=201)
def register(body: Credentials, request: Request, response: Response) -> dict:
    _require_rate(auth_limiter, request)
    credentials = validate_credentials(body.email, body.password)
    if not credentials["ok"]:
        raise HTTPException(status_code=400, detail=credentials["error"])
    user_id = new_id()
    try:
        with session_scope() as db:
            db.execute(text("INSERT INTO users(id,email,password_hash) VALUES (:id,:email,:password_hash)"), {
                "id": user_id, "email": credentials["email"], "password_hash": hash_password(body.password),
            })
    except IntegrityError:
        raise HTTPException(status_code=409, detail="An account with that email already exists.")
    return _create_session(user_id, credentials["email"], request, response)


@app.post("/api/v1/auth/login")
def login(body: Credentials, request: Request, response: Response) -> dict:
    _require_rate(auth_limiter, request)
    credentials = validate_credentials(body.email, body.password)
    if not credentials["ok"]:
        raise HTTPException(status_code=400, detail=credentials["error"])
    with session_scope() as db:
        row = db.execute(text("SELECT id,email,password_hash FROM users WHERE email = :email"), {"email": credentials["email"]}).mappings().first()
    if not row or not verify_password(body.password, row["password_hash"]):
        raise HTTPException(status_code=401, detail="Email or password is incorrect.")
    return _create_session(str(row["id"]), row["email"], request, response)


@app.post("/api/v1/auth/refresh")
def refresh(request: Request, response: Response) -> dict:
    _require_rate(auth_limiter, request)
    old_token = _cookie_value(request, "pf_refresh")
    if not old_token:
        raise HTTPException(status_code=401, detail="No refresh session.")
    old_hash = hash_refresh_token(old_token)
    with session_scope() as db:
        row = db.execute(text("""
            SELECT rs.id, rs.user_id, u.email
            FROM refresh_sessions rs JOIN users u ON u.id = rs.user_id
            WHERE rs.token_hash = :token_hash AND rs.revoked_at IS NULL AND rs.expires_at > NOW()
        """), {"token_hash": old_hash}).mappings().first()
        if not row:
            raise HTTPException(status_code=401, detail="Refresh session expired or revoked.")
        rotated = new_refresh_token()
        expires_at = datetime.now(timezone.utc) + timedelta(days=settings.refresh_days)
        db.execute(text("UPDATE refresh_sessions SET revoked_at = NOW() WHERE id = :id"), {"id": row["id"]})
        db.execute(text("""
            INSERT INTO refresh_sessions(id,user_id,token_hash,expires_at,user_agent,ip_address)
            VALUES (:id,:user_id,:token_hash,:expires_at,:user_agent,:ip_address)
        """), {
            "id": new_id(), "user_id": row["user_id"], "token_hash": hash_refresh_token(rotated), "expires_at": expires_at,
            "user_agent": request.headers.get("user-agent", "")[:1000], "ip_address": _client_key(request)[:128],
        })
    _set_refresh_cookie(response, rotated)
    return {"accessToken": issue_access_token(str(row["user_id"]), row["email"]), "user": {"id": str(row["user_id"]), "email": row["email"]}}


@app.post("/api/v1/auth/logout", status_code=204)
def logout(request: Request, response: Response) -> Response:
    _require_rate(auth_limiter, request)
    token = _cookie_value(request, "pf_refresh")
    try:
        if token:
            with session_scope() as db:
                db.execute(text("UPDATE refresh_sessions SET revoked_at = NOW() WHERE token_hash = :token_hash AND revoked_at IS NULL"), {"token_hash": hash_refresh_token(token)})
    finally:
        _clear_refresh_cookie(response)
    return response


@app.get("/api/v1/me")
def me(user: dict = Depends(require_auth)) -> dict:
    return {"user": user}


@app.get("/api/v1/sync")
def get_sync(user: dict = Depends(require_auth)) -> dict:
    with session_scope() as db:
        row = db.execute(text("SELECT version,payload,updated_at FROM cloud_documents WHERE user_id = :user_id"), {"user_id": user["id"]}).mappings().first()
    if not row:
        return {"exists": False, "version": 0, "payload": None, "updatedAt": None}
    return {"exists": True, "version": int(row["version"]), "payload": row["payload"], "updatedAt": row["updated_at"]}


def _save_snapshot(user: dict, body: SnapshotRequest, force: bool) -> dict:
    validation = validate_cloud_snapshot(body.payload)
    if not validation["valid"]:
        raise HTTPException(status_code=400, detail={"error": "Invalid cloud snapshot.", "details": validation["errors"]})
    with session_scope() as db:
        row = db.execute(text("SELECT version,payload,updated_at FROM cloud_documents WHERE user_id = :user_id FOR UPDATE"), {"user_id": user["id"]}).mappings().first()
        current_version = int(row["version"]) if row else 0
        if not force and row and current_version != body.baseVersion:
            return {
                "__conflict__": True,
                "status_code": 409,
                "server": {"version": current_version, "payload": row["payload"], "updatedAt": row["updated_at"]},
            }
        next_version = current_version + 1
        db.execute(text("""
            INSERT INTO cloud_documents(user_id,version,payload,updated_at)
            VALUES (:user_id,:version,CAST(:payload AS jsonb),NOW())
            ON CONFLICT(user_id) DO UPDATE SET version=EXCLUDED.version,payload=EXCLUDED.payload,updated_at=NOW()
        """), {"user_id": user["id"], "version": next_version, "payload": json.dumps(body.payload, separators=(",", ":"))})
    return {"saved": True, "version": next_version}


@app.put("/api/v1/sync")
def put_sync(body: SnapshotRequest, user: dict = Depends(require_auth)) -> dict:
    result = _save_snapshot(user, body, False)
    if result.get("__conflict__"):
        raise HTTPException(status_code=409, detail={"code": "SYNC_CONFLICT", "server": result["server"]})
    return result


@app.post("/api/v1/sync/overwrite")
def overwrite_sync(body: SnapshotRequest, user: dict = Depends(require_auth)) -> dict:
    return _save_snapshot(user, body, True)
