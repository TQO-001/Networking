from __future__ import annotations

import sys
import unittest
from pathlib import Path

BACKEND_ROOT = Path(__file__).resolve().parents[1]
if str(BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(BACKEND_ROOT))


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.discover(str(BACKEND_ROOT / "tests"), pattern="test_*.py", top_level_dir=str(BACKEND_ROOT.parent))
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
