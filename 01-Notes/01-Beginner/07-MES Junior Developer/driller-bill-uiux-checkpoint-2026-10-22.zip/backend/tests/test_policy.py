from __future__ import annotations

import unittest

from app.policy import normalize_email, validate_credentials
from app.snapshot import validate_cloud_snapshot
from app.constants import CLOUD_SCHEMA, CLOUD_VERSION


class PolicyTests(unittest.TestCase):
    def test_credentials_normalize_and_bound(self):
        self.assertEqual(normalize_email("  STUDENT@EXAMPLE.COM "), "student@example.com")
        self.assertTrue(validate_credentials("student@example.com", "this-is-a-good-strong-password")["ok"])
        self.assertFalse(validate_credentials("bad", "this-is-a-good-strong-password")["ok"])
        self.assertFalse(validate_credentials("student@example.com", "short")["ok"])

    def test_snapshot_schema(self):
        valid = validate_cloud_snapshot({
            "schema": CLOUD_SCHEMA,
            "version": CLOUD_VERSION,
            "data": {"history": [], "seen": {}, "mastery": {}, "authoring": [], "settings": {}},
        })
        self.assertTrue(valid["valid"])

    def test_snapshot_rejects_unknown_fields(self):
        result = validate_cloud_snapshot({
            "schema": CLOUD_SCHEMA,
            "version": CLOUD_VERSION,
            "data": {"history": {}, "secret": "x"},
        })
        self.assertFalse(result["valid"])
        self.assertTrue(any("Unknown snapshot field" in item for item in result["errors"]))
        self.assertTrue(any("history must be an array" in item for item in result["errors"]))


if __name__ == "__main__":
    unittest.main()


class ConfigSecurityTests(unittest.TestCase):
    def test_only_explicit_development_disables_production_guards(self):
        from app.config import Settings

        self.assertFalse(Settings(app_env="development").production)
        self.assertTrue(Settings(app_env="production").production)
        self.assertTrue(Settings(app_env="staging").production)
        self.assertTrue(Settings(app_env="").production)

    def test_production_requires_a_long_jwt_secret(self):
        from app.config import Settings

        settings = Settings(app_env="preview", database_url="postgresql://example/db", jwt_secret="too-short")
        with self.assertRaisesRegex(RuntimeError, "at least 32 characters"):
            settings.assert_valid()
