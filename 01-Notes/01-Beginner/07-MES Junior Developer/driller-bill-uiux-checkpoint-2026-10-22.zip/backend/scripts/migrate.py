from __future__ import annotations

from pathlib import Path

from sqlalchemy import text

from app.db import get_engine


def main() -> None:
    engine = get_engine()
    migration_dir = Path(__file__).resolve().parents[1] / "migrations" / "versions"
    with engine.begin() as connection:
        connection.execute(text("CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW())"))
        for path in sorted(migration_dir.glob("*.sql")):
            version = path.name
            applied = connection.execute(text("SELECT 1 FROM schema_migrations WHERE version = :version"), {"version": version}).first()
            if applied:
                continue
            for statement in [part.strip() for part in path.read_text(encoding="utf-8").split(";\n") if part.strip()]:
                connection.execute(text(statement))
            connection.execute(text("INSERT INTO schema_migrations(version) VALUES (:version)"), {"version": version})
    print("Database migrations: PASS")


if __name__ == "__main__":
    main()
