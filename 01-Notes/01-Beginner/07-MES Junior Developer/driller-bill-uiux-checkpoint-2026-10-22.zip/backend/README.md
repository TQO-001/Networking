# Driller Bill Python API

FastAPI + SQLAlchemy + PostgreSQL backend for optional Driller Bill cloud sync.

## Run locally

```bash
python -m venv .venv
. .venv/bin/activate
pip install -r backend/requirements.txt
export DATABASE_URL='postgresql+psycopg://pennyfarthing:password@localhost:5432/pennyfarthing'
export PF_JWT_SECRET='replace-with-at-least-32-random-characters'
python backend/scripts/migrate.py
uvicorn app.main:app --app-dir backend --reload --port 8787
```

## Test

```bash
python backend/tests/run_tests.py
```

The frontend keeps the same `/api/v1` contract, so the React cloud UI does not need a rewrite just because the backend implementation is now Python.


## Runtime environment

Set `APP_ENV=development` explicitly for local development. Any other value (including an unset variable) enables production security checks. Production deployments must provide `DATABASE_URL` and a `PF_JWT_SECRET` containing at least 32 characters.
