# Driller Bill integration notes

This release adopts **Driller Bill** as the product identity and integrates the earlier Driller Bill v0.5.1 training system into the modern CCNA platform.

## Preserved legacy capabilities

- 22 reusable module engines across switches, routers, servers, and firewalls.
- Guided theory → simulation → hands-on terminal practice.
- Speed Drill mode with target timing and scoring.
- Open Sandbox practice without graded objectives.
- Twin session recording with error/typo telemetry, sensitive-value redaction, Markdown artifacts, and ZIP export.
- Built-in Markdown networking notes.
- Declarative community Drill Builder (schema v1).
- Module-level XP/progress tracking.

## Modern platform retained

- Randomized CCNA exams and five-variant question families.
- Evidence exhibits and multi-step scenario forms.
- Stateful multi-device networking, topology, protocol, packet, and PBQ labs.
- Adaptive mastery and spaced repetition.
- Question Authoring Studio.
- Offline data safety and optional FastAPI/PostgreSQL cloud sync.

The old module engines are loaded through `src/driller-bill/DrillCatalog.js` and validated independently by `npm run validate:driller-bill`. The modern network simulator remains the canonical engine for the newer lab surfaces.
