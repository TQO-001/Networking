# Driller Bill Cloud Deployment

Driller Bill no longer requires the Docker/Nginx deployment.

Recommended self-hosted layout:

```text
Internet
   |
 Nginx / TLS
   |
   +-- React web container
   |
   +-- /api -> FastAPI container -> PostgreSQL
```

The included `docker-compose.cloud.yml` uses three services:

- `driller-bill-web`
- `driller-bill-api`
- `driller-bill-db`

Set `PF_DB_PASSWORD`, `PF_JWT_SECRET`, and `PF_ALLOWED_ORIGINS` in the environment before starting the stack.

```bash
docker compose -f docker-compose.cloud.yml up -d --build
npm run smoke:cloud
```

The smoke check calls `/api/v1/health` through the published web/Nginx endpoint (`http://127.0.0.1:8080` by default) and verifies both API and database health. Set `CLOUD_SMOKE_URL` to check a different origin. The API release defaults to the version in the root `package.json`; set `DRILLER_BILL_VERSION` only when intentionally overriding it.

The API automatically applies versioned SQL migrations before starting Uvicorn.

For an external Nginx reverse proxy, proxy `/api/` to the API container and `/` to the web container, with HTTPS termination at Nginx.
