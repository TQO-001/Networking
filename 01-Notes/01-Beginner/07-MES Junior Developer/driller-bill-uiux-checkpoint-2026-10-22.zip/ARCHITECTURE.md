## v59 — Change Control & Operational Hardening

`src/core/change-control.js` is the deterministic change-control boundary. It classifies typed configuration intents, builds preflight checks, normalizes sanitized audit records, and supplies rollback guidance without automatically executing a rollback. The Device Agent keeps raw executable plans in memory only while a preflight is active. Physical SSH/serial mutations require a matching short-lived `changeId`; simulated mutations retain compatibility by creating an internal preflight.

The Device Agent persists sanitized change history beside device registrations, configuration history and inspections. Browser-facing snapshots, apply transcripts and change records contain display-safe commands/configuration only; credential-bearing simulated state is removed from mutation responses.

The Configuration workspace exposes `Plan → Preflight → Approve → Apply → Verify`, and Runbook steps reuse the same preflight/approval transaction rather than bypassing change control. This preserves one deterministic mutation path for UI, Runbooks, Twin proposals and future AI integrations.

## v58 — Unified Workflow Orchestration

The application now has a local-first workflow orchestration layer (`src/core/unified-workflows.js`) and a workspace surface (`src/UnifiedWorkflows.jsx`). A workflow persists its template, target, ordered stages, notes, artifacts and timeline. Stage-to-view mapping is shared through `UnifiedWorkflowBar.jsx`, while App owns navigation. Workflow state contains engineering context only; credentials remain agent-side.

## v57 — Serial / Console Transport

The Device Agent now exposes three transport implementations behind the same browser-facing protocol: `simulated`, `ssh`, and `serial`. Credentials and transport handles remain in the local agent. Configuration, Runbooks, Troubleshooting, inspection, history and Twin workflows consume the adapter interface rather than transport-specific APIs.

## v56 — Network & Device Operations

The typed configuration layer now models a wider network-operations surface. UI, Runbooks and Twin share the same intent validation/rendering pipeline, while simulated inspection exposes structured protocol/service state for verification. Credential-bearing operations are execution-only and redacted at display boundaries.

## v55 — Twin Intelligence

The engineering workspace now has a local-first Twin Intelligence layer. It retrieves relevant Knowledge Graph articles, consumes structured inspection/diagnostic evidence, ranks context, explains observations, and can translate supported natural-language requests into deterministic typed intent proposals. The Twin never applies a proposed live configuration itself; approved changes continue through the existing Preview → Apply → Verify pipeline.

Model handoff is deliberately explicit: `buildModelContext()` produces a redacted JSON package containing the current reasoning context and safety rules. This allows an external LLM to be added later without making credentials or an external model a hidden dependency of the core application.


## v54 — Troubleshooting Workspace

The operational layer now contains a structured troubleshooting engine and UI. Cases model symptoms, hypotheses, tests, observed evidence and typed remediation candidates. The workspace can inspect shared simulated devices locally or collect read-only evidence from live devices through the Device Agent.

### v60 multi-device change-set layer

The engineering stack now includes a change-set orchestration boundary above the v59 single-device change-control contract:

```text
Change Set
  ├─ Device A → plan → preflight → approval → apply → verify
  ├─ Device B → plan → preflight → approval → apply → verify
  └─ Device N → plan → preflight → approval → apply → verify
```

Each target remains independent for change history and failure state. The coordinator supports stop-on-failure and continue-on-failure strategies but never performs implicit rollback.
