# Penny Farthing browser testing

Install dependencies, then install the Playwright browser once:

```bash
npm install
npx playwright install chromium
```

Fast local quality gate:

```bash
npm run qa
```

Full release gate:

```bash
npm run qa:release
```

The browser suite covers app boot, sidebar orientation/overflow, workspace navigation without exit buttons, starting a full simulation, mobile navigation, and unexpected page errors. CI keeps a trace, screenshot, and video on browser-test failures.
