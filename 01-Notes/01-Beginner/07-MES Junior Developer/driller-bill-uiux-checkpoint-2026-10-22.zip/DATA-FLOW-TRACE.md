# Penny Farthing React data-flow trace

## 1. Where state is initialized

`App` owns the application state with React `useState`:

- `view` / `screen` control the active workspace and presentation mode.
- `mode`, `domain`, `adaptive`, `coldStart`, `difficulty` configure exam generation.
- `history`, `seen`, `savedSession`, `settings`, and `mastery` hydrate from local storage through lazy initializers.
- `questions`, `answers`, `review`, `index`, `startedAt`, `endAt`, `timeLeft`, and `result` describe the active assessment.
- `sidebarCollapsed` and `mobileNavOpen` control the sidebar UI state.

## 2. How props are passed down

`App` passes the sidebar its current `view`, `collapsed`, `mobileOpen`, `assessmentActive`, and callback props. The navigation callback is deliberately named `onNavigate` rather than `setView`, making it explicit that the child is invoking a parent-owned action rather than owning navigation state.

`Dashboard` receives state plus actions through `homeProps`. Feature pages receive their own `onHome` / `onBack` callbacks derived from `navigateToView`.

## 3. Where side effects occur

- Local storage reads happen in lazy state initializers.
- `persistSession` writes the active exam snapshot to local storage.
- The exam timer effect installs and cleans up its interval.
- The session persistence effect saves answer/index/review changes.
- The keyboard shortcut effect installs and removes its global key listener.
- Mastery/history writes occur during assessment completion and review grading.
- Sidebar collapse state is persisted when changed.

## 4. Parent/child data flow

For sidebar navigation:

`App state (view)` → `NavigationSidebar.view` → user click → `NavigationSidebar.onNavigate(next)` → `App.navigateToView(next)` → `setView(next)` / `setScreen('home')` → React render → updated `view` prop returns to the sidebar.

Development builds log each stage with `[Penny Farthing][data-flow]` and `[Penny Farthing][data-flow][Sidebar]` prefixes.

## Sidebar bug identified and fixed

Previously, `App` returned `Exam` and `Study` before entering the `workspace()` shell. That meant the persistent sidebar was unmounted on those screens. The v17.2 audit build routes both screens through the workspace shell, while active assessments protect navigation with a confirmation and hide quick-start replacement actions.


## Dashboard component flow

`App` initializes the dashboard data and callbacks. It passes `history`, `objective`, `wrongCount`, configuration state, `masteryDue`, and action callbacks into `Dashboard` through `homeProps` and the spread props. `Dashboard` does not own application state; its controls call the setter/callback props supplied by `App`.

Development-only logs were added to `Dashboard` for: initial props, cleanup, starting an assessment, and navigation actions. This validates the parent-to-child and child-to-parent flow in the browser console.
