# Driller Bill

Current release: **v64.0.6 — Workspace layouts + terminal ergonomics**

Driller Bill is a local-first network-engineering workspace for learning, network simulation, IOS-style CLI practice, topology work, troubleshooting, documentation and carefully controlled device operations. The app combines CCNA learning with practical engineering tools and an optional local Device Agent for simulated, SSH and serial/console transports.

## Quick start

Requirements: Node.js 22 (or Node.js 20.19+), npm, and a modern browser.

```bash
npm install
npm run dev
```

Run the available project checks before making changes:

```bash
npm run check
npm run deploy:preflight
```

Production assets are built with `npm run build`. Browser smoke tests run with `npm run qa:e2e` after project dependencies and Playwright Chromium are installed. See [E2E testing](E2E-TESTING.md) for details.

## What it includes

### Learning and simulation

- Twenty-two Driller Bill module engines covering switches, routers, servers and firewalls.
- Guided theory, simulation and hands-on CLI drills, plus Speed Drill and Open Sandbox modes.
- Module-level XP/progress, session recording, networking notes and a schema-based Drill Builder.
- Randomized CCNA theory exams, 1,935 authored questions across 387 families, exhibits, multi-step scenarios and advanced performance-based questions.
- Stateful CLI, topology and packet simulation, adaptive mastery, spaced repetition and question authoring.

### Network-engineering workspaces

- Device inventory, structured inspection and local simulated/SSH/serial console access.
- Typed configuration intents and explainable plans for switching, routing, OSPF, ACLs, access-port security, STP, EtherChannel, NAT, DHCP, management and IPv6.
- Runbooks, evidence-driven troubleshooting, network discovery, topology reconciliation and a connected Knowledge Base.
- Change control for physical devices using **Plan → Preflight → Approve → Apply → Verify**, including baseline/post-change snapshots and a sanitized history.
- Twin Intelligence for reviewing evidence, planning next steps and producing documentation with sensitive-value redaction.
- Local-first data backup/recovery and an optional FastAPI + PostgreSQL cloud layer.

## Local Device Agent

The optional Device Agent runs on the machine that has access to your lab devices:

```bash
node agent/server.mjs
```

It prints a bearer token. Enter that token in **Engineering → Devices**. The agent binds to `127.0.0.1:8788` by default. SSH uses the host OpenSSH client; serial/console connections use the `serialport` package and local paths such as `COM3` or `/dev/ttyUSB0`.

For password authentication, set the password in an environment variable before launching the agent and enter only the variable name in Driller Bill. The browser sends the environment-variable name, never the password. Key-based authentication can use a private-key path or the host SSH agent. Host-key verification defaults to `accept-new`. Raw command execution on physical devices is read-only; configuration mutations must use the change-control workflow. See [Device Agent documentation](agent/README.md).

## Cloud deployment

The optional hosted stack is Nginx + FastAPI + PostgreSQL via Docker Compose. Set `PF_DB_PASSWORD` and `PF_JWT_SECRET` before deployment and follow [Cloud deployment](CLOUD-DEPLOY.md). Docker and a cloud database are not required for the local-first learning and simulation workflows.

## Data and security

- Browser-side app data is local-first; export backups before clearing site data.
- Physical-device credentials remain in the local agent process and are not returned to the browser.
- Configuration changes go through an explicit review and change-control path; device changes must still be validated against the actual target equipment and site procedures.
- The agent enforces read-only raw commands on physical devices and stores a capped audit history of attempts.

## Documentation

- [Architecture](ARCHITECTURE.md)
- [Data flow trace](DATA-FLOW-TRACE.md)
- [Legacy migration map](DRILLER-BILL-MIGRATION.md)
- [Cloud deployment](CLOUD-DEPLOY.md)
- [Release history](RELEASE-NOTES.md)
- [Historical release notes and test reports](docs/releases/)
- [Improvement audit and roadmap](docs/IMPROVEMENT-AUDIT-ROADMAP.md)

## License and status

This repository is an actively developed workspace. Automated checks cover authored content, core logic, module metadata, local-agent behavior and backend policies; Docker builds, browser interaction, and real SSH/serial hardware should be verified in an environment with the needed dependencies and equipment before production use.
