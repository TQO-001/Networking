import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, Route, Routes, useNavigate, useLocation } from 'react-router-dom';
import SideRays from './components/SideRays.jsx';
import GhostCursor from './components/GhostCursor.jsx';
import WarpText from './components/WarpText.jsx';

const iconPaths = {
  book: <><path d="M4 5.5A3.5 3.5 0 0 1 7.5 2H20v18H7.5A3.5 3.5 0 0 0 4 23z"/><path d="M4 5.5v17.2M8 6h8M8 10h7"/></>,
  home: <><path d="m3 10 9-7 9 7"/><path d="M5 9v11h14V9M9 20v-7h6v7"/></>,
  sun: <><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></>,
  moon: <path d="M20.5 14A8.5 8.5 0 0 1 10 3.5 8.5 8.5 0 1 0 20.5 14Z"/>,
  arrow: <><path d="M5 12h14M13 6l6 6-6 6"/></>,
  lock: <><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/></>,
  user: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
  mail: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></>,
  shield: <><path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="m9 12 2 2 4-4"/></>,
  network: <><rect x="3" y="4" width="7" height="6" rx="1"/><rect x="14" y="4" width="7" height="6" rx="1"/><rect x="8.5" y="15" width="7" height="6" rx="1"/><path d="M6.5 10v2h11v-2M12 12v3"/></>,
  plus: <path d="M12 5v14M5 12h14"/>,
  upload: <><path d="M12 16V3m0 0L7 8m5-5 5 5M4 15v5h16v-5"/></>,
  trash: <><path d="M3 6h18M8 6V3h8v3m3 0-1 15H6L5 6m4 4v7m6-7v7"/></>,
  logout: <><path d="M10 17l5-5-5-5M15 12H3"/><path d="M12 3h7a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-7"/></>,
  clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
  menu: <><path d="M3 6h18M3 12h18M3 18h18"/></>,
};
function Icon({ name, size = 18, className = '' }) {
  return <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{iconPaths[name] || iconPaths.network}</svg>;
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    credentials: 'same-origin',
    ...options,
    headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || 'The request could not be completed.');
    error.status = response.status;
    error.code = data.code;
    throw error;
  }
  return data;
}

function Brand({ compact = false, light = false }) {
  return <Link to="/" className={`brand-lockup${compact ? ' brand-compact' : ''}${light ? ' brand-light' : ''}`} aria-label="Holly Bibley home">
    <span className="brand-mark"><Icon name="book" size={21} /></span>
    <span className="brand-name">Holly Bibley</span>
  </Link>;
}

function ThemeButton({ theme, setTheme }) {
  return <button className="icon-button" type="button" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`} title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}><Icon name={theme === 'dark' ? 'sun' : 'moon'} size={18} /></button>;
}

function useThemePreference() {
  const [theme, setThemeState] = useState(() => {
    try { return localStorage.getItem('holly-bibley-theme-v1') || 'dark'; } catch { return 'dark'; }
  });
  const setTheme = (next) => {
    const resolved = next === 'light' ? 'light' : 'dark';
    setThemeState(resolved);
    try { localStorage.setItem('holly-bibley-theme-v1', resolved); } catch { /* Theme is only a preference. */ }
  };
  useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]);
  return [theme, setTheme];
}

function Home() {
  const [theme, setTheme] = useThemePreference();
  return <main className="landing-page">
    <div className="landing-atmosphere" aria-hidden="true"><SideRays rayColor1="#E5B84B" rayColor2="#8C6A27" origin="top-right" speed={0.72} intensity={1.15} spread={2.4} density={4} sharpness={0.35} glow={1.1} opacity={0.65} dust={0.06} followMouse={false} /><div className="landing-vignette" /></div>
    <GhostCursor color="#D5A93F" size={58} trailLength={32} inertia={0.25} turbulence={0.35} drift={0.2} bloomStrength={0.5} brightness={0.8} theme="dark" clickPuff={false} intro={false} zIndex={1} />
    <header className="landing-header"><Brand light /><ThemeButton theme={theme} setTheme={setTheme} /></header>
    <section className="landing-hero">
      <img className="praying-illustration" src="/assets/praying-person-placeholder.svg" alt="Transparent placeholder illustration of a person praying" />
      <div className="hero-ornament" aria-hidden="true"><span /><i>✦</i><span /></div>
      <WarpText text="Holly Bibley" color="#F1D58A" warpStrength={0.045} warpScale={1.6} speed={0.25} pointerInfluence={0.23} pointerStrength={0.12} refraction={0.007} chromatic={0.05} ripple={false} clickRipple={false} idleDrift={0.04} intro fontSize="clamp(3rem, 9vw, 7.1rem)" fontWeight={500} fontFamily="Georgia, 'Times New Roman', serif" letterSpacing="-0.055em" style={{ height: 'clamp(110px, 21vw, 210px)', minHeight: 110, width: 'min(100%, 920px)' }} />
      <div className="landing-buttons"><Link className="button button-gold" to="/login">Login <Icon name="arrow" size={16} /></Link><Link className="button button-outline-gold" to="/signup">Sign Up <Icon name="arrow" size={16} /></Link></div>
    </section>
    <footer className="landing-footer"><span>MAP WITH INTENTION</span><span className="footer-separator"/><span>BUILD WITH CLARITY</span><span className="footer-separator"/><span>HOLLY BIBLEY</span></footer>
  </main>;
}

function AuthLayout({ children, title, description, backLabel = 'Back to home' }) {
  const [theme, setTheme] = useThemePreference();
  return <main className="auth-page">
    <div className="auth-atmosphere" aria-hidden="true"><SideRays rayColor1="#E5B84B" rayColor2="#8C6A27" origin="top-right" speed={0.42} intensity={0.7} spread={2.1} density={3} sharpness={0.32} opacity={0.3} followMouse={false} /></div>
    <header className="auth-header"><Brand light /><div className="auth-head-actions"><ThemeButton theme={theme} setTheme={setTheme} /><Link className="back-link" to="/">{backLabel}</Link></div></header>
    <div className="auth-shell"><div className="auth-symbol"><Icon name="book" size={24}/></div><p className="eyebrow">WELCOME TO HOLLY BIBLEY</p><h1>{title}</h1><p className="auth-description">{description}</p>{children}</div>
    <p className="auth-footnote"><Icon name="shield" size={14}/> Your diagrams are stored in your account and protected by server-side access controls.</p>
  </main>;
}

function FormMessage({ error, success }) {
  if (!error && !success) return null;
  return <div className={`form-message ${error ? 'is-error' : 'is-success'}`} role="status">{error || success}</div>;
}

function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [needsVerification, setNeedsVerification] = useState(false);
  const [busy, setBusy] = useState(false);
  useEffect(() => { let active = true; api('/api/auth/me').then(() => { if (active) navigate('/dashboard', { replace: true }); }).catch(() => {}); return () => { active = false; }; }, [navigate]);
  async function submit(event) {
    event.preventDefault(); setError(''); setNeedsVerification(false); setBusy(true);
    try { await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }); navigate('/dashboard', { replace: true }); }
    catch (e) { setError(e.message); setNeedsVerification(e.code === 'EMAIL_NOT_VERIFIED'); }
    finally { setBusy(false); }
  }
  return <AuthLayout title="Welcome back" description="Sign in to pick up where your network diagrams left off.">
    <form className="auth-form" onSubmit={submit}>
      <label className="input-label">Email address<div className="input-wrap"><Icon name="mail" size={17}/><input type="email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" placeholder="you@example.com" required maxLength={254}/></div></label>
      <label className="input-label">Password<div className="input-wrap"><Icon name="lock" size={17}/><input type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" placeholder="Your password" required maxLength={128}/></div></label>
      <div className="form-links"><span>Keep your account private</span><Link to="/forgot-password">Forgot password?</Link></div>
      <FormMessage error={error}/>
      {needsVerification && <p className="auth-inline-link"><Link to={`/verify-email?email=${encodeURIComponent(email)}`}>Resend verification email</Link></p>}
      <button className="button button-gold button-wide" type="submit" disabled={busy}>{busy ? 'Signing in…' : 'Login'} <Icon name="arrow" size={17}/></button>
    </form>
    <p className="auth-switch">New to Holly Bibley? <Link to="/signup">Create an account</Link></p>
  </AuthLayout>;
}

function Signup() {
  const navigate = useNavigate();
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(event) {
    event.preventDefault(); setError(''); setBusy(true);
    try { const result = await api('/api/auth/signup', { method: 'POST', body: JSON.stringify({ displayName, email, password }) }); navigate(`/verify-email?email=${encodeURIComponent(email)}`, { replace: true, state: { message: result.message } }); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }
  return <AuthLayout title="Make it yours" description="Create your account to keep network diagrams saved, organised, and private.">
    <form className="auth-form" onSubmit={submit}>
      <label className="input-label">Your name<div className="input-wrap"><Icon name="user" size={17}/><input value={displayName} onChange={e => setDisplayName(e.target.value)} autoComplete="name" placeholder="How should we address you?" required maxLength={80}/></div></label>
      <label className="input-label">Email address<div className="input-wrap"><Icon name="mail" size={17}/><input type="email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" placeholder="you@example.com" required maxLength={254}/></div></label>
      <label className="input-label">Password<div className="input-wrap"><Icon name="lock" size={17}/><input type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="new-password" placeholder="At least 12 characters" required minLength={12} maxLength={128}/></div></label>
      <p className="field-note">Use at least 12 characters. A longer, unique passphrase is even better.</p>
      <FormMessage error={error}/>
      <button className="button button-gold button-wide" type="submit" disabled={busy}>{busy ? 'Creating account…' : 'Create account'} <Icon name="arrow" size={17}/></button>
    </form>
    <p className="auth-switch">Already have an account? <Link to="/login">Login</Link></p>
  </AuthLayout>;
}


function VerifyEmail() {
  const location = useLocation();
  const navigate = useNavigate();
  const params = new URLSearchParams(location.search);
  const token = params.get('token') || '';
  const verifiedInUrl = params.get('verified') === '1';
  const [email, setEmail] = useState(params.get('email') || '');
  const initialMessage = location.state?.message || '';
  const [error, setError] = useState(initialMessage.toLowerCase().includes('could not be delivered') ? initialMessage : '');
  const [success, setSuccess] = useState(initialMessage && !initialMessage.toLowerCase().includes('could not be delivered') ? initialMessage : '');
  const [busy, setBusy] = useState(false);
  const [verified, setVerified] = useState(false);

  async function verify(event) {
    event.preventDefault(); setError(''); setBusy(true);
    try {
      const result = await api('/api/auth/email-verification/complete', { method: 'POST', body: JSON.stringify({ token }) });
      setSuccess(result.message || 'Your email is verified.');
      setVerified(true);
      navigate('/verify-email?verified=1', { replace: true, state: { message: result.message || 'Your email is verified.' } });
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }
  async function resend(event) {
    event.preventDefault(); setError(''); setSuccess(''); setBusy(true);
    try { const result = await api('/api/auth/email-verification/request', { method: 'POST', body: JSON.stringify({ email }) }); setSuccess(result.message); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }

  const showVerified = verified || verifiedInUrl;
  return <AuthLayout title={showVerified ? 'You’re verified' : token ? 'Confirm your email' : 'Check your inbox'} description={showVerified ? 'Your email address is verified and your account is ready.' : token ? 'Confirm that you own this email address to activate your account.' : 'Use the link in the verification email to activate your Holly Bibley account.'}>
    {token || showVerified ? <form className="auth-form" onSubmit={verify}>
      {!showVerified && <p className="field-note">Verification links expire after 24 hours and can only be used once.</p>}
      <FormMessage error={error} success={success}/>
      {showVerified ? <button className="button button-gold button-wide" type="button" onClick={() => navigate('/dashboard', { replace: true })}>Continue to your diagrams <Icon name="arrow" size={17}/></button> : <><button className="button button-gold button-wide" type="submit" disabled={busy}>{busy ? 'Verifying…' : 'Verify email address'} <Icon name="arrow" size={17}/></button><p className="auth-switch"><Link to="/verify-email">Request a fresh verification link</Link></p></>}
    </form> : <>
      <FormMessage error={error} success={success}/>
      <form className="auth-form" onSubmit={resend}>
        <label className="input-label">Email address<div className="input-wrap"><Icon name="mail" size={17}/><input type="email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" placeholder="you@example.com" required maxLength={254}/></div></label>
        <button className="button button-gold button-wide" type="submit" disabled={busy}>{busy ? 'Sending…' : 'Send verification link again'} <Icon name="arrow" size={17}/></button>
      </form>
      <p className="auth-switch">Already verified? <Link to="/login">Login</Link></p>
    </>}
    <p className="auth-switch"><Link to="/login">Back to login</Link></p>
  </AuthLayout>;
}

function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(event) {
    event.preventDefault(); setError(''); setSuccess(''); setBusy(true);
    try { const result = await api('/api/auth/password-reset/request', { method: 'POST', body: JSON.stringify({ email }) }); setSuccess(result.message + (import.meta.env.DEV ? ' If running locally without SMTP, check the API terminal for the development link.' : '')); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }
  return <AuthLayout title="Reset password" description="We’ll send reset instructions if an account exists for that email.">
    <form className="auth-form" onSubmit={submit}>
      <label className="input-label">Email address<div className="input-wrap"><Icon name="mail" size={17}/><input type="email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" placeholder="you@example.com" required maxLength={254}/></div></label>
      <FormMessage error={error} success={success}/>
      <button className="button button-gold button-wide" type="submit" disabled={busy}>{busy ? 'Requesting…' : 'Send reset instructions'} <Icon name="arrow" size={17}/></button>
    </form>
    <p className="auth-switch"><Link to="/login">Return to login</Link></p>
  </AuthLayout>;
}


function SignedOut() {
  return <AuthLayout title="You’re signed out" description="Your session has been closed on this browser. Your saved diagrams remain in your account.">
    <div className="signed-out-actions"><Link className="button button-gold button-wide" to="/login">Login again <Icon name="arrow" size={17}/></Link><Link className="button button-subtle button-wide" to="/">Return to home</Link></div>
  </AuthLayout>;
}

function ResetPassword() {
  const navigate = useNavigate();
  const token = new URLSearchParams(useLocation().search).get('token') || '';
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(event) {
    event.preventDefault(); setError(''); setSuccess(''); setBusy(true);
    try { const data = await api('/api/auth/password-reset/complete', { method: 'POST', body: JSON.stringify({ token, password }) }); setSuccess(data.message || 'Password updated.'); setTimeout(() => navigate('/login', { replace: true }), 1200); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }
  return <AuthLayout title="Choose a new password" description="Reset links expire after 30 minutes and can only be used once.">
    {!token ? <FormMessage error="This reset link has no token. Request a new one from the login page."/> : <form className="auth-form" onSubmit={submit}>
      <label className="input-label">New password<div className="input-wrap"><Icon name="lock" size={17}/><input type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="new-password" minLength={12} maxLength={128} placeholder="At least 12 characters" required/></div></label>
      <FormMessage error={error} success={success}/>
      <button className="button button-gold button-wide" type="submit" disabled={busy}>{busy ? 'Updating…' : 'Update password'} <Icon name="arrow" size={17}/></button>
    </form>}
    <p className="auth-switch"><Link to="/login">Back to login</Link></p>
  </AuthLayout>;
}

function Header({ user, onSignOut, theme, setTheme }) {
  return <header className="app-header"><Brand/><div className="header-right"><Link className="header-link" to="/guide">Field guide</Link><ThemeButton theme={theme} setTheme={setTheme}/><div className="user-chip"><span className="user-avatar">{(user?.displayName || user?.email || 'H').slice(0,1).toUpperCase()}</span><span className="user-chip-name">{user?.displayName || user?.email}</span></div><button className="button button-subtle button-small" onClick={onSignOut}><Icon name="logout" size={16}/> Sign out</button></div></header>;
}

const blankDocument = (projectName = 'Untitled logical network') => ({ schema: 'holly-bibley-project', version: 3, projectName, updatedAt: new Date().toISOString(), vlans: [], devices: [], connections: [], notes: '' });

function Dashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const [theme, setTheme] = useThemePreference();
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const fileRef = useRef(null);
  const creatingFromQuery = useRef(false);

  async function loadDashboard() {
    setLoading(true); setError('');
    try {
      const me = await api('/api/auth/me');
      setUser(me.user);
      const data = await api('/api/projects');
      setProjects(data.projects);
      setLoading(false);
      if (new URLSearchParams(location.search).get('create') === '1' && !creatingFromQuery.current) {
        creatingFromQuery.current = true;
        navigate('/dashboard', { replace: true });
        await createProject();
      }
    } catch (e) {
      setLoading(false);
      if (e.status === 401) navigate('/login', { replace: true });
      else setError(e.message);
    }
  }
  useEffect(() => { loadDashboard(); /* initial load only; project actions explicitly reload */ }, []);

  async function createProject() {
    setBusy(true); setError('');
    try {
      const data = await api('/api/projects', { method: 'POST', body: JSON.stringify({ title: 'Untitled logical network', document: blankDocument() }) });
      navigate(`/mapper.html?projectId=${encodeURIComponent(data.project.id)}`);
    } catch (e) { setError(e.message); setBusy(false); }
  }
  async function importProject(file) {
    if (!file) return;
    setError(''); setBusy(true);
    try {
      if (file.size > 2_500_000) throw new Error('This project file is too large to import (2.5 MB maximum).');
      const document = JSON.parse(await file.text());
      const data = await api('/api/projects', { method: 'POST', body: JSON.stringify({ title: document.projectName || file.name.replace(/\.json$/i, ''), document }) });
      navigate(`/mapper.html?projectId=${encodeURIComponent(data.project.id)}`);
    } catch (e) { setError(e instanceof SyntaxError ? 'That file is not valid JSON.' : e.message); }
    finally { setBusy(false); if (fileRef.current) fileRef.current.value = ''; }
  }
  async function deleteProject(project) {
    if (!window.confirm(`Delete “${project.title}”? This permanently deletes the saved diagram from your account.`)) return;
    try { await api(`/api/projects/${project.id}`, { method: 'DELETE' }); setProjects(prev => prev.filter(p => p.id !== project.id)); }
    catch (e) { setError(e.message); }
  }
  async function signOut() {
    try { await api('/api/auth/logout', { method: 'POST' }); } catch { /* Clear the app view regardless; expired cookies will redirect next time. */ }
    navigate('/signed-out', { replace: true });
  }
  const visibleProjects = useMemo(() => projects.filter(p => p.title.toLowerCase().includes(query.toLowerCase())), [projects, query]);

  if (loading) return <div className="app-loading"><div className="loader-ring"/><span>Opening your workspace…</span></div>;
  return <main className="dashboard-page"><Header user={user} onSignOut={signOut} theme={theme} setTheme={setTheme}/><section className="dashboard-content">
    <div className="dashboard-intro"><div><p className="eyebrow">YOUR WORKSPACE</p><h1>Good to see you, <span>{user?.displayName?.split(' ')[0] || 'engineer'}</span>.</h1><p className="dashboard-subtitle">Your diagrams are saved to your account, ready when you need them.</p></div><button className="button button-gold" onClick={createProject} disabled={busy}><Icon name="plus"/> New diagram</button></div>
    <div className="workspace-tools"><div className="search-box"><span className="search-glyph">⌕</span><input aria-label="Search diagrams" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search your diagrams"/></div><button className="button button-subtle" onClick={() => fileRef.current?.click()} disabled={busy}><Icon name="upload" size={16}/> Import JSON</button><input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={e => importProject(e.target.files?.[0])}/></div>
    <FormMessage error={error}/>
    {visibleProjects.length ? <div className="project-grid">{visibleProjects.map(project => <article className="project-card" key={project.id}>
      <div className="project-card-art"><div className="mini-topology"><span className="mini-vlan mini-vlan-one"/><span className="mini-vlan mini-vlan-two"/><i/><i/><i/><i/></div><span className="project-card-icon"><Icon name="network" size={21}/></span></div>
      <div className="project-card-content"><div className="project-card-head"><h2>{project.title}</h2><button className="icon-button muted-icon" aria-label={`Delete ${project.title}`} title="Delete diagram" onClick={() => deleteProject(project)}><Icon name="trash" size={16}/></button></div><div className="project-meta"><span>{project.vlanCount} VLANs</span><span className="meta-dot"/><span>{project.deviceCount} devices</span></div><div className="project-updated"><Icon name="clock" size={14}/> Updated {formatDate(project.updatedAt)}</div><button className="button button-outline-gold project-open" onClick={() => navigate(`/mapper.html?projectId=${encodeURIComponent(project.id)}`)}>Open diagram <Icon name="arrow" size={16}/></button></div>
    </article>)}</div> : <div className="empty-projects"><div className="empty-illustration"><Icon name="network" size={34}/></div><h2>{query ? 'No matching diagrams' : 'Your network map starts here'}</h2><p>{query ? 'Try a different search term.' : 'Create your first logical diagram. Add VLANs, map the devices and interfaces, and make the relationships easier to understand.'}</p><div className="empty-actions"><button className="button button-gold" onClick={createProject} disabled={busy}><Icon name="plus"/> Create your first diagram</button><button className="button button-subtle" onClick={() => fileRef.current?.click()}><Icon name="upload"/> Import an existing project</button></div></div>}
    <div className="dashboard-security-note"><Icon name="shield" size={17}/><span><strong>Private by account.</strong> Diagram reads, updates, and deletes are scoped to the signed-in owner on the server. Keep JSON exports in an approved secure location.</span></div>
  </section></main>;
}

function GuidePage() {
  const [theme, setTheme] = useThemePreference();
  const [user, setUser] = useState(null);
  const navigate = useNavigate();
  useEffect(() => { api('/api/auth/me').then(d => setUser(d.user)).catch(() => {}); }, []);
  return <main className="dashboard-page"><Header user={user || { displayName: 'Field guide' }} onSignOut={async () => { try { await api('/api/auth/logout', { method: 'POST' }); } catch {} navigate('/signed-out'); }} theme={theme} setTheme={setTheme}/><section className="guide-page-content"><p className="eyebrow">FIELD GUIDE</p><h1>Map the network, not just the cables.</h1><p>Learn the diagram conventions before building a topology.</p><div className="guide-chapters">{[
    ['01','VLAN segments','Give each logical network its own labelled line. Include its VLAN ID, name, subnet and, where applicable, gateway.'],
    ['02','Devices and ports','Identify each device by role and hostname. Label interfaces with IP/prefix and include the owning switch name with each switch port.'],
    ['03','Firewall boundaries','Treat containment and connectivity as separate relationships. A virtual firewall may sit inside an ESXi host group while its vNICs connect to separate VLANs.'],
    ['04','VM groups','Keep hosted VM cards inside their host group. The host group connects to the VLAN by default; virtual firewalls can expose their own VLAN interface connectors.'],
    ['05','Long VLAN lines','Use gentle or deep curves to separate long logical segments. Device connectors terminate at the curve, so they remain visually attached.'],
    ['06','Verify before trusting','A diagram represents intended topology. Verify VLAN membership, routes, firewall policies, switchports and return paths from approved sources.'],
  ].map(([n,title,body]) => <article className="guide-chapter" key={n}><span>{n}</span><div><h2>{title}</h2><p>{body}</p></div></article>)}</div><a className="button button-gold" href="/logical-network-mapping-guide.md" target="_blank" rel="noreferrer">Open full written guide <Icon name="arrow" size={16}/></a></section></main>;
}

function NotFound() { return <main className="not-found"><Brand/><h1>We lost this route.</h1><p>The page you requested isn't part of Holly Bibley.</p><Link className="button button-gold" to="/">Return home</Link></main>; }
function formatDate(value) { if (!value) return 'just now'; const date = new Date(value); if (Number.isNaN(date.getTime())) return 'recently'; return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(date); }

export default function App() {
  return <Routes>
    <Route path="/" element={<Home/>}/>
    <Route path="/login" element={<Login/>}/>
    <Route path="/signup" element={<Signup/>}/>
    <Route path="/verify-email" element={<VerifyEmail/>}/>
    <Route path="/forgot-password" element={<ForgotPassword/>}/>
    <Route path="/reset-password" element={<ResetPassword/>}/>
    <Route path="/signed-out" element={<SignedOut/>}/>
    <Route path="/dashboard" element={<Dashboard/>}/>
    <Route path="/guide" element={<GuidePage/>}/>
    <Route path="*" element={<NotFound/>}/>
  </Routes>;
}
