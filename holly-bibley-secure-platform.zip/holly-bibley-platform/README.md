# Holly Bibley — secure logical network mapping

Holly Bibley is a React web application with an Express API and PostgreSQL storage. It keeps the mapper's VLANs, devices, VM groups, firewall interface relationships, remote-session links, field guide, and SVG/PNG/JSON export workflow, while adding real user accounts and server-side private diagram storage.

## Included

- Minimal dark-cinematic homepage with a gold theme and two actions: Login and Sign Up.
- Login, signup, password-reset request, password-reset completion, and signed-out pages.
- Verified-email accounts; 24-hour, single-use verification tokens hashed at rest; Argon2id password hashes; random opaque session tokens stored only as SHA-256 hashes; HttpOnly, SameSite=Strict cookies; Secure cookies in production; login/signup rate limits; same-origin enforcement on state-changing API requests.
- PostgreSQL users, sessions, reset tokens, and JSONB diagrams. Read/update/delete operations filter by the authenticated user's ID. Optimistic revisions prevent silent overwrites when a diagram is changed in another session.
- SMTP password reset in production. Development without SMTP logs the reset URL to the API console; production startup refuses to run without SMTP configured.
- Original SVG topology editor and 5-chapter practical guide.
- Per-VLAN line styling: straight, gentle curve, and deep curve. Device interface connectors are routed to their actual position on the curved segment; the setting is saved in project JSON and stored in PostgreSQL.
- Virtual firewall containment and network connectivity are separate relationships. A virtual firewall can appear as a VM inside its ESXi/server outer group while dashed, interface-specific connectors extend to external VLANs.
- Gold-accent light/dark theme, transparent gold line-art praying-person SVG placeholder, React Bits SideRays, GhostCursor, and WarpText components.

## Requirements

- Node.js 22.12 or later
- npm
- Docker Desktop (or a PostgreSQL 16 instance)
- For real password-reset email in production: an SMTP service and a sender address authorized by that service

## Run locally on Windows

1. Extract the ZIP into a normal folder. Do not open the mapper HTML with `file://`; the authenticated app must run on the same origin as its API.
2. Copy `.env.example` to `.env`.
3. Edit `.env` and choose a strong local database password. Set `POSTGRES_PASSWORD` to that value and set the password part in `DATABASE_URL` to the same value. If the password contains URL-special characters, URL-encode them in `DATABASE_URL`.
4. In the project folder run:

   ```powershell
   npm install
   docker compose up -d db
   npm run db:migrate
   npm run dev
   ```

5. Open **http://127.0.0.1:5173**. Create an account, then create a diagram. The editor saves to PostgreSQL under that account.
6. For email verification and password reset during local development without SMTP, look at the API terminal for the development links.

Stop the local database with `docker compose down`. The named `holly_bibley_data` volume persists your local database. `docker compose down -v` deletes that volume and permanently removes its data.

## Production deployment checklist

This repository is a deployable application foundation, not a hosted service. Before exposing it to users:

1. Use HTTPS end-to-end. Set `NODE_ENV=production`, `APP_ORIGIN=https://your-real-origin`, and `PUBLIC_APP_URL=https://your-real-origin`.
2. Set a unique, strong `DATABASE_URL`, `POSTGRES_PASSWORD` (if using the included Compose file), `SMTP_URL`, and `SMTP_FROM` via your platform's secret manager. Never commit `.env` or secrets.
3. For managed PostgreSQL, enable TLS and set `PGSSL=true` when the service supports a trusted server certificate. Enable provider-managed encryption at rest, automated encrypted backups, restore testing, and a retention policy.
4. Build the frontend with `npm run build`; start the API/static server with `npm start`. Put a properly configured reverse proxy in front if your hosting platform requires one, and forward client IPs correctly only from trusted proxies.
5. Test signup, login, session expiration/logout, reset emails, reset-token expiry/one-use semantics, ownership isolation between two users, revision conflicts, backups/restores, and import/export in the production-like environment.
6. Set monitoring and alerting for API errors, database saturation, disk capacity, backups, and failed email delivery. Configure rate limiting at the edge too if the application runs across multiple API processes.

## Security and data handling

- Passwords are hashed with Argon2id, never stored in plaintext.
- Session tokens are high-entropy random values. The raw value is sent only in a Secure/HttpOnly/SameSite cookie (Secure in production); only its SHA-256 hash is saved in PostgreSQL.
- Diagram ownership is enforced in SQL predicates on each diagram read/write/delete, not merely hidden in the frontend.
- Reset tokens are random, hashed at rest, expire after 30 minutes, can only be used once, and revoke existing sessions after a successful password change.
- State-changing API calls are rejected unless the request's `Origin` exactly matches `APP_ORIGIN`.
- Email verification is required before sign-in. Verification tokens expire after 24 hours, are stored as hashes, and are single-use. Production requires SMTP delivery so verification and password-reset links are not exposed in logs.
- Diagram JSON is not field-level encrypted by the app. Use TLS, database access restrictions, encryption at rest, secure backups, and approved retention policies. Network diagrams can reveal sensitive infrastructure details.
- Production password resets require SMTP. Development-mode reset links are written to the API console only when SMTP is absent. Do not use development mode or console reset links for production.
- Rate limits in Express are process-local. For a multi-instance deployment, add a shared rate-limit store or edge rate limiting.

## VLAN line curves

Select a VLAN and choose its **VLAN line style** in the properties panel, or set it while creating/editing the VLAN:

- **Straight** — conventional horizontal segment.
- **Gentle curve** — a shallow arc for long or visually crowded segments.
- **Deep curve** — a more pronounced arc to distinguish the segment from nearby VLANs.

Connector points and interface labels follow the curve. Curving is a readability convention only; it doesn't imply a physical cable curve or a different VLAN configuration.

## Project files

- `src/` — React pages, styles, and the supplied React Bits effects.
- `server/index.js` — API, authentication, sessions, email resets, and owner-scoped diagram storage.
- `server/schema.sql` — PostgreSQL schema.
- `server/migrate.js` — schema setup.
- `public/mapper.html` and `public/mapper-app.js` — logical network editor.
- `public/assets/praying-person-placeholder.svg` — transparent decorative placeholder illustration; replaceable with your own licensed transparent image asset.
- `public/logical-network-mapping-guide.md` — complete written guide.

## Useful commands

```powershell
npm run dev       # React/Vite frontend + API watch mode
npm run build     # Production frontend bundle
npm start         # Serve production bundle and API
npm run db:migrate
npm run check     # Syntax checks and build
```
