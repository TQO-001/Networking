import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import argon2 from 'argon2';
import nodemailer from 'nodemailer';
import pg from 'pg';
import { createHash, randomBytes } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { z } from 'zod';

const { Pool } = pg;
const app = express();
const PORT = Number(process.env.PORT || 3001);
const NODE_ENV = process.env.NODE_ENV || 'development';
const IS_PROD = NODE_ENV === 'production';
const APP_ORIGIN = (process.env.APP_ORIGIN || 'http://localhost:5173').replace(/\/$/, '');
const PUBLIC_APP_URL = (process.env.PUBLIC_APP_URL || APP_ORIGIN).replace(/\/$/, '');
const COOKIE_NAME = process.env.COOKIE_NAME || 'hb_session';
const SESSION_DAYS = Math.max(1, Math.min(30, Number(process.env.SESSION_DAYS || 7)));
const SESSION_MS = SESSION_DAYS * 24 * 60 * 60 * 1000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIST_DIR = path.resolve(__dirname, '../dist');

if (!process.env.DATABASE_URL) {
  console.error('DATABASE_URL is required. Copy .env.example to .env, then start PostgreSQL.');
  process.exit(1);
}
if (IS_PROD && !/^https:\/\//i.test(APP_ORIGIN)) {
  console.error('Production APP_ORIGIN must be an HTTPS origin.');
  process.exit(1);
}
if (IS_PROD && !/^https:\/\//i.test(PUBLIC_APP_URL)) {
  console.error('Production PUBLIC_APP_URL must be an HTTPS URL.');
  process.exit(1);
}
if (IS_PROD && !process.env.SMTP_URL) {
  console.error('Production requires SMTP_URL so password reset is delivered rather than silently discarded.');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: Number(process.env.PG_POOL_MAX || 10),
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,
  ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: true } : undefined,
});
pool.on('error', (error) => console.error('[database pool error]', error.message));

app.disable('x-powered-by');
if (IS_PROD) app.set('trust proxy', 1);
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      baseUri: ["'self'"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'", 'data:'],
      formAction: ["'self'"],
      frameAncestors: ["'none'"],
      imgSrc: ["'self'", 'data:', 'blob:'],
      objectSrc: ["'none'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      upgradeInsecureRequests: IS_PROD ? [] : null,
    },
  },
  referrerPolicy: { policy: 'no-referrer' },
}));
app.use(express.json({ limit: '3mb', strict: true }));
app.use((req, res, next) => {
  res.setHeader('Cache-Control', req.path.startsWith('/api/') ? 'no-store' : 'no-cache');
  next();
});

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many account attempts. Please wait a little before trying again.' } });
const resetLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 5, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many password-reset requests. Please try again later.' } });
const jsonString = (max = 120) => z.string().trim().min(1).max(max);
const authEmail = z.string().trim().email().max(254).transform((v) => v.toLowerCase());
const passwordSchema = z.string().min(12, 'Use at least 12 characters.').max(128);
const signupSchema = z.object({ displayName: jsonString(80), email: authEmail, password: passwordSchema });
const loginSchema = z.object({ email: authEmail, password: z.string().min(1).max(128) });
const resetRequestSchema = z.object({ email: authEmail });
const resetCompleteSchema = z.object({ token: z.string().min(32).max(200), password: passwordSchema });
const diagramDocumentSchema = z.object({
  schema: z.literal('holly-bibley-project'),
  version: z.number().int().min(1).max(20),
  projectName: z.string().trim().min(1).max(120),
  vlans: z.array(z.record(z.string(), z.unknown())).max(300),
  devices: z.array(z.record(z.string(), z.unknown())).max(5000),
  connections: z.array(z.record(z.string(), z.unknown())).max(10000).optional().default([]),
}).passthrough();
const createDiagramSchema = z.object({ title: z.string().trim().min(1).max(120).optional(), document: diagramDocumentSchema });
const updateDiagramSchema = z.object({ document: diagramDocumentSchema, expectedRevision: z.number().int().positive() });

const hashSecret = (raw) => createHash('sha256').update(raw).digest('hex');
const nowPlus = (ms) => new Date(Date.now() + ms);
const safeUser = (row) => ({ id: row.id, displayName: row.display_name, email: row.email, emailVerified: Boolean(row.email_verified_at), createdAt: row.created_at });
function setSessionCookie(res, token) {
  res.cookie(COOKIE_NAME, token, { httpOnly: true, secure: IS_PROD, sameSite: 'strict', path: '/', maxAge: SESSION_MS });
}
function clearSessionCookie(res) {
  res.clearCookie(COOKIE_NAME, { httpOnly: true, secure: IS_PROD, sameSite: 'strict', path: '/' });
}
function assertSameOrigin(req, res, next) {
  const origin = req.get('origin');
  if (!origin || origin.replace(/\/$/, '') !== APP_ORIGIN) {
    return res.status(403).json({ error: 'Request origin could not be verified. Refresh the app and try again.' });
  }
  next();
}
async function requireAuth(req, res, next) {
  try {
    const rawToken = req.cookies?.[COOKIE_NAME] || parseCookie(req.headers.cookie, COOKIE_NAME);
    if (!rawToken) return res.status(401).json({ error: 'Please sign in to continue.' });
    const result = await pool.query(
      `SELECT s.id AS session_id, s.expires_at, u.id, u.display_name, u.email, u.created_at, u.email_verified_at
       FROM sessions s JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = $1 AND s.expires_at > now() AND u.email_verified_at IS NOT NULL LIMIT 1`,
      [hashSecret(rawToken)],
    );
    if (!result.rowCount) {
      clearSessionCookie(res);
      return res.status(401).json({ error: 'Your session has expired. Please sign in again.' });
    }
    req.authUser = result.rows[0];
    req.sessionId = result.rows[0].session_id;
    req.rawSessionToken = rawToken;
    next();
  } catch (error) { next(error); }
}
function parseCookie(header = '', name) {
  for (const part of header.split(';')) {
    const index = part.indexOf('=');
    if (index < 0) continue;
    if (part.slice(0, index).trim() === name) {
      try { return decodeURIComponent(part.slice(index + 1).trim()); } catch { return ''; }
    }
  }
  return '';
}
function validationError(error, res) {
  if (error?.name === 'ZodError') {
    const issue = error.issues?.[0];
    const field = issue?.path?.join('.') || 'request';
    return res.status(400).json({ error: `${field}: ${issue?.message || 'Invalid value.'}` });
  }
  return false;
}
async function createSession(userId, req, res) {
  const raw = randomBytes(32).toString('base64url');
  await pool.query('INSERT INTO sessions(user_id, token_hash, expires_at, user_agent) VALUES($1,$2,$3,$4)', [
    userId, hashSecret(raw), nowPlus(SESSION_MS), String(req.get('user-agent') || '').slice(0, 500),
  ]);
  setSessionCookie(res, raw);
}

// Every state-changing browser request must be same-origin. SameSite cookies are an additional layer.
app.use('/api', (req, res, next) => ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) ? assertSameOrigin(req, res, next) : next());
app.get('/api/health', async (_req, res) => {
  try { await pool.query('SELECT 1'); res.json({ status: 'ok' }); }
  catch { res.status(503).json({ status: 'unavailable' }); }
});

app.get('/api/auth/me', requireAuth, (req, res) => res.json({ user: safeUser(req.authUser) }));
async function deliverEmailVerification(user, rawToken) {
  const url = `${PUBLIC_APP_URL}/verify-email?token=${encodeURIComponent(rawToken)}`;
  if (process.env.SMTP_URL) {
    const transport = nodemailer.createTransport(process.env.SMTP_URL);
    await transport.sendMail({
      from: process.env.SMTP_FROM || 'Holly Bibley <no-reply@example.com>',
      to: user.email,
      subject: 'Verify your Holly Bibley account',
      text: `Hello ${user.display_name},\n\nVerify your email address to activate your Holly Bibley account. This link expires in 24 hours:\n${url}\n\nIf you did not create this account, ignore this email.`,
      html: `<p>Hello ${escapeHtml(user.display_name)},</p><p>Verify your email address to activate your Holly Bibley account. This link expires in 24 hours.</p><p><a href="${url}">Verify email</a></p><p>If you did not create this account, ignore this email.</p>`,
    });
  } else if (!IS_PROD) {
    console.info(`[DEV EMAIL VERIFICATION] ${user.email}: ${url}`);
  } else {
    throw new Error('SMTP_URL is required for production email verification.');
  }
}

app.post('/api/auth/signup', authLimiter, async (req, res, next) => {
  try {
    const data = signupSchema.parse(req.body);
    const passwordHash = await argon2.hash(data.password, { type: argon2.argon2id, memoryCost: 19456, timeCost: 2, parallelism: 1 });
    const result = await pool.query(
      'INSERT INTO users(display_name,email,password_hash) VALUES($1,$2,$3) RETURNING id,display_name,email,created_at,email_verified_at',
      [data.displayName, data.email, passwordHash],
    );
    const user = result.rows[0];
    const raw = randomBytes(32).toString('base64url');
    await pool.query('INSERT INTO email_verification_tokens(user_id,token_hash,expires_at) VALUES($1,$2,$3)', [user.id, hashSecret(raw), nowPlus(24 * 60 * 60 * 1000)]);
    let deliveryFailed = false;
    try { await deliverEmailVerification(user, raw); }
    catch (mailError) { deliveryFailed = true; console.error('[verification email delivery failed]', mailError.message); }
    res.status(201).json({ verificationRequired: true, email: user.email, message: deliveryFailed ? 'Your account was created, but the verification email could not be delivered. Use the resend form after email service is available.' : 'Account created. Check your email for a verification link before signing in.' });
  } catch (error) {
    if (validationError(error, res)) return;
    if (error.code === '23505') return res.status(409).json({ error: 'An account with this email already exists. Try signing in instead.' });
    next(error);
  }
});
app.post('/api/auth/email-verification/request', resetLimiter, async (req, res, next) => {
  try {
    const { email } = resetRequestSchema.parse(req.body);
    const found = await pool.query('SELECT id,email,display_name,email_verified_at FROM users WHERE email=$1 LIMIT 1', [email]);
    if (found.rowCount && !found.rows[0].email_verified_at) {
      const user = found.rows[0];
      const raw = randomBytes(32).toString('base64url');
      await pool.query('DELETE FROM email_verification_tokens WHERE user_id=$1', [user.id]);
      await pool.query('INSERT INTO email_verification_tokens(user_id,token_hash,expires_at) VALUES($1,$2,$3)', [user.id, hashSecret(raw), nowPlus(24 * 60 * 60 * 1000)]);
      await deliverEmailVerification(user, raw);
    }
    res.status(202).json({ message: 'If that address belongs to an unverified account, a new verification link will be sent.' });
  } catch (error) { if (validationError(error, res)) return; next(error); }
});
app.post('/api/auth/email-verification/complete', authLimiter, async (req, res, next) => {
  const tokenSchema = z.object({ token: z.string().min(32).max(200) });
  const client = await pool.connect().catch((error) => { next(error); return null; });
  if (!client) return;
  try {
    const { token } = tokenSchema.parse(req.body);
    await client.query('BEGIN');
    const result = await client.query('SELECT id,user_id FROM email_verification_tokens WHERE token_hash=$1 AND used_at IS NULL AND expires_at > now() LIMIT 1 FOR UPDATE', [hashSecret(token)]);
    if (!result.rowCount) { await client.query('ROLLBACK'); return res.status(400).json({ error: 'This verification link is invalid or expired. Request a new one.' }); }
    const { id: tokenId, user_id: userId } = result.rows[0];
    await client.query('UPDATE users SET email_verified_at=COALESCE(email_verified_at,now()),updated_at=now() WHERE id=$1', [userId]);
    await client.query('UPDATE email_verification_tokens SET used_at=now() WHERE id=$1', [tokenId]);
    await client.query('DELETE FROM email_verification_tokens WHERE user_id=$1 AND id<>$2', [userId, tokenId]);
    const userResult = await client.query('SELECT id,display_name,email,created_at,email_verified_at FROM users WHERE id=$1', [userId]);
    await client.query('COMMIT');
    await createSession(userId, req, res);
    res.json({ user: safeUser(userResult.rows[0]), message: 'Email verified. Your account is ready.' });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    if (validationError(error, res)) return;
    next(error);
  } finally { client.release(); }
});
app.post('/api/auth/login', authLimiter, async (req, res, next) => {
  try {
    const data = loginSchema.parse(req.body);
    const result = await pool.query('SELECT id,display_name,email,password_hash,created_at,email_verified_at FROM users WHERE email=$1 LIMIT 1', [data.email]);
    const user = result.rows[0];
    const valid = user ? await argon2.verify(user.password_hash, data.password).catch(() => false) : false;
    if (!valid) return res.status(401).json({ error: 'Email or password is incorrect.' });
    if (!user.email_verified_at) return res.status(403).json({ code: 'EMAIL_NOT_VERIFIED', error: 'Please verify your email address before signing in.' });
    await createSession(user.id, req, res);
    res.json({ user: safeUser(user) });
  } catch (error) { if (validationError(error, res)) return; next(error); }
});
app.post('/api/auth/logout', async (req, res, next) => {
  try {
    const raw = req.cookies?.[COOKIE_NAME] || parseCookie(req.headers.cookie, COOKIE_NAME);
    if (raw) await pool.query('DELETE FROM sessions WHERE token_hash=$1', [hashSecret(raw)]);
    clearSessionCookie(res);
    res.json({ ok: true });
  } catch (error) { next(error); }
});

app.post('/api/auth/password-reset/request', resetLimiter, async (req, res, next) => {
  try {
    const { email } = resetRequestSchema.parse(req.body);
    const found = await pool.query('SELECT id,email,display_name FROM users WHERE email=$1 LIMIT 1', [email]);
    if (found.rowCount) {
      const user = found.rows[0];
      const raw = randomBytes(32).toString('base64url');
      await pool.query('INSERT INTO password_reset_tokens(user_id,token_hash,expires_at) VALUES($1,$2,$3)', [user.id, hashSecret(raw), nowPlus(30 * 60 * 1000)]);
      const url = `${PUBLIC_APP_URL}/reset-password?token=${encodeURIComponent(raw)}`;
      if (process.env.SMTP_URL) {
        const transport = nodemailer.createTransport(process.env.SMTP_URL);
        await transport.sendMail({
          from: process.env.SMTP_FROM || 'Holly Bibley <no-reply@example.com>',
          to: user.email,
          subject: 'Reset your Holly Bibley password',
          text: `Hello ${user.display_name},\n\nUse this link to reset your password. It expires in 30 minutes:\n${url}\n\nIf you did not request this, ignore this email.`,
          html: `<p>Hello ${escapeHtml(user.display_name)},</p><p>Use this link to reset your password. It expires in 30 minutes.</p><p><a href="${url}">Reset password</a></p><p>If you did not request this, ignore this email.</p>`,
        });
      } else if (!IS_PROD) {
        console.info(`[DEV PASSWORD RESET] ${user.email}: ${url}`);
      } else {
        // Startup guards against this configuration, but fail closed if the environment changes.
        throw new Error('SMTP_URL is required for production password reset.');
      }
    }
    res.status(202).json({ message: 'If that email belongs to an account, password-reset instructions will be sent.' });
  } catch (error) { if (validationError(error, res)) return; next(error); }
});
app.post('/api/auth/password-reset/complete', authLimiter, async (req, res, next) => {
  const client = await pool.connect().catch((error) => { next(error); return null; });
  if (!client) return;
  try {
    const data = resetCompleteSchema.parse(req.body);
    await client.query('BEGIN');
    const result = await client.query(
      'SELECT id,user_id FROM password_reset_tokens WHERE token_hash=$1 AND used_at IS NULL AND expires_at > now() LIMIT 1 FOR UPDATE',
      [hashSecret(data.token)],
    );
    if (!result.rowCount) { await client.query('ROLLBACK'); return res.status(400).json({ error: 'This reset link is invalid or expired. Request a new one.' }); }
    const { id: tokenId, user_id: userId } = result.rows[0];
    const passwordHash = await argon2.hash(data.password, { type: argon2.argon2id, memoryCost: 19456, timeCost: 2, parallelism: 1 });
    await client.query('UPDATE users SET password_hash=$1,updated_at=now() WHERE id=$2', [passwordHash, userId]);
    await client.query('UPDATE password_reset_tokens SET used_at=now() WHERE id=$1', [tokenId]);
    await client.query('DELETE FROM password_reset_tokens WHERE user_id=$1 AND id<>$2', [userId, tokenId]);
    await client.query('DELETE FROM sessions WHERE user_id=$1', [userId]);
    await client.query('COMMIT');
    clearSessionCookie(res);
    res.json({ ok: true, message: 'Your password has been updated. Please sign in again.' });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    if (validationError(error, res)) return;
    next(error);
  } finally { client.release(); }
});

app.get('/api/projects', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query('SELECT id,title,revision,created_at,updated_at, jsonb_array_length(document->\'vlans\') AS vlan_count, jsonb_array_length(document->\'devices\') AS device_count FROM diagrams WHERE user_id=$1 ORDER BY updated_at DESC', [req.authUser.id]);
    res.json({ projects: result.rows.map(row => ({ id: row.id, title: row.title, revision: row.revision, createdAt: row.created_at, updatedAt: row.updated_at, vlanCount: Number(row.vlan_count || 0), deviceCount: Number(row.device_count || 0) })) });
  } catch (error) { next(error); }
});
app.post('/api/projects', requireAuth, async (req, res, next) => {
  try {
    const data = createDiagramSchema.parse(req.body);
    const title = data.title || data.document.projectName;
    const result = await pool.query(
      'INSERT INTO diagrams(user_id,title,document) VALUES($1,$2,$3::jsonb) RETURNING id,title,document,revision,created_at,updated_at',
      [req.authUser.id, title, JSON.stringify(data.document)],
    );
    const row = result.rows[0];
    res.status(201).json({ project: { id: row.id, title: row.title, document: row.document, revision: row.revision, createdAt: row.created_at, updatedAt: row.updated_at } });
  } catch (error) { if (validationError(error, res)) return; next(error); }
});
app.get('/api/projects/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query('SELECT id,title,document,revision,created_at,updated_at FROM diagrams WHERE id=$1 AND user_id=$2 LIMIT 1', [req.params.id, req.authUser.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Diagram not found.' });
    const row = result.rows[0];
    res.json({ project: { id: row.id, title: row.title, document: row.document, revision: row.revision, createdAt: row.created_at, updatedAt: row.updated_at } });
  } catch (error) { next(error); }
});
app.put('/api/projects/:id', requireAuth, async (req, res, next) => {
  try {
    const data = updateDiagramSchema.parse(req.body);
    const result = await pool.query(
      'UPDATE diagrams SET title=$1,document=$2::jsonb,revision=revision+1,updated_at=now() WHERE id=$3 AND user_id=$4 AND revision=$5 RETURNING id,title,document,revision,created_at,updated_at',
      [data.document.projectName, JSON.stringify(data.document), req.params.id, req.authUser.id, data.expectedRevision],
    );
    if (!result.rowCount) {
      const exists = await pool.query('SELECT revision FROM diagrams WHERE id=$1 AND user_id=$2', [req.params.id, req.authUser.id]);
      if (!exists.rowCount) return res.status(404).json({ error: 'Diagram not found.' });
      return res.status(409).json({ error: 'This diagram changed in another session. Reload the latest copy before continuing.', currentRevision: exists.rows[0].revision });
    }
    const row = result.rows[0];
    res.json({ project: { id: row.id, title: row.title, document: row.document, revision: row.revision, createdAt: row.created_at, updatedAt: row.updated_at } });
  } catch (error) { if (validationError(error, res)) return; next(error); }
});
app.delete('/api/projects/:id', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query('DELETE FROM diagrams WHERE id=$1 AND user_id=$2 RETURNING id', [req.params.id, req.authUser.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Diagram not found.' });
    res.json({ ok: true });
  } catch (error) { next(error); }
});

// Static client and the legacy mapper share the origin, so the HttpOnly session cookie also protects the mapper API calls.
app.use(express.static(DIST_DIR, { index: false, maxAge: IS_PROD ? '1h' : 0 }));
app.use((req, res, next) => {
  if (!['GET', 'HEAD'].includes(req.method)) return next();
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'API route not found.' });
  res.sendFile(path.join(DIST_DIR, 'index.html'), (error) => { if (error) next(error); });
});
app.use((error, _req, res, _next) => {
  if (error?.type === 'entity.too.large') return res.status(413).json({ error: 'This diagram is too large to save.' });
  if (error instanceof SyntaxError && 'body' in error) return res.status(400).json({ error: 'Invalid JSON request.' });
  console.error('[api error]', error?.message || 'Unknown error');
  res.status(500).json({ error: 'The request could not be completed. Check the server logs for details.' });
});

try {
  await pool.query('SELECT 1');
  if (IS_PROD) {
    try { await readFile(path.join(DIST_DIR, 'index.html')); }
    catch { throw new Error('Frontend build not found. Run npm run build before starting production mode.'); }
  }
  app.listen(PORT, () => console.log(`Holly Bibley API ready on port ${PORT} (${NODE_ENV}).`));
} catch (error) {
  console.error('Startup failed:', error.message);
  process.exit(1);
}

function escapeHtml(text = '') {
  return String(text).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
