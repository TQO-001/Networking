# Raw CLI — SL7 site (SL7, SL7MCC, SL7Oper)

[[00-SL7_Index|Index]] · [[01-Topology_and_Connections|Topology & connections]] · [[09-Open_Issues_and_Questions|Open issues]]

Unedited CLI output as captured from each switch. Commands run: `show vlan brief` · `show ip interface brief` · `show cdp neighbors` · `show cdp neighbors detail` · `show lldp neighbors` · `show lldp neighbors detail`. Summaries and port maps built from this output are in [[02-SL7_LV_Room]].

## Earlier captures (from the room notes)

These three `show cdp neighbors detail` outputs were taken while documenting the rooms and are kept unchanged. Note that the **SL7MCC** capture below lists the SL7 switch at `192.168.1.52`, while the later full capture shows `192.168.160.73` (see [[09-Open_Issues_and_Questions]]).

### IND-SW-EDNL_SL7

```Cisco
IND-SW-EDNL_SL7#show cdp neighbors detail
-------------------------

Device ID: IND-SW-EDNL_TLL.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.59
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/1,  Port ID (outgoing port): GigabitEthernet1/2
Holdtime : 138 sec

-------------------------

Device ID: IND-SW-SL7Mcc.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.112
Platform: cisco IE-3200-8T2S,  Capabilities: Router Switch IGMP
Interface: FastEthernet1/4,  Port ID (outgoing port): GigabitEthernet1/3
Holdtime : 129 sec

-------------------------

Device ID: IND-SW-EDNL_A17ControlRoom.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.65
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/2,  Port ID (outgoing port): GigabitEthernet1/1
Holdtime : 165 sec
```

### IND-SW-SL7Mcc

```Cisco
IND-SW-SL7Mcc#show cdp neighbors detail
-------------------------

Device ID: IND-SW-EDNL-SL7Oper.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.119
Platform: cisco IE-3300-8P2S,  Capabilities: Router Switch IGMP
Interface: GigabitEthernet1/8,  Port ID (outgoing port): GigabitEthernet1/3
Holdtime : 135 sec

-------------------------

Device ID: IND-SW-EDNL_SL7.hulamin.co.za
Entry address(es):
  IP address: 192.168.1.52
Platform: cisco IE-3000-4TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/3,  Port ID (outgoing port): FastEthernet1/4
Holdtime : 172 sec
```

### IND-SW-EDNL-SL7Oper

```Cisco
IND-SW-EDNL-SL7Oper#show cdp neighbors detail
-------------------------
Device ID: IND-SW-SL7Mcc.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.112
Platform: cisco IE-3200-8T2S,  Capabilities: Router Switch IGMP
Interface: GigabitEthernet1/3,  Port ID (outgoing port): GigabitEthernet1/8
Holdtime : 155 sec
```

## IND-SW-EDNL_SL7

```Cisco
IND-SW-EDNL_SL7>show vlan brief

VLAN Name                             Status    Ports
---- -------------------------------- --------- -------------------------------
1    default                          active
250  IND-250                          active
501  CCL                              active
526  IND-S6                           active
560  VLAN0560                         active
561  VLAN0561                         active    Fa1/2
567  CTTL5_Mgaurd                     active
574  IND-AnnealingFurnace             active
579  PTTL_Network                     active
582  IND-SL6                          active
585  A17_network                      active
590  EDPowerMeters                    active    Fa1/1
591  SL7                              active
592  crane                            active
593  Ignition                         active    Fa1/3
1002 fddi-default                     act/unsup
1003 token-ring-default               act/unsup
1004 fddinet-default                  act/unsup
1005 trnet-default                    act/unsup
IND-SW-EDNL_SL7>show ip interface brief
Interface              IP-Address      OK? Method Status                Protocol
Vlan1                  unassigned      YES NVRAM  up                    up
Vlan501                unassigned      YES manual up                    up
Vlan560                192.168.160.73  YES NVRAM  up                    up
Vlan561                unassigned      YES unset  up                    up
Vlan579                unassigned      YES unset  up                    up
Vlan585                unassigned      YES unset  up                    up
Vlan590                unassigned      YES unset  up                    up
Vlan591                unassigned      YES unset  up                    up
FastEthernet1/1        unassigned      YES unset  up                    up
FastEthernet1/2        unassigned      YES unset  up                    up
FastEthernet1/3        unassigned      YES unset  down                  down
FastEthernet1/4        unassigned      YES unset  up                    up
GigabitEthernet1/1     unassigned      YES unset  up                    up
GigabitEthernet1/2     unassigned      YES unset  up                    up
IND-SW-EDNL_SL7>show cdp neighbors
Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge
                  S - Switch, H - Host, I - IGMP, r - Repeater, P - Phone,
                  D - Remote, C - CVTA, M - Two-port Mac Relay

Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
IND-SW-EDNL_TLL.hulamin.co.za
                 Gig 1/1           173              S I   IE-3000-8 Gig 1/2
IND-SW-SL7Mcc.hulamin.co.za
                 Fas 1/4           176             R S I  IE-3200-8 Gig 1/3
IND-SW-EDNL_A17ControlRoom.hulamin.co.za
                 Gig 1/2           158              S I   IE-3000-8 Gig 1/1
IND-SW-EDNL_SL7>show cdp neighbors detail
-------------------------
Device ID: IND-SW-EDNL_TLL.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.59
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/1,  Port ID (outgoing port): GigabitEthernet1/2
Holdtime : 170 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF000000000000002790CCD580FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Power Available TLV:

    Power request id: 0, Power management id: 1, Power available: 0, Power management level: -1
Management address(es):
  IP address: 192.168.160.59

-------------------------
Device ID: IND-SW-SL7Mcc.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.112
Platform: cisco IE-3200-8T2S,  Capabilities: Router Switch IGMP
Interface: FastEthernet1/4,  Port ID (outgoing port): GigabitEthernet1/3
Holdtime : 173 sec

Version :
Cisco IOS Software [Gibraltar], IE3x00 Switch Software (IE3x00-UNIVERSALK9-M), Version 16.12.3, RELEASE SOFTWARE (fc5)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2020 by Cisco Systems, Inc.
Compiled Mon 09-Mar-20 20:30 by mcpre

advertisement version: 2
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Power Available TLV:

    Power request id: 0, Power management id: 0, Power available: 0, Power management level: 0
Management address(es):
  IP address: 192.168.160.112

-------------------------
Device ID: IND-SW-EDNL_A17ControlRoom.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.65
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/2,  Port ID (outgoing port): GigabitEthernet1/1
Holdtime : 155 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF000000000000002790CCE080FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Power Available TLV:

    Power request id: 0, Power management id: 1, Power available: 0, Power management level: -1
Management address(es):
  IP address: 192.168.160.65

IND-SW-EDNL_SL7>show lldp neighbors
Capability codes:
    (R) Router, (B) Bridge, (T) Telephone, (C) DOCSIS Cable Device
    (W) WLAN Access Point, (P) Repeater, (S) Station, (O) Other

Device ID           Local Intf     Hold-time  Capability      Port ID
IND-SW-SL7Mcc       Fa1/4          120        B,R             Gi1/3
IND-SW-EDNL_TLL     Gi1/1          120        B               port-002-00000
IND-SW-EDNL_A17ContrGi1/2          120        B               port-001-00000

Total entries displayed: 3

IND-SW-EDNL_SL7>show lldp neighbors detail
------------------------------------------------
Chassis id: 549f.c65f.f340
Port id: Gi1/3
Port Description: GigabitEthernet1/3
System Name: IND-SW-SL7Mcc.hulamin.co.za

System Description:
Cisco IOS Software [Gibraltar], IE3x00 Switch Software (IE3x00-UNIVERSALK9-M), Version 16.12.3, RELEASE SOFTWARE (fc5)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2020 by Cisco Systems, Inc.
Compiled Mon 09-Mar-20 20:30 by mcpre

Time remaining: 94 seconds
System Capabilities: B,R
Enabled Capabilities: B,R
Management Addresses:
    IP: 192.168.160.112
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
Media Attachment Unit type: 16
Vlan ID: 1

------------------------------------------------
Chassis id: 0027.90cc.d582
Port id: port-002-00000
Port Description: GigabitEthernet1/2
System Name: IND-SW-EDNL_TLL.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

Time remaining: 105 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.59
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1

------------------------------------------------
Chassis id: 0027.90cc.e082
Port id: port-001-00000
Port Description: GigabitEthernet1/1
System Name: IND-SW-EDNL_A17ControlRoom.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

Time remaining: 105 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.65
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1


Total entries displayed: 3

IND-SW-EDNL_SL7>
```

## IND-SW-SL7Mcc

```Cisco
IND-SW-SL7Mcc>show vlan brief

VLAN Name                             Status    Ports
---- -------------------------------- --------- -------------------------------
1    default                          active    Gi1/1, Gi1/2
250  IND-250                          active
560  management                       active
561  IND-CESMS                        active    Gi1/10
591  SL7                              active    Gi1/5, Gi1/6, Gi1/7, Gi1/9
593  Ignition                         active    Gi1/4
1002 fddi-default                     act/unsup
1003 token-ring-default               act/unsup
1004 fddinet-default                  act/unsup
1005 trnet-default                    act/unsup
IND-SW-SL7Mcc>show ip interface brief
Interface              IP-Address      OK? Method Status                Protocol
Vlan1                  unassigned      YES NVRAM  up                    up
Vlan560                192.168.160.112 YES NVRAM  up                    up
Vlan593                192.168.193.201 YES manual up                    up
GigabitEthernet1/1     unassigned      YES unset  down                  down
GigabitEthernet1/2     unassigned      YES unset  down                  down
GigabitEthernet1/3     unassigned      YES unset  up                    up
GigabitEthernet1/4     unassigned      YES unset  up                    up
GigabitEthernet1/5     unassigned      YES unset  down                  down
GigabitEthernet1/6     unassigned      YES unset  up                    up
GigabitEthernet1/7     unassigned      YES unset  up                    up
GigabitEthernet1/8     unassigned      YES unset  up                    up
GigabitEthernet1/9     unassigned      YES unset  up                    up
GigabitEthernet1/10    unassigned      YES unset  up                    up
IND-SW-SL7Mcc>show cdp neighbors
Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge
                  S - Switch, H - Host, I - IGMP, r - Repeater, P - Phone,
                  D - Remote, C - CVTA, M - Two-port Mac Relay

Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
IND-SW-EDNL-SL7Oper.hulamin.co.za
                 Gig 1/8           153             R S I  IE-3300-8 Gig 1/3
IND-SW-EDNL_SL7.hulamin.co.za
                 Gig 1/3           121              S I   IE-3000-4 Fas 1/4

Total cdp entries displayed : 2
IND-SW-SL7Mcc>show cdp neighbors detail
-------------------------
Device ID: IND-SW-EDNL-SL7Oper.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.119
Platform: cisco IE-3300-8P2S,  Capabilities: Router Switch IGMP
Interface: GigabitEthernet1/8,  Port ID (outgoing port): GigabitEthernet1/3
Holdtime : 147 sec

Version :
Cisco IOS Software [Dublin], IE3x00 Switch Software (IE3x00-UNIVERSALK9-M), Version 17.12.4, RELEASE SOFTWARE (fc3)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2024 by Cisco Systems, Inc.
Compiled Tue 23-Jul-24 09:58 by mcpre

advertisement version: 2
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.119

-------------------------
Device ID: IND-SW-EDNL_SL7.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.73
Platform: cisco IE-3000-4TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/3,  Port ID (outgoing port): FastEthernet1/4
Holdtime : 175 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.0(2)EY3, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2013 by Cisco Systems, Inc.
Compiled Thu 14-Nov-13 13:52 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF00000000000000562B857380FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.73


Total cdp entries displayed : 2
IND-SW-SL7Mcc>show lldp neighbors
Capability codes:
    (R) Router, (B) Bridge, (T) Telephone, (C) DOCSIS Cable Device
    (W) WLAN Access Point, (P) Repeater, (S) Station, (O) Other

Device ID           Local Intf     Hold-time  Capability      Port ID
C7401-SL7-IBA       Gi1/6          3601                       40a6.b7ce.4a92
C7401-SL7-IBA       Gi1/10         3601                       28c5.c87e.0816
CM1542-1            Gi1/9          20         S               port-002.sl7xaplc.profinetxadrives0b79
IND-SW-EDNL_SL7.hulaGi1/3          120        B               Fa1/4
S7-1500             Gi1/7          20         B,S             port-001.sl7xaplc.profinetxainterfacexb2469f
IND-SW-EDNL-SL7Oper.Gi1/8          20         B,R             port-003-00000
d0ad.08da.afc1      Gi1/4          3601                       d0ad.08da.afc1

Total entries displayed: 7

IND-SW-SL7Mcc>show lldp neighbors detail
------------------------------------------------
Local Intf: Gi1/6
Chassis id: C7401-SL7-IBA
Port id: 40a6.b7ce.4a92
Port Description - not advertised
System Name - not advertised
System Description - not advertised

Time remaining: 2776 seconds
System Capabilities - not advertised
Enabled Capabilities - not advertised
Management Addresses - not advertised
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
Media Attachment Unit type - not advertised
Vlan ID: - not advertised

MED Information:

    MED Codes:
          (NP) Network Policy, (LI) Location Identification
          (PS) Power Source Entity, (PD) Power Device
          (IN) Inventory

    Inventory information - not advertised
    Capabilities:
    Device type: Endpoint Class I
    Network Policies - not advertised
    Power requirements - not advertised
    Location - not advertised

------------------------------------------------
Local Intf: Gi1/10
Chassis id: C7401-SL7-IBA
Port id: 28c5.c87e.0816
Port Description - not advertised
System Name - not advertised
System Description - not advertised

Time remaining: 2776 seconds
System Capabilities - not advertised
Enabled Capabilities - not advertised
Management Addresses - not advertised
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
Media Attachment Unit type - not advertised
Vlan ID: - not advertised

MED Information:

    MED Codes:
          (NP) Network Policy, (LI) Location Identification
          (PS) Power Source Entity, (PD) Power Device
          (IN) Inventory

    Inventory information - not advertised
    Capabilities:
    Device type: Endpoint Class I
    Network Policies - not advertised
    Power requirements - not advertised
    Location - not advertised

------------------------------------------------
Local Intf: Gi1/9
Chassis id: S7-1500 CM                6GK7 542-1AX10-0XE0  VPS9330589           1 V  4  0 21
Port id: port-002.sl7xaplc.profinetxadrives0b79
Port Description: Siemens, SIMATIC S7, Ethernet Port, X1 P2R
System Name: CM1542-1

System Description:
Siemens, SIMATIC S7, CM1542-1

Time remaining: 16 seconds
System Capabilities: S
Enabled Capabilities: S
Management Addresses:
    IP: 192.168.210.100
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    100base-TX(FD)
    100base-TX(HD)
Media Attachment Unit type: 16
Vlan ID: - not advertised

------------------------------------------------
Local Intf: Gi1/3
Chassis id: 0056.2b85.7380
Port id: Fa1/4
Port Description: FastEthernet1/4
System Name: IND-SW-EDNL_SL7.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.0(2)EY3, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2013 by Cisco Systems, Inc.
Compiled Thu 14-Nov-13 13:52 by prod_rel_team

Time remaining: 115 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.73
Auto Negotiation - supported, enabled
Physical media capabilities:
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
Media Attachment Unit type: 16
Vlan ID: 1

------------------------------------------------
Local Intf: Gi1/7
Chassis id: S7-1500                   6ES7 516-3AP03-0AB0  S C-S4A14B142024     5 V  3  0  3
Port id: port-001.sl7xaplc.profinetxainterfacexb2469f
Port Description: Siemens, SIMATIC S7, Ethernet Port, X2 P1
System Name - not advertised

System Description:
Siemens, SIMATIC S7, CPU 1516-3 PN/DP, 6ES7 516-3AP03-0AB0, HW: Version 5, FW: Version V3.0.3, S C-S4A14B142024

Time remaining: 18 seconds
System Capabilities: B,S
Enabled Capabilities: B,S
Management Addresses:
    IP: 192.168.1.5
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    100base-TX(FD)
    100base-TX(HD)
Media Attachment Unit type: 16
Vlan ID: - not advertised

------------------------------------------------
Local Intf: Gi1/8
Chassis id: c860.8fbd.caeb
Port id: port-003-00000
Port Description: GigabitEthernet1/3
System Name: IND-SW-EDNL-SL7Oper.hulamin.co.za

System Description:
Cisco IOS Software [Dublin], IE3x00 Switch Software (IE3x00-UNIVERSALK9-M), Version 17.12.4, RELEASE SOFTWARE (fc3)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2024 by Cisco Systems, Inc.
Compiled Tue 23-Jul-24 09:58 by mcpre

Time remaining: 16 seconds
System Capabilities: B,R
Enabled Capabilities: B,R
Management Addresses:
    IP: 192.168.160.119
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
Media Attachment Unit type: 30
Vlan ID: 1

------------------------------------------------
Local Intf: Gi1/4
Chassis id: d0ad.08da.afc1
Port id: d0ad.08da.afc1
Port Description - not advertised
System Name - not advertised
System Description - not advertised

Time remaining: 3185 seconds
System Capabilities - not advertised
Enabled Capabilities - not advertised
Management Addresses - not advertised
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
Media Attachment Unit type - not advertised
Vlan ID: - not advertised

MED Information:

    MED Codes:
          (NP) Network Policy, (LI) Location Identification
          (PS) Power Source Entity, (PD) Power Device
          (IN) Inventory

    Inventory information - not advertised
    Capabilities:
    Device type: Endpoint Class I
    Network Policies - not advertised
    Power requirements - not advertised
    Location - not advertised


Total entries displayed: 7

IND-SW-SL7Mcc>

```

## IND-SW-EDNL-SL7Oper

```Cisco
IND-SW-EDNL-SL7Oper>show vlan brief

VLAN Name                             Status    Ports
---- -------------------------------- --------- -------------------------------
1    default                          active    Gi1/1, Gi1/2, Gi1/6, Gi1/8, Gi1/9
                                                Gi1/10, Ap1/1
250  IND-250                          active
560  IND-Manangement                  active
561  IND-CESMS                        active    Gi1/5
591  IND-Dept34                       active    Gi1/4
593  Ignition                         active    Gi1/7
1002 fddi-default                     act/unsup
1003 token-ring-default               act/unsup
1004 fddinet-default                  act/unsup
1005 trnet-default                    act/unsup
IND-SW-EDNL-SL7Oper>show ip interface brief
Interface              IP-Address      OK? Method Status                Protocol
Vlan1                  unassigned      YES NVRAM  up                    up
Vlan560                192.168.160.119 YES NVRAM  up                    up
GigabitEthernet1/1     unassigned      YES unset  down                  down
GigabitEthernet1/2     unassigned      YES unset  down                  down
GigabitEthernet1/3     unassigned      YES unset  up                    up
GigabitEthernet1/4     unassigned      YES unset  down                  down
GigabitEthernet1/5     unassigned      YES unset  down                  down
GigabitEthernet1/6     unassigned      YES unset  down                  down
GigabitEthernet1/7     unassigned      YES unset  up                    up
GigabitEthernet1/8     unassigned      YES unset  down                  down
GigabitEthernet1/9     unassigned      YES unset  down                  down
GigabitEthernet1/10    unassigned      YES unset  down                  down
AppGigabitEthernet1/1  unassigned      YES unset  up                    up
IND-SW-EDNL-SL7Oper>show cdp neighbors
Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge
                  S - Switch, H - Host, I - IGMP, r - Repeater, P - Phone,
                  D - Remote, C - CVTA, M - Two-port Mac Relay

Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
IND-SW-SL7Mcc.hulamin.co.za
                 Gig 1/3           155             R S I  IE-3200-8 Gig 1/8

Total cdp entries displayed : 1
IND-SW-EDNL-SL7Oper>show cdp neighbors detail
-------------------------
Device ID: IND-SW-SL7Mcc.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.112
Platform: cisco IE-3200-8T2S,  Capabilities: Router Switch IGMP
Interface: GigabitEthernet1/3,  Port ID (outgoing port): GigabitEthernet1/8
Holdtime : 154 sec

Version :
Cisco IOS Software [Gibraltar], IE3x00 Switch Software (IE3x00-UNIVERSALK9-M), Version 16.12.3, RELEASE SOFTWARE (fc5)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2020 by Cisco Systems, Inc.
Compiled Mon 09-Mar-20 20:30 by mcpre

advertisement version: 2
Peer Source MAC: 549f.c65f.f348
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.112


Total cdp entries displayed : 1
IND-SW-EDNL-SL7Oper>show lldp neighbors
Capability codes:
    (R) Router, (B) Bridge, (T) Telephone, (C) DOCSIS Cable Device
    (W) WLAN Access Point, (P) Repeater, (S) Station, (O) Other

Device ID           Local Intf     Hold-time  Capability      Port ID
IND-SW-SL7Mcc.hulamiGi1/3          120        B,R             Gi1/8

Total entries displayed: 1

IND-SW-EDNL-SL7Oper>show lldp neighbors detail
------------------------------------------------
Local Intf: Gi1/3
Local Intf service instance: -
Chassis id: 549f.c65f.f340
Port id: Gi1/8
Port Description: GigabitEthernet1/8
System Name: IND-SW-SL7Mcc.hulamin.co.za

System Description:
Cisco IOS Software [Gibraltar], IE3x00 Switch Software (IE3x00-UNIVERSALK9-M), Version 16.12.3, RELEASE SOFTWARE (fc5)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2020 by Cisco Systems, Inc.
Compiled Mon 09-Mar-20 20:30 by mcpre

Time remaining: 114 seconds
System Capabilities: B,R
Enabled Capabilities: B,R
Management Addresses:
    IP: 192.168.160.112
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
Media Attachment Unit type: 30
Vlan ID: 1
Peer Source MAC: 549f.c65f.f348


Total entries displayed: 1

IND-SW-EDNL-SL7Oper>

```
