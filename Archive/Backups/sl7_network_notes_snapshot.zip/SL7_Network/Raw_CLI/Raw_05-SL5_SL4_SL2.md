# Raw CLI — SL5, SL4 and SL2

[[00-SL7_Index|Index]] · [[01-Topology_and_Connections|Topology & connections]] · [[09-Open_Issues_and_Questions|Open issues]]

Unedited CLI output as captured from each switch. Commands run: `show vlan brief` · `show ip interface brief` · `show cdp neighbors` · `show cdp neighbors detail` · `show lldp neighbors` · `show lldp neighbors detail`. Summaries and port maps built from this output are in [[08-SL5_SL4_SL2]].

## IND-SW-EDNL_SL5

```Cisco
Industrial IT Switch
IND-SW-EDNL_SL5>show vlan brief

VLAN Name                             Status    Ports
---- -------------------------------- --------- -------------------------------
1    default                          active
250  IND-250                          active
501  CCL                              active
519  FS14                             active
526  IND-S6                           active
560  VLAN0560                         active
561  VLAN0561                         active    Fa1/1, Fa1/4, Fa1/5, Fa1/6, Fa1/7
567  CTTL5_Mgaurd                     active
574  IND-AnnealingFurnace             active
579  PTTL                             active
582  IND-SL6                          active
585  VLAN0585                         active
590  EDPowerMeters                    active    Fa1/2, Fa1/3
591  IND_SL5                          active    Fa1/8
593  Ignition                         active
1002 fddi-default                     act/unsup
1003 token-ring-default               act/unsup
1004 fddinet-default                  act/unsup
1005 trnet-default                    act/unsup
IND-SW-EDNL_SL5>show ip interface brief
Interface              IP-Address      OK? Method Status                Protocol
Vlan1                  unassigned      YES NVRAM  up                    up
Vlan501                unassigned      YES unset  up                    up
Vlan519                unassigned      YES unset  up                    up
Vlan560                192.168.160.56  YES NVRAM  up                    up
Vlan561                unassigned      YES unset  up                    up
Vlan579                unassigned      YES unset  up                    up
Vlan585                unassigned      YES unset  up                    up
Vlan590                unassigned      YES unset  up                    up
Vlan591                unassigned      YES unset  up                    up
FastEthernet1/1        unassigned      YES unset  down                  down
FastEthernet1/2        unassigned      YES unset  up                    up
FastEthernet1/3        unassigned      YES unset  up                    up
FastEthernet1/4        unassigned      YES unset  down                  down
FastEthernet1/5        unassigned      YES unset  up                    up
FastEthernet1/6        unassigned      YES unset  down                  down
FastEthernet1/7        unassigned      YES unset  down                  down
FastEthernet1/8        unassigned      YES unset  up                    up
GigabitEthernet1/1     unassigned      YES unset  up                    up
GigabitEthernet1/2     unassigned      YES unset  up                    up
IND-SW-EDNL_SL5>show cdp neighbors
Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge
                  S - Switch, H - Host, I - IGMP, r - Repeater, P - Phone,
                  D - Remote, C - CVTA, M - Two-port Mac Relay

Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
IND-SW-EDNL_PTTL.hulamin.co.za
                 Gig 1/2           126              S I   IE-3000-8 Gig 1/1
IND-SW-EDNL_SL4.hulamin.co.za
                 Gig 1/1           160              S I   IE-3000-8 Gig 1/2

Total cdp entries displayed : 2
IND-SW-EDNL_SL5>show cdp neighbors detail
-------------------------
Device ID: IND-SW-EDNL_PTTL.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.70
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/2,  Port ID (outgoing port): GigabitEthernet1/1
Holdtime : 126 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF000000000000002790CCE980FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.70

-------------------------
Device ID: IND-SW-EDNL_SL4.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.55
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/1,  Port ID (outgoing port): GigabitEthernet1/2
Holdtime : 160 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF000000000000002790CD0100FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.55


Total cdp entries displayed : 2
IND-SW-EDNL_SL5>show lldp neighbors
Capability codes:
    (R) Router, (B) Bridge, (T) Telephone, (C) DOCSIS Cable Device
    (W) WLAN Access Point, (P) Repeater, (S) Station, (O) Other

Device ID           Local Intf     Hold-time  Capability      Port ID
emg                 Fa1/8          20                         port-001
cpu1214             Fa1/8          20         B,S             port-001
IND-SW-EDNL_SL4.hulaGi1/1          120        B               port-002-00000
cp-343-1-lean       Fa1/8          20         S               port-001
pn-io               Fa1/8          20         S               port-002
IND-SW-EDNL_PTTL.hulGi1/2          120        B               port-001-00000
plcxb1d0ed          Fa1/8          20         B,S             port-001
3c52.826a.985e      Fa1/8          3601                       3c52.826a.985e
3c52.8265.f065      Fa1/8          3601                       3c52.8265.f065
e073.e716.47af      Fa1/8          3601                       e073.e716.47af

Total entries displayed: 10

IND-SW-EDNL_SL5>show lldp neighbors detail
------------------------------------------------
Local Intf: Fa1/8
Chassis id: emg
Port id: port-001
Port Description - not advertised
System Name - not advertised
System Description - not advertised

Time remaining: 19 seconds
System Capabilities - not advertised
Enabled Capabilities - not advertised
Management Addresses:
    IP: 10.0.0.27
Auto Negotiation - supported, enabled
Physical media capabilities:
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
Media Attachment Unit type: 16
Vlan ID: - not advertised

------------------------------------------------
Local Intf: Fa1/8
Chassis id: cpu1214
Port id: port-001
Port Description: Siemens, SIMATIC S7, Ethernet Port, X1 P1
System Name - not advertised

System Description:
Siemens, SIMATIC S7, CPU-1200, 6ES7 214-1AG40-0XB0, HW: 4, FW: V.4.1.3, S C-H1S36170

Time remaining: 15 seconds
System Capabilities: B,S
Enabled Capabilities: B,S
Management Addresses:
    IP: 10.0.0.20
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    100base-TX(FD)
    100base-TX(HD)
    100base-T4
    10base-T(FD)
    10base-T(HD)
Media Attachment Unit type: 16
Vlan ID: - not advertised

------------------------------------------------
Local Intf: Gi1/1
Chassis id: 0027.90cd.0101
Port id: port-002-00000
Port Description: GigabitEthernet1/2
System Name: IND-SW-EDNL_SL4.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

Time remaining: 116 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.55
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1

------------------------------------------------
Local Intf: Fa1/8
Chassis id: cp-343-1-lean
Port id: port-001
Port Description: Siemens, SIMATIC NET, Fast Ethernet Switch Port 1, 100 Mbit, full duplex, autonegotiation, link
System Name - not advertised

System Description:
Siemens, SIMATIC NET, CP 343-1 Lean, 6GK7 343-1CX10-0XE0, HW: Version 5, FW: Version V2.3.2, VPB5543770

Time remaining: 18 seconds
System Capabilities: S
Enabled Capabilities: S
Management Addresses:
    IP: 192.168.0.1
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
Media Attachment Unit type: 16
Vlan ID: - not advertised

------------------------------------------------
Local Intf: Fa1/8
Chassis id: pn-io
Port id: port-002
Port Description: Siemens, SIMATIC NET, Fast Ethernet Port 2, 100 Mbit, full duplex, autonegotiation, link
System Name - not advertised

System Description:
Siemens, SIMATIC NET, CP 343-1, 6GK7 343-1EX30-0XE0, HW: Version 6, FW: Version V2.5.0, VPC1521145

Time remaining: 19 seconds
System Capabilities: S
Enabled Capabilities: S
Management Addresses:
    IP: 10.0.0.50
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
Media Attachment Unit type: 16
Vlan ID: - not advertised

------------------------------------------------
Local Intf: Gi1/2
Chassis id: 0027.90cc.e982
Port id: port-001-00000
Port Description: GigabitEthernet1/1
System Name: IND-SW-EDNL_PTTL.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

Time remaining: 110 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.70
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1

------------------------------------------------
Local Intf: Fa1/8
Chassis id: plcxb1d0ed
Port id: port-001
Port Description: Siemens, SIMATIC S7, Ethernet Port, X1 P1
System Name - not advertised

System Description:
Siemens, SIMATIC S7, CPU-1200, 6ES7 214-1AG40-0XB0, HW: 4, FW: V.4.1.3, S C-H1S37241

Time remaining: 15 seconds
System Capabilities: B,S
Enabled Capabilities: B,S
Management Addresses:
    IP: 192.168.2.30
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    100base-TX(FD)
    100base-TX(HD)
    100base-T4
    10base-T(FD)
    10base-T(HD)
Media Attachment Unit type: 16
Vlan ID: - not advertised

------------------------------------------------
Local Intf: Fa1/8
Chassis id: 3c52.826a.985e
Port id: 3c52.826a.985e
Port Description - not advertised
System Name - not advertised
System Description - not advertised

Time remaining: 3249 seconds
System Capabilities - not advertised
Enabled Capabilities - not advertised
Management Addresses - not advertised
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
Media Attachment Unit type - not advertised
Vlan ID: - not advertised

MED Information:

    MED Codes:
          (NP) Network Policy, (LI) Location Identification
          (PS) Power Source Entity, (PD) Power Device
          (IN) Inventory

    Inventory information - not advertised
    Capabilities:
    Device type: Endpoint Class I
    Network Policies - not advertised
    Power requirements - not advertised
    Location - not advertised

------------------------------------------------
Local Intf: Fa1/8
Chassis id: 3c52.8265.f065
Port id: 3c52.8265.f065
Port Description - not advertised
System Name - not advertised
System Description - not advertised

Time remaining: 3220 seconds
System Capabilities - not advertised
Enabled Capabilities - not advertised
Management Addresses - not advertised
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
Media Attachment Unit type - not advertised
Vlan ID: - not advertised

MED Information:

    MED Codes:
          (NP) Network Policy, (LI) Location Identification
          (PS) Power Source Entity, (PD) Power Device
          (IN) Inventory

    Inventory information - not advertised
    Capabilities:
    Device type: Endpoint Class I
    Network Policies - not advertised
    Power requirements - not advertised
    Location - not advertised

------------------------------------------------
Local Intf: Fa1/8
Chassis id: e073.e716.47af
Port id: e073.e716.47af
Port Description - not advertised
System Name - not advertised
System Description - not advertised

Time remaining: 3226 seconds
System Capabilities - not advertised
Enabled Capabilities - not advertised
Management Addresses - not advertised
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
Media Attachment Unit type - not advertised
Vlan ID: - not advertised

MED Information:

    MED Codes:
          (NP) Network Policy, (LI) Location Identification
          (PS) Power Source Entity, (PD) Power Device
          (IN) Inventory

    Inventory information - not advertised
    Capabilities:
    Device type: Endpoint Class I
    Network Policies - not advertised
    Power requirements - not advertised
    Location - not advertised


Total entries displayed: 10

IND-SW-EDNL_SL5>

```

## IND-SW-EDNL_SL4

```Cisco
Industrial IT Switch
IND-SW-EDNL_SL4>show vlan brief

VLAN Name                             Status    Ports
---- -------------------------------- --------- -------------------------------
1    default                          active
250  IND-250                          active
501  CCL                              active
519  FS14                             active
526  IND-S6                           active
560  VLAN0560                         active
561  VLAN0561                         active    Fa1/1, Fa1/3, Fa1/4, Fa1/5
567  CTTL5_Mgaurd                     active
574  IND-AnnealingFurnace             active
579  PTTL_Network                     active
582  IND-SL6                          active
585  VLAN0585                         active
590  EDPowerMeters                    active    Fa1/2
591  VLAN0591                         active    Fa1/6, Fa1/7, Fa1/8
593  Ignition                         active
1002 fddi-default                     act/unsup
1003 token-ring-default               act/unsup
1004 fddinet-default                  act/unsup
1005 trnet-default                    act/unsup
IND-SW-EDNL_SL4>show ip interface brief
Interface              IP-Address      OK? Method Status                Protocol
Vlan1                  unassigned      YES NVRAM  administratively down down
Vlan501                unassigned      YES unset  up                    up
Vlan519                unassigned      YES unset  up                    up
Vlan560                192.168.160.55  YES NVRAM  up                    up
Vlan561                unassigned      YES unset  up                    up
Vlan579                unassigned      YES unset  up                    up
Vlan585                unassigned      YES unset  up                    up
Vlan590                unassigned      YES unset  up                    up
FastEthernet1/1        unassigned      YES unset  down                  down
FastEthernet1/2        unassigned      YES unset  up                    up
FastEthernet1/3        unassigned      YES unset  down                  down
FastEthernet1/4        unassigned      YES unset  down                  down
FastEthernet1/5        unassigned      YES unset  down                  down
FastEthernet1/6        unassigned      YES unset  down                  down
FastEthernet1/7        unassigned      YES unset  down                  down
FastEthernet1/8        unassigned      YES unset  up                    up
GigabitEthernet1/1     unassigned      YES unset  up                    up
GigabitEthernet1/2     unassigned      YES unset  up                    up
IND-SW-EDNL_SL4>show cdp neighbors
Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge
                  S - Switch, H - Host, I - IGMP, r - Repeater, P - Phone,
                  D - Remote, C - CVTA, M - Two-port Mac Relay

Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
IND-SW-EDNL-SL2.hulamin.co.za
                 Gig 1/1           141              S I   IE-3000-8 Gig 1/1
IND-SW-EDNL_SL5.hulamin.co.za
                 Gig 1/2           139              S I   IE-3000-8 Gig 1/1

Total cdp entries displayed : 2
IND-SW-EDNL_SL4>show cdp neighbors detail
-------------------------
Device ID: IND-SW-EDNL-SL2.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.54
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/1,  Port ID (outgoing port): GigabitEthernet1/1
Holdtime : 141 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF000000000000002790CCE700FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.54

-------------------------
Device ID: IND-SW-EDNL_SL5.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.56
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/2,  Port ID (outgoing port): GigabitEthernet1/1
Holdtime : 139 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF000000000000002790CCD600FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.56


Total cdp entries displayed : 2
IND-SW-EDNL_SL4>show lldp neighbors
Capability codes:
    (R) Router, (B) Bridge, (T) Telephone, (C) DOCSIS Cable Device
    (W) WLAN Access Point, (P) Repeater, (S) Station, (O) Other

Device ID           Local Intf     Hold-time  Capability      Port ID
IND-SW-EDNL_SL5.hulaGi1/2          120        B               port-001-00000
IND-SW-EDNL-SL2.hulaGi1/1          120        B               port-001-00000
f8ed.fc52.42b1      Fa1/8          3601                       f8ed.fc52.42b1

Total entries displayed: 3

IND-SW-EDNL_SL4>show lldp neighbors detail
------------------------------------------------
Local Intf: Gi1/2
Chassis id: 0027.90cc.d640
Port id: port-001-00000
Port Description: IND-SW-EDNL_SL4
System Name: IND-SW-EDNL_SL5.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

Time remaining: 100 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.56
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1

------------------------------------------------
Local Intf: Gi1/1
Chassis id: 0027.90cc.e740
Port id: port-001-00000
Port Description: GigabitEthernet1/1
System Name: IND-SW-EDNL-SL2.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

Time remaining: 119 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.54
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1

------------------------------------------------
Local Intf: Fa1/8
Chassis id: f8ed.fc52.42b1
Port id: f8ed.fc52.42b1
Port Description - not advertised
System Name - not advertised
System Description - not advertised

Time remaining: 3060 seconds
System Capabilities - not advertised
Enabled Capabilities - not advertised
Management Addresses - not advertised
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
Media Attachment Unit type - not advertised
Vlan ID: - not advertised

MED Information:

    MED Codes:
          (NP) Network Policy, (LI) Location Identification
          (PS) Power Source Entity, (PD) Power Device
          (IN) Inventory

    Inventory information - not advertised
    Capabilities:
    Device type: Endpoint Class I
    Network Policies - not advertised
    Power requirements - not advertised
    Location - not advertised


Total entries displayed: 3

IND-SW-EDNL_SL4>

```

## IND-SW-EDNL-SL2

```Cisco
Industrial IT Switch
IND-SW-EDNL-SL2>show vlan brief

VLAN Name                             Status    Ports
---- -------------------------------- --------- -------------------------------
1    default                          active    Gi1/2
250  IND-250                          active
501  CCL                              active
519  FS14                             active
526  IND-S6                           active
560  VLAN0560                         active
561  VLAN0561                         active    Fa1/1, Fa1/2, Fa1/3, Fa1/4, Fa1/5
                                                Fa1/6, Fa1/7, Fa1/8
567  CTTL5_Mgaurd                     active
574  IND-AnnealingFurnace             active
579  PTTL_Network                     active
582  IND-SL6                          active
585  VLAN0585                         active
590  EDPowerMeters                    active
593  Ignition                         active
1002 fddi-default                     act/unsup
1003 token-ring-default               act/unsup
1004 fddinet-default                  act/unsup
1005 trnet-default                    act/unsup
IND-SW-EDNL-SL2>show ip interface brief
Interface              IP-Address      OK? Method Status                Protocol
Vlan1                  unassigned      YES NVRAM  up                    up
Vlan50                 unassigned      YES unset  down                  down
Vlan501                unassigned      YES unset  up                    up
Vlan519                unassigned      YES unset  up                    up
Vlan560                192.168.160.54  YES NVRAM  up                    up
Vlan561                unassigned      YES unset  up                    up
Vlan579                unassigned      YES unset  up                    up
Vlan585                unassigned      YES unset  up                    up
Vlan590                unassigned      YES unset  up                    up
FastEthernet1/1        unassigned      YES unset  down                  down
FastEthernet1/2        unassigned      YES unset  down                  down
FastEthernet1/3        unassigned      YES unset  down                  down
FastEthernet1/4        unassigned      YES unset  down                  down
FastEthernet1/5        unassigned      YES unset  down                  down
FastEthernet1/6        unassigned      YES unset  down                  down
FastEthernet1/7        unassigned      YES unset  down                  down
FastEthernet1/8        unassigned      YES unset  down                  down
GigabitEthernet1/1     unassigned      YES unset  up                    up
GigabitEthernet1/2     unassigned      YES unset  down                  down
IND-SW-EDNL-SL2>show cdp neighbors
Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge
                  S - Switch, H - Host, I - IGMP, r - Repeater, P - Phone,
                  D - Remote, C - CVTA, M - Two-port Mac Relay

Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
IND-SW-EDNL_SL4.hulamin.co.za
                 Gig 1/1           126              S I   IE-3000-8 Gig 1/1

Total cdp entries displayed : 1
IND-SW-EDNL-SL2>show cdp neighbors detail
-------------------------
Device ID: IND-SW-EDNL_SL4.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.55
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/1,  Port ID (outgoing port): GigabitEthernet1/1
Holdtime : 126 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF000000000000002790CD0100FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.55


Total cdp entries displayed : 1
IND-SW-EDNL-SL2>show lldp neighbors
Capability codes:
    (R) Router, (B) Bridge, (T) Telephone, (C) DOCSIS Cable Device
    (W) WLAN Access Point, (P) Repeater, (S) Station, (O) Other

Device ID           Local Intf     Hold-time  Capability      Port ID
IND-SW-EDNL_SL4.hulaGi1/1          120        B               port-001-00000

Total entries displayed: 1

IND-SW-EDNL-SL2>show lldp neighbors detail
------------------------------------------------
Local Intf: Gi1/1
Chassis id: 0027.90cd.0101
Port id: port-001-00000
Port Description: GigabitEthernet1/1
System Name: IND-SW-EDNL_SL4.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

Time remaining: 95 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.55
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1


Total entries displayed: 1

IND-SW-EDNL-SL2>

```
