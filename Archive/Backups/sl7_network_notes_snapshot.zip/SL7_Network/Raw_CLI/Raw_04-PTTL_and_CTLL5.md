# Raw CLI — PTTL, CTLL5 and PLC switches

[[00-SL7_Index|Index]] · [[01-Topology_and_Connections|Topology & connections]] · [[09-Open_Issues_and_Questions|Open issues]]

Unedited CLI output as captured from each switch. Commands run: `show vlan brief` · `show ip interface brief` · `show cdp neighbors` · `show cdp neighbors detail` · `show lldp neighbors` · `show lldp neighbors detail`. Summaries and port maps built from this output are in [[07-PTTL_and_CTLL5]].

## IND-SW-EDNL_PTTL

```Cisco
Industrial IT Switch
IND-SW-EDNL_PTTL>show vlan brief

VLAN Name                             Status    Ports
---- -------------------------------- --------- -------------------------------
1    default                          active
250  IND-250                          active
501  CCL                              active
519  FS14                             active
526  IND-S6                           active
560  VLAN0560                         active
561  VLAN0561                         active    Fa1/5, Fa1/6
567  VLAN0567                         active
574  IND-AnnealingFurnace             active
579  PTTL                             active
581  PTTL_ACDrives                    active
582  IND-SL6                          active
585  VLAN0585                         active
590  EDPowerMeters                    active    Fa1/1, Fa1/2, Fa1/3, Fa1/4, Fa1/7
591  IND_SL5                          active
593  Ignition                         active
1002 fddi-default                     act/unsup
1003 token-ring-default               act/unsup
1004 fddinet-default                  act/unsup
1005 trnet-default                    act/unsup
IND-SW-EDNL_PTTL>show ip interface brief
Interface              IP-Address      OK? Method Status                Protocol
Vlan1                  unassigned      YES NVRAM  administratively down down
Vlan501                unassigned      YES unset  up                    up
Vlan519                unassigned      YES unset  up                    up
Vlan560                192.168.160.70  YES NVRAM  up                    up
Vlan571                unassigned      YES unset  down                  down
Vlan579                unassigned      YES unset  up                    up
Vlan581                192.168.181.149 YES NVRAM  up                    up
Vlan582                192.168.182.149 YES NVRAM  up                    up
Vlan585                unassigned      YES unset  up                    up
Vlan590                unassigned      YES unset  up                    up
Vlan591                unassigned      YES unset  up                    up
FastEthernet1/1        unassigned      YES unset  up                    up
FastEthernet1/2        unassigned      YES unset  up                    up
FastEthernet1/3        unassigned      YES unset  up                    up
FastEthernet1/4        unassigned      YES unset  up                    up
FastEthernet1/5        unassigned      YES unset  up                    up
FastEthernet1/6        unassigned      YES unset  up                    up
FastEthernet1/7        unassigned      YES unset  up                    up
FastEthernet1/8        unassigned      YES unset  up                    up
GigabitEthernet1/1     unassigned      YES unset  up                    up
GigabitEthernet1/2     unassigned      YES unset  up                    up
IND-SW-EDNL_PTTL>show cdp neighbors
Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge
                  S - Switch, H - Host, I - IGMP, r - Repeater, P - Phone,
                  D - Remote, C - CVTA, M - Two-port Mac Relay

Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
IND-SW-EDNL_Dept34_PTTL.hulamin.co.za
                 Gig 1/2           160              S I   WS-C2960X Gig 1/0/26
IND-SW-EDNL_PTTL_PLC.hulamin.co.za
                 Fas 1/8           127              S I   IE-3000-8 Gig 1/1
IND-SW-EDNL_SL5.hulamin.co.za
                 Gig 1/1           148              S I   IE-3000-8 Gig 1/2

Total cdp entries displayed : 3
IND-SW-EDNL_PTTL>show cdp neighbors detail
-------------------------
Device ID: IND-SW-EDNL_Dept34_PTTL.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.84
Platform: cisco WS-C2960X-24TS-L,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/2,  Port ID (outgoing port): GigabitEthernet1/0/26
Holdtime : 160 sec

Version :
Cisco IOS Software, C2960X Software (C2960X-UNIVERSALK9-M), Version 15.2(2)E7, RELEASE SOFTWARE (fc3)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2017 by Cisco Systems, Inc.
Compiled Wed 12-Jul-17 13:06 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF0000000000007802B1AFB900FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.84

-------------------------
Device ID: IND-SW-EDNL_PTTL_PLC.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.90
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: FastEthernet1/8,  Port ID (outgoing port): GigabitEthernet1/1
Holdtime : 127 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 12.2(58)SE2, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2011 by Cisco Systems, Inc.
Compiled Thu 21-Jul-11 00:59 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF00000000000008CCA7C07A00FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.90

-------------------------
Device ID: IND-SW-EDNL_SL5.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.56
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/1,  Port ID (outgoing port): GigabitEthernet1/2
Holdtime : 148 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF000000000000002790CCD600FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.56


Total cdp entries displayed : 3
IND-SW-EDNL_PTTL>show lldp neighbors
Capability codes:
    (R) Router, (B) Bridge, (T) Telephone, (C) DOCSIS Cable Device
    (W) WLAN Access Point, (P) Repeater, (S) Station, (O) Other

Device ID           Local Intf     Hold-time  Capability      Port ID
IND-SW-EDNL_Dept34_PGi1/2          120        B               Gi1/0/26
IND-SW-EDNL_SL5.hulaGi1/1          120        B               port-002-00000
IND-SW-EDNL_PTTL_PLCFa1/8          120        B               Gi1/1

Total entries displayed: 3

IND-SW-EDNL_PTTL>show lldp neighbors detail
------------------------------------------------
Local Intf: Gi1/2
Chassis id: 7802.b1af.b900
Port id: Gi1/0/26
Port Description: GigabitEthernet1/0/26
System Name: IND-SW-EDNL_Dept34_PTTL.hulamin.co.za

System Description:
Cisco IOS Software, C2960X Software (C2960X-UNIVERSALK9-M), Version 15.2(2)E7, RELEASE SOFTWARE (fc3)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2017 by Cisco Systems, Inc.
Compiled Wed 12-Jul-17 13:06 by prod_rel_team

Time remaining: 103 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.84
Auto Negotiation - not supported
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1

------------------------------------------------
Local Intf: Gi1/1
Chassis id: 0027.90cc.d640
Port id: port-002-00000
Port Description: IND-SW-EDNL_PTTL
System Name: IND-SW-EDNL_SL5.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

Time remaining: 107 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.56
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1

------------------------------------------------
Local Intf: Fa1/8
Chassis id: 08cc.a7c0.7a00
Port id: Gi1/1
Port Description: GigabitEthernet1/1
System Name: IND-SW-EDNL_PTTL_PLC.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 12.2(58)SE2, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2011 by Cisco Systems, Inc.
Compiled Thu 21-Jul-11 00:59 by prod_rel_team

Time remaining: 100 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.90
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
Media Attachment Unit type: 16
Vlan ID: 1


Total entries displayed: 3

IND-SW-EDNL_PTTL>

```

## IND-SW-EDNL_CTLL5

```Cisco

Industrial IT Switch
IND-SW-EDNL_CTLL5>show vlan brief

VLAN Name                             Status    Ports
---- -------------------------------- --------- -------------------------------
1    default                          active    Gi1/2
250  IND-250                          active
501  CCL                              active
526  IND-S6                           active
560  VLAN0560                         active
561  VLAN0561                         active    Fa1/1, Fa1/2, Fa1/6
567  CTTL5_Mgaurd                     active    Fa1/3, Fa1/4
574  IND-AnnealingFurnace             active
579  PTTL                             active
581  PTTL_ACDrives                    active
582  IND-SL6                          active
585  VLAN0585                         active
590  EDPowerMeters                    active    Fa1/5
591  CTLL5_Network                    active    Fa1/7, Fa1/8
593  Ignition                         active
1002 fddi-default                     act/unsup
1003 token-ring-default               act/unsup
1004 fddinet-default                  act/unsup
1005 trnet-default                    act/unsup
IND-SW-EDNL_CTLL5>show ip interface brief
Interface              IP-Address      OK? Method Status                Protocol
Vlan1                  unassigned      YES NVRAM  administratively down down
Vlan501                unassigned      YES unset  up                    up
Vlan560                192.168.160.71  YES NVRAM  up                    up
Vlan567                192.168.167.50  YES NVRAM  up                    up
Vlan579                unassigned      YES unset  up                    up
Vlan581                192.168.181.148 YES NVRAM  up                    up
Vlan582                192.168.182.148 YES NVRAM  up                    up
Vlan585                unassigned      YES unset  up                    up
Vlan590                unassigned      YES unset  up                    up
Vlan591                10.18.14.251    YES NVRAM  up                    up
FastEthernet1/1        unassigned      YES unset  down                  down
FastEthernet1/2        unassigned      YES unset  down                  down
FastEthernet1/3        unassigned      YES unset  up                    up
FastEthernet1/4        unassigned      YES unset  down                  down
FastEthernet1/5        unassigned      YES unset  down                  down
FastEthernet1/6        unassigned      YES unset  down                  down
FastEthernet1/7        unassigned      YES unset  down                  down
FastEthernet1/8        unassigned      YES unset  up                    up
GigabitEthernet1/1     unassigned      YES unset  up                    up
GigabitEthernet1/2     unassigned      YES unset  down                  down
IND-SW-EDNL_CTLL5>show cdp neighbors
Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge
                  S - Switch, H - Host, I - IGMP, r - Repeater, P - Phone,
                  D - Remote, C - CVTA, M - Two-port Mac Relay

Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
IND-SW-EDNL_Dept34_PTTL.hulamin.co.za
                 Gig 1/1           173              S I   WS-C2960X Gig 1/0/25

Total cdp entries displayed : 1
IND-SW-EDNL_CTLL5>show cdp neighbors detail
-------------------------
Device ID: IND-SW-EDNL_Dept34_PTTL.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.84
Platform: cisco WS-C2960X-24TS-L,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/1,  Port ID (outgoing port): GigabitEthernet1/0/25
Holdtime : 173 sec

Version :
Cisco IOS Software, C2960X Software (C2960X-UNIVERSALK9-M), Version 15.2(2)E7, RELEASE SOFTWARE (fc3)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2017 by Cisco Systems, Inc.
Compiled Wed 12-Jul-17 13:06 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF0000000000007802B1AFB900FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.84


Total cdp entries displayed : 1
IND-SW-EDNL_CTLL5>
IND-SW-EDNL_CTLL5>show lldp neighbors
Capability codes:
    (R) Router, (B) Bridge, (T) Telephone, (C) DOCSIS Cable Device
    (W) WLAN Access Point, (P) Repeater, (S) Station, (O) Other

Device ID           Local Intf     Hold-time  Capability      Port ID
IND-SW-EDNL_Dept34_PGi1/1          120        B               Gi1/0/25
IND-SW-CTLL5-panel  Fa1/8          20         B               6

Total entries displayed: 2

IND-SW-EDNL_CTLL5>show lldp neighbors detail
------------------------------------------------
Local Intf: Gi1/1
Chassis id: 7802.b1af.b900
Port id: Gi1/0/25
Port Description: GigabitEthernet1/0/25
System Name: IND-SW-EDNL_Dept34_PTTL.hulamin.co.za

System Description:
Cisco IOS Software, C2960X Software (C2960X-UNIVERSALK9-M), Version 15.2(2)E7, RELEASE SOFTWARE (fc3)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2017 by Cisco Systems, Inc.
Compiled Wed 12-Jul-17 13:06 by prod_rel_team

Time remaining: 112 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.84
Auto Negotiation - not supported
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1

------------------------------------------------
Local Intf: Fa1/8
Chassis id: 0090.e8c5.41b8
Port id: 6
Port Description: 1000TX,RJ45.
System Name: IND-SW-CTLL5-panel

System Description:
EDS-G516E

Time remaining: 19 seconds
System Capabilities: B
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.113
    OID:
        0.0.0.0.1.0.0.0.3.0.0.0.6.0.0.0.1.0.0.0.4.0.0.0.1.0.0.33.14720.0.0.7.0.0.0.71.
Auto Negotiation - not supported
Physical media capabilities - not advertised
Media Attachment Unit type - not advertised
Vlan ID: - not advertised


Total entries displayed: 2

IND-SW-EDNL_CTLL5>

```

## IND-SW-EDNL_PTTL_PLC

```Cisco
ndustrial
IND-SW-EDNL_PTTL_PLC>show vlan brief

VLAN Name                             Status    Ports
---- -------------------------------- --------- -------------------------------
1    default                          active
250  IND-250                          active
526  IND-S6                           active
560  VLAN0560                         active
574  IND-AnnealingFurnace             active
579  PTTL                             active    Fa1/1, Fa1/2, Fa1/3, Fa1/4, Fa1/5
                                                Fa1/6, Fa1/7
581  PTTL_ACDrives                    active    Fa1/8
582  IND-SL6                          active
593  Ignition                         active
1002 fddi-default                     act/unsup
1003 token-ring-default               act/unsup
1004 fddinet-default                  act/unsup
1005 trnet-default                    act/unsup
IND-SW-EDNL_PTTL_PLC>show ip interface brief
Interface              IP-Address      OK? Method Status                Protocol
Vlan1                  unassigned      YES NVRAM  up                    up
Vlan560                192.168.160.90  YES NVRAM  up                    up
Vlan579                192.168.179.100 YES NVRAM  up                    up
Vlan581                192.168.181.150 YES NVRAM  up                    up
Vlan582                192.168.182.150 YES NVRAM  up                    up
FastEthernet1/1        unassigned      YES unset  up                    up
FastEthernet1/2        unassigned      YES unset  up                    up
FastEthernet1/3        unassigned      YES unset  down                  down
FastEthernet1/4        unassigned      YES unset  up                    up
FastEthernet1/5        unassigned      YES unset  up                    up
FastEthernet1/6        unassigned      YES unset  up                    up
FastEthernet1/7        unassigned      YES unset  up                    up
FastEthernet1/8        unassigned      YES unset  up                    up
GigabitEthernet1/1     unassigned      YES unset  up                    up
GigabitEthernet1/2     unassigned      YES unset  up                    up
IND-SW-EDNL_PTTL_PLC>show cdp neighbors
Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge
                  S - Switch, H - Host, I - IGMP, r - Repeater, P - Phone,
                  D - Remote, C - CVTA, M - Two-port Mac Relay

Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
IND-SW-EDNL_PTTL.hulamin.co.za
                 Gig 1/1           135              S I   IE-3000-8 Fas 1/8
IND-SW-EDNL_PTTL_PLC2.hulamin.co.za
                 Gig 1/2           166              S I   IE-3000-4 Gig 1/1
IND-SW-EDNL_PTTL_PLC>show cdp neighbors detail
-------------------------
Device ID: IND-SW-EDNL_PTTL.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.70
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/1,  Port ID (outgoing port): FastEthernet1/8
Holdtime : 133 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF000000000000002790CCE980FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.70

-------------------------
Device ID: IND-SW-EDNL_PTTL_PLC2.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.124
Platform: cisco IE-3000-4TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/2,  Port ID (outgoing port): GigabitEthernet1/1
Holdtime : 164 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.0(2)EY3, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2013 by Cisco Systems, Inc.
Compiled Thu 14-Nov-13 13:52 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF00000000000000562B857400FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.124

IND-SW-EDNL_PTTL_PLC>show lldp neighbors
Capability codes:
    (R) Router, (B) Bridge, (T) Telephone, (C) DOCSIS Cable Device
    (W) WLAN Access Point, (P) Repeater, (S) Station, (O) Other

Device ID           Local Intf     Hold-time  Capability      Port ID
IND-SW-EDNL_PTTL_PLCGi1/2          120        B               Gi1/1
IND-SW-EDNL_PTTL    Gi1/1          120        B               port-010-00000

Total entries displayed: 2

IND-SW-EDNL_PTTL_PLC>show lldp neighbors detail
------------------------------------------------
Chassis id: 0056.2b85.7400
Port id: Gi1/1
Port Description: GigabitEthernet1/1
System Name: IND-SW-EDNL_PTTL_PLC2.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.0(2)EY3, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2013 by Cisco Systems, Inc.
Compiled Thu 14-Nov-13 13:52 by prod_rel_team

Time remaining: 109 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.124
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
Media Attachment Unit type: 30
Vlan ID: 1

------------------------------------------------
Chassis id: 0027.90cc.e982
Port id: port-010-00000
Port Description: FastEthernet1/8
System Name: IND-SW-EDNL_PTTL.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

Time remaining: 99 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.70
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
Media Attachment Unit type: 16
Vlan ID: 1


Total entries displayed: 2

IND-SW-EDNL_PTTL_PLC>

```

## IND-SW-EDNL_PTTL_PLC2

```Cisco

IND-SW-EDNL_PTTL_PLC2>show vlan brief

VLAN Name                             Status    Ports
---- -------------------------------- --------- -------------------------------
1    default                          active    Gi1/2
501  VLAN0501                         active
560  IND-Management                   active
561  IND-CESMS                        active
562  IND-CESMS_CCTV                   active
563  IND-CCL_CESS                     active
564  IND-CDHotMIl_L1                  active
565  IND-FoilAnnealing                active
566  IND-FoilSeparators               active
567  IND-CTTL5                        active
568  IND-CNG                          active
569  IND-CCL2Gauge                    active
570  CD_A19_Furnace_PLC_system        active
571  CD_A19_Furnace_HMI_System        active
572  IND-CCL1Gauge                    active
573  IND-CNGCCLGAs_Access_PLC         active
574  IND-AnnealingFurnace             active
575  CD_EMERGENCY_PowerHMI_PLC        active
576  CD_EMERGENCY_Power_PLC           active
577  IND-CNGCDHotlineGAs_Access_PLC   active
578  CD_A19_Furnace_Server_Access     active
579  -PTTL                            active    Fa1/1, Fa1/2, Fa1/3, Fa1/4
580  IND-Plate_Plant                  active
581  IND-PTTL_DC_Drives               active
582  IND-PTTL_AC_Drives               active
592  CCL_Ruler                        active
593  Ignition                         active
1002 fddi-default                     act/unsup
1003 token-ring-default               act/unsup
1004 fddinet-default                  act/unsup
1005 trnet-default                    act/unsup
IND-SW-EDNL_PTTL_PLC2>show ip interface brief
Interface              IP-Address      OK? Method Status                Protocol
Vlan1                  unassigned      YES NVRAM  up                    up
Vlan560                192.168.160.124 YES NVRAM  up                    up
Vlan579                unassigned      YES unset  up                    up
FastEthernet1/1        unassigned      YES unset  up                    up
FastEthernet1/2        unassigned      YES unset  down                  down
FastEthernet1/3        unassigned      YES unset  down                  down
FastEthernet1/4        unassigned      YES unset  down                  down
GigabitEthernet1/1     unassigned      YES unset  up                    up
GigabitEthernet1/2     unassigned      YES unset  down                  down
IND-SW-EDNL_PTTL_PLC2>show cdp neighbors
Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge
                  S - Switch, H - Host, I - IGMP, r - Repeater, P - Phone,
                  D - Remote, C - CVTA, M - Two-port Mac Relay

Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
IND-SW-EDNL_PTTL_PLC.hulamin.co.za
                 Gig 1/1           123              S I   IE-3000-8 Gig 1/2
IND-SW-EDNL_PTTL_PLC2>show cdp neighbors detail
-------------------------
Device ID: IND-SW-EDNL_PTTL_PLC.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.90
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/1,  Port ID (outgoing port): GigabitEthernet1/2
Holdtime : 123 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 12.2(58)SE2, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2011 by Cisco Systems, Inc.
Compiled Thu 21-Jul-11 00:59 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF00000000000008CCA7C07A00FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Power Available TLV:

    Power request id: 0, Power management id: 0, Power available: 0, Power management level: 0
Management address(es):
  IP address: 192.168.160.90

IND-SW-EDNL_PTTL_PLC2>show lldp neighbors
Capability codes:
    (R) Router, (B) Bridge, (T) Telephone, (C) DOCSIS Cable Device
    (W) WLAN Access Point, (P) Repeater, (S) Station, (O) Other

Device ID           Local Intf     Hold-time  Capability      Port ID
IND-SW-EDNL_PTTL_PLCGi1/1          120        B               Gi1/2
503e.aa16.6734      Fa1/1          3601                       503e.aa16.6734

Total entries displayed: 2

IND-SW-EDNL_PTTL_PLC2>show lldp neighbors detail
------------------------------------------------
Chassis id: 08cc.a7c0.7a00
Port id: Gi1/2
Port Description: GigabitEthernet1/2
System Name: IND-SW-EDNL_PTTL_PLC.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 12.2(58)SE2, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2011 by Cisco Systems, Inc.
Compiled Thu 21-Jul-11 00:59 by prod_rel_team

Time remaining: 96 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.90
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
Media Attachment Unit type: 30
Vlan ID: 1

------------------------------------------------
Chassis id: 503e.aa16.6734
Port id: 503e.aa16.6734
Port Description - not advertised
System Name - not advertised
System Description - not advertised

Time remaining: 2922 seconds
System Capabilities - not advertised
Enabled Capabilities - not advertised
Management Addresses - not advertised
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
Media Attachment Unit type - not advertised
Vlan ID: - not advertised

MED Information:

    MED Codes:
          (NP) Network Policy, (LI) Location Identification
          (PS) Power Source Entity, (PD) Power Device
          (IN) Inventory

    Inventory information - not advertised
    Capabilities:
    Device type: Endpoint Class I
    Network Policies - not advertised
    Power requirements - not advertised
    Location - not advertised


Total entries displayed: 2

IND-SW-EDNL_PTTL_PLC2>

```
