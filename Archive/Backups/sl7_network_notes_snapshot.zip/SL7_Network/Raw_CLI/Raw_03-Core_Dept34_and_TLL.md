# Raw CLI — Dept34 core, Dept34_PTTL and TLL

[[00-SL7_Index|Index]] · [[01-Topology_and_Connections|Topology & connections]] · [[09-Open_Issues_and_Questions|Open issues]]

Unedited CLI output as captured from each switch. Commands run: `show vlan brief` · `show ip interface brief` · `show cdp neighbors` · `show cdp neighbors detail` · `show lldp neighbors` · `show lldp neighbors detail`. Summaries and port maps built from this output are in [[06-Core_Dept34_and_TLL]].

## IND-SW-Dept34_Distr

```Cisco
IND-SW-Dept34_Distr>show vlan brief

VLAN Name                             Status    Ports
---- -------------------------------- --------- -------------------------------
1    default                          active    Gi1/0/1, Gi1/0/2, Gi1/0/3, Gi1/0/4
                                                Gi1/0/5, Gi1/0/6, Gi1/0/7, Gi1/0/8
                                                Gi1/0/9, Gi1/0/10, Gi1/0/11, Gi1/0/12
                                                Gi1/0/13, Gi1/0/14, Gi1/0/15, Gi1/0/16
                                                Gi1/0/17, Gi1/0/18, Gi1/0/19, Gi1/0/20
                                                Gi1/0/21, Gi1/0/22, Gi1/0/23, Te1/0/25
                                                Te1/0/26, Te1/0/28, Ap1/0/1
250  VLAN_250                         active
501  CCL                              active
508  FM8_9_Plant_bus                  active
509  FM8_9_Terminal_bus               active
514  S4                               active
515  FS15                             active
519  Fs14                             active
560  Switch_Management                active
561  CESMS                            active
562  CCTV                             active
563  CESS                             active
564  IND-CDhotMill                    active
565  FoilFinishing_Seperators         active
566  FoilFinishing_Annealing          active
567  CTLL5_Mgaurd                     active
568  IND-CNG_Network                  active
569  IND-CCL2Gauge                    active
570  IND-A19_Furnace_plc              active
571  IND-A19_Furnace_HMM_Network      active
572  IND-CCL1Gauge                    active
573  IND-CCL1CNG-Alternative          active
574  IND-Annealing_furnace            active
575  CD_EMERGENCY_PowerHMI_PLC        active
576  CD_EMERGENCY_PwrPLC_PLC_Network  active
577  IND-CNGCDHotlineGAs_Access_PLC   active
578  IND-A19Network                   active
579  IND-PTTL                         active
580  IND-PlatePlant                   active
581  ED_Extrutions                    active
582  VLAN0582                         active
585  IND-A17                          active
587  ED_Effluent_Plant                active
588  IND-RG9                          active
589  CD_Power_Meters                  active
590  Power_Meters                     active
591  IND_SL5                          active
592  Crane                            active
593  Igntion                          active
1002 fddi-default                     act/unsup
1003 token-ring-default               act/unsup
1004 fddinet-default                  act/unsup
1005 trnet-default                    act/unsup
IND-SW-Dept34_Distr>
IND-SW-Dept34_Distr>show ip interface brief
Interface              IP-Address      OK? Method Status                Protocol
Vlan1                  unassigned      YES NVRAM  up                    up
Vlan560                192.168.160.117 YES NVRAM  up                    up
GigabitEthernet1/0/1   unassigned      YES unset  down                  down
GigabitEthernet1/0/2   unassigned      YES unset  down                  down
GigabitEthernet1/0/3   unassigned      YES unset  down                  down
GigabitEthernet1/0/4   unassigned      YES unset  down                  down
GigabitEthernet1/0/5   unassigned      YES unset  down                  down
GigabitEthernet1/0/6   unassigned      YES unset  down                  down
GigabitEthernet1/0/7   unassigned      YES unset  down                  down
GigabitEthernet1/0/8   unassigned      YES unset  down                  down
GigabitEthernet1/0/9   unassigned      YES unset  down                  down
GigabitEthernet1/0/10  unassigned      YES unset  down                  down
GigabitEthernet1/0/11  unassigned      YES unset  down                  down
GigabitEthernet1/0/12  unassigned      YES unset  down                  down
GigabitEthernet1/0/13  unassigned      YES unset  down                  down
GigabitEthernet1/0/14  unassigned      YES unset  down                  down
GigabitEthernet1/0/15  unassigned      YES unset  down                  down
GigabitEthernet1/0/16  unassigned      YES unset  down                  down
GigabitEthernet1/0/17  unassigned      YES unset  down                  down
GigabitEthernet1/0/18  unassigned      YES unset  down                  down
GigabitEthernet1/0/19  unassigned      YES unset  down                  down
GigabitEthernet1/0/20  unassigned      YES unset  down                  down
GigabitEthernet1/0/21  unassigned      YES unset  down                  down
GigabitEthernet1/0/22  unassigned      YES unset  down                  down
GigabitEthernet1/0/23  unassigned      YES unset  down                  down
GigabitEthernet1/0/24  unassigned      YES unset  up                    up
Te1/0/25               unassigned      YES unset  down                  down
Te1/0/26               unassigned      YES unset  down                  down
Te1/0/27               unassigned      YES unset  up                    up
Te1/0/28               unassigned      YES unset  down                  down
Ap1/0/1                unassigned      YES unset  up                    up
IND-SW-Dept34_Distr>
IND-SW-Dept34_Distr>show cdp neighbors
Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge
                  S - Switch, H - Host, I - IGMP, r - Repeater, P - Phone,
                  D - Remote, C - CVTA, M - Two-port Mac Relay

Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
ind-Core1-MSR.plant.hulamin.co.za
                 Ten 1/0/27        157             R S I  C9500-48Y Twe 1/0/21
IND-SW-EDNL_Dept34_PTTL.hulamin.co.za
                 Gig 1/0/24        178              S I   WS-C2960X Gig 1/0/28

Total cdp entries displayed : 2
IND-SW-Dept34_Distr>show cdp neighbors detail
-------------------------
Device ID: ind-Core1-MSR.plant.hulamin.co.za
Entry address(es):
  IP address: 192.168.1.1
Platform: cisco C9500-48Y4C,  Capabilities: Router Switch IGMP
Interface: TenGigabitEthernet1/0/27,  Port ID (outgoing port): TwentyFiveGigE1/0/21
Holdtime : 144 sec

Version :
Cisco IOS Software [Cupertino], Catalyst L3 Switch Software (CAT9K_IOSXE), Version 17.9.4, RELEASE SOFTWARE (fc5)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2023 by Cisco Systems, Inc.
Compiled Wed 26-Jul-23 10:26 by mcpre

advertisement version: 2
Peer Source MAC: e80a.b9f1.93b5
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.1.1

-------------------------
Device ID: IND-SW-EDNL_Dept34_PTTL.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.84
Platform: cisco WS-C2960X-24TS-L,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/0/24,  Port ID (outgoing port): GigabitEthernet1/0/28
Holdtime : 165 sec

Version :
Cisco IOS Software, C2960X Software (C2960X-UNIVERSALK9-M), Version 15.2(2)E7, RELEASE SOFTWARE (fc3)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2017 by Cisco Systems, Inc.
Compiled Wed 12-Jul-17 13:06 by prod_rel_team

advertisement version: 2
Peer Source MAC: 7802.b1af.b91c
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF0000000000007802B1AFB900FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.84


Total cdp entries displayed : 2
IND-SW-Dept34_Distr>
IND-SW-Dept34_Distr>show lldp neighbors
Capability codes:
    (R) Router, (B) Bridge, (T) Telephone, (C) DOCSIS Cable Device
    (W) WLAN Access Point, (P) Repeater, (S) Station, (O) Other

Device ID           Local Intf     Hold-time  Capability      Port ID
IND-SW-EDNL_Dept34_PGi1/0/24       120        B               Gi1/0/28
ind-Core1-MSR.plant.Te1/0/27       120        B,R             Twe1/0/21

Total entries displayed: 2

IND-SW-Dept34_Distr>show lldp neighbors detail
------------------------------------------------
Local Intf: Gi1/0/24
Local Intf service instance: -
Chassis id: 7802.b1af.b900
Port id: Gi1/0/28
Port Description: GigabitEthernet1/0/28
System Name: IND-SW-EDNL_Dept34_PTTL.hulamin.co.za

System Description:
Cisco IOS Software, C2960X Software (C2960X-UNIVERSALK9-M), Version 15.2(2)E7, RELEASE SOFTWARE (fc3)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2017 by Cisco Systems, Inc.
Compiled Wed 12-Jul-17 13:06 by prod_rel_team

Time remaining: 92 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.84
Auto Negotiation - not supported
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1
Peer Source MAC: 7802.b1af.b91c

------------------------------------------------
Local Intf: Te1/0/27
Local Intf service instance: -
Chassis id: e80a.b9f1.93a0
Port id: Twe1/0/21
Port Description: TwentyFiveGigE1/0/21
System Name: ind-Core1-MSR.plant.hulamin.co.za

System Description:
Cisco IOS Software [Cupertino], Catalyst L3 Switch Software (CAT9K_IOSXE), Version 17.9.4, RELEASE SOFTWARE (fc5)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2023 by Cisco Systems, Inc.
Compiled Wed 26-Jul-23 10:26 by mcpre

Time remaining: 100 seconds
System Capabilities: B,R
Enabled Capabilities: B,R
Management Addresses:
    IP: 192.168.1.1
Auto Negotiation - not supported
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 24
Vlan ID: 1
Peer Source MAC: e80a.b9f1.93b5


Total entries displayed: 2

```

## IND-SW-EDNL_Dept34_PTTL

```Cisco
IND-SW-EDNL_Dept34_PTTL>show vlan brief

VLAN Name                             Status    Ports
---- -------------------------------- --------- -------------------------------
1    default                          active    Gi1/0/1, Gi1/0/5, Gi1/0/6, Gi1/0/8
                                                Gi1/0/16
250  IND-250                          active
501  CCL                              active
515  FS15                             active
519  FS14                             active
526  IND-S6                           active
560  VLAN0560                         active
561  VLAN0561                         active    Gi1/0/9, Gi1/0/14, Gi1/0/15, Gi1/0/17
                                                Gi1/0/18, Gi1/0/19, Gi1/0/20, Gi1/0/21
                                                Gi1/0/22, Gi1/0/23
567  CTTL5_Mgaurd                     active
574  IND-AnnealingFurnace             active
579  PTTL Network                     active
581  PTTL_ACDrives                    active    Gi1/0/10, Gi1/0/11, Gi1/0/12, Gi1/0/13
582  IND-SL6                          active
585  VLAN0585                         active
590  EDPowerMeters                    active
591  IND_SL5                          active
592  Crane                            active
593  Ignition                         active
1002 fddi-default                     act/unsup
1003 token-ring-default               act/unsup
1004 fddinet-default                  act/unsup
1005 trnet-default                    act/unsup
IND-SW-EDNL_Dept34_PTTL>show ip interface brief
Interface              IP-Address      OK? Method Status                Protocol
Vlan1                  unassigned      YES NVRAM  up                    up
Vlan501                unassigned      YES unset  up                    up
Vlan515                unassigned      YES unset  up                    up
Vlan519                unassigned      YES unset  up                    up
Vlan560                192.168.160.84  YES NVRAM  up                    up
Vlan561                unassigned      YES unset  up                    up
Vlan567                unassigned      YES unset  up                    up
Vlan579                unassigned      YES unset  up                    up
Vlan581                192.168.181.146 YES NVRAM  up                    up
Vlan582                192.168.182.146 YES NVRAM  up                    up
Vlan585                unassigned      YES unset  up                    up
Vlan590                unassigned      YES unset  up                    up
Vlan591                10.18.14.250    YES NVRAM  up                    up
FastEthernet0          unassigned      YES NVRAM  administratively down down
GigabitEthernet1/0/1   unassigned      YES unset  down                  down
GigabitEthernet1/0/2   unassigned      YES unset  up                    up
GigabitEthernet1/0/3   unassigned      YES unset  up                    up
GigabitEthernet1/0/4   unassigned      YES unset  up                    up
GigabitEthernet1/0/5   unassigned      YES unset  up                    down
GigabitEthernet1/0/6   unassigned      YES unset  down                  down
GigabitEthernet1/0/7   unassigned      YES unset  up                    up
GigabitEthernet1/0/8   unassigned      YES unset  down                  down
GigabitEthernet1/0/9   unassigned      YES unset  up                    up
GigabitEthernet1/0/10  unassigned      YES unset  down                  down
GigabitEthernet1/0/11  unassigned      YES unset  down                  down
GigabitEthernet1/0/12  unassigned      YES unset  down                  down
GigabitEthernet1/0/13  unassigned      YES unset  down                  down
GigabitEthernet1/0/14  unassigned      YES unset  down                  down
GigabitEthernet1/0/15  unassigned      YES unset  down                  down
GigabitEthernet1/0/16  unassigned      YES unset  down                  down
GigabitEthernet1/0/17  unassigned      YES unset  down                  down
GigabitEthernet1/0/18  unassigned      YES unset  down                  down
GigabitEthernet1/0/19  unassigned      YES unset  down                  down
GigabitEthernet1/0/20  unassigned      YES unset  down                  down
GigabitEthernet1/0/21  unassigned      YES unset  down                  down
GigabitEthernet1/0/22  unassigned      YES unset  down                  down
GigabitEthernet1/0/23  unassigned      YES unset  down                  down
GigabitEthernet1/0/24  unassigned      YES unset  up                    down
GigabitEthernet1/0/25  unassigned      YES unset  up                    up
GigabitEthernet1/0/26  unassigned      YES unset  up                    up
GigabitEthernet1/0/27  unassigned      YES unset  up                    up
GigabitEthernet1/0/28  unassigned      YES unset  up                    up
Port-channel1          unassigned      YES unset  up                    up
IND-SW-EDNL_Dept34_PTTL>show cdp neighbors
Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge
                  S - Switch, H - Host, I - IGMP, r - Repeater, P - Phone,
                  D - Remote, C - CVTA, M - Two-port Mac Relay

Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
IND-SW-EDNL_TLL.hulamin.co.za
                 Gig 1/0/27        149              S I   IE-3000-8 Gig 1/1
IND-SW-EDNL_PTTL.hulamin.co.za
                 Gig 1/0/26        141              S I   IE-3000-8 Gig 1/2
IND-SW-Dept34_Distr
                 Gig 1/0/28        168              S I   IE-9320-2 Gig 1/0/24
IND-SW-EDNL_CTLL5.hulamin.co.za
                 Gig 1/0/25        163              S I   IE-3000-8 Gig 1/1

Total cdp entries displayed : 4
IND-SW-EDNL_Dept34_PTTL>show cdp neighbors detail
-------------------------
Device ID: IND-SW-EDNL_TLL.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.59
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/0/27,  Port ID (outgoing port): GigabitEthernet1/1
Holdtime : 149 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF000000000000002790CCD580FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.59

-------------------------
Device ID: IND-SW-EDNL_PTTL.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.70
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/0/26,  Port ID (outgoing port): GigabitEthernet1/2
Holdtime : 141 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF000000000000002790CCE980FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.70

-------------------------
Device ID: IND-SW-Dept34_Distr
Entry address(es):
  IP address: 192.168.160.117
  IPv6 address: FE80::B28D:57FF:FE9C:8EC7  (link-local)
Platform: cisco IE-9320-22S2C4X,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/0/28,  Port ID (outgoing port): GigabitEthernet1/0/24
Holdtime : 168 sec

Version :
Cisco IOS Software [Dublin], Catalyst L3 Switch Software (IE9K_IOSXE), Version 17.12.2, RELEASE SOFTWARE (fc2)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2023 by Cisco Systems, Inc.
Compiled Tue 14-Nov-23 06:36 by mcpre

advertisement version: 2
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.117

-------------------------
Device ID: IND-SW-EDNL_CTLL5.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.71
Platform: cisco IE-3000-8TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/0/25,  Port ID (outgoing port): GigabitEthernet1/1
Holdtime : 163 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF000000000000002790CCEA00FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.71


Total cdp entries displayed : 4
IND-SW-EDNL_Dept34_PTTL>show lldp neighbors
Capability codes:
    (R) Router, (B) Bridge, (T) Telephone, (C) DOCSIS Cable Device
    (W) WLAN Access Point, (P) Repeater, (S) Station, (O) Other

Device ID           Local Intf     Hold-time  Capability      Port ID
IND-SW-EDNL_CTLL5.huGi1/0/25       120        B               port-001-00000
IND-SW-Dept34_Distr Gi1/0/28       20         B               port-024
IND-SL7-ENG-DRI     Gi1/0/2        20         S               port-001
IND-SL7-ENG-PLC     Gi1/0/2        20         S               port-001
IND-PTTLACDRV       Gi1/0/2        20         S               port-001
IND-SW-EDNL_TLL.hulaGi1/0/27       120        B               port-001-00000
IND-CTLL5-ENG       Gi1/0/2        20         S               port-001
IND-SW-EDNL_PTTL.hulGi1/0/26       120        B               port-002-00000

Total entries displayed: 8

IND-SW-EDNL_Dept34_PTTL>show lldp neighbors detail
------------------------------------------------
Local Intf: Gi1/0/25
Chassis id: 0027.90cc.ea40
Port id: port-001-00000
Port Description: GigabitEthernet1/1
System Name: IND-SW-EDNL_CTLL5.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

Time remaining: 99 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.71
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1

------------------------------------------------
Local Intf: Gi1/0/28
Chassis id: b08d.579c.8ec7
Port id: port-024
Port Description: GigabitEthernet1/0/24
System Name: IND-SW-Dept34_Distr

System Description:
Cisco IOS Software [Dublin], Catalyst L3 Switch Software (IE9K_IOSXE), Version 17.12.2, RELEASE SOFTWARE (fc2)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2023 by Cisco Systems, Inc.
Compiled Tue 14-Nov-23 06:36 by mcpre

Time remaining: 18 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.117
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - not supported
Physical media capabilities:
    1000baseT(FD)
Media Attachment Unit type: 26
Vlan ID: 1

------------------------------------------------
Local Intf: Gi1/0/2
Chassis id: ind-sl7-eng-dri
Port id: port-001
Port Description - not advertised
System Name: IND-SL7-ENG-DRI

System Description:
VMware, Inc. VMware Virtual Platform,None,VMware-42 24 a1 26 4c dd 0a ba-b4 07 a4 f5 66 49 19 c5 + engineering

Time remaining: 14 seconds
System Capabilities: S
Enabled Capabilities: S
Management Addresses:
    IP: 192.168.191.51
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
    1000baseT(HD)
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
    Other/unknown
Media Attachment Unit type: 30
Vlan ID: - not advertised

------------------------------------------------
Local Intf: Gi1/0/2
Chassis id: ind-sl7-eng-plc
Port id: port-001
Port Description - not advertised
System Name: IND-SL7-ENG-PLC

System Description:
VMware, Inc. VMware Virtual Platform,None,VMware-42 24 cb 94 46 3c 24 b6-cf ae 73 16 12 cf ef 8b

Time remaining: 15 seconds
System Capabilities: S
Enabled Capabilities: S
Management Addresses:
    IP: 192.168.1.50
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
    1000baseT(HD)
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
    Other/unknown
Media Attachment Unit type: 30
Vlan ID: - not advertised

------------------------------------------------
Local Intf: Gi1/0/2
Chassis id: ind-pttlacdrv
Port id: port-001
Port Description - not advertised
System Name: IND-PTTLACDRV

System Description:
VMware, Inc. VMware Virtual Platform,None,VMware-42 19 86 3f 39 83 18 a1-58 27 3c bc 7a ec b9 52 + engineering

Time remaining: 19 seconds
System Capabilities: S
Enabled Capabilities: S
Management Addresses:
    IP: 192.168.182.13
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
    1000baseT(HD)
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
    Other/unknown
Media Attachment Unit type: 30
Vlan ID: - not advertised

------------------------------------------------
Local Intf: Gi1/0/27
Chassis id: 0027.90cc.d582
Port id: port-001-00000
Port Description: GigabitEthernet1/1
System Name: IND-SW-EDNL_TLL.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

Time remaining: 90 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.59
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1

------------------------------------------------
Local Intf: Gi1/0/2
Chassis id: ind-ctll5-eng
Port id: port-001
Port Description - not advertised
System Name: IND-CTLL5-ENG

System Description:
VMware, Inc. VMware Virtual Platform,None,VMware-42 24 59 3a 29 5c f4 10-b5 e7 a8 9c f2 a4 5a 79 + engineering

Time remaining: 12 seconds
System Capabilities: S
Enabled Capabilities: S
Management Addresses:
    IP: 10.18.14.210
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseT(FD)
    1000baseT(HD)
    100base-TX(FD)
    100base-TX(HD)
    10base-T(FD)
    10base-T(HD)
    Other/unknown
Media Attachment Unit type: 30
Vlan ID: - not advertised

------------------------------------------------
Local Intf: Gi1/0/26
Chassis id: 0027.90cc.e982
Port id: port-002-00000
Port Description: GigabitEthernet1/2
System Name: IND-SW-EDNL_PTTL.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.2(4)EA5, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2016 by Cisco Systems, Inc.
Compiled Tue 20-Dec-16 14:59 by prod_rel_team

Time remaining: 111 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.70
    OID:
        1.3.6.1.4.1.24686.
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1


Total entries displayed: 8

IND-SW-EDNL_Dept34_PTTL>

```

## IND-SW-EDNL_TLL

```Cisco
Industrial IT Switch
IND-SW-EDNL_TLL>show vlan brief

VLAN Name                             Status    Ports
---- -------------------------------- --------- -------------------------------
1    default                          active    Fa1/8
250  IND-250                          active
501  CCL                              active
526  IND-S6                           active
560  VLAN0560                         active
561  VLAN0561                         active    Fa1/3, Fa1/4, Fa1/5, Fa1/6, Fa1/7
567  CTTL5_Mgaurd                     active
574  IND-AnnealingFurnace             active
579  PTTL Network                     active
581  PTTL_ACDrives                    active
582  IND-SL6                          active
585  VLAN0585                         active
590  EDPowerMeters                    active    Fa1/1, Fa1/2
591  VLAN0591                         active
592  Crane                            active
593  Ignition                         active
1002 fddi-default                     act/unsup
1003 token-ring-default               act/unsup
1004 fddinet-default                  act/unsup
1005 trnet-default                    act/unsup
IND-SW-EDNL_TLL>show ip interface brief
Interface              IP-Address      OK? Method Status                Protocol
Vlan1                  unassigned      YES NVRAM  administratively down down
Vlan501                unassigned      YES unset  up                    up
Vlan560                192.168.160.59  YES NVRAM  up                    up
Vlan567                unassigned      YES unset  up                    up
Vlan579                unassigned      YES unset  up                    up
Vlan581                192.168.181.147 YES NVRAM  up                    up
Vlan582                192.168.182.147 YES NVRAM  up                    up
Vlan585                unassigned      YES unset  up                    up
Vlan590                unassigned      YES unset  up                    up
Vlan591                unassigned      YES unset  up                    up
FastEthernet1/1        unassigned      YES unset  up                    up
FastEthernet1/2        unassigned      YES unset  up                    up
FastEthernet1/3        unassigned      YES unset  down                  down
FastEthernet1/4        unassigned      YES unset  down                  down
FastEthernet1/5        unassigned      YES unset  down                  down
FastEthernet1/6        unassigned      YES unset  down                  down
FastEthernet1/7        unassigned      YES unset  up                    up
FastEthernet1/8        unassigned      YES unset  down                  down
GigabitEthernet1/1     unassigned      YES unset  up                    up
GigabitEthernet1/2     unassigned      YES unset  up                    up
IND-SW-EDNL_TLL>show cdp neighbors
Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge
                  S - Switch, H - Host, I - IGMP, r - Repeater, P - Phone,
                  D - Remote, C - CVTA, M - Two-port Mac Relay

Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
IND-SW-EDNL_Dept34_PTTL.hulamin.co.za
                 Gig 1/1           171              S I   WS-C2960X Gig 1/0/27
IND-SW-EDNL_SL7.hulamin.co.za
                 Gig 1/2           128              S I   IE-3000-4 Gig 1/1

Total cdp entries displayed : 2
IND-SW-EDNL_TLL>show cdp neighbors detail
-------------------------
Device ID: IND-SW-EDNL_Dept34_PTTL.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.84
Platform: cisco WS-C2960X-24TS-L,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/1,  Port ID (outgoing port): GigabitEthernet1/0/27
Holdtime : 171 sec

Version :
Cisco IOS Software, C2960X Software (C2960X-UNIVERSALK9-M), Version 15.2(2)E7, RELEASE SOFTWARE (fc3)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2017 by Cisco Systems, Inc.
Compiled Wed 12-Jul-17 13:06 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF0000000000007802B1AFB900FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.84

-------------------------
Device ID: IND-SW-EDNL_SL7.hulamin.co.za
Entry address(es):
  IP address: 192.168.160.73
Platform: cisco IE-3000-4TC,  Capabilities: Switch IGMP
Interface: GigabitEthernet1/2,  Port ID (outgoing port): GigabitEthernet1/1
Holdtime : 128 sec

Version :
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.0(2)EY3, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2013 by Cisco Systems, Inc.
Compiled Thu 14-Nov-13 13:52 by prod_rel_team

advertisement version: 2
Protocol Hello:  OUI=0x00000C, Protocol ID=0x0112; payload len=27, value=00000000FFFFFFFF010221FF00000000000000562B857380FF0000
VTP Management Domain: ''
Native VLAN: 1
Duplex: full
Management address(es):
  IP address: 192.168.160.73


Total cdp entries displayed : 2
IND-SW-EDNL_TLL>show lldp neighbors
Capability codes:
    (R) Router, (B) Bridge, (T) Telephone, (C) DOCSIS Cable Device
    (W) WLAN Access Point, (P) Repeater, (S) Station, (O) Other

Device ID           Local Intf     Hold-time  Capability      Port ID
IND-SW-EDNL_Dept34_PGi1/1          120        B               Gi1/0/27
IND-SW-EDNL_SL7.hulaGi1/2          120        B               Gi1/1

Total entries displayed: 2

IND-SW-EDNL_TLL>show lldp neighbors detail
------------------------------------------------
Local Intf: Gi1/1
Chassis id: 7802.b1af.b900
Port id: Gi1/0/27
Port Description: GigabitEthernet1/0/27
System Name: IND-SW-EDNL_Dept34_PTTL.hulamin.co.za

System Description:
Cisco IOS Software, C2960X Software (C2960X-UNIVERSALK9-M), Version 15.2(2)E7, RELEASE SOFTWARE (fc3)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2017 by Cisco Systems, Inc.
Compiled Wed 12-Jul-17 13:06 by prod_rel_team

Time remaining: 94 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.84
Auto Negotiation - not supported
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1

------------------------------------------------
Local Intf: Gi1/2
Chassis id: 0056.2b85.7380
Port id: Gi1/1
Port Description: GigabitEthernet1/1
System Name: IND-SW-EDNL_SL7.hulamin.co.za

System Description:
Cisco IOS Software, IES Software (IES-LANBASEK9-M), Version 15.0(2)EY3, RELEASE SOFTWARE (fc1)
Technical Support: http://www.cisco.com/techsupport
Copyright (c) 1986-2013 by Cisco Systems, Inc.
Compiled Thu 14-Nov-13 13:52 by prod_rel_team

Time remaining: 94 seconds
System Capabilities: B,R
Enabled Capabilities: B
Management Addresses:
    IP: 192.168.160.73
Auto Negotiation - supported, enabled
Physical media capabilities:
    1000baseX(FD)
Media Attachment Unit type: 26
Vlan ID: 1


Total entries displayed: 2

IND-SW-EDNL_TLL>

```
