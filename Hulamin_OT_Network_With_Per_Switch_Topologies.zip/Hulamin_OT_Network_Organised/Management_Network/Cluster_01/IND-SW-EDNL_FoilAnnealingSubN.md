# IND-SW-EDNL_FoilAnnealingSubN

> Cluster: Cluster_01  
> Classification: provisional LLDP/CDP discovery grouping. Confirm physical department/location before renaming or moving.

#### IND-SW-EDNL_FoilAnnealingSubN

##### Device Info

| Field | Value |
|---|---|
| **Name** | IND-SW-EDNL_FoilAnnealingSubN |
| **IP Address** | 192.168.160.67 |
| **Vendor profile** | cisco_ios |
| **Model** | cisco WS-C2950SX-24 |
| **Total physical ports reported** | — |
| **Ports up** | — |
| **Location** | Not documented |
| **Transport** | SSH |
| **Connection port** | 22 |
| **Collection status** | failed |
| **Connection method** | Netmiko SSH |
| **Collection time** | 10.00s |
| **Notes** | NetmikoTimeoutException: TCP connection to device failed.  Common causes of this problem are: 1. Incorrect hostname or IP address. 2. Wrong TCP port. 3. Intermediate firewall blocking access.  Device settings: cisco_ios 192.168.160.67:22   |

##### Connected Ports / Discovered Neighbours

| Local Port | State | VLAN | Connected Device | Remote Port | Remote IP | Remote Platform | Media | Seen By |
|---|---|---|---|---|---|---|---|---|
| — | — | — | No port or neighbour data was returned. | — | — | — | — | — |

##### Raw CLI Output

Collection did not produce command output.

---
