# Documentation website environment

This directory owns only the dependencies needed to preview/build the Markdown course website. It is intentionally separate from all eight Python learning projects.

From the repository root:

```bash
uv sync --project docs-site
uv run --project docs-site mkdocs serve --config-file mkdocs.yml
```

Markdown source lives in `../docs/`. Do not edit generated HTML under `site/`; edit the corresponding Markdown page instead.

The course uses MkDocs with the Material theme for a dependable starting point in October 2026. The Markdown and `mkdocs.yml` configuration keep the content portable if you choose to evaluate Zensical later.
