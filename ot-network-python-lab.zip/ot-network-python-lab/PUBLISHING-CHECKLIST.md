# Before publishing this repository

- [ ] Decide whether to add a licence. Do not assume a public repository automatically grants permission to reuse the code.
- [ ] Review the README and repository name.
- [ ] Run tests and Ruff locally for all eight projects, on each available OS.
- [ ] Run the documentation site and inspect navigation and links.
- [ ] Confirm sample inventories use fictional/documentation-only values.
- [ ] Confirm there are no company names, site addresses, actual inventories, logs, screenshots, certificates, usernames, passwords, tokens or `.env` files.
- [ ] Confirm `.venv`, `site/`, report outputs and packet captures are not staged.
- [ ] After `uv sync` in each project, commit its `uv.lock` file.
- [ ] Do not claim live OT integration until you've tested it against an authorised simulator/lab and documented the limits.
