# OT Network Python Lab

A beginner-friendly, hands-on Python course for networking and OT engineering. The repository combines editable Markdown lessons with eight small, independently managed Python projects.

The goal is not to memorise code. The goal is to understand how the code works, test it, document it, debug it, and make it maintainable enough for another engineer to use.

## Learning path

1. Set up a consistent Python environment on Windows and Linux.
2. Learn Python fundamentals and professional project structure.
3. Build an IPv4 subnet calculator and OT asset inventory validator.
4. Build a reachability checker and interface-health report tool.
5. Analyse text logs and offline packet captures.
6. Read data from an OPC UA lab server and a Modbus TCP simulator.

## Requirements

- Python 3.14.x (the `.python-version` files request Python 3.14; `uv` can manage the interpreter).
- Visual Studio Code.
- Git.
- `uv` for environments and dependencies.
- Internet access for initial installation of tools and third-party packages. The actual learning projects can then work against local files or your approved lab.

## Start with the course website

From this repository's root directory:

```bash
uv sync --project docs-site
uv run --project docs-site mkdocs serve --config-file mkdocs.yml
```

Open the local URL printed by MkDocs in your browser. Stop the server with `Ctrl+C`.

To build a static site instead of serving a preview:

```bash
uv run --project docs-site mkdocs build --config-file mkdocs.yml
```

Generated site files go into `site/` and are excluded from Git.

## Run your first project

Commands are run from the project folder. In PowerShell, `cd` works the same way as in most terminals.

```bash
cd projects/01-subnet-calculator
uv sync
uv run python -m subnet_calculator.cli 192.168.10.25/24
uv run pytest
uv run ruff check .
uv run ruff format --check .
```

If you are using Windows PowerShell, run the same commands. `uv` selects the project's requested Python version and uses that project's `.venv` and lockfile.

## How the repository is organised

- `docs/`: course lessons and detailed project walkthroughs. These are normal Markdown files you can edit in VS Code.
- `projects/`: eight separate Python projects. Every project owns its own `pyproject.toml`, dependency environment, source code, tests and README.
- `docs-site/`: the isolated tooling environment for the documentation website.
- `.github/workflows/`: an example cross-platform CI workflow for tests, linting and formatting checks.

The root folder is a learning repository, not one large Python application. Each project can eventually be extracted into its own repository without rewriting its package structure.

## Recommended workflow for every project

1. Read the relevant lesson before changing code.
2. Run the current program and tests.
3. Make one small change at a time.
4. Run tests and Ruff after every meaningful change.
5. Inspect the Git diff before committing.
6. Update the project's README when behaviour changes.
7. Write down the issue, evidence and fix when troubleshooting.

Useful commands from inside a project:

```bash
uv sync
uv run pytest
uv run ruff check .
uv run ruff format .
git status
git diff
```

`uv sync` generates `uv.lock` the first time and installs the locked dependencies. Commit that lockfile for reproducibility. Do not commit `.venv`, secrets, production logs, customer data or real OT network exports.

## OT safety boundary

Use fictional data, your own computer, isolated virtual machines, protocol simulators or explicitly authorised test systems. Do not run scans, packet capture, polling or protocol clients against production OT equipment just because an IP address is reachable. Follow site change control and monitoring procedures. Projects 6–8 are deliberately designed around offline captures, read operations and lab endpoints.

## Further reading

- [Python documentation](https://docs.python.org/3.14/)
- [Python Packaging User Guide](https://packaging.python.org/)
- [uv documentation](https://docs.astral.sh/uv/)
- [pytest documentation](https://docs.pytest.org/)
- [Ruff documentation](https://docs.astral.sh/ruff/)
- [Scapy documentation](https://scapy.readthedocs.io/)
- [asyncua documentation](https://opcua-asyncio.readthedocs.io/)
- [PyModbus documentation](https://pymodbus.readthedocs.io/)
