# Glossary

- **API:** a defined interface through which one program uses another program or service.
- **Asset inventory:** a record of devices, identities, network addresses, roles and other relevant attributes.
- **CLI:** command-line interface; the way a program accepts arguments and reports results in a terminal.
- **Dependency:** a package or tool a project requires.
- **ICMP:** Internet Control Message Protocol; used by utilities such as ping for echo checks and network diagnostics.
- **IP address:** a logical address used to identify an interface on an IP network.
- **Lockfile:** a file recording specific resolved dependency versions for reproducible installs.
- **Modbus register:** a protocol-defined 16-bit value addressed according to a device's register map.
- **NodeId:** the identifier of a node in an OPC UA address space.
- **OPC UA:** an industrial interoperability framework for exchanging structured data and information models.
- **OT:** operational technology; systems that monitor or affect physical processes.
- **Packet capture:** a recorded collection of network packets, often stored in PCAP/PCAPNG format.
- **Pytest:** a Python testing framework.
- **Ruff:** a Python linter and formatter.
- **Unit test:** a test of one small part of an application in isolation.
- **uv:** a Python tool for interpreter, environment and dependency management.
- **VLAN:** a logical Layer 2 broadcast domain implemented within switching infrastructure.
- **Virtual environment:** an isolated Python environment for project packages.
