# Project workflow checklist

Use this checklist each time you start or finish a meaningful task.

## Before coding

- [ ] Read the requirement and relevant project lesson.
- [ ] Confirm that the target is fictional, local or explicitly approved.
- [ ] Check `git status` so existing work is not lost.
- [ ] Run the current tests to establish a baseline.

## While coding

- [ ] Make a small change.
- [ ] Keep application logic separate from CLI output where practical.
- [ ] Validate inputs at program boundaries.
- [ ] Use clear function and variable names.
- [ ] Avoid secrets and sensitive operational data.

## Before committing

- [ ] `uv run pytest`
- [ ] `uv run ruff check .`
- [ ] `uv run ruff format --check .`
- [ ] Review `git diff` and `git status`.
- [ ] Update README/docs if usage has changed.
- [ ] Confirm the tests cover the behaviour added or fixed.
- [ ] Commit one logical change with a meaningful message.
