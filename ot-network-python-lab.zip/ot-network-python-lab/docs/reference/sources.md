# Sources and further reading

These are primary documentation sources to consult when library APIs or installation instructions change. Tutorials and example commands in this course should always be checked against the version installed by the project's lockfile.

- Python 3.14 documentation: https://docs.python.org/3.14/
- Python packaging guide: https://packaging.python.org/
- uv docs: https://docs.astral.sh/uv/
- VS Code Python docs: https://code.visualstudio.com/docs/languages/python
- Git documentation: https://git-scm.com/doc
- pytest docs: https://docs.pytest.org/
- Ruff docs: https://docs.astral.sh/ruff/
- psutil docs: https://psutil.readthedocs.io/
- Scapy docs: https://scapy.readthedocs.io/
- asyncua docs: https://opcua-asyncio.readthedocs.io/
- PyModbus docs: https://pymodbus.readthedocs.io/
- MkDocs Material docs: https://squidfunk.github.io/mkdocs-material/
- Zensical docs: https://zensical.org/docs/

Package APIs can evolve. If an example fails because a library renamed a parameter, check the installed version and the primary documentation before changing the code randomly.
