# Troubleshooting guide

## `uv` says the Python version is missing

Run `uv python list` and `uv python install 3.14`. Check that your network permits the tool to download the managed interpreter. Do not change the project's Python requirement merely to work around a failed download without understanding compatibility.

## Package installation fails

Read the complete error. Common causes include a blocked package index, DNS/proxy problems, TLS interception, or a package/version compatibility constraint. In a corporate environment, ask for the supported package index and proxy instructions; do not bypass security controls.

## `ModuleNotFoundError`

- Confirm that the terminal is in the correct project directory.
- Run `uv sync` in that project.
- Run commands using `uv run` so the project environment is selected.
- Check the import name: some package names differ from the Python import name.

## `pytest` cannot import the package

The projects use a `src` layout and configure pytest to include `src` for local tests. Run tests from the project root. Do not fix import errors by hardcoding an absolute path to your own computer.

## File not found

Print the current directory (`Get-Location` in PowerShell, `pwd` in Bash). Relative paths are interpreted from the current directory. Use the project README's working directory and sample-data path.

## Ping shows offline but you believe the host is running

ICMP may be blocked, a route may be missing or the local `ping` command may not exist. This tool reports ICMP-command reachability, not whether every application on the host is healthy. Confirm using an approved alternative such as a documented application health check.

## Protocol client cannot connect

Check that the lab server/simulator is running, endpoint and port match the server configuration, routing/firewall rules permit the connection, and the node/register address is correct. A connection test alone does not justify trying random addresses on a production network.

## Ruff reports a problem

Read the rule code and file/line. Fix the underlying issue where practical. Run `uv run ruff format .` only when a formatting change is intended, then inspect the diff.
