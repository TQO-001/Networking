# Editing the course website

Edit the source `.md` files under `docs/` in VS Code. `mkdocs.yml` controls the navigation menu. When adding a new lesson, create the Markdown file, add an entry to `nav`, then run the site locally and confirm the page and links work.

From the repository root:

```bash
uv run --project docs-site mkdocs serve --config-file mkdocs.yml
```

MkDocs rebuilds the preview when Markdown is saved. Generated output in `site/` is disposable; edit the Markdown source, not generated HTML.

The site uses MkDocs with the Material theme as a stable starter for this course. Keep lessons in standard Markdown and avoid theme-specific syntax unless it materially helps. That makes it easier to evaluate a different documentation generator later.
