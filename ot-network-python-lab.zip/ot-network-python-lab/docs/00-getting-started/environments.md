# Python environments: uv, venv and pip

## Why environments exist

Different projects can need different versions of the same dependency. A virtual environment isolates installed packages so one project does not accidentally change another project's dependencies.

This repository gives each Python project its own `.venv` and `uv.lock`. The documentation website has a separate environment under `docs-site/`.

## The uv workflow used in this course

Run these commands from the project directory:

```bash
uv sync
uv run python -m subnet_calculator.cli 192.168.10.25/24
uv run pytest
uv add psutil
uv remove psutil
```

The last two commands are examples only: use `uv add` when a project really needs a dependency. Project 1 does not need `psutil`.

- `uv sync` resolves/installs the project's declared dependencies from `pyproject.toml` and `uv.lock`.
- `uv run` runs a command inside the project environment.
- `uv add` declares a runtime dependency and updates the lockfile.
- `uv remove` removes a declared dependency.
- `uv lock` refreshes dependency resolution without being a substitute for testing.

Commit `pyproject.toml` and `uv.lock` together. The manifest explains what the project requests; the lockfile records resolved versions.

## What are venv and pip?

The traditional equivalent is:

```bash
python -m venv .venv
```

Windows PowerShell activation:

```powershell
.venv\Scripts\Activate.ps1
python -m pip install pytest ruff
python -m pip freeze
```

Linux activation:

```bash
source .venv/bin/activate
python -m pip install pytest ruff
python -m pip freeze
```

When finished, run `deactivate` in a shell where you activated the environment. Activation is optional; it primarily changes which executables the shell finds first. In this course, `uv run` avoids needing to activate it.

`pip` installs packages. `venv` creates a virtual environment. `uv` combines environment management, Python version management, dependency resolution and fast installation. They are related, but they are not interchangeable words.

## Important details

- Do not use `pip install` globally for each project.
- Do not delete a lockfile just because a dependency installation fails; first read the error and diagnose the actual cause.
- Do not copy a `.venv` from Windows to Linux or vice versa. Recreate it with `uv sync`.
- For workplace projects, follow the organisation's approved package index, dependency review and vulnerability-management process.
