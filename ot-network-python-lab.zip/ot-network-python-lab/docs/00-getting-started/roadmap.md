# Learning roadmap

## The approach: one deep skill, the rest functional

Your main focus is Python fundamentals and professional code structure. The network projects supply meaningful examples, but do not try to learn Python, TCP/IP, OPC UA, Git and testing all at once.

### Milestones

| Milestone | Evidence you are ready to continue |
|---|---|
| Environment | You can open a terminal, run Python, use `uv`, and explain where the environment lives. |
| Python foundations | You can write a function, use a loop, handle a bad value, and read a CSV file without copying an entire solution. |
| Project structure | You understand the difference between a CLI, application logic, tests, metadata and documentation. |
| Projects 1–2 | You can validate user data and produce clear error messages. |
| Projects 3–4 | You understand that availability checks and interface counters have limitations. |
| Projects 5–6 | You can summarise logs or a capture without making claims unsupported by the data. |
| Projects 7–8 | You can connect to a lab protocol service and collect data using a read-only client. |

## A repeatable study session

1. **Read (10–15 minutes):** read the relevant lesson and project objective.
2. **Run (5 minutes):** execute the starter program and tests before editing anything.
3. **Understand (15 minutes):** trace one function and note its input, output and possible errors.
4. **Build (20–40 minutes):** complete one small exercise.
5. **Verify (10 minutes):** run tests, Ruff and a manual example.
6. **Record (5 minutes):** commit the change and write down what you learned.

Shorter sessions are fine. Stop at a clean checkpoint rather than rushing through a lesson.

## Required vs extension work

The README and project lesson define the required core. Sections labelled **Extension** are optional. Do not start an extension while the core program is failing its tests.

## What “workplace-ready” means here

These projects are training tools, not production OT monitoring products. The goal is to practise transferable engineering habits: reproducible dependencies, reviewable changes, input validation, clear diagnostics, tests, documented assumptions and conservative interaction with systems.
