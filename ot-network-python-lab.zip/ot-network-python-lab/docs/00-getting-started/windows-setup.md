# Windows setup (PowerShell)

These steps are written for Windows 10/11 and PowerShell. If your work computer is managed, follow your organisation's software installation policy rather than installing tools without approval.

## 1. Install the tools

Install Python 3.14.x, Git and Visual Studio Code using their official installation instructions. Install the official VS Code Python extension. Then install `uv` using the official `uv` installation instructions. Do not download installers from third-party mirrors.

Official references:

- [Python for Windows](https://docs.python.org/3.14/using/windows.html)
- [Git downloads](https://git-scm.com/downloads)
- [VS Code Python tutorial](https://code.visualstudio.com/docs/languages/python)
- [uv installation](https://docs.astral.sh/uv/getting-started/installation/)

## 2. Verify installations

Open PowerShell and run:

```powershell
python --version
git --version
uv --version
```

The Python version should begin with `Python 3.14.`. If Windows opens the Microsoft Store when you type `python`, review App Execution Aliases and your installation `PATH`; do not randomly reinstall everything.

## 3. Open the repository

In VS Code, choose **File → Open Folder** and select the `ot-network-python-lab` directory. Open **Terminal → New Terminal**. Confirm that the terminal starts at the repository root by running:

```powershell
Get-Location
Get-ChildItem
```

## 4. Prepare a project

```powershell
cd projects/01-subnet-calculator
uv sync
uv run python -m subnet_calculator.cli 192.168.10.25/24
uv run pytest
uv run ruff check .
uv run ruff format --check .
```

The first `uv sync` may download the requested Python interpreter and dependencies. It creates a local `.venv` and `uv.lock` file if one does not exist. Commit `uv.lock`; do not commit `.venv`.

## 5. Run the course website

Open a second terminal, navigate to the repository root, then:

```powershell
uv sync --project docs-site
uv run --project docs-site mkdocs serve --config-file mkdocs.yml
```

Open the local address MkDocs prints. Stop the server using `Ctrl+C`.

## Common Windows problems

- **`uv` is not recognised:** close and reopen the terminal after installation; check the official installation guide and `PATH`.
- **Wrong Python version:** run `uv python list`; `uv` can manage Python 3.14 for a project even if another version is installed globally.
- **Execution policy messages:** the commands above use `uv run` and do not require you to activate a PowerShell script manually.
- **Permission denied:** move the repo to a folder you own; do not run VS Code or Python as Administrator as a routine workaround.
- **Network restrictions:** on a managed workstation, proxy/firewall policy may block package indexes. Ask your administrator for the approved approach instead of bypassing the control.
