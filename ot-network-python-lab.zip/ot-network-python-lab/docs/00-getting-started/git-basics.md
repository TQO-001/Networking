# Git basics for engineering work

Git records how your project changes. GitHub hosts a remote copy and adds features such as issue tracking, pull requests and automated checks.

## First-time identity setup

Set your Git name and email using the address you want associated with your commits. If you are working on a managed device, follow your organisation's configuration guidance.

```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```

These values are commit metadata, not authentication credentials. Never put a token, password or private key in a Git command saved to your shell history.

## Everyday loop

```bash
git status
git diff
git add src/subnet_calculator/calculator.py tests/test_calculator.py
git commit -m "Add IPv4 subnet summary"
git status
```

Use `git add` for the specific files you intend to commit. Avoid `git add .` until you understand what is in the working tree, especially when reports or captures may contain sensitive information.

## Commit quality

Good commit messages say what changed:

- `Validate subnet calculator input`
- `Add duplicate IP checks to inventory report`
- `Document ICMP monitoring limitations`

Avoid messages such as `stuff`, `updates`, or `final final`. One logical change per commit makes debugging and reviewing easier.

## Before pushing to GitHub

1. Run tests and Ruff.
2. Review `git status` and `git diff`.
3. Check that no secrets, `.env` files, production logs, real inventories, packet captures or company screenshots are staged.
4. Commit and push using your normal GitHub authentication method.

A public repository is a public disclosure. Sanitise samples even when you think an address is “only internal.”
