# Linux setup (Bash)

Use a supported Linux distribution such as Ubuntu in a personal machine or lab VM. On a managed work machine, follow local software-installation and network policies.

## 1. Install the tools

Install Git and Visual Studio Code using your distribution's supported method or the vendor's official instructions. Install `uv` from its official documentation. Use the Python version managed by uv for these projects; avoid changing the system Python required by operating-system tools.

References:

- [Python on Linux](https://docs.python.org/3.14/using/unix.html)
- [Git downloads](https://git-scm.com/downloads)
- [VS Code setup](https://code.visualstudio.com/docs/setup/linux)
- [uv installation](https://docs.astral.sh/uv/getting-started/installation/)

## 2. Verify

```bash
python3 --version
git --version
uv --version
```

The system's `python3` may not be version 3.14. That is okay: this course uses the `.python-version` and `requires-python` project settings so uv can manage the project interpreter.

## 3. Prepare a project

From the repository root:

```bash
cd projects/01-subnet-calculator
uv sync
uv run python -m subnet_calculator.cli 192.168.10.25/24
uv run pytest
uv run ruff check .
uv run ruff format --check .
```

## 4. Run the website

From the repository root:

```bash
uv sync --project docs-site
uv run --project docs-site mkdocs serve --config-file mkdocs.yml
```

Visit the local URL printed by MkDocs and stop the server with `Ctrl+C`.

## Linux notes

- Some operations such as capturing live packets may require elevated capabilities; this course avoids live capture and reads saved capture files instead.
- Do not run the project with `sudo` just to make an error disappear. Understand the permission requirement first.
- ICMP echo requests may be blocked by local firewall policy. A failed ping does not prove that a host or application is offline.
- Interface names and statistics vary by operating system and virtualisation platform.
