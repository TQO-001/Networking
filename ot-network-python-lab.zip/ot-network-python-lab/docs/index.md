# Welcome to the OT Network Python Lab

Learn Python by building the kinds of small diagnostic and monitoring tools a network engineer can understand, test and maintain.

## What you will build

| Project | What it teaches | Main tool |
|---|---|---|
| 1. IPv4 subnet calculator | Functions, IP maths, validation | Python standard library |
| 2. OT asset inventory checker | CSV, records, validation | `csv`, `ipaddress` |
| 3. Reachability monitor | Processes, timeouts, reports | `subprocess`, `time` |
| 4. Interface health monitor | OS statistics and snapshots | `psutil` |
| 5. Log analyser | Text parsing and aggregation | `re`, `Counter`, `json` |
| 6. Offline packet analyser | Packet layers and protocol counts | Scapy |
| 7. OPC UA client | Async code and industrial telemetry | `asyncua` |
| 8. Modbus TCP reader | Register addressing and TCP clients | PyModbus |

## How to use the course

1. Work through [the roadmap](00-getting-started/roadmap.md) and complete the platform setup.
2. Read the Python fundamentals pages while building Project 1.
3. For each project, read its lesson, run the starter version, inspect the source, complete the exercises, and run the tests.
4. Commit your progress with Git. A small, understandable commit is better than one huge commit at the end.
5. Keep your notes about surprising errors and how you resolved them. Troubleshooting is part of engineering.

## Definition of done

A project is not done merely because it runs once. For the core version, aim to:

- [ ] Explain the purpose of every module and important function.
- [ ] Run it from a clean checkout using the README instructions.
- [ ] Handle invalid input without a confusing traceback.
- [ ] Pass its automated tests and Ruff checks.
- [ ] Describe limitations and safe operating boundaries.
- [ ] Commit the code, tests and documentation together.

## Safety first

Start with fictional input data and local services. Use packet capture files you created or are authorised to examine. Run network checks and industrial protocol clients only against your own machine, an isolated lab or explicitly approved endpoints. These starter clients are designed to read or report data; they are not intended to change PLC states, write registers or scan production subnets.
