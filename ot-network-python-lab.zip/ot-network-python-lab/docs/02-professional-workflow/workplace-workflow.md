# A professional development loop

Use this process for every project, even if you are working alone. It mimics the parts of workplace software engineering that transfer well to a junior role.

## 1. State the requirement

Write one sentence describing the problem and the expected result. Define what the program will not do. For network tools, define the authorised targets and the maximum traffic or request frequency before running them.

## 2. Plan the smallest change

Name the input, output and failure cases. Sketch the function signatures or sample output before writing a large amount of code.

## 3. Implement a small slice

Keep changes small enough to review. Avoid combining formatting changes, major refactoring and new features into one change unless the refactor is required.

## 4. Verify

Run tests, Ruff and a manual example. Check both successful output and failure behaviour. For external services, distinguish a software defect from a lab endpoint being unavailable or configured differently.

## 5. Review

Read the diff as if a teammate will review it. Ask:

- Does each function have one clear job?
- Are assumptions and limitations documented?
- Could bad input crash the program with an unhelpful message?
- Are credentials or sensitive logs accidentally included?
- Does the code claim more than the evidence establishes?

## 6. Document and commit

Update the README when commands, dependencies or output change. Commit a single logical change using an imperative message such as `Validate IPv4 input`. Push to the branch you intend to share.

## Troubleshooting note format

For non-trivial issues, record:

- **Symptom:** what happened.
- **Expected:** what should have happened.
- **Evidence:** exact command, relevant output and environment (sanitised).
- **Hypothesis:** the most likely cause and why.
- **Test:** the smallest safe check to confirm or disprove it.
- **Resolution:** what changed and how it was verified.

This is more useful than recording only the final fix because another engineer can reproduce the diagnosis.
