# Testing, Ruff and code quality

## The testing pyramid at this course's scale

1. **Unit tests:** test a small function using known inputs and expected outputs. Example: a `/24` subnet should have 254 conventional usable hosts.
2. **Component tests:** test how parts work together, such as reading a CSV file and validating its rows.
3. **Lab/integration tests:** connect to a simulator or explicitly approved lab service. These are optional and are not required for the basic automated test suite.

Do not make every automated test depend on a live PLC, an Internet host or a specific NIC. Such tests fail for reasons unrelated to the logic and can cause unwanted network traffic.

## Run tests

From a project directory:

```bash
uv run pytest
```

A test usually follows **Arrange → Act → Assert**:

```python
def test_example() -> None:
    # Arrange
    value = "192.168.10.25/24"

    # Act
    result = value.endswith("/24")

    # Assert
    assert result is True
```

This is only an illustration of structure, not a useful test for IP calculations. A real test must assert the behaviour that matters.

## Run Ruff

```bash
uv run ruff check .
uv run ruff format --check .
```

To apply formatting intentionally:

```bash
uv run ruff format .
```

Ruff's linter identifies patterns that may be errors or maintenance problems; its formatter standardises presentation. A clean Ruff run does not prove that your program is correct. Tests and review are still required.

## What should be tested?

- A normal valid case.
- The smallest and largest allowed values.
- Invalid text or missing fields.
- Empty files and empty collections where relevant.
- Failure of a dependency or network service without attempting to hide it.

## When a test fails

Read the first failure and traceback. Identify the assertion and actual value. Reproduce the small failure. Change one thing. Run the focused test, then the full suite. Do not delete or weaken a test merely to make the suite green; update it only when the intended behaviour has deliberately changed.
