# Professional Python project structure

A small script can start as one file. As it grows, separate responsibilities so the code can be tested and understood without running the entire application.

## The structure used in this course

```text
project-name/
├── README.md
├── pyproject.toml
├── uv.lock
├── .python-version
├── src/
│   └── package_name/
│       ├── __init__.py
│       ├── core.py
│       └── cli.py
└── tests/
    ├── test_core.py
    └── test_cli.py
```

- `src/package_name/`: code users import.
- `core.py`: reusable logic, ideally independent of terminal input/output.
- `cli.py`: command-line arguments, printing and exit codes.
- `tests/`: executable checks of intended behaviour.
- `pyproject.toml`: project metadata, runtime dependencies and development tools.
- `uv.lock`: exact resolved dependency versions for repeatable installs.
- `README.md`: how a new user installs, runs and tests the project.

## Why the `src` layout?

It helps avoid accidental imports from the repository root during tests and encourages testing the installed package layout. It is common in Python packages, though a tiny throwaway script does not always need it.

## What belongs in which module?

A useful rule is to separate **what the program does** from **how a user interacts with it**. For example, `summarize_network("192.168.10.25/24")` should calculate a report and return it. `cli.py` should read the CLI argument and print the report. Keeping the calculation separate makes it easy to test without capturing terminal output.

Avoid adding abstractions just to make the folder look sophisticated. A second module is worthwhile when it clarifies a responsibility or makes the code more testable.

## `pyproject.toml` and dependency groups

Runtime dependencies are packages needed to run the program (for example, `psutil` in Project 4). Development dependencies support work on the code (for example, `pytest` and `ruff`). The project metadata in this course uses a development dependency group to make both available with `uv sync`.

## Naming habits

- Packages and modules: `snake_case`.
- Functions and variables: `snake_case`.
- Classes: `PascalCase`.
- Constants: `UPPER_SNAKE_CASE`.
- Names should express meaning, not implementation trivia.

## When a project is mature

A workplace repository may also need deployment configuration, structured logging, security review, release notes, licensing, contribution guidance, monitoring and operational runbooks. Add those because the project needs them; don't copy a large enterprise template into a four-function learning exercise.
