# Project 4 — Network Interface Health Monitor

**Level:** Beginner to intermediate · **Dependency:** `psutil` · **Main concept:** inspect local OS networking data and report its limitations.

## What you're building

A one-time snapshot of the computer running the script: interface names, IP addresses, up/down status when supplied by the OS, speed/MTU and cumulative sent/received packets, bytes, errors and drops where available.

This is a local-machine report. It does not log into switches or collect statistics from remote interfaces.

## Step 1 — Install and run

```bash
uv sync
uv run python -m interface_health.cli --output interface-snapshot.json
uv run pytest
```

Open the JSON output and identify the interface used by your current connection. Do not assume the same interface names exist on Windows and Linux; virtual adapters, VPNs, containers and VMs can add interfaces.

## Step 2 — Inspect the code

`collect_snapshot` calls `psutil.net_if_addrs`, `psutil.net_if_stats` and `psutil.net_io_counters(pernic=True)`. It joins those data sources by interface name. Some fields may be absent or `None` on some operating systems/drivers; this is normal and should not automatically be treated as a zero value.

The result is structured as a dictionary and written with `json.dumps`. JSON output is suitable for later processing by dashboards or scripts.

## Important measurement concept: counters versus rates

The byte and packet fields are cumulative counters. If `bytes_received` is 1,000,000 in one snapshot, that does not mean the link is currently receiving 1,000,000 bytes per second.

To estimate a rate, take two snapshots and calculate:

`rate_bytes_per_second = (counter_2 - counter_1) / elapsed_seconds`

You must handle counter resets, interface disappearance and elapsed time carefully. This project intentionally starts with a single snapshot.

## Exercises

1. Add a test that writes a JSON report and reads it back.
2. Inspect how interface names and fields differ between your Windows host and a Linux VM.
3. Explain why missing speed information should not be shown as `0 Mbps` without qualification.
4. **Extension:** implement a two-snapshot byte-rate estimate, including protection against zero or negative elapsed time and counter resets.
5. **Extension:** output CSV rows as well as JSON, but avoid producing multiple incompatible formats with undocumented field names.

## Workplace context

Interface counters can help investigate drops/errors and traffic trends, but interpretation depends on the device, driver and counter definitions. A local OS snapshot is not a switch-port error report. For switches, use an approved management mechanism and the device's documentation.

## Definition of done

- [ ] Program reports local interfaces on your OS.
- [ ] JSON is valid and fields missing on the OS are handled.
- [ ] You can explain why a counter is not a rate.
- [ ] Tests and Ruff checks pass.
