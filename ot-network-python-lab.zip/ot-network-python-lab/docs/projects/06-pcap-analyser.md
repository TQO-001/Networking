# Project 6 — Offline Packet Capture Analyser

**Level:** Intermediate · **Dependency:** Scapy · **Main concept:** read protocol layers from a saved capture without capturing live traffic.

## What you're building

A program that reads an existing PCAP/PCAPNG file and counts packets, IPv4/IPv6 packets, TCP/UDP/ICMP packets and the most common source addresses. It reports aggregate counts rather than dumping packet payloads.

## Step 1 — Install and run

```bash
uv sync
uv run python -m pcap_analyzer.cli --help
uv run pytest
```

You need an existing capture file for the integration example. Use a capture you made in a permitted lab or one your course/workplace explicitly permits you to analyse. Copy it to a local path that is excluded from Git, then run:

```bash
uv run python -m pcap_analyzer.cli path/to/approved-capture.pcapng --top 10 --output summary.json
```

Replace the example path with the actual local file path. No capture is bundled because captures can contain sensitive payloads and identifiers.

## Step 2 — Inspect packet layers

Scapy represents packets as collections of decoded protocol layers. `IP in packet` checks whether an IPv4 layer exists; `TCP in packet` checks for TCP. A packet can contain multiple layers, so counts such as IPv4 and TCP are overlapping categories and should not be added together as if they were mutually exclusive.

`PcapReader` streams packets from disk. The reader is closed in a `finally` block to release the file handle even if analysis fails.

## What this tool does not do

- It does not capture live traffic.
- It does not decrypt encrypted payloads.
- It cannot see packets that were not present in the capture.
- “Top source” means source addresses appearing most often in captured packets; it does not automatically identify a compromised host or a traffic volume in bytes.

## Exercises

1. Explain why one TCP/IPv4 packet contributes to both the IPv4 and TCP counts.
2. Write a test for `top_source_addresses` sorting.
3. Extend the summary with TCP source/destination port counts while avoiding storing full payloads.
4. Add total captured bytes if you can do so using a correctly documented length field.
5. **Extension:** compare a small local capture with Wireshark and explain why the counts should match or how snap length / capture filters may affect them.

## Safety and workplace context

Capture content can include credentials, session tokens or process information even when you do not expect it. Follow authorisation, data handling and retention policy. For OT traffic, prefer a controlled mirror/TAP workflow approved by the network owner; don't start a live capture on a production interface as a learning experiment.

## Definition of done

- [ ] Automated tests run without requiring a real PCAP.
- [ ] You can analyse an authorised saved capture.
- [ ] The report distinguishes overlapping protocol-layer counts.
- [ ] Raw packet payloads are not printed or stored by default.
