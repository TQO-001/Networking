# Project 1 — IPv4 Subnet Calculator

**Level:** Beginner · **Dependencies:** Python standard library only · **Main concept:** turn a real networking calculation into a well-tested function.

## What you're building

A command-line tool that normalises an IPv4 CIDR network and prints its network address, prefix length, subnet mask, broadcast address, total address count, usable-host count and conventional first/last usable addresses. It can also check whether another IPv4 address belongs to that subnet.

This is useful for reviewing subnet plans, but it should not replace a verified IP address management tool in production.

## Concepts to learn first

- A CIDR prefix such as `/24` represents how many leading bits identify the network.
- `ipaddress.ip_network(value, strict=False)` accepts an address with host bits set and calculates the containing network.
- A usual IPv4 subnet of size 256 has 254 conventional usable host addresses. `/31` point-to-point networks and `/32` host routes are special cases.
- A function returns data; a CLI decides how that data is displayed.

## Step 1 — Run it before reading the code

From this project directory:

```bash
uv sync
uv run python -m subnet_calculator.cli 192.168.10.25/24 --check-ip 192.168.10.50
uv run pytest
```

Inspect each printed field and explain it in your own words. Then run:

```bash
uv run python -m subnet_calculator.cli 192.168.10.25/24 --check-ip 192.168.11.50
uv run python -m subnet_calculator.cli not-an-ip/24
```

The first check should report that the candidate is outside the subnet. Invalid input should produce a readable error and a non-zero exit code, not a Python traceback.

## Step 2 — Trace the code

Open `src/subnet_calculator/calculator.py`.

1. Find `summarize_network` and identify its input (`cidr`) and returned value (`NetworkSummary`).
2. Follow the call to `ip_network` and read the standard-library documentation for that function.
3. Explain why the code checks `isinstance(network, IPv4Network)`.
4. Examine how `/31` and `/32` differ from a typical subnet.
5. Open `src/subnet_calculator/cli.py`. Notice that parsing arguments and printing output happen outside the reusable calculation function.

The dataclass gives a named shape to the result. A dataclass is simply a convenient way to define a small class for structured data; you will see more complex classes later in your learning.

## Step 3 — Read the tests

Open `tests/test_calculator.py` and match each assertion to a requirement. Tests check `/24`, `/31`, membership and invalid/unsupported inputs. Run a focused test with:

```bash
uv run pytest tests/test_calculator.py -q
```

## Exercises (try before changing the starter code)

1. Calculate the expected values for `10.10.4.17/27` by hand. Run the program and compare.
2. Add a test for a `/30` and explain why only two conventional usable host addresses remain.
3. Add a test where the candidate address is invalid.
4. Improve the output labels so the special `/31` behaviour is clearly documented.
5. **Extension:** add IPv6 support. Do not copy IPv4 broadcast logic directly; IPv6 networks do not use an IPv4-style broadcast address. Design a clear output model for IPv6 first.

## Workplace practice

- Keep calculations deterministic and unit-testable.
- Treat the user's string as untrusted input and handle exceptions at the CLI boundary.
- Update README examples when output changes.
- Commit with a message such as `Add subnet boundary tests`.

## Definition of done

- [ ] You can explain every field in the report.
- [ ] Normal, boundary and invalid inputs are tested.
- [ ] `uv run pytest`, `uv run ruff check .` and `uv run ruff format --check .` pass.
- [ ] The README has a command that another person can copy and run.
