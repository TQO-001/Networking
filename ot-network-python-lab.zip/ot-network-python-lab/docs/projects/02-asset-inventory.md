# Project 2 — OT Asset Inventory Checker

**Level:** Beginner · **Dependencies:** Python standard library only · **Main concept:** read tabular data, validate it and report actionable errors.

## What you're building

A validator for a CSV containing `device_name`, `ip_address` and `vlan` columns. It reports empty device names, malformed addresses, duplicated IPs and VLAN IDs outside the configured range. It checks data; it does not discover devices on a network.

The sample file uses documentation-only addresses from `192.0.2.0/24`, not a live asset list.

## Step 1 — Inspect and run the sample

```bash
uv sync
uv run python -m asset_inventory.cli sample-data/inventory.csv
uv run pytest
```

Open `sample-data/inventory.csv` in VS Code. The first line is the header. The next lines are fictional devices.

To see the error reporting, create a copy named `sample-data/inventory-bad.csv`, then change a VLAN to `4095` and repeat an IP address. Run:

```bash
uv run python -m asset_inventory.cli sample-data/inventory-bad.csv
```

Keep the original valid sample so you have a repeatable baseline.

## Step 2 — Understand the validator

Open `src/asset_inventory/validator.py`.

- `REQUIRED_COLUMNS` defines the minimum CSV schema.
- `validate_inventory` reads the file and checks the column names before validating rows.
- `csv.DictReader` turns each row into a dictionary keyed by column name.
- `validate_rows` checks individual fields and keeps a dictionary of previously seen IP addresses to find duplicates.
- The `line_number` starts at 2 because line 1 contains the CSV header.

`ip_address()` verifies that the value is a syntactically valid IPv4 or IPv6 address. It does **not** prove that the device is reachable, belongs on the correct VLAN or is approved to communicate with another device.

## Step 3 — Follow the command-line boundary

`cli.py` takes a file path, invokes the validator and chooses an exit code:

- `0`: no data issues were found.
- `1`: inventory data failed validation.
- `2`: the file could not be read or parsed at the boundary.

Exit codes are useful in scheduled jobs and CI pipelines because other tools can tell success from failure without reading every line of output.

## Exercises

1. Test an empty CSV and describe the result. Add a clear message if the current result is ambiguous.
2. Test a missing required column.
3. Test a hostname accidentally pasted into the IP column.
4. Decide whether duplicate *device names* should also be an error. Write a test before implementing that rule.
5. **Extension:** add a `site` column and group issue counts by site. Keep the program's policy rules explicit rather than hiding them in magic numbers.

## Workplace context

Real OT inventories may include criticality, vendor/model, firmware, location, owner, zone/conduit, last-seen timestamp and change-ticket references. The exact schema is an organisational decision. This project intentionally validates only a tiny subset. Do not publish real inventory files or screenshots in a public repository.

## Definition of done

- [ ] You can explain why CSV values must be converted/validated.
- [ ] Missing columns, invalid IPs, duplicate IPs and bad VLANs are tested.
- [ ] Error messages identify the row and field without disclosing unrelated data.
- [ ] Quality checks pass and the README documents the CSV schema.
