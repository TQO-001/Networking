# Project 5 — Network Log Analyser

**Level:** Intermediate · **Dependencies:** Python standard library · **Main concept:** recognise patterns and report counts without copying entire logs into an output.

## What you're building

A local text-file analyser that counts recognised severity words and records line numbers containing several common authentication-failure phrases. The report includes counts and line numbers but not full log message contents.

This is a learning heuristic, not a standards-compliant parser for every syslog, Windows Event Log or vendor-specific format.

## Step 1 — Run the sample

```bash
uv sync
uv run python -m network_log_analyzer.cli sample-data/example.log --output summary.json
uv run pytest
```

Inspect the JSON report. Compare its counts to the lines in the sample file.

## Step 2 — Understand the patterns

- `re.compile` creates a regular expression once so it can be reused.
- `\b` means a word boundary.
- `re.IGNORECASE` allows the pattern to match different letter cases.
- The severity normalisation map treats aliases such as `WARN` and `WARNING` as one category.
- `Counter` conveniently counts repeated categories.
- The analyser returns line numbers for suspicious matches, rather than copying raw messages into the report.

A regex only finds the phrases you taught it. A different vendor may use different fields or messages. A matching phrase is not proof of malicious activity; review surrounding evidence according to your incident-handling process.

## Step 3 — Be careful with sensitive data

Logs can contain usernames, device identifiers, internal addresses, tokens or other sensitive data. Run on files you are authorised to analyse, store summaries in an approved location, and never commit real workplace logs to a public repository.

## Exercises

1. Add `LINK DOWN` and `INTERFACE DOWN` patterns and report their counts.
2. Test lowercase and uppercase severity labels.
3. Write a test for an empty file.
4. Add a source-file field to the report without including raw message content.
5. **Extension:** add support for a documented JSON log format. Validate each required key before using it.

## Workplace context

In production, prefer structured logs or vendor-supported exports when available. Time zones, multiline entries and field formats matter. Avoid simplistic pattern matches that create huge numbers of false positives, and never change the original evidence file during analysis.

## Definition of done

- [ ] Valid sample produces expected counts.
- [ ] Empty/unknown severity lines are handled.
- [ ] Report omits raw log lines by default.
- [ ] Regex limitations and privacy precautions are documented.
