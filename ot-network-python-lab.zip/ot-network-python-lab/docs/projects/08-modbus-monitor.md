# Project 8 — Modbus TCP Lab Monitor

**Level:** Intermediate · **Dependency:** PyModbus · **Main concept:** connect to a Modbus TCP simulator and read a documented range of registers.

## What you're building

A small client that connects to a specified Modbus TCP host and port, reads holding registers, prints their values, and optionally records timestamped CSV rows. It never writes registers.

The default host is `127.0.0.1` and the default port is `502`, so the starter does not silently select a remote plant address. You still need a Modbus simulator or local lab service to be listening there.

## Step 1 — Understand addressing before running it

Modbus register address notation is inconsistent across device documentation. PyModbus uses zero-based addresses. A manual may refer to a holding register as `40001` while a client call uses address `0`; check the device's register map and the simulator documentation before choosing an address. Do not try random addresses on production equipment.

A Modbus/TCP connection uses an IP/host and TCP port. A unit/device ID is also included for routing or compatibility with the target server. These values come from the lab configuration, not guesswork.

## Step 2 — Run tests and inspect help

```bash
uv sync
uv run pytest
uv run python -m modbus_monitor.cli --help
```

The automated tests focus on input validation, so they do not need a running simulator.

## Step 3 — Read from a simulator

Once an approved simulator is running and you've confirmed its register map:

```bash
uv run python -m modbus_monitor.cli --host 127.0.0.1 --port 502 --device-id 1 --address 0 --count 2 --poll-count 3 --interval 5 --output modbus-readings.csv
```

Change host, port, device ID and register range to match your **local simulator** if its configuration differs. This client only performs `read_holding_registers`. No register/coil write command exists in the starter project.

## Step 4 — Read the implementation

- `validate_register_range` catches invalid address/count values before making a request.
- `ModbusTcpClient` creates the TCP client.
- `connect()` can fail; it should not be treated as proof the device is offline in every broader sense.
- `response.isError()` separates a protocol error response from a successful read.
- `client.close()` runs in `finally` so the connection is cleaned up after success or failure.

Register values are raw 16-bit integers. The meaning and scaling are defined by the device's register map. Do not assume that value `250` means 25.0 degrees unless the device documentation says it uses that scale.

## Exercises

1. Add a test for address `65535` with count `1` and for an invalid range that crosses the maximum address.
2. Explain why a holding register reading may expose a setpoint or configuration value even though your client never writes it.
3. Add a command-line option for the timeout after checking PyModbus's current API.
4. **Extension:** read input registers using a documented simulator register map and describe how that function differs from holding-register reads.
5. **Extension:** decode a two-register numeric value only after you know the server's word/byte order and scale. Add tests using known example values.

## OT safety boundary

Never poll a live PLC or field device without authorisation and an approved test plan. Even read-only traffic can consume resources or trigger monitoring/communications policies. Use a simulator first, keep polling finite and slow, and do not add write operations as a casual extension.

## Definition of done

- [ ] Validation rejects invalid address ranges.
- [ ] Client handles connection and protocol errors.
- [ ] Lab reads are timestamped and can be logged to CSV.
- [ ] The code contains no write calls and documents register addressing assumptions.
