# Project 3 — Network Reachability Monitor

**Level:** Beginner to intermediate · **Dependencies:** Python standard library · **Main concept:** call a local OS utility safely and turn each check into a record.

## What you're building

A small wrapper around the operating system's `ping` command. It accepts explicit hostnames/IP addresses, runs one attempt per target per round, prints a UTC timestamp and records optional CSV results.

The reported `command_duration_ms` measures how long the ping process took, including process startup. It is **not** the same as the network round-trip time reported inside ping output.

## Step 1 — Run a safe local test

```bash
uv sync
uv run python -m reachability_monitor.cli 127.0.0.1 --count 2 --interval 2 --output reachability.csv
uv run pytest
```

`127.0.0.1` is the loopback address for the same computer. Review the generated `reachability.csv` locally; it should not be committed unless deliberately sanitised and needed as a fixture.

## Step 2 — Understand subprocesses

Open `src/reachability_monitor/monitor.py`.

- `build_ping_command` selects flags appropriate to Windows or common Unix-like systems.
- It returns a list of arguments and never uses `shell=True`. Keeping arguments separate avoids shell interpretation of user-provided text.
- `subprocess.run` executes the local `ping` program and enforces a timeout.
- A return code of zero is interpreted as a successful ping command; a non-zero return is treated as no successful reply.
- The result includes a UTC timestamp, target, boolean status, process duration and a short detail field.

The flags differ across OSes, and not every implementation of `ping` supports exactly the same options. This starter handles Windows and common Linux/macOS variants; extend and test other environments deliberately.

## Step 3 — Understand the limitations

A ping check is an ICMP reachability signal—not a complete health check. The target may be alive while ICMP is blocked; an interface may respond while an application is down. ICMP filtering may also cause false “DOWN” signals. Use a more specific approved application health check where necessary.

Repeated checks generate traffic. Keep the count finite, avoid tight loops, and obtain approval before checking a workplace device. Do not substitute an entire production subnet for the explicit target list.

## Exercises

1. Change `--count` to 1 and then 3. Explain how many check records should be produced for two targets.
2. Add a test for the macOS command branch.
3. Add a `--timeout` option and validate it as positive. Ensure it reaches `check_target`.
4. Adjust the program to keep a count of consecutive failed checks per target.
5. **Extension:** add a TCP connection check for one known service in a lab. Document why a successful TCP connection means something different from a successful ICMP echo.

## Workplace practice

- Report failure mode rather than declaring “device is broken.”
- Keep sampling interval and number of attempts explicit.
- Make CSV output stable and documented.
- Test command construction without requiring a real network in unit tests.

## Definition of done

- [ ] Localhost test works where `ping` is available.
- [ ] Windows/Linux command selection has tests.
- [ ] The program has a finite poll count and timeout.
- [ ] You can describe at least three reasons a failed ping might not mean the host is down.
