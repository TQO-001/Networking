# Project 7 — OPC UA Monitoring Client

**Level:** Intermediate · **Dependency:** `asyncua` · **Main concept:** connect to an OPC UA server and read selected nodes repeatedly.

This project connects naturally to a local Node-RED OPC UA lab. The default endpoint is set to `opc.tcp://127.0.0.1:53880/UA/SimpleNodeRedServer`, matching the previously discussed local lab setup. Confirm the actual endpoint in your own server configuration before running it. If the server is on another VM, use the approved lab address and network arrangement instead of assuming `127.0.0.1` refers to that VM.

## Step 1 — Find real NodeIds

Start your OPC UA server and connect UaExpert to it using the server's configured endpoint and security settings. Browse its address space and identify the exact NodeIds of the variables you want to read. Do not guess a NodeId from the variable's display name: namespace indexes and identifier types matter.

## Step 2 — Run the read-only client

From this project's directory:

```bash
uv sync
uv run pytest
uv run python -m opcua_monitor.cli --help
```

Then provide an actual NodeId from your lab, for example if UaExpert shows a string NodeId:

```bash
uv run python -m opcua_monitor.cli --node-id "ns=2;s=YOUR_OBSERVED_NODE_ID" --count 3 --interval 5 --output opcua-readings.csv
```

Replace the entire example NodeId with the exact identifier displayed by UaExpert; it is not a guaranteed NodeId in your server. For additional nodes, repeat `--node-id`.

## Step 3 — Understand asynchronous code

`asyncua.Client` is used as an asynchronous context manager, which connects and disconnects the session. `await node.read_value()` yields control while waiting for the response. `asyncio.run` in the CLI starts the event loop. You do not need to master every detail of asynchronous programming immediately; understand what the code is waiting for and where failures are caught.

The program reads selected values only. It does not write variables or invoke methods on the server. Keep the number of nodes and poll rate small while learning.

## Troubleshooting

- **Connection refused / timeout:** verify the server is running, endpoint path and port match, and the lab's firewall/routing permits the connection.
- **Bad NodeId / node not found:** copy the full NodeId from UaExpert; confirm namespace index after reconnecting.
- **Security or authentication error:** configure the client to match the lab server's intended security/authentication policy. Do not weaken production server security just to make a demo work.
- **Values don't change:** confirm that the OPC UA server node is actually connected to changing data and that UaExpert shows the expected value.

## Exercises

1. Add a test for CSV header handling and `serialise_value`.
2. Poll two nodes and explain the output order.
3. Add a `--timeout` option only after reading how asyncua handles connection/timeouts in the installed version.
4. **Extension:** add basic data-type and status-quality checks, preserving the distinction between a value of zero and a failed read.

## Workplace context

OPC UA communicates structured industrial information, but an application must still understand its server's address space, data types, timestamp semantics and quality/status. Read-only access is a sensible learning boundary, not a complete security design. Follow the server's approved certificates, endpoint security and access-control policy.

## Definition of done

- [ ] Can find actual NodeIds through UaExpert.
- [ ] Client reads a lab value and emits a timestamped CSV row.
- [ ] A failed node read is reported distinctly from a valid null/zero value.
- [ ] No write calls are implemented.
