# Files and data: CSV, JSON and paths

Networking tools often read inventories, parse exported logs and write reports. File handling is therefore a core skill.

## Paths

Use `pathlib.Path` instead of manually joining path fragments with `/` or `\\`:

```python
from pathlib import Path

report_path = Path("reports") / "inventory-report.json"
```

`pathlib` chooses appropriate path handling for the current operating system. A relative path is interpreted from the program's current working directory, not automatically from the directory containing the Python file. That distinction explains many “file not found” mistakes.

## CSV

```python
import csv
from pathlib import Path

path = Path("sample-data") / "inventory.csv"
with path.open("r", newline="", encoding="utf-8-sig") as handle:
    for row in csv.DictReader(handle):
        print(row["device_name"], row["ip_address"])
```

`DictReader` maps the header names to the values in each row. CSV values are text, so convert and validate values such as VLAN IDs explicitly. `utf-8-sig` also handles a common UTF-8 byte-order mark found in spreadsheet exports.

## JSON

```python
import json

report = {"checked_devices": 3, "offline_devices": 1}
text = json.dumps(report, indent=2)
print(text)
```

JSON is useful when another program will consume the report. CSV is convenient for tables and spreadsheets. Choose the format based on the users of the output, not because one format is always superior.

## Exercises

1. Read the supplied inventory CSV and print its device names.
2. Count the rows and explain why a header is not a device.
3. Add a fictional row, run the inventory validator and verify the change.
4. Save a small dictionary as JSON and load it again.
5. Try a nonexistent file path and write down what a useful error message should say.

Never use real workplace inventory data in a public repository. Build and test against fictional lab data first.
