# Python fundamentals for network engineers

This page is a short reference, not a substitute for writing small examples yourself. Run each snippet in a scratch file or the Python REPL.

## Variables and types

```python
hostname = "SW-LAB-01"      # str: text
vlan_id = 10                 # int: whole number
reachable = True             # bool: true/false
response_ms = 3.7            # float: decimal number
```

A variable name should explain what the value represents. `ip = "192.0.2.10"` is clearer than `x = "192.0.2.10"`.

## Lists and dictionaries

```python
interfaces = ["eth0", "lo", "ens33"]
device = {"name": "PLC-SIM-01", "ip": "192.0.2.10", "vlan": 10}
print(device["ip"])
```

Use a list for an ordered collection. Use a dictionary for values identified by keys. In the asset inventory project, each CSV row becomes a mapping of column names to text values.

## Conditions and loops

```python
if reachable:
    print("The check succeeded")
else:
    print("The check failed")

for interface in interfaces:
    print(interface)
```

Indentation defines code blocks in Python. Use four spaces per indentation level; do not mix tabs and spaces.

## Functions

```python
def is_valid_vlan(vlan_id: int) -> bool:
    return 1 <= vlan_id <= 4094
```

A function should have a clear purpose. It receives inputs (parameters), performs a unit of work and may return an output. The return type hint communicates intent but does not automatically validate the input at runtime.

## Exceptions and validation

External input can be invalid. Convert it and handle the expected error near the boundary:

```python
def parse_vlan(text: str) -> int:
    try:
        vlan_id = int(text)
    except ValueError as exc:
        raise ValueError("VLAN must be a whole number") from exc

    if not 1 <= vlan_id <= 4094:
        raise ValueError("VLAN must be between 1 and 4094")
    return vlan_id
```

Do not catch every possible exception and silently continue. Catch expected failures, provide useful context and preserve the real cause while debugging.

## Modules and imports

A module is a Python file. Put calculation logic in one module and command-line interaction in another when that separation makes testing easier. Project 1 uses `calculator.py` for the reusable calculation and `cli.py` for arguments and output.

## Exercises

1. Write `is_valid_vlan(vlan_id)` and test 1, 4094, 0 and 4095.
2. Create a dictionary for a fictional HMI with `name`, `ip` and `vlan` keys. Print each value.
3. Write a function that accepts a list of integers and returns the largest value. Decide what should happen for an empty list.
4. Explain the difference between returning `False` and raising `ValueError` for invalid input.

Do these before looking up a complete solution. Use the project test cases as examples of how to verify behaviour.
