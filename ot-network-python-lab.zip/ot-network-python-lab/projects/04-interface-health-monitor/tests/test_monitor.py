import json
from pathlib import Path

from interface_health.monitor import write_snapshot


def test_write_snapshot_produces_json(tmp_path: Path) -> None:
    output = tmp_path / "snapshot.json"
    write_snapshot(output, {"interfaces": [], "note": "test"})
    loaded = json.loads(output.read_text(encoding="utf-8"))
    assert loaded["interfaces"] == []
    assert loaded["note"] == "test"
