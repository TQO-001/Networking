import json
import socket
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def collect_snapshot() -> dict[str, Any]:
    """Collect one local interface snapshot; it does not contact remote devices."""
    import psutil

    addresses_by_interface = psutil.net_if_addrs()
    stats_by_interface = psutil.net_if_stats()
    counters_by_interface = psutil.net_io_counters(pernic=True)
    names = sorted(
        set(addresses_by_interface) | set(stats_by_interface) | set(counters_by_interface)
    )
    interfaces: list[dict[str, Any]] = []

    for name in names:
        addresses = []
        for address in addresses_by_interface.get(name, []):
            if address.family in {socket.AF_INET, socket.AF_INET6}:
                addresses.append(address.address)
        stats = stats_by_interface.get(name)
        counters = counters_by_interface.get(name)
        interfaces.append(
            {
                "name": name,
                "addresses": addresses,
                "is_up": stats.isup if stats else None,
                "speed_mbps": stats.speed if stats else None,
                "mtu": stats.mtu if stats else None,
                "bytes_sent": counters.bytes_sent if counters else None,
                "bytes_received": counters.bytes_recv if counters else None,
                "packets_sent": counters.packets_sent if counters else None,
                "packets_received": counters.packets_recv if counters else None,
                "errors_in": counters.errin if counters else None,
                "errors_out": counters.errout if counters else None,
                "drops_in": counters.dropin if counters else None,
                "drops_out": counters.dropout if counters else None,
            }
        )

    return {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "interfaces": interfaces,
        "note": "I/O counters are cumulative since boot or driver reset, not per-second rates.",
    }


def write_snapshot(path: Path, snapshot: dict[str, Any]) -> None:
    path.write_text(json.dumps(snapshot, indent=2), encoding="utf-8")
