import argparse
import json
from pathlib import Path

from interface_health.monitor import collect_snapshot, write_snapshot


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Report this computer's network interface health.")
    parser.add_argument("--output", type=Path, help="optional path for a JSON report")
    args = parser.parse_args(argv)
    try:
        snapshot = collect_snapshot()
        if args.output:
            write_snapshot(args.output, snapshot)
        print(json.dumps(snapshot, indent=2))
    except (OSError, ImportError) as exc:
        print(f"Could not collect/write interface report: {exc}")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
