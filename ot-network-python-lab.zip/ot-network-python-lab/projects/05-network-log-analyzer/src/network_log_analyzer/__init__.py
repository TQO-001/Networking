"""Network log analysis learning project."""
