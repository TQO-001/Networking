import re
from collections import Counter
from collections.abc import Iterable
from pathlib import Path
from typing import Any

SEVERITY_PATTERN = re.compile(
    r"\b(CRITICAL|FATAL|ERROR|ERR|WARNING|WARN|INFO|DEBUG)\b", re.IGNORECASE
)
AUTH_FAILURE_PATTERN = re.compile(
    r"\b(authentication failed|login failed|failed password|invalid user)\b", re.IGNORECASE
)
SEVERITY_NORMALISATION = {"FATAL": "CRITICAL", "ERR": "ERROR", "WARN": "WARNING"}


def classify_severity(line: str) -> str | None:
    """Return a recognised severity name or None when the line has no match."""
    match = SEVERITY_PATTERN.search(line)
    if not match:
        return None
    severity = match.group(1).upper()
    return SEVERITY_NORMALISATION.get(severity, severity)


def analyse_lines(lines: Iterable[str]) -> dict[str, Any]:
    """Summarise the given text lines without copying message contents into the report."""
    total_lines = 0
    severity_counts: Counter[str] = Counter()
    auth_failure_line_numbers: list[int] = []

    for line_number, line in enumerate(lines, start=1):
        total_lines += 1
        severity = classify_severity(line)
        if severity:
            severity_counts[severity] += 1
        if AUTH_FAILURE_PATTERN.search(line):
            auth_failure_line_numbers.append(line_number)

    return {
        "total_lines": total_lines,
        "severity_counts": dict(sorted(severity_counts.items())),
        "authentication_failure_count": len(auth_failure_line_numbers),
        "authentication_failure_line_numbers": auth_failure_line_numbers,
    }


def analyse_file(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        return analyse_lines(handle)
