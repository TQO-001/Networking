import argparse
import json
from pathlib import Path

from network_log_analyzer.analyzer import analyse_file


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Summarise a text log without displaying raw log messages."
    )
    parser.add_argument("log_file", type=Path, help="a text log file you are authorised to examine")
    parser.add_argument("--output", type=Path, help="optional JSON report path")
    args = parser.parse_args(argv)
    try:
        report = analyse_file(args.log_file)
        encoded = json.dumps(report, indent=2)
        if args.output:
            args.output.write_text(encoded + "\n", encoding="utf-8")
        print(encoded)
    except OSError as exc:
        print(f"Could not analyse log file: {exc}")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
