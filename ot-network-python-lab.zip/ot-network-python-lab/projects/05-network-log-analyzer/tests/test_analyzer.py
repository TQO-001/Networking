from network_log_analyzer.analyzer import analyse_lines, classify_severity


def test_severity_aliases_are_normalised() -> None:
    assert classify_severity("WARN interface changed") == "WARNING"
    assert classify_severity("FATAL service stopped") == "CRITICAL"
    assert classify_severity("ordinary message") is None


def test_analyse_lines_counts_findings_without_copying_messages() -> None:
    report = analyse_lines(
        [
            "INFO startup complete",
            "WARNING link down",
            "ERROR authentication failed for user test",
            "login failed",
        ]
    )
    assert report["total_lines"] == 4
    assert report["severity_counts"] == {"ERROR": 1, "INFO": 1, "WARNING": 1}
    assert report["authentication_failure_count"] == 2
    assert "startup complete" not in str(report)
