# Network Log Analyser

Summarise text log severity and locate lines matching common authentication-failure phrases.

## Status

Starter implementation for the OT Network Python Lab course. Read the walkthrough before extending the project. The program is intentionally conservative and does not write to industrial devices.

## Setup

Run these commands from this directory:

```bash
uv sync
uv run python -m network_log_analyzer.cli --help
uv run pytest
uv run ruff check .
uv run ruff format --check .
```

## Run an example

```bash
uv run python -m network_log_analyzer.cli sample-data/example.log --output summary.json
```


Sample files are under `sample-data/` where provided. All sample device names and addresses are fictional/documentation-only.

## Documentation

Read the detailed course walkthrough: [`Network Log Analyser lesson`](../../docs/projects/05-log-analyser.md).

## Limitations and safe use

- Use only local, isolated or explicitly approved lab targets.
- These starter tools are not certified production monitoring systems.
- Check the README and course lesson for protocol-specific assumptions, limits and known failure modes.
