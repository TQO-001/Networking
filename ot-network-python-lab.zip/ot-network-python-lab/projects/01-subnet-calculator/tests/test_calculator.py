import pytest

from subnet_calculator.calculator import address_belongs_to_network, summarize_network


def test_summarize_slash_24() -> None:
    result = summarize_network("192.168.10.25/24")
    assert result.network_address == "192.168.10.0"
    assert result.subnet_mask == "255.255.255.0"
    assert result.broadcast_address == "192.168.10.255"
    assert result.usable_host_count == 254
    assert result.first_usable_address == "192.168.10.1"
    assert result.last_usable_address == "192.168.10.254"


def test_slash_31_uses_both_addresses() -> None:
    result = summarize_network("192.0.2.10/31")
    assert result.usable_host_count == 2
    assert result.first_usable_address == "192.0.2.10"
    assert result.last_usable_address == "192.0.2.11"


def test_candidate_membership() -> None:
    assert address_belongs_to_network("192.168.1.0/24", "192.168.1.88")
    assert not address_belongs_to_network("192.168.1.0/24", "192.168.2.88")


@pytest.mark.parametrize("cidr", ["not-an-ip", "192.168.1.1/99", "2001:db8::/64"])
def test_invalid_or_unsupported_network(cidr: str) -> None:
    with pytest.raises(ValueError):
        summarize_network(cidr)
