import argparse

from subnet_calculator.calculator import address_belongs_to_network, summarize_network


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Summarise an IPv4 subnet.")
    parser.add_argument("cidr", help="IPv4 address/prefix, e.g. 192.168.10.25/24")
    parser.add_argument("--check-ip", help="also check whether this IPv4 address is in the subnet")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        summary = summarize_network(args.cidr)
        for key, value in summary.__dict__.items():
            print(f"{key.replace('_', ' ').title()}: {value}")
        if args.check_ip:
            belongs = address_belongs_to_network(args.cidr, args.check_ip)
            print(f"{args.check_ip} belongs to network: {'yes' if belongs else 'no'}")
    except ValueError as exc:
        print(f"Input error: {exc}")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
