from dataclasses import dataclass
from ipaddress import IPv4Network, ip_address, ip_network


@dataclass(frozen=True)
class NetworkSummary:
    """A concise summary of an IPv4 network."""

    network_address: str
    prefix_length: int
    subnet_mask: str
    broadcast_address: str
    total_addresses: int
    usable_host_count: int
    first_usable_address: str
    last_usable_address: str


def summarize_network(cidr: str) -> NetworkSummary:
    """Summarise an IPv4 CIDR network; host bits in `cidr` are normalised."""
    network = ip_network(cidr, strict=False)
    if not isinstance(network, IPv4Network):
        raise ValueError("This starter project supports IPv4 only.")

    # RFC 3021 point-to-point /31 networks use both addresses; /32 is one host.
    if network.prefixlen >= 31:
        first = network.network_address
        last = network.broadcast_address
        usable = network.num_addresses
    else:
        first = network.network_address + 1
        last = network.broadcast_address - 1
        usable = network.num_addresses - 2

    return NetworkSummary(
        network_address=str(network.network_address),
        prefix_length=network.prefixlen,
        subnet_mask=str(network.netmask),
        broadcast_address=str(network.broadcast_address),
        total_addresses=network.num_addresses,
        usable_host_count=usable,
        first_usable_address=str(first),
        last_usable_address=str(last),
    )


def address_belongs_to_network(cidr: str, candidate: str) -> bool:
    """Return whether a valid IP address belongs to an IPv4 network."""
    network = ip_network(cidr, strict=False)
    address = ip_address(candidate)
    if not isinstance(network, IPv4Network) or address.version != 4:
        raise ValueError("Both the network and candidate must be IPv4.")
    return address in network
