"""IPv4 subnet calculator learning project."""
