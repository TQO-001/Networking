import pytest

from modbus_monitor.client import validate_register_range


def test_valid_register_range() -> None:
    validate_register_range(0, 10)
    validate_register_range(65535, 1)


@pytest.mark.parametrize(
    ("address", "count"),
    [(-1, 1), (0, 0), (0, 126), (65535, 2), (65536, 1)],
)
def test_invalid_register_range(address: int, count: int) -> None:
    with pytest.raises(ValueError):
        validate_register_range(address, count)
