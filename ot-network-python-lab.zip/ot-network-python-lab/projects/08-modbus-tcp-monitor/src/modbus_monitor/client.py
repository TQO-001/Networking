import csv
import time
from datetime import datetime, timezone
from pathlib import Path


def validate_register_range(address: int, count: int) -> None:
    """Validate a 0-based 16-bit register address range before making a request."""
    if not 0 <= address <= 65535:
        raise ValueError("address must be between 0 and 65535")
    if not 1 <= count <= 125:
        raise ValueError("count must be between 1 and 125 registers")
    if address + count > 65536:
        raise ValueError("address + count exceeds the 16-bit address space")


def append_csv(path: Path, timestamp: str, device_id: int, address: int, values: list[int]) -> None:
    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["timestamp_utc", "device_id", "register_address", "value"],
        )
        if not exists:
            writer.writeheader()
        for offset, value in enumerate(values):
            writer.writerow(
                {
                    "timestamp_utc": timestamp,
                    "device_id": device_id,
                    "register_address": address + offset,
                    "value": value,
                }
            )


def poll_registers(
    host: str,
    port: int,
    address: int,
    count: int,
    device_id: int,
    poll_count: int = 1,
    interval_seconds: float = 5.0,
    output: Path | None = None,
) -> int:
    """Read holding registers; this function contains no write operations."""
    validate_register_range(address, count)
    if not host.strip():
        raise ValueError("host must not be empty")
    if not 1 <= port <= 65535:
        raise ValueError("port must be between 1 and 65535")
    if not 1 <= device_id <= 247:
        raise ValueError("device_id must be between 1 and 247")
    if poll_count < 1:
        raise ValueError("poll_count must be at least 1")
    if interval_seconds < 0:
        raise ValueError("interval_seconds cannot be negative")

    try:
        from pymodbus.client import ModbusTcpClient
    except ImportError as exc:
        raise RuntimeError("PyModbus is not installed; run `uv sync` in this project.") from exc

    client = ModbusTcpClient(host, port=port, timeout=3)
    failures = 0
    try:
        if not client.connect():
            raise ConnectionError(f"Could not connect to Modbus TCP endpoint {host}:{port}")
        for poll_number in range(poll_count):
            timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
            response = client.read_holding_registers(
                address=address,
                count=count,
                device_id=device_id,
            )
            if response.isError():
                failures += 1
                print(f"{timestamp} | Modbus read error | {response}")
            else:
                values = list(response.registers)
                print(f"{timestamp} | unit {device_id} | address {address} | registers {values}")
                if output:
                    append_csv(output, timestamp, device_id, address, values)
            if poll_number + 1 < poll_count and interval_seconds:
                time.sleep(interval_seconds)
    finally:
        client.close()
    return 1 if failures else 0
