"""Read-only Modbus TCP lab monitor learning project."""
