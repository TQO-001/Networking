import argparse
from pathlib import Path

from modbus_monitor.client import poll_registers


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Read holding registers from a Modbus TCP lab endpoint."
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="lab simulator IP/hostname; default is localhost",
    )
    parser.add_argument("--port", type=int, default=502)
    parser.add_argument("--address", type=int, default=0, help="0-based starting register address")
    parser.add_argument("--count", type=int, default=1, help="number of registers to read (1-125)")
    parser.add_argument("--device-id", type=int, default=1, help="Modbus unit/device ID")
    parser.add_argument(
        "--poll-count", type=int, default=1, help="number of read rounds; finite count only"
    )
    parser.add_argument("--interval", type=float, default=5.0, help="seconds between read rounds")
    parser.add_argument("--output", type=Path, help="optional CSV output file")
    args = parser.parse_args(argv)
    try:
        return poll_registers(
            args.host,
            args.port,
            args.address,
            args.count,
            args.device_id,
            args.poll_count,
            args.interval,
            args.output,
        )
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"Modbus monitor error: {exc}")
        return 2
    except Exception as exc:
        print(f"Modbus library/server error ({type(exc).__name__}): {exc}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
