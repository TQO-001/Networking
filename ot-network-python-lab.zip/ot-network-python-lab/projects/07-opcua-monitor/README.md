# OPC UA Monitoring Client

Read selected NodeIds from an explicitly configured OPC UA lab server.

## Status

Starter implementation for the OT Network Python Lab course. Read the walkthrough before extending the project. The program is intentionally conservative and does not write to industrial devices.

## Setup

Run these commands from this directory:

```bash
uv sync
uv run python -m opcua_monitor.cli --help
uv run pytest
uv run ruff check .
uv run ruff format --check .
```

## Run an example

```bash
uv run python -m opcua_monitor.cli --node-id "ns=2;s=ReplaceWithYourActualNodeId" --count 3 --interval 5 --output opcua-readings.csv
```

Replace the NodeId marker with the exact identifier observed in UaExpert on your lab server. The endpoint defaults to the local Node-RED OPC UA lab address previously discussed; verify the server configuration before running it. Do not guess node identifiers.


No real device addresses or packet captures are bundled with this project. Use the isolated lab or an authorised, sanitised sample.

## Documentation

Read the detailed course walkthrough: [`OPC UA Monitoring Client lesson`](../../docs/projects/07-opcua-monitor.md).

## Limitations and safe use

- Use only local, isolated or explicitly approved lab targets.
- These starter tools are not certified production monitoring systems.
- Check the README and course lesson for protocol-specific assumptions, limits and known failure modes.
