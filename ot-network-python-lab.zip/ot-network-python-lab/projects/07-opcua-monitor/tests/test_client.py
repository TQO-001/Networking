import json
from pathlib import Path

from opcua_monitor.client import append_csv, serialise_value


def test_serialise_value_for_csv() -> None:
    assert serialise_value(25.7) == "25.7"
    assert json.loads(serialise_value({"valid": True})) == {"valid": True}


def test_append_csv_writes_header_once(tmp_path: Path) -> None:
    path = tmp_path / "readings.csv"
    record = {
        "timestamp_utc": "2026-01-01T00:00:00+00:00",
        "endpoint": "opc.tcp://127.0.0.1:4840/example",
        "node_id": "i=2258",
        "status": "OK",
        "value_or_error": "25.7",
    }
    append_csv(path, record)
    append_csv(path, record)
    text = path.read_text(encoding="utf-8")
    assert text.count("timestamp_utc") == 1
    assert text.count("25.7") == 2
