import argparse
import asyncio
from pathlib import Path

from opcua_monitor.client import monitor_nodes

DEFAULT_ENDPOINT = "opc.tcp://127.0.0.1:53880/UA/SimpleNodeRedServer"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Read NodeIds from an OPC UA lab server.")
    parser.add_argument("--endpoint", default=DEFAULT_ENDPOINT, help="approved lab server endpoint")
    parser.add_argument(
        "--node-id",
        action="append",
        required=True,
        help="NodeId to read; repeat this option for multiple nodes",
    )
    parser.add_argument("--count", type=int, default=1, help="number of polls; finite count only")
    parser.add_argument("--interval", type=float, default=5.0, help="seconds between polls")
    parser.add_argument("--output", type=Path, help="optional CSV output file")
    args = parser.parse_args(argv)
    if args.count < 1:
        parser.error("--count must be at least 1")
    if args.interval < 0:
        parser.error("--interval cannot be negative")
    try:
        return asyncio.run(
            monitor_nodes(args.endpoint, args.node_id, args.count, args.interval, args.output)
        )
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"OPC UA monitor error: {exc}")
        return 2
    except Exception as exc:
        print(f"OPC UA library/server error ({type(exc).__name__}): {exc}")
        return 2
    except KeyboardInterrupt:
        print("Stopped by user.")
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
