import asyncio
import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def utc_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def serialise_value(value: Any) -> str:
    """Render a scalar or structured value into a readable CSV-friendly string."""
    try:
        return json.dumps(value, ensure_ascii=False, default=str)
    except (TypeError, ValueError):
        return str(value)


def append_csv(path: Path, record: dict[str, str]) -> None:
    exists = path.exists()
    columns = ["timestamp_utc", "endpoint", "node_id", "status", "value_or_error"]
    with path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        if not exists:
            writer.writeheader()
        writer.writerow(record)


async def monitor_nodes(
    endpoint: str,
    node_ids: list[str],
    poll_count: int = 1,
    interval_seconds: float = 5.0,
    output: Path | None = None,
) -> int:
    """Poll configured NodeIds. This client reads values; it never writes them."""
    if poll_count < 1:
        raise ValueError("poll_count must be at least 1")
    if interval_seconds < 0:
        raise ValueError("interval_seconds cannot be negative")
    if not node_ids:
        raise ValueError("At least one NodeId is required")

    try:
        from asyncua import Client
    except ImportError as exc:
        raise RuntimeError("asyncua is not installed; run `uv sync` in this project.") from exc

    failures = 0
    async with Client(url=endpoint) as client:
        nodes = [(node_id, client.get_node(node_id)) for node_id in node_ids]
        for poll_number in range(poll_count):
            for node_id, node in nodes:
                timestamp = utc_timestamp()
                try:
                    value = await node.read_value()
                except Exception as exc:  # Report a failed read without hiding which NodeId failed.
                    failures += 1
                    status = "ERROR"
                    value_text = f"{type(exc).__name__}: {exc}"
                else:
                    status = "OK"
                    value_text = serialise_value(value)
                record = {
                    "timestamp_utc": timestamp,
                    "endpoint": endpoint,
                    "node_id": node_id,
                    "status": status,
                    "value_or_error": value_text,
                }
                print(f"{timestamp} | {node_id} | {status} | {value_text}")
                if output:
                    append_csv(output, record)
            if poll_number + 1 < poll_count and interval_seconds:
                await asyncio.sleep(interval_seconds)
    return 1 if failures else 0
