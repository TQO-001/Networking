"""Read-only OPC UA monitoring learning project."""
