# Offline Packet Capture Analyser

Analyse an existing PCAP or PCAPNG file without capturing live traffic.

## Status

Starter implementation for the OT Network Python Lab course. Read the walkthrough before extending the project. The program is intentionally conservative and does not write to industrial devices.

## Setup

Run these commands from this directory:

```bash
uv sync
uv run python -m pcap_analyzer.cli --help
uv run pytest
uv run ruff check .
uv run ruff format --check .
```

## Run an example

```bash
uv run python -m pcap_analyzer.cli path/to/approved-capture.pcapng --output summary.json
```


No real device addresses or packet captures are bundled with this project. Use the isolated lab or an authorised, sanitised sample.

## Documentation

Read the detailed course walkthrough: [`Offline Packet Capture Analyser lesson`](../../docs/projects/06-pcap-analyser.md).

## Limitations and safe use

- Use only local, isolated or explicitly approved lab targets.
- These starter tools are not certified production monitoring systems.
- Check the README and course lesson for protocol-specific assumptions, limits and known failure modes.
