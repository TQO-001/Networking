from collections import Counter
from pathlib import Path
from typing import Any


def top_source_addresses(counts: Counter[str], limit: int = 5) -> list[dict[str, Any]]:
    """Return source-address counts sorted by frequency; useful as a pure unit."""
    if limit < 1:
        raise ValueError("limit must be at least 1")
    return [{"source": address, "packets": count} for address, count in counts.most_common(limit)]


def analyse_capture(path: Path, top_n: int = 5) -> dict[str, Any]:
    """Read an existing packet capture and return aggregate counts only."""
    if top_n < 1:
        raise ValueError("top_n must be at least 1")
    try:
        from scapy.all import ICMP, IP, IPv6, PcapReader, TCP, UDP
    except ImportError as exc:
        raise RuntimeError("Scapy is not installed; run `uv sync` in this project.") from exc

    packet_total = ipv4_total = ipv6_total = tcp_total = udp_total = icmp_total = 0
    source_counts: Counter[str] = Counter()
    reader = PcapReader(str(path))
    try:
        for packet in reader:
            packet_total += 1
            if IP in packet:
                ipv4_total += 1
                source_counts[packet[IP].src] += 1
            if IPv6 in packet:
                ipv6_total += 1
                source_counts[packet[IPv6].src] += 1
            if TCP in packet:
                tcp_total += 1
            if UDP in packet:
                udp_total += 1
            if ICMP in packet:
                icmp_total += 1
    finally:
        reader.close()

    return {
        "capture_file": path.name,
        "packet_count": packet_total,
        "ipv4_packets": ipv4_total,
        "ipv6_packets": ipv6_total,
        "tcp_packets": tcp_total,
        "udp_packets": udp_total,
        "icmp_packets": icmp_total,
        "top_source_addresses": top_source_addresses(source_counts, top_n),
        "note": "Counts describe only the packets present in this capture file.",
    }
