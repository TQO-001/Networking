"""Offline packet capture analysis learning project."""
