import argparse
import json
from pathlib import Path

from pcap_analyzer.analyzer import analyse_capture


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Summarise an existing PCAP/PCAPNG capture.")
    parser.add_argument("capture_file", type=Path, help="existing authorised capture file")
    parser.add_argument("--top", type=int, default=5, help="number of source addresses to show")
    parser.add_argument("--output", type=Path, help="optional JSON report path")
    args = parser.parse_args(argv)
    try:
        report = analyse_capture(args.capture_file, args.top)
        encoded = json.dumps(report, indent=2)
        if args.output:
            args.output.write_text(encoded + "\n", encoding="utf-8")
        print(encoded)
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"Could not analyse capture: {exc}")
        return 2
    except Exception as exc:
        print(f"Capture parser error ({type(exc).__name__}): {exc}")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
