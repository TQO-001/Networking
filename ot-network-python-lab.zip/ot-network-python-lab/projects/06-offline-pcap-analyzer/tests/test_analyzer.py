from collections import Counter

import pytest

from pcap_analyzer.analyzer import top_source_addresses


def test_top_source_addresses_are_sorted_by_count() -> None:
    counts = Counter({"192.0.2.1": 5, "192.0.2.2": 2, "192.0.2.3": 4})
    assert top_source_addresses(counts, 2) == [
        {"source": "192.0.2.1", "packets": 5},
        {"source": "192.0.2.3", "packets": 4},
    ]


def test_top_source_limit_must_be_positive() -> None:
    with pytest.raises(ValueError):
        top_source_addresses(Counter(), 0)
