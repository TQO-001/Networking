import argparse
from pathlib import Path

from asset_inventory.validator import validate_inventory


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate a fictional OT asset inventory CSV.")
    parser.add_argument(
        "csv_file",
        type=Path,
        help="CSV with device_name, ip_address, vlan columns",
    )
    args = parser.parse_args(argv)

    try:
        errors = validate_inventory(args.csv_file)
    except (OSError, UnicodeError) as exc:
        print(f"Could not read inventory: {exc}")
        return 2

    if errors:
        print(f"Found {len(errors)} issue(s):")
        for error in errors:
            print(f"- {error}")
        return 1

    print("Inventory validation passed: no issues found.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
