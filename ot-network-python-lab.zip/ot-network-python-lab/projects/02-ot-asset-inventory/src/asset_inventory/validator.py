import csv
from collections.abc import Iterable
from ipaddress import ip_address
from pathlib import Path

REQUIRED_COLUMNS = {"device_name", "ip_address", "vlan"}


def validate_rows(rows: Iterable[dict[str, str | None]]) -> list[str]:
    """Return validation errors for inventory rows; an empty list means valid."""
    errors: list[str] = []
    seen_ips: dict[str, int] = {}

    for line_number, row in enumerate(rows, start=2):  # CSV line 1 is the header.
        name = (row.get("device_name") or "").strip()
        ip_text = (row.get("ip_address") or "").strip()
        vlan_text = (row.get("vlan") or "").strip()

        if not name:
            errors.append(f"Line {line_number}: device_name is empty")

        try:
            parsed_ip = ip_address(ip_text)
        except ValueError:
            errors.append(f"Line {line_number}: invalid IP address {ip_text!r}")
        else:
            normalised_ip = str(parsed_ip)
            if normalised_ip in seen_ips:
                errors.append(
                    f"Line {line_number}: duplicate IP {normalised_ip} also used on "
                    f"line {seen_ips[normalised_ip]}"
                )
            else:
                seen_ips[normalised_ip] = line_number

        try:
            vlan = int(vlan_text)
        except ValueError:
            errors.append(f"Line {line_number}: VLAN must be a whole number")
        else:
            if not 1 <= vlan <= 4094:
                errors.append(f"Line {line_number}: VLAN must be between 1 and 4094")

    return errors


def validate_inventory(path: Path) -> list[str]:
    """Read and validate a CSV inventory file."""
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        columns = set(reader.fieldnames or [])
        missing = REQUIRED_COLUMNS - columns
        if missing:
            return [f"Missing required CSV column(s): {', '.join(sorted(missing))}"]
        return validate_rows(reader)
