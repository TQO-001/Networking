"""OT asset inventory validator learning project."""
