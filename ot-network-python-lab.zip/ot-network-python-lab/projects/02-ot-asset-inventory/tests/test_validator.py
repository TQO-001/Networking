from pathlib import Path

from asset_inventory.validator import validate_inventory, validate_rows


def test_valid_rows_have_no_errors() -> None:
    rows = [
        {"device_name": "PLC-SIM-01", "ip_address": "192.0.2.10", "vlan": "10"},
        {"device_name": "HMI-SIM-01", "ip_address": "192.0.2.11", "vlan": "20"},
    ]
    assert validate_rows(rows) == []


def test_duplicate_ip_empty_name_and_bad_vlan_are_reported() -> None:
    rows = [
        {"device_name": "SW-SIM-01", "ip_address": "192.0.2.10", "vlan": "10"},
        {"device_name": "", "ip_address": "192.0.2.10", "vlan": "4095"},
    ]
    errors = validate_rows(rows)
    assert any("device_name is empty" in error for error in errors)
    assert any("duplicate IP" in error for error in errors)
    assert any("between 1 and 4094" in error for error in errors)


def test_missing_required_column_is_reported(tmp_path: Path) -> None:
    path = tmp_path / "inventory.csv"
    path.write_text("device_name,ip_address\nPLC,192.0.2.1\n", encoding="utf-8")
    errors = validate_inventory(path)
    assert errors == ["Missing required CSV column(s): vlan"]
