# Network Reachability Monitor

Check explicitly supplied targets with the local ping utility and record the result.

## Status

Starter implementation for the OT Network Python Lab course. Read the walkthrough before extending the project. The program is intentionally conservative and does not write to industrial devices.

## Setup

Run these commands from this directory:

```bash
uv sync
uv run python -m reachability_monitor.cli --help
uv run pytest
uv run ruff check .
uv run ruff format --check .
```

## Run an example

```bash
uv run python -m reachability_monitor.cli 127.0.0.1 --count 2 --interval 5 --output reachability.csv
```


No real device addresses or packet captures are bundled with this project. Use the isolated lab or an authorised, sanitised sample.

## Documentation

Read the detailed course walkthrough: [`Network Reachability Monitor lesson`](../../docs/projects/03-reachability-monitor.md).

## Limitations and safe use

- Use only local, isolated or explicitly approved lab targets.
- These starter tools are not certified production monitoring systems.
- Check the README and course lesson for protocol-specific assumptions, limits and known failure modes.
