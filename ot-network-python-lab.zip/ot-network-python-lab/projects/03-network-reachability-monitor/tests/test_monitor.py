import pytest

from reachability_monitor.monitor import build_ping_command


def test_builds_windows_ping_command() -> None:
    assert build_ping_command("127.0.0.1", "Windows") == [
        "ping", "-n", "1", "-w", "1000", "127.0.0.1"
    ]


def test_builds_linux_ping_command() -> None:
    assert build_ping_command("127.0.0.1", "Linux") == [
        "ping", "-c", "1", "-W", "1", "127.0.0.1"
    ]


def test_empty_target_is_rejected() -> None:
    with pytest.raises(ValueError, match="must not be empty"):
        build_ping_command("   ", "Linux")
