import argparse
import time
from pathlib import Path

from reachability_monitor.monitor import append_csv_result, check_target


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Check reachability for approved lab targets.")
    parser.add_argument("targets", nargs="+", help="Explicit hostnames or IP addresses to check")
    parser.add_argument("--count", type=int, default=1, help="Number of rounds; use a finite count")
    parser.add_argument("--interval", type=float, default=5.0, help="Seconds between rounds")
    parser.add_argument("--output", type=Path, help="Optional CSV output file")
    args = parser.parse_args(argv)
    if args.count < 1:
        parser.error("--count must be at least 1")
    if args.interval < 0:
        parser.error("--interval cannot be negative")

    down_count = 0
    for round_number in range(args.count):
        for target in args.targets:
            result = check_target(target)
            status = "UP" if result.reachable else "DOWN/NO ICMP REPLY"
            print(
                f"{result.timestamp_utc} | {target} | {status} | "
                f"{result.command_duration_ms:.2f} ms | {result.detail}"
            )
            if not result.reachable:
                down_count += 1
            if args.output:
                try:
                    append_csv_result(args.output, result)
                except OSError as exc:
                    print(f"Could not write CSV: {exc}")
                    return 2
        if round_number + 1 < args.count and args.interval:
            time.sleep(args.interval)

    print(f"Checks completed: {args.count * len(args.targets)}; unsuccessful checks: {down_count}")
    return 1 if down_count else 0


if __name__ == "__main__":
    raise SystemExit(main())
