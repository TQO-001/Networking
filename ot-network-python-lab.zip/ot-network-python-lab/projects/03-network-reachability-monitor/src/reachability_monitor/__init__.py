"""Network reachability monitoring learning project."""
