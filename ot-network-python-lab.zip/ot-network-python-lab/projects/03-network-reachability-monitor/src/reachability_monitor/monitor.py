import platform
import subprocess
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


@dataclass(frozen=True)
class PingResult:
    timestamp_utc: str
    target: str
    reachable: bool
    command_duration_ms: float
    detail: str


def build_ping_command(target: str, system_name: str | None = None) -> list[str]:
    """Build a one-packet ping command for Windows or Unix-like systems."""
    if not target.strip():
        raise ValueError("Target must not be empty")
    system = (system_name or platform.system()).lower()
    if system == "windows":
        return ["ping", "-n", "1", "-w", "1000", target]
    if system == "linux":
        return ["ping", "-c", "1", "-W", "1", target]
    operating_system = system_name or platform.system()
    raise ValueError(f"Unsupported operating system for ping flags: {operating_system}")


def check_target(target: str, timeout_seconds: float = 3.0) -> PingResult:
    """Run a single ping attempt without a shell; elapsed time includes process overhead."""
    command = build_ping_command(target)
    started = time.perf_counter()
    detail = ""
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=False,
            timeout=timeout_seconds,
        )
        reachable = completed.returncode == 0
        detail = "ping command returned success" if reachable else "no successful ping reply"
    except subprocess.TimeoutExpired:
        reachable = False
        detail = "ping process exceeded its timeout"
    except OSError as exc:
        reachable = False
        detail = f"could not run ping: {exc.__class__.__name__}"

    elapsed_ms = (time.perf_counter() - started) * 1000
    return PingResult(
        timestamp_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        target=target,
        reachable=reachable,
        command_duration_ms=round(elapsed_ms, 2),
        detail=detail,
    )


def append_csv_result(path: Path, result: PingResult) -> None:
    import csv

    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(PingResult.__dataclass_fields__))
        if not exists:
            writer.writeheader()
        writer.writerow(result.__dict__)
