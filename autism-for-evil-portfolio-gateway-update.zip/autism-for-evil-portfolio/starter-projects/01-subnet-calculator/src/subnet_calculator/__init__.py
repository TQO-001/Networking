"""Subnet calculator learning project."""

from subnet_calculator.calculator import describe_network

__all__ = ["describe_network"]
