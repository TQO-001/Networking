"""Terminal interface for the subnet calculator."""

from subnet_calculator.calculator import describe_network


def main() -> int:
    """Prompt for a network and print its summary."""
    cidr = input("Enter a network (for example 192.168.10.25/24): ").strip()

    try:
        print(describe_network(cidr))
    except ValueError as error:
        print(f"Invalid network: {error}")
        return 1

    return 0
