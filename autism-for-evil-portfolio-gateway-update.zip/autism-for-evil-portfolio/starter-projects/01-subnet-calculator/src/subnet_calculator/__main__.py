"""Allow running the package with ``python -m subnet_calculator``."""

from subnet_calculator.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
