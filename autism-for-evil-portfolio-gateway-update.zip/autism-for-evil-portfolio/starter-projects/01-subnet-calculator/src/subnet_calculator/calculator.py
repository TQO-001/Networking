"""Network-summary logic, kept separate from terminal input/output."""

import ipaddress


def describe_network(cidr: str) -> str:
    """Return a readable summary for an IPv4 or IPv6 network.

    Args:
        cidr: An IP address with a prefix, such as ``192.168.10.25/24``.

    Returns:
        A multi-line summary of the normalised network.

    Raises:
        ValueError: If ``cidr`` is not a valid IP network expression.
    """
    network = ipaddress.ip_network(cidr.strip(), strict=False)
    lines = [
        f"Network: {network}",
        f"Network address: {network.network_address}",
        f"Prefix length: /{network.prefixlen}",
        f"Total addresses: {network.num_addresses}",
    ]

    if network.version == 4:
        lines.extend(
            [
                f"Broadcast address: {network.broadcast_address}",
                f"Subnet mask: {network.netmask}",
            ]
        )
        if network.num_addresses > 2:
            first_host = network.network_address + 1
            last_host = network.broadcast_address - 1
            lines.append(f"Traditional usable host range: {first_host} - {last_host}")
        else:
            lines.append("Traditional usable host range: special-case subnet; verify use case")
    else:
        lines.append("Broadcast address: not applicable (IPv6 has no broadcast)")
        lines.append("Usable host range: depends on your IPv6 allocation and addressing plan")

    return "\n".join(lines)
