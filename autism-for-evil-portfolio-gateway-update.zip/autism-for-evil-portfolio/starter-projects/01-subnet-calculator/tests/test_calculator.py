"""Tests for network summary calculations."""

import ipaddress

import pytest

from subnet_calculator import describe_network


def test_ipv4_slash_24_is_normalised_and_has_expected_host_range() -> None:
    summary = describe_network("192.168.10.25/24")

    assert "Network: 192.168.10.0/24" in summary
    assert "Network address: 192.168.10.0" in summary
    assert "Broadcast address: 192.168.10.255" in summary
    assert "Subnet mask: 255.255.255.0" in summary
    assert "Traditional usable host range: 192.168.10.1 - 192.168.10.254" in summary


def test_ipv4_slash_32_does_not_claim_a_traditional_host_range() -> None:
    summary = describe_network("192.168.10.25/32")

    assert "Total addresses: 1" in summary
    assert "special-case subnet" in summary


def test_ipv6_does_not_report_a_broadcast_address() -> None:
    summary = describe_network("2001:db8::1/64")

    assert "Network: 2001:db8::/64" in summary
    assert "Broadcast address: not applicable (IPv6 has no broadcast)" in summary
    assert "Broadcast address: 2001:db8::ffff:ffff:ffff:ffff" not in summary


def test_invalid_network_raises_value_error() -> None:
    with pytest.raises(ValueError):
        describe_network("not-an-ip/24")


def test_stdlib_ipaddress_parsing_behaviour_is_explicit() -> None:
    network = ipaddress.ip_network("10.4.8.9/16", strict=False)

    assert str(network) == "10.4.0.0/16"
