# Subnet Calculator

The first Python networking project from Autism For Evil. This is a learning starter, not a certified IP planning tool.

## What it does

- Accepts IPv4 or IPv6 CIDR notation.
- Normalises the input with Python's built-in `ipaddress` module.
- Displays the network address, prefix length, address count and family-appropriate details.
- Catches invalid network input in the command-line interface.
- Has automated tests for an IPv4 `/24`, IPv4 `/32`, IPv6 and invalid input.

The IPv4 usable-host line uses a traditional teaching convention. Special-purpose ranges and point-to-point conventions can differ. Check the network design requirements before using any result operationally.

## Requirements

- Python 3.14
- uv

## Run

```bash
uv sync --dev
uv run python -m subnet_calculator
```

Enter a CIDR expression such as `192.168.10.25/24` or `2001:db8::1/64`.

## Test and check style

```bash
uv run pytest
uv run ruff check .
uv run ruff format --check .
```

## Project structure

- `src/subnet_calculator/calculator.py` contains the calculation and formatting logic.
- `src/subnet_calculator/cli.py` contains the interactive terminal code.
- `src/subnet_calculator/__main__.py` provides the `python -m subnet_calculator` entry point.
- `tests/` checks behaviour independently of terminal input.

## Learning extensions

1. Add a test for an IPv6 `/64`.
2. Add a `--json` option without mixing argument parsing into the core function.
3. Add an option to check whether an IP address belongs to a supplied network.
4. Add a README example that captures both command and output.
5. Add type checks and CI after you understand the existing project.

Only use examples or target data you are authorised to use.
