# Build, publication and QA checklist

## Content / packaging checks

- [x] Added 144 curated networking Markdown pages from `Networking.zip`.
- [x] Sorted notes into topic shelves rather than preserving the original messy folder hierarchy.
- [x] Withheld personal journal and operational task folders from the initial public export.
- [x] Withheld two raw device transcripts containing real-looking identifiers/configuration material and a customer-specific project note.
- [x] Generalized employer/customer-identifying host and domain values in otherwise useful educational notes. Likely environment-specific switch-management, NTP and syslog addresses in walkthrough copies were replaced with reserved documentation values.
- [x] Replaced explicit sample credential values and a pasted type-5 secret hash with placeholders.
- [x] Removed unverified raster screenshots/photos and created 17 original SVG diagrams for the public notes.
- [x] Added About and Contact routes.
- [x] Integrated the supplied PlasmaWave React component with a purple/blue theme and reduced-quality settings for the main hero.
- [x] Added a name-only root gateway (`/`) that links to `/autism-for-evil/`.
- [x] Added `TechText`, `SideRays`, and `GhostCursor` Canvas 2D adaptations to the gateway, with reduced-motion handling and a keyboard-accessible anchor.
- [x] Added `.env.example` and documented the mailto-only contact form.
- [x] Added a list of temporary portrait placeholder sources and a warning to replace them before public launch.

## Still to verify locally before publication

- [ ] Install packages: `npm install`.
- [ ] Run the Astro check: `npm run check`.
- [ ] Build static routes: `npm run build`.
- [ ] Browse each route at desktop and mobile widths.
- [ ] Verify PlasmaWave on a WebGL2-capable device and confirm graceful fallback if WebGL2 is not available.
- [ ] Verify the gateway effects, click-through, touch behaviour, canvas fallback and performance in a real browser.
- [ ] Keyboard-test navigation, theme switch, search/filter, lesson progress and contact form.
- [ ] Confirm contrast and reduced-motion behaviour in the browser.
- [ ] Replace or license the two remote portrait placeholders.
- [ ] Configure the contact destination (or connect a real contact-form service).
- [ ] Read every public networking page before making the repository public; verify no employer/customer details or operational records remain, and check that documentation-only IPs are not copied into a real environment.
- [ ] Generate and commit `package-lock.json` after a successful install.
- [ ] Set `site` in `astro.config.mjs` when the final domain is known.

## Run locally

Requires a compatible Node 22 installation (use `.nvmrc` as the starting point):

```bash
npm install
npm run check
npm run build
npm run dev
```

The content migration and basic source checks were performed in the generation environment. The gateway route and component integration are not browser-verified yet. Package downloads timed out, so a full Astro build and actual browser-based visual/accessibility pass were not completed here. Do not mark any of the unchecked items as passed until they have genuinely been verified.

## Gateway update verification — 23 October 2026

- [x] Root `/` now renders a name-only gateway; the `Thulani Langa` link opens `/autism-for-evil/`.
- [x] Moved the full content homepage to `src/pages/autism-for-evil/index.astro` and repaired the relative imports.
- [x] Added `GhostCursor`, `TechText`, and `SideRays` canvas effects to the gateway; kept the existing `PlasmaWave` on the full site homepage.
- [x] Static source audit: 16 Astro page routes detected, 0 broken relative imports, migration manifest valid, required gateway/component routes present.
- [x] `node --check astro.config.mjs` passed.
- [x] Python subnet calculator tests passed: 5/5.
- [ ] Full Astro build remains unverified because `node_modules` is not present and the `astro` executable is unavailable in the build environment. Run `npm install`, `npm run check`, and `npm run build` locally before deployment.
- [ ] Browser test gateway click-through, mobile layout, touch cursor behavior and reduced-motion mode before publishing.
