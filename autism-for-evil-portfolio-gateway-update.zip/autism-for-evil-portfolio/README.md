# Autism For Evil — technical portfolio

A portfolio-style publication for tutorials, courses, networking notes, build logs and project write-ups. The current focus is OT networking and learning Python by building small, testable engineering tools. This is a prototype for a future personal portfolio, not a claim that every project brief is already implemented.

## Visual direction

Purple-and-blue technical editorial style. The first visit is a minimal, name-only gateway; clicking **Thulani Langa** opens the full Autism For Evil portfolio. The portfolio includes a plasma-wave hero, canvas cursor/text/rays effects, portrait placeholders, an accessible light/dark theme switch, and content designed to grow. The name **Autism For Evil** is the current working brand supplied by the site owner.

## Stack

- Astro for content-first pages and static generation.
- React integration for the WebGL2 `PlasmaWave` hero plus lightweight canvas adaptations of `GhostCursor`, `TechText`, and `SideRays` for the gateway page.
- Markdown content collections for courses, articles, project briefs, the Python reference shelf and curated networking notes.
- Plain CSS design tokens for responsive layouts, purple/blue themes, portrait placement and reduced-motion styling.

Astro's official React integration supports rendering React components and hydrating selected components on the client. See the [Astro React integration guide](https://docs.astro.build/en/guides/integrations-guide/react/).

## Run locally

Requirements: Node.js `22.22.0` or a newer compatible Node 22 release, npm, and an internet connection for the first dependency installation.

```bash
npm install
npm run dev
```

Open the local URL shown in the terminal (usually `http://localhost:4321`).

Build and preview:

```bash
npm run build
npm run preview
```

Generated static files are written to `dist/`.

## Contact form setup

The current contact form is a static mailto composer, not a server-side form handler. To configure its destination, copy `.env.example` to `.env` and set `PUBLIC_CONTACT_EMAIL` to the email address you intend to publish. It opens the visitor's email application with a prepared draft; it does not send messages by itself. Before a serious launch, consider a privacy-conscious form service or a server-side endpoint with spam protection.

Do not add a private address to the repo until you are ready for it to be public. `.env` is ignored by Git; only `.env.example` is tracked.

## Main routes

- `/` — minimal intro gateway showing only the owner’s name; click the name to enter the portfolio.
- `/autism-for-evil/` — main site home page and featured content.
- `/courses/` — course catalogue.
- `/courses/python-for-network-engineers/` — beginner-first Python learning path.
- `/articles/` — editorial notes and learning posts.
- `/projects/` — project briefs and build records.
- `/networking/` — searchable networking reference library.
- `/networking/<note-path>/` — individual note pages.
- `/library/` — the existing Python notes, curated as a separate reference shelf.
- `/about/` — public professional introduction.
- `/contact/` — contact page.
- `/search/` — search over the site's content.

## Where content lives

- `src/content/lessons/` — new beginner-first Python lessons.
- `src/content/articles/` — articles / field notes; initial entries are drafts.
- `src/content/projects/` — project briefs. Only mark a project as complete when there is implementation and test evidence.
- `src/content/library/` — browser-ready versions of the uploaded Python foundation notes.
- `src/content/networking/` — 144 curated networking notes sorted into topic-based shelves.
- `public/networking-assets/` — 17 original, hand-authored SVG diagrams used by the notes; unverified imported raster screenshots and photos were removed.
- `legacy-notes/` — source copies of the initial Python notes, excluding editor caches and virtual environments.
- `src/pages/` — Astro page routes.
- `src/components/react/PlasmaWave.jsx` and `.css` — supplied WebGL2 plasma visual for the main hero.
- `src/components/react/GhostCursor.jsx`, `TechText.jsx`, and `SideRays.jsx` with companion CSS — lighter Canvas 2D adaptations used on the intro gateway. They preserve the requested visual interactions/props where implemented; they are not byte-for-byte copies of the full WebGL/advanced upstream source.
- `docs/NETWORKING-NOTES-MIGRATION.md` — how the networking notes were regrouped and what was withheld.
- `networking-notes-manifest.json` — machine-readable migration manifest.
- `ASSET-CREDITS.md` — temporary portrait sources and publishing caveats.

## Networking notes: public-safety curation

The uploaded vault contained a mixture of study material, raw device transcripts and notes that were not suitable for immediate public publication. The site deliberately does **not** include the private journal, workplace task records, raw switch boot/config dumps or a customer-specific project note. Device names and corporate/local domains used in suitable educational notes were generalized; likely environment-specific IP examples for switch management, NTP and syslog were replaced with reserved documentation addresses; specific credential examples were replaced with placeholders. Unverified imported raster screenshots and photos were replaced with original SVG diagrams. This is cautious filtering, not a substitute for reviewing every page before publication.

Before making this repo public, do a final read-through of `/networking/` and the project pages. Never publish real company IP inventories, device configurations, credentials, SSH key material, network diagrams or unredacted logs without explicit authorization.

## Portrait placeholders

The portrait images on the home and About pages are remote, temporary stock placeholders, not photos of Thulani. They may fail to load if the provider blocks hotlinking, and their reuse/licensing status has not been confirmed for a production public website. The pages hide failed images and retain the initials/artwork as a fallback. Replace both images with properly licensed portraits you choose before launch. See `ASSET-CREDITS.md`.

## React Bits-inspired visual components

The gateway uses `TechText` for the name, `SideRays` for the ambient lighting, and `GhostCursor` for the cursor trail. These are lightweight Canvas 2D adaptations shaped around the JavaScript/CSS prop interface from the request, keeping the name readable and avoiding multiple full-screen WebGL effects at once. They are decorative; the actual link is a semantic anchor and remains keyboard accessible. All effects stop or reduce activity when possible under `prefers-reduced-motion`, the page is hidden, or the section leaves view.

`PlasmaWave` remains on the main `/autism-for-evil/` home page.


`src/components/react/PlasmaWave.jsx` and `PlasmaWave.css` contain the WebGL2 visual component adapted from the source supplied for this build. It is decorative and marked `aria-hidden`; the content remains readable if WebGL2 is unavailable. The home page loads it with Astro's `client:visible` directive, uses the purple/blue palette, and lowers quality to moderate GPU work. Test on mobile and reduce `quality` or set `paused` if needed. Respect `prefers-reduced-motion`; the component's source checks that preference.

Upstream attribution: [React Bits by David Haz](https://github.com/DavidHDev/react-bits). The repository's current [license](https://github.com/DavidHDev/react-bits/blob/main/LICENSE.md) is MIT + Commons Clause: it allows use in an application or website but restricts redistribution of the component itself, including in a bundle. The deployed portfolio may use it under those terms; before publishing this source repository publicly, review that clause carefully. Keep this repo private or replace the component if source redistribution is not permitted for your intended setup. Full note: `ASSET-CREDITS.md`.

## Verification status

The content and packaging structure was checked locally, including path-based curation, redaction searches, JSON manifest parsing, gateway-route wiring, component import paths, and JavaScript syntax where available. The package-install step for Astro/React dependencies timed out in this environment, so a full `npm run build` and browser-based visual/accessibility test could not be completed here. Do not treat the project as production-verified until those checks pass on your machine. See `BUILD-CHECKLIST.md`.

## Keep the content honest

- Mark planned work as planned.
- State what has actually been tested.
- Separate personal learning notes from workplace records.
- Use synthetic or redacted data in public examples.
- Keep secrets in protected environment variables, never source files.
