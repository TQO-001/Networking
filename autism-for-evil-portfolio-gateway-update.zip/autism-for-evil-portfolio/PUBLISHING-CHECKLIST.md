# Autism For Evil — publishing checklist

## Before pushing the repository public

- [ ] Run `npm install`, `npm run check`, and `npm run build` successfully.
- [ ] Open all main pages and note pages at desktop and mobile widths.
- [ ] Review the entire public networking notebook for company/customer material, credentials, hostnames, IP inventories, screenshots and configuration output.
- [ ] Replace the remote portrait placeholders with chosen, properly licensed images, or remove them.
- [ ] Configure the contact destination intentionally. Never commit `.env`.
- [ ] Review the React Bits MIT + Commons Clause terms. They allow use in an app/site but restrict redistribution of the component itself; keep this source repo private or replace the component before making the code repo public unless you have confirmed the source may be distributed under your intended arrangement.
- [ ] Confirm every project card describes the true state: planned, in progress, or completed with evidence.
- [ ] Add a domain to `astro.config.mjs` only when it is actually known.
- [ ] Generate and commit `package-lock.json` after a successful npm install.
- [ ] Add screenshots only after verifying that they contain no private device labels, serials, domains, or credentials.

## Local commands

```bash
npm install
npm run check
npm run build
npm run dev
```

The current generated version has not had a full Astro build or browser-based visual review because package downloads timed out in the generation environment. Verify locally before deploying.
