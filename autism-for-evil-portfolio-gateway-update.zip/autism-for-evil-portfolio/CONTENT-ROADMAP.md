# Content architecture and editorial roadmap

The site now has three distinct learning surfaces so readers are not forced to treat every note as a linear course.

## 1. Guided course: Python for Network Engineers

Location: `src/content/lessons/python-for-network-engineers/`

This is the front door for learners who have never programmed before. It starts with orientation and environment setup, then explains programs, values, decisions, loops, functions, CSV, error handling and testing. The path leads to a subnet calculator using Python's standard library.

Every lesson should explain new vocabulary, show a complete working example, name the file and command to use, show expected output, offer an exercise and hint, and end with a checkpoint.

## 2. Reference shelf: uploaded Python foundation notes

Location: `src/content/library/`

The uploaded Python material spans basics through decorators, generators, testing, APIs, automation and security. It remains a browsable reference shelf; it is not being advertised as a complete beginner-to-advanced course until the prerequisites and examples are reviewed.

## 3. Networking notebook

Location: `src/content/networking/`

The uploaded networking notes have been regrouped into these shelves:

- Start here / OT engineering roadmap.
- Networking foundations.
- CCNA exam blueprint and written drills.
- Industrial networking and Cisco IOS practice.
- Python and network automation.
- Linux foundations.
- Node-RED and industrial data.
- Secure self-hosted systems.
- Command references.
- Project notes.
- Practice and review.

Notes stay editable Markdown. The public export deliberately excludes personal journals, operational task records, two raw switch transcripts, and a customer-specific project note. Certain device/domain identifiers and credential examples were generalized. Treat the output as curated rather than guaranteed fully redacted; audit the rendered pages before publishing.

## 4. Project log

Location: `src/content/projects/`

The eight records are build briefs or works in progress, not claims that the tools all exist. Move a project to `complete` only after implementation, tests and documentation support that status. Add screenshots from synthetic or sanitized data.

## 5. Articles and field notes

Location: `src/content/articles/`

The initial articles are drafts. Rewrite first-person claims to reflect actual experience and add evidence before publishing them as completed case studies.

## 6. Portfolio identity

- `/about/` contains a public professional introduction based on the information supplied by the site owner.
- `/contact/` currently prepares a `mailto:` draft; it does not provide server-side message delivery.
- Home and About use remote portrait placeholders that must be replaced or properly licensed before launch.
- `PlasmaWave` supplies a decorative purple/blue hero visual; the rest of the content should remain usable when WebGL2 is unavailable.

## Suggested next additions

- A proper local build and browser accessibility pass.
- Replace stock placeholders with approved personal photos and add descriptive alt text.
- Configure a real contact destination or form provider.
- Responsive screenshots and a custom Open Graph image.
- Sitemap / RSS once content is ready for publication.
- Automated CI after a lockfile is generated.
