# Networking notes migration report

## Summary

The uploaded `Networking.zip` was treated as an Obsidian-style knowledge base rather than copied wholesale into a public site. The site now contains **144 curated Markdown pages** and **17 original SVG diagrams**, grouped into searchable topic shelves.

The new taxonomy includes: foundations; CCNA blueprint and written drills; industrial networking / Cisco IOS; Python and network automation; Linux; Node-RED and industrial data; secure self-hosted systems; command references; project notes; practice and review.

## Publication-safety choices

The archive mixes study notes with journals and operational records. The following were excluded from the public content collection:

- Personal journals / life-planning / ambiguous private reference notes.
- `01-Tasks` and deployment-specific workplace flows.
- Raw switch transcripts containing device identifiers, destructive maintenance commands, a corporate DNS suffix, credentials, management addressing or SSH key output.
- A customer-specific scrap-inventory project note.

Where a note was otherwise useful as a general lesson, company-associated switch/domain values were replaced with lab examples, likely environment-specific management/NTP/syslog addresses in related walkthrough copies were replaced with reserved documentation addresses, and plaintext password / secret examples were changed to placeholders. Original raster screenshots and photos with unverified licensing or potentially identifying terminal output were removed and replaced by original, generic SVG diagrams. Example values should still be reviewed after rendering.

## What this means

The public export should be safer than a direct copy, but it is not a guarantee that each paragraph is cleared for publication. The site owner should review every rendered page, especially configuration walkthroughs, screenshots, logs, project notes and any file referring to specific workplaces. Do not publish an actual production configuration merely because an identifier was renamed.

## Implementation

- Each public note has frontmatter for title, description, category, level, source-path label and tags.
- Markdown stays editable in `src/content/networking/`.
- `public/networking-assets/` contains original SVG network diagrams created for this site. The imported raster assets are not retained in the public build.
- `networking-notes-manifest.json` records curated page titles/targets, safe public assets, and aggregate exclusion counts; it intentionally omits the original paths of excluded private notes.
- The original `Networking.zip`, its `.git` history, Obsidian application state and large non-Markdown binaries are not embedded in the site archive.

## Before launch

1. Browse `/networking/` and use search for company names, real domains, credentials, IP inventories and hostnames.
2. Review any remaining configuration command that resembles a real deployment.
3. Check image assets visually for confidential labels or IPs.
4. Compare included notes against your employer's disclosure rules and remove anything not cleared for a public portfolio.
