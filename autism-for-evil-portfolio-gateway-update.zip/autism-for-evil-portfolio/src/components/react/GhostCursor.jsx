import { useEffect, useRef } from 'react';
import './GhostCursor.css';

const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

function parseColor(value) {
  const hex = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(value || '').trim());
  if (hex) {
    const full = hex[1].length === 3 ? hex[1].split('').map((part) => part + part).join('') : hex[1];
    return [0, 2, 4].map((index) => parseInt(full.slice(index, index + 2), 16));
  }
  const rgb = /^rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/i.exec(String(value));
  return rgb ? rgb.slice(1, 4).map(Number) : [180, 151, 207];
}

/** A lightweight canvas interpretation of React Bits' GhostCursor effect. */
export default function GhostCursor({
  color = '#B497CF',
  size = 80,
  trailLength = 50,
  inertia = 0.5,
  turbulence = 0.5,
  drift = 0.3,
  detail = 1,
  brightness = 1,
  bloomStrength = 0.6,
  bloomRadius = 1,
  bloomThreshold = 0.025,
  grainIntensity = 0.05,
  edgeIntensity = 0,
  clickPuff = true,
  intro = true,
  theme = 'dark',
  mixBlendMode,
  fadeDelayMs,
  fadeDurationMs,
  maxDevicePixelRatio = 2,
  targetPixels = 600000,
  zIndex = 10,
  className = '',
  style = {},
}) {
  const containerRef = useRef(null);
  const canvasRef = useRef(null);
  const settingsRef = useRef({});
  settingsRef.current = {
    color: parseColor(color), size: Math.max(8, size), trailLength: clamp(trailLength, 1, 200),
    inertia: clamp(inertia, 0, 0.99), turbulence: clamp(turbulence, 0, 2), drift,
    detail: clamp(detail, 0, 1), brightness: Math.max(0, brightness), bloomStrength: Math.max(0, bloomStrength),
    bloomRadius: clamp(bloomRadius, 0, 3), bloomThreshold: Math.max(0, bloomThreshold),
    grainIntensity: clamp(grainIntensity, 0, 1), edgeIntensity: clamp(edgeIntensity, 0, 1), clickPuff,
    intro, theme, fadeDelayMs, fadeDurationMs, maxDevicePixelRatio: clamp(maxDevicePixelRatio, 0.25, 3), targetPixels,
  };

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    const context = canvas?.getContext('2d');
    if (!container || !canvas || !context) return undefined;

    const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    const touch = window.matchMedia?.('(pointer: coarse)').matches ?? false;
    const pointer = { x: -1000, y: -1000, lastMove: 0, inside: false };
    const particles = [];
    let width = 1;
    let height = 1;
    let dpr = 1;
    let raf = 0;
    let lastTime = 0;
    let clock = 0;
    let visible = true;
    let introTimer = 0;

    const resize = () => {
      const rect = container.getBoundingClientRect();
      width = Math.max(1, rect.width);
      height = Math.max(1, rect.height);
      const s = settingsRef.current;
      dpr = Math.min(window.devicePixelRatio || 1, s.maxDevicePixelRatio, Math.sqrt(s.targetPixels / (width * height)) || 1);
      canvas.width = Math.max(1, Math.round(width * dpr));
      canvas.height = Math.max(1, Math.round(height * dpr));
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      context.setTransform(dpr, 0, 0, dpr, 0, 0);
      wake();
    };

    const addSmoke = (x, y, amount = 1) => {
      const s = settingsRef.current;
      const [r, g, b] = s.color;
      for (let i = 0; i < amount; i += 1) {
        particles.push({
          x: x + (Math.random() - 0.5) * s.size * 0.22,
          y: y + (Math.random() - 0.5) * s.size * 0.22,
          vx: (Math.random() - 0.5) * (0.45 + s.turbulence * 1.3),
          vy: -0.15 - Math.random() * (0.25 + Math.abs(s.drift) * 0.6),
          radius: s.size * (0.10 + Math.random() * 0.25),
          life: 1,
          decay: 0.004 + Math.random() * (0.011 + 0.17 / s.trailLength),
          phase: Math.random() * Math.PI * 2,
          color: `rgb(${r}, ${g}, ${b})`,
        });
      }
      if (particles.length > 220) particles.splice(0, particles.length - 220);
    };

    const draw = (now) => {
      raf = 0;
      if (document.hidden || !visible) return;
      const s = settingsRef.current;
      const dt = Math.min(0.05, lastTime ? (now - lastTime) / 1000 : 1 / 60);
      lastTime = now;
      clock += dt;
      const elapsed = now - pointer.lastMove;
      const delay = s.fadeDelayMs ?? (touch ? 500 : 1000);
      const duration = s.fadeDurationMs ?? (touch ? 1000 : 1500);
      const presence = pointer.inside && elapsed < delay ? 1 : clamp(1 - Math.max(0, elapsed - delay) / duration, 0, 1);

      if (presence > 0 && pointer.inside && !reducedMotion) {
        addSmoke(pointer.x, pointer.y, Math.min(3, 1 + Math.floor(s.trailLength / 50)));
      }

      context.clearRect(0, 0, width, height);
      const edge = s.edgeIntensity;
      for (let i = particles.length - 1; i >= 0; i -= 1) {
        const p = particles[i];
        p.life -= p.decay * (dt * 60);
        p.phase += dt * (0.8 + s.turbulence);
        p.vx += Math.sin(p.phase) * s.turbulence * 0.025;
        p.x += (p.vx + Math.sin(p.phase * 0.7) * s.turbulence * 0.15) * dt * 60;
        p.y -= s.drift * dt * 12;
        p.radius += dt * (3 + s.bloomRadius * 2);
        if (p.life <= 0 || p.y < -p.radius * 3 || p.x < -p.radius * 3 || p.x > width + p.radius * 3) {
          particles.splice(i, 1);
          continue;
        }
        const fadeX = Math.min(1, p.x / Math.max(1, width * 0.15), (width - p.x) / Math.max(1, width * 0.15));
        const fadeY = Math.min(1, p.y / Math.max(1, height * 0.15), (height - p.y) / Math.max(1, height * 0.15));
        const edgeFade = edge ? clamp(Math.min(fadeX, fadeY) / edge, 0, 1) : 1;
        const alpha = clamp(p.life * 0.18 * s.brightness * (0.65 + s.bloomStrength * 0.35) * edgeFade, 0, 0.55);
        const gradient = context.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.radius * (1.2 + s.bloomRadius * 0.35));
        gradient.addColorStop(0, `rgba(244, 237, 255, ${alpha * (0.35 + s.detail * 0.4)})`);
        gradient.addColorStop(0.25, p.color.replace('rgb(', 'rgba(').replace(')', `, ${alpha})`));
        gradient.addColorStop(1, p.color.replace('rgb(', 'rgba(').replace(')', ', 0)'));
        context.fillStyle = gradient;
        context.beginPath();
        context.arc(p.x, p.y, p.radius * (1.2 + s.bloomRadius * 0.35), 0, Math.PI * 2);
        context.fill();
      }
      if (s.grainIntensity > 0 && particles.length) {
        context.globalAlpha = Math.min(0.06, s.grainIntensity * 0.18);
        context.fillStyle = '#fff';
        for (let i = 0; i < 16; i += 1) context.fillRect(Math.random() * width, Math.random() * height, 1, 1);
        context.globalAlpha = 1;
      }
      const active = (!reducedMotion && pointer.inside && presence > 0.01) || particles.length > 0;
      if (active) raf = requestAnimationFrame(draw);
      else lastTime = 0;
    };

    function wake() {
      if (!raf && !document.hidden && visible) raf = requestAnimationFrame(draw);
    }

    const getLocal = (event) => {
      const rect = container.getBoundingClientRect();
      return { x: event.clientX - rect.left, y: event.clientY - rect.top };
    };
    const onMove = (event) => {
      const point = getLocal(event);
      const inside = point.x >= 0 && point.y >= 0 && point.x <= width && point.y <= height;
      if (inside) {
        if (pointer.inside && !reducedMotion) {
          const distance = Math.hypot(point.x - pointer.x, point.y - pointer.y);
          if (distance > 4) addSmoke((point.x + pointer.x) / 2, (point.y + pointer.y) / 2, Math.min(5, Math.ceil(distance / 28)));
        }
        pointer.x = point.x;
        pointer.y = point.y;
        pointer.inside = true;
        pointer.lastMove = performance.now();
        wake();
      } else {
        pointer.inside = false;
        wake();
      }
    };
    const onLeave = () => { pointer.inside = false; wake(); };
    const onDown = (event) => {
      if (!settingsRef.current.clickPuff || reducedMotion) return;
      const point = getLocal(event);
      if (point.x >= 0 && point.y >= 0 && point.x <= width && point.y <= height) {
        addSmoke(point.x, point.y, 24);
        pointer.x = point.x; pointer.y = point.y; pointer.inside = true; pointer.lastMove = performance.now();
        wake();
      }
    };
    const onVisibility = () => { if (document.hidden) cancelAnimationFrame(raf); else wake(); };
    const intersection = new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; if (visible) wake(); else cancelAnimationFrame(raf); });
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(container);
    intersection.observe(container);
    window.addEventListener('pointermove', onMove, { passive: true });
    window.addEventListener('pointerdown', onDown, { passive: true });
    container.addEventListener('pointerleave', onLeave, { passive: true });
    document.addEventListener('visibilitychange', onVisibility);
    resize();
    if (intro && !reducedMotion) {
      pointer.x = width * 0.44; pointer.y = height * 0.62; pointer.inside = true; pointer.lastMove = performance.now();
      addSmoke(pointer.x, pointer.y, 18); wake();
      introTimer = window.setTimeout(() => { pointer.inside = false; wake(); }, 1500);
    }

    return () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(introTimer);
      resizeObserver.disconnect(); intersection.disconnect();
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerdown', onDown);
      container.removeEventListener('pointerleave', onLeave);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [intro]);

  return <div ref={containerRef} className={`ghost-cursor ${className}`.trim()} style={{ zIndex, mixBlendMode: mixBlendMode || (theme === 'light' ? 'normal' : 'screen'), ...style }} aria-hidden="true"><canvas ref={canvasRef} className="ghost-cursor__canvas" /></div>;
}
