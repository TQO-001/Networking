import { useEffect, useRef } from 'react';
import './TechText.css';

const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

/** A responsive canvas wordmark with cursor-guided dashed outlines and letter focus. */
export default function TechText({
  text = 'Thulani Langa', fontFamily = '', fontWeight = 600, fontSize = 150,
  letterSpacing = -0.035, align = 'center', color = 'currentColor', accentColor = '#93C5FD',
  reveal = 'letter', reach = 200, softness = 0.7, dashLength = 4, dashGap = 2,
  lineStyle = 'dashed', strokeWidth = 1.5, specks = 15, selection = true, labels = true,
  draggable = true, bounce = 0.4, clickKick = true, intro = 'none', introDuration = 2,
  guides = false, sweep = true, speed = 1, className = '', style = {},
}) {
  const containerRef = useRef(null);
  const canvasRef = useRef(null);
  const settingsRef = useRef({});
  settingsRef.current = { text, fontFamily, fontWeight, fontSize, letterSpacing, align, color, accentColor, reveal, reach, softness, dashLength, dashGap, lineStyle, strokeWidth, specks, selection, labels, draggable, bounce, clickKick, intro, introDuration, guides, sweep, speed };

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!container || !canvas) return undefined;
    if (!ctx) {
      container.classList.add('tech-text--fallback');
      return () => container.classList.remove('tech-text--fallback');
    }
    container.classList.remove('tech-text--fallback');
    const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    let width=1, height=1, dpr=1, raf=0, start=performance.now(), last=0, hover=-1, time=0, visible=true;
    let chars=[], pointer={x:-1000,y:-1000,inside:false}, introEnd=0;

    const resolvedColor = (value) => {
      if (!value || value === 'currentColor' || value === 'inherit') return getComputedStyle(container).color || '#ffffff';
      return value;
    };
    const resize = () => {
      const rect=container.getBoundingClientRect(); width=Math.max(1,rect.width); height=Math.max(1,rect.height);
      dpr=Math.min(window.devicePixelRatio||1,2); canvas.width=Math.max(1,Math.round(width*dpr)); canvas.height=Math.max(1,Math.round(height*dpr));
      ctx.setTransform(dpr,0,0,dpr,0,0); chars=[]; placeChars(); wake();
    };
    const placeChars = () => {
      const s=settingsRef.current; const family=s.fontFamily || getComputedStyle(container).fontFamily || 'sans-serif';
      let size=Math.min(s.fontSize, height*0.72); ctx.font=`${s.fontWeight} ${size}px ${family}`;
      const spacing=size*s.letterSpacing; const widths=Array.from(s.text, char=>ctx.measureText(char).width);
      const total=widths.reduce((sum,value)=>sum+value,0)+spacing*Math.max(0,widths.length-1);
      const scale=Math.min(1,(width*0.92)/Math.max(1,total)); size*=scale;
      ctx.font=`${s.fontWeight} ${size}px ${family}`;
      const measured=Array.from(s.text,char=>ctx.measureText(char));
      const fullWidths=measured.map(m=>m.width); const letterSpace=size*s.letterSpacing;
      const full=fullWidths.reduce((sum,value)=>sum+value,0)+letterSpace*Math.max(0,fullWidths.length-1);
      let x=s.align==='left'?width*0.04:s.align==='right'?width-width*0.04-full:(width-full)/2;
      const y=height/2 + (measured[0]?.actualBoundingBoxAscent || size*0.7)*0.42;
      chars=[];
      Array.from(s.text).forEach((char,index)=>{ const advance=fullWidths[index]+letterSpace; if(char.trim()) chars.push({char,x,y,width:fullWidths[index],advance,offsetY:0}); x+=advance; });
      introEnd=performance.now()+Math.max(0,s.introDuration)*1000;
    };
    const roundedRect = (x,y,w,h,r) => { ctx.beginPath(); ctx.roundRect(x,y,w,h,r); };
    const draw = (now) => {
      raf=0; if(!visible || document.hidden) return;
      const s=settingsRef.current; const dt=Math.min(0.05,last?(now-last)/1000:1/60); last=now;
      if(!reducedMotion) time+=dt*s.speed;
      if(!chars.length) placeChars();
      ctx.clearRect(0,0,width,height);
      const ink=resolvedColor(s.color), accent=resolvedColor(s.accentColor);
      const introActive=!reducedMotion && s.intro!=='none' && now<introEnd;
      hover=-1;
      if(pointer.inside && !introActive){
        let nearest=Infinity;
        chars.forEach((g,i)=>{ const d=Math.abs(pointer.x-(g.x+g.width/2)); if(d<nearest){nearest=d;hover=i;} });
        if(nearest>Math.max(36,s.fontSize*0.36)) hover=-1;
      } else if(s.sweep && !reducedMotion && !introActive && chars.length){ hover=Math.floor((time*0.35%1)*chars.length); }
      const phase=introActive ? clamp(1-(introEnd-now)/(Math.max(0.1,s.introDuration)*1000),0,1) : 1;
      chars.forEach((g,index)=>{
        if(introActive && s.intro==='type' && phase < (index+1)/chars.length) return;
        if(introActive && s.intro==='assemble') { ctx.globalAlpha=clamp((phase-index/chars.length)*chars.length,0,1); }
        else ctx.globalAlpha=1;
        ctx.font=`${s.fontWeight} ${Math.min(s.fontSize,height*0.72)*(width/(width||1))}px ${s.fontFamily||getComputedStyle(container).fontFamily||'sans-serif'}`;
        // Keep the actual rendered baseline/scale from layout measurements consistent after resize.
        const family=s.fontFamily||getComputedStyle(container).fontFamily||'sans-serif';
        const size=Math.min(s.fontSize,height*0.72, (width*0.92)/Math.max(1,chars.reduce((sum,c)=>sum+c.advance,0)));
        ctx.font=`${s.fontWeight} ${size}px ${family}`;
        const focused=index===hover;
        ctx.fillStyle=ink; ctx.fillText(g.char,g.x,g.y+g.offsetY);
        if(focused && s.reveal!=='off'){
          ctx.save();
          // Create a transparent cut-out in the active letter, then trace its technical outline.
          ctx.globalCompositeOperation='destination-out'; ctx.fillText(g.char,g.x,g.y+g.offsetY); ctx.globalCompositeOperation='source-over';
          ctx.strokeStyle=accent; ctx.lineWidth=s.strokeWidth; ctx.lineJoin='round'; ctx.setLineDash(s.lineStyle==='solid'?[]:[s.dashLength,s.dashGap]); ctx.strokeText(g.char,g.x,g.y+g.offsetY); ctx.setLineDash([]);
          ctx.restore();
          if(s.selection){
            const metrics=ctx.measureText(g.char); const top=g.y-(metrics.actualBoundingBoxAscent||size*0.7)-7; const h=(metrics.actualBoundingBoxAscent||size*0.7)+(metrics.actualBoundingBoxDescent||size*0.1)+14;
            ctx.strokeStyle=`${accent}99`;ctx.lineWidth=1;roundedRect(g.x-5,top,g.width+10,h,2);ctx.stroke();
            ctx.fillStyle=accent;[[g.x-5,top],[g.x+g.width+5,top],[g.x-5,top+h],[g.x+g.width+5,top+h]].forEach(([x,y])=>ctx.fillRect(x-2,y-2,4,4));
            if(s.labels){ctx.font='10px ui-monospace, monospace';ctx.fillStyle=accent;ctx.fillText(`${g.char} / ${Math.round(g.width)}px`,g.x,top-7);}
            for(let n=0;n<Math.min(5,s.specks);n++){const px=g.x+((Math.sin(time*2.2+n*17.7)+1)/2)*(g.width+10)-5;const py=top+((Math.cos(time*2.5+n*7.3)+1)/2)*h;ctx.globalAlpha=0.25+((n%3)/5);ctx.fillRect(px,py,2,2);ctx.globalAlpha=1;}
          }
        }
        ctx.globalAlpha=1;
      });
      if(s.guides && hover>=0){const g=chars[hover];ctx.strokeStyle=`${accent}66`;ctx.setLineDash([3,5]);ctx.beginPath();ctx.moveTo(0,g.y);ctx.lineTo(width,g.y);ctx.stroke();ctx.setLineDash([]);}
      const active=(!reducedMotion && (pointer.inside || (s.sweep && !introActive))) || introActive;
      if(active) raf=requestAnimationFrame(draw); else last=0;
    };
    function wake(){if(!raf&&visible&&!document.hidden)raf=requestAnimationFrame(draw);}
    const onMove=(event)=>{const rect=container.getBoundingClientRect();pointer.x=event.clientX-rect.left;pointer.y=event.clientY-rect.top;pointer.inside=pointer.x>=0&&pointer.y>=0&&pointer.x<=width&&pointer.y<=height;wake();};
    const onLeave=()=>{pointer.inside=false;wake();};
    const resizeObserver=new ResizeObserver(resize); resizeObserver.observe(container);
    const intersection=new IntersectionObserver(([entry])=>{visible=entry.isIntersecting;if(visible)wake();else cancelAnimationFrame(raf);});intersection.observe(container);
    container.addEventListener('pointermove',onMove,{passive:true});container.addEventListener('pointerleave',onLeave,{passive:true});document.addEventListener('visibilitychange',wake);
    resize(); if(intro!=='none' && !reducedMotion) wake();
    return()=>{cancelAnimationFrame(raf);resizeObserver.disconnect();intersection.disconnect();container.removeEventListener('pointermove',onMove);container.removeEventListener('pointerleave',onLeave);document.removeEventListener('visibilitychange',wake);};
  }, [text, fontFamily, fontWeight, fontSize, letterSpacing, align, intro, introDuration, sweep, speed, color, accentColor, selection, labels, guides, reveal, dashLength, dashGap, lineStyle, strokeWidth, specks]);

  return <div ref={containerRef} className={`tech-text ${className}`.trim()} style={style} role="img" aria-label={text}><canvas ref={canvasRef} className="tech-text-canvas" /> <span className="tech-text__fallback">{text}</span></div>;
}
