import { useEffect, useRef } from 'react';
import './SideRays.css';

const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
const parseColor = (value) => {
  const match = /^#?([\da-f]{3}|[\da-f]{6})$/i.exec(String(value || '').trim());
  if (!match) return [150, 200, 255];
  const hex = match[1].length === 3 ? match[1].split('').map((x) => x + x).join('') : match[1];
  return [0, 2, 4].map((index) => parseInt(hex.slice(index, index + 2), 16));
};

/** Lightweight canvas implementation of React Bits' interactive SideRays background. */
export default function SideRays({
  rayColor1 = '#8B5CF6', rayColor2 = '#60A5FA', blend = 0.55, origin = 'top-right',
  speed = 0.45, intensity = 1.2, spread = 1.8, density = 24, sharpness = 0.35,
  tilt = 0, falloff = 1.6, glow = 0.8, saturation = 1, dust = 0.08, followMouse = true,
  mouseInfluence = 0.28, intro = true, lightMode = false, opacity = 1, maxDevicePixelRatio = 2,
  className = '', style = {},
}) {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const settingsRef = useRef({});
  settingsRef.current = { rayColor1: parseColor(rayColor1), rayColor2: parseColor(rayColor2), blend: clamp(blend,0,1), origin, speed, intensity, spread, density, sharpness, tilt, falloff, glow, saturation, dust, followMouse, mouseInfluence, intro, lightMode, opacity, maxDevicePixelRatio };

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !container || !ctx) return undefined;
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
    let width = 1, height = 1, dpr = 1, raf = 0, last = 0, clock = 0, visible = true;
    const mouse = { x: 0.5, y: 0.4, inside: false };
    const resize = () => {
      const rect = container.getBoundingClientRect();
      width = Math.max(1, rect.width); height = Math.max(1, rect.height);
      const s = settingsRef.current;
      dpr = Math.min(window.devicePixelRatio || 1, s.maxDevicePixelRatio, Math.sqrt(2400000 / (width * height)) || 1);
      canvas.width = Math.max(1, Math.round(width * dpr)); canvas.height = Math.max(1, Math.round(height * dpr));
      ctx.setTransform(dpr,0,0,dpr,0,0); wake();
    };
    const draw = (now) => {
      raf = 0; if (!visible || document.hidden) return;
      const s = settingsRef.current;
      const dt = Math.min(0.05, last ? (now - last) / 1000 : 1/60); last = now;
      if (!reduced) clock += dt * s.speed;
      ctx.clearRect(0,0,width,height);
      const a = s.rayColor1, b = s.rayColor2;
      const color = (first, alpha) => `rgba(${first[0]}, ${first[1]}, ${first[2]}, ${alpha})`;
      let ox = width * 0.98, oy = height * 0.02;
      if (s.origin === 'top-left') { ox = width * 0.02; oy = height * 0.02; }
      if (s.origin === 'bottom-right') { ox = width * 0.98; oy = height * 0.98; }
      if (s.origin === 'bottom-left') { ox = width * 0.02; oy = height * 0.98; }
      if (s.origin === 'left') { ox = width * 0.02; oy = height * 0.5; }
      if (s.origin === 'right') { ox = width * 0.98; oy = height * 0.5; }
      const direction = (s.origin.startsWith('bottom') ? -1 : 1);
      let mouseAngle = 0;
      if (s.followMouse && mouse.inside && !reduced) {
        mouseAngle = clamp((mouse.x * width - ox) / Math.max(1,width) * 0.32, -0.25,0.25) * s.mouseInfluence;
      }
      const baseAngle = (s.origin === 'left' ? 0 : s.origin === 'right' ? Math.PI : s.origin.includes('left') ? 0.3 : Math.PI - 0.3) + (s.tilt * Math.PI / 180) + mouseAngle;
      const rayCount = clamp(Math.round(s.density), 4, 70);
      ctx.save();
      ctx.globalCompositeOperation = s.lightMode ? 'multiply' : 'screen';
      for (let i = 0; i < rayCount; i += 1) {
        const u = (i / Math.max(1, rayCount - 1)) - 0.5;
        const wobble = reduced ? 0 : Math.sin(clock * 0.7 + i * 1.71) * 0.018;
        const angle = baseAngle + u * s.spread * 0.65 + wobble * direction;
        const reach = Math.max(width,height) * (1.05 - Math.abs(u) * 0.22);
        const endX = ox + Math.cos(angle) * reach;
        const endY = oy + Math.sin(angle) * reach;
        const grad = ctx.createLinearGradient(ox,oy,endX,endY);
        const maxAlpha = clamp(s.intensity * (0.014 + (1 - s.sharpness) * 0.024), 0.006, 0.09) * s.opacity;
        const chosen = (i / rayCount) < s.blend ? b : a;
        grad.addColorStop(0,color(chosen, maxAlpha * s.glow));
        grad.addColorStop(0.35,color(chosen, maxAlpha * (0.55 + s.sharpness * 0.3)));
        grad.addColorStop(1,color(chosen,0));
        ctx.beginPath(); ctx.moveTo(ox,oy);
        const half = Math.max(1,width * (0.007 + (1-s.sharpness)*0.018) * s.spread / 2);
        ctx.lineTo(endX + Math.sin(angle) * half,endY - Math.cos(angle) * half);
        ctx.lineTo(endX - Math.sin(angle) * half,endY + Math.cos(angle) * half);
        ctx.closePath(); ctx.fillStyle = grad; ctx.fill();
      }
      if (s.dust > 0) {
        for (let i=0;i<Math.round(45*s.dust);i+=1) {
          const seed = i * 17.91;
          const x = (Math.sin(seed + clock*0.08)*0.5+0.5)*width;
          const y = (Math.cos(seed*0.7 - clock*0.06)*0.5+0.5)*height;
          ctx.fillStyle = color(i%2 ? a : b, (0.08 + 0.15 * Math.sin(seed+clock))*s.opacity);
          ctx.fillRect(x,y,1.3,1.3);
        }
      }
      ctx.restore();
      if ((!reduced && s.speed > 0) || (s.followMouse && mouse.inside)) raf = requestAnimationFrame(draw);
      else last = 0;
    };
    function wake() { if (!raf && visible && !document.hidden) raf = requestAnimationFrame(draw); }
    const onMove = (event) => { const rect = container.getBoundingClientRect(); mouse.x = (event.clientX-rect.left)/Math.max(1,rect.width); mouse.y = (event.clientY-rect.top)/Math.max(1,rect.height); mouse.inside = mouse.x>=0 && mouse.x<=1 && mouse.y>=0 && mouse.y<=1; wake(); };
    const onLeave = () => { mouse.inside = false; wake(); };
    const resizeObserver = new ResizeObserver(resize); resizeObserver.observe(container);
    const intersection = new IntersectionObserver(([entry])=>{ visible=entry.isIntersecting; if(visible) wake(); else cancelAnimationFrame(raf); }); intersection.observe(container);
    container.addEventListener('pointermove',onMove,{passive:true}); container.addEventListener('pointerleave',onLeave,{passive:true});
    document.addEventListener('visibilitychange',wake); resize(); if(intro) wake();
    return ()=>{ cancelAnimationFrame(raf); resizeObserver.disconnect(); intersection.disconnect(); container.removeEventListener('pointermove',onMove); container.removeEventListener('pointerleave',onLeave); document.removeEventListener('visibilitychange',wake); };
  }, [intro]);

  return <div ref={containerRef} className={`side-rays ${className}`.trim()} style={style} aria-hidden="true"><canvas ref={canvasRef} className="side-rays__canvas" /></div>;
}
