---
title: "Network interface health monitor"
description: "Collect interface names, addresses and byte/packet counters from the computer running the tool, then calculate differences between samples."
order: 4
stage: "System monitoring"
status: "brief"
technologies: ["Python", "psutil", "pytest"]
tags: ["interfaces", "metrics"]
---
## Problem

Interface statistics can help explain whether traffic is moving and whether counters are changing. This project observes the local machine or an explicitly selected lab server; it does not change interface settings.

## Intended behaviour

- List interfaces and their addresses.
- Read bytes sent/received and packets sent/received.
- Capture error and drop counters where the operating system exposes them.
- Sample twice and calculate counter deltas.
- Handle counters resetting or interfaces disappearing between samples.

## Build sequence

Start with one snapshot, then add sampling, then add output formatting. Introduce `psutil` only after you understand the fields you intend to display.
