---
title: "Network reachability monitor"
description: "Poll a small, explicit list of approved lab targets and record check results over time without claiming more than the measurements prove."
order: 3
stage: "Monitoring basics"
status: "brief"
technologies: ["Python standard library", "subprocess or sockets", "datetime", "logging"]
tags: ["monitoring", "network-ops"]
---
## Problem

A single manual check is only a snapshot. A small monitor can record a history of whether a chosen check succeeded during a test window.

## Intended behaviour

- Read an explicit configured list of lab targets.
- Use one documented reachability method per target.
- Record timestamps, result, elapsed time where supported, and errors.
- Apply a timeout and a bounded polling interval.
- Export results so they can be graphed later.

## Engineering notes

ICMP ping availability and command-line flags differ across Windows and Linux. The implementation must account for platform differences and should test those paths separately. A failed ping does not always mean a host is down; a host may filter ICMP or a path may block it.

## Safety boundary

Do not run broad address-range scans or unapproved polling against production OT. Start with a few explicit addresses in a personal or approved lab.
