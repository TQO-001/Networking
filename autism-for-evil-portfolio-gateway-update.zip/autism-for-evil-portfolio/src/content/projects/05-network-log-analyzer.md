---
title: "Network log analyser"
description: "Parse sample syslog-style text and summarise severities, link-state events and repeated messages with explainable rules."
order: 5
stage: "Troubleshooting"
status: "brief"
technologies: ["Python standard library", "re", "logging", "datetime"]
tags: ["logs", "troubleshooting"]
---
## Problem

Logs can be long, repetitive and difficult to skim. This tool turns sample or exported log text into a structured summary while retaining the original source line for traceability.

## Intended behaviour

- Read a local log file without modifying it.
- Count messages by severity or known event pattern.
- Highlight link-up/link-down style messages in a test dataset.
- Handle lines that do not match the expected format.
- Export a short summary and preserve a reference to the original line number.

Use sanitised sample data. Do not publish unredacted company logs, hostnames, public IPs or tokens.
