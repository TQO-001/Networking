---
title: "OT asset inventory checker"
description: "Read a CSV inventory and flag missing fields, duplicate IPs, malformed addresses and inconsistent device roles without scanning the network."
order: 2
stage: "Python fundamentals"
status: "brief"
technologies: ["Python standard library", "csv", "ipaddress", "pytest"]
tags: ["OT", "CSV", "validation"]
---
## Problem

Network teams need an inventory that is consistent enough to trust. This project works with fictional or approved inventory data and does not connect to devices.

## Intended behaviour

- Read a CSV with hostname, IP address, role and VLAN columns.
- Report missing required fields and duplicated IP addresses.
- Validate address syntax with the standard library's `ipaddress` module.
- Produce a readable summary and optional CSV report of findings.

## Build sequence

1. Read a CSV with `csv.DictReader`.
2. Represent each row clearly and validate required columns.
3. Track duplicates using a dictionary or set.
4. Return structured findings from validation functions.
5. Test each rule with small sample files.

## Definition of done

A deliberately malformed sample inventory produces predictable findings, valid records are not reported as errors, and a README describes the file format. Use synthetic data in public examples.
