---
title: "Offline packet capture analyser"
description: "Summarise an existing capture file to learn packet structure, protocol counts and conversations without beginning with live capture."
order: 6
stage: "Packet analysis"
status: "brief"
technologies: ["Python", "Scapy", "PCAP"]
tags: ["packet-analysis", "Scapy"]
---
## Problem

Packet captures contain detailed evidence about network conversations. The first version should read an existing approved capture file and produce a summary rather than capture traffic from a live network.

## Intended behaviour

- Open a local `.pcap` or `.pcapng` file.
- Count packet types and observed IP endpoints.
- Report packet lengths and timestamps where available.
- Handle an empty or unreadable capture clearly.
- Keep output concise and avoid exposing sensitive payload data by default.

## Safety boundary

Only inspect captures you own or are authorised to use. For public portfolio screenshots, use synthetic or sanitised data and hide sensitive payloads.
