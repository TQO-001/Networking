---
title: "README"
description: "https://www.freecodecamp.org/news/learn-linux-for-beginners-book-basic-to-advanced/"
category: "Linux / Foundations"
level: "Beginner"
sourcePath: "Curated networking notebook"
tags: ["linux", "foundations"]
---

https://www.freecodecamp.org/news/learn-linux-for-beginners-book-basic-to-advanced/
https://www.netacad.com/courses/linux-essentials?courseLang=en-US
