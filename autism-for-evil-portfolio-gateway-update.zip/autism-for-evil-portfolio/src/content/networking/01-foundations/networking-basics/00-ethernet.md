---
title: "00 Ethernet"
description: "https://networklessons.com/switching/introduction-to-ethernet"
category: "Networking foundations / Basics"
level: "Beginner"
sourcePath: "Curated networking notebook"
tags: ["networking", "foundations", "basics"]
---

https://networklessons.com/switching/introduction-to-ethernet
