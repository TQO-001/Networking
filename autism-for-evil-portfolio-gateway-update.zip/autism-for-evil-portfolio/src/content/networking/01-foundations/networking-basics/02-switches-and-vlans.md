---
title: "Network Switch"
description: "A network switch is a vital component of a computer network that connects multiple devices, like computers, printers, and servers, within a local area network (LAN). It operates at the data…"
category: "Networking foundations / Basics"
level: "Beginner"
sourcePath: "Curated networking notebook"
tags: ["networking", "foundations", "basics"]
---

# Network Switch
## What is a Switch
A network switch is a vital component of a computer network that connects multiple devices, like computers, printers, and servers, within a local area network (LAN). It operates at the data link layer of the OSI model and ensures seamless communication between devices by forwarding data packets based on their destination MAC addresses. The primary function of a network switch is to enhance network performance by optimizing the flow of data traffic. Unlike a hub, a network switch smartly directs data packets only to the devices that need them, reducing network congestion and improving overall efficiency.

![A generic Layer 2 switch connecting several local network devices](/networking-assets/switch-basics.svg)

#### Types of network switches
- **Unmanaged switches**: Simple plug-and-play devices with no setup needed. Best for home or small office use. 
- **Managed switches**: Advanced devices that let you monitor traffic, add security, and set up virtual networks (VLANs). Best for big companies.
- **Smart (web-managed) switches**: A middle choice. They offer basic web controls for VLANs and priority settings at a lower cost than fully managed options

When you work with switches, you must remember that there’s a big difference between physical and logical topology. Physical is just the way our cables are connected, while logical is how we have set up things ‘virtually’. 
# VLANs (Virtual LANs)
A VLAN (Virtual Local Area Network) is ==a logical method used to divide a single physical network into multiple separate virtual networks==. A VLAN is a Virtual LAN, so it’s like having a “switch inside a switch”.
- It reduces unnecessary broadcast traffic, enhances security, and improves network performance, flexibility, and manageability.
- Traditionally, broadcast domains were separated using Layer 3 devices (routers).
- **Same VLAN:** Devices communicate directly within the same broadcast domain.
- **Different VLANs:** Communication requires Inter-VLAN Routing via a router or a Layer 3 switch (SVI).

> [!NOTE] **NOTE** - To reach hosts in a different VLAN, a router is needed as stated above.

## VLAN Segmentation

Segmentation is one of the most important design principles in both enterprises and lab environments. Without it, any single compromised device could access everything else — which makes testing or defense simulations unrealistic.

To enforce segmentation, I created VLANs for each network zone.

In pfSense, VLANs are configured under:  
**Interfaces → Assignments → VLANs → Add.**

Each VLAN has a unique ID (e.g., VLAN 100 for Management, VLAN 200 for VMs, VLAN 250 for Servers).

## VLAN ID Ranges (Cisco Standard)

- **VLAN 0 and VLAN 4095:** Reserved VLAN IDs are defined by IEEE 802.1Q and used internally for protocol operations and cannot be configured or assigned to ports.
- **VLAN 1 (Default VLAN):** The default VLAN on Cisco switches and all switch ports are assigned to VLAN 1 by default. It cannot be deleted and is commonly used for control and management protocols such as STP, CDP, and VTP.
- **VLAN 2 to VLAN 1001 (Normal VLAN Range):** This range is used for regular VLAN configuration. VLANs in this range are fully configurable, editable, and delectable, and are stored in the switch’s VLAN database.
- **VLAN 1002 to VLAN 1005:** Reserved VLANs for legacy network technologies such as FDDI and Token Ring. These VLANs are predefined and cannot be removed, even if the technologies are no longer in use.
- **VLAN 1006 to VLAN 4094 (Extended VLAN Range):** Designed for large-scale networks requiring a high number of VLANs. VLANs in this range are stored in the **running configuration** and typically require the switch to operate in VTP transparent mode.
![A router forwarding traffic between two different IP networks](/networking-assets/router.svg)

### VLAN 1
VLAN 1 isn’t just a starter setting; on most enterprise hardware, it is the default VLAN used for the switch’s internal logic.

Even if you aren’t sending your printer or laptop traffic through it, the switch itself uses VLAN 1 to “talk” to its neighbors. Many control plane protocols default to VLAN 1. For example, Cisco switches use it for CDP (Cisco Discovery Protocol), VTP, and PAgP, while the standard Spanning Tree Protocol (STP) also typically operates on VLAN 1 across vendors by default.

While you can and should move user data and management traffic to other VLANs for security purposes, attempting to delete VLAN 1 typically fails or causes operational issues. The best practice is to leave VLAN 1 in place but unused. Change the native VLAN on trunk ports to an unused VLAN ID and don’t assign any access ports to VLAN 1.

Note that some non-Cisco vendors, such as Juniper or certain Linux-based switches, handle the “default” VLAN differently or allow you to rename it.

### Types of VLAN Links
- **Access Link:** Connects a VLAN-unaware end device (such as a PC) to a VLAN-aware switch. Frames transmitted over an access link are untagged and belong to a single VLAN.
- **Trunk Link:** Connects VLAN-aware devices such as switch-to-switch or switch-to-router links. It carries traffic from multiple VLANs using IEEE 802.1Q tagging.
- **Hybrid Link:** Supports both tagged and untagged frames on the same link. It is typically vendor-specific and not part of the IEEE 802.1Q standard.

### Features
- **VLAN Tagging (IEEE 802.1Q):** Inserts a 4-byte VLAN tag into Ethernet frames to identify the VLAN to which the frame belongs.
- **VLAN Membership:** Devices can be assigned to VLANs based on switch port, MAC address, or protocol type.
- **VLAN Trunking:** Allows multiple VLANs to share a single physical link between VLAN-aware devices.
- **Dynamic VLANs:** VLAN membership is automatically assigned to devices based on predefined policies or authentication mechanisms.

---
## Crucial Rules: Subnets vs. VLANs (Layer 2 vs. Layer 3)
A common mistake in network design is confusing **Layer 2 VLAN tags** with **Layer 3 IP Subnets**. Always keep the following fundamental rules in mind:

### 1. The "1 Subnet = 1 VLAN" Mapping Rule
* **Rule:** An IP Subnet (e.g., `192.168.10.0/24`) must correspond strictly to a **single** VLAN ID (e.g., VLAN 10).
* **The Problem:** If you place two different IP subnets (e.g., `192.168.10.0/24` and `192.168.11.0/24`) inside the **same** VLAN ID (e.g., VLAN 10), devices will fail to communicate—even if a default gateway/firewall is present.

### 2. How Inter-VLAN Routing Fails on SVI Mismatches
Consider a scenario where:
* **SW1 SVI (`interface Vlan10`):** `192.168.10.200/24`
* **SW2 SVI (`interface Vlan10`):** `192.168.11.201/24`

When SW1 attempts to ping SW2:
1. **Routing Lookup:** SW1 sees that `192.168.11.201` is on a different subnet, so it forwards the packet to its default gateway (`192.168.10.1` on the firewall) tagged as **VLAN 10**.
2. **Firewall Routing:** The firewall receives the packet on its VLAN 10 interface and routes it out to its **VLAN 11 interface** (`192.168.11.1`).
3. **ARP Failure:** The firewall sends an ARP request for `192.168.11.201` tagged with **VLAN 11**. However, because SW2 has `192.168.11.201` assigned to `interface Vlan10`, SW2 ignores ARP requests arriving on **VLAN 11**. Traffic is silently dropped.

### Key Takeaways
> [!WARNING] **CRITICAL**
> * **Switch Virtual Interfaces (SVIs):** An `interface VlanX` command tells the switch CPU to bind that IP address specifically to Ethernet frames tagged with **VLAN X**.
> * **Matching SVIs to Subnets:** To allow a switch on Subnet `192.168.11.0/24` to talk through a router/firewall, its SVI **must** be created on `interface Vlan11`, matching the VLAN tag assigned to that subnet on the firewall.

---
## Cisco VLAN Configuration
To **Configure Cisco VLAN**, firstly create the **[VLAN](https://ipcisco.com/lesson/vlans-virtual-local-area-networks/)** with the **VLAN ID** and then give it a name;  
>**REMEMBER** The standard VLAN number range is 1 to 1005. 1002 to 1005 is reserved for Token Ring and FDDI. And lastly 1006 to 4094 range is used by VTP transparent mode)

### 1. Open the switch SW1 console line and create domain and user name.
```cisco
SW1>enable
SW1>configure terminal
SW1(config)#ip domain-name lab.example
SW1(config)#username labadmin secret <REPLACE_WITH_LAB_USER_SECRET>
SW1(config)#
```

### 2. Create VLAN and assign a name to the VLAN for description.
```cisco
SW1(config)#vlan 2
SW1(config-vlan)#name USERS
```

### 3. VLAN port assignment and configure the port mode.
```cisco
SW1(config)#interface fa1/1
SW1(config-if)#switchport mode access
SW1(config-if)#switchport access vlan 2
```
