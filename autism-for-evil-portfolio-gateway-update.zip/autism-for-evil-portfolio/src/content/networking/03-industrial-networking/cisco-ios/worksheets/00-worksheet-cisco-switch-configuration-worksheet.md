---
title: "Cisco IOS Switch Configuration Practice Worksheet & Answer Key"
description: "This study guide and fill-in-the-blank practice sheet is designed to help you practice and memorize essential Cisco IOS switch initial setup"
category: "Industrial networking / Cisco IOS / Worksheets"
level: "Beginner–Intermediate"
sourcePath: "Curated networking notebook"
tags: ["industrial", "networking", "cisco", "ios", "worksheets"]
---

# Cisco IOS Switch Configuration Practice Worksheet & Answer Key

This study guide and fill-in-the-blank practice sheet is designed to help you practice and memorize essential Cisco IOS switch initial setup commands.

---

## 📝 Practice Worksheet
*Fill in the missing commands (indicated by `[ ??? ]`) to complete each step of the switch configuration.*

### Section 1: Initial Setup & Management IP

1. **Enter Privileged EXEC mode:**
   ```cisco
   Switch> [ ??? ]
   ```

2. **Enter Global Configuration mode:**
   ```cisco
   Switch# [ ??? ]
   ```

3. **Access interface VLAN 1 to assign management IP `192.0.2.10` with subnet `255.255.255.0`:**
   ```cisco
   Switch(config)# [ ??? ]
   Switch(config-if)# [ ??? ]
   ```

4. **Return to global config mode and configure the default gateway `192.0.2.1`:**
   ```cisco
   Switch(config-if)# [ ??? ]
   Switch(config)# [ ??? ]
   ```

---

### Section 2: Device Naming & Line Security

5. **Set the hostname to `LAB-SW-01` and domain name to `lab.example`:**
   ```cisco
   Switch(config)# [ ??? ]
   LAB-SW-01(config)# [ ??? ]
   ```

6. **Secure VTY lines `0` to `15` with password `<REPLACE_WITH_LAB_VTY_SECRET>`:**
   ```cisco
   LAB-SW-01(config)# [ ??? ]
   LAB-SW-01(config-line)# [ ??? ]
   ```

7. **Secure `console 0` with password `<REPLACE_WITH_LAB_CONSOLE_SECRET>`:**
   ```cisco
   LAB-SW-01(config-line)# exit
   LAB-SW-01(config)# [ ??? ]
   LAB-SW-01(config-line)# [ ??? ]
   ```

8. **Set the Privileged EXEC encrypted password to `<REPLACE_WITH_LAB_ENABLE_SECRET>`:**
   ```cisco
   LAB-SW-01(config-line)# exit
   LAB-SW-01(config)# [ ??? ]
   ```

---

### Section 3: SSH Hardening

9. **Generate RSA keys (using default 2048-bit size) and enforce SSH Version 2:**
   ```cisco
   LAB-SW-01(config)# [ ??? ]
   LAB-SW-01(config)# [ ??? ]
   ```

10. **Restrict VTY lines `0 5` to SSH only and require local database authentication:**
    ```cisco
    LAB-SW-01(config)# [ ??? ]
    LAB-SW-01(config-line)# [ ??? ]
    LAB-SW-01(config-line)# [ ??? ]
    ```

---

### Section 4: VLAN Creation & Port Configuration

11. **Create VLAN 2 and name it `USERS`:**
    ```cisco
    LAB-SW-01(config)# [ ??? ]
    LAB-SW-01(config-vlan)# [ ??? ]
    ```

12. **Assign FastEthernet ports `1/2` through `1/4` as access ports on VLAN 2:**
    ```cisco
    LAB-SW-01(config)# [ ??? ]
    LAB-SW-01(config-if-range)# [ ??? ]
    LAB-SW-01(config-if-range)# [ ??? ]
    ```

13. **Configure GigabitEthernet port `1/2` as a trunk port:**
    ```cisco
    LAB-SW-01(config)# [ ??? ]
    LAB-SW-01(config-if)# [ ??? ]
    ```

---

### Section 5: Saving Configuration

14. **Save the active configuration from RAM to NVRAM:**
    ```cisco
    LAB-SW-01# [ ??? ]
    ```

---

## 🔑 Answer Key

Below are the exact commands required for each question.

| # | Prompt | Command |
|---|---|---|
| **1** | Enter Privileged EXEC mode | `enable` |
| **2** | Enter Global Configuration mode | `config t` *(or `configure terminal`)* |
| **3a** | Access VLAN 1 Interface | `interface vlan 1` |
| **3b** | Assign IP address & Subnet | `ip address 192.0.2.10 255.255.255.0` |
| **4a** | Exit interface mode | `exit` |
| **4b** | Set Default Gateway | `ip default-gateway 192.0.2.1` |
| **5a** | Set Hostname | `hostname LAB-SW-01` |
| **5b** | Set Domain Name | `ip domain-name lab.example` |
| **6a** | Enter VTY Lines 0-15 | `line vty 0 15` |
| **6b** | Set VTY Password | `password <REPLACE_WITH_LAB_VTY_SECRET>` |
| **7a** | Enter Console Line 0 | `line console 0` |
| **7b** | Set Console Password | `password <REPLACE_WITH_LAB_CONSOLE_SECRET>` |
| **8** | Set Privileged EXEC Password | `enable secret <REPLACE_WITH_LAB_ENABLE_SECRET>` |
| **9a** | Generate RSA Keys | `crypto key generate rsa` |
| **9b** | Enforce SSH Version 2 | `ip ssh version 2` |
| **10a** | Select VTY Lines 0-5 | `line vty 0 5` |
| **10b** | Restrict input to SSH | `transport input ssh` |
| **10c** | Require local database login | `login local` |
| **11a** | Create VLAN 2 | `vlan 2` |
| **11b** | Name VLAN | `name USERS` |
| **12a** | Select Interface Range | `interface range fastEthernet 0/5-7` |
| **12b** | Set Mode to Access | `switchport mode access` |
| **12c** | Assign to VLAN 2 | `switchport access vlan 2` |
| **13a** | Select Interface | `interface fastEthernet 0/2` |
| **13b** | Set Mode to Trunk | `switchport mode trunk` |
| **14** | Save Configuration to NVRAM | `copy running-config startup-config` *(or `write memory` / `wr`)* |

---

## 📜 Full Terminal Script Reference

```cisco
Switch>enable
Switch#config t
Switch(config)#interface vlan 1
Switch(config-if)#ip address 192.0.2.10 255.255.255.0
Switch(config-if)#exit
Switch(config)#ip default-gateway 192.0.2.1

Switch(config)#hostname LAB-SW-01
LAB-SW-01(config)#ip domain-name lab.example

LAB-SW-01(config)#line vty 0 15
LAB-SW-01(config-line)#password <REPLACE_WITH_LAB_VTY_SECRET>
LAB-SW-01(config-line)#exit

LAB-SW-01(config)#line console 0
LAB-SW-01(config-line)#password <REPLACE_WITH_LAB_CONSOLE_SECRET>
LAB-SW-01(config-line)#exit

LAB-SW-01(config)#enable secret <REPLACE_WITH_LAB_ENABLE_SECRET>

LAB-SW-01(config)#crypto key generate rsa
LAB-SW-01(config)#ip ssh version 2

LAB-SW-01(config)#line vty 0 5
LAB-SW-01(config-line)#transport input ssh
LAB-SW-01(config-line)#login local
LAB-SW-01(config-line)#exit

LAB-SW-01(config)#vlan 2
LAB-SW-01(config-vlan)#name USERS
LAB-SW-01(config-vlan)#exit

LAB-SW-01(config)#interface range fastEthernet 0/5-7
LAB-SW-01(config-if-range)#switchport mode access
LAB-SW-01(config-if-range)#switchport access vlan 2
LAB-SW-01(config-if-range)#exit

LAB-SW-01(config)#interface fastEthernet 0/2
LAB-SW-01(config-if)#switchport mode trunk
LAB-SW-01(config-if)#exit
LAB-SW-01(config)#exit

LAB-SW-01#copy running-config startup-config
```
