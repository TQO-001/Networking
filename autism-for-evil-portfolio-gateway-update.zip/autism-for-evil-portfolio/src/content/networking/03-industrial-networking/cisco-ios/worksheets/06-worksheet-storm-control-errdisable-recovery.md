---
title: "Storm Control & Err-Disable Recovery Practice Worksheet & Answer Key"
description: "Scenario: Access port FastEthernet0/10 on LAB-SW-02 needs broadcast/multicast storm protection that shuts the port down on a violation, with automatic recovery after 5 minutes…"
category: "Industrial networking / Cisco IOS / Worksheets"
level: "Beginner–Intermediate"
sourcePath: "Curated networking notebook"
tags: ["industrial", "networking", "cisco", "ios", "worksheets"]
---

# Storm Control & Err-Disable Recovery Practice Worksheet & Answer Key

**Scenario:** Access port `FastEthernet0/10` on `LAB-SW-02` needs broadcast/multicast storm protection that shuts the port down on a violation, with automatic recovery after 5 minutes specifically for storm-control-caused shutdowns.

---

## 📝 Practice Worksheet

### Section 1: Storm Control Thresholds

1. **Select the interface:**
   ```text
   LAB-SW-02(config)# [ ??? ]
   ```

2. **Set broadcast storm control level to 70%:**
   ```text
   LAB-SW-02(config-if)# [ ??? ]
   ```

3. **Set multicast storm control level to 70%:**
   ```text
   LAB-SW-02(config-if)# [ ??? ]
   ```

### Section 2: Storm Control Action

4. **Set the action to shut the port down on violation:**
   ```text
   LAB-SW-02(config-if)# [ ??? ]
   ```

### Section 3: Err-Disable Recovery

5. **Enable automatic err-disable recovery specifically for the storm-control cause:**
   ```text
   LAB-SW-02(config)# [ ??? ]
   ```

6. **Set the recovery interval to 300 seconds:**
   ```text
   LAB-SW-02(config)# [ ??? ]
   ```

### Section 4: Manual Recovery (No Auto-Recovery Configured)

7. **For a cause without auto-recovery enabled, manually recover an err-disabled port by cycling it:**
   ```text
   LAB-SW-02(config)# [ ??? ]
   LAB-SW-02(config-if)# [ ??? ]
   LAB-SW-02(config-if)# [ ??? ]
   ```

### Section 5: Verification

8. **View which err-disable causes have auto-recovery enabled, and the configured interval:**
   ```text
   LAB-SW-02# [ ??? ]
   ```

9. **View which interfaces are currently err-disabled:**
   ```text
   LAB-SW-02# [ ??? ]
   ```

---

## 🔑 Answer Key

| # | Prompt | Command |
|---|---|---|
| **1** | Select interface | `interface fastEthernet0/10` |
| **2** | Broadcast storm control | `storm-control broadcast level 70.00` |
| **3** | Multicast storm control | `storm-control multicast level 70.00` |
| **4** | Shutdown action | `storm-control action shutdown` |
| **5** | Auto-recovery for storm-control | `errdisable recovery cause storm-control` |
| **6** | Recovery interval | `errdisable recovery interval 300` |
| **7a-c** | Manual recovery | `interface fastEthernet0/10` / `shutdown` / `no shutdown` |
| **8** | Show recovery config | `show errdisable recovery` |
| **9** | Show err-disabled interfaces | `show interfaces status err-disabled` |

---

## 📜 Full Terminal Script Reference

```text
LAB-SW-02(config)#interface fastEthernet0/10
LAB-SW-02(config-if)#storm-control broadcast level 70.00
LAB-SW-02(config-if)#storm-control multicast level 70.00
LAB-SW-02(config-if)#storm-control action shutdown
LAB-SW-02(config-if)#exit

LAB-SW-02(config)#errdisable recovery cause storm-control
LAB-SW-02(config)#errdisable recovery interval 300
LAB-SW-02(config)#exit

LAB-SW-02#show errdisable recovery
LAB-SW-02#show interfaces status err-disabled

LAB-SW-02#configure terminal
LAB-SW-02(config)#interface fastEthernet0/10
LAB-SW-02(config-if)#shutdown
LAB-SW-02(config-if)#no shutdown
```

**Note:** Err-disable recovery is configured per-cause, not globally — enabling it for `storm-control` doesn't affect how the switch handles a port shut down by `bpduguard` or a port-security violation. Decide auto-recovery on a cause-by-cause basis.
