---
title: "IOS File Management Practice Worksheet & Answer Key"
description: "Scenario: You're upgrading LAB-SW-02 to a new IOS image. Before doing anything, you back up the running config; after the upgrade, you verify the new image, point boot at it, and clean…"
category: "Industrial networking / Cisco IOS / Extra practice"
level: "Intermediate"
sourcePath: "Curated networking notebook"
tags: ["industrial", "networking", "cisco", "ios", "extra", "practice"]
---

# IOS File Management Practice Worksheet & Answer Key

**Scenario:** You're upgrading `LAB-SW-02` to a new IOS image. Before doing anything, you back up the running config; after the upgrade, you verify the new image, point boot at it, and clean up the old one once it's confirmed stable.

---

## 📝 Practice Worksheet

### Section 1: Inspecting Flash & Version

1. **List the contents of flash memory:**
   ```text
   LAB-SW-02# [ ??? ]
   ```

2. **View the currently running IOS version and config register:**
   ```text
   LAB-SW-02# [ ??? ]
   ```

### Section 2: Backing Up the Config

3. **Copy the running config to a TFTP server:**
   ```text
   LAB-SW-02# [ ??? ]
   ```

### Section 3: Copying a New IOS Image to Flash

4. **Copy a new IOS image from a TFTP server into flash:**
   ```text
   LAB-SW-02# [ ??? ]
   ```

### Section 4: Verifying the Image

5. **Verify the MD5 checksum of the copied image `c2960x-universalk9-mz.152-7.E5.bin`:**
   ```text
   LAB-SW-02# [ ??? ]
   ```

### Section 5: Setting Boot Image & Reloading

6. **From global config, set the switch to boot from the new image on next reload:**
   ```text
   LAB-SW-02(config)# [ ??? ]
   ```

7. **Save the config and reload:**
   ```text
   LAB-SW-02(config)# [ ??? ]
   LAB-SW-02# [ ??? ]
   LAB-SW-02# [ ??? ]
   ```

### Section 6: Cleaning Up the Old Image

8. **Delete the old image `c2960x-universalk9-mz.152-6.E3.bin` from flash (after confirming the upgrade is stable):**
   ```text
   LAB-SW-02# [ ??? ]
   ```

### Section 7: Restoring a Config from Backup

9. **Restore a saved config `LAB-SW-02-backup.cfg` from TFTP into the running config:**
   ```text
   LAB-SW-02# [ ??? ]
   ```

---

## 🔑 Answer Key

| # | Prompt | Command |
|---|---|---|
| **1** | List flash contents | `dir flash:` (or `show flash`) |
| **2** | Show version/config register | `show version` |
| **3** | Backup running config | `copy running-config tftp` |
| **4** | Copy image to flash | `copy tftp flash` |
| **5** | Verify image MD5 | `verify /md5 flash:c2960x-universalk9-mz.152-7.E5.bin` |
| **6** | Set boot image | `boot system flash:c2960x-universalk9-mz.152-7.E5.bin` |
| **7a** | Exit to EXEC | `end` |
| **7b** | Save config | `copy running-config startup-config` |
| **7c** | Reload | `reload` |
| **8** | Delete old image | `delete flash:c2960x-universalk9-mz.152-6.E3.bin` |
| **9** | Restore config from TFTP | `copy tftp running-config` |

---

## 📜 Full Terminal Script Reference

```text
LAB-SW-02#dir flash:
LAB-SW-02#show version

LAB-SW-02#copy running-config tftp
Address or name of remote host []? 10.10.1.20
Destination filename [LAB-SW-02-confg]? LAB-SW-02-backup.cfg

LAB-SW-02#copy tftp flash
Address or name of remote host []? 10.10.1.20
Source filename []? c2960x-universalk9-mz.152-7.E5.bin

LAB-SW-02#verify /md5 flash:c2960x-universalk9-mz.152-7.E5.bin

LAB-SW-02#configure terminal
LAB-SW-02(config)#boot system flash:c2960x-universalk9-mz.152-7.E5.bin
LAB-SW-02(config)#end
LAB-SW-02#copy running-config startup-config
LAB-SW-02#reload

LAB-SW-02#delete flash:c2960x-universalk9-mz.152-6.E3.bin

LAB-SW-02#copy tftp running-config
Address or name of remote host []? 10.10.1.20
Source filename []? LAB-SW-02-backup.cfg
```

**Note:** `copy tftp running-config` merges onto whatever's already running rather than replacing it — for a clean, from-scratch restore, copy into `startup-config` instead and reload, rather than into `running-config`.
