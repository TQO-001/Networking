---
title: "Basic Switch Management & Console Hardening Practice Worksheet & Answer Key"
description: "Scenario: You're standardizing baseline settings on a freshly racked switch, LAB-SW-02, before any VLAN or security work"
category: "Industrial networking / Cisco IOS / Extra practice"
level: "Intermediate"
sourcePath: "Curated networking notebook"
tags: ["industrial", "networking", "cisco", "ios", "extra", "practice"]
---

# Basic Switch Management & Console Hardening Practice Worksheet & Answer Key

**Scenario:** You're standardizing baseline settings on a freshly racked switch, `LAB-SW-02`, before any VLAN or security work begins.

---

## 📝 Practice Worksheet
*Fill in the missing commands (indicated by `[ ??? ]`) to complete each step.*

### Section 1: Hostname & Lookups

1. **Enter Privileged EXEC mode, then Global Configuration mode:**
   ```text
   Switch> [ ??? ]
   Switch# [ ??? ]
   ```

2. **Set the hostname to `LAB-SW-02`:**
   ```text
   Switch(config)# [ ??? ]
   ```

3. **Disable DNS lookups so mistyped commands fail instantly:**
   ```text
   LAB-SW-02(config)# [ ??? ]
   ```

### Section 2: Banners

4. **Configure a MOTD banner reading `AUTHORIZED ACCESS ONLY.` using `#` as the delimiter:**
   ```text
   LAB-SW-02(config)# [ ??? ]
   ```

### Section 3: Console Line Hardening

5. **Enter console line 0 configuration:**
   ```text
   LAB-SW-02(config)# [ ??? ]
   ```

6. **Enable synchronous logging so log messages don't interrupt typed commands:**
   ```text
   LAB-SW-02(config-line)# [ ??? ]
   ```

7. **Set the exec timeout to 10 minutes:**
   ```text
   LAB-SW-02(config-line)# [ ??? ]
   ```

8. **Set the command history buffer to 50 lines:**
   ```text
   LAB-SW-02(config-line)# [ ??? ]
   ```

### Section 4: Timestamps, NTP & Syslog

9. **Enable real-time (datetime) timestamps on log messages, with millisecond precision:**
   ```text
   LAB-SW-02(config)# [ ??? ]
   ```

10. **Point the switch to NTP server `192.0.2.5`:**
    ```text
    LAB-SW-02(config)# [ ??? ]
    ```

11. **Send logs to syslog server `192.0.2.6`, at the `informational` severity threshold and above:**
    ```text
    LAB-SW-02(config)# [ ??? ]
    LAB-SW-02(config)# [ ??? ]
    ```

### Section 5: Saving Configuration

12. **Exit to Privileged EXEC and save the active configuration to NVRAM:**
    ```text
    LAB-SW-02(config)# [ ??? ]
    LAB-SW-02# [ ??? ]
    ```

---

## 🔑 Answer Key

| # | Prompt | Command |
|---|---|---|
| **1a** | Enter Privileged EXEC mode | `enable` |
| **1b** | Enter Global Config mode | `configure terminal` |
| **2** | Set hostname | `hostname LAB-SW-02` |
| **3** | Disable DNS lookups | `no ip domain-lookup` |
| **4** | MOTD banner | `banner motd #AUTHORIZED ACCESS ONLY.#` |
| **5** | Enter console line | `line console 0` |
| **6** | Synchronous logging | `logging synchronous` |
| **7** | Exec timeout (10 min) | `exec-timeout 10 0` |
| **8** | History size | `history size 50` |
| **9** | Real-time timestamps | `service timestamps log datetime msec` |
| **10** | NTP server | `ntp server 192.0.2.5` |
| **11a** | Syslog host | `logging host 192.0.2.6` |
| **11b** | Syslog severity threshold | `logging trap informational` |
| **12a** | Exit to EXEC | `end` |
| **12b** | Save config | `copy running-config startup-config` |

---

## 📜 Full Terminal Script Reference

```text
Switch>enable
Switch#configure terminal
Switch(config)#hostname LAB-SW-02
LAB-SW-02(config)#no ip domain-lookup

LAB-SW-02(config)#banner motd #AUTHORIZED ACCESS ONLY.#

LAB-SW-02(config)#line console 0
LAB-SW-02(config-line)#logging synchronous
LAB-SW-02(config-line)#exec-timeout 10 0
LAB-SW-02(config-line)#history size 50
LAB-SW-02(config-line)#exit

LAB-SW-02(config)#service timestamps log datetime msec
LAB-SW-02(config)#ntp server 192.0.2.5
LAB-SW-02(config)#logging host 192.0.2.6
LAB-SW-02(config)#logging trap informational

LAB-SW-02(config)#end
LAB-SW-02#copy running-config startup-config
```
