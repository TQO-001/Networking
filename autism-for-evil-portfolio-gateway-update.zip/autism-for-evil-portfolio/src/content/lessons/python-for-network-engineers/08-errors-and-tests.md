---
title: "Errors, validation and your first tests"
description: Learn to read exceptions, reject bad input clearly, and use automated tests to check code behaviour.
order: 8
minutes: 30
level: Beginner
course: python-for-network-engineers
tags: [exceptions, validation, testing, pytest]
kind: lesson
---
Every real program encounters unexpected input: a blank field, a misspelled role, a file that moved, or text where a number was expected. The goal is not to pretend errors never happen. The goal is to identify them clearly and respond in a controlled way.

## 1. Read the error from the bottom up

Run this on purpose:

```python
vlan_id = int("twenty")
```

Python raises a `ValueError` because the text cannot be converted into an integer. Read the final line of the traceback first; it usually tells you the exception type and message. Then look upward to find which line of your code triggered it.

When you troubleshoot, note the exact input, the expected behaviour and the actual error. Avoid making several unrelated edits before rerunning the program.

## 2. Catch an expected input error

```python
vlan_text = input("Enter a VLAN ID: ")

try:
    vlan_id = int(vlan_text)
except ValueError:
    print("Please enter a whole number, for example 20.")
else:
    print(f"You entered VLAN {vlan_id}.")
```

The `try` block contains an operation that may fail in the known way. The `except ValueError` block handles that specific error. The `else` block runs only if the `try` block succeeds.

Avoid catching every possible exception just to make a program keep going. Broad catches can hide programming mistakes. Handle the errors you understand, and let unexpected errors remain visible while you debug.

## 3. Validate data before using it

Validation means checking that an input meets rules your program relies on. For example, an inventory row should have a hostname. Later, an IP address should parse as an IP address, not merely look like one.

```python
def has_hostname(hostname: str) -> bool:
    return bool(hostname.strip())
```

`strip()` removes whitespace from the start and end of a string. `bool(...)` converts an empty string to `False` and a non-empty string to `True`. Test this function with `"SW-LAB-01"`, `""` and a string containing only spaces.

## 4. A test is a repeatable question

A test turns an expectation into a check. For example: “When a hostname contains text, does `has_hostname()` return `True`?”

Install the development tools once the project's environment is set up. In this course we use `pytest`:

```python
# tests/test_inventory.py
from inventory import has_hostname


def test_hostname_with_text_is_valid():
    assert has_hostname("SW-LAB-01") is True


def test_empty_hostname_is_invalid():
    assert has_hostname("") is False


def test_whitespace_hostname_is_invalid():
    assert has_hostname("   ") is False
```

The `assert` statement checks whether an expectation is true. If it is not, pytest reports the failure. The tests live outside the application code so they can check behaviour without becoming part of the normal user-facing program.

Run the tests with:

```bash
uv run pytest
```

We will cover installing and managing the tools in a separate environment guide. If you have not set up `uv` and `pytest` yet, save the example and return after the setup section; do not silently skip the idea of testing.

## Exercise: invalid inventory row

Write a function that receives a dictionary representing one device row. It should return a list of problems: include `"missing hostname"` if the hostname is empty, and `"missing IP address"` if the IP field is empty. Write one test for a valid row and one for an invalid row.

**Done when:** you can explain the difference between an exception and a validation result, and your tests check more than the happy path.

**Next:** [Build your first network tool](/learn/python-for-network-engineers/09-build-subnet-calculator/).
