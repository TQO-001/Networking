---
title: "Read a CSV device inventory"
description: Use the standard library to load fictional asset records from a spreadsheet-friendly CSV file and report what is inside.
order: 7
minutes: 30
level: Beginner
course: python-for-network-engineers
tags: [files, csv, inventory]
kind: lesson
---
A device list stored inside Python source code is fine for an exercise, but people already maintain information in spreadsheets. CSV (comma-separated values) is a simple text format that can be opened by spreadsheet applications and read by Python.

In this lesson we will read a **fictional lab inventory**. We will not connect to devices; we will only process a local file.

## 1. Create the sample file

In your project folder, create `devices.csv` with these exact lines:

```csv
hostname,ip_address,role,vlan
SW-LAB-01,192.168.10.2,switch,10
HMI-SIM-01,192.168.20.20,hmi,20
PLC-SIM-01,192.168.20.30,plc-simulator,20
```

The first row contains column headers. The other rows hold one device each. These addresses and names are deliberately fictional examples for learning.

## 2. Read the file with `csv.DictReader`

Create `read_inventory.py`:

```python
import csv
from pathlib import Path

inventory_path = Path("devices.csv")

with inventory_path.open(newline="", encoding="utf-8") as file:
    reader = csv.DictReader(file)
    for row in reader:
        print(f"{row['hostname']} — {row['ip_address']} ({row['role']})")
```

Run it from the folder containing `devices.csv`. You should see one line for each data row.

A few details are worth understanding:

- `import csv` loads Python's built-in CSV tools. It does not require a separate package installation.
- `Path("devices.csv")` represents the file path. `pathlib` is the standard library's modern path-handling interface.
- `with ... open(...) as file` opens the file and ensures it is closed when the indented block ends, even if an error occurs.
- `csv.DictReader` uses the header row as keys. Each `row` behaves like a dictionary, so you can access `row['hostname']` by its column name.

## 3. Count the records

```python
import csv
from pathlib import Path

with Path("devices.csv").open(newline="", encoding="utf-8") as file:
    devices = list(csv.DictReader(file))

print(f"Loaded {len(devices)} records")
```

This version loads all rows into a list so we can count and inspect them more than once. For a small teaching inventory, that is straightforward. For very large files, process rows one at a time rather than automatically loading the whole file into memory.

## 4. Be precise about errors

If Python says the file cannot be found, check that the file is named `devices.csv` and that your terminal is in the directory you think it is. Many beginner errors are path errors rather than Python-logic errors.

If a report needs to be reliable, it should also check for missing columns, blank hostnames, duplicate addresses and invalid IP addresses. We will turn those ideas into the first real project.

## Exercise: find missing hostnames

Add a row with a blank hostname to `devices.csv`. Update your program so it prints a warning for rows where `hostname` is empty and prints a normal device label for the others.

**Done when:** the program reads the file without hardcoding each row, and adding another row to the CSV automatically adds it to the report.

**Next:** [Handle errors and test your work](/learn/python-for-network-engineers/08-errors-and-tests/).
