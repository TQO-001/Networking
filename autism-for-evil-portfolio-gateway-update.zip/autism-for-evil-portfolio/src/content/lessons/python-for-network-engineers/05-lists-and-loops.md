---
title: "Lists and loops: stop repeating yourself"
description: Store multiple devices in one collection and let Python process them one at a time.
order: 5
minutes: 25
level: Beginner
course: python-for-network-engineers
tags: [lists, loops, collections]
kind: lesson
---
Imagine you have 30 devices. You do not want to write a separate block of code for every device. A **list** lets you store multiple values together, and a **loop** lets Python repeat a task for each value.

## 1. Create a list

```python
devices = [
    "SW-LAB-01",
    "HMI-SIM-01",
    "PLC-SIM-01",
]

print(devices)
print(len(devices))
```

The square brackets create a list. Each text value is one **item**. `len(devices)` tells you how many items are in the list.

You can access an item by its index:

```python
print(devices[0])  # SW-LAB-01
print(devices[1])  # HMI-SIM-01
```

Python counts list indexes from zero, not one. Asking for `devices[3]` in a list containing only three items produces an error because index `3` does not exist.

## 2. Use a `for` loop

```python
for device in devices:
    print(f"Reviewing {device}")
```

Read it as: “for each item in `devices`, temporarily call that item `device` and run the indented block.” Python assigns each list item to `device` in turn.

This is an example of a **loop variable**. Its name is your choice; use a name that helps the reader understand the item.

## 3. Lists can contain dictionaries

A hostname alone is not enough for an asset inventory. We often need several fields associated with the same device. A **dictionary** stores key/value pairs:

```python
device = {
    "hostname": "SW-LAB-01",
    "ip_address": "192.168.10.2",
    "role": "switch",
}

print(device["hostname"])
print(device["ip_address"])
```

We can put multiple dictionaries in a list:

```python
devices = [
    {"hostname": "SW-LAB-01", "role": "switch"},
    {"hostname": "HMI-SIM-01", "role": "hmi"},
    {"hostname": "PLC-SIM-01", "role": "plc-simulator"},
]

for device in devices:
    print(f"{device['hostname']} is a {device['role']}")
```

There are single quotes around the dictionary keys inside the f-string so that they do not conflict with the outer quotes. If nested quotes look confusing, take your time and type the example exactly before adapting it.

## 4. Count and filter

```python
for device in devices:
    if device["role"] == "switch":
        print(f"Switch found: {device['hostname']}")
```

This combines a loop and a condition. The loop visits every item; the `if` chooses which items should produce output.

## Exercise: build a tiny lab list

Create a list containing at least three fictional devices. Each device should have a hostname and role. Loop through the list and print one sentence for every device. Then print only the devices whose role is `switch`.

**Stretch:** add an `ip_address` field to every dictionary.

**Done when:** the program works for three devices without duplicating a separate `print()` block for each one. Add a fourth device and verify your loop handles it without other code changes.

**Next:** [Functions: give a task a name](/learn/python-for-network-engineers/06-functions/).
