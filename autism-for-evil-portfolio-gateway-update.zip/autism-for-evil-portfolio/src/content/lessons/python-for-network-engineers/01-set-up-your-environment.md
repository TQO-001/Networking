---
title: "Set up Python, VS Code, uv and Git"
description: Install and verify the tools used throughout the course on Windows or Linux, then create a clean project workspace.
order: 1
minutes: 25
level: Beginner
course: python-for-network-engineers
tags: [setup, VS Code, uv, Git, Windows, Linux]
kind: guide
---
This setup lesson prepares your computer for the course. There are a few tools, but each has a specific job. We will verify each one before moving on.

## The tools, in plain language

| Tool | What it does |
|---|---|
| Python 3.14 | Runs the Python programs you write. |
| VS Code | Editor where you read and change your code. |
| VS Code Python extension | Adds Python-aware editing, interpreter selection and debugging. |
| `uv` | Installs/manages Python versions, creates project environments and tracks dependencies. |
| Git | Records changes to your files so you can review or roll back work. |
| GitHub | Hosts Git repositories online. We will publish only files that are safe to share. |

The website itself is built with Astro, which uses Node.js. That is separate from the Python toolchain taught by this course. You do not need Node.js to write the Python examples; you need it only when running or editing this portfolio website.

## Step 1 — Install VS Code

Install Visual Studio Code from its official website, then open it. In the Extensions panel, install Microsoft's **Python** extension. The extension helps VS Code recognise Python files, select an interpreter and run/debug code. It does not replace the Python interpreter itself.

## Step 2 — Install Git

Install Git for your operating system, then open a new VS Code terminal and run:

```bash
git --version
```

You should see a version number. If the command is not found immediately after installation, restart the terminal or VS Code so it refreshes its environment variables.

## Step 3 — Install uv

`uv` is the tool we will use to manage the Python version and dependencies for each project. Follow the official instructions for your operating system at [docs.astral.sh/uv](https://docs.astral.sh/uv/). Use the installer published by Astral; avoid copying installation commands from unrelated tutorial sites.

After installation, close and reopen your terminal, then run:

```bash
uv --version
```

You should see a version number. If not, check the installation instructions for adding uv to your PATH.

## Step 4 — Install Python 3.14 through uv

Run:

```bash
uv python install 3.14
uv python find 3.14
```

The first command asks uv to install a managed Python 3.14 interpreter. The second shows the interpreter location it found. This is useful when your computer's default Python belongs to the operating system or is a different version.

## Step 5 — Create the course workspace

In the terminal, go to a folder where you keep coding projects. Then run the following commands one at a time:

```bash
mkdir python-network-lab
cd python-network-lab
uv init --python 3.14
uv run python --version
```

On Windows PowerShell and Linux Bash, those `mkdir` and `cd` commands work as shown. If the folder already exists, open it with `cd python-network-lab` instead of creating it again.

`uv init` creates a small Python project with configuration and a starter file. `uv run` executes Python within the project's managed environment. The version command should report Python 3.14.x.

## Step 6 — Open the folder in VS Code

If the `code` terminal command is available, run:

```bash
code .
```

Otherwise, choose **File → Open Folder** in VS Code and open `python-network-lab`. You should see files such as `pyproject.toml`, `.python-version`, `.gitignore` and `main.py`. These are normal project files; keep them rather than deleting everything except the Python script.

## Step 7 — A quick health check

Create a file named `environment_check.py` and enter:

```python
import sys

print(f"Python version: {sys.version}")
print(f"Python executable: {sys.executable}")
print("Course environment is ready")
```

Run it from the project folder:

```bash
uv run python environment_check.py
```

The version line tells you what Python ran; the executable line shows which interpreter path was used. The path may differ between Windows and Linux. That is expected.

## Common setup problems

- **`uv` is not found:** restart your terminal and re-check the installation/PATH instructions.
- **Python reports the wrong version:** run `uv python find 3.14`, confirm you are inside the course folder, and use `uv run python --version`.
- **VS Code uses a different interpreter when you press Run:** prefer the documented terminal command `uv run python your_file.py` while learning. It makes the environment explicit.
- **The `code` command is missing:** open the folder from VS Code's File menu.
- **Git works in one terminal but not another:** reopen the terminals after installing Git.

## What are `venv` and `pip`?

You may see tutorials use `python -m venv .venv` and `pip install package-name`. These are the traditional built-in environment and package-install tools. `uv` can manage environments and installations for you, but the underlying concepts still matter: each project should have isolated dependencies, dependencies should be documented, and the same project should be reproducible on another machine. We will compare the workflows in a separate reference note rather than mixing all of their commands into the first exercise.

## Checkpoint

Before continuing, confirm all four commands return sensible output:

```bash
uv --version
uv python find 3.14
uv run python --version
git --version
```

You are ready when the course can run Python 3.14 from the project folder. Do not install `psutil`, Scapy, `asyncua` or PyModbus yet. We will add libraries only when a project needs them.

**Next:** [Your first Python program](/learn/python-for-network-engineers/02-your-first-program/).
