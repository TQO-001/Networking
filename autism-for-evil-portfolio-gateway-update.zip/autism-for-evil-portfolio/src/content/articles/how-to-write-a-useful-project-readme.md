---
title: What makes a project README useful?
description: A small checklist for documenting a technical project so another person can understand and reproduce it.
date: "2026-10-22"
tags: [documentation, Git, software-engineering]
status: draft
featured: false
---
A README is a handover document, not an advertisement. It should let a new reader answer five questions quickly: what problem does this solve, what does it do, how do I run it, how do I verify it, and what are its limitations?

For a network engineering tool, it should also describe the expected input, the environment in which it was tested and whether it touches a network or only reads local files. A tool that makes a claim about reachability needs to explain what check it performs and what its result can—and cannot—prove.

A practical structure is:

1. **Purpose:** one paragraph describing the problem.
2. **Features:** the actual behaviours implemented today.
3. **Requirements:** language version and dependencies.
4. **Setup:** copyable commands for a clean environment.
5. **Usage:** input and output examples using fictional data.
6. **Tests:** exact command and current results.
7. **Limitations and safety:** supported cases, known gaps and intended scope.
8. **Roadmap:** future ideas clearly separated from completed features.

The most important rule is to keep the README honest. Don't list planned capabilities as if they already work, and don't say a project is production-ready because it runs on one machine.
