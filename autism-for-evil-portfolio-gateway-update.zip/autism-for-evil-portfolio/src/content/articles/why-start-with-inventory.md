---
title: Why I want an inventory before a scanner
description: Asset data is a useful first programming problem because it teaches validation without needing to touch a live network.
date: "2026-10-22"
tags: [OT, asset-management, Python]
status: draft
featured: false
---
A network tool is only as useful as the assumptions it makes about its targets. Before I automate any checks, I want to be able to read a known list of fictional or approved lab devices and catch the easy mistakes: duplicate addresses, blank hostnames, malformed IP strings and inconsistent role labels.

That is a good Python exercise because it can be completed entirely offline. It teaches data structures, files, validation, errors and tests while keeping the experiment safe and repeatable.

Later, the inventory can become the input to a controlled reachability monitor. The tool should make it obvious which targets it will check, record what it actually measured, and avoid implying that one failed check proves a device is broken.

This is still a learning note. As the project develops, I will replace the outline with implementation details, test cases, screenshots that contain only fictional information, and lessons from debugging.
