---
title: Learning Python through OT networking problems
description: Why I am approaching Python through practical network tools instead of unrelated beginner exercises.
date: "2026-10-22"
tags: [python, OT, learning-in-public]
status: draft
featured: true
---
I want to learn Python in a way that makes me better at my work as an OT network engineer. That means using real engineering questions as the motivation: how do we keep an asset inventory consistent, how do we spot a missing response, and how do we turn logs into a useful summary?

The first tools in this learning path will be intentionally small. A subnet calculator teaches input, functions and validation. An asset inventory checker teaches dictionaries, files and CSV. A reachability monitor introduces timing, logging and the limits of network tests.

The goal is not to claim that a beginner script is a production monitoring platform. It is to learn how to make a small tool dependable: define its inputs, handle failure, test edge cases, document assumptions and make it easy for another person to run.

I will keep this site as a public learning record. Completed projects will have source code and test evidence; ideas that are not built yet will be clearly labelled as plans.

## What I am prioritising

- Python fundamentals before specialist libraries.
- The standard library before extra dependencies.
- A clear `src/` layout once projects grow beyond a single file.
- Tests and readable errors, not just code that works once.
- A lab-first approach for monitoring and industrial protocols.

The learning path begins with the smallest useful tool and grows from there.
