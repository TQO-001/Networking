# Asset credits and image placeholders

The home page and About page currently use **temporary remote stock placeholders** to prototype the cut-out / “popping into the layout” portrait treatment. They are not images of Thulani and must not be presented as if they are.

- Standing portrait placeholder: [Rawpixel image result](https://images.rawpixel.com/image_png_social_portrait/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDI0LTExL3Jhd3BpeGVsX29mZmljZV8zMl9hX3Byb2Zlc3Npb25hbF9mdWxsLWJvZHlfcG9ydHJhaXRfb2ZfYW1lcmljYV84NjM3YTg5NS01ODYwLTQ4YjktODRlYy1lMjU4YzFkMDBmNDMucG5n.png).
- Seated portrait placeholder: [Rawpixel image result](https://images.rawpixel.com/image_png_social_square/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDI0LTA4L3Jhd3BpeGVsX29mZmljZV8zMl9waG90b19vZl9hX3lvdW5nX2FmcmljYW5fbWFuX2hhcHB5X29uX2FybWNoYV81Y2U0ZmZjMC1hMjQ0LTRiNTQtYTU5OS01YmUxNGIyNGE0YTUucG5n.png).

These URLs were used as visual references/placeholders; their licence and suitability for use on a publicly deployed commercial portfolio have **not** been verified. The images are hotlinked and can disappear or be blocked. Before launch, replace them with a personal photo you choose or assets licensed for the intended use, then update alt text to describe the actual image accurately.

The `PlasmaWave` component is integrated from the implementation supplied in the build request and adapted for the site's purple/blue palette. The interface marks the canvas as decorative (`aria-hidden`) so the hero's text remains the primary content.

Upstream attribution: **React Bits / David Haz**, [react-bits repository](https://github.com/DavidHDev/react-bits), [current license](https://github.com/DavidHDev/react-bits/blob/main/LICENSE.md). As checked on 22 October 2026, the repository identifies its license as **MIT + Commons Clause**. It permits using the component in an application or website, including commercial applications, but restricts selling, sublicensing, or redistributing the component itself, including in a bundle. A deployed portfolio is different from publishing the component source. **Before making this source repository public, review the clause; keep the source private or replace the component if the terms make public source redistribution unsuitable.**


## Intro gateway visual effects

The name gateway (`/`) uses lightweight Canvas 2D adaptations for the requested React Bits `TechText`, `SideRays`, and `GhostCursor` interactions. `PlasmaWave` remains on the main portfolio homepage. The canvas adaptations are intentionally kept lighter than the supplied full WebGL/advanced source so the first page does not run several full-screen GPU effects simultaneously. Upstream attribution: [React Bits / David Haz](https://github.com/DavidHDev/react-bits), [Tech Text](https://reactbits.dev/text-animations/tech-text), [Side Rays](https://reactbits.dev/c/backgrounds/side-rays), and [Ghost Cursor](https://reactbits.dev/animations/ghost-cursor). Before publishing component source publicly, review the current [React Bits license](https://github.com/DavidHDev/react-bits/blob/main/LICENSE.md) and the Commons Clause restrictions.
